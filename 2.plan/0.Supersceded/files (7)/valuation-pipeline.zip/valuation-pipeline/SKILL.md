---
name: valuation-pipeline
description: XPV valuation pipeline, build 11.3. Finds a portfolio company's files in the knowledge sources (valuation workbooks, financial statements, monthly summaries), maps how its LP numbers are built for the requested quarter, proves period and meaning first, records a named approval with one decision per exception, files the user's documents and facts, explains any number, and runs the private answer-key verify. Use for any request to onboard, map, check, approve, attest, verify, explain, file, or find files for a portfolio company's valuation, or to run the pipeline self-test.
---

# Valuation pipeline (build 11.3)

`scripts/pipeline.py` does all the work. Run ONE command at a time and do exactly what its printed lines say.
Never open, read, summarise or check workbooks yourself; never calculate numbers; never run other scripts.

## Glossary
| Term | Meaning |
|---|---|
| Limited partner (LP) report | XPV's quarterly investor report; the pipeline works back from each company's LP numbers |
| Requested valuation date | The quarter-end the analyst asked for; gather adds it to the onboarding command as `--period-end` |
| Exception | A finding that needs its own explicit decision before approval (one decision each, never as a group) |
| Company file | `<company_id>_company.zip`: one company's map, facts, evidence, decisions and approvals (saved to SharePoint) |
| Knowledge sources | Valuation Workbooks, Company Financial Statements, Monthly Summaries, LP_reports |

## Playbook A - "Onboard <company> for <quarter>" (the main job)
1. **Search knowledge:** *Valuation Workbooks* "<company> <quarter> valuation workbook" and "<company> <previous quarter> valuation workbook"; *Company Financial Statements* "<company> <month> <year>" for each month of the quarter; *Monthly Summaries* "<company> monthly summary <quarter>".
2. **Gather:** `python scripts/pipeline.py gather --company "<company>" --quarter "<quarter>"`
3. **Fill gaps, at most twice:** for each `NEED:` line, run exactly the search it names, then gather again.
4. **Onboard:** run the `THEN:` command gather printed, unchanged (it includes `--period-end`).
5. **Follow the printed lines** until `READINESS:` (JUDGMENT NEEDED, SHAREPOINT, RECALC, THEN).
6. **Report:** post from `ONBOARD:` to `READINESS:` unchanged. Then ONE message: anything under `NEED:`; "For each EXCEPTIONS item, give one of its options and a reason"; "Reply 'approve as <your name>' with any corrections."
7. **Approve** only when the user's latest message approves, with a decision for every exception (command below). If `APPROVAL REFUSED:` prints, post it and ask once for what it lists.

## Playbook B - from the user
- **Files** uploaded or linked: `add --files "<name>" ... --company "<company>" --by "<user's name>"`; post the INTAKE lines.
- **A fact or number** they state: after onboarding, `add --company "<company>" --fact "<what it is>" --value "<the number exactly as said>" --by "<name>" --said "<their exact words>"`. Never calculate, convert or infer it.
- **The analyst names the right cell** ("EV is Valuation!C21"): re-run the onboarding command adding `--cells '{"enterprise_value": "Valuation!C21"}' --by "<name>" --said "<their exact words>"`. Fields: enterprise_value, equity_value, investor_value, ebitda_adjusted, multiple_ebitda, revenue_ttm.
- **The analyst says which entity a blocked statement belongs to:** re-run the onboarding command adding `--entities '{"<file name>": "<entity>"}' --by "<name>"`.
- **Desktop Excel recalculation done** (after `VERIFICATION: not verified`): `attest --company "<company_id>" --by "<name>" --refreshed "<links / add-ins refreshed, or none>" --unresolved "<what could not refresh, or none>" --outputs-checked "<which LP values they compared>" --said "<their exact words>"`.
- **"How did other companies handle <acquisitions / pro forma / waterfalls>?"**: search *Valuation Workbooks* for that word, then `reference --feature <acquisition|pro_forma|waterfall|cap_table|linked_workbooks|quarter_named_sheets> --workbooks "<names found>"` (up to 5). Structure only; never copy numbers between companies.
- **"What do we have for <company>?"**: `status --company "<company>"`. **"Where does this number come from?"**: `explain`.

## Playbook C - authorised verify (answer key)
"Verify <test id>": the analyst has filled a PRIVATE answer key (`references/answer_key_template.json`) and uploaded it. Search knowledge as in Playbook A step 1 for its company and quarter, then `python scripts/pipeline.py verify --key "<answer key file name>"`. Post the `VERIFY:` lines unchanged; never post anything else from verify, never quote the key.

## Commands
| Job | Command |
|---|---|
| Self-test | `python scripts/pipeline.py selftest` |
| Choose a company's files | `python scripts/pipeline.py gather --company "<company>" --quarter "<Q2 2026>"` |
| Onboard | the `THEN:` line gather printed (`--period-end` included). Options: `--cells '<JSON>'`, `--entities '<JSON>'`, `--by`, `--said`; `--excel-diagnostic` only when the user asks for the Excel diagnostic |
| Answer a judgment (after exit 10) | re-run the SAME command adding `--answers '<one-line JSON>'` |
| After an Excel stage | the `THEN:` command printed (it carries `--stage probe`, `--stage recalc` or `--stage read` when staged); if Run script failed, the `IF RUN SCRIPT FAILS:` command |
| Approve | `python scripts/pipeline.py approve --company "<company_id>" --by "<approver's name>" --decisions '<JSON {"A-id": "<option>: <reason>"}>' [--changes '<JSON {"A-id": "correction"}>'] --said "<the user's exact words>"` |
| Attest a desktop recalculation | `python scripts/pipeline.py attest --company "<company_id>" --by "<name>" --refreshed "..." --unresolved "..." --outputs-checked "..." --said "<exact words>"` |
| Verify (private answer key) | `python scripts/pipeline.py verify --key "<answer key file name>"` |
| Explain | `python scripts/pipeline.py explain "<A-id, field name or Sheet!Cell>" --company "<company_id>"` |
| Status | `python scripts/pipeline.py status --company "<company>"` |
| File the user's files | `python scripts/pipeline.py add --files "<name>" ... --company "<company>" --by "<name>"` |
| Record a stated fact | `python scripts/pipeline.py add --company "<company>" --fact "<what>" --value "<as stated>" --by "<name>" --said "<exact words>"` |
| Other companies' structure | `python scripts/pipeline.py reference --feature <feature> --workbooks "<name>" ...` |
| Portfolio overview (only when asked) | `python scripts/pipeline.py census --workbooks "<name>" ...` |

Pass files **by name**, exactly as fetched or uploaded (no folder path). The script finds them.

## Printed lines (your interface)
| Line starts with | What you do |
|---|---|
| `GATHER:` `ONBOARD:` `CENSUS:` `READING:` `PERIODS:` `METHOD:` `BUILD:` `TRACE:` `LEARNED:` `HAVE:` `REFERENCE:` `INTAKE:` `STATUS:` `LP FIELDS:` `LIVENESS:` `VERIFICATION:` `INPUTS:` `LINE MAP:` `EVIDENCE:` `REVIEW:` `EXCEPTIONS:` `PERIOD GATE:` `STATEMENTS:` `FILE:` `CHECK:` `VERSION:` | Part of the report: post unchanged when NEXT says so |
| `NEED:` `OPTIONAL:` | In gather: search for exactly what it names. Elsewhere: ask the user for NEED items in one message after the report |
| `SHAREPOINT: Create new folder` | SharePoint *Create new folder* with that library and path; if it exists, continue |
| `SHAREPOINT: Create file` | SharePoint *Create file* with that folderPath and name; the body is the printed `/app/created/...` path, never file content or base64 |
| `SHAREPOINT: SKIP` | Do not save that file; give it to the user as a download |
| `RECALC:` | *Run script from SharePoint library* ONCE on the file whose Id Create file returned, with the printed `cells` text copied exactly (a list, or a `{"mode": ...}` object for a staged step - do not retype it). `RECALC: skipped (...)` means no Excel step; `RECALC: <stage> stage ok` is information |
| `RECALC RULES:` | Obey it: if Run script fails, times out or returns an error, run the `IF RUN SCRIPT FAILS:` command at once. Never retry Run script |
| `THEN:` | Run that command exactly; for an Excel step, pass the Run script result exactly as returned between the JSON markers |
| `IF RUN SCRIPT FAILS:` | Only if Run script failed or timed out: run that command with the error text exactly as returned |
| `JUDGMENT NEEDED` | Answer each `Q-` item (rules below), then re-run with `--answers` |
| `READINESS:` `APPROVED:` `ATTESTED:` `EXPLAIN:` `ALL SELFTESTS:` | Post unchanged |
| `APPROVAL REFUSED:` | Post unchanged; ask the analyst once for a decision on each listed exception (or the fix it names). Save nothing |
| `VERIFY:` | Post unchanged; these lines carry no values, names or cells |
| `STOPPED:` | Tell the user exactly what it says and stop. Save nothing |
| `PIPELINE ERROR:` | Report it exactly and stop; if it names a missing file, search knowledge for it once, else ask the user |
| `NEXT:` | The instruction for the rest of your turn. Follow it literally |

Exit codes: 0 done (follow NEXT) | 10 JUDGMENT NEEDED | 20 waiting for a tool step | 3 STOPPED or APPROVAL REFUSED (the user must act) | 1 error.

## Exceptions and decisions (approval)
Each `EXCEPTIONS:` item lists its options. Map the analyst's words to ONE option per item, in one line of JSON with their reason after a colon, e.g. `{"A-1a2b3c4d": "intentional_lag: the company reports one month late", "A-5e6f7a8b": "carry_values: peers feed updated yearly"}`. Options: `intentional_lag`, `fiscal_year_basis` (period conflicts); `accepted`; `restore_formula`; `carry_values` (linked workbook); `exclude_file` (blocked statement); `accept_python_checks_only` (Excel did not verify). Fix-first options (`wrong_cells_selected`, `workbook_defect`, `provide_linked_workbook`, `rerun_with_entity`, `attest_first`) make approve refuse and say what to do. Never choose an option the analyst did not give; if their words fit none, ask.

## Answering JUDGMENT NEEDED
- **Choice items** list options `a)`, `b)`... Choose the option whose label and position fit best; for line-map items prefer the statement line with the same meaning (revenue with revenue, cash with cash). Answer `"none"` if nothing fits.
- **Calculation items** show a `target`, its formula and labelled `input` cells. Answer with the cells that reproduce the target: `{"op": "sum", "terms": [["Valuation!B21", 1], ["Valuation!B22", 1], ["Valuation!B23", -1]]}` (or `"op": "product"`, where -1 divides). Use only printed cells or cells in the formula. Python checks it against Excel's value.
- All items in ONE line of JSON: `{"Q-1a2b3c4d": "a", "Q-5e6f7a8b": {"op": "sum", "terms": [...]}}`. Never invent cells or numbers.

## Rules
- Knowledge is only for fetching files for the scripts; never for answering valuation questions or quoting numbers.
- One company per conversation; approve in the same conversation (the company file is not in knowledge).
- Uploads (20 per conversation) only for files not in SharePoint.
- Quarterly generation (refresh) is not in build 11.3: say so if asked.
