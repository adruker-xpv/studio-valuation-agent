# run_selftest.py (v10, phase 1) - every test runs the pipeline command line exactly as the agent does, on synthetic
# files generated in code. Prints one PASS/FAIL line per test and a final "ALL SELFTESTS:" line.
import datetime, json, os, re, shutil, subprocess, sys, tempfile, traceback, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(PKG, "scripts"))
import fixtures as FX

PIPE = os.path.join(PKG, "scripts", "pipeline.py")
CHECK = os.path.join(PKG, "tools", "check_package.py")
ROOT = tempfile.mkdtemp(prefix="v11_selftest_")
NOW = "2026-10-06T12:00:00"
RESULTS = []
Q2 = [(2026, 4), (2026, 5), (2026, 6)]


def env(out):
    e = dict(os.environ, VALUATION_NOW=NOW, VALUATION_UPLOAD_ROOT=out, PYTHONDONTWRITEBYTECODE="1")
    return e


def run(args, cwd, out, stdin=None):
    os.environ["VALUATION_FILE_ROOTS"] = cwd           # gather looks only in this test's folder
    p = subprocess.run([sys.executable, PIPE] + args + ["--out", out] if args[0] not in ("selftest", "version", "gather") else
                       [sys.executable, PIPE] + args, cwd=cwd, env=env(out), input=stdin, capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


def case(name):
    d = os.path.join(ROOT, re.sub(r"[^A-Za-z0-9]+", "_", name))
    up, out = os.path.join(d, "uploads"), os.path.join(d, "out")
    os.makedirs(up), os.makedirs(out)
    return up, out


def wb(up, name="AlphaWater_valuation_Q2-2026.xlsx", **kw):
    FX.company_workbook(os.path.join(up, name), **kw)
    return name


def stm(up, yms=Q2, **kw):
    return [os.path.basename(p) for p in FX.statements(up, yms, **kw)]


def onboard(up, out, w, s=(), extra=()):
    return run(["onboard", "--workbook", w, "--statements", *s, "--company", "Alpha Water Inc", *extra], up, out)


def simulated_script_result(out, copy_name, cells, change=None, refused=False, wrap=True):
    """what recalc-and-read.ts v3 returns, built from the copy's saved values (Excel would return the same)."""
    from openpyxl import load_workbook
    from wbutil import parse_ref_str, ref_str
    p = os.path.join(out, "onboarding", copy_name)
    if refused:
        obj = {"version": 3, "guard": "refused", "workbook": copy_name, "reason": "name must contain __copy or __draft"}
    else:
        w = load_workbook(p, data_only=True)
        vals = {}
        for c in cells:
            k = parse_ref_str(c)
            v = w[k[0]].cell(k[1], k[2]).value
            if isinstance(v, datetime.datetime):
                v = (v.date() - datetime.date(1899, 12, 30)).days
            vals[c] = v
        if change:
            vals[change[0]] = change[1]
        obj = {"version": 3, "guard": "ok", "workbook": copy_name, "seconds": 4.2, "calculation_mode": "Automatic",
               "values": vals, "errors": {}, "error_count_total": 0, "error_sample": []}
    return json.dumps({"result": json.dumps(obj)}) if wrap else json.dumps(obj)


def recalc_args(text):
    cells = json.loads(re.search(r"\| cells: (\[.*\])", text).group(1))
    copy = re.search(r"Id that Create file returned for (\S+__copy\.xlsx)", text).group(1)
    return cells, copy


def copy_writable(src, dst):
    """copy file contents only: the installed skill folder can be read-only, and its permission bits must not be copied."""
    for root, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        rel = os.path.relpath(root, src)
        os.makedirs(os.path.join(dst, rel), exist_ok=True)
        for f in files:
            shutil.copyfile(os.path.join(root, f), os.path.join(dst, rel, f))


def test(name):
    def deco(fn):
        def wrapped():
            try:
                fn()
                RESULTS.append((name, True, ""))
            except AssertionError as e:
                RESULTS.append((name, False, str(e)[:600]))
            except Exception as e:
                RESULTS.append((name, False, f"{type(e).__name__}: {e}\n{traceback.format_exc()[-800:]}"))
        wrapped.__name__ = fn.__name__
        TESTS.append(wrapped)
        return wrapped
    return deco


TESTS = []


def has(text, *needles):
    for n in needles:
        assert n in text, f"expected {n!r} in output:\n{text[-2500:]}"


# ------------------------------------------------------------------------------------------------ T0 guardrails
@test("T0.1 identical inputs and clock give a byte-identical company file")
def t01():
    zs = []
    src, _ = case("t01_src")
    w, s = wb(src), stm(src)
    for i in range(2):
        up, out = case(f"t01_{i}")
        for n in [w] + s:
            shutil.copyfile(os.path.join(src, n), os.path.join(up, n))
        rc, o = onboard(up, out, w, s)
        assert rc == 20, o
        zs.append(open(os.path.join(out, "alpha-water_company.zip"), "rb").read())
    assert zs[0] == zs[1], "company files differ between identical runs"


@test("T0.2 release check catches a deny-listed term, junk folders and a nested skill; a clean package passes")
def t02():
    d = os.path.join(ROOT, "t02")
    copy_writable(PKG, os.path.join(d, "clean"))
    deny = os.path.join(d, "deny.txt")
    term = "zebra" + "corp"                      # built at run time so this test file never contains the term
    open(deny, "w").write(f"# test list\n{term}\n")
    rc, o = subprocess.run([sys.executable, CHECK, os.path.join(d, "clean"), "--deny-list", deny], capture_output=True, text=True).returncode, ""
    assert rc == 0, "clean package failed the release check"
    dirty = os.path.join(d, "dirty")
    copy_writable(os.path.join(d, "clean"), dirty)
    os.makedirs(os.path.join(dirty, "scripts", "~BROMIUM"))
    open(os.path.join(dirty, "scripts", "~BROMIUM", "x.py"), "w").write("stub")
    open(os.path.join(dirty, "references", "notes.md"), "w").write("Quarterly numbers for " + term.title() + " Ltd")
    os.makedirs(os.path.join(dirty, "nested"))
    open(os.path.join(dirty, "nested", "SKILL.md"), "w").write("---\nname: x\n---")
    p = subprocess.run([sys.executable, CHECK, dirty, "--deny-list", deny], capture_output=True, text=True)
    assert p.returncode == 1, p.stdout
    has(p.stdout, "~BROMIUM", f"deny-listed term '{term}' inside references/notes.md", "nested or extra SKILL.md")


@test("T0.3 every protocol line printed is documented in SKILL.md (the printed lines are the agent's interface)")
def t03():
    up, out = case("t03")
    w = wb(up)
    rc, o = onboard(up, out, w, stm(up))
    cells, copy = recalc_args(o)
    rc2, o2 = run(["check-recalc", "--company", "alpha-water", "--values", "-"], up, out, simulated_script_result(out, copy, cells))
    rc3, o3 = run(["approve", "--company", "alpha-water", "--by", "Test Analyst"], up, out)
    rc4, o4 = run(["census", "--workbooks", w], up, out)
    skill = open(os.path.join(PKG, "SKILL.md"), encoding="utf-8").read()
    sys.path.insert(0, os.path.join(PKG, "scripts"))
    from pipeline import PREFIXES
    for text in (o, o2, o3, o4):
        for line in text.splitlines():
            m = re.match(r"^([A-Z][A-Z ]{2,}?)(:| \()", line)
            if m and not line.startswith("- "):
                pre = m.group(1) + (":" if m.group(2) == ":" else "")
                assert any(line.startswith(p) for p in PREFIXES), f"undocumented protocol line: {line[:80]}"
    for p in PREFIXES:
        assert f"`{p.rstrip(':')}" in skill or p in skill, f"SKILL.md does not document {p}"


# ------------------------------------------------------------------------------------------------ T1 census / analysis
@test("T1.1 census: a standard EV/EBITDA workbook is understood with every required LP field proven and no findings")
def t11():
    up, out = case("t11")
    w = wb(up)
    rc, o = run(["census", "--workbooks", w], up, out)
    assert rc == 0, o
    has(o, "| AlphaWater_valuation_Q2-2026.xlsx | READY TO ONBOARD | 2026-06 | 12-month window ending 2026-06 (fixed range, moved by hand) | aligned | ev_ebitda | ttm_adjusted_ebitda |",
        "READING: AlphaWater_valuation_Q2-2026.xlsx")
    j = json.load(open(os.path.join(out, "census", "census_2026-10-06.json")))
    wbk = j["workbooks"][0]
    for f in ("enterprise_value", "equity_value", "investor_value", "ebitda_adjusted", "multiple_ebitda", "moic"):
        assert wbk["lp_fields"]["fields"][f]["status"] == "verified", (f, wbk["lp_fields"]["fields"][f])
    assert wbk["findings"] == [] and wbk["unproven_identities"] == [], wbk["findings"]
    assert wbk["method"]["components"][0]["multiple_cell"] == "Valuation!B16"
    assert wbk["diagnostics"]["external_links"]["scope"] == "LP dependency graph" and "workbook_total" in wbk["diagnostics"]["external_links"]
    md = open(os.path.join(out, "census", "census_2026-10-06.md")).read()
    has(md, "## Glossary", "Trailing twelve months (TTM)")


def analyze_fx(**kw):
    from analyze import analyze
    d = os.path.join(ROOT, "an_" + "_".join(f"{k}{v}" for k, v in sorted(kw.items())))
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, "AlphaWater_valuation_Q2-2026.xlsx")
    FX.company_workbook(p, **kw)
    return analyze(p)


@test("T1.2 a typed TTM total is a pasted calculation with the formula that restores it")
def t12():
    a = analyze_fx(pasted_ttm=True)
    f = [x for x in a["findings"] if x["kind"] == "pasted_calculation"]
    assert len(f) == 1 and "=SUM(Monthly!N8:Y8)" in f[0]["text"], a["findings"]
    assert a["liveness"]["L2"]["result"].startswith("1 PASTED")


@test("T1.3 a typed copy of the LP value is found (L1) with the formula that links it")
def t13():
    a = analyze_fx(hardcoded_lp=True)
    f = [x for x in a["findings"] if x["kind"] == "hardcoded_output"]
    assert len(f) == 1 and f[0]["cell"] == "'LP Summary'!C4" and f[0]["proposed_formula"] == "=Valuation!B26", a["findings"]


@test("T1.4 a TTM window that ends a month early is found (L5), naming both months")
def t14():
    a = analyze_fx(ttm_off=True)
    f = [x for x in a["findings"] if x["kind"] == "metric_window"]
    assert f and "2025-06..2026-05" in f[0]["text"] and "2026-06" in f[0]["text"], a["findings"]


@test("T1.5 add-in cells are listed; external links, manual calculation and errors upstream are L3 findings")
def t15():
    a = analyze_fx(add_in=True)
    assert a["addins"] and a["addins"][0]["cell"] == "Valuation!B10" and a["liveness"]["L3"]["result"] == "PASS"
    for kw, kind in ((dict(external=True), "external_link"), (dict(manual_calc=True), "manual_calculation"),
                     (dict(error_in_chain=True), "error_in_chain")):
        a = analyze_fx(**kw)
        assert any(x["kind"] == kind for x in a["findings"]), (kind, a["findings"])


@test("T1.6 blended method: weights 0.25 / 0.75 read from the weight cell and proven")
def t16():
    a = analyze_fx(variant="blended")
    assert a["method"]["variant"] == "blended" and a["method"]["weights"]["revenue"] == 0.25, a["method"]
    assert a["lp_fields"]["multiple_revenue"]["status"] == "verified"


@test("T1.7 FX: value to XPV is the USD cell, proven as local value / FX rate")
def t17():
    a = analyze_fx(fx=True)
    assert a["method"]["fx_rule"] == "divide" and a["lp_fields"]["investor_value"]["cell"] == "Valuation!B28", a["lp_fields"]["investor_value"]
    assert a["lp_fields"]["fx_rate"]["status"] == "verified"


@test("T1.8 a company held at cost is recognised (value = invested capital), with no EV findings")
def t18():
    a = analyze_fx(variant="held_at_cost")
    assert a["method"]["variant"] == "held_at_cost", a["method"]
    assert not [x for x in a["findings"] if x["kind"] == "field_not_found"], a["findings"]


@test("T1.9 cells that feed no LP field are never classified (only counted)")
def t19():
    a = analyze_fx()
    cells = {i["cell"] for i in a["inputs"]}
    assert "Valuation!B30" not in cells and not any(m["label"] == "Headcount" for m in a["monthly_lines"])
    assert a["typed_numbers"]["untouched"] > 0


@test("T1.10 month headers that are formulas (=EOMONTH) still form a monthly block")
def t110():
    a = analyze_fx(formula_headers=True)
    assert a["blocks"] and a["blocks"][0]["months"] == 24 and a["method"]["metric_basis"] == "ttm", a["blocks"]


# ------------------------------------------------------------------------------------------------ T1 onboarding
@test("T1.11 onboarding with 3 overlap months in thousands: statement rows matched on every month at scale 1000")
def t111():
    up, out = case("t111")
    rc, o = onboard(up, out, wb(up), stm(up))
    assert rc == 20, o
    has(o, "5 matched all overlap months", "RECALC: Run script from SharePoint library", "__copy.xlsx")
    from company_file import read
    parts, _ = read(os.path.join(out, "alpha-water_company.zip"))
    ents = {e["label"]: e for e in parts["line_map"]["entries"]}
    assert ents["Revenue"]["scale"] == 1000 and ents["Revenue"]["evidence"] == "matched_all_overlap_months"
    assert ents["Revenue"]["months_matched"] == ["2026-04", "2026-05", "2026-06"]
    assert not [i for i in parts["assumptions"]["items"] if i["review"] and "adjustment" in i["text"].lower()], "adjustment rows must not be review items"


@test("T1.12 a renamed statement line ('Sales') is still matched by its numbers")
def t112():
    up, out = case("t112")
    rc, o = onboard(up, out, wb(up), stm(up, rename_revenue=True))
    from company_file import read
    parts, _ = read(os.path.join(out, "alpha-water_company.zip"))
    e = [x for x in parts["line_map"]["entries"] if x["label"] == "Revenue"][0]
    assert e["statement"]["label"] == "Sales" and e["evidence"] == "matched_all_overlap_months", e


@test("T1.13 one differing month: JUDGMENT NEEDED, then the AI answer is recorded and listed for review")
def t113():
    up, out = case("t113")
    w, s = wb(up), stm(up, mismatch=("opex", (2026, 5), 7))
    rc, o = onboard(up, out, w, s)
    assert rc == 10, o
    has(o, "JUDGMENT NEEDED", "Operating expenses", "note: 2026-05")
    qid = re.search(r"^(Q-[0-9a-f]{8}) ", o, re.M).group(1)
    rc, o = onboard(up, out, w, s, ["--answers", json.dumps({qid: "a"})])
    assert rc == 20, o
    from company_file import read
    parts, ledger = read(os.path.join(out, "alpha-water_company.zip"))
    e = [x for x in parts["line_map"]["entries"] if x["label"] == "Operating expenses"][0]
    assert e["evidence"] == "title_confirmed_by_ai", e
    assert any(i["review"] and i["basis"] == "AI judgement" for i in parts["assumptions"]["items"])
    assert any(x["event"] == "judgment_answered" for x in ledger)


@test("T1.14 a single overlap month is accepted as weaker evidence and listed for review")
def t114():
    up, out = case("t114")
    rc, o = onboard(up, out, wb(up), stm(up, [(2026, 6)]))
    assert rc == 20, o
    has(o, "single period")


@test("T1.15 period gate: next quarter's statements with this quarter's workbook STOP, naming both periods; nothing saved")
def t115():
    up, out = case("t115")
    rc, o = onboard(up, out, wb(up), stm(up, [(2026, 7), (2026, 8), (2026, 9)]))
    assert rc == 3, o
    has(o, "STOPPED: period gate", "2026-07..2026-09", "valued at 2026-06", "2026-04..2026-06")
    assert not os.path.exists(os.path.join(out, "alpha-water_company.zip"))


def onboarded(name, **kw):
    up, out = case(name)
    rc, o = onboard(up, out, wb(up, **kw), stm(up))
    assert rc == 20, o
    return up, out, o


@test("T1.16 check-recalc PASS on the script's wrapped result; report with glossary; readiness pending approval")
def t116():
    up, out, o = onboarded("t116")
    cells, copy = recalc_args(o)
    rc, o2 = run(["check-recalc", "--company", "alpha-water", "--values", "-"], up, out, simulated_script_result(out, copy, cells))
    assert rc == 0, o2
    has(o2, "L4 PASS", "READINESS: ONBOARDED_PENDING_APPROVAL", "name: alpha-water_company.zip", "alpha-water_onboarding_2026-06.md")
    md = open(os.path.join(out, "onboarding", "alpha-water_onboarding_2026-06.md")).read()
    has(md, "## Glossary", "## LP fields", "## Identities", "## For review", "## How to approve")


@test("T1.17 check-recalc FAIL when Excel's value differs; FAIL when the script refused; NOT RUN when unavailable")
def t117():
    up, out, o = onboarded("t117")
    cells, copy = recalc_args(o)
    rc, o2 = run(["check-recalc", "--company", "alpha-water", "--values", "-"], up, out,
                 simulated_script_result(out, copy, cells, change=("Valuation!B21", 1.0), wrap=False))
    has(o2, "L4 FAIL (1 different", "Valuation!B21: saved 33,221,587 but Excel recalculates 1")
    up, out, o = onboarded("t117b")
    cells, copy = recalc_args(o)
    rc, o2 = run(["check-recalc", "--company", "alpha-water", "--values", "-"], up, out, simulated_script_result(out, copy, cells, refused=True))
    has(o2, "L4 FAIL", "refused")
    up, out, o = onboarded("t117c")
    rc, o2 = run(["check-recalc", "--company", "alpha-water", "--unavailable", "Connection Required"], up, out)
    has(o2, "L4 NOT RUN", "Connection Required")


@test("T1.18 approve needs a name, records corrections as decisions, binds to the method hash; unknown IDs rejected")
def t118():
    up, out, o = onboarded("t118", pasted_ttm=True)
    cells, copy = recalc_args(o)
    run(["check-recalc", "--company", "alpha-water", "--values", "-"], up, out, simulated_script_result(out, copy, cells))
    rc, o2 = run(["approve", "--company", "alpha-water", "--by", "A-badid00", "--changes", json.dumps({"A-00000000": "x"})], up, out)
    assert rc == 1 and "unknown review item" in o2, o2
    from company_file import read
    parts, _ = read(os.path.join(out, "alpha-water_company.zip"))
    item = [i for i in parts["assumptions"]["items"] if i["review"] and i.get("proposed")][0]
    rc, o3 = run(["approve", "--company", "alpha-water", "--by", "Test Analyst", "--changes",
                  json.dumps({item["id"]: "restore formula"}), "--said", "approve, and restore the TTM formula"], up, out)
    assert rc == 0, o3
    has(o3, "APPROVED: onboarding of Alpha Water Inc by Test Analyst", "1 correction(s)", "READINESS: ONBOARDED")
    parts, ledger = read(os.path.join(out, "alpha-water_company.zip"))
    assert parts["profile"]["approvals"][-1]["method_hash"] == parts["profile"]["method_hash"]
    assert parts["decisions"]["items"][0]["value"] == "restore formula"
    assert [x["event"] for x in ledger][-2:] == ["decision", "approval"]


@test("T1.19 a tampered company file stops with an integrity message")
def t119():
    up, out, o = onboarded("t119")
    zp = os.path.join(out, "alpha-water_company.zip")
    with zipfile.ZipFile(zp) as z:
        files = {n: z.read(n) for n in z.namelist()}
    lines = files["evidence_ledger.jsonl"].decode().splitlines()
    e = json.loads(lines[0]); e["by"] = "someone else"; lines[0] = json.dumps(e, sort_keys=True)
    files["evidence_ledger.jsonl"] = ("\n".join(lines) + "\n").encode()
    with zipfile.ZipFile(zp, "w") as z:
        for n, b in files.items():
            z.writestr(n, b)
    rc, o2 = run(["explain", "enterprise_value", "--company", "alpha-water"], up, out)
    assert rc == 3 and "integrity" in o2, o2


@test("T1.20 explain prints a field's formula and labelled precedents, and a review item's proposals")
def t120():
    up, out, o = onboarded("t120")
    rc, o2 = run(["explain", "enterprise_value", "--company", "alpha-water"], up, out)
    assert rc == 0, o2
    has(o2, "EXPLAIN: enterprise_value | Valuation!B21", "formula =B16*B7", "<- Valuation!B16 'Selected EV/EBITDA multiple'")


@test("T1.21 SharePoint lines skip files over the 4 MB tool limit and say to return them as downloads")
def t121():
    from wbutil import sp_lines
    d = os.path.join(ROOT, "t121")
    os.makedirs(d)
    big = os.path.join(d, "big.xlsx")
    open(big, "wb").write(b"0" * 4_100_000)
    os.environ["VALUATION_UPLOAD_ROOT"] = d
    lines = sp_lines("x", "q", [big])
    assert any("SKIP big.xlsx" in l and "download" in l for l in lines), lines


@test("T1.22 quarterly columns: flows match the sum of 3 statement months, balances the quarter-end month; TTM = 4 quarters")
def t122():
    up, out = case("t122")
    FX.quarterly_workbook(os.path.join(up, "Quarterly_valuation_Q2-2026.xlsx"))
    s = stm(up, [(2026, m) for m in range(1, 7)])
    rc, o = run(["onboard", "--workbook", "Quarterly_valuation_Q2-2026.xlsx", "--statements", *s, "--company", "Quarter Co"], up, out)
    assert rc == 20, o
    has(o, "METHOD: ev_ebitda | metric basis ttm", "PERIOD GATE: overlap months 2026-01..2026-06")
    from company_file import read
    parts, _ = read(os.path.join(out, "quarter_company.zip"))
    ents = {e["label"]: e for e in parts["line_map"]["entries"]}
    assert ents["Revenue"]["operation"] == "sum_3" and ents["Revenue"]["evidence"] == "matched_all_overlap_months", ents["Revenue"]
    assert ents["Cash"]["operation"] == "value_at" and ents["Cash"]["scale"] == 1000, ents["Cash"]
    w = parts["lp_map"]["metric_windows"][0]
    assert w["months"] == 12 and w["last"] == "2026-06" and w["ends_at_valuation_month"], w
    up2, out2 = case("t122b")
    FX.quarterly_workbook(os.path.join(up2, "Quarterly_valuation_Q2-2026.xlsx"))
    rc, o = run(["onboard", "--workbook", "Quarterly_valuation_Q2-2026.xlsx", "--statements",
                 *stm(up2, [(2026, 4), (2026, 5)]), "--company", "Quarter Co"], up2, out2)
    assert rc == 20, o                                       # Apr and May are inside Q2: not a period-gate stop


@test("T1.23 a workbook last saved by a tool that does not calculate (no saved values) is a finding, not a silent failure")
def t123():
    from openpyxl import load_workbook
    from analyze import analyze
    d = os.path.join(ROOT, "t123")
    os.makedirs(d)
    p = os.path.join(d, "AlphaWater_valuation_Q2-2026.xlsx")
    FX.company_workbook(p)
    load_workbook(p).save(p)                     # an openpyxl round trip drops every saved formula result
    a = analyze(p)
    assert any(x["kind"] == "no_saved_values" for x in a["findings"]), a["findings"]


@test("T1.24 census: a workbook whose analysis is killed (out of memory) is reported; the other workbooks still complete")
def t124():
    up, out = case("t124")
    w1, w2 = wb(up), wb(up, name="Bravo_valuation_Q2-2026.xlsx")
    os.environ["VALUATION_TEST_KILL"] = w2
    try:
        rc, o = run(["census", "--workbooks", w1, w2], up, out)
    finally:
        del os.environ["VALUATION_TEST_KILL"]
    assert rc == 0, o
    has(o, "| AlphaWater_valuation_Q2-2026.xlsx | READY TO ONBOARD", "| Bravo_valuation_Q2-2026.xlsx | NOT ANALYSED",
        "Bravo_valuation_Q2-2026.xlsx: NOT ANALYSED - the analysis process was killed by the sandbox", "READING: Bravo_valuation_Q2-2026.xlsx (")


@test("T1.25 period alignment: a Q2 file whose date cell and TTM windows say March is a mismatch question for the analyst (REVIEW, not BLOCKED)")
def t125():
    a = analyze_fx(shift=3, date_cell=datetime.datetime(2026, 3, 31))
    assert a["period"]["alignment"] == "mismatch", a["period"]
    assert a["period"]["intended_sources"]["file name"] == "2026-06" and a["period"]["detected_calculation_month"] == "2026-03"
    assert a["verdict"]["status"] == "REVIEW" and any(f["kind"] == "period_mismatch" for f in a["findings"]), a["findings"]
    assert a["verdict"]["questions_for_analyst"], a["verdict"]


@test("T1.26 add-in cells saved with provider errors are one warning, not separate valuation failures")
def t126():
    a = analyze_fx(add_in_error=True)
    eb = a["error_breakdown"]
    assert eb["add_in_cells_with_errors"] == 1 and eb["own_errors"] == 0, eb
    f = [x for x in a["findings"] if x["kind"] == "addin_error"]
    assert f and f[0]["severity"] == "warning" and "#NOTAUTH" in f[0]["text"], a["findings"]
    assert a["verdict"]["status"] == "REVIEW", a["verdict"]


@test("T1.27 adjusted EBITDA summed from its own monthly row is proven by formula, not reported as unproven")
def t127():
    a = analyze_fx(adj_in_rows=True)
    i2 = [i for i in a["identities"] if i["id"] == "I2"]
    assert i2 and i2[0]["result"] in ("PASS (formula)", "N/A"), a["identities"]
    assert "adjusted EBITDA" not in a["verdict"]["unproven_identities"]


@test("T1.28 a data sheet no formula refers to is counted, not stored (memory), and changes nothing else")
def t128():
    a = analyze_fx(noise_sheet=True)
    assert a["skipped_cells"].get("Data dump") == 1000, a["skipped_cells"]
    assert a["verdict"]["status"] == "READY TO ONBOARD", a["verdict"]


@test("T1.29 a dynamic TTM (SUMIFS on dates) is found by its values, not misread as a 24-month window")
def t129():
    a = analyze_fx(dynamic_ttm=True)
    w = [x for x in a["metric_windows"] if x["field"] == "ebitda_reported"][0]
    assert (w["first"], w["last"], w["months"]) == ("2025-07", "2026-06", 12), w
    assert w["type"].startswith("dynamic") and a["period"]["alignment"] == "aligned", (w, a["period"])


@test("T1.30 a calendar-year window 6 months before the valuation date is described as such and asked about, not blocked")
def t130():
    a = analyze_fx(shift=6)
    f = [x for x in a["findings"] if x["kind"] == "metric_window"]
    assert f and "calendar year 2025" in f[0]["text"] and "6 month(s) earlier" in f[0]["text"], a["findings"]
    assert a["verdict"]["status"] == "REVIEW" and a["period"]["alignment"] == "mismatch", (a["verdict"]["status"], a["period"])


@test("T1.31 metrics feeding one EV that end in different months are a warning even when the lag is small")
def t131():
    a = analyze_fx(ttm_off=True)
    f = [x for x in a["findings"] if x["kind"] == "metric_window"]
    assert f and f[0]["severity"] == "warning" and "different month" in f[0]["text"], f
    assert a["verdict"]["status"] == "REVIEW"


def proforma_case(name, extra_row=False, previous=True):
    up, out = case(name)
    FX.proforma_workbook(os.path.join(up, "Delta_Water_Valuation_Q2-2026.xlsx"), extra_row=extra_row)
    if previous:
        FX.proforma_workbook(os.path.join(up, "Delta_Water_Valuation_Q1-2026.xlsx"), quarter="Q1", xpv_shares=2_500_000, extra_row=extra_row)
    s = [os.path.basename(p) for ent, f in (("EntityA", 0.6), ("EntityB", 0.4)) for p in FX.entity_statements(up, ent, f, Q2)]
    args = ["onboard", "--workbook", "Delta_Water_Valuation_Q2-2026.xlsx", "--statements", *s, "--company", "Delta Water"]
    if previous:
        args += ["--previous", "Delta_Water_Valuation_Q1-2026.xlsx"]
    rc, o = run(args, up, out)
    from company_file import read
    parts = read(os.path.join(out, "delta-water_company.zip"))[0] if rc == 20 else None
    return rc, o, parts


@test("T1.32 build map: every part the LP numbers depend on is traced, in build order, each input with a next-quarter source")
def t132():
    rc, o, parts = proforma_case("t132")
    assert rc == 20, o
    P = {(p["sheet"], p["role"]): p for p in parts["build"]["parts"]}
    order = [ (p["sheet"], p["role"]) for p in parts["build"]["parts"]]
    pf = ("Pro Forma Financials (Q2)", "pro_forma")
    assert pf in P and {"P1", "P2"} <= set(P[pf]["depends_on"]), P.get(pf)
    adj = P[("Pro Forma Financials (Q2)", "adjustments")]
    assert adj["inputs"][0]["class"] == "adjustment" and adj["inputs"][0]["each_quarter"].startswith("proposed")
    cap = P[("Cap Table", "cap_table")]
    assert cap["inputs"][0]["count"] == 5 and cap["inputs"][0]["each_quarter"] == "update or confirm unchanged", cap
    pos = {k: i for i, k in enumerate(order)}
    assert pos[("Entity A Monthly", "financials")] < pos[pf] < pos[("Valuation", "valuation")] < pos[("Cap Table", "cap_table")] < pos[("LP Summary", "lp_output")]
    assert parts["build"]["gaps"] == [] and not [i for i in parts["inputs"]["items"] if i["class"] == "add_in"]
    has(o, "TRACE: investor value (P", "BUILD: ")
    tr = parts["build"]["trace"]["investor_value"]
    assert "P1" in sum(tr, []) and "P2" in sum(tr, []), tr          # the value traces back to both entities' financials


@test("T1.33 pro forma: each entity's statement pack maps to that entity's rows, proven on every overlap month")
def t133():
    rc, o, parts = proforma_case("t133", previous=False)
    ents = [e for e in parts["line_map"]["entries"] if e["evidence"] == "matched_all_overlap_months"]
    by = {(e["line"].split("|")[0], e["label"]): e["statement"]["entity"] for e in ents}
    assert by[("Entity A Monthly", "Revenue")] == "entitya" and by[("Entity B Monthly", "Revenue")] == "entityb", by
    assert len(ents) == 10, len(ents)


@test("T1.34 learning from the previous quarter: the quarter-named sheet is rolled, the cap-table change is seen, comparables carried")
def t134():
    rc, o, parts = proforma_case("t134")
    L = parts["build"]["learned"]
    assert L["rolled_sheets"] == [{"current": "Pro Forma Financials (Q2)", "previous": "Pro Forma Financials (Q1)"}], L["rolled_sheets"]
    assert L["by_class"]["cap_table"] == {"changed": 1, "unchanged": 4} and L["by_class"]["comparable"]["changed"] == 0, L["by_class"]
    assert any(c["label"] == "XPV shares" for c in L["changed_cells"].values()) and L["window_shift_months"] == 3
    has(o, "LEARNED: from Delta_Water_Valuation_Q1-2026.xlsx: sheets rolled per quarter: 'Pro Forma Financials (Q1)' -> 'Pro Forma Financials (Q2)'")


@test("T1.35 an input with no source next quarter is a GAP and a review item, so nothing feeding the LP row is left stale")
def t135():
    rc, o, parts = proforma_case("t135", extra_row=True, previous=False)
    g = parts["build"]["gaps"]
    assert g and g[0]["label"].endswith("Other income") and g[0]["class"] == "statement_gap", g
    assert any(i["review"] and i["action"] == "give_source" for i in parts["assumptions"]["items"])
    has(o, "- GAP P", "1 gap(s)")


@test("T1.36 a sheet name with brackets is a sheet, not a data-provider function")
def t136():
    from wbutil import func_names
    assert func_names("='Pro Forma Financials (Q2)'!AA17") == [] and func_names("=SUM('A (1)'!B2:B4)") == ["SUM"]


@test("T1.37 the census is a report only: monthly files given with it are named and skipped, and nothing else is stored")
def t137():
    up, out = case("t137")
    w = wb(up, name="2026_Q2_-_Alpha_Water_Valuation_Workbook.xlsx")
    st = [os.path.basename(p) for p in FX.statements(up, [(2026, 6)], company="Alpha_Water")]
    rc, o = run(["census", "--workbooks", w, *st], up, out)
    assert rc == 0, o
    has(o, "CENSUS: 1 workbook(s)", "- Alpha_Water_Financial_Statements_June_30__2026.xlsx: a statement pack, not a valuation workbook - skipped")
    assert not os.path.exists(os.path.join(out, "_portfolio")) and "REGISTER" not in o


@test("T1.38 reference on demand: the structure of the workbooks found for a feature (e.g. acquisitions) - no numbers")
def t138():
    up, out = case("t138")
    FX.proforma_workbook(os.path.join(up, "2026_Q2_-_Delta_Water_Valuation_Workbook.xlsx"), acquisition_note=True)
    w = wb(up, name="2026_Q2_-_Alpha_Water_Valuation_Workbook.xlsx")
    rc, o = run(["reference", "--feature", "acquisition", "--workbooks", "2026_Q2_-_Delta_Water_Valuation_Workbook.xlsx", w], up, out)
    assert rc == 0, o
    has(o, "REFERENCE: 1 workbook(s) with feature 'acquisition'", "- Delta Water", "Pre-acquisition EBITDA of Entity B")
    assert "Alpha Water" not in o and "10,623,900" not in o
    rc, o = run(["reference", "--feature", "acquisition"], up, out)
    assert rc == 3 and "Search 'Valuation Workbooks'" in o, o


@test("T1.39 intake: files are classified and filed; a stated fact is recorded word for word in the company file")
def t139():
    up, out = case("t139")
    FX.proforma_workbook(os.path.join(up, "2026_Q1_-_Delta_Water_Valuation_Workbook.xlsx"), quarter="Q1")
    st = os.path.basename(FX.entity_statements(up, "EntityB", 0.4, [(2026, 6)])[0])
    FX.cap_table_file(os.path.join(up, "Delta_cap_table.xlsx"))
    open(os.path.join(up, "Delta_deal_memo.pdf"), "wb").write(b"%PDF-1.4 test")
    rc, o = run(["add", "--files", "2026_Q1_-_Delta_Water_Valuation_Workbook.xlsx", st, "Delta_cap_table.xlsx", "Delta_deal_memo.pdf",
                 "--company", "Delta Water", "--by", "Test Analyst"], up, out)
    assert rc == 0, o
    has(o, "-> Delta Water (stated by the user) | valuation workbook | period 2026-03", "statement pack | entity entityb | period 2026-06",
        "Delta_cap_table.xlsx -> Delta Water (stated by the user) | cap table", "Delta_deal_memo.pdf -> Delta Water (stated by the user) | document",
        "path: Valuations/delta-water/inbox")
    fact = ["add", "--company", "Delta Water", "--fact", "acquired company TTM EBITDA", "--value", "2,100,000", "--by", "Test Analyst",
            "--said", "we bought Gamma; its TTM EBITDA is 2.1m"]
    rc, o = run(fact, up, out)
    assert rc == 3 and "Onboard Delta Water first" in o, o
    rc, o, parts = proforma_case("t139b", previous=False)
    up2, out2 = os.path.join(ROOT, "t139b", "uploads"), os.path.join(ROOT, "t139b", "out")
    rc, o = run(fact, up2, out2)
    has(o, "INTAKE: fact F-001 for Delta Water: acquired company TTM EBITDA = 2,100,000 (by Test Analyst")
    from company_file import read
    parts, ledger = read(os.path.join(out2, "delta-water_company.zip"))
    assert parts["facts"]["items"][0]["said"].startswith("we bought Gamma") and ledger[-1]["event"] == "fact_recorded"


@test("T1.40 HAVE / NEED: onboarding lists what it had, what is missing (an entity's statements) and what would help")
def t140():
    up, out = case("t140")
    FX.proforma_workbook(os.path.join(up, "Delta_Water_Valuation_Q2-2026.xlsx"))
    s = [os.path.basename(p) for p in FX.entity_statements(up, "EntityA", 0.6, Q2)]
    rc, o = run(["onboard", "--workbook", "Delta_Water_Valuation_Q2-2026.xlsx", "--statements", *s, "--company", "Delta Water"], up, out)
    assert rc == 20, o
    has(o, "HAVE: approved workbook Delta_Water_Valuation_Q2-2026.xlsx", "HAVE: statements for entitya: 2026-04, 2026-05, 2026-06",
        "NEED: statements for 2 entities", "OPTIONAL: previous quarter's approved workbook", "NEED: (each quarter)")


@test("T1.41 AI judgement: an unproven equity bridge (SUMIF) is proposed by the AI and verified by Python; a wrong proposal is rejected")
def t141():
    up, out = case("t141")
    w = wb(up, sumif_bridge=True)
    rc, o = onboard(up, out, w, stm(up))
    assert rc == 10, o
    has(o, "Python could not prove the equity value", "target Valuation!B24", "input Valuation!B21 'Enterprise value'")
    qid = re.search(r"^(Q-[0-9a-f]{8}) Python could not prove the equity", o, re.M).group(1)
    good = {"op": "sum", "terms": [["Valuation!B21", 1], ["Valuation!B22", 1], ["Valuation!B23", -1], ["Valuation!B33", -1], ["Valuation!B34", -1]]}
    rc, o2 = onboard(up, out, w, stm(up), ["--answers", json.dumps({qid: good})])
    assert rc == 20, o2
    from company_file import read
    parts, _ = read(os.path.join(out, "alpha-water_company.zip"))
    ids = {i["id"]: i["result"] for i in parts["lp_map"]["identities"]}
    assert ids["I3"] == "PASS (AI + Python)" and ids["I4"] == "PASS", ids
    assert parts["lp_map"]["fields"]["equity_value"]["basis"].startswith("AI-proposed calculation verified by Python")
    up2, out2 = case("t141b")
    w2 = wb(up2, sumif_bridge=True)
    bad = {"op": "sum", "terms": [["Valuation!B21", 1], ["Valuation!B22", 1], ["Valuation!B23", -1]]}
    rc, o3 = onboard(up2, out2, w2, stm(up2), ["--answers", json.dumps({qid: bad})])
    has(o3, "NOT reproduced (Python")
    parts, _ = read(os.path.join(out2, "alpha-water_company.zip"))
    assert {i["id"]: i["result"] for i in parts["lp_map"]["identities"]}["I3"] == "NOT PROVEN"


@test("T1.42 a metric read from a linked workbook says so (the monthly data lives outside), instead of just 'not traced'")
def t142():
    a = analyze_fx(linked_ttm=True)
    assert "linked workbook" in a["metric_sources"].get("ebitda_reported", ""), a["metric_sources"]


@test("T1.43 gather looks only in its search folders and says where it looked (no files from other runs)")
def t143():
    up, out = case("t143")
    wb(up, name="2026_Q2_-_Alpha_Water_Valuation_Workbook.xlsx")
    decoy = os.path.join(ROOT, "t143_decoy")
    os.makedirs(decoy)
    wb(decoy, name="2026_Q2_-_Alpha_Water_Valuation_Workbook_v9.xlsx")
    rc, o = run(["gather", "--company", "Alpha Water", "--quarter", "Q2 2026"], up, out)
    has(o, "HAVE: valuation workbook 2026_Q2_-_Alpha_Water_Valuation_Workbook.xlsx", f"GATHER: looked in {up}")
    assert "_v9" not in o, o


@test("T1.44 gather treats a monthly workbook the valuation workbook links to as this company's, even with an unrelated name")
def t144():
    up, out = case("t144")
    wb(up, name="2026_Q2_-_Alpha_Water_Valuation_Workbook.xlsx", external="Gamma Holdings Detailed Backup.xlsx")
    rc, o = run(["gather", "--company", "Alpha Water", "--quarter", "Q2 2026"], up, out)
    has(o, 'NEED: linked workbook "Gamma Holdings Detailed Backup.xlsx"')
    FX.statements(up, [(2026, 6)], company="Gamma_Holdings")
    shutil.copyfile(os.path.join(up, "Gamma_Holdings_Financial_Statements_June_30__2026.xlsx"), os.path.join(up, "Gamma Holdings Detailed Backup.xlsx"))
    os.remove(os.path.join(up, "Gamma_Holdings_Financial_Statements_June_30__2026.xlsx"))
    rc, o = run(["gather", "--company", "Alpha Water", "--quarter", "Q2 2026"], up, out)
    has(o, "Gamma Holdings Detailed Backup.xlsx (2026-06", "linked by the valuation workbook", '"Gamma Holdings Detailed Backup.xlsx"')
    assert 'NEED: linked workbook' not in o, o


@test("T1.45 gather picks this company's approved workbook (not the draft, highest version), the previous quarter and the quarter's statements")
def t145():
    up, out = case("t145")
    wb(up, name="2026_Q2_-_Alpha_Water_Valuation_Workbook_DRAFT.xlsx")
    wb(up, name="2026_Q2_-_Alpha_Water_Valuation_Workbook_v1.xlsx")
    wb(up, name="2026_Q2_-_Alpha_Water_Valuation_Workbook_v2.xlsx")
    wb(up, name="2026_Q1_-_Alpha_Water_Valuation_Workbook.xlsx")
    wb(up, name="2026_Q2_-_Bravo_Water_Valuation_Workbook.xlsx")
    FX.statements(up, [(2026, 4), (2026, 6)], company="Alpha_Water")
    rc, o = run(["gather", "--company", "Alpha Water", "--quarter", "Q2 2026"], up, out)
    assert rc == 0, o
    has(o, "GATHER: Alpha Water | Q2 2026 (2026-04, 2026-05, 2026-06)", "HAVE: valuation workbook 2026_Q2_-_Alpha_Water_Valuation_Workbook_v2.xlsx (2026-06)",
        "HAVE: previous quarter 2026_Q1_-_Alpha_Water_Valuation_Workbook.xlsx", "NEED: statements for May 2026",
        "ignored (other companies): 2026_Q2_-_Bravo_Water_Valuation_Workbook.xlsx",
        'THEN: python scripts/pipeline.py onboard --workbook "2026_Q2_-_Alpha_Water_Valuation_Workbook_v2.xlsx" --previous "2026_Q1_-_Alpha_Water_Valuation_Workbook.xlsx" --statements')
    assert "DRAFT.xlsx (2026-06" not in o.split("HAVE: valuation workbook")[1].split("\n")[0].split("chosen over")[0]


@test("T1.46 gather with only a draft and nothing else says exactly what to search for, and quarter wording is flexible")
def t146():
    up, out = case("t146")
    wb(up, name="2026_Q1_-_Alpha_Water_Valuation_Workbook_DRAFT.xlsx")
    rc, o = run(["gather", "--company", "Alpha Water", "--quarter", "2026-Q1"], up, out)
    has(o, "(2026-03, DRAFT)", "NEED: an approved (non-draft) Q1 2026 valuation workbook - search 'Valuation Workbooks'",
        "OPTIONAL: the Q4 2025 valuation workbook", "NEED: statements for January 2026 - search 'Company Financial Statements' and 'Monthly Summaries'")
    rc, o = run(["gather", "--company", "Alpha Water", "--quarter", "March 2026"], up, out)
    has(o, "Q1 2026 (2026-01, 2026-02, 2026-03)")


@test("T1.47 a workbook with add-in or linked cells skips the Excel step and finishes onboarding in one step (no timeouts)")
def t147():
    up, out = case("t147")
    rc, o = onboard(up, out, wb(up, add_in=True), stm(up))
    assert rc == 0, o
    has(o, "RECALC: skipped (skipped: the workbook has 1 data-provider add-in cell(s)", "L4 SKIPPED", "READINESS: ONBOARDED_PENDING_APPROVAL")
    assert "Run script from SharePoint library" not in o and "__copy.xlsx" not in o


@test("T1.48 the cells for the Office Script are plain JSON strings with no single quotes to re-type")
def t148():
    up, out = case("t148")
    rc, o = onboard(up, out, wb(up), stm(up))
    cells, _ = recalc_args(o)
    assert "LP Summary!C4" in cells and not any("'" in c for c in cells), cells
    has(o, "RECALC RULES: pass the cells text exactly as printed")


def main():
    report = "--report" in sys.argv
    for t in TESTS:
        t()
    passed = sum(1 for _, ok, _ in RESULTS if ok)
    for name, ok, why in RESULTS:
        print(f"- {'PASS' if ok else 'FAIL'}: {name}" + ("" if ok else f"\n    {why}"))
    line = f"ALL SELFTESTS: {'PASS' if passed == len(RESULTS) else 'FAIL'} ({passed}/{len(RESULTS)})"
    print(line)
    if report:
        p = os.path.join(os.environ.get("VALUATION_REPORT_DIR", "/app/created" if os.path.isdir("/app") else os.getcwd()), "selftest_report.txt")
        open(p, "w").write("\n".join(f"{'PASS' if ok else 'FAIL'} {n} {w}" for n, ok, w in RESULTS) + "\n" + line + "\n")
        print(f"FILE: {p}")
    shutil.rmtree(ROOT, ignore_errors=True)
    return 0 if passed == len(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())
