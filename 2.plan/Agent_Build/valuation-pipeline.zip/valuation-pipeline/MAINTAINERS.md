# valuation-pipeline build 11.2 - maintainers' notes

## Glossary
| Term | Meaning |
|---|---|
| Limited partner (LP) row | The per-company fields the quarterly LP report needs. The pipeline works back from it. |
| Bronze / silver / gold | Raw files untouched / normalised company data in the company file / the LP numbers Excel calculates |
| Identity | A valuation equation (EV = multiple x metric, equity = EV + cash - debt, ...) Python checks against Excel's saved values |
| Liveness checks L1-L5 | L1 LP values are formulas; L2 no pasted calculations; L3 no external links, manual calculation or errors upstream; L4 Excel recalculation of a copy matches; L5 identities and TTM windows match |
| Period block | A row of 6+ consecutive month headers (or 4+ quarter headers) with numeric rows below; where new periods are written |
| Line map | Statement line -> monthly row, proven on every overlap month (after scale and sign) |
| Method hash | Hash of field cells, method, input classes, line map and decisions; an approval is bound to it |

## Design rules (do not break)
1. **Work back from the LP row.** Only cells upstream of LP fields are classified; everything else is only counted.
2. **History comes from the approved workbook.** Statements prove the line map on overlap months; they never
   overwrite approved history.
3. **The pipeline writes only raw inputs** (statement months, dates, FX, frozen add-in values). Every other cell keeps
   its formula, so an analyst's change to comparables, add-backs or terms flows through Excel. (Phase 2 enforces this
   with a test: template and draft differ only in input cells.)
4. **Excel computes gold, Python checks it.** Python never re-implements a waterfall; it checks identities and bounds.
5. **Deterministic.** Clock only through `wbutil.now()` (`VALUATION_NOW`); IDs are hashes of canonical JSON; the
   company zip is written with fixed timestamps and sorted entries.
6. **The printed lines are the agent's interface.** Any new prefix goes into `pipeline.PREFIXES` and `SKILL.md`
   (test T0.3 enforces both).
7. **Assume, record, confirm once.** Judgement calls are filled automatically (approved workbook > company decision >
   XPV pattern > best-practice default > AI judgement), each recorded with its basis; the analyst approves once.
   Only impossible states stop a run (`STOPPED:`).

## Module map
| File | Role |
|---|---|
| `scripts/pipeline.py` | CLI, printed lines, exit codes, assumptions register, onboarding report |
| `scripts/analyze.py` | LP field candidates, identity solver ("Python chain"), metric windows, input classes, pasted calculations, liveness L1-L3, L5 |
| `scripts/workbook_model.py` | Streams the workbook twice (formulas, saved values; openpyxl read-only mode) into two compact dicts; formula-free sheets nothing refers to are counted, not stored (memory: a 2-million-cell workbook peaks near 55 MB, about 590 MB if every sheet has formulas). One read of a workbook: cells, saved values, labels, precedents (ranges, defined names), add-ins, external links, monthly and quarterly blocks, fingerprint |
| `scripts/parts.py` | Build map: parts traced back from the LP row in build order, next-quarter source for every input, gaps, trace per LP field, learning from the previous quarter's approved workbook, balance-source proof |
| `pipeline.py gather` | Chooses a company's files for a quarter from everything available (knowledge-fetched, uploaded): approved over draft, highest version, previous quarter, the quarter's statements and monthly summaries, linked workbooks; prints exact searches for gaps and the onboarding command |
| `scripts/catalog.py` | What a file is (valuation workbook, statement pack, monthly summary, LP report, cap table, document), company names from file names, structure features and patterns (no numbers) |
| `references/build_rules.json` | Part roles (sheet and label words) and next-quarter sources by input class - add a company's wording here |
| `scripts/formula_eval.py` | Re-computes one formula from its precedents' saved values (+ - * / ^ %, SUM, AVERAGE, MIN, MAX, ABS, ROUND, IFERROR); anything else is "unsupported", never guessed |
| `scripts/statements.py` | Statement reader (v6 layouts: months across columns, one file per month, sheet per month, two-row headers, CSV, YTD columns), line map, period gate |
| `scripts/company_file.py` | Company zip, ledger hash chain, manifest, method hash |
| `scripts/wbutil.py` | Shared helpers: hashing, references, labels, periods, file resolution, SharePoint lines |
| `references/lp_fields.json` | LP field registry: synonyms and exclusions (add a company's wording here, not in code) |
| `references/input_words.json` | Words for adjustments (nine categories), balances, FX, dates |
| `references/materiality_defaults.json` | Tolerances and caps (labelled unapproved) |
| `tools/check_package.py` | Release check (deny-list, junk, nested skills) and clean zip |
| `tests/fixtures.py`, `tests/run_selftest.py` | Synthetic workbooks with Excel-style saved values; CLI-level tests |

## Company file (`<company_id>_company.zip`)
| Part | Content |
|---|---|
| `profile` | id, name, valuation date and its basis, method (variant, metric basis, weights, FX rule, ownership rule, bridge), workbook fingerprint, readiness, approvals, method hash |
| `lp_map` | LP fields -> cell, label, value, status (`verified` / `mapped` / `weak` / `chosen`), basis, aliases, typed copies, alternatives; identities; metric windows |
| `inputs` | every typed input upstream (class `monthly`, `date`, `balance`, `fx`, `parameter`, `fund_record`, `pasted_calculation`), monthly rows, add-ins, external links, errors, untouched count |
| `blocks`, `silver_monthly` | monthly blocks; every block row x month with value, cell, typed/formula, source type |
| `line_map` | entries (statement line, scale, sign, months matched, evidence), gate message, statement file register |
| `liveness` | L1-L5 results, findings, recalculation request and saved values |
| `assumptions`, `decisions`, `judgments` | register (with review flags), named corrections, AI answers |
| `bronze_registry` | every raw file: name, SHA-256, bytes, kind, period, SharePoint path |
| `explain` | per-cell details for `explain` (label, formula, labelled precedents) |
| `evidence_ledger.jsonl`, `bundle_manifest.json` | hash-chained events; SHA-256 of every file (verified on open) |

Readiness: `ONBOARDING_PENDING_RECALC` -> `ONBOARDED_PENDING_APPROVAL` -> `ONBOARDED` (phase 2 adds `PROVEN` after a
gold comparison).

## Census
Each workbook is analysed in its own process (`census-one`), so a workbook the sandbox kills (exit 137, out of
memory) is reported as NOT ANALYSED with its file facts, and the other workbooks still complete. Every count carries
its scope (LP dependency graph, LP fields, entire workbook). Verdicts: READY TO ONBOARD, REVIEW (warnings or unproven
identities), BLOCKED (a blocking finding: required field missing, period mismatch, stale or missing saved values,
own errors upstream), NOT ANALYSED. A verdict is not an approval.

Periods are conventions, not errors. The census reports each metric's window by its values (a 3/12/36-month run of
one period row that sums to the cell, so SUM ranges, SUMIFS/OFFSET date windows and typed totals are all read the same
way), its type (dynamic, rolls with a date / fixed range, moved by hand / typed), and its lag behind the intended
period (date cell, file name). Lag 0 = aligned; 1-3 months (`metric_lag_months_usual`) = information, confirmed once at
onboarding; longer, earlier-than-reported, or metrics ending in different months = a warning with a question. Onboarding
records the confirmed convention; the refresh keeps it and flags any change.

## Judgement and verification
The AI is used where judgement adds value and is always checked: choosing between printed options (line map, field
cells), and proposing calculations for identities Python could not prove (`{"op": "sum"|"product", "terms": [[cell,
sign]]}`), which `analyze.solve_chain` keeps only if they reproduce Excel's saved value. Numbers never come from the AI;
facts stated by the analyst are recorded verbatim with provenance (`add --fact`).

## Extending
- New wording for a field: add a synonym in `references/lp_fields.json`; run the self-test.
- New method variant: add the identity in `analyze.solve_chain`, a fixture option in `tests/fixtures.py`, and a test.
- Phase 2 (refresh) reads `lp_map`, `inputs`, `blocks`, `line_map` and `decisions`; it must not change their meaning.

## Tests
`python scripts/pipeline.py selftest` - 51 tests (T0.1-T0.3 guardrails, T1.1-T1.48 phase 1). Fixtures are generated
in code; their saved values were checked against a spreadsheet engine's recalculation during development.

## Release
1. `python scripts/pipeline.py selftest` -> `ALL SELFTESTS: PASS`.
2. `python tools/check_package.py valuation-pipeline --deny-list <secure list> --zip-out valuation-pipeline.zip`.
3. Upload that zip as-is (do not unzip and re-zip on a laptop: endpoint security adds `~BROMIUM` stub files).

## Build 11.1 notes
- No stored portfolio archive. Company map, facts and approvals: the company file. Files: SharePoint / knowledge.
- `gather` searches `VALUATION_FILE_ROOTS` if set (tests set it to their own folder), else uploads, the working folder
  and `/app` (where knowledge files land), skipping skills, created output and test folders below each root. It prints
  where it looked and where files were found.
- Company files are only looked up in this run's folders (`resolve(..., broad=False)`), never across `/app`.

## Build 11.2 notes
- The Excel step (L4) is skipped automatically when the workbook has data-provider add-ins, formulas reading other
  workbooks, more than `recalc_max_formulas` formulas or more than `recalc_max_bytes`: Excel Online cannot finish a
  full recalculation within the tool's time limit. Onboarding then finishes in one step with `L4 SKIPPED`.
- RECALC prints plain references (`Financial Summary!J59`, no single quotes); Office Script v4 reads the cell list
  before calculating, tolerates re-quoted lists, and checks only the requested cells.
- The agent runs Run script at most once per RECALC line (RECALC RULES line, SKILL.md, instructions).
