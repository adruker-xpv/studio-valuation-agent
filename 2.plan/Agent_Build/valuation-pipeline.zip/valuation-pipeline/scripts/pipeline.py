# pipeline.py (build 11) - the only command the agent runs. Phase 1 commands:
#   census       read-only scan of approved workbooks (what each company's workbook looks like)
#   onboard      approved workbook (+ that quarter's statements) -> company file, liveness copy, Excel step
#   check-recalc result of the Office Script on the liveness copy -> L4, onboarding report, company file saved
#   approve      a named analyst approves the onboarding assumptions (bound to the method hash)
#   explain      everything about one review item, field or cell, so the agent never opens files
#   selftest     synthetic tests (no real data)
# Exit codes: 0 done | 10 JUDGMENT NEEDED (agent answers, re-runs) | 20 waiting for a tool step (RECALC)
#             3 STOPPED (the user must act) | 1 error
import argparse, datetime, json, os, re, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from wbutil import (VERSION, PKG, CREATED, UPLOADS, now, today, dump, short_id, company_slug, resolve, sp_lines, copy_into,
                    stable_name, file_sha256, ym_str, is_num, ym_to_i, i_to_ym, parse_ref_str, col_let, similarity)
import company_file as CF
from analyze import analyze, MAT
import statements as ST
import parts as PT
import catalog as CT

GLOSSARY = [
    ("Limited partner (LP) report", "The quarterly investor report. Everything here works back from its per-company row."),
    ("LP row / LP fields", "The per-company numbers the LP report needs: enterprise value, equity value, value to XPV, MOIC, metrics."),
    ("Enterprise value (EV)", "Value of the company before debt and cash: selected multiple x metric (or a weighted blend)."),
    ("Trailing twelve months (TTM)", "Sum of the last 12 monthly values, ending at the valuation month."),
    ("EBITDA / adjusted EBITDA", "Earnings before interest, tax, depreciation and amortization; adjusted adds approved one-time items."),
    ("Identity", "A valuation equation Python checks against Excel's saved values, e.g. EV = multiple x adjusted EBITDA."),
    ("Liveness checks L1-L5", "L1 LP values are formulas; L2 typed numbers are raw inputs, not pasted calculations; L3 no external "
                              "links, manual calculation or errors; L4 Excel recalculation of a copy matches the saved values; "
                              "L5 Python's identities and TTM windows match Excel."),
    ("Pasted calculation", "A typed number that equals a calculation of other cells (e.g. a typed TTM total). It will not update."),
    ("Monthly row", "A workbook row under month headers; new months are written into these rows each quarter."),
    ("Line map", "Which statement line feeds each monthly row, proven on the months both files cover (overlap months)."),
    ("Parameter", "A typed input carried forward from the approved workbook: comparables, discounts, weights, cap table, terms."),
    ("Add-in cell", "A formula calling a data-provider function (e.g. PitchBook); drafts freeze it to its saved value."),
    ("Company file", "<company_id>_company.zip: the standing data, evidence ledger and manifest for one company."),
]
PREFIXES = ("ONBOARD:", "CENSUS:", "STATEMENTS:", "PERIOD GATE:", "LP FIELDS:", "METHOD:", "LIVENESS:", "INPUTS:",
            "LINE MAP:", "REVIEW:", "SHAREPOINT:", "RECALC:", "THEN:", "IF RUN SCRIPT FAILS:", "JUDGMENT NEEDED",
            "READINESS:", "STOPPED:", "NEXT:", "APPROVED:", "EXPLAIN:", "PIPELINE ERROR:", "ALL SELFTESTS:", "FILE:",
            "CHECK:", "VERSION:", "READING:", "RECALC RULES:", "BUILD:", "TRACE:", "LEARNED:", "HAVE:", "NEED:", "OPTIONAL:",
            "REFERENCE:", "INTAKE:", "STATUS:", "GATHER:")


def out_dir(a):
    d = a.out or (CREATED if os.path.isdir("/app") else os.getcwd())
    os.makedirs(d, exist_ok=True)
    return d


def need_files(names):
    found, missing = [], []
    for n in names:
        p = resolve(n)
        (found if p else missing).append(p or n)
    if missing:
        print("PIPELINE ERROR: these files are not in the chat: " + "; ".join(missing) +
              ". Ask the user to upload them or paste their SharePoint links (download each link with sharepoint_get_doc), then stop.")
        sys.exit(1)
    return found


def company_zip(a, cid):
    p = resolve(f"{cid}_company.zip", [out_dir(a)], broad=False)
    if not p:
        print(f"PIPELINE ERROR: {cid}_company.zip is not in the chat. Ask the user to paste the SharePoint link to "
              f"Valuations/{cid}/company/{cid}_company.zip (download it with sharepoint_get_doc), then stop.")
        sys.exit(1)
    try:
        parts, ledger = CF.read(p)
    except CF.IntegrityError as e:
        print(f"STOPPED: company file integrity check failed: {e}. Do not use this file; ask the user for the version saved in SharePoint.")
        sys.exit(3)
    return p, parts, ledger


def fmt(v):
    if is_num(v):
        return f"{v:,.4f}" if abs(v) < 100 else f"{v:,.0f}"
    return str(v)


# ------------------------------------------------------------------------------------------------ assumptions
def build_assumptions(parts):
    """every judgement in the onboarding, with its basis; review=True items are listed for the analyst."""
    items = []
    prof, lp, inp, lm, live = parts["profile"], parts["lp_map"], parts["inputs"], parts["line_map"], parts["liveness"]

    def add(group, subject, text, basis, confidence, review, action="approve", cell=None, proposed=None):
        items.append({"id": short_id("A", {"g": group, "s": subject}), "group": group, "subject": subject, "text": text,
                      "basis": basis, "confidence": confidence, "review": review, "action": action, "cell": cell,
                      "proposed": proposed})
    for f in live["findings"]:
        add("finding", f"{f['kind']}:{f.get('cell')}", f"[{f['check']} {f.get('severity', '')}] {f['text']}", "liveness check", "n/a", True,
            "correct" if f.get("proposed_formula") or f["kind"] == "pasted_calculation" else "acknowledge", f.get("cell"),
            f.get("proposed_formula"))
    vd = prof.get("valuation_date") or {}
    add("method", "valuation_date", f"valuation date {vd.get('value')} (from {vd.get('basis')})", vd.get("basis") or "none",
        "high" if vd.get("cell") or "given" in str(vd.get("basis")) else "medium", not (vd.get("cell") or "given" in str(vd.get("basis"))))
    per = prof.get("period") or {}
    if per.get("windows"):
        conv_ok = per.get("alignment") == "aligned"
        add("method", "period_convention", f"metric period convention: {'; '.join(per['windows'])}; intended {per.get('intended_reporting_month') or 'unknown'}"
            f"; alignment {per.get('alignment')}. Recorded as this company's convention on approval; the refresh keeps it and flags any change",
            "workbook formulas", "high" if conv_ok else "medium", not conv_ok)
    if prof.get("linked_workbooks"):
        add("inputs", "linked_workbooks", f"values read from other workbooks ({', '.join(prof['linked_workbooks'][:4])}) are frozen at their "
            "last saved values; the refresh asks for those workbooks too, or carries the values with a note", "workbook links", "medium", True)
    meth = prof["method"]
    proven = any(i["id"] == "I1" and i["result"] == "PASS" for i in lp["identities"]) or meth["variant"] == "held_at_cost"
    wtxt = f", weights revenue {meth['weights']['revenue']} / EBITDA {meth['weights']['ebitda']} ({meth['weights']['basis']})" if meth.get("weights") else ""
    add("method", "method", f"method {meth['variant']}, metric basis {meth.get('metric_basis') or 'unknown'}{wtxt}"
        f"{', FX ' + meth['fx_rule'] if meth.get('fx_rule') else ''}, ownership: {meth.get('ownership_rule') or 'n/a'}",
        "identities" if proven else "labels only", "high" if proven else "low", not proven)
    for f, rec in sorted(lp["fields"].items()):
        if rec["status"] == "verified":
            continue
        add("lp_field", f, f"{f.replace('_', ' ')} = {rec['cell']} ('{rec['label']}', {fmt(rec['value'])})", rec["basis"],
            "medium" if rec["status"] in ("mapped", "chosen") else "low",
            f in ("enterprise_value", "equity_value", "investor_value", "moic") or rec["status"] == "weak", "approve", rec["cell"])
    ver = [f for f, r in lp["fields"].items() if r["status"] == "verified"]
    if ver:
        add("lp_field", "verified", f"{len(ver)} LP fields proven by identities: {', '.join(sorted(ver))}", "identities", "high", False)
    ents = lm.get("entries", [])
    full = [e for e in ents if e["evidence"] == "matched_all_overlap_months"]
    if full:
        add("line_map", "matched", f"{len(full)} monthly rows matched to statement lines on every overlap month", "statements", "high", False)
    for e in ents:
        if e["evidence"] in ("matched_all_overlap_months", "no_statements", "no_overlap", "adjustment_rows", "entity_statements_missing") or (e.get("adjustment") and e["evidence"] in ("title_only", "no_source")):
            continue
        if e["evidence"] == "single_period":
            add("line_map", e["line"], f"'{e['label']}' <- statement '{e['statement']['label']}' (one overlap period only)", "one period", "medium", True)
        elif e["evidence"] == "title_confirmed_by_ai":
            add("line_map", e["line"], f"'{e['label']}' <- statement '{e['statement']['label']}' (chosen by AI from titles; numbers differ)", "AI judgement", "low", True)
        elif e["evidence"] in ("title_only", "no_source"):
            props = ", ".join(f"'{p['label']}'" for p in e.get("proposals", [])) or "none"
            add("line_map", e["line"], f"'{e['label']}': no statement line matched (title proposals: {props}); "
                "the refresh will ask for its new months", "no match", "low", True, "give_value")
    for ev_, why in (("no_statements", "onboarded without statements"), ("no_overlap", "the statements cover no complete period of these rows"),
                     ("entity_statements_missing", "that entity's statements were not given")):
        ns = [e for e in ents if e["evidence"] == ev_ and not e.get("adjustment")]
        if ns:
            add("line_map", ev_, f"{len(ns)} monthly rows have no statement evidence yet ({why}); "
                "the first refresh maps them and proves them on its months", "no statements", "low", True)
    for f_, h in sorted((parts["lp_map"].get("hypotheses") or {}).items()):
        add("lp_field", f"hyp:{f_}", f"{f_.replace('_', ' ')}: AI proposed {h['calculation']} - "
            + ("verified by Python (Excel's value reproduced)" if h["verified"] else "NOT reproduced by Python; the analyst confirms the calculation"),
            "AI judgement + Python check", "medium" if h["verified"] else "low", True)
    bld = parts.get("build") or {}
    for g in bld.get("gaps", []):
        add("build", f"gap:{g['cell']}", f"{g['part']} {g['cell']} ('{g['label']}') has no source next quarter: {g['why']}", "build map", "low", True,
            "give_source", g["cell"])
    if bld.get("parts"):
        add("build", "map", f"build map: {len(bld['parts'])} parts traced from the LP row; each quarter: "
            + ("; ".join(bld["actions_each_quarter"]) if bld.get("actions_each_quarter") else "all inputs automatic or carried"),
            "build map", "high", False)
        for p in bld["parts"]:
            if p["per_quarter_sheet"]:
                add("build", f"roll:{p['sheet']}", f"'{p['sheet']}' is named for its quarter: the refresh creates the next quarter's copy and "
                    "points the valuation at it" + (f" (seen last quarter as '{p['prior_quarter_sheet']}')" if p.get("prior_quarter_sheet") else
                                                    " (confirm: no prior quarter given)"), "sheet name" + (" + prior quarter" if p.get("prior_quarter_sheet") else ""),
                    "high" if p.get("prior_quarter_sheet") else "medium", not p.get("prior_quarter_sheet"))
    adj = [m for m in inp["monthly_lines"] if m.get("adjustment")]
    if adj:
        add("inputs", "adjustments", f"{len(adj)} adjustment rows ({', '.join(m['label'] for m in adj[:4])}): new months come from the "
            "add-back schedule, or are proposed from the statements in the 9 adjustment categories; the analyst has the final say",
            "XPV method", "medium", False)
    params = [i for i in inp["items"] if i["class"] == "parameter"]
    if params:
        add("inputs", "parameters", f"{len(params)} parameters carried from the approved workbook (e.g. "
            + ", ".join(sorted({i['label'] for i in params if i['label']})[:6]) + ")", "approved workbook", "high", False)
    if inp.get("addins"):
        add("inputs", "addins", f"{len(inp['addins'])} add-in cells ({', '.join(sorted({f for a_ in inp['addins'] for f in a_['functions']}))}) "
            "are frozen to their saved values in drafts; their formulas are kept in the company file", "XPV method", "high", False)
    for i in [i for i in inp["items"] if i["class"] == "fx"]:
        add("inputs", f"fx:{i['cell']}", f"FX rate {i['cell']} ('{i['label']}' = {fmt(i['value'])}) is a quarterly input that is not in "
            "the statements; the refresh asks for the period-end rate", "XPV method", "medium", False, cell=i["cell"])
    fr = [i for i in inp["items"] if i["class"] == "fund_record"]
    if fr:
        add("inputs", "fund_records", f"{', '.join(i['field'].replace('_', ' ') for i in fr)} are typed in the workbook "
            f"({', '.join(i['cell'] for i in fr)}); each quarter they are confirmed against fund records", "default", "medium", False)
    add("settings", "materiality", "materiality thresholds and tolerances are the package defaults (unapproved)",
        "references/materiality_defaults.json", "medium", False)
    order = {"finding": 0, "build": 1, "lp_field": 2, "method": 3, "line_map": 4, "inputs": 5, "settings": 6}
    items.sort(key=lambda x: (order[x["group"]], not x["review"], x["subject"]))
    return {"items": items, "review_count": sum(1 for i in items if i["review"])}


# ------------------------------------------------------------------------------------------------ report
def report_md(parts):
    prof, lp, inp, lm, live, asm = (parts[k] for k in ("profile", "lp_map", "inputs", "line_map", "liveness", "assumptions"))
    L = [f"# Onboarding report - {prof['company_name']} ({(prof.get('valuation_date') or {}).get('value')})", "",
         f"Package {VERSION} | company_id `{prof['company_id']}` | workbook `{prof['workbook']['name']}` | generated {now().isoformat()}", "",
         "## Glossary", "", "| Term | Meaning |", "|---|---|"] + [f"| {t} | {d} |" for t, d in GLOSSARY] + ["",
         "## Result", "", f"- Readiness: **{prof['readiness']}**",
         f"- Method: {prof['method']['variant']} (metric basis {prof['method'].get('metric_basis')})",
         f"- Items for review: {asm['review_count']}", "",
         "## LP fields", "", "| Field | Cell | Label | Value | Status | Basis |", "|---|---|---|---|---|---|"]
    for f, r in sorted(lp["fields"].items()):
        L.append(f"| {f.replace('_', ' ')} | {r['cell']} | {r['label']} | {fmt(r['value'])} | {r['status']} | {r['basis']} |")
    L += ["", "## Identities (Python chain vs Excel)", "", "| ID | Identity | Result | Detail |", "|---|---|---|---|"]
    L += [f"| {i['id']} | {i['name']} | {i['result']} | {i['detail']} |" for i in lp["identities"]]
    if lp.get("metric_windows"):
        L += ["", "## Metric windows", "", "| Field | Range | Months | Ends at valuation month | Python sum = Excel |", "|---|---|---|---|---|"]
        L += [f"| {w['field']} | {w['range']} | {w['first']}..{w['last']} ({w['months']}) | {w['ends_at_valuation_month']} | "
              f"{w['python_sum_matches_excel']} |" for w in lp["metric_windows"]]
    L += ["", "## Liveness checks", "", "| Check | What | Result |", "|---|---|---|"]
    L += [f"| {k} | {v['name']} | {v['result']} |" for k, v in sorted(live["checks"].items())]
    if live["findings"]:
        L += ["", "Findings:"] + [f"- [{f['check']}] {f['text']}" for f in live["findings"]]
    c = inp["counts"]
    L += ["", "## Inputs upstream of the LP row", "",
          f"- Monthly rows: {c.get('monthly_lines', 0)} ({c.get('monthly_cells', 0)} typed month cells)",
          f"- Dates {c.get('date', 0)} | balances {c.get('balance', 0)} | FX {c.get('fx', 0)} | parameters {c.get('parameter', 0)} | "
          f"fund records {c.get('fund_record', 0)} | pasted calculations {c.get('pasted_calculation', 0)} | add-in cells {c.get('add_in', 0)}",
          f"- Typed numbers not upstream of the LP row (never written, never reviewed): {inp['typed_numbers']['untouched']}",
          f"- Sheets the LP row depends on: {', '.join(inp['sheets_reached'])}", "",
          "## Line map", "", f"- {lm.get('gate')}", "", "| Workbook row | Statement line | Scale | Evidence |", "|---|---|---|---|"]
    for e in lm.get("entries", []):
        st = (e.get("statement") or {}).get("label") or "-"
        L.append(f"| {e['label']} | {st} | {e.get('scale', '-')} | {e['evidence']} |")
    if parts.get("build"):
        L += ["", "## Build map (traced back from the LP row, in build order)", "", "```"] + build_lines(parts["build"]) + ["```"]
    L += ["", "## For review", ""]
    for i in asm["items"]:
        if i["review"]:
            L.append(f"- **{i['id']}** ({i['group']}, {i['confidence']}): {i['text']}" + (f" -> proposed `{i['proposed']}`" if i.get("proposed") else ""))
    L += ["", "## Accepted as a set when approved", ""] + [f"- {i['id']}: {i['text']}" for i in asm["items"] if not i["review"]]
    L += ["", "## How to approve", "", "Tell the agent: \"Approve the onboarding as <your name>\" (add any corrections, e.g. "
          "\"use cell X for equity value\"). Approval is bound to this exact method; a later change needs a new approval.", ""]
    return "\n".join(L)


# ------------------------------------------------------------------------------------------------ census
def workbook_stats(path):
    """file facts that need no workbook loading (for a workbook the analysis could not finish)."""
    import zipfile
    out = {"file_mb": round(os.path.getsize(path) / 1e6, 1), "sheets": None, "largest_sheet_xml_mb": None}
    try:
        with zipfile.ZipFile(path) as z:
            sizes = [i.file_size for i in z.infolist() if re.match(r"xl/worksheets/sheet\d+\.xml$", i.filename)]
            out["sheets"] = len(sizes)
            out["largest_sheet_xml_mb"] = round(max(sizes) / 1e6, 1) if sizes else 0
            out["all_sheet_xml_mb"] = round(sum(sizes) / 1e6, 1)
    except Exception as e:
        out["error"] = f"{type(e).__name__}: {e}"
    return out


def census_record(an, path):
    lp, c = an["lp_fields"], an["input_counts"]
    req = ("enterprise_value", "equity_value", "investor_value")
    ex = an["explain_cells"]
    fields = {}
    for f_, r in lp.items():
        d = ex.get(r["cell"], {})
        fields[f_] = dict(r, formula=d.get("formula"), precedents=[p["cell"] for p in d.get("precedents", [])])
    blocks = an["blocks"]
    feeding = c.get("monthly_lines", 0)
    sev = {"blocking": 0, "warning": 0}
    by_kind = {}
    for f_ in an["findings"]:
        sev[f_["severity"]] = sev.get(f_["severity"], 0) + 1
        by_kind[f_["kind"]] = by_kind.get(f_["kind"], 0) + 1
    wc = an["workbook_counts"]
    return {
        "workbook": stable_name(path), "verdict": an["verdict"], "period": an["period"],
        "method": {"type": an["method"]["variant"], "components": an["method_components"],
                   "other_multiples_not_in_ev": an["other_multiples"], "fx_rule": an["method"]["fx_rule"],
                   "ownership_rule": an["method"]["ownership_rule"], "bridge": an["method"]["bridge"]},
        "metric_basis": an["metric_basis_list"],
        "lp_fields": {"total": len(lp), "verified": sum(1 for v in lp.values() if v["status"] == "verified"),
                      "mapped_only": sum(1 for v in lp.values() if v["status"] != "verified"),
                      "required_missing": [f for f in req if f not in lp and an["method"]["variant"] != "held_at_cost"
                                           or (f == "investor_value" and f not in lp)],
                      "fields": fields},
        "unproven_identities": an["verdict"]["unproven_identities"], "features": an["features"],
        "metric_sources": an["metric_sources"], "hypotheses_possible": [i["name"] for i in an["identities"] if i["result"] == "NOT PROVEN"],
        "identities": an["identities"], "metric_windows": an["metric_windows"],
        "diagnostics": {
            "period_structures": {"detected_in_workbook": len(blocks),
                                  "detail": [f"{b['sheet']} {b['first']}..{b['last']} {'quarterly' if b.get('step') == 3 else 'monthly'} x{b['rows']} rows" for b in blocks],
                                  "rows_feeding_lp_fields": feeding,
                                  "interpretation": ("" if feeding or not blocks else
                                                     "period structures exist, but none of their rows feed the LP fields found")},
            "parameters": {"count": c.get("parameter", 0), "scope": "LP dependency graph"},
            "fund_records": {"count": c.get("fund_record", 0), "scope": "LP dependency graph"},
            "pasted_calculations": {"count": c.get("pasted_calculation", 0), "scope": "LP dependency graph"},
            "hardcoded_lp_values": {"count": by_kind.get("hardcoded_output", 0), "scope": "LP fields and their copies"},
            "add_ins": {"count": c.get("add_in", 0), "scope": "LP dependency graph", "workbook_total": wc["add_in_cells"],
                        "functions": sorted({f for a_ in an["addins"] for f in a_["functions"]}),
                        "with_provider_errors": an["error_breakdown"]["add_in_cells_with_errors"]},
            "external_links": {"count": len(an["externals"]), "scope": "LP dependency graph",
                               "workbook_total": wc["external_link_formulas"], "status": "external_frozen" if an["externals"] else None,
                               "linked_workbooks": wc.get("linked_workbooks", []),
                               "note": "values read from other workbooks are the last saved values; they never recalculate here"},
            "errors": dict(an["error_breakdown"], workbook_total=wc["error_cells"]),
            "calculation_mode": {"value": an["workbook"]["calc_mode"], "scope": "entire workbook"},
            "sheets_reached": {"sheets": an["sheets_reached"], "of_total": len(an["workbook"]["sheets"]), "scope": "LP dependency graph"},
            "cells_not_stored": {"count": wc["cells_not_stored_on_unreferenced_sheets"], "scope": "sheets no formula refers to",
                                 "by_sheet": an["skipped_cells"]},
            "findings": {"total": len(an["findings"]), **sev, "by_kind": by_kind},
        },
        "findings": an["findings"],
    }


def cmd_census_one(a):
    if os.environ.get("VALUATION_TEST_KILL") and os.environ["VALUATION_TEST_KILL"] == os.path.basename(a.workbook):
        import signal
        os.kill(os.getpid(), signal.SIGKILL)                      # test hook: behave like the sandbox's memory kill
    an = analyze(a.workbook, a.period_end)
    rec = census_record(an, a.workbook)
    b = PT.Builder(an, None).build()
    rec["build"] = {"parts": [{k: p[k] for k in ("id", "sheet", "role", "depends_on", "status", "needs", "per_quarter_sheet")} |
                              {"inputs": [{k: i[k] for k in ("class", "count", "each_quarter")} for i in p["inputs"]]} for p in b["parts"]],
                    "trace": b["trace"], "gaps": b["gaps"], "actions_each_quarter": b["actions_each_quarter"], "lines": build_lines(b)}
    if b["gaps"]:
        rec["verdict"]["warnings"].append(f"{len(b['gaps'])} input(s) feeding the LP row have no source next quarter")
        if rec["verdict"]["status"] == "READY TO ONBOARD":
            rec["verdict"]["status"] = "REVIEW"
    dump(rec, a.json_out)
    return 0


def cmd_census(a):
    allp = need_files(a.workbooks)
    od = os.path.join(out_dir(a), "census")
    os.makedirs(od, exist_ok=True)
    paths, skipped = [], []
    for p in allp:                       # optional portfolio overview: only valuation workbooks are censused
        cls = CT.classify_file(p)
        if cls["kind"] == "valuation workbook":
            paths.append(p)
        else:
            skipped.append((p, cls))
    recs = []
    for p in paths:
        st = workbook_stats(p)
        print(f"READING: {stable_name(p)} ({st['file_mb']} MB, {st['sheets']} sheets, largest sheet {st['largest_sheet_xml_mb']} MB of XML)", flush=True)
        tmp = os.path.join(od, f".one_{abs(hash(p)) % 10**8}.json")
        cmd = [sys.executable, os.path.abspath(__file__), "census-one", "--workbook", p, "--json-out", tmp]
        if a.period_end:
            cmd += ["--period-end", a.period_end]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode == 0 and os.path.exists(tmp):
            with open(tmp, encoding="utf-8") as fh:
                recs.append(json.load(fh))
            os.remove(tmp)
            continue
        killed = r.returncode in (-9, 137)
        why = ("the analysis process was killed by the sandbox (exit 137 / signal 9 - almost always out of memory)" if killed
               else f"the analysis stopped with exit {r.returncode}: " + (" ".join((r.stdout + r.stderr).split()[-40:]) or "no message"))
        recs.append({"workbook": stable_name(p), "verdict": {"status": "NOT ANALYSED", "blocking": [why], "warnings": []},
                     "file": st})
    def cell(rec, k):
        v, per, meth, lpf = rec["verdict"], rec.get("period", {}), rec.get("method", {}), rec.get("lp_fields", {})
        if k == "workbook": return rec["workbook"]
        if k == "verdict": return v["status"]
        if rec["verdict"]["status"] == "NOT ANALYSED": return "-"
        if k == "intended": return per.get("intended_reporting_month") or ("conflict: " + ", ".join(f"{s} {m}" for s, m in per.get("intended_sources", {}).items()) if per.get("intended_sources") else "unknown")
        if k == "calculated": return "; ".join(per.get("windows") or []) or "not traced"
        if k == "alignment": return per.get("alignment")
        if k == "method":
            parts = [f"{c_['metric']}" + (f" x{c_['weight']:g}" if isinstance(c_.get("weight"), (int, float)) and meth["type"] == "blended" else "") for c_ in meth.get("components", [])]
            return meth["type"] + (f" ({' + '.join(parts)})" if parts and meth["type"] in ("blended",) else "")
        if k == "basis": return ", ".join(rec.get("metric_basis", []))
        if k == "fields": return f"{lpf['verified']} proven / {lpf['mapped_only']} mapped / {len(lpf['required_missing'])} missing"
        if k == "unproven": return ", ".join(rec.get("unproven_identities", [])) or "none"
        if k == "build":
            b = rec.get("build") or {}
            return f"{len(b.get('parts', []))} parts, {len(b.get('gaps', []))} gaps, {sum(1 for p in b.get('parts', []) if p['needs'])} need action"
        if k == "blocking": return str(rec["diagnostics"]["findings"].get("blocking", 0))
        if k == "warnings": return str(rec["diagnostics"]["findings"].get("warning", 0))
    cols = [("workbook", "workbook"), ("verdict", "verdict"), ("intended", "intended period"), ("calculated", "metric window"),
            ("alignment", "period alignment"), ("method", "method"), ("basis", "metric basis"), ("fields", "LP fields"),
            ("unproven", "unproven identities"), ("build", "build map"), ("blocking", "blocking"), ("warnings", "warnings")]
    table = ["| " + " | ".join(h for _, h in cols) + " |", "|" + "---|" * len(cols)]
    table += ["| " + " | ".join(str(cell(r_, k)) for k, _ in cols) + " |" for r_ in recs]
    md = [f"# Workbook census ({today()}, package {VERSION})", "", "## Glossary", "", "| Term | Meaning |", "|---|---|"] + \
         [f"| {t} | {d} |" for t, d in GLOSSARY] + [
         "| Verdict | READY TO ONBOARD: nothing found; REVIEW: warnings or unproven identities; BLOCKED: something would make the LP numbers wrong; NOT ANALYSED: the analysis could not finish |",
         "| Scope | Every count says what it covers: the LP dependency graph (cells the LP fields depend on), the LP fields, or the entire workbook |",
         "", "## Summary", ""] + table + [""]
    for r_ in recs:
        md += [f"## {r_['workbook']} - {r_['verdict']['status']}", ""]
        if r_["verdict"]["status"] == "NOT ANALYSED":
            md += [f"- {r_['verdict']['blocking'][0]}", f"- file: {r_['file']}", ""]
            continue
        per, meth, dg = r_["period"], r_["method"], r_["diagnostics"]
        md += ["### Period", f"- intended: {per['intended_sources'] or 'no source'}; calculation month(s): {per['calculation_months_seen'] or 'not traced'}; alignment **{per['alignment']}**", "",
               "### Method", f"- type: {meth['type']}; FX: {meth['fx_rule'] or 'none'}; ownership: {meth['ownership_rule'] or 'n/a'}"]
        md += [f"- component: {c_['metric']} | multiple {c_.get('multiple_cell', '-')} | metric {c_.get('metric_cell', '-')} | weight {c_.get('weight')} | basis {c_.get('period_basis', '-')}" for c_ in meth["components"]]
        md += [f"- present but not used in EV: {o['label']} ({o['cell']} = {fmt(o['value'])})" for o in meth["other_multiples_not_in_ev"]]
        md += ["", "### LP fields", "", "| Field | Cell | Label | Status | Basis | Formula |", "|---|---|---|---|---|---|"]
        md += [f"| {f_} | {v['cell']} | {v['label']} | {v['status']} | {v['basis']} | `{(v.get('formula') or 'typed')[:60]}` |" for f_, v in sorted(r_["lp_fields"]["fields"].items())]
        md += ["", "### Identities", ""] + [f"- {i['id']} {i['name']}: **{i['result']}** - {i['detail']}" for i in r_["identities"]]
        md += ["", "### Diagnostics (with scope)", "", "| Item | Count | Scope | Detail |", "|---|---|---|---|"]
        for k_, d in dg.items():
            if k_ == "findings":
                continue
            cnt = d.get("count", d.get("detected_in_workbook", d.get("value", "")))
            extra = {kk: vv for kk, vv in d.items() if kk not in ("count", "scope", "detected_in_workbook", "value")}
            md.append(f"| {k_.replace('_', ' ')} | {cnt} | {d.get('scope', 'entire workbook')} | {json.dumps(extra, default=str)[:160]} |")
        if r_.get("build"):
            md += ["", "### Build map (traced back from the LP row, in build order)", "", "```"] + r_["build"]["lines"] + ["```"]
        md += ["", "### Findings", ""] + [f"- **{f_['severity']}** [{f_['check']}] {f_['text']}" for f_ in r_["findings"]] + ([] if r_["findings"] else ["- none"]) + [""]
    mdp = os.path.join(od, f"census_{today()}.md")
    open(mdp, "w", encoding="utf-8").write("\n".join(md))
    jp = dump({"package_version": VERSION, "date": today(), "workbooks": recs}, os.path.join(od, f"census_{today()}.json"))
    print(f"CENSUS: {len(recs)} workbook(s) | package {VERSION}")
    print("\n".join(table))
    for r_ in recs:
        v = r_["verdict"]
        reason = (v["blocking"] or v["warnings"] or [""])[0]
        print(f"- {r_['workbook']}: {v['status']}" + (f" - {reason[:220]}" if reason else ""))
        for q_ in v.get("questions_for_analyst", [])[:3]:
            if q_ != reason:
                print(f"  question for the analyst: {q_[:220]}")
        links = (r_.get("diagnostics", {}).get("external_links", {}) or {}).get("linked_workbooks")
        if links:
            print(f"  linked workbooks (their values are frozen here): {', '.join(links[:5])}")
    for p, cls in skipped:
        print(f"- {stable_name(p)}: a {cls['kind']}, not a valuation workbook - skipped (use it at onboarding)")
    for r_ in recs:
        if r_.get("hypotheses_possible"):
            print(f"  {r_['workbook']}: unproven {', '.join(r_['hypotheses_possible'])} - at onboarding the AI proposes the calculation and Python checks it")
        for f_, t in (r_.get("metric_sources") or {}).items():
            print(f"  {r_['workbook']}: {f_.replace('_', ' ')} {t}")
    print(f"FILE: {mdp}")
    for l in sp_lines("_census", "", [mdp, jp]):
        print(l)
    print("NEXT: carry out the SHAREPOINT lines, then post the table and the lines under it unchanged and offer the .md files. Stop.")
    return 0


# ------------------------------------------------------------------------------------------------ judgement, needs, intake
IDENTITY_FIELDS = {"I1": "enterprise_value", "I3": "equity_value", "I4": "investor_value", "I6": "moic"}


def identity_questions(an):
    """unproven identities become AI questions: the AI proposes the calculation from the labelled inputs, Python checks it."""
    out = []
    for i in an["identities"]:
        f_ = IDENTITY_FIELDS.get(i["id"])
        if i["result"] not in ("NOT PROVEN", "OUT OF BOUNDS") or not f_ or f_ not in an["lp_fields"]:
            continue
        cell = an["lp_fields"][f_]["cell"]
        d = an["explain_cells"].get(cell) or an["model"].describe(parse_ref_str(cell))
        out.append({"id": short_id("Q", {"identity": f_, "cell": cell}), "type": "identity", "field": f_, "target": cell,
                    "label": d["label"], "value": d["value"], "formula": d["formula"], "precedents": d["precedents"], "options": {},
                    "prompt": f"Python could not prove the {i['name']} ({i['detail']}). From the formula and its labelled inputs, "
                              f"give the calculation that reproduces it - Python will check it against Excel's value."})
    return out


def have_need(an, idx, build, prior_given):
    vm = an.get("_val_i")
    months = [ym_str(vm - j) for j in (2, 1, 0)] if vm is not None else []
    fin = [p for p in build["parts"] if p["role"] == "financials"]
    have_ent = {}
    for f in idx["files"]:
        if f["statement_period"]:
            have_ent.setdefault(ST.entity_of(f["name"]), set()).add(f["statement_period"])
    L = [f"HAVE: approved workbook {an['workbook']['name']} (valued {an['valuation_month']})"]
    for e, ms in sorted(have_ent.items()):
        miss = [m_ for m_ in months if m_ not in ms]
        L.append(f"HAVE: statements for {e}: {', '.join(sorted(ms))}" + (f" | NEED: {', '.join(miss)} for a full line map" if miss else ""))
    if not have_ent:
        L.append(f"NEED: monthly statements for {', '.join(months) or 'the valuation quarter'} for each entity "
                 f"({len(fin)} financials part(s): {', '.join(p['sheet'] for p in fin)}) - onboarding ran without them")
    elif len(have_ent) < len(fin):
        L.append(f"NEED: statements for {len(fin)} entities (financials sheets: {', '.join(p['sheet'] for p in fin)}); "
                 f"given for {len(have_ent)}")
    L.append("HAVE: previous quarter's approved workbook" if prior_given else
             "OPTIONAL: previous quarter's approved workbook (--previous) - enables the walk-forward backtest and shows what changes each quarter")
    links = an["workbook_counts"].get("linked_workbooks", [])
    if an["externals"]:
        L.append(f"NEED: (before the refresh) the linked workbook(s) feeding the LP row ({', '.join(links[:4]) or 'see the census'}), "
                 "or a decision to carry their values")
    for act in build.get("actions_each_quarter", []):
        L.append(f"NEED: (each quarter) {act}")
    return L


def assign_company(path, company=None):
    """which company a file belongs to: the user said so > its name resembles a company. (gather also uses the
    valuation workbook's own links.) Returns (company_id, name, basis)."""
    if company:
        return company_slug(company), company, "stated by the user"
    guess = CT.company_from_filename(path)
    if guess:
        return company_slug(guess), guess, "from the file name (confirm)"
    return None, None, "unknown company (say which company)"


def cmd_add(a):
    od = out_dir(a)
    if a.fact:
        if not a.company or not a.by:
            print("STOPPED: a fact needs --company and --by (the analyst's name). Ask the user and stop.")
            return 3
        cid = company_slug(a.company)
        if not resolve(f"{cid}_company.zip", [od], broad=False):
            print(f"STOPPED: facts are kept in {a.company}'s company file, which is not in this conversation. Onboard {a.company} "
                  "first (or paste the SharePoint link to its company file), then repeat. Tell the user exactly this and stop.")
            return 3
        zp, parts, ledger = company_zip(a, cid)
        facts = parts.setdefault("facts", {"items": []})["items"]
        rec = {"id": f"F-{len(facts) + 1:03d}", "about": a.fact, "value": a.value, "target": a.target, "by": a.by,
               "said": a.said or "", "on": today(), "status": "recorded as stated; applied by the quarterly generation to its part"}
        facts.append(rec)
        ledger = CF.ledger_append(ledger, "fact_recorded", by=a.by, data=rec)
        zp = CF.write(os.path.join(od, os.path.basename(zp)), parts, ledger)
        print(f"INTAKE: fact {rec['id']} for {a.company}: {rec['about']} = {rec['value']} (by {rec['by']}, {rec['on']}) - "
              "recorded exactly as stated in the company file; never recalculated by the AI")
        for l in sp_lines(cid, "company", [zp], folder=False):
            print(l)
        print("NEXT: carry out the SHAREPOINT line, then post the INTAKE line. Stop.")
        return 0
    paths = need_files(a.files or [])
    saved = []
    for p in paths:
        cls = CT.classify_file(p)
        cid, cname, basis = assign_company(p, a.company)
        if not cid:
            print(f"INTAKE: {stable_name(p)} | {cls['kind']} | company unknown: not filed - re-run add with --company \"<company name>\"")
            continue
        dest = copy_into(p, os.path.join(od, "inbox", cid))
        saved.append((cid, dest))
        print(f"INTAKE: {stable_name(p)} -> {cname} ({basis}) | {cls['kind']}"
              + (f" | entity {cls['entity']}" if cls.get("entity") else "") + (f" | period {cls['period']}" if cls.get("period") else ""))
    for cid in sorted({c for c, _ in saved}):
        for l in sp_lines(cid, "inbox", [d for c, d in saved if c == cid]):
            print(l)
    print("NEXT: carry out the SHAREPOINT lines, then post the INTAKE lines unchanged. If a company is wrong, re-run add with "
          "--company. Stop.")
    return 0


def cmd_reference(a):
    """on demand: how the given workbooks (found by searching 'Valuation Workbooks' for the feature) are structured."""
    if not a.workbooks:
        print(f"STOPPED: reference needs workbooks. Search 'Valuation Workbooks' for \"{a.feature or 'the feature'}\", then re-run "
              "reference with --workbooks and the names found (up to 5).")
        return 3
    hits = []
    for p in need_files(a.workbooks[:5]):
        tmp = os.path.join(out_dir(a), f".ref_{abs(hash(p)) % 10**8}.json")
        r = subprocess.run([sys.executable, os.path.abspath(__file__), "census-one", "--workbook", p, "--json-out", tmp],
                           capture_output=True, text=True)
        if r.returncode != 0 or not os.path.exists(tmp):
            print(f"- {stable_name(p)}: could not be analysed (exit {r.returncode})")
            continue
        with open(tmp, encoding="utf-8") as fh:
            rec = json.load(fh)
        os.remove(tmp)
        pat = CT.pattern_of(rec)
        if a.feature and not (pat["flags"].get(a.feature) or pat["features"].get(a.feature)):
            continue
        hits.append((CT.company_from_filename(p) or stable_name(p), stable_name(p), pat))
    print(f"REFERENCE: {len(hits)} workbook(s)" + (f" with feature '{a.feature}'" if a.feature else "") + " | structure only, no numbers")
    for comp, name, pat in hits:
        print(f"- {comp} ({name}): method {pat['method']} | flags {', '.join(k for k, v in pat['flags'].items() if v) or '-'}")
        print(f"  parts: {'; '.join(x['sheet'] + ' [' + x['role'] + ']' for x in pat['parts'][:12])}")
        for fl in (pat["features"].get(a.feature, [])[:5] if a.feature else []):
            print(f"  {a.feature}: {fl['sheet']} - {fl['label']}")
    print("NEXT: post the REFERENCE lines unchanged. They show how other companies are structured; the analyst decides what to "
          "follow. Never copy numbers between companies. Stop.")
    return 0


def cmd_status(a):
    cid = company_slug(a.company)
    if not resolve(f"{cid}_company.zip", [out_dir(a)], broad=False):
        print(f"STATUS: {a.company} has no company file in this conversation. NEXT: onboard it (\"Onboard {a.company} for <quarter>\"), "
              "or paste the SharePoint link to its company file. Stop.")
        return 0
    _, parts, ledger = company_zip(a, cid)
    prof = parts["profile"]
    print(f"STATUS: {prof['company_name']} | readiness {prof['readiness']} | valued {prof.get('valuation_month')} | "
          f"approvals {len(prof.get('approvals', []))} | ledger events {len(ledger)}")
    nxt = {"ONBOARDING_PENDING_RECALC": "carry out the RECALC step and check-recalc",
           "ONBOARDED_PENDING_APPROVAL": "named approval",
           "ONBOARDED": "quarterly generation (next build)"}.get(prof["readiness"], "-")
    print(f"STATUS: next step: {nxt}")
    for f in parts.get("bronze_registry", {}).get("files", []):
        print(f"HAVE: {f['name']} ({f['kind']}{', ' + str(f['period']) if f.get('period') else ''})")
    for x in parts.get("facts", {}).get("items", []):
        print(f"HAVE: fact {x['id']}: {x['about']} = {x['value']} (by {x['by']}, {x['on']})")
    for g in (parts.get("build") or {}).get("gaps", [])[:5]:
        print(f"NEED: source for {g['cell']} '{g['label']}' ({g['why']})")
    for act in (parts.get("build") or {}).get("actions_each_quarter", []):
        print(f"NEED: (each quarter) {act}")
    print("NEXT: post the STATUS, HAVE and NEED lines unchanged; ask the user for anything under NEED. Stop.")
    return 0


# ------------------------------------------------------------------------------------------------ gather
MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
FILE_EXT = (".xlsx", ".xlsm", ".csv", ".pdf", ".docx")


def parse_quarter(text):
    """'2026-Q2', 'Q2 2026', 'June 2026', '2026-06' -> month index of the quarter end."""
    t = str(text or "").strip().lower()
    m = re.search(r"(20\d{2})\s*-?\s*q([1-4])", t)
    if m:
        return ym_to_i((int(m.group(1)), int(m.group(2)) * 3))
    m = re.search(r"q([1-4])\s*-?\s*(20\d{2})", t)
    if m:
        return ym_to_i((int(m.group(2)), int(m.group(1)) * 3))
    from wbutil import parse_date_text
    p = parse_date_text(t)
    if p:
        return ym_to_i((p[0], ((p[1] - 1) // 3 + 1) * 3))
    return None


def search_roots():
    env = os.environ.get("VALUATION_FILE_ROOTS")
    if env:
        return [r for r in env.split(os.pathsep) if r]
    return [UPLOADS, os.getcwd(), "/app"]


SKIP_DIRS = ("/skills", "/created", "/census", "/__pycache__", "_selftest_", "/inbox", "/bronze", "/onboarding")


def candidate_files(explicit):
    if explicit:
        return need_files(explicit)
    roots = search_roots()
    seen, out = set(), []
    for r in roots:
        if not r or not os.path.isdir(r):
            continue
        for root, dirs, files in os.walk(r):
            rel = "/" + os.path.relpath(root, r).replace(os.sep, "/")     # skip rules apply below the search folder
            if rel != "/." and any(x in rel for x in SKIP_DIRS):
                dirs[:] = []
                continue
            for f in files:
                pth = os.path.join(root, f)
                if f.lower().endswith(FILE_EXT) and "__copy" not in f and "__draft" not in f and pth not in seen:
                    seen.add(pth)
                    out.append(pth)
    return out


def rank_workbook(path):
    n = os.path.basename(path).lower()
    v = re.search(r"\bv(\d+)\b", n.replace("_", " "))
    return (0 if "draft" in n else 1, 1 if re.search(r"final|approved", n) else 0, int(v.group(1)) if v else 0, os.path.getmtime(path))


def cmd_gather(a):
    q_end = parse_quarter(a.quarter)
    if q_end is None:
        print(f"STOPPED: '{a.quarter}' is not a quarter. Ask the user which quarter (e.g. Q2 2026) and stop.")
        return 3
    months = [q_end - 2, q_end - 1, q_end]
    rows, seen_names = [], set()
    for p in candidate_files(a.files):
        if stable_name(p) in seen_names:                 # the same file fetched twice (e.g. upload and knowledge)
            continue
        seen_names.add(stable_name(p))
        try:
            cls = CT.classify_file(p)
        except Exception:
            continue
        guess = CT.company_from_filename(p)
        if similarity(guess, a.company) >= 0.5:
            owner = "this company"
        elif cls["kind"] == "LP report":
            owner = "portfolio"
        elif cls["kind"] in ("valuation workbook", "monthly summary") and guess:
            owner = f"other: {guess}"                       # a workbook named for a different company
        else:
            owner = "unknown"                               # e.g. statements named for an entity: the line map decides
        per = cls.get("period")
        rows.append({"path": p, "name": stable_name(p), "kind": cls["kind"], "period": per, "entity": cls.get("entity"),
                     "owner": owner, "pi": ym_to_i(tuple(map(int, per.split("-")))) if per else None})
    mine = [r for r in rows if r["owner"] == "this company"]
    used_dirs = sorted({os.path.dirname(r["path"]) for r in rows})
    vw = lambda pi: sorted((r for r in mine if r["kind"] == "valuation workbook" and r["pi"] == pi), key=lambda r: rank_workbook(r["path"]), reverse=True)
    cur, prev = vw(q_end), vw(q_end - 3)
    linked = []
    if cur:
        try:
            from workbook_model import _zip_facts
            linked = _zip_facts(cur[0]["path"])[3]
        except Exception:
            linked = []
    linked_b = {CT.bare_name(x) for x in linked}
    for r in rows:                                          # a file the chosen workbook links to belongs to this company
        if CT.bare_name(r["name"]) in linked_b and r["owner"] != "this company":
            r["owner"] = "this company"
            r["linked"] = True
    stm = [r for r in rows if (r["kind"] in ("statement pack", "monthly summary") and r["pi"] in months
                               and r["owner"] in ("this company", "unknown")) or r.get("linked")]
    have_names = {CT.bare_name(r["name"]) for r in rows}
    qlabel = f"Q{(i_to_ym(q_end)[1] - 1) // 3 + 1} {i_to_ym(q_end)[0]}"
    print(f"GATHER: {a.company} | {qlabel} ({', '.join(ym_str(m) for m in months)}) | {len(rows)} file(s) available | "
          f"{len(mine)} for this company | {sum(1 for r in rows if r['owner'].startswith('other'))} other companies' (ignored)")
    print(f"GATHER: looked in {', '.join(search_roots()) if not a.files else 'the files given'}; files found in "
          f"{', '.join(used_dirs[:4]) or 'none'}{' ...' if len(used_dirs) > 4 else ''}")
    if cur:
        c0 = cur[0]
        draft = "draft" in c0["name"].lower()
        print(f"HAVE: valuation workbook {c0['name']} ({c0['period']}{', DRAFT' if draft else ''})"
              + (f" | chosen over {', '.join(r['name'] for r in cur[1:])}" if len(cur) > 1 else ""))
        if draft:
            print(f"NEED: an approved (non-draft) {qlabel} valuation workbook - search 'Valuation Workbooks' for \"{a.company} {qlabel} valuation\"; "
                  "if none exists, ask the user whether to onboard from the draft")
    else:
        print(f"NEED: the {qlabel} valuation workbook - search 'Valuation Workbooks' for \"{a.company} {qlabel} valuation workbook\"")
    pl = f"Q{(i_to_ym(q_end - 3)[1] - 1) // 3 + 1} {i_to_ym(q_end - 3)[0]}"
    if prev:
        print(f"HAVE: previous quarter {prev[0]['name']} ({prev[0]['period']})")
    else:
        print(f"OPTIONAL: the {pl} valuation workbook (enables the walk-forward backtest) - search 'Valuation Workbooks' for \"{a.company} {pl} valuation\"")
    got = {}
    for r in stm:
        got.setdefault(r["pi"], []).append(r)
        print(f"HAVE: {r['kind']} {r['name']} ({r['period']}{', entity ' + r['entity'] if r.get('entity') else ''}"
              + (", linked by the valuation workbook" if r.get("linked") else "")
              + (", company not named in file: the line map proves it or rejects it" if r["owner"] == "unknown" else "") + ")")
    for mi in months:
        if mi not in got:
            y, mo = i_to_ym(mi)
            print(f"NEED: statements for {MONTH_NAMES[mo - 1]} {y} - search 'Company Financial Statements' and 'Monthly Summaries' "
                  f"for \"{a.company} {MONTH_NAMES[mo - 1]} {y}\" (every entity)")
    for lw in linked:
        if CT.bare_name(lw) not in have_names:
            print(f"NEED: linked workbook \"{lw}\" (the valuation workbook reads it) - search 'Monthly Summaries' for that name")
    for r in rows:
        if r["owner"] == "portfolio":
            print(f"HAVE: LP report {r['name']} (kept for checking reported values; not used by onboarding)")
    other = [r for r in rows if r["owner"].startswith("other")]
    if other:
        print(f"GATHER: ignored (other companies): {', '.join(r['name'] for r in other[:6])}{' ...' if len(other) > 6 else ''}")
    if cur:
        cmd = (f'python scripts/pipeline.py onboard --workbook "{cur[0]["name"]}"'
               + (f' --previous "{prev[0]["name"]}"' if prev else "")
               + (" --statements " + " ".join(f'"{r["name"]}"' for r in stm) if stm else "")
               + f' --company "{a.company}"')
        print(f"THEN: {cmd}")
    print("NEXT: if NEED lines remain and this is gather round 1 or 2, search the named knowledge sources for exactly those items, "
          "then run gather again. Then run the THEN command. Ask the user only for items still missing after round 2, in one message.")
    return 0


# ------------------------------------------------------------------------------------------------ onboard
def parse_answers(s):
    if not s:
        return None
    s = s.strip()
    if s == "-":
        s = sys.stdin.read()
    try:
        return json.loads(s)
    except json.JSONDecodeError as e:
        print(f"PIPELINE ERROR: --answers is not valid JSON ({e}). Re-run with one line of JSON, e.g. {{\"Q-1a2b3c4d\": \"a\"}}")
        sys.exit(1)


def cmd_onboard(a):
    wb = need_files([a.workbook])[0]
    st = workbook_stats(wb)
    print(f"READING: {stable_name(wb)} ({st['file_mb']} MB, {st['sheets']} sheets, largest sheet {st['largest_sheet_xml_mb']} MB of XML)", flush=True)
    stmts = need_files(a.statements or [])
    answers = parse_answers(a.answers)
    cid = company_slug(a.company)
    forced = {}
    an = analyze(wb, a.period_end)
    idx = ST.index_files(stmts) if stmts else {"files": [], "values": [], "checks": []}
    mrows = [ml for ml in an["monthly_lines"]]
    entries, stats, lq, stmt_months = ST.line_map(an["model"], mrows, idx, an["_val_i"]) if stmts else ([], {}, [], [])
    block_months = sorted({mi - j for b_ in an["model"].blocks() for mi in b_["months"] for j in range(b_["step"] or 1)})
    ok, gate_msg, mode = ST.period_gate(stmt_months, block_months, an["_val_i"])
    if not ok:
        print(f"STOPPED: period gate - {gate_msg}.")
        print("NEXT: tell the user exactly this and stop. Do not save anything.")
        return 3
    if not stmts:
        entries = [{"line": ml["line"], "label": ml["label"], "adjustment": bool(ml.get("adjustment")), "statement": None,
                    "evidence": "no_statements"} for ml in mrows]
        stats = {"no_statements": len(entries)}
    questions = an["questions"] + lq + identity_questions(an)
    if questions and answers is None:
        print("JUDGMENT NEEDED (the only AI step). Answer each item from what is printed here: choose the option whose label and "
              "value best fit, or \"none\" if no option fits. Never guess numbers. Then re-run the SAME command adding: "
              "--answers '<one-line JSON {\"Q-id\": \"letter or none\"}>'")
        for q in questions:
            print(f"{q['id']} {q['prompt']}")
            if q["type"] == "identity":
                print(f"  target {q['target']} '{q['label']}' = {fmt(q['value'])} | formula {q['formula'] or '(typed)'}")
                for pr in q["precedents"]:
                    print(f"  input {pr['cell']} '{pr['label']}' = {fmt(pr['value'])}" + (f" | {pr['formula']}" if pr.get("formula") else ""))
                print('  answer: {"op": "sum", "terms": [["Sheet!B21", 1], ["Sheet!B25", -1]]} (or "op": "product", -1 divides) or "none"')
                continue
            for letter, o in q["options"].items():
                desc = f"{o.get('cell', '')} '{o.get('label')}'" + (f" = {fmt(o['value'])}" if "value" in o else "") + \
                       (f" ({o.get('entity', '')}, sheet {o['sheet']}, title similarity {o['similarity']})" if "sheet" in o else "")
                print(f"  {letter}) {desc.strip()}")
            for d in q.get("differences", []):
                sc = d.get("scale", 1)
                print(f"  note: {d['month']} workbook {fmt(d['workbook'])} vs statement {fmt(d['statement'])}"
                      + (f" (x{sc:g} = {fmt(d['statement'] * sc)})" if sc != 1 else "") + (" same" if d.get("matches") else " DIFFERENT"))
        return 10
    answered, hyps = {}, {}
    for q in questions:
        raw = (answers or {}).get(q["id"], "none")
        if q["type"] == "identity":
            if isinstance(raw, dict) and raw.get("terms"):
                hyps[q["field"]] = {"target": q["target"], "op": raw.get("op", "sum"), "terms": raw["terms"]}
                answered[q["id"]] = {"question": q["prompt"], "answer": raw}
            continue
        ans = str(raw).strip().lower()
        if ans in q["options"]:
            answered[q["id"]] = {"question": q["prompt"], "answer": q["options"][ans]}
            if q["type"] == "lp_field":
                forced[q["field"]] = q["options"][ans]["cell"]
            elif q["type"] == "line_map":
                for e in entries:
                    if e["line"] == q["line"]:
                        e["statement"] = {"sheet": q["options"][ans]["sheet"], "label": q["options"][ans]["label"],
                                          "entity": q["options"][ans].get("entity")}
                        e["evidence"] = "title_confirmed_by_ai"
    if forced or hyps:
        an = analyze(wb, a.period_end, forced, hyps)
        for f_, cell in forced.items():
            if f_ in an["lp_fields"] and an["lp_fields"][f_]["status"] != "verified":
                an["lp_fields"][f_].update(status="chosen", basis="AI judgement (JUDGMENT NEEDED)")
    stats = {}
    for e in entries:
        stats[e["evidence"]] = stats.get(e["evidence"], 0) + 1
    prior = None
    if a.previous:
        pp = need_files([a.previous])[0]
        prior = analyze(pp)
    bal = PT.balance_sources(an, idx, an["_val_i"]) if stmts else {}
    build = PT.Builder(an, entries if stmts else None).build(prior, bal)
    od = out_dir(a)
    vm = an["valuation_month"] or "unknown"
    # bronze: the approved workbook and statements, saved once, never modified
    bronze_dir = os.path.join(od, "bronze", vm)
    bronze = [{"name": stable_name(wb), "kind": "baseline_workbook", "sha256": file_sha256(wb), "bytes": os.path.getsize(wb),
               "period": vm, "saved_to": f"Valuations/{cid}/bronze/{vm}/{stable_name(wb)}"}]
    for s_, fi in zip(sorted(stmts), idx["files"]):
        bronze.append({"name": fi["name"], "kind": "statement", "sha256": fi["sha256"], "bytes": fi["bytes"],
                       "period": fi["statement_period"], "saved_to": f"Valuations/{cid}/bronze/{vm}/{fi['name']}"})
    bronze_paths = [copy_into(wb, bronze_dir)] + [copy_into(s_, bronze_dir) for s_ in stmts]
    stem = os.path.splitext(stable_name(wb))[0]
    copy_path = copy_into(wb, os.path.join(od, "onboarding"), f"{stem}__copy.xlsx")
    lp = an["lp_fields"]
    recalc_cells = []
    for f_, r in sorted(lp.items()):
        for c in [r["cell"]] + r.get("aliases", []) + r.get("typed_copies", []):
            if c not in recalc_cells:
                recalc_cells.append(c)
    for w in an["metric_windows"]:
        if w["via"] not in recalc_cells:
            recalc_cells.append(w["via"])
    recalc_cells = [plain_ref(c) for c in recalc_cells[:MAT["max_recalc_cells"]]]
    m = an["model"]
    saved = {c: excel_value(m.v(parse_ref_str(c))) for c in recalc_cells}
    wc = an["workbook_counts"]
    skip = []                             # Excel Online cannot recalculate these in time: Python's checks (L5) cover the LP chain
    if wc["add_in_cells"]:
        skip.append(f"{wc['add_in_cells']} data-provider add-in cell(s)")
    if wc["external_link_formulas"]:
        skip.append(f"{wc['external_link_formulas']} formula(s) reading other workbooks")
    if wc["formulas"] > MAT.get("recalc_max_formulas", 150_000):
        skip.append(f"{wc['formulas']:,} formulas")
    if os.path.getsize(wb) > MAT.get("recalc_max_bytes", 8_000_000):
        skip.append(f"{os.path.getsize(wb) / 1e6:.1f} MB")
    silver = []
    for b_ in m.blocks():
        for row in b_["rows"]:
            silver.append({"line": row["line"], "label": row["label"], "sheet": b_["sheet"], "row": row["row"],
                           "values": {ym_str(i): {"value": m.v(k), "cell": f"{k[0]}!{_c(k)}", "typed": not m.is_formula(k),
                                                  "source_type": "baseline_workbook", "lifecycle": "active"}
                                      for i, k in sorted(row["cells"].items())}})
    profile = {"company_id": cid, "company_name": a.company, "package_version": VERSION,
               "valuation_date": an["valuation_date"], "valuation_month": an["valuation_month"], "method": an["method"],
               "workbook": {"name": stable_name(wb), "sha256": file_sha256(wb), "fingerprint": an["workbook"]["fingerprint"],
                            "sheets": an["workbook"]["sheets"], "calc_mode": an["workbook"]["calc_mode"]},
               "period": an["period"], "linked_workbooks": an["workbook_counts"].get("linked_workbooks", []),
               "readiness": "ONBOARDING_PENDING_RECALC", "approvals": [], "onboarded_on": today()}
    parts = {
        "profile": profile,
        "lp_map": {"fields": lp, "identities": an["identities"], "metric_windows": an["metric_windows"],
                   "hypotheses": an.get("hypotheses", {})},
        "inputs": {"items": an["inputs"], "monthly_lines": an["monthly_lines"], "counts": an["input_counts"],
                   "typed_numbers": an["typed_numbers"], "addins": an["addins"], "externals": an["externals"],
                   "errors": an["errors"], "volatile": an["volatile"], "sheets_reached": an["sheets_reached"]},
        "blocks": {"blocks": an["blocks"]},
        "silver_monthly": {"lines": silver},
        "line_map": {"entries": entries, "stats": stats, "gate": gate_msg, "mode": mode, "statements": idx["files"],
                     "statement_checks": idx["checks"]},
        "liveness": {"checks": an["liveness"], "findings": an["findings"],
                     "recalc": {"status": "PENDING", "copy": os.path.basename(copy_path), "cells": recalc_cells, "saved_values": saved}},
        "decisions": {"items": []},
        "bronze_registry": {"files": bronze},
        "explain": an["explain_cells"],
        "materiality": MAT,
        "judgments": {"answered": answered},
        "build": build,
        "facts": {"items": []},
    }
    parts["assumptions"] = build_assumptions(parts)
    ledger = CF.ledger_append([], "bronze_registered", data={"files": [(b["name"], b["sha256"]) for b in bronze]})
    if answered:
        ledger = CF.ledger_append(ledger, "judgment_answered", by="agent (AI)", data=answered)
    ledger = CF.ledger_append(ledger, "onboarded", by=a.by, data={"valuation_month": vm, "method": an["method"]["variant"],
                                                                   "fields": {f_: r["cell"] for f_, r in lp.items()},
                                                                   "fingerprint": an["workbook"]["fingerprint"]})
    zp = CF.write(os.path.join(od, f"{cid}_company.zip"), parts, ledger)
    print_summary(parts)
    print_build(build)
    for h in an.get("hypotheses", {}).values():
        print(f"- AI-proposed {h['target']}: {h['calculation']} -> " + ("verified by Python" if h["verified"] else
              f"NOT reproduced (Python {fmt(h['python_value']) if h['python_value'] is not None else 'n/a'} vs Excel {fmt(h['excel_value'])}); listed for the analyst"))
    for l in have_need(an, idx, build, bool(a.previous)):
        print(l)
    print(f"PERIOD GATE: {gate_msg}")
    if skip:
        for l in sp_lines(cid, f"bronze/{vm}", bronze_paths):
            print(l)
        reason = "skipped: the workbook has " + ", ".join(skip) + " - Excel Online cannot recalculate it within the tool's time limit; Python's checks (L5) cover the LP numbers"
        print(f"RECALC: skipped ({reason})")
        return cmd_check_recalc(argparse.Namespace(company=cid, unavailable=reason, values=None, out=a.out))
    for l in sp_lines(cid, f"bronze/{vm}", bronze_paths) + sp_lines(cid, "onboarding", [copy_path]):
        print(l)
    print(f"RECALC: Run script from SharePoint library | file: the Id that Create file returned for {os.path.basename(copy_path)} "
          f"| cells: {json.dumps(recalc_cells)}")
    print("RECALC RULES: pass the cells text exactly as printed (do not retype or re-quote it); run the script ONCE - if it fails, "
          "times out or returns an error, run the IF RUN SCRIPT FAILS command at once and never retry")
    print(f"THEN: python scripts/pipeline.py check-recalc --company \"{cid}\" --values - <<'JSON'\n<the Run script result, exactly as returned>\nJSON")
    print(f"IF RUN SCRIPT FAILS: python scripts/pipeline.py check-recalc --company \"{cid}\" --unavailable \"<the error, exactly as returned>\"")
    print("NEXT: carry out the SHAREPOINT lines, then the RECALC line, then the THEN command. No other steps.")
    return 20


def _c(k):
    return f"{col_let(k[2])}{k[1]}"


def plain_ref(c):
    """'Financial Summary'!J59 -> Financial Summary!J59: nothing for the agent to re-quote; the script accepts both."""
    sh, _, addr = c.rpartition("!")
    return (sh[1:-1].replace("''", "'") if sh.startswith("'") and sh.endswith("'") else sh) + "!" + addr


def excel_value(v):
    """saved values in the form the Office Script returns them (dates as Excel serial numbers)."""
    if isinstance(v, (datetime.datetime, datetime.date)):
        d = v.date() if isinstance(v, datetime.datetime) else v
        return (d - datetime.date(1899, 12, 30)).days
    return v


def build_lines(build):
    if not build:
        return []
    P = build["parts"]
    out = [f"BUILD: {len(P)} part(s) traced back from the LP row, in build order | {len(build['gaps'])} gap(s) | "
           f"{sum(1 for p in P if p['needs'])} part(s) need an update or confirmation each quarter"]
    for p in P:
        ins = "; ".join((f"{i['rows_count']} {i['class'].replace('_', ' ')} row(s) ({i['count']} cells)" if i.get("rows_count")
                         else f"{i['count']} {i['class'].replace('_', ' ')} input(s)") + (f" [{', '.join(i['entities'])}]" if i.get("entities") else "")
                        + f" - {i['each_quarter']}" + (f", changed last quarter: {i['last_quarter']['changed']} of {i['last_quarter']['changed'] + i['last_quarter']['unchanged']}"
                                                   if i.get("last_quarter") and (i["last_quarter"]["changed"] + i["last_quarter"]["unchanged"]) else "")
                        for i in p["inputs"]) or "formulas only"
        dep = f" <- {', '.join(p['depends_on'])}" if p["depends_on"] else ""
        roll = (" | named for its quarter" + (f" (was '{p['prior_quarter_sheet']}')" if p.get("prior_quarter_sheet") else "")
                + ": the refresh adds the next quarter's copy") if p["per_quarter_sheet"] else ""
        out.append(f"- {p['id']} {p['sheet']} [{p['role']}]{dep} | {ins}{roll}")
    for f, chain in build["trace"].items():
        out.append(f"TRACE: {f.replace('_', ' ')} ({', '.join(chain[0])})" + "".join(f" <- {', '.join(c)}" for c in chain[1:]))
    L = build.get("learned")
    if L:
        bc = ", ".join(f"{c.replace('_', ' ')} {v['changed']}/{v['changed'] + v['unchanged']} changed" for c, v in sorted(L["by_class"].items()))
        out.append(f"LEARNED: from {L['prior_workbook']}: " + (f"sheets rolled per quarter: " + "; ".join(f"'{r['previous']}' -> '{r['current']}'" for r in L["rolled_sheets"]) + " | " if L["rolled_sheets"] else "")
                   + (f"inputs: {bc}" if bc else "no inputs matched") + (f" | metric windows moved {L['window_shift_months']} month(s)" if L.get("window_shift_months") is not None else ""))
    for g in build["gaps"][:10]:
        out.append(f"- GAP {g['part']} {g['cell']} '{g['label']}': {g['why']}")
    return out


def print_build(build):
    for l in build_lines(build):
        print(l)


def print_summary(parts):
    prof, lp, inp, lm, live, asm = (parts[k] for k in ("profile", "lp_map", "inputs", "line_map", "liveness", "assumptions"))
    vd = prof.get("valuation_date") or {}
    print(f"ONBOARD: {prof['company_name']} | company_id {prof['company_id']} | valuation date {vd.get('value')} "
          f"(from {vd.get('basis')}) | package {VERSION}")
    meth = prof["method"]
    print(f"METHOD: {meth['variant']} | metric basis {meth.get('metric_basis') or 'unknown'}"
          + (f" | weights revenue {meth['weights']['revenue']} / EBITDA {meth['weights']['ebitda']}" if meth.get("weights") else "")
          + (f" | FX {meth['fx_rule']}" if meth.get("fx_rule") else "") + f" | ownership {meth.get('ownership_rule') or 'n/a'}")
    F = lp["fields"]
    miss = [f for f in ("enterprise_value", "equity_value", "investor_value") if f not in F]
    print(f"LP FIELDS: {len(F)} found ({sum(1 for r in F.values() if r['status'] == 'verified')} proven by identities)"
          + (f" | missing: {', '.join(miss)}" if miss else ""))
    for f in ("enterprise_value", "equity_value", "investor_value", "ebitda_adjusted", "revenue_ttm", "multiple_ebitda", "moic"):
        if f in F:
            r = F[f]
            print(f"- {f.replace('_', ' ')}: {r['cell']} = {fmt(r['value'])} [{r['status']}]")
    print("LIVENESS: " + " | ".join(f"{k} {v['result']}" for k, v in sorted(live["checks"].items())))
    c = inp["counts"]
    print(f"INPUTS: {c.get('monthly_lines', 0)} monthly rows | {c.get('date', 0)} dates | {c.get('balance', 0)} balances | "
          f"{c.get('fx', 0)} FX | {c.get('parameter', 0)} parameters | {c.get('fund_record', 0)} fund records | "
          f"{c.get('pasted_calculation', 0)} pasted calculations | {c.get('add_in', 0)} add-in cells | "
          f"{inp['typed_numbers']['untouched']} typed cells not upstream (never written)")
    st = lm.get("stats", {})
    print("LINE MAP: " + (" | ".join(f"{v} {k.replace('_', ' ')}" for k, v in sorted(st.items())) or "no monthly rows"))
    rv = [i for i in asm["items"] if i["review"]]
    print(f"REVIEW: {len(rv)} item(s) for the analyst; {len(asm['items']) - len(rv)} accepted as a set on approval")
    for i in rv[:MAT["max_review_items_printed"]]:
        print(f"- {i['id']} {i['text']}" + (f" -> proposed {i['proposed']}" if i.get("proposed") and i["proposed"] not in i["text"] else ""))
    if len(rv) > MAT["max_review_items_printed"]:
        print(f"- ... {len(rv) - MAT['max_review_items_printed']} more in the onboarding report")


# ------------------------------------------------------------------------------------------------ check-recalc
def parse_recalc(text):
    obj = text
    for _ in range(4):
        if isinstance(obj, str):
            try:
                obj = json.loads(obj)
            except json.JSONDecodeError:
                return None
        if isinstance(obj, dict) and ("values" in obj or "guard" in obj):
            return obj
        if isinstance(obj, dict):
            obj = obj.get("result", obj.get("body", obj.get("outputs")))
        else:
            return None
    return None


def cmd_check_recalc(a):
    cid = company_slug(a.company)
    zp, parts, ledger = company_zip(a, cid)
    live = parts["liveness"]
    rc = live["recalc"]
    if a.unavailable and a.unavailable.startswith("skipped:"):
        live["checks"]["L4"]["result"] = "SKIPPED"
        rc.update(status="SKIPPED", reason=a.unavailable[:500])
    elif a.unavailable:
        live["checks"]["L4"]["result"] = "NOT RUN"
        live["findings"].append({"check": "L4", "kind": "recalc_not_run", "cell": None, "severity": "warning",
                                 "text": f"the Excel recalculation could not run ({a.unavailable[:160]}); saved values were checked by Python only"})
        rc.update(status="NOT RUN", reason=a.unavailable[:500])
    else:
        raw = sys.stdin.read() if a.values == "-" else a.values
        res = parse_recalc(raw)
        if res is None:
            print("PIPELINE ERROR: the Run script result could not be read (expected the JSON the script returns). "
                  "Pass the result exactly as returned.")
            return 1
        if res.get("guard") == "refused":
            live["checks"]["L4"]["result"] = "FAIL"
            live["findings"].append({"check": "L4", "kind": "recalc_refused", "cell": None,
                                     "text": f"the Office Script refused to run on '{res.get('workbook')}': {res.get('reason')}"})
            rc.update(status="REFUSED")
        else:
            vals, errs = res.get("values", {}), res.get("errors", {})
            diffs, missing = [], []
            for c in rc["cells"]:
                s, g = rc["saved_values"].get(c), vals.get(c)
                if c in errs:
                    diffs.append((c, s, errs[c]))
                elif g is None and c not in vals:
                    missing.append(c)
                elif is_num(s) and is_num(g):
                    if abs(s - g) > max(1e-6, MAT["recalc_relative_tolerance"] * max(abs(s), abs(g))):
                        diffs.append((c, s, g))
                elif str(s) != str(g) and not (s in (None, "") and g in (None, "")):
                    diffs.append((c, s, g))
            for c, s, g in diffs:
                live["findings"].append({"check": "L4", "kind": "recalc_difference", "cell": c,
                                         "text": f"{c}: saved {fmt(s)} but Excel recalculates {fmt(g)}"})
            for c in missing:
                live["findings"].append({"check": "L4", "kind": "recalc_missing", "cell": c, "text": f"{c}: not returned by the script"})
            secs = res.get("seconds")
            if is_num(secs) and secs > MAT["recalc_seconds_risk"]:
                live["findings"].append({"check": "L4", "kind": "recalc_slow", "cell": None,
                                         "text": f"the recalculation took {secs:.0f} s (limit 120 s; risk above {MAT['recalc_seconds_risk']} s)"})
            n_err = res.get("error_count_total", 0) or 0
            live["checks"]["L4"]["result"] = (f"PASS ({len(rc['cells'])} cells)" if not diffs and not missing
                                              else f"FAIL ({len(diffs)} different, {len(missing)} missing)")
            rc.update(status="DONE", seconds=secs, differences=len(diffs), workbook_errors=n_err)
            if n_err:
                live["findings"].append({"check": "L4", "kind": "workbook_errors", "cell": None,
                                         "text": f"after recalculation the workbook shows {n_err} error cell(s) (sample: "
                                                 + ", ".join(f"{x.get('cell')} {x.get('value')}" for x in (res.get('error_sample') or [])[:5]) + ")"})
    parts["profile"]["readiness"] = "ONBOARDED_PENDING_APPROVAL"
    parts["assumptions"] = build_assumptions(parts)
    ledger = CF.ledger_append(ledger, "recalc_checked", data={"L4": live["checks"]["L4"]["result"]})
    od = out_dir(a)
    zp = CF.write(os.path.join(od, os.path.basename(zp)), parts, ledger)
    rp = os.path.join(od, "onboarding", f"{cid}_onboarding_{parts['profile']['valuation_month']}.md")
    os.makedirs(os.path.dirname(rp), exist_ok=True)
    open(rp, "w", encoding="utf-8").write(report_md(parts))
    print_summary(parts)
    print_build(parts.get("build"))
    for l in sp_lines(cid, "company", [zp]) + sp_lines(cid, "onboarding", [rp], folder=False):
        print(l)
    print(f"READINESS: {parts['profile']['readiness']}")
    print("NEXT: carry out the SHAREPOINT lines, then post this report from ONBOARD to READINESS unchanged and offer the "
          "onboarding report file. Ask the analyst to review the REVIEW items and reply \"approve as <name>\" "
          "(with any corrections). Stop.")
    return 0


# ------------------------------------------------------------------------------------------------ approve
def cmd_approve(a):
    cid = company_slug(a.company)
    zp, parts, ledger = company_zip(a, cid)
    if not a.by or not a.by.strip():
        print("STOPPED: an approval needs the approver's name. Ask the user for it and stop.")
        return 3
    changes = parse_answers(a.changes) or {}
    ids = {i["id"]: i for i in parts["assumptions"]["items"]}
    unknown = [k for k in changes if k not in ids]
    if unknown:
        print(f"PIPELINE ERROR: unknown review item(s): {', '.join(unknown)}. Use the IDs printed in REVIEW.")
        return 1
    for k, v in sorted(changes.items()):
        parts["decisions"]["items"].append({"item": k, "subject": ids[k]["subject"], "value": v, "by": a.by.strip(),
                                            "on": today(), "said": a.said or ""})
        ledger = CF.ledger_append(ledger, "decision", by=a.by.strip(), data={"item": k, "value": v})
    mh = CF.method_hash(parts)
    appr = {"by": a.by.strip(), "on": today(), "method_hash": mh, "review_items": parts["assumptions"]["review_count"],
            "liveness": {k: v["result"] for k, v in parts["liveness"]["checks"].items()}, "said": a.said or ""}
    parts["profile"]["approvals"].append(appr)
    parts["profile"]["readiness"] = "ONBOARDED"
    parts["profile"]["method_hash"] = mh
    ledger = CF.ledger_append(ledger, "approval", by=a.by.strip(), data=appr)
    od = out_dir(a)
    zp = CF.write(os.path.join(od, os.path.basename(zp)), parts, ledger)
    print(f"APPROVED: onboarding of {parts['profile']['company_name']} by {a.by.strip()} on {today()} | method {mh} | "
          f"{len(changes)} correction(s) recorded")
    for l in sp_lines(cid, "company", [zp], folder=False):
        print(l)
    print("READINESS: ONBOARDED")
    print("NEXT: carry out the SHAREPOINT line, then post the APPROVED line. Stop.")
    return 0


# ------------------------------------------------------------------------------------------------ explain
def cmd_explain(a):
    cid = company_slug(a.company)
    _, parts, _ = company_zip(a, cid)
    item = a.item.strip()
    ex = parts.get("explain", {})
    asm = {i["id"]: i for i in parts["assumptions"]["items"]}
    cell = None
    if item in asm:
        i = asm[item]
        print(f"EXPLAIN: {item} | {i['group']} | confidence {i['confidence']} | basis {i['basis']} | action {i['action']}")
        print(f"- {i['text']}")
        if i.get("proposed"):
            print(f"- proposed: {i['proposed']}")
        cell = i.get("cell")
        if i["group"] == "line_map":
            for e in parts["line_map"]["entries"]:
                if e["line"] == i["subject"]:
                    print(f"- workbook months {e.get('workbook_months')} | overlap {e.get('overlap_months')}")
                    for p in e.get("proposals", []):
                        print(f"- proposal: statement '{p['label']}' (sheet {p['sheet']}, title similarity {p['similarity']})")
                    sl = next((s for s in parts["silver_monthly"]["lines"] if s["line"] == e["line"]), None)
                    if sl:
                        last = sorted(sl["values"].items())[-3:]
                        print("- last months in the workbook: " + "; ".join(f"{mth} {fmt(v['value'])} ({v['cell']})" for mth, v in last))
    elif item in parts["lp_map"]["fields"]:
        r = parts["lp_map"]["fields"][item]
        print(f"EXPLAIN: {item} | {r['cell']} | status {r['status']} | basis {r['basis']}")
        bld = parts.get("build") or {}
        if item in bld.get("trace", {}):
            names = bld.get("part_names", {})
            print("- built from: " + " <- ".join(", ".join(f"{x} {names.get(x, '')}" for x in c) for c in bld["trace"][item]))
        for alt in r.get("alternatives", []):
            print(f"- alternative: {alt['cell']} '{alt['label']}' = {fmt(alt['value'])}")
        cell = r["cell"]
    else:
        cell = item
        print(f"EXPLAIN: {item}")
    d = ex.get(cell) if cell else None
    if d:
        print(f"- cell {d['cell']} | label '{d['label']}' | row label '{d['row_label']}' | column header '{d['column_header']}'")
        print(f"- value {fmt(d['value'])} | formula {d['formula'] or '(typed)'}")
        for p in d["precedents"]:
            print(f"  <- {p['cell']} '{p['label']}' = {fmt(p['value'])}" + (f" | {p['formula']}" if p["formula"] else ""))
        if d["more_precedents"]:
            print(f"  <- ... {d['more_precedents']} more")
    elif cell:
        print("- no stored detail for this cell (it is not on the LP chain)")
    print("NEXT: post the EXPLAIN lines unchanged. Stop.")
    return 0


# ------------------------------------------------------------------------------------------------ selftest
def cmd_selftest(a):
    p = subprocess.run([sys.executable, os.path.join(PKG, "tests", "run_selftest.py")] + (["--report"] if a.report else []),
                       capture_output=True, text=True)
    sys.stdout.write(p.stdout + p.stderr)
    return p.returncode


def main(argv=None):
    ap = argparse.ArgumentParser(prog="pipeline.py")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p):
        p.add_argument("--out", default=None)
        return p
    c = common(sub.add_parser("census"))
    c.add_argument("--workbooks", nargs="+", required=True)
    c.add_argument("--period-end", default=None)
    ad = common(sub.add_parser("add"))
    ad.add_argument("--files", nargs="*", default=[])
    ad.add_argument("--company", default=None)
    ad.add_argument("--by", default=None)
    ad.add_argument("--fact", default=None)
    ad.add_argument("--value", default=None)
    ad.add_argument("--target", default=None)
    ad.add_argument("--said", default=None)
    rf = common(sub.add_parser("reference"))
    rf.add_argument("--feature", default=None)
    rf.add_argument("--workbooks", nargs="*", default=[])
    ga = sub.add_parser("gather")
    ga.add_argument("--company", required=True)
    ga.add_argument("--quarter", required=True)
    ga.add_argument("--files", nargs="*", default=None)
    stp = common(sub.add_parser("status"))
    stp.add_argument("--company", required=True)
    c1 = sub.add_parser("census-one")
    c1.add_argument("--workbook", required=True)
    c1.add_argument("--json-out", required=True)
    c1.add_argument("--period-end", default=None)
    o = common(sub.add_parser("onboard"))
    o.add_argument("--workbook", required=True)
    o.add_argument("--statements", nargs="*", default=[])
    o.add_argument("--company", required=True)
    o.add_argument("--period-end", default=None)
    o.add_argument("--answers", default=None)
    o.add_argument("--previous", default=None)
    o.add_argument("--by", default=None)
    r = common(sub.add_parser("check-recalc"))
    r.add_argument("--company", required=True)
    g = r.add_mutually_exclusive_group(required=True)
    g.add_argument("--values")
    g.add_argument("--unavailable")
    p = common(sub.add_parser("approve"))
    p.add_argument("--company", required=True)
    p.add_argument("--by", required=True)
    p.add_argument("--changes", default=None)
    p.add_argument("--said", default=None)
    e = common(sub.add_parser("explain"))
    e.add_argument("item")
    e.add_argument("--company", required=True)
    s = sub.add_parser("selftest")
    s.add_argument("--report", action="store_true")
    sub.add_parser("version")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "version":
            print(f"VERSION: valuation-pipeline {VERSION}")
            return 0
        return {"census": cmd_census, "census-one": cmd_census_one, "gather": cmd_gather, "add": cmd_add, "reference": cmd_reference, "status": cmd_status,
                "onboard": cmd_onboard, "check-recalc": cmd_check_recalc, "approve": cmd_approve,
                "explain": cmd_explain, "selftest": cmd_selftest}[a.cmd](a)
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else 1
    except Exception as e:
        import traceback
        print(f"PIPELINE ERROR: {type(e).__name__}: {e}")
        if os.environ.get("VALUATION_DEBUG"):
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
