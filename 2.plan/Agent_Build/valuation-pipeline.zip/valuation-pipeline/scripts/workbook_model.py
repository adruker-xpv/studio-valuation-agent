# workbook_model.py (build 11) - reads a workbook once (formulas and saved values) and answers questions about it:
# labels, precedents, everything upstream of a cell, add-in and external formulas, monthly blocks.
# Never modifies the workbook.
import bisect, datetime, re, hashlib, zipfile
from collections import defaultdict, deque
from openpyxl import load_workbook
from openpyxl.utils.formulas import FORMULAE
from wbutil import (parse_refs, func_names, name_tokens, is_external, is_num, is_error_value, parse_period,
                    ym_to_i, ref_str, col_let, REF, STR_LIT, col_idx)

BUILTIN = {f.upper() for f in FORMULAE} | {
    "IFERROR", "IFNA", "SUMIFS", "COUNTIFS", "AVERAGEIFS", "XLOOKUP", "XMATCH", "FILTER", "SORT", "UNIQUE", "SEQUENCE",
    "LET", "LAMBDA", "TEXTJOIN", "CONCAT", "IFS", "SWITCH", "MAXIFS", "MINIFS", "EOMONTH", "EDATE", "NETWORKDAYS",
    "XIRR", "XNPV", "AGGREGATE", "FORECAST", "STDEV", "TRANSPOSE", "CHOOSE", "OFFSET", "INDIRECT"}
VOLATILE = {"OFFSET", "INDIRECT", "TODAY", "NOW", "RAND", "RANDBETWEEN"}
MAX_UPSTREAM = 250_000
MAX_KEEP_ROWS, MAX_KEEP_COLS = 1_048_576, 16_384


def addin_function(name):
    n = name.upper()
    if n.startswith(("_XLL.", "_XLDUDF")):
        return True
    if n.startswith(("_XLFN.", "_XLWS.", "_XLPM.", "_XLETA.")):
        return False
    return n not in BUILTIN


def _rel_key(formula, row, col):
    """formula with references made relative to its own cell (R1C1 style): copies of one formula look the same."""
    def one(ca, c, ra, r):
        ci, ri = col_idx(c), int(r)
        return (f"R{ri}" if ra else f"R[{ri - row}]") + (f"C{ci}" if ca else f"C[{ci - col}]")

    def sub(m):
        s = m.group(1) or m.group(2) or ""
        s = s + "!" if s else ""
        s += one(m.group(3), m.group(4), m.group(5), m.group(6))
        if m.group(8):
            s += ":" + one(m.group(7), m.group(8), m.group(9), m.group(10))
        return s
    return REF.sub(sub, STR_LIT.sub('""', formula))


class CellView:
    """read-only mapping key -> {"f": formula or None, "v": saved value}, built on two compact dicts."""
    def __init__(self, vals, forms):
        self._v, self._f = vals, forms

    def __contains__(self, k):
        return k in self._v or k in self._f

    def __getitem__(self, k):
        if k not in self._v and k not in self._f:
            raise KeyError(k)
        return {"f": self._f.get(k), "v": self._v.get(k)}

    def get(self, k, default=None):
        return self[k] if k in self else default

    def __iter__(self):
        yield from self._v
        for k in self._f:
            if k not in self._v:
                yield k

    def __len__(self):
        return len(self._v) + sum(1 for k in self._f if k not in self._v)

    def items(self):
        for k in self:
            yield k, {"f": self._f.get(k), "v": self._v.get(k)}


def _zip_facts(path):
    """calculation mode, external link parts and merged ranges, read straight from the file (streaming-safe)."""
    calc, ext, merged = "auto", 0, {}
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        ext = sum(1 for n in names if re.match(r"xl/externalLinks/externalLink\d+\.xml$", n))
        linked = []
        for n in sorted(names):
            if re.match(r"xl/externalLinks/_rels/externalLink\d+\.xml\.rels$", n):
                for t in re.findall(r'Target="([^"]+)"', z.read(n).decode("utf-8", "ignore")):
                    linked.append(re.split(r"[/\\]", t.replace("%20", " "))[-1])
        self_linked = linked
        wbx = z.read("xl/workbook.xml").decode("utf-8", "ignore")
        m = re.search(r'<calcPr[^>]*\bcalcMode="([^"]+)"', wbx)
        if m:
            calc = m.group(1)
        rels = z.read("xl/_rels/workbook.xml.rels").decode("utf-8", "ignore") if "xl/_rels/workbook.xml.rels" in names else ""
        target = {mm.group(1): mm.group(2) for mm in re.finditer(r'<Relationship[^>]*Id="([^"]+)"[^>]*Target="([^"]+)"', rels)}
        target.update({mm.group(2): mm.group(1) for mm in re.finditer(r'<Relationship[^>]*Target="([^"]+)"[^>]*Id="([^"]+)"', rels)})
        for sm in re.finditer(r'<sheet\b[^>]*name="([^"]+)"[^>]*r:id="([^"]+)"', wbx):
            sheet = sm.group(1).replace("&amp;", "&").replace("&apos;", "'").replace("&quot;", '"').replace("&lt;", "<").replace("&gt;", ">")
            t = target.get(sm.group(2), "")
            xml = "xl/" + t.lstrip("/").replace("xl/", "", 1) if t else None
            if not xml or xml not in names:
                continue
            refs, tail = [], ""
            with z.open(xml) as fh:                                  # chunked scan: never loads a big sheet at once
                while True:
                    chunk = fh.read(1 << 20)
                    if not chunk:
                        break
                    text = tail + chunk.decode("utf-8", "ignore")
                    refs += re.findall(r'<mergeCell ref="([A-Z]+\d+:[A-Z]+\d+)"', text)
                    tail = text[-200:]
            out = set()
            for r_ in refs:
                a, b = r_.split(":")
                ma, mb = re.match(r"([A-Z]+)(\d+)", a), re.match(r"([A-Z]+)(\d+)", b)
                out.add((int(ma.group(2)), col_idx(ma.group(1)), int(mb.group(2)), col_idx(mb.group(1))))
            merged[sheet] = sorted(out)
    return calc, ext, merged, self_linked


class Model:
    def __init__(self, path):
        """Streams the workbook twice (formulas, then saved values) and keeps only what can matter: every cell of a
        sheet that has formulas, and on formula-free sheets only the block (from A1) that formulas or names reach.
        Data-dump sheets nothing refers to are counted, not stored."""
        self.path = path
        wbf = load_workbook(path, data_only=False, read_only=True, keep_links=False)
        self.sheets = list(wbf.sheetnames)
        self.sheet_lc = {s.lower(): s for s in self.sheets}
        forms, has_f = {}, set()
        for ws in wbf.worksheets:
            sh = ws.title
            for row in ws.iter_rows():
                for c in row:
                    v = c.value
                    if v is None or not getattr(c, "row", None):
                        continue
                    f = None
                    if hasattr(v, "text") and not isinstance(v, str):          # ArrayFormula / DataTableFormula
                        f = "=" + str(getattr(v, "text", "") or "").lstrip("=")
                    elif isinstance(v, str) and v.startswith("=") and len(v) > 1:
                        f = v
                    if f:
                        forms[(sh, c.row, c.column)] = f
                        has_f.add(sh)
        self.names = self._defined_names(wbf)
        wbf.close()
        reach = {}
        def grow(sh, r2, c2):
            real = self.sheet_lc.get(sh.lower())
            if real and real not in has_f:
                rr, cc = reach.get(real, (0, 0))
                reach[real] = (max(rr, min(r2, MAX_KEEP_ROWS)), max(cc, min(c2, MAX_KEEP_COLS)))
        for k, f in forms.items():
            for (sh, r1, c1, r2, c2) in parse_refs(f, k[0]):
                grow(sh, r2, c2)
        for boxes in self.names.values():
            for (sh, r1, c1, r2, c2) in boxes:
                grow(sh, r2, c2)
        wbv = load_workbook(path, data_only=True, read_only=True, keep_links=False)
        vals, skipped = {}, {}
        for ws in wbv.worksheets:
            sh = ws.title
            keep_all = sh in has_f
            lim = reach.get(sh)
            n_skip = 0
            for row in ws.iter_rows():
                for c in row:
                    v = c.value
                    if v is None or not getattr(c, "row", None):
                        continue
                    if keep_all or (lim and c.row <= lim[0] + 2 and c.column <= lim[1]):
                        vals[(sh, c.row, c.column)] = v
                    else:
                        n_skip += 1
            if n_skip:
                skipped[sh] = n_skip
        wbv.close()
        self._v, self._f = vals, forms
        self.cells = CellView(vals, forms)
        self.skipped_cells = skipped
        self.calc_mode, self.external_link_parts, self._merged, self.linked_workbooks = _zip_facts(path)
        self._index()
        self._prec = {}
        self._blocks = None

    # ----------------------------------------------------------------- indexes
    def _defined_names(self, wb):
        out = {}

        def add(name, dn):
            try:
                dests = list(dn.destinations)
            except Exception:
                return
            keys = set()
            for sh, coord in dests:
                if sh not in self.sheets:
                    continue
                coord = coord.replace("$", "")
                m = re.fullmatch(r"([A-Z]{1,3})(\d+)(?::([A-Z]{1,3})(\d+))?", coord)
                if not m:
                    continue
                c1, r1 = col_idx(m.group(1)), int(m.group(2))
                c2, r2 = (col_idx(m.group(3)), int(m.group(4))) if m.group(3) else (c1, r1)
                keys.add((sh, min(r1, r2), min(c1, c2), max(r1, r2), max(c1, c2)))
            if keys:
                out[name.upper()] = keys
        try:
            for name, dn in wb.defined_names.items():
                add(name, dn)
        except Exception:
            pass
        for ws in wb.worksheets:
            try:
                for name, dn in ws.defined_names.items():
                    add(name, dn)
            except Exception:
                pass
        return out

    def _index(self):
        self.rows = defaultdict(lambda: defaultdict(list))
        self.text_row = defaultdict(lambda: defaultdict(list))      # sheet -> row -> sorted cols holding label text
        self.head_col = defaultdict(lambda: defaultdict(list))      # sheet -> col -> sorted rows holding header text/date
        texts = {}
        for (sh, r, c) in self.cells:
            self.rows[sh][r].append(c)
        for k, v in self._v.items():
            if isinstance(v, str) and v.strip() and not is_error_value(v):
                texts[k] = v.strip()
        for sh, ranges in self._merged.items():
            for (r1, c1, r2, c2) in ranges:
                t = texts.get((sh, r1, c1))
                if t:
                    for r in range(r1, r2 + 1):
                        for c in range(c1, c2 + 1):
                            texts.setdefault((sh, r, c), t)
        self.texts = texts
        for (sh, r, c), t in texts.items():
            if not parse_period(t):
                self.text_row[sh][r].append(c)
            self.head_col[sh][c].append(r)
        for (sh, r, c), v in self._v.items():
            if isinstance(v, (datetime.datetime, datetime.date)):
                self.head_col[sh][c].append(r)
        for d in (self.rows, self.text_row, self.head_col):
            for sh in d:
                for k in d[sh]:
                    d[sh][k] = sorted(set(d[sh][k]))
        self.row_keys = {sh: sorted(rs) for sh, rs in self.rows.items()}

    # ----------------------------------------------------------------- basic accessors
    def f(self, key):
        return self._f.get(key)

    def v(self, key):
        return self._v.get(key)

    def is_formula(self, key):
        return bool(self.f(key))

    def is_typed_number(self, key):
        return key not in self._f and is_num(self._v.get(key))

    def is_date(self, key):
        return isinstance(self.v(key), (datetime.datetime, datetime.date))

    def row_label(self, key):
        sh, r, c = key
        cols = self.text_row[sh].get(r, [])
        i = bisect.bisect_left(cols, c)
        return self.texts[(sh, r, cols[i - 1])][:80] if i else ""

    def col_header(self, key, max_up=40):
        sh, r, c = key
        rows = self.head_col[sh].get(c, [])
        j = bisect.bisect_left(rows, r)
        if not j or r - rows[j - 1] > max_up:
            return ""
        hk = (sh, rows[j - 1], c)
        if hk in self.texts:
            return self.texts[hk][:80]
        v = self.v(hk)
        return v.strftime("%Y-%m-%d") if isinstance(v, (datetime.datetime, datetime.date)) else ""

    def label(self, key):
        return self.row_label(key) or self.col_header(key)

    def cells_in(self, sh, r1, c1, r2, c2):
        out = []
        rows = self.row_keys.get(sh, [])
        for r in rows[bisect.bisect_left(rows, r1):bisect.bisect_right(rows, r2)]:
            cols = self.rows[sh][r]
            for c in cols[bisect.bisect_left(cols, c1):bisect.bisect_right(cols, c2)]:
                out.append((sh, r, c))
        return out

    # ----------------------------------------------------------------- dependency graph
    def precedents(self, key):
        if key in self._prec:
            return self._prec[key]
        f = self.f(key)
        out = set()
        if f:
            for (sh, r1, c1, r2, c2) in parse_refs(f, key[0]):
                real = self.sheet_lc.get(sh.lower())
                if not real:
                    continue
                if (r1, c1) == (r2, c2):
                    if (real, r1, c1) in self.cells:
                        out.add((real, r1, c1))
                else:
                    out.update(self.cells_in(real, r1, c1, r2, c2))
            for tok in name_tokens(f):
                for (sh, r1, c1, r2, c2) in self.names.get(tok.upper(), ()):
                    out.update(self.cells_in(sh, r1, c1, r2, c2))
        out.discard(key)
        self._prec[key] = out
        return out

    def upstream(self, keys):
        seen, q = set(), deque(k for k in keys if k in self.cells)
        while q and len(seen) < MAX_UPSTREAM:
            k = q.popleft()
            if k in seen:
                continue
            seen.add(k)
            for p in self.precedents(k):
                if p not in seen:
                    q.append(p)
        return seen

    def addin_cells(self, keys=None):
        out = []
        for k in (keys if keys is not None else self.cells):
            f = self.f(k)
            if f:
                names = sorted({n for n in func_names(f) if addin_function(n)})
                if names:
                    out.append((k, names))
        return out

    def external_cells(self, keys=None):
        return [k for k in (keys if keys is not None else self.cells) if self.f(k) and is_external(self.f(k))]

    def volatile_cells(self, keys=None):
        return [k for k in (keys if keys is not None else self.cells) if self.f(k) and VOLATILE & set(func_names(self.f(k)))]

    def error_cells(self, keys=None):
        return [k for k in (keys if keys is not None else self.cells) if is_error_value(self.v(k))]

    def fingerprint(self):
        src = "|".join(self.sheets) + "||" + "|".join(sorted(
            f"{k[0]}!{_rel_key(f, k[1], k[2])}@{k[1]},{k[2]}" for k, f in self._f.items()))
        return hashlib.sha256(src.encode("utf-8")).hexdigest()[:16]

    # ----------------------------------------------------------------- monthly blocks
    def _period_of(self, key):
        """-> (month index, 'm' or 'q') for a header cell, else None."""
        v = self.v(key)
        if isinstance(v, (datetime.datetime, datetime.date)):
            return ym_to_i((v.year, v.month)), "d"
        if isinstance(v, str):
            s = v.strip().lower()
            p = parse_period(s)
            if not p:
                return None
            if re.match(r"^(q[1-4]|(fy)?\d{2,4}\s*-?\s*q[1-4])", s):
                return ym_to_i(p), "q"
            if re.search(r"[a-z]{3}|\d{4}-\d{2}|\d{1,2}/\d{4}", s) and not s.startswith("fy"):
                return ym_to_i(p), "m"
        return None

    def blocks(self):
        """Rows of period headers - 6+ consecutive months, or 4+ consecutive quarters - with numeric rows below.
        Headers may be typed dates, formula dates or text ('Jun-26', 'Q2-26'). A non-period column of up to 2 cells
        (e.g. a year total) may sit between periods."""
        if self._blocks is not None:
            return self._blocks
        found = []
        header_rows = set()
        for sh in self.sheets:
            for r in self.row_keys.get(sh, []):
                ps = [(c, self._period_of((sh, r, c))) for c in self.rows[sh][r]]
                ps = [(c, p[0], p[1]) for c, p in ps if p is not None]
                run, step = [], None
                for c, m, kind in ps + [(None, None, None)]:
                    ok, nstep = False, None
                    if run and c is not None and c - run[-1][0] <= 3:
                        d, prev = m - run[-1][1], run[-1][2]
                        if step is None:
                            if kind == "q" and prev == "q" and d == 3:
                                ok, nstep = True, 3
                            elif kind != "q" and prev != "q" and d in (1, 3):
                                ok, nstep = True, d
                        elif d == step and (step == 3 or kind != "q"):
                            ok, nstep = True, step
                    if ok:
                        step = nstep
                        run.append((c, m, kind))
                        continue
                    if run and step and ((step == 1 and len(run) >= 6) or (step == 3 and len(run) >= 4)):
                        found.append((sh, r, [(cc, mm) for cc, mm, _ in run], step))
                        header_rows.add((sh, r))
                    run, step = ([(c, m, kind)] if c is not None else []), None
        blocks = []
        for sh, hr, run, step in found:
            first_col = run[0][0]
            rows, empty = [], 0
            later_headers = sorted(r for (s, r) in header_rows if s == sh and r > hr)
            stop = later_headers[0] if later_headers else hr + 400
            occ = defaultdict(int)
            for r in range(hr + 1, min(stop, hr + 400)):
                cells = {m: (sh, r, c) for c, m in run if is_num(self.v((sh, r, c)))}
                if not cells:
                    empty += 1
                    if empty >= 4:
                        break
                    continue
                empty = 0
                lab = self.row_label((sh, r, first_col))
                if not lab:
                    continue
                occ[lab.lower()] += 1
                n = occ[lab.lower()]
                rows.append({"row": r, "label": lab, "line": f"{sh}|{lab}" + (f" #{n}" if n > 1 else ""),
                             "cells": cells, "step": step,
                             "typed": sum(1 for k in cells.values() if not self.is_formula(k)),
                             "formula": sum(1 for k in cells.values() if self.is_formula(k))})
            if rows:
                blocks.append({"sheet": sh, "header_row": hr, "months": [m for _, m in run], "cols": [c for c, _ in run],
                               "rows": rows, "step": step})
        self._blocks = blocks
        self.block_cell = {}
        for b in blocks:
            for row in b["rows"]:
                for m, k in row["cells"].items():
                    self.block_cell[k] = (row["line"], m, b["step"])
        return blocks

    def block_of_cell(self, key):
        self.blocks()
        return self.block_cell.get(key)

    def describe(self, key, n_prec=12):
        """everything a reviewer needs about one cell, without opening the workbook."""
        prec = sorted(self.precedents(key))
        return {"cell": ref_str(key), "label": self.label(key), "row_label": self.row_label(key),
                "column_header": self.col_header(key), "value": self.v(key), "formula": self.f(key),
                "precedents": [{"cell": ref_str(p), "label": self.label(p), "value": self.v(p),
                                "formula": self.f(p)} for p in prec[:n_prec]],
                "more_precedents": max(0, len(prec) - n_prec)}
