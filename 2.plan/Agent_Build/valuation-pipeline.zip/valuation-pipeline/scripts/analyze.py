# analyze.py (build 11) - understands one approved valuation workbook, working back from the LP row.
#   1. find each LP field's cell by label (references/lp_fields.json)
#   2. prove the mapping with Python's own valuation identities (the "Python chain"):
#        EV = multiple x metric (or blended weights), equity = EV + cash - debt (+ bridge items),
#        investor value = equity x ownership (or / FX), else a waterfall (Excel only, bounds checked),
#        MOIC = (value + proceeds) / invested capital; TTM metric windows end at the valuation month
#   3. classify every typed input upstream of the LP row: monthly data, date, balance, FX, parameter, pasted calculation
#   4. liveness checks L1-L5 (L4, the Excel recalculation of a copy, is completed later by check-recalc)
import datetime, os, re
from collections import defaultdict
from wbutil import (ref_data, label_score, similarity, norm_label, is_num, ref_str, range_str, parse_refs,
                    ym_to_i, ym_str, parse_date_text, short_id, col_idx, parse_ref_str, is_external)
from workbook_model import Model
import formula_eval as FE

FIELDS = ref_data("lp_fields.json")
WORDS = ref_data("input_words.json")
RULES = ref_data("build_rules.json")
ROLE_WORDS = {r["role"]: r for r in RULES["roles"]}
MAT = ref_data("materiality_defaults.json")
OUTPUT_FIELDS = ("enterprise_value", "equity_value", "investor_value", "investor_value_local", "ebitda_adjusted",
                 "ebitda_reported", "revenue_ttm", "moic")
GOOD_SHEETS = re.compile(r"valuation|summary|lp|output|fmv|fair value|dashboard|report", re.I)
DATA_SHEETS = re.compile(r"monthly|statement|^is$|^bs$|income|balance|input|data|raw|comp", re.I)


def close(a, b, rel=None):
    rel = MAT["identity_relative_tolerance"] if rel is None else rel
    return is_num(a) and is_num(b) and abs(a - b) <= max(1e-6, rel * max(abs(a), abs(b)))


def frac(v):
    return v / 100.0 if is_num(v) and v > 1.0 else v


def words_hit(label, words):
    L = f" {norm_label(label)} "
    return any(f" {norm_label(w)} " in L for w in words)


# ---------------------------------------------------------------------------------------------- candidates
def find_candidates(m):
    """field -> ranked candidate cells. One label score per unique label (fast on large workbooks)."""
    m.blocks()
    cache = {}
    out = defaultdict(list)
    excl_all = FIELDS["exclude_everywhere"]
    for k, v in m._v.items():
        c = {"f": m._f.get(k)}
        is_d = isinstance(v, (datetime.datetime, datetime.date))
        if not (is_num(v) or is_d) or m.block_of_cell(k):
            continue
        rl, ch = m.row_label(k), m.col_header(k)
        for field, spec in FIELDS["fields"].items():
            if (spec["kind"] == "date") != is_d:
                continue
            key = (field, rl, ch)
            if key not in cache:
                syn, ex = spec["synonyms"], spec.get("exclude", []) + excl_all
                cache[key] = max(label_score(rl, syn, ex), label_score(ch, syn, ex) - 1.0)
            s = cache[key]
            if s < 3:
                continue
            bonus = (0.5 if c["f"] else 0.0) + (0.5 if GOOD_SHEETS.search(k[0]) else 0.0) - (0.5 if DATA_SHEETS.search(k[0]) else 0.0)
            out[field].append({"key": k, "score": s + bonus, "label": rl or ch, "value": v, "formula": bool(c["f"])})
    for f in out:
        out[f].sort(key=lambda x: (-x["score"], x["key"]))
        out[f] = out[f][:10]
    return out


# ---------------------------------------------------------------------------------------------- the Python chain
HYP_IDS = {"enterprise_value": ("I1", "enterprise value"), "equity_value": ("I3", "equity value"),
           "investor_value": ("I4", "investor value"), "moic": ("I6", "MOIC")}


def hypothesis_value(m, hyp):
    """an AI-proposed calculation: {"op": "sum"|"product", "terms": [["Sheet!B21", 1], ["Sheet!B25", -1]]}.
    sum: sum of sign x value; product: product of value ** sign (sign -1 divides). None if any cell is missing."""
    try:
        terms = [(parse_ref_str(c), float(sg)) for c, sg in hyp.get("terms", [])]
    except (ValueError, TypeError):
        return None
    vals = [(m.v(k), sg) for k, sg in terms]
    if not terms or any(not is_num(v) for v, _ in vals):
        return None
    if hyp.get("op", "sum") == "product":
        out = 1.0
        for v, sg in vals:
            if sg < 0 and v == 0:
                return None
            out *= v ** sg
        return out
    return sum(v * sg for v, sg in vals)


def describe_hypothesis(m, hyp):
    j = " x " if hyp.get("op") == "product" else " "
    parts = []
    for c, sg in hyp.get("terms", []):
        lab = m.label(parse_ref_str(c)) or c
        if hyp.get("op") == "product":
            parts.append(("/ " if float(sg) < 0 else "") + f"{lab} ({c})")
        else:
            parts.append(("- " if float(sg) < 0 else "+ ") + f"{lab} ({c})")
    return j.join(parts).lstrip("+ ").replace(" x / ", " / ")


def solve_chain(m, C, hyps=None):
    """Proves which cells are EV, multiple(s), metric(s), equity, bridge items, investor value, by identities.
    hyps: AI-proposed calculations from JUDGMENT NEEDED; each is kept only if Python reproduces the saved value."""
    res = {"fields": {}, "identities": [], "variant": None, "weights": None, "fx_rule": None, "ownership_rule": None,
           "bridge": [], "hypotheses": {}}
    F = res["fields"]

    def put(field, cand, status, basis):
        F[field] = {"key": cand["key"], "label": cand["label"], "value": cand["value"], "formula": cand["formula"],
                    "status": status, "basis": basis, "score": cand["score"]}
    hyp_ok = {}
    for field, hyp in sorted((hyps or {}).items()):
        try:
            tgt = parse_ref_str(hyp["target"])
        except (KeyError, ValueError):
            continue
        hv, tv = hypothesis_value(m, hyp), m.v(tgt)
        ok_h = hv is not None and is_num(tv) and close(tv, hv)
        desc = describe_hypothesis(m, hyp)
        res["hypotheses"][field] = {"target": hyp["target"], "calculation": desc, "verified": ok_h,
                                    "python_value": hv, "excel_value": tv}
        if ok_h and field in HYP_IDS:
            hyp_ok[field] = True
            put(field, {"key": tgt, "label": m.label(tgt), "value": tv, "formula": m.is_formula(tgt), "score": 99.0},
                "verified", f"AI-proposed calculation verified by Python: {desc}")
            iid, nm = HYP_IDS[field]
            res["identities"].append({"id": iid, "name": nm, "result": "PASS (AI + Python)", "detail": f"{nm} = {desc}"[:240]})
            if field == "enterprise_value":
                res["variant"] = "ai_verified_formula"

    ok = lambda c: is_num(c["value"])
    EVs = [c for c in C.get("enterprise_value", []) if ok(c)][:6]
    Me = [c for c in C.get("multiple_ebitda", []) if ok(c) and 0.1 <= c["value"] <= 100][:6]
    Mr = [c for c in C.get("multiple_revenue", []) if ok(c) and 0.05 <= c["value"] <= 50][:6]
    Xe = [dict(c, field="ebitda_adjusted") for c in C.get("ebitda_adjusted", []) if ok(c) and abs(c["value"]) >= 100][:6] + \
         [dict(c, field="ebitda_reported") for c in C.get("ebitda_reported", []) if ok(c) and abs(c["value"]) >= 100][:4]
    Xr = [c for c in C.get("revenue_ttm", []) if ok(c) and abs(c["value"]) >= 100][:6]
    Wr = [c for c in C.get("weight_revenue", []) if ok(c)][:4]
    found = []
    for ev in ([] if hyp_ok.get("enterprise_value") else EVs):
        E = ev["value"]
        for me in Me:
            for xe in Xe:
                if me["key"] != xe["key"] and close(E, me["value"] * xe["value"]):
                    found.append((ev["score"] + me["score"] + xe["score"] + 2, "ev_ebitda", ev, me, xe, None, None, None))
        for mr in Mr:
            for xr in Xr:
                if mr["key"] != xr["key"] and close(E, mr["value"] * xr["value"]):
                    found.append((ev["score"] + mr["score"] + xr["score"] + 2, "ev_revenue", ev, None, None, mr, xr, None))
        for me in Me:
            for xe in Xe:
                for mr in Mr:
                    for xr in Xr:
                        a, b = me["value"] * xe["value"], mr["value"] * xr["value"]
                        for wr in Wr:
                            w = frac(wr["value"])
                            if 0 < w < 1 and close(E, w * b + (1 - w) * a):
                                found.append((ev["score"] + me["score"] + xe["score"] + mr["score"] + xr["score"] + 3,
                                              "blended", ev, me, xe, mr, xr, {"revenue": w, "ebitda": 1 - w, "basis": f"weight cell {ref_str(wr['key'])}"}))
                        if abs(b - a) > 1e-9:
                            w = (E - a) / (b - a)
                            if 0.0 < w < 1.0 and abs(w * 20 - round(w * 20)) < 1e-6:
                                found.append((ev["score"] + me["score"] + xe["score"] + mr["score"] + xr["score"],
                                              "blended", ev, me, xe, mr, xr, {"revenue": round(w, 4), "ebitda": round(1 - w, 4), "basis": "solved from EV (round weights)"}))
    if found:
        found.sort(key=lambda t: -t[0])
        _, variant, ev, me, xe, mr, xr, wts = found[0]
        res["variant"], res["weights"] = variant, wts
        put("enterprise_value", ev, "verified", f"EV identity ({variant})")
        if me:
            put("multiple_ebitda", me, "verified", "EV identity")
            put(xe["field"], xe, "verified", "EV identity")
            res["ev_metric_field"] = xe["field"]
        if mr:
            put("multiple_revenue", mr, "verified", "EV identity")
            put("revenue_ttm", xr, "verified", "EV identity")
        detail = {"ev_ebitda": "EV = EV/EBITDA multiple x EBITDA", "ev_revenue": "EV = EV/Revenue multiple x revenue",
                  "blended": f"EV = {wts['revenue'] if wts else '?'} x EV/Revenue x revenue + {wts['ebitda'] if wts else '?'} x EV/EBITDA x EBITDA"}[variant]
        res["identities"].append({"id": "I1", "name": "enterprise value", "result": "PASS", "detail": detail})
    elif not hyp_ok.get("enterprise_value"):
        fb = None
        for ev in [c for c in EVs if c["formula"]][:4]:
            try:
                val, used = FE.evaluate(m, ev["key"])
            except (FE.Unsupported, FE.ExcelError):
                continue
            if close(val, ev["value"], 1e-9):
                fb = (ev, used)
                break
        if fb:
            ev, used = fb
            res["variant"] = "custom_formula"
            put("enterprise_value", ev, "verified", "EV formula re-computed in Python")
            for fld in ("multiple_ebitda", "multiple_revenue", "ebitda_adjusted", "ebitda_reported", "revenue_ttm"):
                for c in C.get(fld, []):
                    if c["key"] in used and fld not in F:
                        put(fld, c, "verified", "input of the EV formula")
                        break
            res["ev_inputs"] = [{"cell": ref_str(k), "label": m.label(k), "value": m.v(k)} for k in sorted(used)]
            res["identities"].append({"id": "I1", "name": "enterprise value", "result": "PASS (formula)",
                                      "detail": ("no standard multiple x metric identity; EV's own formula re-computed in Python from "
                                                 + ", ".join(m.label(k) or ref_str(k) for k in sorted(used)))[:240]})
        else:
            res["identities"].append({"id": "I1", "name": "enterprise value", "result": "NOT PROVEN" if EVs else "N/A",
                                      "detail": "no multiple x metric combination reproduces EV" if EVs else "no enterprise value cell found"})
    # adjusted EBITDA = reported + adjustments
    xa, xrp = F.get("ebitda_adjusted"), None
    if xa:
        for rp in C.get("ebitda_reported", [])[:5]:
            for ad in C.get("ebitda_adjustments", [])[:5]:
                if is_num(rp["value"]) and is_num(ad["value"]) and close(xa["value"], rp["value"] + ad["value"]):
                    put("ebitda_reported", rp, "verified", "adjusted EBITDA identity")
                    put("ebitda_adjustments", ad, "verified", "adjusted EBITDA identity")
                    xrp = rp
                    break
            if xrp:
                break
        if xrp:
            res["identities"].append({"id": "I2", "name": "adjusted EBITDA", "result": "PASS", "detail": "adjusted EBITDA = EBITDA + adjustments"})
        else:
            try:
                val, used = FE.evaluate(m, xa["key"])
                ok_f = close(val, xa["value"], 1e-9)
            except (FE.Unsupported, FE.ExcelError):
                ok_f = False
            if ok_f:
                res["identities"].append({"id": "I2", "name": "adjusted EBITDA", "result": "PASS (formula)",
                                          "detail": "no separate EBITDA + adjustments cells; its own formula re-computed in Python"})
            elif not C.get("ebitda_adjustments"):
                res["identities"].append({"id": "I2", "name": "adjusted EBITDA", "result": "N/A",
                                          "detail": "no adjustments total cell to test against"})
            else:
                res["identities"].append({"id": "I2", "name": "adjusted EBITDA", "result": "NOT PROVEN",
                                          "detail": "no EBITDA + adjustments pair reproduces it, and its formula could not be re-computed"})
    # equity = EV + cash - debt (+ bridge)
    evf = F.get("enterprise_value")
    if evf and not hyp_ok.get("equity_value"):
        E_ = evf["value"]
        done = False
        for eq in [c for c in C.get("equity_value", []) if ok(c)][:6]:
            Q = eq["value"]
            tries = []
            for nd in C.get("net_debt", [])[:4]:
                tries += [(Q, E_ - nd["value"], [("net_debt", nd, -1)]), (Q, E_ + nd["value"], [("net_debt", nd, +1)])]
            for ca in C.get("cash", [])[:4]:
                for de in C.get("debt", [])[:4]:
                    tries += [(Q, E_ + ca["value"] - de["value"], [("cash", ca, 1), ("debt", de, -1)]),
                              (Q, E_ + ca["value"] + de["value"], [("cash", ca, 1), ("debt", de, 1)])]
                tries.append((Q, E_ + ca["value"], [("cash", ca, 1)]))
            for de in C.get("debt", [])[:4]:
                tries.append((Q, E_ - de["value"], [("debt", de, -1)]))
            tries.append((Q, E_, []))
            for q, calc, parts in tries:
                if all(is_num(p[1]["value"]) for p in parts) and close(q, calc):
                    put("equity_value", eq, "verified", "equity bridge identity")
                    for fld, cand, sign in parts:
                        put(fld, cand, "verified", "equity bridge identity")
                    res["bridge"] = [{"field": fld, "cell": ref_str(cand["key"]), "sign": sign} for fld, cand, sign in parts]
                    res["identities"].append({"id": "I3", "name": "equity value", "result": "PASS",
                                              "detail": "equity = EV" + "".join(f" {'+' if s > 0 else '-'} {f}" for f, _, s in parts)})
                    done = True
                    break
            if not done:
                try:
                    val, used = FE.evaluate(m, eq["key"])
                except (FE.Unsupported, FE.ExcelError):
                    val, used = None, set()
                if val is not None and close(Q, val, 1e-9) and evf["key"] in used:
                    put("equity_value", eq, "verified", "equity formula re-computed in Python")
                    res["bridge"] = [{"field": "bridge_item", "cell": ref_str(k), "label": m.label(k)} for k in sorted(used) if k != evf["key"]]
                    res["identities"].append({"id": "I3", "name": "equity value", "result": "PASS (formula)",
                                              "detail": f"equity = EV with {len(res['bridge'])} bridge item(s) (its formula re-computed in Python)"})
                    done = True
            if done:
                break
        if not done:
            res["identities"].append({"id": "I3", "name": "equity value", "result": "NOT PROVEN",
                                      "detail": "no cash/debt/bridge combination reproduces equity from EV"})
    # investor value
    eqf = F.get("equity_value")
    IV = [c for c in C.get("investor_value", []) if ok(c)][:8]
    IVL = [c for c in C.get("investor_value_local", []) if ok(c)][:4]
    FX = [c for c in C.get("fx_rate", []) if ok(c) and 0.2 < c["value"] < 5][:4]
    OW = [c for c in C.get("ownership", []) if ok(c) and 0 < frac(c["value"]) <= 1][:4]
    if eqf and IV and not hyp_ok.get("investor_value"):
        Q = eqf["value"]
        hit = None
        for iv in IV:
            V = iv["value"]
            for ow in OW:
                o = frac(ow["value"])
                if close(V, Q * o):
                    hit = (iv, "ownership", ow, None, None)
                    break
                for fx in FX:
                    if close(V, Q * o / fx["value"]):
                        hit = (iv, "ownership", ow, fx, "divide"); break
                    if close(V, Q * o * fx["value"]):
                        hit = (iv, "ownership", ow, fx, "multiply"); break
                if hit:
                    break
            if not hit:
                for loc in IVL + [c for c in IV if c["key"] != iv["key"]]:
                    for fx in FX:
                        if close(V, loc["value"] / fx["value"]):
                            hit = (iv, "waterfall", None, fx, "divide", loc); break
                        if close(V, loc["value"] * fx["value"]):
                            hit = (iv, "waterfall", None, fx, "multiply", loc); break
                    if hit:
                        break
            if hit:
                break
        if hit:
            iv, rule, ow, fx, fxr = hit[:5]
            put("investor_value", iv, "verified", f"investor value identity ({rule}{', FX ' + fxr if fx else ''})")
            if ow:
                put("ownership", ow, "verified", "investor value identity")
            if fx:
                put("fx_rate", fx, "verified", "investor value identity")
                res["fx_rule"] = fxr
            if len(hit) > 5:
                put("investor_value_local", hit[5], "verified", "FX identity")
            res["ownership_rule"] = "simple ownership" if rule == "ownership" else "waterfall (Excel only)"
            res["identities"].append({"id": "I4", "name": "investor value", "result": "PASS",
                                      "detail": ("equity x ownership" if ow else "local value") + (f" {'/' if fxr == 'divide' else 'x'} FX" if fx else "")})
        else:
            fb = None
            for iv in [c for c in IV if c["formula"]][:4]:
                try:
                    val, used = FE.evaluate(m, iv["key"])
                except (FE.Unsupported, FE.ExcelError):
                    continue
                near = eqf["key"] in used or any(eqf["key"] in m.precedents(u) for u in used)
                if close(val, iv["value"], 1e-9) and near:
                    fb = iv
                    break
        if not hit and fb:
            put("investor_value", fb, "verified", "investor value formula re-computed in Python (uses equity value)")
            res["ownership_rule"] = "formula (Excel)"
            res["identities"].append({"id": "I4", "name": "investor value", "result": "PASS (formula)",
                                      "detail": "no ownership / FX identity; its own formula re-computed in Python from equity value"})
        elif not hit:
            best = IV[0]
            fxv = FX[0]["value"] if FX else 1.0
            lim = Q * max(fxv, 1 / fxv)
            inb = -1e-6 <= best["value"] <= lim * (1 + MAT["identity_relative_tolerance"])
            put("investor_value", best, "mapped", "label; waterfall decides the value (Excel only)")
            res["ownership_rule"] = "waterfall (Excel only)"
            res["identities"].append({"id": "I4", "name": "investor value", "result": "BOUNDS OK" if inb else "OUT OF BOUNDS",
                                      "detail": f"0 <= investor value <= equity value{' (FX-adjusted)' if FX else ''}: {'yes' if inb else 'NO'}"})
    # held at cost (no enterprise value proven, value equals cost)
    IC = [c for c in C.get("invested_capital", []) if ok(c) and abs(c["value"]) >= 100][:6]
    if not evf and IV:
        for iv in IV:
            for ic in IC:
                if iv["key"] != ic["key"] and close(iv["value"], ic["value"]):
                    res["variant"] = "held_at_cost"
                    put("investor_value", iv, "verified", "value equals invested capital (held at cost)")
                    put("invested_capital", ic, "verified", "value equals invested capital (held at cost)")
                    res["identities"].append({"id": "I5", "name": "held at cost", "result": "PASS", "detail": "investor value = invested capital"})
                    break
            if res["variant"]:
                break
    # MOIC
    ivf = F.get("investor_value")
    if ivf and not hyp_ok.get("moic"):
        def moic_hit():
            for mo in [c for c in C.get("moic", []) if ok(c) and 0 <= c["value"] < 100][:4]:
                for ic in IC:
                    for p in [None] + [p for p in C.get("proceeds", []) if is_num(p["value"])][:3]:
                        tot = ivf["value"] + (p["value"] if p else 0.0)
                        if ic["value"] and close(mo["value"], tot / ic["value"]):
                            return mo, ic, p
            return None
        hit = moic_hit()
        if hit:
            mo, ic, p = hit
            put("moic", mo, "verified", "MOIC identity")
            put("invested_capital", ic, "verified", "MOIC identity")
            if p:
                put("proceeds", p, "verified", "MOIC identity")
            res["identities"].append({"id": "I6", "name": "MOIC", "result": "PASS",
                                      "detail": "MOIC = (value" + (" + proceeds" if p else "") + ") / invested capital"})
        elif C.get("moic"):
            fb = None
            for mo in [c for c in C.get("moic", []) if ok(c) and c["formula"]][:4]:
                try:
                    val, used = FE.evaluate(m, mo["key"])
                except (FE.Unsupported, FE.ExcelError):
                    continue
                near = ivf["key"] in used or any(close(m.v(u), ivf["value"], 1e-9) for u in used if is_num(m.v(u)))
                if close(val, mo["value"], 1e-9) and near:
                    fb = mo
                    break
            if fb:
                put("moic", fb, "verified", "MOIC formula re-computed in Python (uses value to XPV)")
                res["identities"].append({"id": "I6", "name": "MOIC", "result": "PASS (formula)",
                                          "detail": "no standard (value + proceeds) / cost pair; its own formula re-computed from value to XPV"})
            else:
                res["identities"].append({"id": "I6", "name": "MOIC", "result": "NOT PROVEN",
                                          "detail": "no (value + proceeds) / invested capital combination reproduces MOIC"})
    return res


# ---------------------------------------------------------------------------------------------- TTM windows
def metric_windows(m, key, depth=5):
    """SUM ranges inside monthly block rows used (directly or a few steps upstream) by a metric cell."""
    out, frontier, seen = [], [key], {key}
    for _ in range(depth):
        nxt = []
        for k in frontier:
            f = m.f(k)
            if not f:
                continue
            for (sh, r1, c1, r2, c2) in parse_refs(f, k[0]):
                real = m.sheet_lc.get(sh.lower())
                if not real:
                    continue
                cells = m.cells_in(real, r1, c1, r2, c2)
                hits = [(m.block_of_cell(c), c) for c in cells]
                hits = [(b, c) for b, c in hits if b]
                if hits and (r1, c1) != (r2, c2):
                    months = sorted({b[1] for b, _ in hits})
                    step = max(b[2] for b, _ in hits)
                    out.append({"via": ref_str(k), "range": range_str(real, r1, c1, r2, c2),
                                "line": ", ".join(sorted({b[0] for b, _ in hits})),
                                "first": ym_str(months[0] - step + 1), "last": ym_str(months[-1]),
                                "months": months[-1] - months[0] + step, "periods": len(months), "step": step,
                                "_last_i": months[-1], "python_sum": sum(m.v(c) for _, c in hits if is_num(m.v(c)))})
                else:
                    for c in cells:
                        if c not in seen:
                            seen.add(c)
                            nxt.append(c)
        frontier = nxt
    return out


DYNAMIC = re.compile(r"\b(SUMIFS|SUMIF|OFFSET|INDEX|SUMPRODUCT|EDATE|EOMONTH|XLOOKUP|INDIRECT)\s*\(", re.I)


def window_type(m, key):
    f = m.f(key) or ""
    if not f:
        return "typed value"
    up = [key] + [k for k in m.precedents(key) if m.f(k)][:20]
    return "dynamic, rolls with a date" if any(DYNAMIC.search(m.f(k) or "") for k in up) else "fixed range, moved by hand"


def value_window(m, key):
    """formula-agnostic: which contiguous 3-, 12- or 36-month window of ONE period row sums exactly to this cell?
    Works for SUM ranges, SUMIFS / OFFSET date windows and typed totals alike."""
    v = m.v(key)
    if not is_num(v) or abs(v) < 100:
        return None
    up = m.upstream([key])
    rows = [(r, b["step"] or 1) for b in m.blocks() for r in b["rows"] if any(k in up for k in r["cells"].values())]
    if not rows:
        rows = [(r, b["step"] or 1) for b in m.blocks() for r in b["rows"] if similarity(m.label(key), r["label"]) >= 0.5]
    hits = set()
    for row, st in rows:
        vals = {i: m.v(k) for i, k in row["cells"].items() if is_num(m.v(k))}
        for n_months in (12, 3, 36):
            if n_months % st:
                continue
            for end in sorted(vals):
                win = [vals.get(end - j * st) for j in range(n_months // st)]
                if None not in win and any(win) and abs(sum(win) - v) <= max(0.5, 1e-9 * abs(v)):
                    hits.add((row["line"], end, n_months, st))
    ends = {(e, n) for _, e, n, _ in hits}
    if len(ends) != 1:
        return None
    (end, n), = ends
    st = next(iter(hits))[3]
    return {"via": ref_str(key), "range": "(value-matched)", "line": ", ".join(sorted({h[0] for h in hits})),
            "first": ym_str(end - n + 1), "last": ym_str(end), "months": n, "periods": n // st, "step": st,
            "_last_i": end, "python_sum": v, "value_matched": True}


def window_words(first, last, months):
    if months == 12 and first.endswith("-01") and last.endswith("-12"):
        return f"calendar year {last[:4]}"
    return f"{months}-month window ending {last}"


# ---------------------------------------------------------------------------------------------- pasted calculations
def pasted_calc(m, k, val_i, block_rows):
    v = m.v(k)
    tol = MAT["pasted_calc_abs_tolerance"]
    if not is_num(v) or abs(v) < MAT["pasted_calc_min_abs_value"]:
        return None
    sh, r, c = k
    for direction in ("row", "col"):
        run, vals = [], []
        step = (lambda i: (sh, r, c - i)) if direction == "row" else (lambda i: (sh, r - i, c))
        for i in range(1, 60):
            kk = step(i)
            if kk[1] < 1 or kk[2] < 1:
                break
            x = m.v(kk)
            if not is_num(x) or m.is_date(kk):
                break
            run.append(kk)
            vals.append(x)
            if len(run) >= 2 and sum(1 for y in vals if y) >= 2 and abs(sum(vals) - v) <= tol:
                a, b = run[-1], run[0]
                return {"kind": f"typed total of the {len(run)} cells {'to its left' if direction == 'row' else 'above it'}",
                        "proposed_formula": f"=SUM({range_str(sh, min(a[1], b[1]), min(a[2], b[2]), max(a[1], b[1]), max(a[2], b[2])).split('!')[1]})"}
    lab = m.label(k)
    for row in block_rows:
        if similarity(lab, row["label"]) < 0.5:
            continue
        ms = sorted(row["cells"])
        st = row.get("step", 1) or 1
        for n in (12, 3, 36):
            if n % st:
                continue
            for end in ([val_i] if val_i is not None else []) + [ms[-1]]:
                win = [row["cells"].get(end - j * st) for j in range(n // st)]
                if all(win) and abs(sum(m.v(x) for x in win) - v) <= tol:
                    first, last = win[-1], win[0]
                    return {"kind": f"typed {n}-month total of '{row['label']}' ending {ym_str(end)}",
                            "proposed_formula": "=SUM(" + range_str(first[0], first[1], first[2], last[1], last[2]) + ")"}
    return None


# ---------------------------------------------------------------------------------------------- main analysis
def analyze(path, period_end=None, forced=None, hyps=None):
    """forced: {field: 'Sheet!B5'} - cells chosen by an answered judgment question or a named decision."""
    m = Model(path)
    blocks = m.blocks()
    C = find_candidates(m)
    for field, cell in (forced or {}).items():
        k = parse_ref_str(cell)
        if k in m.cells:
            C[field] = [{"key": k, "score": 99.0, "label": m.label(k), "value": m.v(k), "formula": m.is_formula(k)}]
    chain = solve_chain(m, C, hyps)
    F = chain["fields"]
    # fill unproven fields from labels (status mapped/weak); remember the alternatives
    questions = []
    for field, spec in FIELDS["fields"].items():
        cands = C.get(field, [])
        if field in F or not cands or spec["kind"] == "date":
            continue
        top = cands[0]
        if top["score"] < 6 and not spec.get("required"):
            continue
        F[field] = {"key": top["key"], "label": top["label"], "value": top["value"], "formula": top["formula"],
                    "status": "mapped" if top["score"] >= 6 else "weak", "basis": "label", "score": top["score"]}
        if spec.get("required") and len(cands) > 1 and cands[1]["score"] >= top["score"] - 1 and chain["variant"] != "held_at_cost":
            questions.append({"id": short_id("Q", {"field": field}), "type": "lp_field", "field": field,
                              "prompt": f"Which cell is the current-period {field.replace('_', ' ')} on the LP / valuation summary?",
                              "options": {chr(97 + i): {"cell": ref_str(c["key"]), "label": c["label"], "value": c["value"]}
                                          for i, c in enumerate(cands[:5])}})
    for f_, rec in F.items():
        rec["alternatives"] = [{"cell": ref_str(c["key"]), "label": c["label"], "value": c["value"]}
                               for c in C.get(f_, []) if c["key"] != rec["key"]][:4]
        same = [c for c in C.get(f_, []) if c["key"] != rec["key"] and close(c["value"], rec["value"], 1e-9)]
        rec["aliases"] = [ref_str(c["key"]) for c in same if c["formula"]]
        rec["typed_copies"] = [ref_str(c["key"]) for c in same if not c["formula"]]
    # valuation date
    vd = None
    for c in C.get("valuation_date", []):
        vd = {"value": c["value"].date().isoformat() if isinstance(c["value"], datetime.datetime) else str(c["value"]),
              "basis": f"date cell {ref_str(c['key'])} ('{c['label']}')", "cell": ref_str(c["key"]),
              "_i": ym_to_i((c["value"].year, c["value"].month))}
        break
    windows, wtypes = {}, {}
    for fld in ("revenue_ttm", "ebitda_reported", "ebitda_adjustments", "ebitda_adjusted"):
        if fld in F:
            ws_ = metric_windows(m, F[fld]["key"])
            fixed = []
            for w in ws_:                                   # a range that is not a 3/12/36-month window (e.g. SUMIFS over a
                if w["months"] in (3, 12, 36):              # whole row): find the window its value really covers
                    fixed.append(w)
                    continue
                vw = value_window(m, parse_ref_str(w["via"]))
                fixed.append(vw if vw else w)
            ws_ = fixed
            if not ws_:
                vw = value_window(m, F[fld]["key"])
                ws_ = [vw] if vw else []
            windows[fld] = ws_
            wtypes[fld] = window_type(m, F[fld]["key"])
    if period_end:
        p = parse_date_text(period_end)
        vd = {"value": period_end, "basis": "given with --period-end", "cell": None, "_i": ym_to_i(p)}
    if not vd:
        p = parse_date_text(os.path.splitext(os.path.basename(path))[0])
        if p:
            vd = {"value": f"{p[0]}-{p[1]:02d}", "basis": "workbook file name", "cell": None, "_i": ym_to_i(p)}
    if not vd:
        lasts = [w["_last_i"] for ws in windows.values() for w in ws]
        if lasts:
            i = max(lasts)
            vd = {"value": ym_str(i), "basis": "last month of the metric windows", "cell": None, "_i": i}
    val_i = vd["_i"] if vd else None
    # metric basis and TTM window check
    win_rows, win_ok, seen_w = [], True, set()
    for fld, ws in windows.items():
        for w in ws:
            if (w["via"], w["range"]) in seen_w:
                continue
            seen_w.add((w["via"], w["range"]))
            ends = w["_last_i"] == val_i if val_i is not None else None
            via_key = None
            vm = re.match(r"^(?:'((?:[^']|'')+)'|([^!]+))!([A-Z]+)(\d+)$", w["via"])
            exact = None
            if vm:
                sh = (vm.group(1) or vm.group(2)).replace("''", "'")
                via_key = (sh, int(vm.group(4)), col_idx(vm.group(3)))
                fv = (m.f(via_key) or "").replace("$", "").replace(" ", "").upper()
                if re.fullmatch(r"=SUM\([^()]+\)", fv) and is_num(m.v(via_key)):
                    exact = close(m.v(via_key), w["python_sum"], MAT["recalc_relative_tolerance"] * 1e3)
            if ends is False or exact is False:
                win_ok = False
            win_rows.append({"_last_i": w["_last_i"], "field": fld, "via": w["via"], "range": w["range"], "line": w["line"], "first": w["first"],
                             "last": w["last"], "months": w["months"], "ends_at_valuation_month": ends,
                             "type": wtypes.get(fld), "described": window_words(w["first"], w["last"], w["months"]),
                             "python_sum_matches_excel": exact})
    for fld in ("revenue_ttm", "ebitda_reported", "ebitda_adjustments", "ebitda_adjusted"):
        ws_ = [w for w in win_rows if w["field"] == fld]
        if fld in F and F[fld]["status"] in ("mapped", "weak") and ws_ and all(w["ends_at_valuation_month"] and w["python_sum_matches_excel"] is not False for w in ws_) \
                and any(w["python_sum_matches_excel"] for w in ws_):
            F[fld].update(status="verified", basis="metric window ends at the valuation month; Python's sum = Excel")
    basis = None
    lens = {w["months"] for w in win_rows if w["field"] in ("ebitda_adjusted", "ebitda_reported", "revenue_ttm")}
    adj_label = F["ebitda_adjusted"]["label"] if F.get("ebitda_adjusted") else ""
    if 12 in lens:
        basis = "ttm"
    elif 36 in lens or re.search(r"(3|three)\s*-?\s*y(ea)?r", adj_label, re.I):
        basis = "three_year_average"
    elif 3 in lens:
        basis = "quarter"
    variant = chain["variant"] or ("unknown" if F.get("enterprise_value") else "not_found")
    # inputs upstream of the LP row
    lp_keys = [rec["key"] for f_, rec in F.items() if f_ in OUTPUT_FIELDS]
    alias_keys = []
    for f_, rec in F.items():
        if f_ in OUTPUT_FIELDS:
            for a in rec["aliases"]:
                alias_keys.append(parse_ref_str(a))
    up = m.upstream(lp_keys + alias_keys)
    block_rows_all = [row for b in blocks for row in b["rows"]]
    items, monthly = [], {}

    def add_monthly(k):
        b = m.block_of_cell(k)
        if not b:
            return False
        line, mi, _step = b
        lab_ = line.split("|", 1)[1]
        rec = monthly.setdefault(line, {"line": line, "label": lab_, "sheet": k[0], "row": k[1], "months_typed": 0,
                                        "first": mi, "last": mi,
                                        "adjustment": words_hit(lab_, WORDS["adjustment_words"]) or
                                        any(words_hit(lab_, ws_) for ws_ in WORDS["adjustment_categories"].values())})
        rec["months_typed"] += 1
        rec["first"], rec["last"] = min(rec["first"], mi), max(rec["last"], mi)
        return True
    for k in sorted(up):
        cell = m.cells[k]
        if cell["f"]:
            continue
        v = cell["v"]
        lab = m.label(k)
        if isinstance(v, (datetime.datetime, datetime.date)):
            items.append({"cell": ref_str(k), "class": "date", "label": lab, "value": v.date().isoformat() if isinstance(v, datetime.datetime) else str(v)})
            continue
        if not is_num(v):
            continue
        if add_monthly(k):
            continue
        fund_field = next((f_ for f_, rec in F.items() if rec["key"] == k and FIELDS["fields"][f_]["kind"] == "fund_record"), None)
        pc = None if fund_field else pasted_calc(m, k, val_i, block_rows_all)
        if fund_field:
            items.append({"cell": ref_str(k), "class": "fund_record", "label": lab, "value": v, "field": fund_field})
        elif pc:
            items.append({"cell": ref_str(k), "class": "pasted_calculation", "label": lab, "value": v, **pc})
        elif words_hit(lab, WORDS["fx_words"]):
            items.append({"cell": ref_str(k), "class": "fx", "label": lab, "value": v})
        elif words_hit(lab, ROLE_WORDS["cap_table"]["label_words"]) or words_hit(k[0], ROLE_WORDS["cap_table"]["sheet_words"]):
            items.append({"cell": ref_str(k), "class": "cap_table", "label": lab, "value": v})
        elif words_hit(lab, WORDS["balance_words"]):
            items.append({"cell": ref_str(k), "class": "balance", "label": lab, "value": v})
        elif words_hit(lab, ROLE_WORDS["adjustments"]["label_words"]):
            items.append({"cell": ref_str(k), "class": "adjustment", "label": lab, "value": v})
        elif words_hit(lab, ROLE_WORDS["comparables"]["label_words"]) or words_hit(k[0], ROLE_WORDS["comparables"]["sheet_words"]):
            items.append({"cell": ref_str(k), "class": "comparable", "label": lab, "value": v})
        else:
            items.append({"cell": ref_str(k), "class": "parameter", "label": lab, "value": v})
    # rows that a proposed formula restoration would reconnect (e.g. the monthly rows behind a pasted TTM total)
    extra = set()
    for i in items:
        mm = re.match(r"^=SUM\((.+)\)$", i.get("proposed_formula") or "")
        if i["class"] == "pasted_calculation" and mm:
            for (sh, r1, c1, r2, c2) in parse_refs(mm.group(1), parse_ref_str(i["cell"])[0]):
                real = m.sheet_lc.get(sh.lower())
                if real:
                    extra |= m.upstream(m.cells_in(real, r1, c1, r2, c2))
    for k in sorted(extra - up):
        if not m.cells[k]["f"] and is_num(m.cells[k]["v"]):
            if add_monthly(k):
                monthly[m.block_of_cell(k)[0]]["via_proposed_formula"] = True
    for rec in monthly.values():
        rec["first"], rec["last"] = ym_str(rec["first"]), ym_str(rec["last"])
    typed_all = sum(1 for k, v in m._v.items() if k not in m._f and is_num(v)) + sum(getattr(m, "skipped_cells", {}).values())
    typed_up = sum(1 for k in up if not m.cells[k]["f"] and is_num(m.cells[k]["v"]))
    addins = [{"cell": ref_str(k), "functions": fn, "value": m.v(k), "label": m.label(k)} for k, fn in m.addin_cells(up)]
    externals = [{"cell": ref_str(k), "formula": m.f(k)} for k in m.external_cells(up)]
    errors = [{"cell": ref_str(k), "value": m.v(k), "label": m.label(k)} for k in m.error_cells(up)]
    volatile = [ref_str(k) for k in m.volatile_cells(up)]
    sheets_reached = sorted({k[0] for k in up})
    # liveness
    pasted_cells = {i["cell"] for i in items if i["class"] == "pasted_calculation"}
    stale_findings = []
    wgroups = {}
    def on_chain(f_, rec):
        return f_ in OUTPUT_FIELDS and (rec["status"] in ("verified", "chosen") or
                                        (f_ in ("enterprise_value", "equity_value", "investor_value") and rec["status"] == "mapped"))
    hard = [{"field": f_, "cell": ref_str(rec["key"]), "label": rec["label"], "value": rec["value"]}
            for f_, rec in F.items() if on_chain(f_, rec) and not rec["formula"] and ref_str(rec["key"]) not in pasted_cells]
    hard += [{"field": f_, "cell": c, "label": rec["label"], "value": rec["value"], "copy_of": ref_str(rec["key"])}
             for f_, rec in F.items() if on_chain(f_, rec) for c in rec.get("typed_copies", [])]
    # Python re-computes every LP formula from its saved inputs and compares with Excel's saved result
    fchecks = {"recomputed": 0, "matched": 0, "unsupported": 0}
    for f_, rec in sorted(F.items()):
        if not rec["formula"] or not is_num(rec["value"]):
            continue
        try:
            val, _ = FE.evaluate(m, rec["key"])
        except FE.Unsupported:
            fchecks["unsupported"] += 1
            continue
        except FE.ExcelError:
            continue
        fchecks["recomputed"] += 1
        if close(val, rec["value"], 1e-9):
            fchecks["matched"] += 1
        else:
            stale_findings.append({"check": "L5", "kind": "stale_value", "cell": ref_str(rec["key"]),
                                   "text": f"{f_.replace('_', ' ')} at {ref_str(rec['key'])}: Excel saved {rec['value']:,.2f} but its formula gives {val:,.2f} (stale or manual calculation)"})
    pasted = [i for i in items if i["class"] == "pasted_calculation"]
    findings = []
    for h in hard:
        what = (f"{h['cell']} repeats {h['field'].replace('_', ' ')} ({h['copy_of']}) as a typed number"
                if h.get("copy_of") else f"{h['field'].replace('_', ' ')} at {h['cell']} is a typed number, not a formula")
        fix = f"; proposed: ={h['copy_of']}" if h.get("copy_of") else ""
        findings.append({"check": "L1", "kind": "hardcoded_output", "cell": h["cell"],
                         "proposed_formula": (f"={h['copy_of']}" if h.get("copy_of") else None),
                         "text": what + "; it will not update" + fix})
    for p in pasted:
        findings.append({"check": "L2", "kind": "pasted_calculation", "cell": p["cell"], "proposed_formula": p["proposed_formula"],
                         "text": f"{p['cell']} ('{p['label']}') is a {p['kind']}; proposed: {p['proposed_formula']}"})
    no_vals = [k for k in up if k in m._f and m._v.get(k) is None]
    where = "feeding the LP row"
    all_f = list(m._f)
    if not no_vals and all_f:
        none_f = [k for k in all_f if m._v.get(k) is None]
        if len(none_f) >= 0.5 * len(all_f):
            no_vals, where = none_f, f"in the workbook (of {len(all_f)})"
    if no_vals:
        findings.append({"check": "L3", "kind": "no_saved_values", "cell": ref_str(sorted(no_vals)[0]),
                         "text": f"{len(no_vals)} formula(s) {where} have no saved value (the file was last saved by a "
                                 "tool that does not calculate); open and save it in Excel, then re-run"})
    if m.calc_mode and str(m.calc_mode).lower() == "manual":
        findings.append({"check": "L3", "kind": "manual_calculation", "cell": None,
                         "text": "calculation mode is Manual: saved values may be stale"})
    for e in externals:
        findings.append({"check": "L3", "kind": "external_link", "cell": e["cell"],
                         "text": f"{e['cell']} reads another workbook ({e['formula'][:60]}); its value is frozen at the last save"})
    addin_keys = {k for k, _ in m.addin_cells(up)}
    err_keys = [parse_ref_str(e["cell"]) for e in errors]
    addin_err = [k for k in err_keys if k in addin_keys]
    propagated, own = [], []
    for k in err_keys:
        if k in addin_keys:
            continue
        if addin_err and len(propagated) + len(own) < 400 and set(addin_err) & m.upstream([k]):
            propagated.append(k)
        else:
            own.append(k)
    error_breakdown = {"scope": "LP dependency graph", "add_in_cells_with_errors": len(addin_err),
                       "caused_by_add_in_errors": len(propagated), "own_errors": len(own),
                       "add_in_error_values": sorted({str(m.v(k)) for k in addin_err})}
    if addin_err:
        findings.append({"check": "L3", "kind": "addin_error", "cell": ref_str(addin_err[0]),
                         "text": f"{len(addin_err)} add-in cell(s) were saved showing a data-provider error "
                                 f"({', '.join(error_breakdown['add_in_error_values'])}), e.g. {ref_str(addin_err[0])}"
                                 + (f"; {len(propagated)} further cell(s) show errors only because of them" if propagated else "")
                                 + ". Sign in to the data provider and save the approved workbook again, or drafts will freeze errors"})
    for k in own[:10]:
        findings.append({"check": "L3", "kind": "error_in_chain", "cell": ref_str(k),
                         "text": f"{ref_str(k)} ('{m.label(k)}') shows {m.v(k)} upstream of the LP row"})
    if len(own) > 10:
        findings.append({"check": "L3", "kind": "error_in_chain", "cell": None, "text": f"... {len(own) - 10} more error cells upstream"})
    for idn in chain["identities"]:
        if idn["result"] in ("NOT PROVEN", "OUT OF BOUNDS"):
            findings.append({"check": "L5", "kind": "identity_not_proven" if idn["result"] == "NOT PROVEN" else "identity_out_of_bounds",
                             "cell": None, "text": f"{idn['name']}: {idn['detail']}"})
    for w in win_rows:
        if w["ends_at_valuation_month"] is False:
            wgroups.setdefault((w["first"], w["last"], w["described"], w["type"], w["_last_i"]), []).append(w["field"])
        if w["python_sum_matches_excel"] is False:
            findings.append({"check": "L5", "kind": "stale_sum", "cell": w["via"],
                             "text": f"{w['via']}: Python's sum of {w['range']} differs from Excel's saved value (stale or manual calculation)"})
    findings += stale_findings
    for (first, last, described, wtype, last_i), flds in sorted(wgroups.items()):
        lag = val_i - last_i
        usual = 0 < lag <= MAT.get("metric_lag_months_usual", 3)
        findings.append({"check": "L5", "kind": "metric_window", "cell": None, "lag_months": lag, "info_only": usual,
                         "text": f"{', '.join(f.replace('_', ' ') for f in flds)} use{'s' if len(flds) == 1 else ''} the {described} "
                                 f"({first}..{last}, {wtype}) but the intended period is {ym_str(val_i)}"
                                 + (f" - {lag} month(s) earlier" if lag > 0 else f" - {-lag} month(s) later")
                                 + (". Within the usual reporting lag: confirm once at onboarding that this is the company's convention"
                                    if usual else ". Confirm the convention (latest available month, last fiscal year) or roll the window forward")})
    for f_ in ("enterprise_value", "equity_value", "investor_value"):
        if f_ not in F and variant != "held_at_cost" and not (f_ != "investor_value" and variant == "not_found"):
            findings.append({"check": "L5", "kind": "field_not_found", "cell": None,
                             "text": f"no cell labelled like '{f_.replace('_', ' ')}' was found"})
    metric_sources_pre = {}
    for f_ in ("ebitda_adjusted", "ebitda_reported", "revenue_ttm"):
        if f_ in F and not windows.get(f_):
            if any(m.f(k) and is_external(m.f(k)) for k in m.upstream([F[f_]["key"]])):
                metric_sources_pre[f_] = "reads linked workbook(s)"
    # ---- periods: intended reporting period (date cell, file name, --period-end) vs the month the formulas calculate
    srcs = {}
    if C.get("valuation_date"):
        c0 = C["valuation_date"][0]
        srcs["date cell " + ref_str(c0["key"])] = ym_to_i((c0["value"].year, c0["value"].month))
    pf = parse_date_text(os.path.splitext(os.path.basename(path))[0])
    if pf:
        srcs["file name"] = ym_to_i(pf)
    if period_end:
        srcs["--period-end"] = ym_to_i(parse_date_text(period_end))
    main_fields = ("ebitda_adjusted", "ebitda_reported", "revenue_ttm")
    calc_lasts = sorted({w["_last_i"] for f_, ws in windows.items() if f_ in main_fields for w in ws})
    calc_i = calc_lasts[-1] if calc_lasts else None
    intended = sorted(set(srcs.values()))
    lag = (intended[0] - calc_i) if (len(intended) == 1 and calc_i is not None) else None
    if len(intended) > 1 or len(calc_lasts) > 1:
        alignment = "mismatch"
    elif lag is None:
        alignment = "unresolved"
    elif lag == 0:
        alignment = "aligned"
    elif 0 < lag <= MAT.get("metric_lag_months_usual", 3):
        alignment = f"lagged {lag} month(s)"
    else:
        alignment = "mismatch"
    period = {"intended_reporting_month": ym_str(intended[0]) if len(intended) == 1 else None,
              "intended_sources": {k: ym_str(v) for k, v in srcs.items()},
              "detected_calculation_month": ym_str(calc_i) if calc_i is not None else None,
              "calculation_months_seen": [ym_str(i) for i in calc_lasts], "alignment": alignment, "lag_months": lag,
              "windows": sorted({f"{w['described']} ({w['type']})" for w in win_rows if w["field"] in main_fields})}
    if alignment == "unresolved" and calc_i is None and metric_sources_pre:
        period["note"] = "; ".join(f"{f_.replace('_', ' ')} {t}" for f_, t in metric_sources_pre.items())
    if alignment == "unresolved" and calc_i is not None:
        findings.append({"check": "L5", "kind": "period_unknown", "cell": None,
                         "text": f"no valuation date cell or dated file name: the intended period is unknown (formulas calculate "
                                 f"{ym_str(calc_i)}); give the valuation date at onboarding with --period-end"})
    if alignment == "mismatch" and not any(f_["kind"] == "metric_window" for f_ in findings):
        findings.append({"check": "L5", "kind": "period_mismatch", "cell": None,
                         "text": "intended period (" + ", ".join(f"{k} {v}" for k, v in period["intended_sources"].items())
                                 + f") and calculation month ({', '.join(period['calculation_months_seen']) or 'none'}) disagree"})
    # ---- method components (what EV is built from) and multiples present but not used
    comps = []
    w_ = chain["weights"] or {}
    if variant in ("ev_ebitda", "blended") and F.get("multiple_ebitda"):
        mf = chain.get("ev_metric_field") or "ebitda_adjusted"
        comps.append({"metric": mf, "metric_cell": ref_str(F[mf]["key"]) if mf in F else None,
                      "multiple_cell": ref_str(F["multiple_ebitda"]["key"]), "weight": w_.get("ebitda", 1.0)})
    if variant in ("ev_revenue", "blended") and F.get("multiple_revenue"):
        comps.append({"metric": "revenue_ttm", "metric_cell": ref_str(F["revenue_ttm"]["key"]) if "revenue_ttm" in F else None,
                      "multiple_cell": ref_str(F["multiple_revenue"]["key"]), "weight": w_.get("revenue", 1.0)})
    if variant in ("custom_formula", "ai_verified_formula"):
        comps = [{"metric": f_, "metric_cell": ref_str(F[f_]["key"]), "weight": None, "from": "EV formula inputs"}
                 for f_ in ("ebitda_adjusted", "ebitda_reported", "revenue_ttm") if f_ in F and F[f_]["status"] == "verified"] or \
                [{"metric": "formula inputs", "inputs": chain.get("ev_inputs", [])[:12], "weight": None}]
    if variant == "held_at_cost":
        comps = [{"metric": "invested capital", "weight": 1.0}]
    for c_ in comps:
        if c_.get("metric_cell"):
            ws_ = windows.get(c_["metric"], [])
            c_["period_basis"] = ("ttm" if any(w["months"] == 12 for w in ws_) else
                                  "three_year_average" if any(w["months"] == 36 for w in ws_) else
                                  "quarter" if any(w["months"] == 3 for w in ws_) else "not traced")
    used_mult = {c_.get("multiple_cell") for c_ in comps}
    other_mult = [{"field": f_, "cell": ref_str(c_["key"]), "label": c_["label"], "value": c_["value"]}
                  for f_ in ("multiple_ebitda", "multiple_revenue") for c_ in C.get(f_, [])[:1]
                  if c_["score"] >= 6 and ref_str(c_["key"]) not in used_mult and variant not in ("custom_formula", "held_at_cost")]
    NICE = {"ebitda_adjusted": "adjusted_ebitda", "ebitda_reported": "ebitda", "revenue_ttm": "revenue"}
    metric_sources = {}
    for f_ in ("ebitda_adjusted", "ebitda_reported", "revenue_ttm"):
        if f_ in F and not windows.get(f_):
            upf = m.upstream([F[f_]["key"]])
            ext = [k for k in upf if m.f(k) and is_external(m.f(k))]
            if ext:
                metric_sources[f_] = f"reads {len(ext)} cell(s) from linked workbook(s): the monthly data lives outside this workbook"
            elif not any(m.block_of_cell(k) for k in upf):
                metric_sources[f_] = "no monthly or quarterly rows found behind it (typed, or built from annual columns)"
    for c_ in comps:
        if c_.get("metric") in metric_sources and c_.get("period_basis") == "not traced":
            c_["period_basis"] = "linked workbook" if "linked" in metric_sources[c_["metric"]] else "not traced"
    def basis_word(c_):
        pb = c_.get("period_basis")
        nm = NICE.get(c_["metric"], c_["metric"])
        return f"{nm} from linked workbook" if pb == "linked workbook" else f"period not traced: {nm}" if pb in (None, "not traced") else f"{pb}_{nm}"
    metric_basis = [basis_word(c_) for c_ in comps if c_.get("metric_cell")] or \
                   (["held at cost"] if variant == "held_at_cost" else
                    ["EV proven by its own formula; metric period not traced"] if variant in ("custom_formula", "ai_verified_formula") else
                    ["not traced (EV not proven)"])
    # ---- severity and verdict
    # blocking = definitely broken; period conventions (windows, lags) are questions for the analyst, not blocks
    BLOCKING = {"field_not_found", "no_saved_values", "stale_value", "stale_sum", "error_in_chain", "identity_out_of_bounds"}
    if len(calc_lasts) > 1:                          # metrics feeding the same EV end in different months: suspicious
        for f_ in findings:
            if f_["kind"] == "metric_window" and f_.get("info_only"):
                f_["info_only"] = False
                f_["text"] += " (other metrics in this workbook end in a different month)"
    for f_ in findings:
        f_["severity"] = "blocking" if f_["kind"] in BLOCKING else "info" if f_.get("info_only") else "warning"
    unproven = [i["name"] for i in chain["identities"] if i["result"] == "NOT PROVEN"]
    blocking = [f_["text"] for f_ in findings if f_["severity"] == "blocking"]
    warnings = [f_["text"] for f_ in findings if f_["severity"] == "warning"]
    questions_for_analyst = [f_["text"] for f_ in findings if f_["kind"] in ("metric_window", "period_mismatch", "period_unknown")]
    verdict = {"status": "BLOCKED" if blocking else "REVIEW" if (warnings or unproven) else "READY TO ONBOARD",
               "questions_for_analyst": questions_for_analyst,
               "blocking": blocking, "warnings": warnings, "unproven_identities": unproven,
               "note": "a census verdict only; LP numbers are approved only through onboarding and a named approval"}
    liveness = {
        "L1": {"name": "LP values are formulas", "result": "PASS" if not hard else f"{len(hard)} FINDING(S)"},
        "L2": {"name": "typed numbers upstream are raw inputs", "result": "PASS" if not pasted else f"{len(pasted)} PASTED CALCULATION(S)"},
        "L3": {"name": "no external links, manual calculation or errors",
               "result": "PASS" if not [f_ for f_ in findings if f_["check"] == "L3"] else f"{len([f_ for f_ in findings if f_['check'] == 'L3'])} FINDING(S)"},
        "L4": {"name": "Excel recalculation of a copy matches the saved values", "result": "PENDING"},
        "L5": {"name": "Python chain matches Excel",
               "result": f"{sum(1 for i in chain['identities'] if i['result'] in ('PASS', 'BOUNDS OK', 'PASS (formula)'))}/{sum(1 for i in chain['identities'] if i['result'] != 'N/A')} identities"
                         + ("" if not win_rows else ("; metric windows OK" if win_ok else "; METRIC WINDOW FINDING"))
                         + f"; {fchecks['matched']}/{fchecks['recomputed']} LP formulas re-computed"},
    }
    lp_fields = {}
    for f_, rec in sorted(F.items()):
        v = rec["value"]
        lp_fields[f_] = {"cell": ref_str(rec["key"]), "label": rec["label"], "value": v, "is_formula": rec["formula"],
                         "status": rec["status"], "basis": rec["basis"], "aliases": rec["aliases"],
                         "typed_copies": rec.get("typed_copies", []), "alternatives": rec["alternatives"]}
    explain_cells = {}
    for f_, rec in F.items():
        explain_cells[ref_str(rec["key"])] = m.describe(rec["key"])
    for i in items:
        if i["class"] in ("pasted_calculation", "parameter", "fx", "balance"):
            explain_cells.setdefault(i["cell"], m.describe(parse_ref_str(i["cell"])))
    counts = defaultdict(int)
    for i in items:
        counts[i["class"]] += 1
    counts["monthly_lines"] = len(monthly)
    counts["monthly_cells"] = sum(r["months_typed"] for r in monthly.values())
    counts["add_in"] = len(addins)
    return {
        "model": m, "lp_upstream": up,
        "workbook": {"name": os.path.basename(path), "sheets": m.sheets, "calc_mode": m.calc_mode,
                     "fingerprint": m.fingerprint(), "external_link_parts": m.external_link_parts},
        "valuation_date": {k: v for k, v in (vd or {}).items() if not k.startswith("_")} or None,
        "valuation_month": ym_str(val_i) if val_i is not None else None,
        "_val_i": val_i,
        "lp_fields": lp_fields,
        "method": {"variant": variant, "metric_basis": basis, "weights": chain["weights"], "fx_rule": chain["fx_rule"],
                   "ownership_rule": chain["ownership_rule"], "bridge": chain["bridge"]},
        "identities": chain["identities"], "formula_checks": fchecks, "ev_inputs": chain.get("ev_inputs", []),
        "period": period, "method_components": comps, "metric_sources": metric_sources,
        "hypotheses": chain.get("hypotheses", {}), "features": __import__("catalog").features_of(m), "other_multiples": other_mult, "metric_basis_list": metric_basis,
        "error_breakdown": error_breakdown, "verdict": verdict, "skipped_cells": getattr(m, "skipped_cells", {}),
        "workbook_counts": {"scope": "entire workbook", "formulas": len(m._f), "stored_cells": len(m._v),
                            "add_in_cells": len(m.addin_cells()), "external_link_formulas": len(m.external_cells()),
                            "error_cells": len(m.error_cells()), "external_link_parts": m.external_link_parts,
                            "linked_workbooks": getattr(m, "linked_workbooks", []),
                            "cells_not_stored_on_unreferenced_sheets": sum(getattr(m, "skipped_cells", {}).values())},
        "metric_windows": win_rows,
        "blocks": [{"sheet": b["sheet"], "header_row": b["header_row"], "step": b["step"], "first": ym_str(b["months"][0]),
                    "last": ym_str(b["months"][-1]), "months": len(b["months"]), "rows": len(b["rows"])} for b in blocks],
        "monthly_lines": sorted(monthly.values(), key=lambda r: (r["sheet"], r["row"])),
        "inputs": items,
        "input_counts": dict(counts),
        "typed_numbers": {"upstream": typed_up, "untouched": typed_all - typed_up},
        "addins": addins, "externals": externals, "errors": errors, "volatile": volatile,
        "sheets_reached": sheets_reached,
        "liveness": liveness, "findings": findings, "questions": questions,
        "explain_cells": explain_cells,
    }
