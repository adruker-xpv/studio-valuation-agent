# statements.py (build 11) - reads monthly statement packs (layout handling carried over from v6 index_sources.py) and
# maps statement lines to the workbook's monthly rows using the overlap months: EVERY overlap month must match
# (after scale and sign). Coincidences are avoided by matching numbers >= 100 only, and by requiring all months.
import bisect, csv, datetime, os, re
from collections import defaultdict
from openpyxl import load_workbook
from wbutil import (parse_period, parse_date_text, column_role, ym_to_i, ym_str, norm_label, stable_name, file_sha256,
                    is_num, similarity, ref_data, short_id, i_to_ym)

MAT = ref_data("materiality_defaults.json")
MONTH_ONLY = re.compile(r"^(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?$")
_MON = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
HEADING = re.compile(r"\b(as at|as of|ended|ending|period|month|quarter|year)\b")
SCALES = (1, 1000, 1_000_000, 0.001, 0.000001)


def _grids(path):
    if path.lower().endswith(".csv"):
        g = {}
        with open(path, newline="", encoding="utf-8-sig") as fh:
            for r, row in enumerate(csv.reader(fh), 1):
                for c, v in enumerate(row, 1):
                    v = v.strip()
                    if not v:
                        continue
                    try:
                        g[(r, c)] = float(v.replace(",", "").replace("$", "").replace("(", "-").replace(")", ""))
                    except ValueError:
                        g[(r, c)] = v
        yield "csv", g
        return
    wb = load_workbook(path, data_only=True, read_only=True)
    for ws in wb.worksheets:
        g = {}
        for row in ws.iter_rows():
            for c in row:
                if c.value is not None and getattr(c, "row", None):
                    g[(c.row, c.column)] = c.value
        yield ws.title, g


def _txt(v):
    return v.strftime("%Y-%m-%d") if isinstance(v, datetime.datetime) else str(v).strip()


def _sheet_values(fn, sheet, g):
    text_by_col, text_by_row = defaultdict(list), defaultdict(list)
    for (r, c), v in g.items():
        if not is_num(v) and v is not None and _txt(v):
            text_by_col[c].append(r)
            if isinstance(v, str) and not parse_period(v.strip()):
                text_by_row[r].append(c)
    for d in (text_by_col, text_by_row):
        for k in d:
            d[k].sort()
    out, occ = [], defaultdict(int)
    for (r, c) in sorted(k for k, v in g.items() if is_num(v)):
        v = g[(r, c)]
        cols = text_by_row.get(r, [])
        i = bisect.bisect_left(cols, c)
        label = str(g[(r, cols[i - 1])]).strip()[:80] if i else "?"
        rows = text_by_col.get(c, [])
        j = bisect.bisect_left(rows, r)
        parts = [_txt(g[(rr, c)]) for rr in rows[max(0, j - 3):j]]
        role = column_role(" | ".join(parts))
        per = None
        for part in parts[::-1]:
            d = parse_period(part) or (parse_date_text(part) if role in ("current", "prior_year") else None)
            if d:
                per = d
                break
        if per is None and len(parts) > 1 and role in ("current", "prior_year"):
            per = parse_date_text(" ".join(parts))
        bare = bool(parts) and MONTH_ONLY.match(parts[-1].lower().strip())
        if per is None and bare:
            hr = rows[j - 1]
            years = [(cc, int(m_.group(0))) for (rr, cc), vv in g.items() if rr < hr and cc <= c
                     and isinstance(vv, (str, int, float)) and not isinstance(vv, bool)
                     for m_ in [re.fullmatch(r"(19|20)\d{2}", str(vv).strip().split(".")[0])] if m_]
            if years:
                per = (max(years)[1], _MON[parts[-1].lower().strip()[:3]])
        occ[(norm_label(label), c)] += 1
        n = occ[(norm_label(label), c)]
        out.append({"file": fn, "sheet": sheet, "cell": f"{_col(c)}{r}", "label": label,
                    "label_key": label if n == 1 else f"{label} #{n}", "role": role,
                    "period": f"{per[0]}-{per[1]:02d}" if per and role != "variance" else "", "value": float(v),
                    "undated_month_header": bool(bare and per is None)})
    return out


def _col(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def index_files(paths):
    """-> {'files': [...], 'values': [...], 'checks': [...]} for statement files (xlsx/xlsm/csv)."""
    values, finfo, checks = [], [], []
    for f in sorted(paths):
        fn = stable_name(f)
        sheets = list(_grids(f))
        fp = parse_date_text(os.path.splitext(fn)[0])
        fp_src = "file name" if fp else None
        if not fp:
            for _, g in sheets:
                hit = next((parse_date_text(v) for (r, c), v in sorted(g.items())
                            if r <= 8 and isinstance(v, str) and HEADING.search(v.lower()) and parse_date_text(v)), None)
                if hit:
                    fp, fp_src = hit, "sheet heading"
                    break
        dated_sheets = {sh: d for sh, d in ((sh, parse_date_text(sh)) for sh, _ in sheets) if d}
        mine = []
        for sh, g in sheets:
            vals = _sheet_values(fn, sh, g)
            sd = dated_sheets.get(sh) if len(dated_sheets) > 1 else None
            if sd:
                base = re.sub(r"[\s_\-]*(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[\s_\-]*\d*.*$", "", sh.lower())
                for x in vals:
                    x["sheet_key"] = base.strip() or "statement"
                    if not x["period"] and x["role"] in ("current", "ytd", "budget"):
                        x["period"] = f"{sd[0]}-{sd[1]:02d}"
            mine += vals
        header_dates = sorted({x["period"] for x in mine if x["period"]})
        if not fp and len(dated_sheets) > 1:
            fp, fp_src = max(dated_sheets.values(), key=ym_to_i), "latest dated sheet"
        if not fp and header_dates:
            fp, fp_src = parse_period(header_dates[-1]), "latest dated column"
        if fp:
            for x in mine:
                if x.get("undated_month_header"):
                    continue
                if not x["period"] and x["role"] in ("current", "ytd", "budget"):
                    x["period"] = f"{fp[0]}-{fp[1]:02d}"
                elif not x["period"] and x["role"] == "prior_year":
                    x["period"] = f"{fp[0] - 1}-{fp[1]:02d}"
        months = {x["period"] for x in mine if x["period"] and x["role"] == "current"}
        layout = ("sheet per month" if len(dated_sheets) > 1 else "months across columns" if len(months) >= 3
                  else "one period per file" if fp else "unknown dates")
        values += mine
        finfo.append({"name": fn, "sha256": file_sha256(f), "bytes": os.path.getsize(f),
                      "statement_period": f"{fp[0]}-{fp[1]:02d}" if fp else None, "period_source": fp_src,
                      "layout": layout, "roles": sorted({x["role"] for x in mine}), "numbers": len(mine)})
        if not fp and not months:
            checks.append(f"{fn}: no date found (file name, heading, sheet names or column headers); its numbers are not used")
    return {"files": finfo, "values": values, "checks": checks}


ENTITY_NOISE = re.compile(r"\b(financial|financials|statements?|fs|monthly|month|pack|package|report|reports|management|accounts?|"
                          r"ended|ending|as|at|of|for|the|q[1-4]|fy\d*|ytd|v\d+|final|draft|"
                          r"jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec|january|february|march|april|june|july|august|"
                          r"september|october|november|december)\b|\d+", re.I)


def entity_of(fname):
    """the entity a statement file belongs to, from its name: 'EntityB_Financial_Statements_June_30__2026' -> 'entityb'."""
    stem = re.sub(r"[_\-\.]+", " ", os.path.splitext(os.path.basename(fname))[0].lower())
    return " ".join(ENTITY_NOISE.sub(" ", stem).split()) or "statements"


def build_series(values):
    """(sheet, label, role) -> {month_index: value entry}. The file whose statement period IS the month wins."""
    series = {}
    for v in values:
        p = parse_period(v.get("period")) if v.get("period") else None
        if not p:
            continue
        i = ym_to_i(p)
        key = (entity_of(v["file"]), v.get("sheet_key") or v["sheet"], v["label_key"], v["role"])
        series.setdefault(key, {})
        old = series[key].get(i)
        if old is None or (parse_date_text(os.path.splitext(v["file"])[0]) == p):
            series[key][i] = v
    # monthly values from year-to-date columns where a month column is missing
    for (ent, sh, lab, role), s in list(series.items()):
        if role != "ytd":
            continue
        cur = series.setdefault((ent, sh, lab, "current"), {})
        for i in sorted(s):
            if i in cur:
                continue
            prev = s.get(i - 1)
            if i_to_ym(i)[1] == 1:
                cur[i] = dict(s[i], derived="ytd (first month of year)")
            elif prev is not None:
                cur[i] = dict(s[i], value=s[i]["value"] - prev["value"], derived="ytd difference")
    return series


def line_map(model, monthly_lines, index, val_i):
    """monthly_lines: analysis['monthly_lines'] (typed rows upstream of the LP row).
    -> (entries, stats, questions)"""
    series = {k: s for k, s in build_series(index["values"]).items() if k[3] == "current"}
    stmt_months = sorted({i for s in series.values() for i in s})
    stmt_set = set(stmt_months)
    rows = {r["line"]: r for b in model.blocks() for r in b["rows"]}
    entries, questions = [], []
    tol_min = MAT["line_match_min_abs_value"]
    # entity sheets: 'Entity A Monthly' belongs to the 'entitya' statements. A sibling sheet ('Entity B Monthly') whose
    # entity sent no statements is never matched to another entity's lines.
    ents = sorted({k[0] for k in series})
    squash = lambda t: re.sub(r"[^a-z0-9]", "", str(t).lower())
    block_sheets = sorted({r["line"].split("|", 1)[0] for r in rows.values()})
    sheet_ent = {sh: [e for e in ents if squash(e) and squash(e) in squash(sh)] for sh in block_sheets}
    matched = [sh for sh, es in sheet_ent.items() if es]
    missing_ent = {sh for sh, es in sheet_ent.items() if not es and matched and any(similarity(sh, m_) >= 0.5 for m_ in matched)}
    for ml in monthly_lines:
        row = rows.get(ml["line"])
        if not row:
            continue
        sh_ = ml["line"].split("|", 1)[0]
        if sh_ in missing_ent:
            entries.append({"line": ml["line"], "label": ml["label"], "adjustment": bool(ml.get("adjustment")), "statement": None,
                            "evidence": "entity_statements_missing", "proposals": []})
            continue
        allowed = set(sheet_ent.get(sh_) or ents)
        bvals = {i: model.v(k) for i, k in row["cells"].items() if is_num(model.v(k)) and not model.is_formula(k)}
        step = row.get("step", 1) or 1
        ops = ("value_at",) if step == 1 else ("sum_3", "value_at")      # quarterly rows: flows sum 3 months, balances do not
        overlap = sorted(i for i in bvals if i in stmt_set or (step == 3 and all(i - j in stmt_set for j in range(3))))
        matches = []
        for key, s in series.items():
            if key[0] not in allowed:
                continue
            for op in ops:
                def sv(i, s=s, op=op):
                    if op == "value_at":
                        return s[i]["value"] if i in s else None
                    parts = [s.get(i - j) for j in range(3)]
                    return sum(p["value"] for p in parts) if all(parts) else None
                ov = [i for i in overlap if sv(i) is not None]
                if not ov or max(abs(bvals[i]) for i in ov) < tol_min:
                    continue
                hit = None
                for k_ in SCALES:
                    for sign in (1, -1):
                        if all(abs(bvals[i] - sign * k_ * sv(i)) <= max(0.5 * max(k_, 1) * (3 if op == "sum_3" else 1), 1e-6 * abs(bvals[i])) for i in ov):
                            hit = (k_, sign)
                            break
                    if hit:
                        break
                if hit:
                    matches.append((len(ov), similarity(ml["label"], key[2]), key, hit[0], hit[1], ov, op))
                    break
        e = {"line": ml["line"], "label": ml["label"], "adjustment": bool(ml.get("adjustment")), "workbook_months": [ym_str(min(bvals)), ym_str(max(bvals))] if bvals else None,
             "overlap_months": [ym_str(i) for i in overlap]}
        if matches:
            matches.sort(key=lambda t: (-t[0], -t[1], t[2]))
            n, sim, key, k_, sign, ov, op = matches[0]
            rivals = [t for t in matches[1:] if t[0] == n and t[2] != key]
            e.update({"statement": {"sheet": key[1], "label": key[2], "entity": key[0]}, "scale": k_, "sign": sign, "operation": op,
                      "months_matched": [ym_str(i) for i in ov],
                      "evidence": "matched_all_overlap_months" if n >= 2 else "single_period",
                      "rivals": [{"sheet": t[2][1], "label": t[2][2], "entity": t[2][0]} for t in rivals[:3]]})
        else:
            props = sorted(((similarity(ml["label"], key[2]), key) for key in series if key[0] in allowed), key=lambda t: (-t[0], t[1]))
            props = [p for p in props if p[0] >= 0.34][:3]
            e.update({"statement": None, "evidence": ("adjustment_rows" if ml.get("adjustment") else "no_overlap" if not overlap else
                                                      "title_only" if props else "no_source"),
                      "proposals": [{"sheet": k[1], "label": k[2], "entity": k[0], "similarity": round(sc, 2)} for sc, k in props]})
            if props and overlap and not ml.get("adjustment"):
                diffs = []
                k0 = props[0][1]
                pts = [i for i in overlap if i in series[k0] and step == 1]
                best_k = max(SCALES, key=lambda k_: (sum(1 for i in pts if abs(bvals[i] - k_ * series[k0][i]["value"]) <= 0.5 * max(k_, 1)), -abs(k_ - 1)))
                for i in pts:
                    diffs.append({"month": ym_str(i), "workbook": bvals[i], "statement": series[k0][i]["value"], "scale": best_k,
                                  "matches": abs(bvals[i] - best_k * series[k0][i]["value"]) <= 0.5 * max(best_k, 1)})
                questions.append({"id": short_id("Q", {"line": ml["line"]}), "type": "line_map", "line": ml["line"],
                                  "prompt": f"Workbook row '{ml['label']}' did not match any statement line on every overlap month. "
                                            f"Which statement line feeds it? (numbers that differ are shown)",
                                  "options": {chr(97 + j): {"sheet": k[1], "label": k[2], "entity": k[0], "similarity": round(sc, 2)} for j, (sc, k) in enumerate(props)},
                                  "differences": diffs[:3]})
        entries.append(e)
    stats = defaultdict(int)
    for e in entries:
        stats[e["evidence"]] += 1
    return entries, dict(stats), questions, stmt_months


def period_gate(stmt_months, block_months, val_i):
    """-> (ok, message, mode). Statements from a later quarter than the workbook stop onboarding (the v7 failure)."""
    if not stmt_months:
        return True, "no statements given: line map by titles only (refresh will ask for one quarter of statements)", "no_statements"
    S, B = set(stmt_months), set(block_months)
    if S & B:
        ov = sorted(S & B)
        note = "" if val_i in S else f"; the valuation month {ym_str(val_i)} is not in the statements" if val_i is not None else ""
        return True, f"overlap months {ym_str(ov[0])}..{ym_str(ov[-1])} ({len(ov)}){note}", "overlap"
    if val_i is not None and min(S) > val_i:
        want = [ym_str(val_i - 2), ym_str(val_i)]
        return False, (f"the statements are for {ym_str(min(S))}..{ym_str(max(S))} but the workbook is valued at {ym_str(val_i)}. "
                       f"For onboarding, upload the statements for the workbook's own quarter ({want[0]}..{want[1]}); "
                       f"keep the later statements for the first refresh"), "stopped"
    return True, (f"no month in the statements ({ym_str(min(S))}..{ym_str(max(S))}) is in the workbook's monthly rows: "
                  "line map by titles only"), "no_overlap"
