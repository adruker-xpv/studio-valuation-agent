---
name: valuation-pipeline
description: XPV valuation pipeline, build 11.2. Finds a portfolio company's files in the knowledge sources (valuation workbooks, financial statements, monthly summaries), maps how its LP numbers are built, records a named approval, files the user's documents and facts, explains any number, and shows how other companies structure things. Use for any request to onboard, map, check, approve, explain, file, or find files for a portfolio company's valuation, or to run the pipeline self-test.
---

# Valuation pipeline (build 11.2)

`scripts/pipeline.py` does all the work. Run ONE command at a time and do exactly what its printed lines say.
Never open, read, summarise or check workbooks yourself; never calculate numbers; never run other scripts.

## Glossary
| Term | Meaning |
|---|---|
| Limited partner (LP) report | XPV's quarterly investor report; the pipeline works back from each company's LP numbers |
| Mapping | Onboarding: understanding how the approved workbook turns statements into the LP numbers |
| Company file | `<company_id>_company.zip`: one company's map, facts, evidence and approvals (saved to SharePoint) |
| Knowledge sources | Valuation Workbooks, Company Financial Statements, Monthly Summaries, LP_reports |

## Playbook A - "Onboard <company> for <quarter>" (the main job)
1. **Search knowledge:**
   - *Valuation Workbooks*: "<company> <quarter> valuation workbook" and "<company> <previous quarter> valuation workbook";
   - *Company Financial Statements*: "<company> <month> <year>" for each of the quarter's three months;
   - *Monthly Summaries*: "<company> monthly summary <quarter>".
2. **Gather:** `python scripts/pipeline.py gather --company "<company>" --quarter "<quarter>"`
3. **Fill gaps, at most twice:** for each `NEED:` line, run exactly the search it names, then gather again.
4. **Onboard:** run the `THEN:` command gather printed, unchanged.
5. **Follow the printed lines** until `READINESS:` (JUDGMENT NEEDED, SHAREPOINT, RECALC, THEN).
6. **Report:** post from `ONBOARD:` to `READINESS:` unchanged. Then ONE message: ask for anything still under `NEED:`, and "Reply 'approve as <your name>' with any corrections."
7. **Approve** only when the user's latest message approves (command below).

## Playbook B - from the user
- **Files** uploaded or linked: `add --files "<name>" ... --company "<company>" --by "<user's name>"`; post the INTAKE lines.
- **A fact or number** they state (acquisition, new loan, cap table change): after onboarding, `add --company "<company>" --fact "<what it is>" --value "<the number exactly as said>" --by "<name>" --said "<their exact words>"`. Never calculate, convert or infer it.
- **"How did other companies handle <acquisitions / pro forma / waterfalls>?"**: search *Valuation Workbooks* for that word, then `reference --feature <acquisition|pro_forma|waterfall|cap_table|linked_workbooks|quarter_named_sheets> --workbooks "<names found>"` (up to 5). Post it as structure to consider; never copy numbers between companies.
- **"What do we have for <company>?"**: `status --company "<company>"`. **"Where does this number come from?"**: `explain`.

## Commands
| Job | Command |
|---|---|
| Self-test | `python scripts/pipeline.py selftest` |
| Choose a company's files | `python scripts/pipeline.py gather --company "<company>" --quarter "<Q2 2026>"` |
| Onboard | the `THEN:` line gather printed |
| Valuation date stated by the user | add `--period-end YYYY-MM-DD` to the onboard command |
| Answer a judgment (after exit 10) | re-run the SAME command adding `--answers '<one-line JSON>'` |
| After the Excel step | the `THEN:` command printed; if Run script failed, the `IF RUN SCRIPT FAILS:` command |
| Approve | `python scripts/pipeline.py approve --company "<company_id>" --by "<approver's name>" [--changes '<JSON {"A-id": "the user's correction"}>'] --said "<the user's exact words>"` |
| Explain | `python scripts/pipeline.py explain "<A-id, field name or Sheet!Cell>" --company "<company_id>"` |
| Status | `python scripts/pipeline.py status --company "<company>"` |
| File the user's files | `python scripts/pipeline.py add --files "<name>" ... --company "<company>" --by "<name>"` |
| Record a stated fact | `python scripts/pipeline.py add --company "<company>" --fact "<what>" --value "<as stated>" --by "<name>" --said "<exact words>"` |
| Other companies' structure | `python scripts/pipeline.py reference --feature <feature> --workbooks "<name>" ...` |
| Portfolio overview (only when asked) | `python scripts/pipeline.py census --workbooks "<name>" ...` |

Pass files **by name**, exactly as fetched or uploaded (no folder path). The script finds them.

## Printed lines (your interface)
| Line starts with | What you do |
|---|---|
| `GATHER:` `ONBOARD:` `CENSUS:` `READING:` `BUILD:` `TRACE:` `LEARNED:` `HAVE:` `REFERENCE:` `INTAKE:` `STATUS:` `METHOD:` `LP FIELDS:` `LIVENESS:` `INPUTS:` `LINE MAP:` `REVIEW:` `PERIOD GATE:` `STATEMENTS:` `FILE:` `CHECK:` `VERSION:` | Part of the report: post unchanged when NEXT says so |
| `NEED:` `OPTIONAL:` | In gather: search for exactly what it names. Elsewhere: ask the user for NEED items in one message after the report |
| `SHAREPOINT: Create new folder` | SharePoint *Create new folder* with that library and path; if it exists, continue |
| `SHAREPOINT: Create file` | SharePoint *Create file* with that folderPath and name; the body is the printed `/app/created/...` path, never file content or base64 |
| `SHAREPOINT: SKIP` | Do not save that file; give it to the user as a download |
| `RECALC:` | *Run script from SharePoint library* ONCE on the file whose Id Create file returned, with the printed `cells` text copied exactly (do not retype or re-quote it). `RECALC: skipped (...)` means there is no Excel step: carry on |
| `RECALC RULES:` | Obey it: if Run script fails, times out or returns an error, run the `IF RUN SCRIPT FAILS:` command at once. Never retry Run script |
| `THEN:` | Run that command exactly; for the Excel step, pass the Run script result exactly as returned between the JSON markers |
| `IF RUN SCRIPT FAILS:` | Only if Run script failed or timed out: run that command with the error text exactly as returned |
| `JUDGMENT NEEDED` | Answer each `Q-` item (rules below), then re-run with `--answers` |
| `READINESS:` `APPROVED:` `EXPLAIN:` `ALL SELFTESTS:` | Post unchanged |
| `STOPPED:` | Tell the user exactly what it says and stop. Save nothing |
| `PIPELINE ERROR:` | Report it exactly and stop; if it names a missing file, search knowledge for it once, else ask the user |
| `NEXT:` | The instruction for the rest of your turn. Follow it literally |

Exit codes: 0 done (follow NEXT) | 10 JUDGMENT NEEDED | 20 waiting for a tool step | 3 STOPPED (the user must act) | 1 error.

## Answering JUDGMENT NEEDED
- **Choice items** list options `a)`, `b)`... Choose the option whose label and position fit best; for line-map items prefer the statement line with the same meaning (revenue with revenue, cash with cash). Answer `"none"` if nothing fits.
- **Calculation items** show a `target`, its formula and labelled `input` cells. Answer with the cells that reproduce the target: `{"op": "sum", "terms": [["Valuation!B21", 1], ["Valuation!B22", 1], ["Valuation!B23", -1]]}` (or `"op": "product"`, where -1 divides). Use only printed cells or cells in the formula. Python checks it against Excel's value; a wrong one is rejected and shown to the analyst.
- All items in ONE line of JSON: `{"Q-1a2b3c4d": "a", "Q-5e6f7a8b": {"op": "sum", "terms": [...]}}`. Never invent cells or numbers.

## Rules
- Knowledge is only for fetching files for the scripts; never for answering valuation questions or quoting numbers.
- One company per conversation; approve in the same conversation (the company file is not in knowledge).
- Uploads (20 per conversation) only for files not in SharePoint.
- Quarterly generation (refresh) is not in build 11.2: say so if asked.
