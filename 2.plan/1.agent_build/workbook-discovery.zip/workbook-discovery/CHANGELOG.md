# Changelog – workbook-discovery

## 11.5.0 – hardening and foundations
- **Pre-flight** (`common/preflight.py`): empty, legacy `.xls`, encrypted / password-protected, `.xlsb`, damaged, non-workbook
  and oversized files are refused with one `PREFLIGHT: REFUSED` line naming the fix (exit 3), before any parsing.
- **Files by name** (`common/files.py`): inputs are found where knowledge files and uploads land; two different files with one
  name stop the run; outputs go under `/app/created`.
- **Error taxonomy**: exit 0 done | 1 internal error (one line; traceback in `run_error.log` / `bench_error.log`) | 2 usage |
  3 STOPPED (the user must act).
- **Rules as data** (`references/discovery_rules.json`, validated at start-up); the map records the rule-file hashes and the
  benchmark reports a changed hash as a method change.
- **Invariant registry** (`references/invariants.json`, `discovery/invariants.py`): eight consistency checks with per-company
  profiles; reported as "consistency, not truth" (test I.3 shows why).
- **Schemas** (`common/schema.py`) for the answer key and blind answers.
- **Vendored 11.3 code** adapted in one place (`discovery/vp_adapter.py`), still byte-identical.
- **Coverage**: small formula-free areas nothing refers to are now read completely (Layer 0 complete); a corrupt named range
  is flagged MISSING; a stale EV is caught even when the method cannot be proven.
- **Run log** (`run_log.json`): timings, peak memory, versions - outside the deterministic map.
- **Release** only through `tools/release.py` (tests, package check, zip, `RELEASE_MANIFEST.json`).
- Tests: 26 → 37 (P, I, E, S, R, C families added).

## 11.4.0 – discovery and benchmark, milestone 1
- Layer 0 / 1 / 2 discovery with graph-status flags, regions, sinks, period evidence, terminals; separate benchmark system with
  blind answer key, frozen physical sample, Excel facts script, scorer, regression and sanitised output. 26 tests.
