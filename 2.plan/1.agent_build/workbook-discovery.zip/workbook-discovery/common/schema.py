# common/schema.py (build 11.5) - minimal, dependency-free validation of the JSON contracts (answer key, blind answers,
# map summary). A spec is {key: type | (type, ...) | spec-dict | [item-spec]}; keys ending in '?' are optional.
from common.util import Stop


def _check(obj, spec, path, errors):
    if isinstance(spec, dict):
        if not isinstance(obj, dict):
            errors.append(f"{path or 'document'} must be an object")
            return
        for k, sub in spec.items():
            opt = k.endswith("?")
            kk = k.rstrip("?")
            if kk not in obj:
                if not opt:
                    errors.append(f"{path + '.' if path else ''}{kk} is missing")
                continue
            _check(obj[kk], sub, f"{path + '.' if path else ''}{kk}", errors)
    elif isinstance(spec, list):
        if not isinstance(obj, list):
            errors.append(f"{path} must be a list")
            return
        for i, x in enumerate(obj):
            _check(x, spec[0], f"{path}[{i}]", errors)
    elif spec is not None and not isinstance(obj, spec):
        errors.append(f"{path} has the wrong type ({type(obj).__name__})")


def validate(obj, spec, what):
    errors = []
    _check(obj, spec, "", errors)
    if errors:
        raise Stop(f"the {what} is not valid: " + "; ".join(errors[:8]) + (" ..." if len(errors) > 8 else ""), "invalid_document")
    return obj


PROV = str
ENTRY = {"provenance": PROV}
ANSWER_KEY = {"schema": str, "key_version": str, "gold_id": str, "workbook": {"name": str, "sha256": str}, "requested_period": str,
              "created_on": str, "created_by": str, "blind_frozen_at": str, "blind_sha256": str, "sha256": str,
              "physical_structure": {"worksheets": int, "sheet_names": [str], "formula_cells": int, "populated_cells": int, "errors": int,
                                     "per_sheet": dict, "defined_names?": (int, type(None)), "tables?": (int, type(None)),
                                     "external_links?": (int, type(None))},
              "important_outputs": dict, "junctions": dict, "required_workbook_regions": [dict], "known_irrelevant_regions": [dict],
              "confirmed_dependency_samples": [{"id": str, "cell": str, "period": str, "kind": str, "provenance": PROV}]}
BLIND = {"schema": str, "gold_id": str, "workbook": str, "workbook_sha256": str, "requested_period": str, "frozen_by": str,
         "frozen_at": str, "junctions": dict, "regions": [dict], "sample": [dict], "sha256": str}
