# common/util.py (build 11.5) - low-level helpers shared by DISCOVERY and BENCHMARK: deterministic JSON, hashing, the
# controlled clock, and cell-reference arithmetic. Nothing here decides what a workbook contains or means.
# The benchmark may import ONLY this module from the package (test B.1 enforces it).
import datetime, gzip, hashlib, io, json, os, re

VERSION = "11.5.0"

# Exit codes (the agent's contract; documented in SKILL.md)
EXIT_OK, EXIT_INTERNAL, EXIT_USAGE, EXIT_STOPPED = 0, 1, 2, 3


class Stop(Exception):
    """the user must act (a missing or unreadable file, a hash mismatch, a changed key...). Printed as one STOPPED: line,
    exit code 3. Never used for bugs: those are internal errors (exit 1)."""
    def __init__(self, message, category="user_action"):
        super().__init__(message)
        self.category = category


def now():
    """the only clock. VALUATION_NOW (ISO datetime) makes runs reproducible."""
    s = os.environ.get("VALUATION_NOW")
    return datetime.datetime.fromisoformat(s) if s else datetime.datetime.now().replace(microsecond=0)


def canon(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def dump(obj, path):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=1, sort_keys=True, ensure_ascii=False, default=str)
        fh.write("\n")
    return path


def load(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def write_jsonl_gz(rows, path):
    """deterministic: sorted keys, fixed gzip timestamp."""
    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode="wb", mtime=0) as gz:
        for r in rows:
            gz.write((canon(r) + "\n").encode("utf-8"))
    with open(path, "wb") as fh:
        fh.write(buf.getvalue())
    return path


def read_jsonl_gz(path):
    with gzip.open(path, "rt", encoding="utf-8") as fh:
        for line in fh:
            if line.strip():
                yield json.loads(line)


# ------------------------------------------------------------------------------------------------ cell references
def col_idx(s):
    n = 0
    for ch in s.upper():
        n = n * 26 + (ord(ch) - 64)
    return n


def col_let(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


MAX_ROW, MAX_COL = 1048576, 16384
_ADDR = re.compile(r"^\$?([A-Za-z]{1,3})\$?(\d+)(?::\$?([A-Za-z]{1,3})\$?(\d+))?$")
_COLS = re.compile(r"^\$?([A-Za-z]{1,3}):\$?([A-Za-z]{1,3})$")
_ROWS = re.compile(r"^\$?(\d+):\$?(\d+)$")


def split_sheet(text):
    """"'My Sheet'!A1:B2" -> ("My Sheet", "A1:B2"); "A1" -> (None, "A1")."""
    t = text.strip()
    if "!" not in t:
        return None, t
    sh, _, a = t.rpartition("!")
    sh = sh.strip()
    if sh.startswith("'") and sh.endswith("'"):
        sh = sh[1:-1].replace("''", "'")
    return sh, a.strip()


def parse_box(text, default_sheet=None):
    """address text -> (sheet, r1, c1, r2, c2) or None. Cells, ranges, whole columns and whole rows."""
    sh, a = split_sheet(text)
    sh = sh or default_sheet
    m = _ADDR.match(a)
    if m:
        c1, r1 = col_idx(m.group(1)), int(m.group(2))
        c2, r2 = (col_idx(m.group(3)), int(m.group(4))) if m.group(3) else (c1, r1)
        return (sh, min(r1, r2), min(c1, c2), max(r1, r2), max(c1, c2))
    m = _COLS.match(a)
    if m:
        c1, c2 = sorted((col_idx(m.group(1)), col_idx(m.group(2))))
        return (sh, 1, c1, MAX_ROW, c2)
    m = _ROWS.match(a)
    if m:
        r1, r2 = sorted((int(m.group(1)), int(m.group(2))))
        return (sh, r1, 1, r2, MAX_COL)
    return None


def quote_sheet(sheet):
    return f"'{sheet.replace(chr(39), chr(39) * 2)}'" if re.search(r"[^A-Za-z0-9_]", sheet) else sheet


def box_text(box):
    sh, r1, c1, r2, c2 = box
    a = f"{col_let(c1)}{r1}" + ("" if (r1, c1) == (r2, c2) else f":{col_let(c2)}{r2}")
    return f"{quote_sheet(sh)}!{a}"


def cell_text(sheet, r, c):
    return f"{quote_sheet(sheet)}!{col_let(c)}{r}"


def cell_key(text, default_sheet=None):
    b = parse_box(text, default_sheet)
    if not b or (b[1], b[2]) != (b[3], b[4]):
        raise ValueError(f"not a single cell: {text!r}")
    return (b[0], b[1], b[2])


def box_cells(box, limit=200_000):
    """every address in a box (bounded)."""
    sh, r1, c1, r2, c2 = box
    if (r2 - r1 + 1) * (c2 - c1 + 1) > limit:
        return None
    return {(sh, r, c) for r in range(r1, r2 + 1) for c in range(c1, c2 + 1)}


def split_addresses(text):
    """Excel's 'Sheet1!A1:A3, Sheet1!B5' or a list -> list of address strings (quote-aware)."""
    if isinstance(text, list):
        out = []
        for t in text:
            out += split_addresses(t)
        return out
    out, cur, q = [], "", False
    for ch in str(text or ""):
        if ch == "'":
            q = not q
        if ch == "," and not q:
            out.append(cur.strip())
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out
