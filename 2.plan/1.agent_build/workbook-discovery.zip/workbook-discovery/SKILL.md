---
name: workbook-discovery
description: XPV workbook discovery and benchmark, build 11.5 (milestone 1). Reads one approved historical (Gold) valuation workbook without changing it, maps what it physically contains, how its formulas connect, what periods they represent and where every path ends, checks its internal consistency (invariants); then grades that map against an independent, analyst-made answer key. Use for "run discovery", "build the Gold answer key", "score the benchmark", or "run the discovery tests". Never generates or updates a valuation.
---

# Workbook discovery and benchmark (build 11.5)

Two separate systems in one skill. **Discovery** (`discovery/discover.py`) reads a workbook and writes its map.
**Benchmark** (`benchmark/bench.py`) builds the Gold answer key and grades a map against it. Run ONE command at a time.
Never open, read, summarise or quote workbooks, maps, keys or reports yourself.

## Glossary
| Term | Meaning |
|---|---|
| Gold workbook | A frozen, approved historical valuation workbook, hash-locked, used only for benchmarking |
| Map | Discovery's output folder: `workbook_map.json`, `cells.jsonl.gz`, `discovery_review.xlsx`, `run_log.json` (private) |
| Answer key | The analyst's independent, frozen expected answers (`answer_key_<gold id>_<version>.json`, private) |
| Blind | Answered by the analyst before any discovery output exists |
| Invariant | A consistency check on the workbook (e.g. EV = multiple x metric). Not ground truth |

Pass every file **by name** exactly as fetched or uploaded; the scripts find it. Output folders are created under
`/app/created`, so their files can be offered as downloads.

## Playbook A – "Run discovery on <workbook> for <quarter end>"
1. Fetch the workbook from *Valuation Workbooks* (or the user uploads it).
2. `python discovery/discover.py --workbook "<file name>" --period-end <YYYY-MM-DD> --out "map_<gold id>"` (add `--profile <name>` only if the user names an invariant profile).
3. Post the `PREFLIGHT:` and `DISCOVERY:` lines unchanged. Offer `discovery_review.xlsx` as a download (private).

## Playbook B – building the Gold answer key (one step per request)
| User says | Command |
|---|---|
| "Hash the Gold workbook" | `python benchmark/bench.py hash --workbook "<file>"` |
| "Make the answer-key template for <gold id>" | `python benchmark/bench.py template --workbook "<file>" --gold-id <id> --period-end <YYYY-MM-DD> --out "gold_key_<id>.xlsx"` |
| "Draw the sample" | `python benchmark/bench.py sample --workbook "<file>" --template "gold_key_<id>.xlsx"` (offer both files back) |
| "Freeze the blind answers" (filled template uploaded) | `python benchmark/bench.py freeze-blind --template "<filled file>" --by "<analyst's name>" --out "blind_<id>.json"` |
| "Build the answer key" (blind file, Excel facts, filled review uploaded) | `python benchmark/bench.py key --blind "blind_<id>.json" --workbook "<file>" --facts "<counts json>" "<precedents json>" --review "<filled review>" --map-meta "map_<id>/workbook_map.json" --by "<name>" --out "answer_key_<id>_v1.json"` |

**Never run discovery for a Gold workbook before its blind answers are frozen.** If the user asks, say so and stop.

## Playbook C – "Score the benchmark" (every build)
1. Run Playbook A for the Gold workbook.
2. `python benchmark/bench.py score --map "map_<id>" --key "<answer key>" [--previous "<last benchmark_result.json>"] [--other-gold "<other Gold's result>"] --out "bench_<id>"`
3. Post the `BENCHMARK:` lines unchanged. Offer `benchmark_result.json` (keep for `--previous` next time) and `benchmark_report.md` (private).
Add `--redact-counts` if the user asks for results without numbers.

## Tests
`python tests/run_tests.py` – synthetic discovery and benchmark tests. Expected: `ALL TESTS: PASS (37/37)`.

## Printed lines and exit codes
| Line | What you do |
|---|---|
| `PREFLIGHT:` | `OK`: continue. `REFUSED`: tell the user exactly what it says (it names the fix) and stop |
| `DISCOVERY:` `BENCHMARK:` `ALL TESTS:` | post unchanged – they contain only counts and categories |
| `STOPPED:` | tell the user exactly what it says; do nothing else |
| `DISCOVERY ERROR:` `BENCHMARK ERROR:` | a bug, not a data problem: post the line unchanged, offer `run_error.log` / `bench_error.log`, and stop |
| `NEXT:` | follow it literally |

Exit codes: 0 done | 1 internal error (a bug) | 2 usage (a mistyped command: check it against this file) | 3 STOPPED (the user must act).

## Rules
- Maps, answer keys, the review workbook and benchmark reports are private: never quote cells, sheet names or values from them.
- Never edit an answer key or blind-answers file; the scripts refuse changed files.
- Never retry a command that printed `STOPPED:` or an error line; tell the user.
- This skill never generates, updates or values anything.
