# tests/run_tests.py (build 11.5) - discovery and benchmark tests on synthetic workbooks, run through the command lines
# exactly as the agent runs them. D = discovery, B = benchmark, M = mutation (layout changes must not break meaning;
# P = pre-flight and file handling, I = invariants, E = errors, C = contracts and hygiene, S = schemas, R = rules;
# real changes must be caught), V = the vendored build 11.3 code is unchanged. Keys used here are written from what each
# fixture's author knows - never from discovery's output.
import ast, datetime, glob, hashlib, json, os, re, shutil, subprocess, sys, tempfile, traceback
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path[:0] = [HERE, os.path.join(PKG, "discovery", "vp"), PKG, os.path.join(PKG, "benchmark")]
import vp_fixtures as FX
import dfixtures as DF
from common.util import read_jsonl_gz, load, sha256_file, cell_text, canon, sha256_text
import xmlcount as XC

DISC = os.path.join(PKG, "discovery", "discover.py")
BENCH = os.path.join(PKG, "benchmark", "bench.py")
ROOT = tempfile.mkdtemp(prefix="wd_tests_")
NOW = "2026-10-08T12:00:00"
RESULTS, TESTS = [], []


def env(now=NOW):
    return dict(os.environ, VALUATION_NOW=now, PYTHONDONTWRITEBYTECODE="1")


def run(script, args, cwd, now=NOW):
    p = subprocess.run([sys.executable, script] + args, cwd=cwd, env=env(now), capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


def case(name):
    d = os.path.join(ROOT, re.sub(r"[^A-Za-z0-9]+", "_", name))
    os.makedirs(d)
    return d


def discover(d, wb, pe, out="map", now=NOW):
    rc, o = run(DISC, ["--workbook", wb, "--period-end", pe, "--out", out], d, now)
    assert rc == 0, o
    return o, load(os.path.join(d, out, "workbook_map.json")), {r["cell"]: r for r in read_jsonl_gz(os.path.join(d, out, "cells.jsonl.gz"))}


def test(name):
    def deco(fn):
        def w():
            try:
                fn()
                RESULTS.append((name, True, ""))
            except AssertionError as e:
                RESULTS.append((name, False, str(e)[:700]))
            except Exception as e:
                RESULTS.append((name, False, f"{type(e).__name__}: {e}\n{traceback.format_exc()[-900:]}"))
        TESTS.append(w)
        return w
    return deco


def has(text, *needles):
    for n in needles:
        assert n in text, f"expected {n!r} in:\n{text[-2000:]}"


def structures(name):
    d = case(name)
    DF.structures_workbook(os.path.join(d, "S.xlsx"))
    return (d,) + discover(d, "S.xlsx", "2025-12-31")


def xml_physical(path):
    """stand-in for Excel's own counts in tests: the standard-library checker (for Gold, gold-facts.ts provides them)."""
    x = XC.scan(path)
    return {"source": "test stand-in (xmlcount)", "worksheets": len(x["sheets"]), "sheet_names": [s["name"] for s in x["sheets"]],
            "formula_cells": x["totals"]["formulas"], "populated_cells": x["totals"]["populated"], "errors": x["totals"]["errors"],
            "defined_names": x["defined_names"], "tables": x["tables"], "external_links": x["external_links"],
            "per_sheet": {s["name"]: {"formulas": s["formulas"], "populated": s["populated"], "errors": s["errors"]} for s in x["sheets"]}}


def make_key(d, wb, outputs, junctions=None, required=(), irrelevant=(), samples=(), pe="2026-03-31", gid="GOLD-T1", version="v1"):
    key = {"schema": "gold-answer-key/1", "key_version": version, "gold_id": gid,
           "workbook": {"name": wb, "sha256": sha256_file(os.path.join(d, wb))}, "requested_period": pe, "created_on": NOW,
           "created_by": "test author", "blind_frozen_at": "2026-10-01T00:00:00", "blind_sha256": "test",
           "physical_structure": xml_physical(os.path.join(d, wb)),
           "important_outputs": {k: {"cell": v, "provenance": "blind"} for k, v in outputs.items()},
           "junctions": {k: ({"cell": v, "provenance": "blind"} if "!" in str(v) else {"value": v, "provenance": "blind"}) for k, v in (junctions or {}).items()},
           "required_workbook_regions": [dict(r, provenance="blind") for r in required],
           "known_irrelevant_regions": [dict(r, provenance="blind") for r in irrelevant],
           "confirmed_dependency_samples": [dict(s, provenance="blind") for s in samples]}
    key["sha256"] = sha256_text(canon(key))
    p = os.path.join(d, f"key_{gid}_{version}.json")
    json.dump(key, open(p, "w"))
    return os.path.basename(p)


def factory_key(d, wb, vals, sheet="Valuation Summary", **kw):
    q = f"'{sheet}'" if " " in sheet else sheet
    c = vals[(2026, 3)]["col"]
    return make_key(d, wb, {"enterprise_value": f"{q}!{c}11", "equity_value": f"{q}!{c}14", "value_to_xpv": f"{q}!{c}16"},
                    {"valuation_metric": f"{q}!{c}8", "selected_multiple": f"{q}!{c}10", "metric_period": "2026-03",
                     "metric_window_first": "2025-04", "metric_window_last": "2026-03", "method": "ev_ebitda"}, **kw)


def score(d, keyf, mapdir="map", extra=()):
    rc, o = run(BENCH, ["score", "--map", mapdir, "--key", keyf, "--out", "bench_" + mapdir, *extra], d)
    res = load(os.path.join(d, "bench_" + mapdir, "benchmark_result.json")) if rc == 0 else None
    return rc, o, res


# ------------------------------------------------------------------------------------------------ D discovery
@test("D.1 physical inventory equals the independent standard-library checker (shared formulas, spill, table, links)")
def d1():
    d, o, M, C = structures("d1")
    rc, out = run(BENCH, ["physical", "--workbook", "S.xlsx", "--map", "map"], d)
    assert rc == 0, out
    x = XC.scan(os.path.join(d, "S.xlsx"))
    assert x["totals"]["formulas"] > 40 and x["totals"]["formulas"] == M["layer0"]["totals"]["formula_cells"], (x["totals"], M["layer0"]["totals"])
    has(out, f"formula cells {x['totals']['formulas']} of {x['totals']['formulas']} PASS", "array result cells 2 of 2 PASS")


@test("D.2 shared-formula members are formula cells; spilled cells are formula results, never typed inputs")
def d2():
    d, o, M, C = structures("d2")
    assert M["layer0"]["shared_formula_members"] == 3 and M["layer0"]["dynamic_array_formulas"] == 1, M["layer0"]
    assert C["Calc!D30"]["l0"]["kind"] == "formula" and C["Calc!D30"]["l1"]["refs"][0]["ref"] == "Inputs!D4", C["Calc!D30"]
    assert C["Calc!D30"]["l1"]["flags"]["value_verification"] == "RECOMPUTED", C["Calc!D30"]["l1"]["flags"]
    assert C["Calc!G3"]["l0"]["kind"] == "array_result", C["Calc!G3"]["l0"]


@test("D.3 every graph-status case is flagged: literal / computed INDIRECT, INDEX, STDEV, #REF!, external, circular, table, names")
def d3():
    d, o, M, C = structures("d3")
    f = lambda c: C[c]["l1"]["flags"]
    assert f("Calc!B4")["dynamic_resolution"] == "DYNAMIC_RESOLVED" and C["Calc!B4"]["l1"]["refs"][0]["ref"] == "Inputs!B4"
    assert f("Calc!B5")["dynamic_resolution"] == "DYNAMIC_UNRESOLVED"
    assert f("Calc!B6")["references_extracted"] == "OVER_APPROXIMATED"
    assert f("Calc!B7")["references_extracted"] == "COMPLETE" and f("Calc!B7")["value_verification"] == "NOT_RECOMPUTED"
    assert f("Calc!B8")["references_extracted"] == "MISSING"
    assert f("Calc!B9")["location"] == "EXTERNAL" and f("Calc!B9")["external_identified"] is True
    assert C["Calc!B9"]["l1"]["refs"][0]["link"] == "Rates Feed.xlsx"
    assert f("Calc!B11")["cycle"] == f("Calc!B12")["cycle"] == "CIRCULAR" and f("Calc!B2")["cycle"] == "ACYCLIC"
    assert C["Calc!B13"]["l1"]["refs"][0]["ref"] == "Tbl!B2:B4" and f("Calc!B13")["references_extracted"] == "COMPLETE", C["Calc!B13"]["l1"]
    assert C["Calc!B14"]["l1"]["refs"][0]["ref"] == "Inputs!B5:M5" and C["Calc!B14"]["l1"]["refs"][0]["via"] == "MyRange"
    assert f("Calc!B15")["references_extracted"] == "COMPLETE"
    assert f("Calc!B2")["value_verification"] == "RECOMPUTED"


@test("D.4 no silent truncation: every formula node carries all five graph-status flags")
def d4():
    d, o, M, C = structures("d4")
    forms = [r for r in C.values() if r["l0"]["kind"] == "formula"]
    assert forms and all(set(r["l1"]["flags"]) >= {"references_extracted", "dynamic_resolution", "location", "cycle", "value_verification"} for r in forms)
    assert len(forms) == M["layer0"]["totals"]["formula_cells"] == M["layer1"]["formula_nodes"]


@test("D.5 a date many formulas use is a hub and does not merge unrelated calculations into one region")
def d5():
    d, o, M, C = structures("d5")
    assert "Inputs!B1" in M["layer1"]["hubs"], M["layer1"]["hubs"]
    assert C["Calc!B16"]["l1"]["region"] == C["Calc!B2"]["l1"]["region"]          # B16 belongs with the TTM it uses
    assert C["Calc!D2"]["l1"]["region"] != C["Calc!B2"]["l1"]["region"]           # the hub date does not join them
    fam = [r for r in M["layer1"]["regions"] if r["id"] == C["Calc!D2"]["l1"]["region"]][0]
    assert fam.get("family", 1) >= 2, fam                                          # side-by-side copies: one family for review


@test("D.6 unreached calculation regions and sinks are reported for the analyst; Python never calls a region irrelevant")
def d6():
    d = case("d6")
    DF.pasted_workbook(os.path.join(d, "P.xlsx"))
    o, M, C = discover(d, "P.xlsx", "2025-12-31")
    regs = {r["id"]: r for r in M["layer1"]["regions"]}
    scratch = [r for r in regs.values() if r["sheets"] == ["Scratch"]]
    assert scratch and scratch[0]["proposed"] == "cannot_determine" and scratch[0]["sinks"] == ["Scratch!C8"], scratch
    assert all(r["proposed"] in ("reached_from_outputs", "cannot_determine", "small_unreached") for r in regs.values())
    from openpyxl import load_workbook
    ws = load_workbook(os.path.join(d, "map", "discovery_review.xlsx"))["Unreached regions"]
    assert any(row[0].value == scratch[0]["id"] for row in ws.iter_rows(min_row=3)), "review sheet lacks the island"


@test("D.7 a pasted value is a possible provenance match (SUPPORTED), unique; round numbers are never searched")
def d7():
    d = case("d7")
    DF.pasted_workbook(os.path.join(d, "P.xlsx"))
    o, M, C = discover(d, "P.xlsx", "2025-12-31")
    pc = M["layer2"]["pasted_value_candidates"]
    assert len(pc) == 1 and pc[0]["input"] == "Valuation!B8" and pc[0]["matches"] == ["Working!B5"], pc
    assert pc[0]["status"] == "SUPPORTED" and pc[0]["unique"] and "not proof" in pc[0]["meaning"]


@test("D.8 period decision table: block header PROVEN, window PROVEN, header only SUPPORTED, conflict, several periods AMBIGUOUS")
def d8():
    d, o, M, C = structures("d8")
    p = lambda c: C[c]["l2"]["period"]
    assert p("Inputs!C4")["status"] == "PROVEN" and p("Inputs!C4")["period"] == "2025-02"
    assert p("Calc!B2")["status"] == "PROVEN" and p("Calc!B2")["period"] == "2025-12"
    assert p("Calc!C2")["status"] == "CONFLICTING", p("Calc!C2")
    d2_ = case("d8b")
    FX.factory_workbook(os.path.join(d2_, "F.xlsx"), older=(2024, 12), column_roles=True)
    o, M2, C2 = discover(d2_, "F.xlsx", "2026-03-31")
    pf = C2["'Valuation Summary'!C10"]["l2"]["period"]                 # older multiple: typed-like formula, header only
    assert pf["status"] in ("SUPPORTED", "PROVEN") and pf["period"] == "2024-12", pf
    bud = [r for r in C2.values() if r["l2"]["period"]["column_role"] == "budget"]
    assert bud, "the budget column role was lost"


@test("D.9 the requested period is the target, never evidence: another request changes no cell's evidence")
def d9():
    d = case("d9")
    FX.factory_workbook(os.path.join(d, "F.xlsx"))
    o, M1, C1 = discover(d, "F.xlsx", "2026-03-31", "m1")
    o, M2, C2 = discover(d, "F.xlsx", "2025-06-30", "m2")
    assert all(C1[c]["l2"]["period"] == C2[c]["l2"]["period"] for c in C1)
    assert not any(e["kind"] == "request" for r in C1.values() for e in r["l2"]["period"]["evidence"])
    assert M1["meta"]["requested_period_target"] == "2026-03-31"


@test("D.10 material inputs: a monthly row is one terminal; each has a class and a separate source; no 'parameter'")
def d10():
    d = case("d10")
    FX.factory_workbook(os.path.join(d, "F.xlsx"), external={"active": "Peers Feed.xlsx", "stale": []})
    o, M, C = discover(d, "F.xlsx", "2026-03-31")
    T = M["layer2"]["terminals"]
    series = [t for t in T if t["kind"] == "series"]
    assert series and all(t["cells"] >= 12 for t in series if t["class"] == "typed financial data"), series
    assert not any("parameter" in t["class"] for t in T) and all("source_evidence" in t for t in T)
    ext = [t for t in T if t["class"] == "external-workbook value"]
    assert ext and "Peers Feed.xlsx" in ext[0]["source_evidence"], ext


@test("D.11 material-by-reference and material-by-contribution are reported separately")
def d11():
    d, o, M, C = structures("d11")
    d2_ = case("d11b")
    FX.factory_workbook(os.path.join(d2_, "F.xlsx"))
    o, M2, C2 = discover(d2_, "F.xlsx", "2026-03-31")
    L = M2["layer1"]
    assert L["material_by_reference"] > 0 and L["material_by_contribution"] > 0 and "material_formulas_contribution_unknown" in L


@test("D.12 deterministic: the same workbook, period and code give byte-identical map files")
def d12():
    d = case("d12")
    DF.structures_workbook(os.path.join(d, "S.xlsx"))
    discover(d, "S.xlsx", "2025-12-31", "a")
    discover(d, "S.xlsx", "2025-12-31", "b")
    for f in ("workbook_map.json", "cells.jsonl.gz"):
        assert open(os.path.join(d, "a", f), "rb").read() == open(os.path.join(d, "b", f), "rb").read(), f


@test("D.13 read-only: discovery never changes the workbook")
def d13():
    d = case("d13")
    FX.factory_workbook(os.path.join(d, "F.xlsx"))
    h = sha256_file(os.path.join(d, "F.xlsx"))
    discover(d, "F.xlsx", "2026-03-31")
    assert sha256_file(os.path.join(d, "F.xlsx")) == h


# ------------------------------------------------------------------------------------------------ B benchmark
@test("B.1 separation: no benchmark module imports discovery code (only common/ and the standard library / openpyxl)")
def b1():
    disc = {os.path.splitext(os.path.basename(p))[0] for p in glob.glob(os.path.join(PKG, "discovery", "**", "*.py"), recursive=True)}
    for p in glob.glob(os.path.join(PKG, "benchmark", "*.py")):
        tree = ast.parse(open(p).read())
        for n in ast.walk(tree):
            mods = [a.name for a in n.names] if isinstance(n, ast.Import) else [n.module or ""] if isinstance(n, ast.ImportFrom) else []
            for m_ in mods:
                top = m_.split(".")[0]
                assert top not in disc and top != "discovery", f"{os.path.basename(p)} imports discovery module {m_}"


def factory_case(name, **kw):
    d = case(name)
    vals = FX.factory_workbook(os.path.join(d, "F.xlsx"), **kw)
    discover(d, "F.xlsx", "2026-03-31")
    return d, vals


SAMPLES = [{"id": "S01", "cell": "'Valuation Summary'!{c}11", "depends_on": ["'Valuation Summary'!{c}8", "'Valuation Summary'!{c}10"], "period": "2026-03",
            "kind": "calculation (formula)"},
           {"id": "S02", "cell": "'Valuation Summary'!{c}5", "depends_on": ["Monthly!Q4:AB4"], "period": "2026-03", "kind": "calculation (formula)"},
           {"id": "S03", "cell": "Monthly!AB4", "depends_on": [], "period": "2026-03", "kind": "typed financial data"},
           {"id": "S04", "cell": "Comps!B9", "depends_on": [], "period": "none", "kind": "market/comparable input"}]


def samples_for(col):
    return [dict(s, cell=s["cell"].format(c=col), depends_on=[x.format(c=col) for x in s["depends_on"]]) for s in SAMPLES]


@test("B.2 a correct, independent key: every check passes; safe to proceed stays NO until a second Gold workbook passes")
def b2():
    d, vals = factory_case("b2", older=(2024, 12), column_roles=True)
    c = vals[(2026, 3)]["col"]
    k = factory_key(d, "F.xlsx", vals, required=[{"id": "K-R1", "purpose": "material", "area": "Monthly!Q4:AB13", "description": "monthly history"}],
                    irrelevant=[{"id": "K-R2", "purpose": "historical", "area": "'Valuation Summary'!B2:D16", "description": "Dec-24 valuation"},
                                {"id": "K-R3", "purpose": "historical", "area": "Monthly!B4:M13", "description": "2024 months"}],
                    samples=samples_for(c))
    rc, o, res = score(d, k)
    assert rc == 0, o
    fails = [x for x in res["checks"] if x["status"] == "FAIL"]
    assert not fails, fails
    assert res["result"]["physical_import"] == "PASS" and res["result"]["material_graph"] == "PASS", res["result"]
    assert res["result"]["safe_to_design_generation"] == "NO" and any("second" in w for w in res["result"]["why_not"])
    has(o, "BENCHMARK: result | physical import PASS | material graph PASS")


@test("B.3 the benchmark fails a wrong map: a removed reference is a silent omission; a wrong PROVEN junction and period are caught")
def b3():
    d, vals = factory_case("b3")
    c = vals[(2026, 3)]["col"]
    import gzip
    rows = list(read_jsonl_gz(os.path.join(d, "map", "cells.jsonl.gz")))
    for r in rows:
        if r["cell"] == f"'Valuation Summary'!{c}11":
            r["l1"]["refs"] = r["l1"]["refs"][:1]                          # tamper: drop one reference
        if r["cell"] == "Monthly!AB4":
            r["l2"]["period"].update(period="2026-02", status="PROVEN")    # tamper: wrong period, claimed PROVEN
    from common.util import write_jsonl_gz
    write_jsonl_gz(rows, os.path.join(d, "map", "cells.jsonl.gz"))
    M = load(os.path.join(d, "map", "workbook_map.json"))
    M["layer2"]["junctions"]["selected_multiple"].update(cell="Comps!B5", status="PROVEN")
    json.dump(M, open(os.path.join(d, "map", "workbook_map.json"), "w"))
    rc, o, res = score(d, factory_key(d, "F.xlsx", vals, samples=samples_for(c)))
    st = {x["id"]: x for x in res["checks"]}
    assert st["S.S01.dependencies"]["detail"] == "silent_omission" and st["S.S01.dependencies"]["status"] == "FAIL", st["S.S01.dependencies"]
    assert st["J.selected_multiple"]["status"] == "FAIL" and res["junctions"]["proven_wrong"] == 1
    assert st["S.S03.period"]["status"] == "FAIL" and res["periods"]["proven_wrong"] == 1
    assert res["result"]["material_graph"] == "FAIL"


@test("B.4 the key and the map are bound to the frozen Gold file: a changed workbook, key or blind file is refused")
def b4():
    d, vals = factory_case("b4")
    k = factory_key(d, "F.xlsx", vals)
    kk = load(os.path.join(d, k))
    kk["important_outputs"]["enterprise_value"]["cell"] = "X!A1"
    json.dump(kk, open(os.path.join(d, "tampered.json"), "w"))
    rc, o = run(BENCH, ["score", "--map", "map", "--key", "tampered.json"], d)
    assert rc == 3 and "changed after it was built" in o, o
    kk = load(os.path.join(d, k))
    kk["workbook"]["sha256"] = "0" * 64
    body = {x: y for x, y in kk.items() if x != "sha256"}
    kk["sha256"] = sha256_text(canon(body))
    json.dump(kk, open(os.path.join(d, "other.json"), "w"))
    rc, o = run(BENCH, ["score", "--map", "map", "--key", "other.json"], d)
    assert rc == 3 and "different workbook" in o, o


def fill_template(path, answers, regions, sample_answers):
    from openpyxl import load_workbook
    wb = load_workbook(path)
    j = wb["1 Blind junctions"]
    for row in j.iter_rows(min_row=2):
        if row[0].value in answers:
            row[2].value = answers[row[0].value]
    g = wb["2 Blind regions"]
    for r in regions:
        g.append([r["purpose"], r["area"], r["description"]])
    s = wb["3 Sample"]
    for row in s.iter_rows(min_row=2):
        cell = row[1].value
        a = sample_answers(cell)
        row[3].value, row[4].value = a
    wb.save(path)


@test("B.5 end to end: template, frozen physical sample, blind freeze, Excel facts, discovery, region review, key, score")
def b5():
    d = case("b5")
    vals = FX.factory_workbook(os.path.join(d, "F.xlsx"), older=(2024, 12))
    c = vals[(2026, 3)]["col"]
    rc, o = run(BENCH, ["template", "--workbook", "F.xlsx", "--gold-id", "GOLD-T5", "--period-end", "2026-03-31", "--out", "gold.xlsx"], d)
    assert rc == 0, o
    rc, o = run(BENCH, ["sample", "--workbook", "F.xlsx", "--template", "gold.xlsx", "--seed", "7", "--request-out", "req.json"], d)
    assert rc == 0, o
    req = load(os.path.join(d, "req.json"))
    shutil.copyfile(os.path.join(d, "gold.xlsx"), os.path.join(d, "gold2.xlsx"))
    rc2, o2 = run(BENCH, ["sample", "--workbook", "F.xlsx", "--template", "gold2.xlsx", "--seed", "7", "--request-out", "req2.json"], d)
    assert rc2 == 3 and "drawn once" in o2, o2
    from openpyxl import load_workbook
    strata = {row[2].value.split(":")[0] for row in load_workbook(os.path.join(d, "gold.xlsx"))["3 Sample"].iter_rows(min_row=2)}
    assert {"F-xsheet", "F-agg", "T-xref"} <= strata, strata
    q = "'Valuation Summary'"
    fill_template(os.path.join(d, "gold.xlsx"),
                  {"enterprise_value": f"{q}!{c}11", "equity_value": f"{q}!{c}14", "value_to_xpv": f"{q}!{c}16", "valuation_metric": f"{q}!{c}8",
                   "selected_multiple": f"{q}!{c}10", "metric_period": "2026-03", "method": "ev_ebitda"},
                  [{"purpose": "material", "area": "Monthly!Q4:AB13", "description": "monthly history"}], lambda cell: ("unsure", "unsure"))
    rc, o = run(BENCH, ["freeze-blind", "--template", "gold.xlsx", "--by", "Test Analyst", "--out", "blind.json"], d, "2026-10-08T09:00:00")
    assert rc == 0, o
    # Excel facts: in tests, the standard-library checker stands in for gold-facts.ts; precedents written by the fixture's author
    x = XC.scan(os.path.join(d, "F.xlsx"))
    json.dump({"version": 1, "mode": "counts", "sheets": [{"name": s["name"], "visibility": "Visible", "populated": s["populated"],
                                                           "formulas": s["formulas"], "errors": s["errors"]} for s in x["sheets"]],
               "defined_names": x["defined_names"], "tables": x["tables"], "linked_workbooks": x["external_links"]},
              open(os.path.join(d, "facts_counts.json"), "w"))
    json.dump({"version": 1, "mode": "precedents", "precedents": {cc: "unavailable: not in this test" for cc in req["cells"]}},
              open(os.path.join(d, "facts_prec.json"), "w"))
    discover(d, "F.xlsx", "2026-03-31", "map", "2026-10-08T08:00:00")
    rc, o = run(BENCH, ["key", "--blind", "blind.json", "--workbook", "F.xlsx", "--facts", "facts_counts.json", "facts_prec.json",
                        "--map-meta", "map/workbook_map.json", "--by", "Test Analyst", "--out", "key.json"], d)
    assert rc == 3 and "older than the blind answers" in o, o            # discovery ran BEFORE the freeze: refused
    discover(d, "F.xlsx", "2026-03-31", "map", "2026-10-08T10:00:00")
    wb = load_workbook(os.path.join(d, "map", "discovery_review.xlsx"))
    ws = wb["Unreached regions"]
    for row in ws.iter_rows(min_row=3):
        row[5].value = "historical"
    wb.save(os.path.join(d, "review_filled.xlsx"))
    rc, o = run(BENCH, ["key", "--blind", "blind.json", "--workbook", "F.xlsx", "--facts", "facts_counts.json", "facts_prec.json",
                        "--review", "review_filled.xlsx", "--map-meta", "map/workbook_map.json", "--by", "Test Analyst", "--out", "key.json"], d)
    assert rc == 0, o
    K = load(os.path.join(d, "key.json"))
    assert any(r["provenance"] == "confirmed_after_proposal" for r in K["known_irrelevant_regions"])
    assert all(s["provenance"] == "blind" for s in K["confirmed_dependency_samples"])
    rc, o, res = score(d, "key.json")
    assert rc == 0 and res["result"]["physical_import"] == "PASS" and res["result"]["material_graph"] == "PASS", (o, res["result"])
    assert res["regions"]["unaccounted"] == [], res["regions"]


@test("B.6 regression against the previous build: new failures, fixes and method changes are reported")
def b6():
    d, vals = factory_case("b6")
    k = factory_key(d, "F.xlsx", vals)
    rc, o, res1 = score(d, k)
    prev = load(os.path.join(d, "bench_map", "benchmark_result.json"))
    for x in prev["checks"]:
        if x["id"] == "J.enterprise_value":
            x["status"] = "FAIL"                                           # was failing before: now fixed
        if x["id"] == "J.equity_value":
            pass
    prev["checks"].append({"id": "J.gone", "family": "interpretation", "status": "PASS"})
    prev["meta"]["rules"] = {"graph": "R0", "period": "P0"}
    json.dump(prev, open(os.path.join(d, "prev.json"), "w"))
    M = load(os.path.join(d, "map", "workbook_map.json"))
    M["layer2"]["junctions"]["equity_value"]["cell"] = "Comps!B4"         # a new failure
    json.dump(M, open(os.path.join(d, "map", "workbook_map.json"), "w"))
    rc, o, res = score(d, k, extra=["--previous", "prev.json"])
    R = res["regression"]
    assert R["fixed"] == ["J.enterprise_value"] and R["new_failures"] == ["J.equity_value"] and R["method_changed"], R
    has(o, "BENCHMARK: regression | previous checks still passing", "new failures 1", "fixed 1", "method changed yes")
    assert res["result"]["safe_to_design_generation"] == "NO"


@test("B.7 sanitised output: no sheet names, cells, values, file names or paths; --redact-counts hides the numbers")
def b7():
    d, vals = factory_case("b7", external={"active": "Peers Feed.xlsx", "stale": ["Old.xlsx"]})
    rc, o, res = score(d, factory_key(d, "F.xlsx", vals))
    body = "\n".join(l for l in o.splitlines() if l.startswith("BENCHMARK:"))
    for bad in ("Valuation", "Summary", "Comps", "Monthly", "Delta", "Peers", ".xlsx", "!", "/", "'"):
        assert bad not in body, f"leaks {bad!r}:\n{body}"
    assert not re.search(r"\b[A-Z]{1,3}\d{1,7}\b", body.replace("R1", "").replace("P1", "")), body
    rc, o2, _ = score(d, factory_key(d, "F.xlsx", vals), extra=["--redact-counts"])
    b2_ = "\n".join(l for l in o2.splitlines() if l.startswith("BENCHMARK:") and "physical" in l)
    assert not re.search(r"\b\d{2,}\b", b2_), b2_


@test("B.8 safe to proceed is YES only when this Gold passes with no open gates AND a different Gold workbook has passed")
def b8():
    d = case("b8")
    vals = FX.company_workbook(os.path.join(d, "C.xlsx"))
    discover(d, "C.xlsx", "2026-06-30")
    k = make_key(d, "C.xlsx", {"enterprise_value": "Valuation!B21", "equity_value": "Valuation!B24", "value_to_xpv": "Valuation!B26"},
                 {"selected_multiple": "Valuation!B16", "valuation_metric": "Valuation!B7"}, pe="2026-06-30", gid="GOLD-T8",
                 irrelevant=[{"id": "K-H1", "purpose": "historical", "area": "Monthly!B4:M17", "description": "months before the TTM window"}])
    rc, o, res = score(d, k)
    assert res["result"]["material_graph"] == "PASS" and not [g for g, v in res["gates"].items() if v], res["gates"]
    other = {"meta": {"gold_id": "GOLD-OTHER"}, "result": {"material_graph": "PASS"}}
    json.dump(other, open(os.path.join(d, "other.json"), "w"))
    rc, o, res = score(d, k, extra=["--other-gold", "other.json"])
    assert res["result"]["safe_to_design_generation"] == "YES", res["result"]
    json.dump(dict(other, meta={"gold_id": "GOLD-T8"}), open(os.path.join(d, "same.json"), "w"))
    rc, o, res = score(d, k, extra=["--other-gold", "same.json"])
    assert res["result"]["safe_to_design_generation"] == "NO"


# ------------------------------------------------------------------------------------------------ M mutations
@test("M.1 inserted columns (an older quarter and Budget / Variance columns): the same meaning is found at the new addresses")
def m1():
    for i, kw in enumerate([{}, {"older": (2024, 12)}, {"older": (2024, 12), "column_roles": True, "budget_first": True}]):
        d, vals = factory_case(f"m1_{i}", **kw)
        rc, o, res = score(d, factory_key(d, "F.xlsx", vals))
        bad = [x for x in res["checks"] if x["id"].startswith("J.") and x["status"] != "PASS"]
        assert not bad, (kw, bad)


@test("M.2 a renamed sheet: formulas follow the new name and the same junctions are found")
def m2():
    d = case("m2")
    vals = FX.factory_workbook(os.path.join(d, "F.xlsx"))
    DF.rename_sheet(os.path.join(d, "F.xlsx"), "Valuation Summary", "VS Q1 2026")
    discover(d, "F.xlsx", "2026-03-31")
    rc, o, res = score(d, factory_key(d, "F.xlsx", vals, sheet="VS Q1 2026"))
    bad = [x for x in res["checks"] if x["id"].startswith("J.") and x["status"] != "PASS"]
    assert not bad and res["result"]["physical_import"] == "PASS", bad


@test("M.3 a decoy multiple and an irrelevant new sheet change nothing that matters")
def m3():
    d, vals = factory_case("m3", decoy="ambiguous_multiple")
    rc, o, res = score(d, factory_key(d, "F.xlsx", vals))
    assert not [x for x in res["checks"] if x["id"].startswith("J.") and x["status"] != "PASS"], res["checks"]
    d2_ = case("m3b")
    FX.company_workbook(os.path.join(d2_, "C.xlsx"), noise_sheet=True)
    discover(d2_, "C.xlsx", "2026-06-30")
    k = make_key(d2_, "C.xlsx", {"enterprise_value": "Valuation!B21", "equity_value": "Valuation!B24", "value_to_xpv": "Valuation!B26"},
                 pe="2026-06-30", irrelevant=[{"id": "K-N", "purpose": "irrelevant", "area": "Data dump", "description": "dump"}])
    rc, o, res = score(d2_, k)
    assert res["result"]["material_graph"] == "PASS", [x for x in res["checks"] if x["status"] == "FAIL"]


@test("M.4 real changes are caught: a TTM window ending a month early, and a required region the outputs do not use")
def m4():
    d = case("m4")
    FX.company_workbook(os.path.join(d, "C.xlsx"), ttm_off=True)
    discover(d, "C.xlsx", "2026-06-30")
    k = make_key(d, "C.xlsx", {"enterprise_value": "Valuation!B21"}, {"metric_window_last": "2026-06"}, pe="2026-06-30",
                 required=[{"id": "K-H", "purpose": "material", "area": "Monthly!B17:Y17", "description": "headcount (not used by the valuation)"}])
    rc, o, res = score(d, k)
    st = {x["id"]: x["status"] for x in res["checks"]}
    assert st["J.metric_window_last"] == "FAIL" and st["R.K-H"] == "FAIL" and res["result"]["material_graph"] == "FAIL", st



# ------------------------------------------------------------------------------------------------ P pre-flight and files
@test("P.1 pre-flight refuses unreadable files with one clear line each (exit 3, no traceback); macros are noted")
def p1():
    d = case("p1")
    FX.factory_workbook(os.path.join(d, "good.xlsx"))
    open(os.path.join(d, "empty.xlsx"), "wb").close()
    ole = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\x00" * 600
    open(os.path.join(d, "legacy.xls"), "wb").write(ole)
    open(os.path.join(d, "locked.xlsx"), "wb").write(ole)
    open(os.path.join(d, "binary.xlsb"), "wb").write(b"PK\x03\x04junk")
    open(os.path.join(d, "broken.xlsx"), "wb").write(open(os.path.join(d, "good.xlsx"), "rb").read()[:400])
    import zipfile
    with zipfile.ZipFile(os.path.join(d, "notwb.xlsx"), "w") as z:
        z.writestr("hello.txt", "hi")
    open(os.path.join(d, "data.csv"), "w").write("a,b\n1,2\n")
    expect = {"empty.xlsx": "empty", "legacy.xls": "legacy .xls", "locked.xlsx": "password-protected", "binary.xlsb": ".xlsb",
              "broken.xlsx": "damaged", "notwb.xlsx": "no workbook part", "data.csv": "not an Excel workbook"}
    for name, words in expect.items():
        rc, o = run(DISC, ["--workbook", name, "--period-end", "2026-03-31", "--out", "m_" + name], d)
        assert rc == 3 and o.strip().startswith(f"PREFLIGHT: REFUSED {name}") and words in o and "Traceback" not in o, (name, o)
    rc, o = run(BENCH, ["hash", "--workbook", "locked.xlsx"], d)
    assert rc == 3 and "PREFLIGHT: REFUSED" in o, o
    sys.path.insert(0, PKG)
    from common.preflight import check_workbook
    shutil.copyfile(os.path.join(d, "good.xlsx"), os.path.join(d, "macro.xlsm"))
    with zipfile.ZipFile(os.path.join(d, "macro.xlsm"), "a") as z:
        z.writestr("xl/vbaProject.bin", b"\x00" * 10)
    assert check_workbook(os.path.join(d, "macro.xlsm"))["macros"] is True


@test("P.2 files passed by name are found where knowledge files land; two different files with one name stop the run")
def p2():
    d = case("p2")
    os.makedirs(os.path.join(d, "kn", "a")); os.makedirs(os.path.join(d, "kn", "b")); os.makedirs(os.path.join(d, "run"))
    FX.factory_workbook(os.path.join(d, "kn", "a", "F.xlsx"))
    shutil.copyfile(os.path.join(d, "kn", "a", "F.xlsx"), os.path.join(d, "kn", "b", "F.xlsx"))      # same content twice: fine
    e = dict(env(), VALUATION_FILE_ROOTS=os.path.join(d, "kn"))
    p = subprocess.run([sys.executable, DISC, "--workbook", "F.xlsx", "--period-end", "2026-03-31", "--out", os.path.join(d, "run", "m")],
                       cwd=os.path.join(d, "run"), env=e, capture_output=True, text=True)
    assert p.returncode == 0, p.stdout + p.stderr
    FX.factory_workbook(os.path.join(d, "kn", "b", "F.xlsx"), older=(2024, 12))                       # different content
    p = subprocess.run([sys.executable, DISC, "--workbook", "F.xlsx", "--period-end", "2026-03-31"], cwd=os.path.join(d, "run"), env=e,
                       capture_output=True, text=True)
    assert p.returncode == 3 and "different files are named 'F.xlsx'" in p.stdout, p.stdout


@test("D.14 a corrupt named range (#REF!) is flagged MISSING on the formulas that use it - no crash, no silent stop")
def d14():
    d, o, M, C = structures("d14")
    f = C["Calc!B17"]["l1"]
    assert f["flags"]["references_extracted"] == "MISSING" and any(r.get("via") == "BadName" for r in f["refs"]), f


# ------------------------------------------------------------------------------------------------ I invariants
@test("I.1 invariants hold on a consistent workbook; a profile can disable one; an unknown check in the registry stops")
def i1():
    d = case("i1")
    FX.factory_workbook(os.path.join(d, "F.xlsx"))
    o, M, C = discover(d, "F.xlsx", "2026-03-31")
    st = {r["id"]: r["status"] for r in M["layer2"]["invariants"]["results"]}
    assert all(st[i] == "HOLDS" for i in ("INV-01", "INV-02", "INV-03", "INV-04", "INV-05", "INV-06", "INV-07")) and st["INV-08"] == "NOT_APPLICABLE", st
    rc, o2 = run(DISC, ["--workbook", "F.xlsx", "--period-end", "2026-03-31", "--out", "m2", "--profile", "example-fx-company"], d)
    assert rc == 0 and load(os.path.join(d, "m2", "workbook_map.json"))["meta"]["invariant_profile"] == "example-fx-company"
    rc, o3 = run(DISC, ["--workbook", "F.xlsx", "--period-end", "2026-03-31", "--out", "m3", "--profile", "no-such-profile"], d)
    assert rc == 3 and "profile 'no-such-profile'" in o3, o3
    sys.path[:0] = [os.path.join(PKG, "discovery")]
    import invariants as IV
    keep = dict(IV.INVARIANTS)
    try:
        IV.INVARIANTS["invariants"] = keep["invariants"] + [{"id": "INV-X", "check": "made_up"}]
        from common.util import Stop
        try:
            IV.evaluate({"m": None, "g": None, "J": {}, "material": set(), "period_of": lambda k: None})
            raise AssertionError("an unknown check did not stop")
        except Stop as e:
            assert "unknown check 'made_up'" in str(e)
    finally:
        IV.INVARIANTS["invariants"] = keep["invariants"]


@test("I.2 invariants catch a stale enterprise value and a balance sheet that does not balance (naming the month)")
def i2():
    d = case("i2")
    DF.pasted_workbook(os.path.join(d, "P.xlsx"), stale_ev=True, balance_sheet="off")
    o, M, C = discover(d, "P.xlsx", "2025-12-31")
    st = {r["id"]: r for r in M["layer2"]["invariants"]["results"]}
    assert st["INV-01"]["status"] == "VIOLATED" and st["INV-07"]["status"] == "VIOLATED", st
    assert st["INV-08"]["status"] == "VIOLATED" and "2025-06" in st["INV-08"]["detail"], st["INV-08"]
    assert M["gates"]["invariants_violated"] >= 3
    d2_ = case("i2b")
    DF.pasted_workbook(os.path.join(d2_, "P.xlsx"), balance_sheet="balanced")
    o, M2, C2 = discover(d2_, "P.xlsx", "2025-12-31")
    assert {r["id"]: r["status"] for r in M2["layer2"]["invariants"]["results"]}["INV-08"] == "HOLDS"


@test("I.3 invariants are not ground truth: a consistent column of the wrong quarter passes them all; the Gold key catches it")
def i3():
    d = case("i3")
    vals = FX.factory_workbook(os.path.join(d, "F.xlsx"), older=(2024, 12))
    discover(d, "F.xlsx", "2024-12-31")                                    # asks for the older quarter: consistent column
    M = load(os.path.join(d, "map", "workbook_map.json"))
    assert all(r["status"] in ("HOLDS", "NOT_APPLICABLE") for r in M["layer2"]["invariants"]["results"]), M["layer2"]["invariants"]
    rc, o, res = score(d, factory_key(d, "F.xlsx", vals))                   # the key says Q1 2026
    assert res["invariants"]["summary"]["VIOLATED"] == 0 and res["result"]["material_graph"] == "FAIL", res["result"]
    has(o, "BENCHMARK: invariants consistency not truth | holds")


# ------------------------------------------------------------------------------------------------ E errors, S schemas, R rules, C contracts
@test("E.1 an internal error prints one line (exit 1) and writes the traceback to run_error.log, not to the agent")
def e1():
    d = case("e1")
    FX.factory_workbook(os.path.join(d, "F.xlsx"))
    p = subprocess.run([sys.executable, DISC, "--workbook", "F.xlsx", "--period-end", "2026-03-31", "--out", "m"], cwd=d,
                       env=dict(env(), WD_TEST_FAULT="after_read"), capture_output=True, text=True)
    assert p.returncode == 1 and p.stdout.strip().splitlines()[-1].startswith("DISCOVERY ERROR: internal RuntimeError"), p.stdout
    assert "Traceback" not in p.stdout + p.stderr and "injected fault" in open(os.path.join(d, "m", "run_error.log")).read()


@test("S.1 schemas: an answer key or blind-answers file missing required fields is refused with what is missing")
def s1():
    d, vals = factory_case("s1")
    k = load(os.path.join(d, factory_key(d, "F.xlsx", vals)))
    del k["physical_structure"]["formula_cells"]
    json.dump(k, open(os.path.join(d, "badkey.json"), "w"))
    rc, o = run(BENCH, ["score", "--map", "map", "--key", "badkey.json"], d)
    assert rc == 3 and "answer key is not valid" in o and "physical_structure.formula_cells is missing" in o, o
    json.dump({"schema": "gold-blind/1"}, open(os.path.join(d, "blind.json"), "w"))
    rc, o = run(BENCH, ["key", "--blind", "blind.json", "--workbook", "F.xlsx", "--facts", "blind.json", "--by", "x", "--out", "k.json"], d)
    assert rc == 3 and "blind answers file is not valid" in o, o


@test("R.1 rules are data: the map records the hashes of the rule and invariant files it ran with")
def r1():
    d = case("r1")
    FX.factory_workbook(os.path.join(d, "F.xlsx"))
    o, M, C = discover(d, "F.xlsx", "2026-03-31")
    sys.path[:0] = [os.path.join(PKG, "discovery")]
    import rules as RU
    assert M["meta"]["rules_hashes"] == RU.HASHES and M["meta"]["invariants_version"] == RU.INVARIANTS["version"]


@test("C.1 the printed lines are the agent's contract: every line uses a prefix SKILL.md documents; exit codes documented")
def c1():
    skill = open(os.path.join(PKG, "SKILL.md"), encoding="utf-8").read()
    prefixes = ["PREFLIGHT:", "DISCOVERY:", "DISCOVERY ERROR:", "BENCHMARK:", "BENCHMARK ERROR:", "STOPPED:", "NEXT:", "ALL TESTS:"]
    for p_ in prefixes:
        assert f"`{p_}`" in skill, f"SKILL.md does not document {p_}"
    for code in ("0 done", "1 internal error", "2 usage", "3 STOPPED"):
        assert code in skill, f"SKILL.md does not document exit code '{code}'"
    d, vals = factory_case("c1")
    outs = [run(BENCH, ["score", "--map", "map", "--key", factory_key(d, "F.xlsx", vals)], d)[1],
            run(DISC, ["--workbook", "F.xlsx", "--period-end", "2026-03-31", "--out", "m2"], d)[1],
            run(DISC, ["--workbook", "missing.xlsx", "--period-end", "2026-03-31"], d)[1],
            run(BENCH, ["template", "--workbook", "F.xlsx", "--gold-id", "G", "--period-end", "2026-03-31", "--out", "t.xlsx"], d)[1]]
    for text in outs:
        for line in text.splitlines():
            if line.strip() and not line.startswith(("- ", "  ")):
                assert line.startswith(tuple(prefixes)), f"undocumented printed line: {line[:90]}"


@test("C.2 hygiene: every module compiles, carries its build header, and has no placeholder code")
def c2():
    for p_ in glob.glob(os.path.join(PKG, "**", "*.py"), recursive=True):
        compile(open(p_, encoding="utf-8").read(), p_, "exec")             # in memory: never writes into the skill folder
        if "/vp/" in p_.replace(os.sep, "/") or p_.endswith("vp_fixtures.py"):
            continue                                                      # vendored build 11.3 code: unchanged by policy (V.1)
        src = open(p_, encoding="utf-8").read()
        assert re.search(r"^# \S+\.py \(build 11\.\d\)", src), f"{p_}: no build header"
        for bad in ("TO" + "DO", "FIX" + "ME", "X" + "XX", "if " + "False"):
            assert bad not in src, f"{p_}: contains {bad}"


# ------------------------------------------------------------------------------------------------ V vendored
@test("V.1 the vendored build 11.3 modules are byte-identical to build 11.3.0 (their 76 tests live in that package)")
def v1():
    for line in open(os.path.join(PKG, "discovery", "vp_hashes.txt")):
        h, name = line.split()
        assert hashlib.sha256(open(os.path.join(PKG, "discovery", "vp", name), "rb").read()).hexdigest() == h, name


def main():
    for t in TESTS:
        t()
    ok = sum(1 for _, p, _ in RESULTS if p)
    for n, p, w in RESULTS:
        print(f"- {'PASS' if p else 'FAIL'}: {n}" + ("" if p else f"\n    {w}"))
    print(f"ALL TESTS: {'PASS' if ok == len(RESULTS) else 'FAIL'} ({ok}/{len(RESULTS)})")
    shutil.rmtree(ROOT, ignore_errors=True)
    return 0 if ok == len(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())
