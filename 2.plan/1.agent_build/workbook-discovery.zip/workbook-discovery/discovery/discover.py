# discovery/discover.py (build 11.5) - the DISCOVERY SYSTEM. Reads one workbook (never changes it) and writes its map:
#   workbook_map.json      summary: Layer 0 inventory, Layer 1 graph status counts / regions / hubs, Layer 2 proposals,
#                          completeness controls, run metadata (versions, hashes, requested period as TARGET)
#   cells.jsonl.gz         one record per stored formula / number / date cell: Layer 0 facts, Layer 1 references and
#                          flags, Layer 2 period evidence, materiality, terminal class
#   discovery_review.xlsx  unreached calculation regions for the analyst (after the blind answers are frozen)
#   run_log.json           timings, peak memory, versions (NOT part of the deterministic map)
# Prints only counts and categories (PREFLIGHT: / DISCOVERY: lines) - names, cells and values stay in the files.
# Exit codes: 0 done | 1 internal error (a bug: the traceback goes to run_error.log) | 2 usage | 3 STOPPED (the user must act).
import argparse, datetime, os, platform, resource, sys, time, traceback
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path[:0] = [os.path.join(HERE, "vp"), HERE, PKG]
from common.util import VERSION, dump, sha256_file, write_jsonl_gz, cell_text, now, Stop, EXIT_OK, EXIT_INTERNAL, EXIT_STOPPED
from common.files import find_input, out_root
from common.preflight import check_workbook
from rules import RULES, INVARIANTS, HASHES
import invariants as INVC
from workbook_model import Model
import inventory as INV
import graph as GR
import semantics as SE
import periods as PER


def jsonable(v):
    if isinstance(v, (datetime.datetime, datetime.date)):
        return v.isoformat()[:10]
    return v


def load_cells(m, path, boxes_by_sheet):
    """reads cells the 11.3 reader did not hold: whole sheets (boxes None) or given boxes. Rebuilds the model's indexes."""
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True, read_only=True, keep_links=False)
    for sh, boxes in boxes_by_sheet.items():
        added = 0
        for row in wb[sh].iter_rows():
            for c in row:
                if c.value is None or not getattr(c, "row", None) or (sh, c.row, c.column) in m._v:
                    continue
                if boxes is None or any(b[1] <= c.row <= b[3] and b[2] <= c.column <= b[4] for b in boxes):
                    m._v[(sh, c.row, c.column)] = c.value
                    added += 1
        m.skipped_cells[sh] = max(0, m.skipped_cells.get(sh, 0) - added)
        if not m.skipped_cells[sh]:
            del m.skipped_cells[sh]
    wb.close()
    m._index()
    m._blocks, m._prec = None, {}


def ensure_stored(m, g, path):
    """cells only a table / name / 3-D reference reaches (beyond what the 11.3 reader held): load exactly those."""
    need = {}
    for n in g.nodes.values():
        for r in n["refs"]:
            if r.get("why", "").startswith("referenced cells are on a sheet region") and r.get("box"):
                need.setdefault(r["box"][0], []).append(r["box"])
    if need:
        load_cells(m, path, need)
    return bool(need)


def run(path, period_end, out, profile=None, pre=None):
    os.makedirs(out, exist_ok=True)
    t0, timings, last = time.time(), {}, [time.time()]

    def lap(k):
        t = time.time()
        timings[k] = round(t - last[0], 3)
        last[0] = t
    facts = INV.xml_facts(path)
    m = Model(path)
    if m.skipped_cells and sum(m.skipped_cells.values()) <= RULES["storage"]["load_unreferenced_cells_up_to"]:
        load_cells(m, path, {sh: None for sh in list(m.skipped_cells)})    # small enough: hold everything (Layer 0 complete)
    lap("read")
    if os.environ.get("WD_TEST_FAULT") == "after_read":          # test hook: behave like an internal bug (test E.1)
        raise RuntimeError("injected fault")
    arr = INV.array_result_cells(facts)
    inv = INV.inventory(m, facts, arr)
    g = GR.Graph(m, facts, arr)
    if ensure_stored(m, g, path):                         # cells only a table / name reference reaches: read them, rebuild
        g = GR.Graph(m, facts, arr)
    lap("graph")
    J, roots, an = SE.junctions(m, path, period_end)
    lap("junctions")
    mat_ref = g.closure(roots)
    g.verify_values(keep_used_for=mat_ref)
    mat_con = g.closure(roots, contributing=True)
    regs, hubs, dependents = g.regions(mat_ref)
    terms = SE.terminals(m, g, mat_ref)
    pasted = SE.pasted_candidates(m, g, terms, mat_ref)
    cp = PER.CellPeriods(m)
    region_of = {c: r["id"] for r in regs for c in r["_members"]}
    rows, pcount, memo = [], {}, {}
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 5000))
    term_class = {}
    for t in terms:
        term_class[t["cell"]] = t["class"]
    for k in sorted(m.cells, key=lambda c: (g.order.index(c[0]) if c[0] in g.order else 999, c[1], c[2])):
        f, v = m._f.get(k), m._v.get(k)
        if not f and not isinstance(v, (int, float, datetime.date, datetime.datetime)) or isinstance(v, bool):
            continue
        pe = SE.period_evidence(m, g, k, cp, SE.AN.value_window, memo)
        pcount[pe["status"]] = pcount.get(pe["status"], 0) + 1
        n = g.nodes.get(k)
        b = m.block_of_cell(k)
        ct = cell_text(*k)
        rows.append({"cell": ct,
                     "l0": {"kind": "formula" if f else "array_result" if k in arr else "date" if isinstance(v, (datetime.date, datetime.datetime)) else "number",
                            "formula": f, "value": jsonable(v), "saved_value_missing": bool(f and v is None)},
                     "l1": {"refs": [{x: r[x] for x in ("ref", "kind", "status", "via", "link", "why") if x in r} for r in n["refs"]] if n else [],
                            "flags": n["flags"] if n else None, "reasons": n["reasons"] if n else [], "functions": n["functions"] if n else [],
                            "label": m.row_label(k), "column_header": m.col_header(k), "block_row": b[0] if b else None,
                            "region": region_of.get(k), "dependents": dependents.get(k, 0), "hub": k in set(hubs),
                            "contributing_known": k in g.contrib if n else None},
                     "l2": {"period": pe, "material_by_reference": k in mat_ref, "material_by_contribution": k in mat_con,
                            "terminal_class": term_class.get(ct)}})
    lap("cells")
    write_jsonl_gz(rows, os.path.join(out, "cells.jsonl.gz"))
    ctx = {"m": m, "g": g, "J": J, "material": mat_ref,
           "period_of": lambda k: (lambda pe: pe["period"] if pe["status"] in ("PROVEN", "SUPPORTED") else None)(
               SE.period_evidence(m, g, k, cp, SE.AN.value_window, memo))}
    invs = INVC.evaluate(ctx, profile)
    fl = {"references_extracted": {}, "dynamic_resolution": {}, "location": {}, "cycle": {}, "value_verification": {}}
    mfl = {k_: {} for k_ in fl}
    for k, n in g.nodes.items():
        for f_, v_ in n["flags"].items():
            if f_ in fl:
                fl[f_][v_] = fl[f_].get(v_, 0) + 1
                if k in mat_ref:
                    mfl[f_][v_] = mfl[f_].get(v_, 0) + 1
    heads = {j: g.headline(AN_key) for j, AN_key in zip(("enterprise_value", "equity_value", "value_to_xpv"), roots)}
    unsupported = sorted({(n["cell"], "; ".join(n["reasons"])) for k, n in g.nodes.items()
                          if n["flags"]["references_extracted"] in ("UNSUPPORTED", "MISSING") or n["flags"]["dynamic_resolution"] == "DYNAMIC_UNRESOLVED"})
    unreached_open = [r for r in regs if r["proposed"] == "cannot_determine"]
    unres_terms = [t for t in terms if t["class"] == "unresolved"]
    questions = [j for j, x in J.items() if isinstance(x, dict) and x.get("status") not in ("PROVEN",)]
    gates = {"material_outputs_not_fully_known": sum(1 for h in heads.values() if h != "FULL"),
             "material_formulas_truncated": sum(1 for k in mat_ref if k in g.nodes and (g.nodes[k]["flags"]["references_extracted"] in ("UNSUPPORTED", "MISSING")
                                                or g.nodes[k]["flags"]["dynamic_resolution"] == "DYNAMIC_UNRESOLVED")),
             "material_formulas_circular": sum(1 for k in mat_ref if k in g.nodes and g.nodes[k]["flags"]["cycle"] == "CIRCULAR"),
             "unreached_regions_cannot_determine": len(unreached_open), "unresolved_material_terminals": len(unres_terms),
             "pasted_value_candidates": len(pasted), "formulas_without_saved_value": inv["totals"]["formulas_without_saved_value"],
             "invariants_violated": sum(1 for r in invs["results"] if r["status"] == "VIOLATED")}
    wsha = sha256_file(path)
    summary = {
        "meta": {"discovery_version": VERSION, "graph_rules": GR.RULES, "period_rules": SE.PERIOD_RULES, "terminal_classes": SE.TERMINAL_CLASSES,
                 "rules_hashes": HASHES, "invariants_version": INVARIANTS["version"], "invariant_profile": profile,
                 "preflight": pre, "workbook": os.path.basename(path), "workbook_sha256": wsha, "workbook_fingerprint": m.fingerprint(),
                 "requested_period_target": period_end, "run_at": now().isoformat(), "python_only": True, "ai_interpretations": 0},
        "layer0": inv,
        "layer1": {"formula_nodes": len(g.nodes), "flags": fl, "material_flags": mfl, "hubs": [cell_text(*h) for h in hubs][:50],
                   "hub_count": len(hubs), "regions": [{k_: v_ for k_, v_ in r.items() if k_ != "_members"} for r in regs],
                   "fully_interpreted": sum(1 for n in g.nodes.values() if n["flags"]["references_extracted"] == "COMPLETE"
                                            and n["flags"]["dynamic_resolution"] != "DYNAMIC_UNRESOLVED"
                                            and (n["flags"]["location"] == "INTERNAL" or n["flags"]["external_identified"])),
                   "material_by_reference": len(mat_ref), "material_by_contribution": len(mat_con),
                   "material_formulas_contribution_unknown": sum(1 for k in mat_ref if k in g.nodes and k not in g.contrib),
                   "unsupported_or_dynamic_examples": [{"cell": c, "why": w} for c, w in unsupported[:40]]},
        "layer2": {"junctions": J, "output_headlines": heads, "terminals": terms, "pasted_value_candidates": pasted, "invariants": invs,
                   "period_status_counts": pcount, "analyst_confirmations_needed": len(questions), "questions": questions},
        "gates": gates}
    dump(summary, os.path.join(out, "workbook_map.json"))
    review(regs, os.path.join(out, "discovery_review.xlsx"), wsha)
    lap("write")
    dump({"discovery_version": VERSION, "timings_seconds": timings, "total_seconds": round(time.time() - t0, 2),
          "peak_memory_mb": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024, "python": platform.python_version(),
          "openpyxl": __import__("openpyxl").__version__, "formula_nodes": len(g.nodes), "stored_cells": len(m.cells)},
         os.path.join(out, "run_log.json"))
    return summary


def review(regs, path, wsha):
    from openpyxl import Workbook
    from openpyxl.worksheet.datavalidation import DataValidation
    wb = Workbook()
    ws = wb.active
    ws.title = "Unreached regions"
    ws.append(["Workbook SHA-256", wsha])
    ws.append(["Region", "Areas", "Formulas", "Sink labels (nearest row labels)", "Proposed by Python", "Analyst verdict", "Analyst note"])
    dv = DataValidation(type="list", formula1='"material,supporting,reference_only,historical,presentation,irrelevant,unsure"', allow_blank=True)
    ws.add_data_validation(dv)
    for r in regs:
        if r["proposed"] == "reached_from_outputs":
            continue
        ws.append([r["id"], "; ".join(r["areas"]), r["formulas"], "; ".join(x for x in r["sink_labels"] if x), r["proposed"], None, None])
        dv.add(f"F{ws.max_row}")
    wb.save(path)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="discover.py", description="Read one workbook (never changes it) and write its map.")
    ap.add_argument("--workbook", required=True, help="file name (searched where knowledge files and uploads land) or path")
    ap.add_argument("--period-end", required=True, help="the requested quarter end, YYYY-MM-DD: the TARGET, never evidence")
    ap.add_argument("--out", default=None, help="output folder (default: /app/created/map_<workbook> or ./map_<workbook>)")
    ap.add_argument("--profile", default=None, help="invariant profile in references/invariants.json (per-company overrides)")
    ap.add_argument("--version", action="version", version=f"workbook-discovery {VERSION}")
    a = ap.parse_args(argv)
    out = None
    try:
        if not (len(a.period_end) == 10 and a.period_end[4] == "-" and a.period_end[7] == "-"):
            raise Stop(f"--period-end must be YYYY-MM-DD (got '{a.period_end}')", "usage")
        path = find_input(a.workbook, "workbook")
        pre = check_workbook(path, RULES["preflight"])
        print(f"PREFLIGHT: OK {pre['kind']} | {pre['bytes'] / 1e6:.1f} MB | {pre['parts']} parts | macros {'yes' if pre['macros'] else 'no'} | "
              f"external link parts {pre['external_link_parts']}" + "".join(f" | warning: {w}" for w in pre["warnings"]), flush=True)
        out = out_root(a.out or "map_" + os.path.splitext(os.path.basename(path))[0][:60])
        s = run(path, a.period_end, out, a.profile, pre)
    except Stop as e:
        msg = str(e)
        print(msg if msg.startswith("PREFLIGHT:") else f"STOPPED: {msg}")
        return EXIT_STOPPED
    except Exception as e:                                   # a bug: one clear line here, the traceback in a file
        logp = os.path.join(out or os.getcwd(), "run_error.log")
        try:
            open(logp, "w").write(traceback.format_exc())
        except OSError:
            logp = "(not writable)"
        print(f"DISCOVERY ERROR: internal {type(e).__name__} - a bug, not a workbook problem; send this line and run_error.log to the maintainer")
        if os.environ.get("WD_DEBUG"):
            traceback.print_exc()
        return EXIT_INTERNAL
    t, l1, g = s["layer0"]["totals"], s["layer1"], s["gates"]
    re_ = l1["flags"]["references_extracted"]
    inv = s["layer2"]["invariants"]["results"]
    print(f"DISCOVERY: build {VERSION} | rules {GR.RULES['version']}/{SE.PERIOD_RULES['version']}/{INVARIANTS['version']} | python only")
    print(f"DISCOVERY: physical | worksheets {s['layer0']['worksheets']} | populated cells {t['populated_cells']} | formula cells {t['formula_cells']} | "
          f"array results {t['array_result_cells']} | defined names {s['layer0']['defined_names']} | tables {s['layer0']['tables']}")
    print(f"DISCOVERY: graph | formula nodes {l1['formula_nodes']} | complete {re_.get('COMPLETE', 0)} | over-approximated {re_.get('OVER_APPROXIMATED', 0)} | "
          f"unsupported {re_.get('UNSUPPORTED', 0)} | missing {re_.get('MISSING', 0)} | regions {len(l1['regions'])} | hubs {l1['hub_count']}")
    print("DISCOVERY: outputs | " + " | ".join(f"{k} {v.lower()}" for k, v in s["layer2"]["output_headlines"].items()))
    print("DISCOVERY: invariants | " + " | ".join(f"{st.lower().replace('_', ' ')} {sum(1 for r in inv if r['status'] == st)}"
                                                 for st in ("HOLDS", "VIOLATED", "NOT_APPLICABLE", "NOT_EVALUATED")))
    print("DISCOVERY: gates | " + " | ".join(f"{k.replace('_', ' ')} {v}" for k, v in g.items()))
    print(f"DISCOVERY: files written to {os.path.basename(out)} (workbook_map.json, cells.jsonl.gz, discovery_review.xlsx, run_log.json) - "
          "keep them in the authorised environment")
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
