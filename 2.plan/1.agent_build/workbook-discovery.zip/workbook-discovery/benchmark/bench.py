# benchmark/bench.py (build 11.5) - the BENCHMARK SYSTEM. Grades a discovery map against an INDEPENDENT Gold answer key.
# It reads discovery's OUTPUT FILES only and never imports discovery code (test B.1). Commands:
#   hash          SHA-256 of the frozen Gold workbook (the key is bound to it)
#   template      the analyst's answer-key workbook (blind junctions, blind regions, sample sheet, lists, instructions)
#   sample        frozen stratified sample of cells, drawn from the PHYSICAL inventory (xmlcount), fixed seed
#   freeze-blind  freezes the analyst's blind answers (timestamp + hash) BEFORE any discovery output is seen
#   key           builds answer_key.json from the frozen blind answers + Excel facts (+ the analyst's region review)
#   physical      tripwire: the standard-library checker's counts versus the map's Layer 0 counts
#   score         grades a map against the key; regression versus a previous result; sanitised BENCHMARK lines
# Exit codes: 0 done | 1 internal error (a bug) | 2 usage | 3 STOPPED (the user must act). Files are passed by name.
import argparse, datetime, json, os, random, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [HERE, os.path.dirname(HERE)]
from common.util import (VERSION, now, dump, load, sha256_file, sha256_text, canon, read_jsonl_gz, parse_box, box_text, box_cells,
                         cell_key, cell_text, split_addresses, Stop, EXIT_OK, EXIT_INTERNAL, EXIT_STOPPED)
from common.files import find_input, out_root
from common.preflight import check_workbook
from common.schema import validate, ANSWER_KEY, BLIND
import xmlcount as XC

SCHEMA = "gold-answer-key/1"
PROVENANCE = ("blind", "confirmed_after_proposal", "corrected", "analyst_added", "excel")
JUNCTIONS = [("enterprise_value", "Which cell is the final enterprise value of the requested quarter?"),
             ("equity_value", "Which cell is the equity value?"),
             ("value_to_xpv", "Which cell is the value attributable to XPV (the number the LP report uses)?"),
             ("valuation_metric", "Which cell holds the metric the valuation actually uses (e.g. TTM adjusted EBITDA)?"),
             ("selected_multiple", "Which cell is the selected multiple that actually feeds the valuation (not a comparable)?")]
VALUE_QUESTIONS = [("metric_period", "Which month does that metric END in? (YYYY-MM)"),
                   ("metric_window_first", "First month of the metric's window (YYYY-MM)"),
                   ("metric_window_last", "Last month of the metric's window (YYYY-MM)"),
                   ("method", "Valuation method (ev_ebitda, ev_revenue, blended, held_at_cost, custom_formula)")]
PURPOSES = ["material", "supporting", "reference_only", "historical", "presentation", "irrelevant"]
KINDS = ["calculation (formula)", "typed financial data", "typed balance-sheet data", "EBITDA adjustment input", "cap-table/share data",
         "market/comparable input", "FX input", "valuation assumption", "investment/fund record", "date input",
         "external-workbook value", "add-in/provider value", "label / not an input", "unsure"]
STRATA = [("F-xsheet", "formula reading another sheet"), ("F-local", "formula reading only its own sheet"),
          ("F-range", "formula with a range"), ("F-lookup", "lookup, conditional or dynamic function"),
          ("F-agg", "aggregate function (SUM, AVERAGE, MEDIAN, MIN, MAX)"), ("F-external", "formula reading another workbook"),
          ("F-name", "formula using a defined name"), ("F-nosaved", "formula without a saved value"),
          ("F-shared", "member of a shared (copied) formula"), ("F-array", "array / spill formula"),
          ("T-xref", "typed number another sheet's formula reads"), ("T-local", "typed number a same-sheet formula reads"),
          ("E-error", "cell showing an Excel error")]


# ------------------------------------------------------------------------------------------------ template and sample
def cmd_template(a):
    from openpyxl import Workbook
    from openpyxl.worksheet.datavalidation import DataValidation
    wsha = sha256_file(a.workbook)
    wb = Workbook()
    r = wb.active
    r.title = "README"
    for row in [["Gold answer key - analyst workbook (build " + VERSION + ")"], [],
                ["Gold ID", a.gold_id], ["Workbook", os.path.basename(a.workbook)], ["Workbook SHA-256", wsha],
                ["Requested quarter end", a.period_end], [],
                ["Glossary"], ["Gold workbook", "A frozen, approved historical valuation workbook used only to test the discovery system"],
                ["Blind", "Answered from the workbook itself BEFORE seeing anything the discovery system produced"],
                ["Junction", "An important valuation cell: enterprise value (EV), equity value, value to XPV, metric, selected multiple"],
                ["Region", "An area of the workbook (Sheet!A1:Z50, or a sheet name for the whole sheet)"],
                ["TTM", "Trailing twelve months: the 12 months ending at the valuation month"], [],
                ["How to fill it"], ["1", "Sheet '1 Blind junctions': give each cell as Sheet!Cell, and the values asked for"],
                ["2", "Sheet '2 Blind regions': list the material areas and the known reference-only / historical / presentation areas"],
                ["3", "Sheet '3 Sample': for each listed cell give its period (YYYY-MM, 'none' or 'unsure') and its kind"],
                ["4", "Do not run discovery or open its outputs until this file is frozen (bench.py freeze-blind)"]]:
        r.append(row)
    j = wb.create_sheet("1 Blind junctions")
    j.append(["Junction", "Question", "Answer (Sheet!Cell or value)", "Notes"])
    for k, q in JUNCTIONS + VALUE_QUESTIONS:
        j.append([k, q, None, None])
    g = wb.create_sheet("2 Blind regions")
    g.append(["Purpose", "Area (Sheet!A1:Z50 or sheet name)", "Description"])
    dv = DataValidation(type="list", formula1="Lists!$A$2:$A$7", allow_blank=True)
    g.add_data_validation(dv)
    dv.add("A2:A200")
    s = wb.create_sheet("3 Sample")
    s.append(["ID", "Cell", "Stratum (physical)", "Period (YYYY-MM / none / unsure)", "Kind", "Notes"])
    dk = DataValidation(type="list", formula1=f"Lists!$B$2:$B${len(KINDS) + 1}", allow_blank=True)
    s.add_data_validation(dk)
    dk.add("E2:E500")
    L = wb.create_sheet("Lists")
    L.append(["Purpose", "Kind"])
    for i in range(max(len(PURPOSES), len(KINDS))):
        L.append([PURPOSES[i] if i < len(PURPOSES) else None, KINDS[i] if i < len(KINDS) else None])
    wb.save(a.out)
    print(f"BENCHMARK: template written for {a.gold_id} (workbook hash recorded) - give it to the analyst before any discovery run")
    return 0


FN = re.compile(r"([A-Z][A-Z0-9.]*)\s*\(")
REFS = re.compile(r"(?:'((?:[^']|'')+)'|([A-Za-z_][A-Za-z0-9_.]*))?!?\$?([A-Z]{1,3})\$?(\d+)")


def strata_of(f, names):
    sh, r, c, text, fl = f
    t = (text or "").upper()
    out = ["F-xsheet" if "!" in t else "F-local"]
    if ":" in t:
        out.append("F-range")
    fns = set(FN.findall(t))
    if fns & {"INDEX", "MATCH", "XMATCH", "VLOOKUP", "HLOOKUP", "XLOOKUP", "LOOKUP", "SUMIF", "SUMIFS", "COUNTIF", "COUNTIFS", "CHOOSE", "OFFSET", "INDIRECT"}:
        out.append("F-lookup")
    if fns & {"SUM", "AVERAGE", "MEDIAN", "MIN", "MAX"}:
        out.append("F-agg")
    if re.search(r"\[\d+\]|\.XLS[XMB]?\]", t):
        out.append("F-external")
    if any(re.search(rf"(?<![A-Z0-9_.]){re.escape(n.upper())}(?![A-Z0-9_(])", t) for n in names):
        out.append("F-name")
    if fl["no_saved_value"]:
        out.append("F-nosaved")
    if fl["shared"]:
        out.append("F-shared")
    if fl["array"]:
        out.append("F-array")
    return out


def draw_sample(path, seed, per, cap):
    """deterministic, stratified by PHYSICAL properties only (never by what discovery concluded)."""
    x = XC.scan(path, want_formulas=True)
    order = {s["name"]: i for i, s in enumerate(x["sheets"])}
    pools = {s: [] for s, _ in STRATA}
    referenced_x, referenced_l = set(), set()
    for f in x["formulas"]:
        for st in strata_of(f, x["defined_name_list"]):
            pools[st].append((f[0], f[1], f[2]))
        for m in REFS.finditer((f[3] or "").upper()):
            sh = (m.group(1) or m.group(2) or "").replace("''", "'")
            real = next((s for s in order if s.upper() == sh.upper()), None) if sh else f[0]
            if real:
                (referenced_x if real != f[0] else referenced_l).add((real, int(m.group(4)), sum((ord(ch) - 64) * 26 ** i for i, ch in enumerate(reversed(m.group(3))))))
    typed = set(x["typed_numbers"])
    pools["T-xref"] = sorted(typed & referenced_x)
    pools["T-local"] = sorted((typed & referenced_l) - referenced_x)
    rng = random.Random(seed)
    chosen, seen = [], set()
    for st, desc in STRATA:
        cands = sorted(set(pools[st]) - seen, key=lambda k: (order.get(k[0], 999), k[1], k[2]))
        pick = rng.sample(cands, min(per, len(cands)))
        for k in sorted(pick, key=lambda k: (order.get(k[0], 999), k[1], k[2])):
            if len(chosen) < cap:
                chosen.append((st, desc, k))
                seen.add(k)
    return chosen, x


def cmd_sample(a):
    from openpyxl import load_workbook
    chosen, x = draw_sample(a.workbook, a.seed, a.per_stratum, a.max)
    wb = load_workbook(a.template)
    s = wb["3 Sample"]
    if s.max_row > 1:
        print("STOPPED: the template already has a sample; a Gold sample is drawn once and frozen. Use a new template for a new key version.")
        return 3
    for i, (st, desc, k) in enumerate(chosen, 1):
        s.append([f"S{i:02d}", cell_text(*k), f"{st}: {desc}", None, None, None])
    r = wb["README"]
    r.append([])
    r.append(["Sample", f"seed {a.seed}, {a.per_stratum} per stratum, at most {a.max}, drawn from the physical inventory"])
    wb.save(a.template)
    req = {"mode": "precedents", "cells": [cell_text(*k) for _, _, k in chosen]}
    open(a.request_out, "w").write(json.dumps(req))
    print(f"BENCHMARK: sample of {len(chosen)} cell(s) across {len({c[0] for c in chosen})} physical strata written to the template; "
          f"Office Script request written ({os.path.basename(a.request_out)})")
    return 0


# ------------------------------------------------------------------------------------------------ freeze and key
def _cell_ok(t):
    try:
        cell_key(str(t))
        return True
    except ValueError:
        return False


def cmd_freeze(a):
    from openpyxl import load_workbook
    wb = load_workbook(a.template, data_only=True)
    readme = {row[0]: row[1] for row in wb["README"].iter_rows(values_only=True) if row and row[0]}
    J, problems = {}, []
    for row in list(wb["1 Blind junctions"].iter_rows(values_only=True))[1:]:
        if not row or not row[0]:
            continue
        k, ans = row[0], (str(row[2]).strip() if row[2] is not None else "")
        if k in dict(JUNCTIONS):
            if not _cell_ok(ans):
                problems.append(f"{k}: '{ans or '(empty)'}' is not Sheet!Cell")
                continue
        J[k] = {"answer": ans or None, "notes": row[3], "provenance": "blind"}
    regions = []
    for i, row in enumerate(list(wb["2 Blind regions"].iter_rows(values_only=True))[1:], 1):
        if row and row[0] and row[1]:
            if row[0] not in PURPOSES:
                problems.append(f"region row {i + 1}: purpose '{row[0]}' is not one of {', '.join(PURPOSES)}")
            regions.append({"id": f"K-R{i}", "purpose": row[0], "area": str(row[1]).strip(), "description": row[2], "provenance": "blind"})
    sample = []
    for row in list(wb["3 Sample"].iter_rows(values_only=True))[1:]:
        if row and row[0]:
            per = str(row[3]).strip() if row[3] is not None else "unsure"
            if per not in ("none", "unsure") and not re.fullmatch(r"\d{4}-\d{2}", per):
                problems.append(f"{row[0]}: period '{per}' is not YYYY-MM, none or unsure")
            sample.append({"id": row[0], "cell": row[1], "stratum": str(row[2]).split(":")[0], "period": per,
                           "kind": row[4] or "unsure", "notes": row[5], "provenance": "blind"})
    if problems:
        print("STOPPED: the blind answers are incomplete: " + "; ".join(problems[:10]))
        return 3
    body = {"schema": "gold-blind/1", "gold_id": readme.get("Gold ID"), "workbook": readme.get("Workbook"),
            "workbook_sha256": readme.get("Workbook SHA-256"), "requested_period": readme.get("Requested quarter end"),
            "frozen_by": a.by, "frozen_at": now().isoformat(), "junctions": J, "regions": regions, "sample": sample}
    body["sha256"] = sha256_text(canon(body))
    dump(body, a.out)
    print(f"BENCHMARK: blind answers frozen for {body['gold_id']} by the analyst | {len(J)} junction answers | {len(regions)} regions | "
          f"{len(sample)} sample cells | store this file read-only")
    return 0


def _facts(paths):
    out = {"counts": None, "precedents": {}}
    for p in paths or []:
        d = load(p)
        d = json.loads(d["result"]) if isinstance(d, dict) and isinstance(d.get("result"), str) else d
        if d.get("mode") == "counts":
            out["counts"] = d
        elif d.get("mode") == "precedents":
            out["precedents"].update(d.get("precedents", {}))
    return out


def cmd_key(a):
    blind = validate(load(a.blind), BLIND, "blind answers file")
    body = {k: v for k, v in blind.items() if k != "sha256"}
    if sha256_text(canon(body)) != blind.get("sha256"):
        print("STOPPED: the blind answers file was changed after it was frozen. Use the frozen file.")
        return 3
    wsha = sha256_file(a.workbook)
    if wsha != blind["workbook_sha256"]:
        print("STOPPED: this workbook is not the Gold workbook the blind answers were given for (hash differs).")
        return 3
    if a.map_meta:
        run_at = load(a.map_meta)["meta"]["run_at"]
        if run_at <= blind["frozen_at"]:
            print("STOPPED: the discovery run used for the region review is older than the blind answers' freeze time - "
                  "the blind answers may not be blind. Freeze first, then run discovery.")
            return 3
    F = _facts(a.facts)
    c = F["counts"]
    if not c:
        print("STOPPED: no Excel counts (run gold-facts.ts in counts mode on the Gold workbook and pass its result with --facts).")
        return 3
    phys = {"source": "excel (gold-facts.ts)", "worksheets": len(c["sheets"]), "sheet_names": [s["name"] for s in c["sheets"]],
            "formula_cells": sum(s["formulas"] for s in c["sheets"]), "populated_cells": sum(s["populated"] for s in c["sheets"]),
            "errors": sum(s["errors"] for s in c["sheets"]), "defined_names": c.get("defined_names"), "tables": c.get("tables"),
            "external_links": c.get("linked_workbooks"),
            "per_sheet": {s["name"]: {"formulas": s["formulas"], "populated": s["populated"], "errors": s["errors"]} for s in c["sheets"]}}
    J = blind["junctions"]
    outs = {k: {"cell": J[k]["answer"], "provenance": "blind"} for k in ("enterprise_value", "equity_value", "value_to_xpv") if J.get(k, {}).get("answer")}
    junc = {k: {"cell": J[k]["answer"], "provenance": "blind"} for k in ("valuation_metric", "selected_multiple") if J.get(k, {}).get("answer")}
    for k in ("metric_period", "metric_window_first", "metric_window_last", "method"):
        if J.get(k, {}).get("answer"):
            junc[k] = {"value": J[k]["answer"], "provenance": "blind"}
    req, irr = [], []
    for r in blind["regions"]:
        (req if r["purpose"] in ("material", "supporting") else irr).append(r)
    if a.review:
        from openpyxl import load_workbook
        ws = load_workbook(a.review, data_only=True)["Unreached regions"]
        rows = list(ws.iter_rows(values_only=True))
        if rows and rows[0][1] != wsha:
            print("STOPPED: the region review is for a different workbook.")
            return 3
        for row in rows[2:]:
            if row and row[0] and row[5] in PURPOSES:
                for j, area in enumerate(x.strip() for x in str(row[1]).split(";") if x.strip()):
                    rec = {"id": f"K-{row[0]}-{j + 1}", "purpose": row[5], "area": area, "description": row[6],
                           "provenance": "confirmed_after_proposal", "by": a.by}
                    (req if row[5] in ("material", "supporting") else irr).append(rec)
    samples = []
    for s in blind["sample"]:
        dep = F["precedents"].get(s["cell"])
        samples.append(dict(s, depends_on=dep if isinstance(dep, list) else None,
                            depends_on_source="excel (getDirectPrecedents)" if isinstance(dep, list) else f"unavailable: {dep}" if dep else "not provided"))
    key = {"schema": SCHEMA, "key_version": a.version, "gold_id": blind["gold_id"], "workbook": {"name": blind["workbook"], "sha256": wsha},
           "requested_period": blind["requested_period"], "created_on": now().isoformat(), "created_by": a.by,
           "blind_frozen_at": blind["frozen_at"], "blind_sha256": blind["sha256"], "physical_structure": phys,
           "important_outputs": outs, "junctions": junc, "required_workbook_regions": req, "known_irrelevant_regions": irr,
           "confirmed_dependency_samples": samples}
    for sec in ("important_outputs", "junctions"):
        for k, v in key[sec].items():
            assert v["provenance"] in PROVENANCE
    for x in req + irr + samples:
        if x.get("provenance") not in PROVENANCE:
            print(f"STOPPED: entry {x.get('id')} has no valid provenance.")
            return 3
    key["sha256"] = sha256_text(canon(key))
    dump(key, a.out)
    print(f"BENCHMARK: answer key {key['gold_id']} {a.version} built | outputs {len(outs)} | junctions {len(junc)} | regions {len(req)} material "
          f"and {len(irr)} not | samples {len(samples)} ({sum(1 for s in samples if s['depends_on'] is not None)} with Excel precedents) | freeze it read-only")
    return 0


# ------------------------------------------------------------------------------------------------ scoring
def _cells_of(addresses, default_sheet, sheets_lc):
    out, unbounded = set(), False
    for t in split_addresses(addresses):
        b = parse_box(t, default_sheet)
        if not b:
            continue
        sh = sheets_lc.get((b[0] or "").lower(), b[0])
        cs = box_cells((sh,) + b[1:], 50_000)
        if cs is None:
            unbounded = True
        else:
            out |= cs
    return out, unbounded


def _in_area(cell, area, sheets_lc):
    if area.strip().lower() in sheets_lc:
        return cell[0] == sheets_lc[area.strip().lower()]
    b = parse_box(area)
    if not b:
        return False
    sh = sheets_lc.get((b[0] or "").lower(), b[0])
    return cell[0] == sh and b[1] <= cell[1] <= b[3] and b[2] <= cell[2] <= b[4]


def _areas_overlap(region_areas, area, sheets_lc):
    for ra in region_areas:
        b = parse_box(ra)
        if not b:
            continue
        if area.strip().lower() in sheets_lc:
            if b[0] == sheets_lc[area.strip().lower()]:
                return True
            continue
        k = parse_box(area)
        if k and sheets_lc.get((k[0] or "").lower(), k[0]) == b[0] and not (k[3] < b[1] or b[3] < k[1] or k[4] < b[2] or b[4] < k[2]):
            return True
    return False


def score(map_dir, key, previous=None, other=None):
    meta = load(os.path.join(map_dir, "workbook_map.json"))
    M = meta
    if M["meta"]["workbook_sha256"] != key["workbook"]["sha256"]:
        return None, "the map was produced from a different workbook than the Gold key (hash differs)"
    cells = {r["cell"]: r for r in read_jsonl_gz(os.path.join(map_dir, "cells.jsonl.gz"))}
    sheets = M["layer0"]["sheets"]
    sheets_lc = {s.lower(): s for s in sheets}
    norm = lambda t: cell_text(*cell_key(t, None)) if t and _cell_ok(t) else t
    checks = []

    def chk(cid, family, status, detail="", **kw):
        checks.append(dict({"id": cid, "family": family, "status": status, "detail": detail}, **kw))
    # 1. physical (truth: Excel's own counts in the key)
    P, T = key["physical_structure"], M["layer0"]["totals"]
    mn = set(sheets)
    chk("P.worksheets", "physical", "PASS" if set(P["sheet_names"]) == mn else "FAIL", f"{len(mn)} of {P['worksheets']}",
        found=len(set(P["sheet_names"]) & mn), expected=P["worksheets"])
    for name, mine, theirs in (("formula_cells", T["formula_cells"], P["formula_cells"]), ("populated_cells", T["populated_cells"], P["populated_cells"]),
                               ("errors", T["errors"], P["errors"]), ("tables", M["layer0"]["tables"], P.get("tables")),
                               ("external_links", M["layer0"].get("external_link_records"), P.get("external_links"))):
        if theirs is None or mine is None:
            continue
        chk(f"P.{name}", "physical", "PASS" if mine == theirs else "FAIL", f"{mine} of {theirs}", found=mine, expected=theirs)
    vis_names = M["layer0"].get("visible_defined_names", M["layer0"]["defined_names"])
    if P.get("defined_names") is not None:
        chk("P.defined_names", "physical", "PASS" if vis_names == P["defined_names"] else "FAIL", f"{vis_names} of {P['defined_names']}",
            found=vis_names, expected=P["defined_names"])
    bad_sheets = [s for s, v in P["per_sheet"].items() if s in M["layer0"]["sheets"] and
                  (M["layer0"]["sheets"][s]["formula_cells"] != v["formulas"])]
    chk("P.per_sheet_formulas", "physical", "PASS" if not bad_sheets else "FAIL", f"{len(P['per_sheet']) - len(bad_sheets)} of {len(P['per_sheet'])}",
        found=len(P["per_sheet"]) - len(bad_sheets), expected=len(P["per_sheet"]), sheets=bad_sheets)
    # formula understanding (denominator: Excel's formula count)
    fl, den = M["layer1"]["flags"], P["formula_cells"]
    ref_ok = fl["references_extracted"].get("COMPLETE", 0) + fl["references_extracted"].get("OVER_APPROXIMATED", 0)
    understanding = {"formula_text_captured": (M["layer1"]["formula_nodes"], den), "references_extracted": (ref_ok, den),
                     "fully_interpreted": (M["layer1"].get("fully_interpreted", 0), den),
                     "numerically_recomputed": (fl["value_verification"].get("RECOMPUTED", 0), M["layer1"]["formula_nodes"]),
                     "unsupported": fl["references_extracted"].get("UNSUPPORTED", 0) + fl["references_extracted"].get("MISSING", 0),
                     "dynamic_unresolved": fl["dynamic_resolution"].get("DYNAMIC_UNRESOLVED", 0),
                     "flags_on_every_formula": all(r["l1"]["flags"] for r in cells.values() if r["l0"]["kind"] == "formula")}
    chk("G.no_silent_truncation", "relationships", "PASS" if understanding["flags_on_every_formula"] else "FAIL",
        "every formula node carries graph-status flags")
    # 3. financial interpretation: outputs and junctions (exact cells in the frozen file)
    J = M["layer2"]["junctions"]
    jres = {"correct": 0, "expected": 0, "claimed": 0, "proven_wrong": 0}
    for k, v in sorted(list(key["important_outputs"].items()) + [(k, v) for k, v in key["junctions"].items() if "cell" in v]):
        mine = J.get(k, {}).get("cell")
        jres["expected"] += 1
        jres["claimed"] += mine is not None
        ok = mine is not None and norm(mine) == norm(v["cell"])
        jres["correct"] += ok
        st = J.get(k, {}).get("status")
        if not ok and st == "PROVEN":
            jres["proven_wrong"] += 1
        chk(f"J.{k}", "interpretation", "PASS" if ok else "FAIL", "found" if ok else ("missing" if mine is None else "different cell"),
            status_claimed=st, expected_cell=v["cell"], got_cell=mine, provenance=v["provenance"])
    mw = J.get("metric_window", {})
    for k, mine in (("metric_period", mw.get("last")), ("metric_window_first", mw.get("first")), ("metric_window_last", mw.get("last"))):
        if k in key["junctions"]:
            ok = mine == key["junctions"][k]["value"]
            if not ok and mw.get("status") == "PROVEN" and mine:
                jres["proven_wrong"] += 1
            chk(f"J.{k}", "interpretation", "PASS" if ok else "FAIL", "", expected_value=key["junctions"][k]["value"], got_value=mine,
                status_claimed=mw.get("status"))
    if "method" in key["junctions"]:
        gv = J.get("method", {}).get("variant")
        chk("J.method", "interpretation", "PASS" if gv == key["junctions"]["method"]["value"] else "FAIL", "",
            expected_value=key["junctions"]["method"]["value"], got_value=gv)
    # 2/3. frozen sample: relationships (truth: Excel's direct precedents), periods and kinds (truth: blind analyst)
    rel = {"exact": 0, "over_flagged": 0, "missing_flagged": 0, "silent_omission": 0, "unflagged_extra": 0, "no_truth": 0}
    per = {"correct": 0, "wrong": 0, "abstained": 0, "unscored": 0, "proven_wrong": 0, "false_certainty": 0}
    kind = {"correct": 0, "wrong": 0, "unscored": 0}
    for s in key["confirmed_dependency_samples"]:
        c = norm(s["cell"])
        r = cells.get(c)
        sid = s["id"]
        if r is None:
            r = {"l0": {"kind": "empty"}, "l1": {"refs": [], "flags": None}, "l2": {"period": {"period": None, "status": "NOT_DETERMINABLE"}}}
        if s.get("depends_on") is None:
            rel["no_truth"] += 1
        else:
            truth, tu = _cells_of(s["depends_on"], cell_key(c)[0], sheets_lc)
            mine, mu = _cells_of([x["ref"] for x in r["l1"]["refs"] if x.get("status") not in ("EXTERNAL", "MISSING", "UNSUPPORTED")],
                                 cell_key(c)[0], sheets_lc)
            fl_ = r["l1"]["flags"] or {}
            unresolved = fl_.get("references_extracted") in ("UNSUPPORTED", "MISSING") or fl_.get("dynamic_resolution") == "DYNAMIC_UNRESOLVED"
            miss, extra = truth - mine, mine - truth
            if not miss and not extra:
                res = "exact"
            elif miss:
                res = "missing_flagged" if unresolved else "silent_omission"
            else:
                res = "over_flagged" if fl_.get("references_extracted") == "OVER_APPROXIMATED" else "unflagged_extra"
            rel[res] += 1
            chk(f"S.{sid}.dependencies", "relationships", "PASS" if res in ("exact", "over_flagged", "missing_flagged") else "FAIL", res,
                cell=c, missing=len(miss), extra=len(extra))
        kp, mp = s["period"], r["l2"]["period"]
        if kp == "unsure":
            per["unscored"] += 1
        else:
            determined = mp["status"] in ("PROVEN", "SUPPORTED")
            if kp == "none":
                res = "false_certainty" if determined and mp["status"] == "PROVEN" else "correct"
            elif not determined:
                res = "abstained"
            else:
                res = "correct" if mp["period"] == kp else "wrong"
            if res == "wrong" and mp["status"] == "PROVEN":
                per["proven_wrong"] += 1
            if res == "false_certainty":
                per["false_certainty"] += 1
                per["wrong"] += 1
            else:
                per[res] += 1
            chk(f"S.{sid}.period", "interpretation", "FAIL" if res in ("wrong", "false_certainty") else "PASS" if res == "correct" else "ABSTAINED",
                res, cell=c, expected=kp, got=mp["period"], status_claimed=mp["status"])
        kk = s.get("kind") or "unsure"
        mk = "calculation (formula)" if r["l0"]["kind"] in ("formula", "array_result") else r["l2"].get("terminal_class")
        if kk == "unsure" or mk is None:
            kind["unscored"] += 1
        else:
            ok = mk == kk
            kind["correct" if ok else "wrong"] += 1
            chk(f"S.{sid}.kind", "interpretation", "PASS" if ok else "FAIL", "", cell=c, expected=kk, got=mk)
    # regions
    reached_cells = [r["cell"] for r in cells.values() if r["l2"]["material_by_reference"]]
    reached_keys = [cell_key(x) for x in reached_cells]
    reg = {"material_expected": 0, "material_reached": 0, "irrelevant_conflicts": 0}
    for r in key["required_workbook_regions"]:
        hit = any(_in_area(k, r["area"], sheets_lc) for k in reached_keys)
        if r["purpose"] == "material":
            reg["material_expected"] += 1
            reg["material_reached"] += hit
            chk(f"R.{r['id']}", "interpretation", "PASS" if hit else "FAIL", "reached" if hit else "missed material region", area=r["area"])
    for r in key["known_irrelevant_regions"]:
        hit = any(_in_area(k, r["area"], sheets_lc) for k in reached_keys)
        reg["irrelevant_conflicts"] += hit
        chk(f"R.{r['id']}", "interpretation", "FAIL" if hit else "PASS", "the outputs depend on an area the key calls " + r["purpose"] if hit else "not reached",
            area=r["area"])
    key_areas = [r["area"] for r in key["required_workbook_regions"] + key["known_irrelevant_regions"]]
    unaccounted = [g["id"] for g in M["layer1"]["regions"] if g["proposed"] == "cannot_determine"
                   and not any(_areas_overlap(g["areas"], a, sheets_lc) for a in key_areas)]
    # 4. completeness gates (open items, never averaged)
    gates = dict(M["gates"])
    gates["unreached_regions_cannot_determine"] = len(unaccounted)
    gates["sample_silent_omissions"] = rel["silent_omission"]
    gates["proven_but_wrong"] = per["proven_wrong"] + jres["proven_wrong"]
    unscored = {"junction_proposals_without_key": sum(1 for k, v in J.items() if isinstance(v, dict) and v.get("cell") and k not in key["important_outputs"] and k not in key["junctions"]),
                "material_terminals_not_in_sample": sum(1 for t in M["layer2"]["terminals"] if norm(t["cell"]) not in {norm(s["cell"]) for s in key["confirmed_dependency_samples"]}),
                "regions_not_in_key": sum(1 for g in M["layer1"]["regions"] if not any(_areas_overlap(g["areas"], a, sheets_lc) for a in key_areas))}
    invr = (M["layer2"].get("invariants") or {}).get("results", [])
    inv_sum = {st: sum(1 for r in invr if r["status"] == st) for st in ("HOLDS", "VIOLATED", "NOT_APPLICABLE", "NOT_EVALUATED")}
    terms = M["layer2"]["terminals"]
    term_acc = {"material_terminals": len(terms), "classified": sum(1 for t in terms if t["class"] != "unresolved"),
                "unresolved": sum(1 for t in terms if t["class"] == "unresolved"),
                "by_class": {c: sum(1 for t in terms if t["class"] == c) for c in sorted({t["class"] for t in terms})}}
    human = {"python_only_determinations": sum(1 for v in J.values() if isinstance(v, dict) and v.get("status") == "PROVEN"),
             "ai_interpretations": M["meta"].get("ai_interpretations", 0),
             "analyst_confirmations_needed": M["layer2"]["analyst_confirmations_needed"],
             "unresolved_after_review": len(unaccounted) + term_acc["unresolved"]}
    phys_pass = all(c["status"] == "PASS" for c in checks if c["family"] == "physical")
    graph_pass = (all(c["status"] == "PASS" for c in checks if c["id"].startswith("J.") and c["id"].split(".")[1] in key["important_outputs"])
                  and rel["silent_omission"] == 0 and gates["proven_but_wrong"] == 0 and per["false_certainty"] == 0
                  and reg["material_reached"] == reg["material_expected"] and understanding["flags_on_every_formula"])
    open_gates = {k: v for k, v in gates.items() if v}
    prev_status = {c["id"]: c["status"] for c in (previous or {}).get("checks", [])}
    reg_out = {"previous_build": (previous or {}).get("meta", {}).get("discovery_version"), "new_failures": [], "fixed": [],
               "still_failing": [], "still_passing": [], "new_checks": [],
               "method_changed": bool(previous) and (previous["meta"].get("rules") != {"graph": M["meta"]["graph_rules"]["version"], "period": M["meta"]["period_rules"]["version"]}
                                                      or (previous["meta"].get("rules_hashes") not in (None, M["meta"].get("rules_hashes"))))}
    for c in checks:
        p = prev_status.get(c["id"])
        if p is None:
            reg_out["new_checks"].append(c["id"]) if previous else None
        elif p == "PASS" and c["status"] == "FAIL":
            reg_out["new_failures"].append(c["id"])
        elif p == "FAIL" and c["status"] == "PASS":
            reg_out["fixed"].append(c["id"])
        elif c["status"] == "FAIL":
            reg_out["still_failing"].append(c["id"])
        else:
            reg_out["still_passing"].append(c["id"])
    other_ok = bool(other) and other.get("result", {}).get("material_graph") == "PASS" and other.get("meta", {}).get("gold_id") != key["gold_id"]
    safe = phys_pass and graph_pass and not open_gates and other_ok and not reg_out["new_failures"]
    result = {"meta": {"benchmark_version": VERSION, "discovery_version": M["meta"]["discovery_version"],
                       "rules": {"graph": M["meta"]["graph_rules"]["version"], "period": M["meta"]["period_rules"]["version"]},
                       "gold_id": key["gold_id"], "key_version": key["key_version"], "key_sha256": key.get("sha256"),
                       "workbook_sha256": key["workbook"]["sha256"], "requested_period": key["requested_period"], "scored_at": now().isoformat(),
                       "test_suite": VERSION, "python_only": M["meta"].get("python_only", True),
                       "rules_hashes": M["meta"].get("rules_hashes"), "invariant_profile": M["meta"].get("invariant_profile")},
              "checks": checks, "understanding": understanding, "junctions": jres, "relationships": rel, "periods": per, "kinds": kind,
              "regions": dict(reg, unaccounted=unaccounted), "terminals": term_acc, "gates": gates, "unscored": unscored, "human": human,
              "invariants": {"version": (M["layer2"].get("invariants") or {}).get("version"), "summary": inv_sum, "results": invr},
              "regression": reg_out,
              "result": {"physical_import": "PASS" if phys_pass else "FAIL", "material_graph": "PASS" if graph_pass else "FAIL",
                         "safe_to_design_generation": "YES" if safe else "NO",
                         "why_not": ([] if phys_pass else ["physical import"]) + ([] if graph_pass else ["material graph"])
                                    + ([f"open gates: {', '.join(sorted(open_gates))}"] if open_gates else [])
                                    + ([] if other_ok else ["needs a second, structurally different Gold workbook to pass"])
                                    + (["new regression failures"] if reg_out["new_failures"] else [])}}
    return result, None


VOCAB = set("""BENCHMARK workbook import build rules key gold hash ok physical worksheets populated cells formula errors tables defined
names external links per sheet formulas of PASS FAIL understanding text captured references extracted fully interpreted numerically
recomputed unsupported dynamic unresolved every formula carries flags period cases correct wrong abstained false certain
determinations proven but material web outputs found important junctions confirmed relationships exact over flagged missing silent
omissions unflagged extra regions accounted reached unaccounted conflicts with terminal inputs classified human python only ai
interpretations analyst confirmations needed after review regression previous checks still passing new failures fixed method
changed result safe to proceed design generation yes no gates open unscored claims kinds not in sample terminals proposals truncated
circular pasted value candidates without saved outputs fully known reach graph none version n a the and for invariants consistency
truth holds violated applicable evaluated""".split())


def sanitised_lines(res, redact=False):
    n = lambda x: "n" if redact else str(x)
    pr = lambda a, b: (f"{n(a)} of {n(b)}")
    u, j, r, p, rg, t, h, R = (res[k] for k in ("understanding", "junctions", "relationships", "periods", "regions", "terminals", "human", "result"))
    ch = {c["id"]: c for c in res["checks"]}
    phys = [c for c in res["checks"] if c["family"] == "physical"]
    L = [f"BENCHMARK: workbook import benchmark | build {res['meta']['benchmark_version']} | rules {res['meta']['rules']['graph']} {res['meta']['rules']['period']} | key {res['meta']['key_version']} | gold hash ok",
         "BENCHMARK: physical | " + " | ".join(f"{c['id'][2:].replace('_', ' ')} {pr(c.get('found'), c.get('expected'))} {c['status']}" for c in phys),
         f"BENCHMARK: formula understanding | text captured {pr(*u['formula_text_captured'])} | references extracted {pr(*u['references_extracted'])} | "
         f"fully interpreted {pr(*u['fully_interpreted'])} | numerically recomputed {pr(*u['numerically_recomputed'])} | unsupported {n(u['unsupported'])} | "
         f"dynamic unresolved {n(u['dynamic_unresolved'])} | flags on every formula {'PASS' if u['flags_on_every_formula'] else 'FAIL'}",
         f"BENCHMARK: period understanding | correct {n(p['correct'])} | wrong {n(p['wrong'])} | abstained {n(p['abstained'])} | false certain {n(p['false_certainty'])} | "
         f"proven but wrong {n(p['proven_wrong'])} | unscored {n(p['unscored'])}",
         f"BENCHMARK: material web | outputs and junctions found {pr(j['correct'], j['expected'])} | proven but wrong {n(j['proven_wrong'])} | "
         f"confirmed relationships exact {pr(r['exact'], r['exact'] + r['over_flagged'] + r['missing_flagged'] + r['silent_omission'] + r['unflagged_extra'])} | "
         f"over flagged {n(r['over_flagged'])} | missing flagged {n(r['missing_flagged'])} | silent omissions {n(r['silent_omission'])} | unflagged extra {n(r['unflagged_extra'])} | "
         f"material regions reached {pr(rg['material_reached'], rg['material_expected'])} | conflicts with key {n(rg['irrelevant_conflicts'])} | unaccounted regions {n(len(rg['unaccounted']))}",
         f"BENCHMARK: invariants consistency not truth | holds {n(res['invariants']['summary']['HOLDS'])} | violated {n(res['invariants']['summary']['VIOLATED'])} | "
         f"not applicable {n(res['invariants']['summary']['NOT_APPLICABLE'])} | not evaluated {n(res['invariants']['summary']['NOT_EVALUATED'])}",
         f"BENCHMARK: terminal accounting | material inputs {n(t['material_terminals'])} | classified {n(t['classified'])} | unresolved {n(t['unresolved'])}",
         f"BENCHMARK: human | python only determinations {n(h['python_only_determinations'])} | ai interpretations {n(h['ai_interpretations'])} | "
         f"analyst confirmations needed {n(h['analyst_confirmations_needed'])} | unresolved after review {n(h['unresolved_after_review'])}",
         "BENCHMARK: gates open | " + (" | ".join(f"{k.replace('_', ' ')} {n(v)}" for k, v in sorted(res["gates"].items()) if v) or "none"),
         "BENCHMARK: unscored claims | " + " | ".join(f"{k.replace('_', ' ')} {n(v)}" for k, v in sorted(res["unscored"].items())),
         (f"BENCHMARK: regression | previous checks still passing {n(len(res['regression']['still_passing']))} | new failures {n(len(res['regression']['new_failures']))} | "
          f"fixed {n(len(res['regression']['fixed']))} | still failing {n(len(res['regression']['still_failing']))} | method changed {'yes' if res['regression']['method_changed'] else 'no'}")
         if res["regression"]["previous_build"] else "BENCHMARK: regression | no previous result given",
         f"BENCHMARK: result | physical import {R['physical_import']} | material graph {R['material_graph']} | safe to proceed to generation design {R['safe_to_design_generation']}"]
    out = []
    for l in L:                                     # every word must be vocabulary, a number, a period or the key version
        words = []
        for w in l.replace("BENCHMARK:", "BENCHMARK").split():
            core = w.strip("|").strip()
            if not core or core == "|" or core.lower() in VOCAB or core in VOCAB or re.fullmatch(r"\d{1,9}|n|v\d+|R\d+|P\d+|\d+\.\d+\.\d+", core):
                words.append(w)
            else:
                words.append("withheld")
        out.append(" ".join(words).replace("BENCHMARK ", "BENCHMARK: ", 1))
    return out


def report_md(res, key):
    L = [f"# Workbook import benchmark - {key['gold_id']} key {key['key_version']} (PRIVATE: keep in the authorised environment)", "",
         "## Glossary", "", "| Term | Meaning |", "|---|---|",
         "| Gold workbook | The frozen, approved historical workbook the key describes |",
         "| Blind | Answered by the analyst before seeing any discovery output |",
         "| Silent omission | Excel says a formula reads a cell; discovery neither found it nor flagged the formula as unresolved |",
         "| PROVEN but wrong | Discovery claimed PROVEN and the key disagrees: the status rules themselves need fixing |",
         "| Gate | An open item that blocks a claim of complete understanding; never averaged into a score |", "",
         "## Result", ""] + [f"- {k.replace('_', ' ')}: **{v}**" for k, v in res["result"].items() if k != "why_not"] + \
        [f"- why not: {'; '.join(res['result']['why_not']) or '-'}", "", "## Checks", "", "| ID | Family | Status | Detail |", "|---|---|---|---|"]
    for c in res["checks"]:
        extra = ", ".join(f"{k}={v}" for k, v in c.items() if k not in ("id", "family", "status", "detail"))
        L.append(f"| {c['id']} | {c['family']} | {c['status']} | {c['detail']} {extra} |")
    L += ["", "## Gates", ""] + [f"- {k.replace('_', ' ')}: {v}" for k, v in sorted(res["gates"].items())]
    L += ["", "## Regression", ""] + [f"- {k.replace('_', ' ')}: {v}" for k, v in res["regression"].items()]
    L += ["", "## Metadata", "", "```", json.dumps(res["meta"], indent=1, sort_keys=True), "```"]
    return "\n".join(L)


def cmd_score(a):
    key = validate(load(a.key), ANSWER_KEY, "answer key")
    body = {k: v for k, v in key.items() if k != "sha256"}
    if key.get("schema") != SCHEMA or sha256_text(canon(body)) != key.get("sha256"):
        print("STOPPED: the answer key was changed after it was built (or is not a Gold key). Use the frozen key.")
        return 3
    prev = load(a.previous) if a.previous else None
    other = load(a.other_gold) if a.other_gold else None
    res, err = score(a.map, key, prev, other)
    if err:
        print(f"STOPPED: {err}.")
        return 3
    os.makedirs(a.out, exist_ok=True)
    dump(res, os.path.join(a.out, "benchmark_result.json"))
    open(os.path.join(a.out, "benchmark_report.md"), "w", encoding="utf-8").write(report_md(res, key))
    for l in sanitised_lines(res, a.redact_counts):
        print(l)
    print("NEXT: post only the BENCHMARK lines. benchmark_report.md and benchmark_result.json are private (they name cells): keep them, "
          "and pass benchmark_result.json as --previous next time.")
    return 0


def cmd_physical(a):
    x = XC.scan(a.workbook)
    M = load(os.path.join(a.map, "workbook_map.json"))
    T = M["layer0"]["totals"]
    pairs = {"worksheets": (M["layer0"]["worksheets"], len(x["sheets"])), "populated_cells": (T["populated_cells"], x["totals"]["populated"]),
             "formula_cells": (T["formula_cells"], x["totals"]["formulas"]), "errors": (T["errors"], x["totals"]["errors"]),
             "array_result_cells": (T["array_result_cells"], x["totals"]["array_results"]), "tables": (M["layer0"]["tables"], x["tables"]),
             "visible_defined_names": (M["layer0"].get("visible_defined_names"), x["defined_names"])}
    bad = {k: v for k, v in pairs.items() if v[0] != v[1]}
    print("BENCHMARK: physical tripwire | " + " | ".join(f"{k.replace('_', ' ')} {v[0]} of {v[1]} {'PASS' if v[0] == v[1] else 'FAIL'}" for k, v in pairs.items()))
    return 0 if not bad else 1


def main(argv=None):
    ap = argparse.ArgumentParser(prog="bench.py")
    sub = ap.add_subparsers(dest="cmd", required=True)
    h = sub.add_parser("hash"); h.add_argument("--workbook", required=True)
    t = sub.add_parser("template"); t.add_argument("--workbook", required=True); t.add_argument("--gold-id", required=True)
    t.add_argument("--period-end", required=True); t.add_argument("--out", required=True)
    s = sub.add_parser("sample"); s.add_argument("--workbook", required=True); s.add_argument("--template", required=True)
    s.add_argument("--seed", type=int, default=20261008); s.add_argument("--per-stratum", type=int, default=3); s.add_argument("--max", type=int, default=45)
    s.add_argument("--request-out", default="gold_facts_precedents_request.json")
    f = sub.add_parser("freeze-blind"); f.add_argument("--template", required=True); f.add_argument("--by", required=True); f.add_argument("--out", required=True)
    k = sub.add_parser("key"); k.add_argument("--blind", required=True); k.add_argument("--workbook", required=True)
    k.add_argument("--facts", nargs="+", required=True); k.add_argument("--review", default=None); k.add_argument("--map-meta", default=None)
    k.add_argument("--by", required=True); k.add_argument("--version", default="v1"); k.add_argument("--out", required=True)
    p = sub.add_parser("physical"); p.add_argument("--workbook", required=True); p.add_argument("--map", required=True)
    sc = sub.add_parser("score"); sc.add_argument("--map", required=True); sc.add_argument("--key", required=True)
    sc.add_argument("--previous", default=None); sc.add_argument("--other-gold", default=None); sc.add_argument("--out", default="benchmark_out")
    sc.add_argument("--redact-counts", action="store_true")
    a = ap.parse_args(argv)
    try:
        resolve_inputs(a)
        if a.cmd == "hash":
            print(f"BENCHMARK: workbook SHA-256 {sha256_file(a.workbook)}")
            return EXIT_OK
        return {"template": cmd_template, "sample": cmd_sample, "freeze-blind": cmd_freeze, "key": cmd_key, "physical": cmd_physical,
                "score": cmd_score}[a.cmd](a)
    except Stop as e:
        msg = str(e)
        print(msg if msg.startswith("PREFLIGHT:") else f"STOPPED: {msg}")
        return EXIT_STOPPED
    except Exception as e:
        import traceback
        p = os.path.join(os.getcwd(), "bench_error.log")
        try:
            open(p, "w").write(traceback.format_exc())
        except OSError:
            pass
        print(f"BENCHMARK ERROR: internal {type(e).__name__} - a bug, not a data problem; send this line and bench_error.log to the maintainer")
        if os.environ.get("WD_DEBUG"):
            traceback.print_exc()
        return EXIT_INTERNAL


def resolve_inputs(a):
    """every file argument found by name (Stop if missing or ambiguous); every workbook pre-flighted before use."""
    for attr, what in (("workbook", "workbook"), ("template", "answer-key template"), ("blind", "blind answers file"),
                       ("key", "answer key"), ("review", "region review"), ("previous", "previous benchmark result"),
                       ("other_gold", "other Gold result"), ("map_meta", "map summary")):
        v = getattr(a, attr, None)
        if v and not (attr == "template" and a.cmd == "template"):
            setattr(a, attr, find_input(v, what))
    if getattr(a, "facts", None):
        a.facts = [find_input(f, "Excel facts file") for f in a.facts]
    if getattr(a, "workbook", None):
        check_workbook(a.workbook)
    if getattr(a, "map", None) and not os.path.isfile(os.path.join(a.map, "workbook_map.json")):
        alt = os.path.join(out_root("."), a.map)
        if os.path.isfile(os.path.join(alt, "workbook_map.json")):
            a.map = alt
        else:
            raise Stop(f"no discovery map in '{a.map}': run discovery first (it writes workbook_map.json there)", "missing_file")


if __name__ == "__main__":
    sys.exit(main())
