# How the register decides

Read this when a user asks why the register did something.

## Identity and duplicates

- **Duplicate check.** A file is a duplicate only when its SHA-256 (its exact bytes) matches a registered file. A similar filename never makes a duplicate. Duplicates are recorded as `duplicate_received` and are not profiled again.
- **File IDs.** `file_id` is `F-` plus the first 12 characters of the SHA-256, so the same bytes always get the same ID.

## Normalized names

Normalized names are used only for filing checks. The observed filename is always kept.

Upload noise is removed: a trailing `(1)`, `- Copy`, a GUID, or a mixed letter-and-digit hex tag such as the `-9e3ec0ba` that Copilot Studio adds. Dates, versions, and words are kept, because they distinguish real files. The name is then lower-cased, and punctuation becomes spaces.

## Versions and supersession

Only files that are **current** (not superseded), in the **same family**, with the **same period end** are compared. Periods are compared by month, so `2026-06` and `2026-06-30` match. Files with a missing period or a different period are never superseded.

Rules, in order:
1. Final over draft.
2. Higher explicit version (`v2` over `v1`), taken from the profiler's filename analysis. This applies only when both files have one.
3. Later received time. If that time was the check time rather than the real receipt time, an open question asks for confirmation.
4. Otherwise **unresolved**: nothing is superseded, and an open question is recorded.

If either file's status is conflict or unknown, the comparison is unresolved.

## Structure

The new file is compared with the most recent file in the same family, regardless of period. Sheets are matched by normalized pattern (`{Mon} {YYYY}`) or, when there is no pattern, by name.

Structural change means any of the following:
- a pattern or name was added or removed;
- a sheet's type changed (both types must be known);
- a sheet's visibility changed.

Not structural change:
- More or fewer tabs under the same pattern, such as an extra monthly tab. This is recorded as an observation only.
- A sheet whose type is unknown on one side. This is listed as unresolved.

## Filing

- `filed`: the normalized name and the size both match.
- `filed_size_differs`: the normalized name matches but the size does not.
- `possible_match`: no name match, but a file of the same size exists.
- `not_filed`: none of the above.

## Guards

- **Company.** A company source of `filename` is refused. `file_content` requires that the profile found a company name inside the file. A register that belongs to another company is refused.
- **Plans.** A plan edited after it was generated is refused by checksum. A plan made against an older copy of the register is refused by event count. The checksum stops accidental edits; it is not a security control.
