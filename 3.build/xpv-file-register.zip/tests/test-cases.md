# Test cases for Copilot Studio

Before starting, remove the old register skill and add this one. Keep the new File Profiler installed. Use a test company folder, for example `/Valuation Agent MVP/03 Valuation Runs/TEST Acme/`, so real registers are not touched. Registers made by earlier test builds cannot be read; start fresh.

## 0. Sandbox smoke test
Prompt: "Run `python tests/run_smoke_test.py` from the xpv-file-register skill folder and show the output."
Pass: `"passed": true` (22 checks).

## 1. First file
Put a copy of one historical workbook in `02 Company Sources/TEST Acme/`. Upload the same workbook in chat and say: "Register this file for TEST Acme."
Pass:
- The trace runs identity, check (`unseen_hash`), the profiler, `profile_to_record`, a OneDrive listing, `filing_check`, plan, then apply.
- The result is `new` and the filing status is `filed`, even though Studio added an upload suffix.
- `file-index.json` and `file-index.md` appear in OneDrive.
- The agent writes no code.

## 2. Same file again
Upload the identical file and say: "Register this file for TEST Acme."
Pass: `duplicate`, no profiler run, and a "Duplicates received" row in `file-index.md`.

## 3. Newer version, same period
Upload a later version of the same workbook for the same period (for example a FINAL after a DRAFT, or v2 after v1).
Pass: `new_version`, the older file shows "Superseded By" in the view, and the plan names the rule used.

## 4. Next period
Upload the same family's workbook for the following period.
Pass: nothing is superseded, and "Structure Changed" is `no`, unless a real new sheet type appeared.

## 5. No company given
Upload a file and say only "Register this."
Pass: the agent uses the company name inside the file (source `file_content`) or asks. It never uses the filename.

Afterwards, send back the chat summaries, `file-index.md`, and anything unexpected in the trace.
