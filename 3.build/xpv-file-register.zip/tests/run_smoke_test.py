#!/usr/bin/env python3
"""Smoke test for the xpv-file-register package.

Simulates a sequence of incoming files for one company (with stand-in
profiles, so the File Profiler is not needed) and checks every register
decision. Run once in the Copilot Studio sandbox after upload:

    python tests/run_smoke_test.py

Prints a JSON report with "passed": true/false. Always exits 0.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
S = ROOT / "scripts"
COMPANY = "Acme Water"


def run(script, *args):
    p = subprocess.run([sys.executable, str(S / script), *map(str, args)], capture_output=True, text=True)
    try:
        return json.loads(p.stdout)
    except json.JSONDecodeError:
        return {"unparseable_stdout": p.stdout[-2000:], "stderr": p.stderr[-2000:]}


def fake_profile(path: Path, family, status, period_end, sheets, version_tokens=(), company="Acme Water Ltd."):
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    def f(v):
        return {"value": v, "evidence": ["/identity/file_name"] if v else []}
    return {
        "profile_contract_version": "3.1.0", "profile_status": "completed",
        "identity": {"file_name": path.name, "sha256": sha,
                     "filename_analysis": {"version_tokens": list(version_tokens)}},
        "observations": {"sheets": []},
        "interpretation": {
            "file_role": f("valuation_workbook"), "status": f(status), "family": f(family),
            "company_name_in_file": f(company), "period_end": f(period_end), "actuals_through": f(None),
            "entities": [],
            "sheets": [{"observed_name": n, "normalized_name_pattern": p, "type": t, "visibility": v,
                        "sheet_kind": "worksheet", "decided_by": "agent"} for n, p, t, v in sheets]},
        "open_questions": [], "profile_completeness": {"found": 5, "total": 12, "ratio": 0.4167, "missing": []},
        "processing_error": None,
    }


def main():
    checks = []

    def check(name, ok, detail=None):
        checks.append({"check": name, "ok": bool(ok), "detail": None if ok else detail})

    with tempfile.TemporaryDirectory() as d:
        d = Path(d)
        reg = d / "file-index.json"
        md = d / "file-index.md"
        listing = d / "listing.json"
        listing.write_text(json.dumps({"value": [
            {"Name": "Acme Valuation Q2 2026 v1 DRAFT.xlsx", "Size": 8, "Path": "/02 Company Sources/Acme/a.xlsx",
             "IsFolder": False},
            {"Name": "Old Folder", "IsFolder": True}]}))
        base_sheets = [("Valuation Summary", None, "valuation_summary", "visible"),
                       ("Jun 2026", "{Mon} {YYYY}", "income_statement", "visible"),
                       ("Calc", None, "calculation", "hidden")]

        def ingest(name, content, profile_args, company_source="user_stated", received_at=None, use_listing=True):
            src = d / name
            src.write_bytes(content)
            w = d / ("work-" + hashlib.md5(name.encode()).hexdigest()[:6])
            args = ["--input", src, "--output", w / "identity.json"]
            if received_at:
                args += ["--received-at", received_at]
            ident = run("file_identity.py", *args)
            chk = run("register_check.py", "--register", reg, "--identity", w / "identity.json")
            plan_args = ["--register", reg, "--identity", w / "identity.json", "--company", COMPANY,
                         "--company-source", company_source, "--output", w / "plan.json"]
            if chk.get("result") == "unseen_hash":
                (w / "profile.json").write_text(json.dumps(fake_profile(src, *profile_args)))
                rec = run("profile_to_record.py", "--identity", w / "identity.json",
                          "--profile", w / "profile.json", "--output", w / "record.json")
                plan_args += ["--record", w / "record.json", "--profile-path", f"/profiles/{name}.json"]
            if use_listing:
                run("filing_check.py", "--identity", w / "identity.json", "--listing", listing,
                    "--output", w / "filing.json")
                plan_args += ["--filing", w / "filing.json"]
            plan = run("register_plan.py", *plan_args)
            applied = run("register_apply.py", "--register", reg, "--plan", w / "plan.json",
                          "--output-json", reg, "--output-md", md) if plan.get("status") == "completed" else None
            return ident, chk, plan, applied, w

        # 0. Leftover markdown view without the JSON register must block.
        stray = d / "stray"
        stray.mkdir()
        (stray / "x.xlsx").write_bytes(b"stray")
        run("file_identity.py", "--input", stray / "x.xlsx", "--output", stray / "identity.json")
        r = run("register_check.py", "--register", d / "missing.json", "--identity", stray / "identity.json",
                "--view-present")
        check("md without json blocks", r.get("result") == "inconsistent_register", r)
        r = run("register_check.py", "--register", d / "missing.json", "--identity", stray / "identity.json",
                "--view-present", "--confirm-new-register")
        check("confirmed fresh start proceeds", r.get("result") == "unseen_hash", r)

        # 1. First file; Studio-style upload suffix; matches the filed original by normalized name.
        i1, c1, p1, a1, w1 = ingest("Acme Valuation Q2 2026 v1 DRAFT-9e3ec0ba.xlsx", b"file-one",
                                    ("acme valuation", "draft", "2026-06-30", base_sheets, ["v1"]),
                                    received_at="2026-07-05T10:00:00+00:00")
        check("upload suffix stripped from normalized name",
              i1.get("normalized_name") == "acme valuation q2 2026 v1 draft.xlsx", i1)
        check("first file is new", p1.get("result") == "new", p1)
        check("first file applied", a1 and a1.get("status") == "completed", a1)
        check("filed by normalized name + size", p1.get("decisions", {}).get("filing") == "filed", p1)
        first_events = json.dumps(json.loads(reg.read_text())["events"], sort_keys=True)

        # 2. Same bytes again -> duplicate, no profiling.
        _, c2, p2, a2, _ = ingest("Acme Valuation Q2 2026 v1 DRAFT (1).xlsx", b"file-one", None)
        check("duplicate detected before profiling", c2.get("result") == "duplicate", c2)
        check("duplicate recorded", p2.get("result") == "duplicate" and a2 and a2.get("status") == "completed", p2)

        # 3. Same family and period, final v2 -> supersedes the draft.
        _, _, p3, a3, _ = ingest("Acme Valuation Q2 2026 v2 FINAL.xlsx", b"file-two",
                                 ("acme valuation", "final", "2026-06", base_sheets, ["v2"]),
                                 received_at="2026-07-10T10:00:00+00:00")
        sup = (p3.get("decisions", {}).get("supersession_checks") or [{}])[0]
        check("final supersedes draft in same period",
              p3.get("result") == "new_version" and sup.get("decision") == "incoming_supersedes_existing"
              and sup.get("rule") == "final_over_draft", p3)
        check("month-level period match (2026-06 vs 2026-06-30)", p3.get("result") == "new_version", p3)

        # 4. Next period with another monthly tab -> no supersession, no structural change.
        q3 = base_sheets + [("Jul 2026", "{Mon} {YYYY}", "income_statement", "visible")]
        _, _, p4, a4, _ = ingest("Acme Valuation Q3 2026 v1 FINAL.xlsx", b"file-three",
                                 ("acme valuation", "final", "2026-09-30", q3, ["v1"]),
                                 received_at="2026-10-05T10:00:00+00:00")
        check("different period never supersedes", not p4.get("decisions", {}).get("supersession_checks"), p4)
        check("period progression is not structural change",
              p4.get("decisions", {}).get("structure", {}).get("structure_changed") is False, p4)

        # 5. A genuinely new sheet type -> structural change reported.
        q4 = q3 + [("Pro Forma", None, "pro_forma", "visible")]
        _, _, p5, _, _ = ingest("Acme Valuation Q4 2026 FINAL.xlsx", b"file-four",
                                ("acme valuation", "final", "2026-12-31", q4, []),
                                received_at="2027-01-05T10:00:00+00:00")
        check("added sheet is structural change",
              p5.get("decisions", {}).get("structure", {}).get("structure_changed") is True, p5)

        # 6. Same period, unknown status -> unresolved, open question.
        _, _, p6, a6, _ = ingest("Acme Valuation Q4 2026 alt.xlsx", b"file-five",
                                 ("acme valuation", None, "2026-12-31", q4, []))
        sup6 = (p6.get("decisions", {}).get("supersession_checks") or [{}])[0]
        check("unknown status is unresolved, not superseded", sup6.get("decision") == "unresolved", p6)
        check("unresolved becomes an open question", "open_question_added" in p6.get("event_types", []), p6)

        # 7. Guards.
        _, _, p7, _, _ = ingest("Other.xlsx", b"file-six", ("other", "final", "2026-06-30", base_sheets, []),
                                company_source="filename")
        check("filename is rejected as a company source", p7.get("status") == "blocked", p7)

        _, _, p8, _, w8 = ingest("NoName.xlsx", b"file-seven",
                                 ("acme valuation", "final", "2027-03-31", base_sheets, [], None),
                                 company_source="file_content")
        check("file_content source needs a company name in the profile", p8.get("status") == "blocked", p8)

        src = d / "Tamper.xlsx"
        src.write_bytes(b"file-eight")
        w = d / "work-tamper"
        run("file_identity.py", "--input", src, "--output", w / "identity.json")
        (w / "profile.json").write_text(json.dumps(fake_profile(src, "acme valuation", "final", "2027-06-30",
                                                                base_sheets)))
        run("profile_to_record.py", "--identity", w / "identity.json", "--profile", w / "profile.json",
            "--output", w / "record.json")
        run("register_plan.py", "--register", reg, "--identity", w / "identity.json", "--company", COMPANY,
            "--company-source", "user_stated", "--record", w / "record.json", "--output", w / "plan.json")
        plan = json.loads((w / "plan.json").read_text())
        plan["events"][0]["file"]["status"] = "draft"
        (w / "edited.json").write_text(json.dumps(plan))
        r = run("register_apply.py", "--register", reg, "--plan", w / "edited.json",
                "--output-json", reg, "--output-md", md)
        check("hand-edited plan is refused", r.get("status") == "blocked", r)

        other = d / "Second.xlsx"
        other.write_bytes(b"file-nine")
        w9 = d / "work-stale"
        run("file_identity.py", "--input", other, "--output", w9 / "identity.json")
        (w9 / "profile.json").write_text(json.dumps(fake_profile(other, "x", "final", "2027-06-30", base_sheets)))
        run("profile_to_record.py", "--identity", w9 / "identity.json", "--profile", w9 / "profile.json",
            "--output", w9 / "record.json")
        run("register_plan.py", "--register", reg, "--identity", w9 / "identity.json", "--company", COMPANY,
            "--company-source", "user_stated", "--record", w9 / "record.json", "--output", w9 / "plan.json")
        run("register_apply.py", "--register", reg, "--plan", w / "plan.json", "--output-json", reg,
            "--output-md", md)
        r = run("register_apply.py", "--register", reg, "--plan", w9 / "plan.json", "--output-json", reg,
                "--output-md", md)
        check("stale plan is refused", r.get("status") == "blocked", r)

        r = run("register_plan.py", "--register", reg, "--identity", w9 / "identity.json", "--company", "Beta Co",
                "--company-source", "user_stated", "--record", w9 / "record.json", "--output", w9 / "plan2.json")
        check("wrong company register is refused", r.get("status") == "blocked", r)

        mismatch = d / "Mismatch.xlsx"
        mismatch.write_bytes(b"file-ten")
        wm = d / "work-mismatch"
        run("file_identity.py", "--input", mismatch, "--output", wm / "identity.json")
        r = run("profile_to_record.py", "--identity", wm / "identity.json", "--profile", w9 / "profile.json",
                "--output", wm / "record.json")
        check("profile for a different file is refused", r.get("status") == "processing_error", r)

        final = json.loads(reg.read_text())
        ids = [e["event_id"] for e in final["events"]]
        check("event ids are sequential and unique", ids == [f"E{i + 1}" for i in range(len(ids))], ids)
        check("markdown view rendered", md.exists() and "| File ID |" in md.read_text())
        n = len(json.loads(first_events))
        check("earlier events never change", json.dumps(final["events"][:n], sort_keys=True) == first_events)

    passed = all(c["ok"] for c in checks)
    print(json.dumps({"passed": passed, "total": len(checks),
                      "failed": [c for c in checks if not c["ok"]]}, indent=2, default=str))


if __name__ == "__main__":
    main()
