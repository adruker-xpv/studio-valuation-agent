#!/usr/bin/env python3
"""Step 4 - filing check: is this file already in the company source folder?

Usage:
    python scripts/filing_check.py --identity <work>/identity.json \
        --listing <work>/listing.json --folder "/Valuation Agent MVP/02 Company Sources/<Company>/" \
        --output <work>/filing.json

--listing is the OneDrive connector's folder-listing response saved exactly as
returned. Common shapes (a list, {"value": [...]}, {"files": [...]}, {"body": ...})
and field names (Name/name/DisplayName, Size/size, Path/path/webUrl) are
recognized. Names are normalized here, so do not edit the listing. Always exits 0.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from register_lib import emit, load_json, normalized_name, now_iso

NAME_KEYS = ["name", "Name", "DisplayName", "displayName", "fileName", "FileName"]
SIZE_KEYS = ["size", "Size", "fileSize", "FileSize", "Length"]
PATH_KEYS = ["path", "Path", "webUrl", "WebUrl", "url", "Url"]
CONTAINER_KEYS = ["value", "files", "items", "body", "result", "data"]


def first(d, keys):
    return next((d[k] for k in keys if k in d and d[k] not in (None, "")), None)


def find_items(obj, depth=0):
    if depth > 5:
        return None
    if isinstance(obj, list) and obj and all(isinstance(x, dict) for x in obj) \
            and any(first(x, NAME_KEYS) for x in obj):
        return obj
    if isinstance(obj, list) and not obj:
        return []
    if isinstance(obj, dict):
        for k in CONTAINER_KEYS:
            if k in obj:
                found = find_items(obj[k], depth + 1)
                if found is not None:
                    return found
    if isinstance(obj, str):
        try:
            return find_items(json.loads(obj), depth + 1)
        except (ValueError, TypeError):
            return None
    return None


def is_folder(item):
    return bool(item.get("IsFolder") or item.get("isFolder") or "folder" in item)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--identity", required=True)
    ap.add_argument("--listing", required=True)
    ap.add_argument("--folder", default=None)
    ap.add_argument("--output", required=True)
    a = ap.parse_args()
    try:
        ident = load_json(Path(a.identity))
        items = find_items(load_json(Path(a.listing)))
        if items is None:
            raise ValueError("could not find a list of files in the listing; save the connector response unchanged")
        files = []
        for it in items:
            if is_folder(it):
                continue
            name = first(it, NAME_KEYS)
            if not name:
                continue
            size = first(it, SIZE_KEYS)
            try:
                size = int(size) if size is not None else None
            except (TypeError, ValueError):
                size = None
            files.append({"name": name, "normalized_name": normalized_name(name)["normalized_name"],
                          "size": size, "path": first(it, PATH_KEYS)})

        exact = [f for f in files if f["normalized_name"] == ident["normalized_name"]]
        if exact:
            same = [f for f in exact if f["size"] is not None and f["size"] == ident["size"]]
            hit = (same or exact)[0]
            status = "filed" if same else "filed_size_differs"
            candidates = exact
        else:
            candidates = [f for f in files if f["size"] is not None and f["size"] == ident["size"]]
            hit = candidates[0] if candidates else None
            status = "possible_match" if candidates else "not_filed"
        result = {"filing_version": "3.1.0", "file_id": ident.get("file_id"), "filed_status": status,
                  "filed_path": hit["path"] if hit else None, "matched_name": hit["name"] if hit else None,
                  "candidate_count": len(candidates), "candidates": candidates[:10],
                  "folder": a.folder, "listing_file_count": len(files), "checked_at": now_iso()}
        out = Path(a.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
        emit({"status": "completed", "filed_status": status, "matched_name": result["matched_name"],
              "candidate_count": len(candidates), "listing_file_count": len(files), "output": str(out)})
    except Exception as e:
        emit({"status": "processing_error", "error": f"{type(e).__name__}: {e}"})


if __name__ == "__main__":
    main()
