#!/usr/bin/env python3
"""Step 2 - duplicate check: has this exact file (same SHA-256) been registered before?

Usage:
    python scripts/register_check.py --register <work>/file-index.json --identity <work>/identity.json

A missing register is treated as empty (first file for the company).
Result is "duplicate" (do not profile again) or "unseen_hash" (profile it). Always exits 0.
"""
from __future__ import annotations

import argparse
from pathlib import Path

from register_lib import emit, load_json, load_register, state


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--register", required=True)
    ap.add_argument("--identity", required=True)
    a = ap.parse_args()
    try:
        ident = load_json(Path(a.identity))
        if ident.get("status") != "completed" or not ident.get("sha256"):
            emit({"status": "processing_error", "result": None,
                  "error": "identity step did not complete; register a processing_error with register_plan.py"})
            return
        reg_path = Path(a.register)
        reg = load_register(reg_path)
        files = state(reg)["files"]
        match = next((f for f in files.values() if f.get("sha256") == ident["sha256"]), None)
        emit({"status": "completed", "register_exists": reg_path.is_file(), "register_company": reg.get("company"),
              "event_count": len(reg["events"]),
              "result": "duplicate" if match else "unseen_hash",
              "file_id": ident["file_id"], "matching_file_id": match["file_id"] if match else None,
              "next_step": "skip profiling; run filing_check.py then register_plan.py" if match
              else "profile the file with the File Profiler, then run profile_to_record.py"})
    except Exception as e:
        emit({"status": "processing_error", "result": None, "error": f"{type(e).__name__}: {e}"})


if __name__ == "__main__":
    main()
