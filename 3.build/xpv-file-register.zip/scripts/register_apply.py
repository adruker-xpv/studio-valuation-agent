#!/usr/bin/env python3
"""Step 6 - apply: append a plan's events to the register and render the Markdown view.

Usage:
    python scripts/register_apply.py --register <work>/file-index.json --plan <work>/plan.json \
        --output-json <work>/file-index.json --output-md <work>/file-index.md

Refuses a plan that was edited after register_plan.py wrote it (checksum),
a plan made against an older copy of the register (event count), or a
company mismatch. Existing events are never changed or removed. Always exits 0.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from register_lib import (REGISTER_VERSION, SKILL_ROOT, canonical_checksum, emit, load_json, load_register,
                          now_iso, state)
from schema_check import validate


def cell(v):
    if v in (None, "", []):
        return "—"
    return str(v).replace("|", "/").replace("\n", " ")


def render(reg):
    st = state(reg)
    lines = [f"# File Register: {reg.get('company') or ''}", "",
             f"Last updated: {now_iso()} | Events: {len(reg['events'])} | "
             f"Generated from file-index.json (do not edit this view)", "",
             "| File ID | File | Family | Role | Status | Period End | Actuals Through | Superseded By | "
             "Structure Changed | Filed |",
             "|---|---|---|---|---|---|---|---|---|---|"]
    for fid, f in sorted(st["files"].items(), key=lambda x: (x[1].get("received_at") or "", x[0])):
        sd = f.get("structure_diff")
        lines.append("| " + " | ".join(cell(v) for v in [
            fid, f.get("file_name"), f.get("family"), f.get("file_role"), f.get("status"), f.get("period_end"),
            f.get("actuals_through"), f.get("superseded_by"),
            None if sd is None else ("yes" if sd.get("structure_changed") else "no"),
            (f.get("filing") or {}).get("filed_status")]) + " |")
    if st["duplicates"]:
        lines += ["", "## Duplicates received", "", "| Received | File | Matches |", "|---|---|---|"]
        for d in st["duplicates"]:
            inc = d.get("incoming", {})
            lines.append(f"| {cell(inc.get('received_at'))} | {cell(inc.get('file_name'))} | {d.get('file_id')} |")
    changed = [(fid, f["structure_diff"]) for fid, f in st["files"].items()
               if f.get("structure_diff") and (f["structure_diff"].get("structure_changed")
                                               or f["structure_diff"].get("unresolved"))]
    if changed:
        lines += ["", "## Structural observations"]
        for fid, d in changed:
            parts = []
            for k in ("added", "removed"):
                if d.get(k):
                    parts.append(f"{k}: {', '.join(map(str, d[k]))}")
            for k in ("type_changed", "visibility_changed", "unresolved"):
                if d.get(k):
                    parts.append(f"{k}: {len(d[k])}")
            lines.append(f"- {fid}: " + "; ".join(parts))
    if st["questions"]:
        lines += ["", "## Open questions"]
        lines += [f"- {q.get('file_id') or '—'} ({q.get('field')}): {q.get('question')}" for q in st["questions"]]
    if st["errors"]:
        lines += ["", "## Processing errors"]
        lines += [f"- {e.get('file_id') or e.get('file_name')} [{e.get('stage')}]: "
                  f"{(e.get('error') or {}).get('error_message') if isinstance(e.get('error'), dict) else e.get('error')}"
                  for e in st["errors"]]
    return "\n".join(lines) + "\n"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--register", required=True)
    ap.add_argument("--plan", required=True)
    ap.add_argument("--output-json", required=True)
    ap.add_argument("--output-md", required=True)
    a = ap.parse_args()
    try:
        plan = load_json(Path(a.plan))
        body = {k: plan[k] for k in ("plan_version", "company", "file_id", "result", "register_event_count",
                                     "decisions", "events")}
        if canonical_checksum(body) != plan.get("checksum"):
            emit({"status": "blocked", "error": "plan.json was changed after it was generated; "
                                                "rerun register_plan.py instead of editing it"})
            return
        reg = load_register(Path(a.register), plan["company"])
        if reg.get("company") not in (None, plan["company"]):
            emit({"status": "blocked", "error": f"register company {reg['company']!r} does not match plan"})
            return
        if len(reg["events"]) != plan["register_event_count"]:
            emit({"status": "blocked", "error": "the register changed since this plan was made; "
                                                "rerun register_plan.py against the current register"})
            return
        reg["company"] = plan["company"]
        reg["schema_version"] = REGISTER_VERSION
        stamp = now_iso()
        start = len(reg["events"])
        for i, e in enumerate(plan["events"]):
            reg["events"].append({"event_id": f"E{start + i + 1}", "recorded_at": stamp,
                                  "plan_checksum": plan["checksum"][:16], **e})
        schema = load_json(SKILL_ROOT / "schemas" / "register.schema.json")
        errors = validate(reg, schema)
        if errors:
            emit({"status": "processing_error", "error": "register would be invalid; nothing written",
                  "errors": errors[:20]})
            return
        oj, om = Path(a.output_json), Path(a.output_md)
        oj.parent.mkdir(parents=True, exist_ok=True)
        om.parent.mkdir(parents=True, exist_ok=True)
        oj.write_text(json.dumps(reg, indent=2, ensure_ascii=False), encoding="utf-8")
        om.write_text(render(reg), encoding="utf-8")
        emit({"status": "completed", "events_appended": len(plan["events"]), "total_events": len(reg["events"]),
              "file_count": len(state(reg)["files"]), "json_path": str(oj), "markdown_path": str(om)})
    except Exception as e:
        emit({"status": "processing_error", "error": f"{type(e).__name__}: {e}"})


if __name__ == "__main__":
    main()
