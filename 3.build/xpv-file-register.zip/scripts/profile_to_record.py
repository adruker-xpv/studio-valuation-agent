#!/usr/bin/env python3
"""Step 3 - convert a File Profiler profile.json into a register record.

Usage:
    python scripts/profile_to_record.py --identity <work>/identity.json \
        --profile <work>/profile.json --output <work>/record.json

The record is built only from the profile's validated fields; nothing is
retyped by the agent. Refuses a profile that belongs to a different file.
Always exits 0.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from register_lib import PROFILE_CONTRACT, REGISTER_VERSION, emit, load_json, version_tuple


def value(interp, field):
    f = (interp or {}).get(field) or {}
    return f.get("value") if isinstance(f, dict) else None


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--identity", required=True)
    ap.add_argument("--profile", required=True)
    ap.add_argument("--output", required=True)
    a = ap.parse_args()
    try:
        ident = load_json(Path(a.identity))
        prof = load_json(Path(a.profile))
        if prof.get("profile_contract_version") != PROFILE_CONTRACT:
            raise ValueError(f"profile contract {prof.get('profile_contract_version')!r} is not "
                             f"{PROFILE_CONTRACT}; rebuild it with the current File Profiler")
        if prof["identity"].get("sha256") != ident.get("sha256"):
            raise ValueError("profile sha256 does not match this file's identity; it describes a different file")
        interp = prof.get("interpretation")
        fa = prof["identity"].get("filename_analysis") or {}
        record = {
            "record_version": REGISTER_VERSION,
            "file_id": ident["file_id"],
            "profile_status": prof["profile_status"],
            "family": value(interp, "family"),
            "file_role": value(interp, "file_role"),
            "status": value(interp, "status"),
            "period_end": value(interp, "period_end"),
            "actuals_through": value(interp, "actuals_through"),
            "company_name_in_file": value(interp, "company_name_in_file"),
            "entities": [e["value"] for e in (interp or {}).get("entities", [])],
            "content_components": [c["component"] for c in (interp or {}).get("content_components", [])],
            "version": version_tuple(fa.get("version_tokens")),
            "version_tokens": fa.get("version_tokens") or [],
            "sheet_signature": [
                {"observed_name": s["observed_name"], "normalized_name_pattern": s.get("normalized_name_pattern"),
                 "type": s.get("type"), "visibility": s.get("visibility"), "sheet_kind": s.get("sheet_kind"),
                 "type_decided_by": s.get("decided_by")}
                for s in (interp or {}).get("sheets", [])
            ] if interp else [
                {"observed_name": s["observed_name"], "normalized_name_pattern": s.get("normalized_name_pattern"),
                 "type": None, "visibility": s.get("visibility"), "sheet_kind": s.get("sheet_kind"),
                 "type_decided_by": "not_reviewed"}
                for s in prof["observations"].get("sheets", [])
            ],
            "profile_open_question_count": len(prof.get("open_questions", [])),
            "profile_completeness": prof.get("profile_completeness"),
            "profile_error": prof.get("processing_error"),
        }
        out = Path(a.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(record, indent=2, ensure_ascii=False), encoding="utf-8")
        emit({"status": "completed", "file_id": record["file_id"], "profile_status": record["profile_status"],
              "family": record["family"], "status_value": record["status"], "period_end": record["period_end"],
              "version": record["version"], "sheet_count": len(record["sheet_signature"]), "output": str(out)})
    except Exception as e:
        emit({"status": "processing_error", "error": f"{type(e).__name__}: {e}"})


if __name__ == "__main__":
    main()
