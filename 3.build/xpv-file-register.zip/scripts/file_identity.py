#!/usr/bin/env python3
"""Step 1 - identity: hash, size and matching name for one incoming file.

Usage:
    python scripts/file_identity.py --input <file> --output <work>/identity.json \
        [--received-at <ISO timestamp from OneDrive/email metadata>] [--received-from <sender or source>]

If --received-at is not given, the time of this check is used and marked as such,
because precedence between same-period files can depend on it. Always exits 0.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from register_lib import REGISTER_VERSION, emit, file_id_for, normalized_name, now_iso, sha256_file


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--received-at")
    ap.add_argument("--received-from")
    a = ap.parse_args()
    src, dst = Path(a.input), Path(a.output)
    ident = {"identity_version": REGISTER_VERSION, "status": "completed", "file_name": src.name,
             **normalized_name(src.name), "sha256": None, "file_id": None, "size": None,
             "received_at": a.received_at or now_iso(),
             "received_at_source": "provided" if a.received_at else "identity_check_time",
             "received_from": a.received_from, "error": None}
    try:
        ident["sha256"] = sha256_file(src)
        ident["file_id"] = file_id_for(ident["sha256"])
        ident["size"] = src.stat().st_size
    except Exception as e:
        ident["status"] = "processing_error"
        ident["error"] = {"error_type": type(e).__name__, "error_message": str(e)}
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(json.dumps(ident, indent=2, ensure_ascii=False), encoding="utf-8")
    emit({"status": ident["status"], "file_id": ident["file_id"], "normalized_name": ident["normalized_name"],
          "upload_suffix": ident["upload_suffix"], "error": ident["error"], "output": str(dst)})


if __name__ == "__main__":
    main()
