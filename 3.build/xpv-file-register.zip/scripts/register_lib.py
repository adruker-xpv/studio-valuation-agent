"""Shared logic for the XPV File Register scripts.

Everything that decides something lives here so that every script applies
exactly the same rules. The register itself is an append-only event log;
current state is always derived from the events, never stored separately.
"""
from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

REGISTER_VERSION = "3.1.0"
READABLE_REGISTER_VERSIONS = {"3.1.0"}
PROFILE_CONTRACT = "3.2.0"
SKILL_ROOT = Path(__file__).resolve().parent.parent

# Upload suffixes added by Copilot Studio, Teams, SharePoint or copy operations.
# Keep in sync with UPLOAD_SUFFIX_RES in the File Profiler's profile_workbook.py.
UPLOAD_SUFFIX_RES = [
    re.compile(r"\s*\(\d+\)$"),
    re.compile(r"[\s_-]+copy(?:\s*\d+)?$", re.I),
    re.compile(r"[\s_-][0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I),
    re.compile(r"[\s_-](?=[0-9a-f]*\d)(?=[0-9a-f]*[a-f])[0-9a-f]{6,}$", re.I),
]
STATUS_RANK = {"final": 2, "draft": 1}


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def file_id_for(sha: str) -> str:
    """Deterministic ID: the same bytes always get the same file_id."""
    return "F-" + sha[:12]


def strip_upload_suffix(stem: str):
    for rx in UPLOAD_SUFFIX_RES:
        m = rx.search(stem)
        if m:
            return stem[:m.start()], m.group(0).strip()
    return stem, None


def normalized_name(file_name: str) -> dict:
    """Matching key for filing checks. Keeps dates and versions; removes only upload noise."""
    p = Path(file_name)
    stem, suffix = strip_upload_suffix(p.stem)
    ext = p.suffix.lower()
    # A name like "Report.xlsx-9e3ec0ba.pdf" carries its original extension inside the stem.
    inner = re.search(r"\.(xlsx|xlsm|xls|pdf|docx|csv)$", stem, re.I)
    if inner:
        stem = stem[:inner.start()]
    key = re.sub(r"[^a-z0-9]+", " ", stem.lower()).strip()
    return {"normalized_name": f"{key}{ext}", "normalized_stem": key, "upload_suffix": suffix,
            "inner_extension": inner.group(1).lower() if inner else None}


def period_key(value):
    """Compare periods at month level: '2026-09' and '2026-09-30' are the same period end."""
    return value[:7] if isinstance(value, str) and len(value) >= 7 else None


def version_tuple(tokens):
    best = None
    for t in tokens or []:
        m = re.search(r"(\d+(?:\.\d+)*)", t)
        if m:
            v = tuple(int(x) for x in m.group(1).split("."))
            best = v if best is None or v > best else best
    return list(best) if best else None


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_register(path: Path, company=None):
    if not path.is_file():
        return {"schema_version": REGISTER_VERSION, "company": company, "events": []}
    reg = load_json(path)
    if reg.get("schema_version") not in READABLE_REGISTER_VERSIONS:
        raise ValueError(f"unsupported register schema_version {reg.get('schema_version')!r}; registers from earlier test builds must be started fresh")
    return reg


def state(reg):
    """Derive current state from the event log."""
    files, superseded_by, filing, structure, duplicates, questions, errors = {}, {}, {}, {}, [], [], []
    for e in reg.get("events", []):
        t, fid = e.get("event_type"), e.get("file_id")
        if t == "registered":
            files[fid] = dict(e.get("file", {}), file_id=fid, registered_at=e.get("recorded_at"))
        elif t == "profile_attached" and fid in files:
            files[fid]["profile"] = e.get("profile", {})
        elif t == "superseded":
            superseded_by[e.get("superseded_file_id")] = {"by": e.get("superseded_by_file_id"), "rule": e.get("rule")}
        elif t == "structure_compared":
            structure[fid] = e.get("diff", {})
        elif t == "filing_checked":
            filing[fid] = e.get("filing_result", {})
        elif t == "duplicate_received":
            duplicates.append(e)
        elif t == "open_question_added":
            questions.append(dict(e.get("question", {}), file_id=fid, event_id=e.get("event_id")))
        elif t == "processing_error":
            errors.append(e)
    for fid, f in files.items():
        f["superseded_by"] = (superseded_by.get(fid) or {}).get("by")
        f["supersession_rule"] = (superseded_by.get(fid) or {}).get("rule")
        f["filing"] = filing.get(fid)
        f["structure_diff"] = structure.get(fid)
    return {"files": files, "duplicates": duplicates, "questions": questions, "errors": errors}


def latest(items):
    return max(items, key=lambda x: (x.get("received_at") or "", x.get("file_id"))) if items else None


def precedence(new, old):
    """Return (winner, rule) where winner is 'new', 'old' or None (unresolved)."""
    sn, so = new.get("status"), old.get("status")
    if sn not in STATUS_RANK or so not in STATUS_RANK:
        return None, "status_conflict_or_unknown"
    if STATUS_RANK[sn] != STATUS_RANK[so]:
        return ("new" if STATUS_RANK[sn] > STATUS_RANK[so] else "old"), "final_over_draft"
    vn, vo = new.get("version"), old.get("version")
    if vn and vo and vn != vo:
        return ("new" if vn > vo else "old"), "higher_explicit_version"
    rn, ro = new.get("received_at") or "", old.get("received_at") or ""
    if rn and ro and rn != ro:
        return ("new" if rn > ro else "old"), "later_received_at"
    return None, "no_rule_resolved"


def signature_index(signature):
    idx = {}
    for s in signature or []:
        key = s.get("normalized_name_pattern") or s.get("observed_name")
        entry = idx.setdefault(key, {"count": 0, "types": set(), "visibility": set(), "names": []})
        entry["count"] += 1
        if s.get("type"):
            entry["types"].add(s["type"])
        entry["visibility"].add(s.get("visibility"))
        entry["names"].append(s.get("observed_name"))
    return idx


def structure_diff(before, after):
    """Compare sheet signatures by normalized pattern (or name when no pattern)."""
    a, b = signature_index(before), signature_index(after)
    added, removed = sorted(set(b) - set(a)), sorted(set(a) - set(b))
    type_changed, visibility_changed, unresolved, observations = [], [], [], []
    for key in sorted(set(a) & set(b)):
        ta, tb = a[key]["types"], b[key]["types"]
        if ta and tb and ta != tb:
            type_changed.append({"key": key, "before": sorted(ta), "after": sorted(tb)})
        elif bool(ta) != bool(tb):
            unresolved.append({"key": key, "reason": "sheet type unknown on one side"})
        if a[key]["visibility"] != b[key]["visibility"]:
            visibility_changed.append({"key": key, "before": sorted(map(str, a[key]["visibility"])),
                                       "after": sorted(map(str, b[key]["visibility"]))})
        if a[key]["count"] != b[key]["count"]:
            observations.append({"key": key, "note": "sheet count for this pattern changed "
                                 "(period progression is not structural change)",
                                 "before": a[key]["count"], "after": b[key]["count"]})
    changed = bool(added or removed or type_changed or visibility_changed)
    return {"structure_changed": changed, "added": added, "removed": removed, "type_changed": type_changed,
            "visibility_changed": visibility_changed, "unresolved": unresolved, "observations": observations}


def canonical_checksum(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def emit(obj):
    print(json.dumps(obj, indent=2, ensure_ascii=False, default=str))
