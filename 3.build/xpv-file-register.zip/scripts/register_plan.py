#!/usr/bin/env python3
"""Step 5 - plan: decide what happens to this file and write the events.

Usage:
    python scripts/register_plan.py --register <work>/file-index.json \
        --identity <work>/identity.json --company "<Company>" --company-source user_stated \
        [--record <work>/record.json] [--filing <work>/filing.json] \
        [--profile-path "<OneDrive path where profile.json was saved>"] \
        --output <work>/plan.json

--company-source is how the company was identified: user_stated, file_content,
or register_match. A filename is never an accepted source.

Makes every decision in code: duplicate, new or new_version; supersession
(final over draft, then higher explicit version, then later received time;
anything else is unresolved); structure comparison against the latest
current file in the same family; and filing. Writes the events that
register_apply.py will append. Never edit plan.json. Always exits 0.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from register_lib import (REGISTER_VERSION, canonical_checksum, emit, latest, load_json, load_register,
                          now_iso, period_key, precedence, state, structure_diff)

COMPANY_SOURCES = ["user_stated", "file_content", "register_match"]


class PlanError(Exception):
    pass


def question(fid, field, text):
    return {"event_type": "open_question_added", "file_id": fid,
            "question": {"field": field, "question": text, "source": "register"}}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--register", required=True)
    ap.add_argument("--identity", required=True)
    ap.add_argument("--company", required=True)
    ap.add_argument("--company-source", required=True)
    ap.add_argument("--record")
    ap.add_argument("--filing")
    ap.add_argument("--profile-path")
    ap.add_argument("--output", required=True)
    a = ap.parse_args()
    try:
        if a.company_source not in COMPANY_SOURCES:
            raise PlanError(f"--company-source must be one of {COMPANY_SOURCES}; a filename is not an accepted source")
        reg = load_register(Path(a.register), a.company)
        if reg.get("company") and reg["company"] != a.company:
            raise PlanError(f"this register belongs to {reg['company']!r}, not {a.company!r}; "
                            "stop and confirm the company")
        ident = load_json(Path(a.identity))
        record = load_json(Path(a.record)) if a.record else None
        filing = load_json(Path(a.filing)) if a.filing else None
        st = state(reg)
        files = st["files"]
        events, decisions = [], {}

        if ident.get("status") != "completed":
            result, fid = "processing_error", None
            events.append({"event_type": "processing_error", "file_id": None,
                           "file_name": ident.get("file_name"), "stage": "identity", "error": ident.get("error")})
        else:
            fid = ident["file_id"]
            dup = next((f for f in files.values() if f.get("sha256") == ident["sha256"]), None)
            if dup:
                result = "duplicate"
                fid = dup["file_id"]
                events.append({"event_type": "duplicate_received", "file_id": fid,
                               "incoming": {k: ident.get(k) for k in
                                            ("file_name", "normalized_name", "received_at",
                                             "received_at_source", "received_from")}})
            else:
                if record is None:
                    raise PlanError("unseen file: --record is required (profile the file, then run profile_to_record.py)")
                if record.get("file_id") != fid:
                    raise PlanError("record.json belongs to a different file")
                if a.company_source == "file_content" and not record.get("company_name_in_file"):
                    raise PlanError("--company-source file_content needs a company name in the profile; "
                                    "the profile has none, so ask the user")
                new = {"file_name": ident["file_name"], "normalized_name": ident["normalized_name"],
                       "sha256": ident["sha256"], "size": ident["size"], "received_at": ident["received_at"],
                       "received_at_source": ident["received_at_source"], "received_from": ident.get("received_from"),
                       **{k: record.get(k) for k in ("profile_status", "family", "file_role", "status", "period_end",
                                                    "actuals_through", "company_name_in_file", "entities",
                                                    "version", "version_tokens", "sheet_signature")}}
                events.append({"event_type": "registered", "file_id": fid, "file": new,
                               "company": a.company, "company_source": a.company_source})
                events.append({"event_type": "profile_attached", "file_id": fid,
                               "profile": {"path": a.profile_path, "status": record.get("profile_status"),
                                           "open_question_count": record.get("profile_open_question_count"),
                                           "completeness": record.get("profile_completeness")}})
                if record.get("profile_status") != "completed":
                    result = "new"
                    events.append({"event_type": "processing_error", "file_id": fid, "stage": "profile",
                                   "error": record.get("profile_error")})
                    events.append(question(fid, "profile", "The workbook could not be profiled. "
                                           "Check the file and resubmit a readable copy."))
                else:
                    result = "new"
                    current = [f for f in files.values() if not f.get("superseded_by")]
                    family = new["family"]
                    if not family:
                        events.append(question(fid, "family", "File family is unknown, so version and structure "
                                               "comparisons were skipped. Which family does this file belong to?"))
                    else:
                        same_family = [f for f in current if f.get("family") == family]
                        pk = period_key(new["period_end"])
                        same_period = [f for f in same_family if pk and period_key(f.get("period_end")) == pk]
                        if not pk:
                            decisions["supersession"] = {"decision": "none", "rule": "period_end_unresolved"}
                        for old in same_period:
                            result = "new_version"
                            winner, rule = precedence(new, old)
                            d = {"compared_with": old["file_id"], "rule": rule}
                            if winner == "new":
                                d["decision"] = "incoming_supersedes_existing"
                                events.append({"event_type": "superseded", "file_id": old["file_id"],
                                               "superseded_file_id": old["file_id"], "superseded_by_file_id": fid,
                                               "rule": rule})
                            elif winner == "old":
                                d["decision"] = "existing_supersedes_incoming"
                                events.append({"event_type": "superseded", "file_id": fid, "superseded_file_id": fid,
                                               "superseded_by_file_id": old["file_id"], "rule": rule})
                            else:
                                d["decision"] = "unresolved"
                                events.append(question(fid, "supersession",
                                                       f"{ident['file_name']} and {old['file_name']} cover the same "
                                                       f"period ({pk}) but precedence could not be decided ({rule}). "
                                                       "Which one is authoritative?"))
                            decisions.setdefault("supersession_checks", []).append(d)
                        by_time = any(d["rule"] == "later_received_at" for d in decisions.get("supersession_checks", []))
                        if by_time:
                            if new["received_at_source"] != "provided":
                                events.append(question(fid, "received_at", "Precedence was decided by received time, "
                                                       "but the time was the check time, not the real receipt time. "
                                                       "Please confirm which file is newer."))
                        ref = latest([f for f in same_family if f.get("sheet_signature")])
                        if ref:
                            diff = structure_diff(ref["sheet_signature"], new["sheet_signature"])
                            events.append({"event_type": "structure_compared", "file_id": fid,
                                           "reference_file_id": ref["file_id"], "diff": diff})
                            decisions["structure"] = {"reference_file_id": ref["file_id"],
                                                      "structure_changed": diff["structure_changed"]}
                        else:
                            decisions["structure"] = {"reference_file_id": None, "structure_changed": None,
                                                      "note": "first file in this family"}

            if filing:
                if filing.get("file_id") != ident["file_id"]:
                    raise PlanError("filing.json belongs to a different file")
                events.append({"event_type": "filing_checked", "file_id": fid,
                               "filing_result": {k: filing.get(k) for k in
                                                 ("filed_status", "filed_path", "matched_name", "candidate_count",
                                                  "folder", "checked_at")}})
                decisions["filing"] = filing.get("filed_status")
            else:
                decisions["filing"] = "not_checked"

        body = {"plan_version": REGISTER_VERSION, "company": a.company, "file_id": fid, "result": result,
                "register_event_count": len(reg["events"]), "decisions": decisions, "events": events}
        plan = {**body, "generated_at": now_iso(), "checksum": canonical_checksum(body)}
        out = Path(a.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(plan, indent=2, ensure_ascii=False), encoding="utf-8")
        emit({"status": "completed", "result": result, "file_id": fid, "decisions": decisions,
              "event_types": [e["event_type"] for e in events], "output": str(out)})
    except PlanError as e:
        emit({"status": "blocked", "error": str(e)})
    except Exception as e:
        emit({"status": "processing_error", "error": f"{type(e).__name__}: {e}"})


if __name__ == "__main__":
    main()
