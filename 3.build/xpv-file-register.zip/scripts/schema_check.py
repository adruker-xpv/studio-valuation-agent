#!/usr/bin/env python3
"""Dependency-free validator for the JSON Schema subset used by this skill.

Supported keywords: $ref (local "#/..."), anyOf, type, const, enum, pattern,
minLength, minimum, maximum, minItems, maxItems, items, required, properties,
additionalProperties. Anything else in a schema is ignored.

Usage (standalone):
    python scripts/schema_check.py --input <file.json> --schema schemas/<name>.schema.json
Always exits 0; read "valid".
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

TYPE_CHECKS = {
    "object": lambda x: isinstance(x, dict),
    "array": lambda x: isinstance(x, list),
    "string": lambda x: isinstance(x, str),
    "integer": lambda x: isinstance(x, int) and not isinstance(x, bool),
    "number": lambda x: isinstance(x, (int, float)) and not isinstance(x, bool),
    "boolean": lambda x: isinstance(x, bool),
    "null": lambda x: x is None,
}


def _resolve_ref(root, ref):
    if not ref.startswith("#/"):
        raise ValueError(f"only local $ref supported: {ref}")
    node = root
    for part in ref[2:].split("/"):
        node = node[part.replace("~1", "/").replace("~0", "~")]
    return node


def _check(x, s, root, path, errs):
    if "$ref" in s:
        _check(x, _resolve_ref(root, s["$ref"]), root, path, errs)
        return
    if "anyOf" in s:
        if not any(not validate(x, sub, root) for sub in s["anyOf"]):
            errs.append({"path": path or "/", "message": "does not match any allowed shape"})
        return
    t = s.get("type")
    if t is not None:
        types = t if isinstance(t, list) else [t]
        if not any(TYPE_CHECKS[k](x) for k in types):
            errs.append({"path": path or "/", "message": f"expected {' or '.join(types)}, got {type(x).__name__}"})
            return
    if "const" in s and x != s["const"]:
        errs.append({"path": path or "/", "message": f"must equal {s['const']!r}"})
    if "enum" in s and x not in s["enum"]:
        errs.append({"path": path or "/", "message": f"{x!r} is not one of {s['enum']}"})
    if isinstance(x, str):
        if "minLength" in s and len(x) < s["minLength"]:
            errs.append({"path": path or "/", "message": f"shorter than {s['minLength']} characters"})
        if "pattern" in s and not re.search(s["pattern"], x):
            errs.append({"path": path or "/", "message": f"{x!r} does not match pattern {s['pattern']}"})
    if TYPE_CHECKS["number"](x):
        if "minimum" in s and x < s["minimum"]:
            errs.append({"path": path or "/", "message": f"less than {s['minimum']}"})
        if "maximum" in s and x > s["maximum"]:
            errs.append({"path": path or "/", "message": f"greater than {s['maximum']}"})
    if isinstance(x, list):
        if "minItems" in s and len(x) < s["minItems"]:
            errs.append({"path": path or "/", "message": f"needs at least {s['minItems']} item(s)"})
        if "maxItems" in s and len(x) > s["maxItems"]:
            errs.append({"path": path or "/", "message": f"allows at most {s['maxItems']} item(s)"})
        if "items" in s:
            for i, item in enumerate(x):
                _check(item, s["items"], root, f"{path}/{i}", errs)
    if isinstance(x, dict):
        for key in s.get("required", []):
            if key not in x:
                errs.append({"path": path or "/", "message": f"missing required field '{key}'"})
        props = s.get("properties", {})
        extra = s.get("additionalProperties", True)
        for key, val in x.items():
            if key in props:
                _check(val, props[key], root, f"{path}/{key}", errs)
            elif extra is False:
                errs.append({"path": f"{path}/{key}", "message": "field is not allowed"})
            elif isinstance(extra, dict):
                _check(val, extra, root, f"{path}/{key}", errs)


def validate(instance, schema, root=None):
    """Return a list of {path, message} errors; empty means valid."""
    errs: list[dict] = []
    _check(instance, schema, root if root is not None else schema, "", errs)
    return errs


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", required=True)
    ap.add_argument("--schema", required=True)
    a = ap.parse_args()
    try:
        errs = validate(json.loads(Path(a.input).read_text(encoding="utf-8")),
                        json.loads(Path(a.schema).read_text(encoding="utf-8")))
        print(json.dumps({"valid": not errs, "error_count": len(errs), "errors": errs[:100]}, indent=2))
    except Exception as e:
        print(json.dumps({"valid": False, "error_count": 1,
                          "errors": [{"path": "/", "message": f"{type(e).__name__}: {e}"}]}, indent=2))


if __name__ == "__main__":
    main()
