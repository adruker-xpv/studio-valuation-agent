---
name: xpv-file-register
description: >-
  Register incoming valuation evidence files for a portfolio company: check whether the exact file
  was seen before, record new files and versions, decide which same-period file supersedes another,
  compare sheet structure with earlier files in the same family, and check whether the file is
  filed in the company source folder. Use for every file received as valuation evidence and for
  filing rechecks. Do not use to inspect workbook contents (use the File Profiler), assess schema
  compatibility, interpret methodology, or calculate valuations.
---
# XPV File Register

Keep an append-only history of every evidence file per company. The register is `file-index.json`: a log of events that is never edited, only appended to. `file-index.md` is a view generated from it. Every decision (duplicate, version, supersession, structure, filing) is made by the bundled scripts. You supply the company, move files through the OneDrive tool, and run the steps in order.

Paths are relative to this skill's folder. Use one working folder per incoming file, shown here as `<work>`.

**OneDrive locations**
- Register: `/Valuation Agent MVP/03 Valuation Runs/{Company}/file-index.json` and `file-index.md`
- Company sources: `/Valuation Agent MVP/02 Company Sources/{Company}/`
- Profiles: `/Valuation Agent MVP/03 Valuation Runs/{Company}/profiles/{file_id}.json`

## Steps

1. **Company.** Establish the company in this order: the user stated it; the company name inside the file (from its profile); an unambiguous existing register. Never use the filename. If none applies, ask the user and stop. Record which source you used: `user_stated`, `file_content`, or `register_match`.

2. **Fetch the register.** Download the company's `file-index.json` to `<work>/file-index.json`. If it does not exist, continue; the scripts start a new one.

3. **Identity.**
   `python scripts/file_identity.py --input <file> --output <work>/identity.json [--received-at <ISO time from OneDrive or email metadata>]`
   Pass `--received-at` whenever the source provides it. Precedence can depend on it.

4. **Duplicate check.**
   `python scripts/register_check.py --register <work>/file-index.json --identity <work>/identity.json`
   - `duplicate`: do not profile; go to step 6.
   - `unseen_hash`: continue.

5. **Profile and convert.** Profile the file with the File Profiler skill and save its `profile.json` to the profiles folder named after `file_id`. Then run:
   `python scripts/profile_to_record.py --identity <work>/identity.json --profile <work>/profile.json --output <work>/record.json`

6. **Filing check.** List the company source folder with the OneDrive tool and save the response unchanged as `<work>/listing.json`. Then run:
   `python scripts/filing_check.py --identity <work>/identity.json --listing <work>/listing.json --folder "<source folder>" --output <work>/filing.json`

7. **Plan.**
   `python scripts/register_plan.py --register <work>/file-index.json --identity <work>/identity.json --company "<Company>" --company-source <source> --record <work>/record.json --filing <work>/filing.json --profile-path "<saved profile path>" --output <work>/plan.json`
   Omit `--record` and `--profile-path` for duplicates.
   - If the status is `blocked`, the message says why (wrong company, missing record, filename used as source). Report it and stop.

8. **Apply.**
   `python scripts/register_apply.py --register <work>/file-index.json --plan <work>/plan.json --output-json <work>/file-index.json --output-md <work>/file-index.md`
   Upload both files back to the register folder.
   - If apply reports that the register changed since the plan, download the register again and repeat steps 7–8. Do this once; if it happens again, stop and report it.

9. **Report** in chat: the result, the supersession decision, whether the structure changed, the filing status, and any open questions from the plan. Do not paste the register JSON.

For several files, finish steps 3–8 for one file before starting the next, so each plan is made against the current register.

## Rules

- Use only the bundled scripts. Do not write, modify, or debug code during a run. A script error is a result to report and stop on, not something to work around.
- Never edit `file-index.json`, `plan.json`, `listing.json`, or any script output by hand. `register_apply.py` refuses a hand-edited plan.
- Never delete or rewrite register history, and never upload, move, rename, or delete source files.
- Do not inspect workbook contents, determine schema compatibility, interpret methodology, create schemas, calculate confidence, or calculate valuations.

`references/decision-rules.md` explains how each decision is made, for when a user asks why.
