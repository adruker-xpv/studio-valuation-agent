# build_profile.py - builds the company mapping profile from the agent's concepts file + evidence
# Usage:
#   python build_profile.py <input_map.json> <matches.json> <concepts.json> --out-dir /app/created
#   add  --approve "concept_a,concept_b" --approver "Name"  ONLY when that person approved in chat
# Lineage, units, sign and period evidence come from matches.json, never from the agent.
# Every concept starts as 'proposed'. Prints PROFILE STATUS first:
#   INVALID (exit 1) | DRAFT (exit 3) | READY_FOR_REPLAY (exit 0; still needs the replay test)
import sys, json, argparse, datetime, os, hashlib
from collections import Counter

WRITE = {"replace_period_value", "roll_window", "carry_forward", "carry_forward_event_driven",
         "manual_input", "manual_review"}
PERIOD = {"month", "quarter_sum_of_months", "quarter_end_balance", "ltm_sum", "ytd",
          "point_in_time", "not_periodic", "uncertain"}
C_FIELDS = {"concept_id", "name", "entity", "targets", "write_mode", "period_rule", "source_filename_pattern",
            "reconciliation_rule", "missing_source_behavior", "notes", "questions"}
MISSING = {"block_and_flag", "carry_forward_and_flag", "manual_input"}
AUTOMATED = {"replace_period_value", "roll_window"}
EVIDENCE_RANK = ["consistent_tie", "partial_or_mixed_tie", "ambiguous", "no_tie", "not_testable"]


def main(a):
    imap = json.load(open(a.input_map, encoding="utf-8"))
    matches = {b["id"]: b for b in json.load(open(a.matches, encoding="utf-8"))["blocks"]}
    concepts = json.load(open(a.concepts, encoding="utf-8")).get("concepts", [])
    entries = {e["id"]: e for e in imap["inputs"]}
    need = {i for i, e in entries.items()
            if (e.get("material") and e.get("type") != "not_material") or e.get("reporting_required") == "yes"}
    template_fp = imap.get("template_fingerprint", "")
    prev = {}
    prev_path = os.path.join(a.out_dir, "mapping_profile.json")
    if os.path.exists(prev_path):
        prev = {c["concept_id"]: (c.get("approval"), c.get("approval_basis_hash"))
                for c in json.load(open(prev_path))["concepts"]}

    errs, owner = [], {}
    for i, c in enumerate(concepts):
        cid = c.get("concept_id")
        if not cid:
            errs.append(f"concept {i}: missing concept_id"); continue
        if set(c) - C_FIELDS:
            errs.append(f"{cid}: unknown fields {sorted(set(c) - C_FIELDS)} (evidence fields are filled by the script)")
        if c.get("write_mode") not in WRITE:
            errs.append(f"{cid}: write_mode must be one of {sorted(WRITE)}")
        if c.get("period_rule") not in PERIOD:
            errs.append(f"{cid}: period_rule must be one of {sorted(PERIOD)}")
        if c.get("missing_source_behavior") not in MISSING:
            errs.append(f"{cid}: missing_source_behavior must be one of {sorted(MISSING)}")
        if c.get("write_mode") in AUTOMATED:
            for f in ("entity", "source_filename_pattern", "reconciliation_rule"):
                if not c.get(f):
                    errs.append(f"{cid}: automated write_mode needs {f}")
        if not c.get("targets"):
            errs.append(f"{cid}: needs at least one target")
        for t in c.get("targets", []):
            if t not in entries:
                errs.append(f"{cid}: target {t} is not an id in the input map")
            elif t in owner:
                errs.append(f"{cid}: target {t} already belongs to {owner[t]}")
            else:
                owner[t] = cid
    for t in sorted(need - set(owner)):
        errs.append(f"{t}: material input not assigned to any concept")
    ids = [c.get("concept_id") for c in concepts]
    for d in {x for x in ids if ids.count(x) > 1}:
        errs.append(f"{d}: duplicate concept_id")
    if errs:
        print("PROFILE STATUS: INVALID")
        print("\n".join(f"- {x}" for x in errs[:100]))
        print("NEXT REQUIRED STEP: fix concepts.json for the problems above and re-run (max 3 attempts).")
        return 1

    approve = {x.strip() for x in (a.approve or "").split(",") if x.strip()}
    if approve and not a.approver:
        print("PROFILE STATUS: INVALID\n- --approve needs --approver (the person who approved)")
        return 1
    today = datetime.date.today().isoformat()
    out, resets = [], []
    for c in concepts:
        blocks = [matches.get(t) for t in c["targets"]]
        stats = [b["status"] if b else "not_testable" for b in blocks]
        worst = max(stats, key=EVIDENCE_RANK.index)
        srcs = Counter()
        for b in blocks:
            if b and b["dominant_source"]:
                d = b["dominant_source"]
                srcs[(d["label"], d["file"], d["transform"], d["scale"], d["sign"])] += d["cells"]
        lineage = [{"source_label": l, "source_file": f, "transform": tr, "unit_scale": sc,
                    "sign": "flip" if sg == -1 else "preserve", "cells_tied": n}
                   for (l, f, tr, sc, sg), n in srcs.most_common()]
        examples = []
        for b in blocks:
            for cell in (b or {}).get("cells", []):
                if cell.get("result") == "tie" and len(examples) < 3:
                    s = cell["candidates"][0]
                    examples.append(f"{cell['cell']} = {s['file']} / {s['sheet']}!{s['cell']} ({s['label']}, {s['period']})")
        basis = json.dumps({"targets": sorted(c["targets"]),
                            **{k: c.get(k) for k in ("entity", "write_mode", "period_rule", "source_filename_pattern",
                                                     "reconciliation_rule", "missing_source_behavior")},
                            "lineage": lineage, "template": template_fp}, sort_keys=True, default=str)
        bhash = hashlib.sha256(basis.encode("utf-8")).hexdigest()[:16]
        fresh = {"status": "proposed", "approved_by": None, "date": None}
        old_appr, old_hash = prev.get(c["concept_id"], (None, None))
        if old_appr and old_appr.get("status") == "approved" and old_hash != bhash:
            appr = dict(fresh, note=f"approval reset: basis changed since {old_appr.get('approved_by')} "
                                    f"approved on {old_appr.get('date')}")
            resets.append(c["concept_id"])
        else:
            appr = old_appr or fresh
        if c["concept_id"] in approve:
            appr = {"status": "approved", "approved_by": a.approver, "date": today}
        out.append({**{k: c.get(k) for k in ("concept_id", "name", "entity", "targets", "write_mode", "period_rule",
                                             "source_filename_pattern", "reconciliation_rule",
                                             "missing_source_behavior", "notes", "questions")},
                    "evidence_status": worst,
                    "source_lineage": lineage,
                    "source_label_candidates": sorted({x["source_label"] for x in lineage}),
                    "tie_examples": examples,
                    "formula_preservation": "write hardcoded input cells only; never overwrite formulas",
                    "approval_basis_hash": bhash,
                    "approval": appr})
    unknown = approve - {c["concept_id"] for c in out}
    n_appr = sum(1 for c in out if c["approval"]["status"] == "approved")
    weak = [c["concept_id"] for c in out if c["evidence_status"] in ("ambiguous", "no_tie")
            and c["write_mode"] not in ("manual_input", "manual_review", "carry_forward", "carry_forward_event_driven")]
    review = [c["concept_id"] for c in out if c["write_mode"] == "manual_review" or c["period_rule"] == "uncertain"]
    ready = n_appr == len(out) and not weak and not review
    status = "READY_FOR_REPLAY" if ready else "DRAFT"

    os.makedirs(a.out_dir, exist_ok=True)
    json.dump({"workbook": imap.get("workbook"), "generated": today, "status": status,
               "template_fingerprint": template_fp,
               "key_outputs": imap.get("key_outputs", []), "concepts": out},
              open(prev_path, "w", encoding="utf-8"), indent=1)
    md = [f"# Mapping profile review: {imap.get('workbook')}", f"Status: **{status}** | concepts: {len(out)} | approved: {n_appr}", "",
          "| Concept | Entity | Targets | Evidence | Source (top) | Write | Period | If source missing | Reconciliation | Approval |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    order = sorted(out, key=lambda c: (c["approval"]["status"] == "approved", -EVIDENCE_RANK.index(c["evidence_status"])))
    for c in order:
        top = c["source_lineage"][0] if c["source_lineage"] else None
        src = f"{top['source_label']} ({top['transform']}, x{top['unit_scale']}{', sign flip' if top['sign'] == 'flip' else ''})" if top else "-"
        md.append(f"| {c['name']} | {c.get('entity') or '-'} | {len(c['targets'])} blocks | {c['evidence_status']} | {src} | "
                  f"{c['write_mode']} | {c['period_rule']} | {c.get('missing_source_behavior')} | "
                  f"{(c.get('reconciliation_rule') or '-').replace('|', '/')} | {c['approval']['status']} |")
    md += ["", "## Questions for the analyst"]
    md += [f"- **{c['name']}**: {q}" for c in out for q in (c.get("questions") or [])] or ["(none)"]
    open(os.path.join(a.out_dir, "mapping_profile_review.md"), "w", encoding="utf-8").write("\n".join(md))

    print(f"PROFILE STATUS: {status}")
    print(f"concepts: {len(out)} | approved: {n_appr} | evidence: " +
          ", ".join(f"{k}={v}" for k, v in Counter(c['evidence_status'] for c in out).items()))
    print(f"gate {'PASS' if n_appr == len(out) else 'FAIL'}: every concept approved by a named person")
    print(f"gate {'PASS' if not weak else 'FAIL'}: automated concepts have value-tie evidence" + (f" (weak: {', '.join(weak)})" if weak else ""))
    print(f"gate {'PASS' if not review else 'FAIL'}: no manual_review or uncertain period rules" + (f" ({', '.join(review)})" if review else ""))
    if unknown:
        print(f"warning: --approve named unknown concepts: {', '.join(sorted(unknown))}")
    if resets:
        print(f"approvals reset because their basis changed: {', '.join(resets)}")
    print("note: READY_FOR_REPLAY is not certification; the replay test must reproduce the key outputs.")
    print(f"FILES WRITTEN:\n{prev_path}\n{os.path.join(a.out_dir, 'mapping_profile_review.md')}")
    print("NEXT REQUIRED STEP: save the profile files, then give the final summary. Do not approve anything "
          "unless the user's latest message approves named concepts and names the approver.")
    return 0 if ready else 3


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("input_map"); ap.add_argument("matches"); ap.add_argument("concepts")
    ap.add_argument("--out-dir", default="/app/created")
    ap.add_argument("--approve", default=""); ap.add_argument("--approver", default="")
    try:
        sys.exit(main(ap.parse_args()))
    except SystemExit:
        raise
    except Exception as e:
        print(f"PROFILE_ERROR: {type(e).__name__}: {e}")
        sys.exit(1)
