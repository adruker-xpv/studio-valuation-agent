# concepts.json format

```json
{"concepts": [
  {"concept_id": "is.revenue",
   "name": "Revenue",
   "entity": "Opus Water (consolidated)",
   "targets": ["Quarterly!B2:E2"],
   "write_mode": "roll_window",
   "period_rule": "quarter_sum_of_months",
   "source_filename_pattern": "<Company> monthly financials <YYYY-MM>.xlsx",
   "reconciliation_rule": "sum of the three new months equals the source's reported quarter total, if one exists",
   "missing_source_behavior": "block_and_flag",
   "notes": "feeds Valuation!B5 via Quarterly!B5 -> Valuation!B1",
   "questions": ["Is the newest quarter always the right-most column?"]}
]}
```
Only these eleven fields. The script adds evidence, lineage and approval fields itself.
`entity`, `source_filename_pattern` and `reconciliation_rule` are required for automated write modes
(replace_period_value, roll_window). Base the filename pattern on the matched source file names in
matches.json, replacing dates with placeholders; never invent a file.
`concept_id`: lowercase `area.name` (is., bs., cf., cap., asm., comp., adj., fx.).
`targets`: ids exactly as in the input map.

## write_mode
- `replace_period_value` overwrite the current-period cell(s) with the new value
- `roll_window` shift periods left and write the newest period (quarterly/monthly rows, LTM windows)
- `carry_forward` keep last quarter's value unless the analyst changes it
- `carry_forward_event_driven` keep unless a capital or instrument event is evidenced (cap table,
  share counts, options, instrument terms); requires evidence of no change each quarter
- `manual_input` the analyst enters it each quarter (judgement assumptions, add-backs)
- `manual_review` rule not yet known; blocks READY_FOR_REPLAY

## missing_source_behavior (required)
- `block_and_flag` stop the refresh for this concept and report it (default for financial data)
- `carry_forward_and_flag` keep last quarter's value and report it (event-driven data, e.g. cap table)
- `manual_input` ask the analyst for the value

## Comparable sets
Make each comparable set ONE concept (e.g. `comp.transactions`) targeting all its rows, with
write_mode `carry_forward_event_driven` and a question about how deals are added or removed.
Existing rows are preserved as history.

## period_rule
`month`, `quarter_sum_of_months`, `quarter_end_balance`, `ltm_sum`, `ytd`, `point_in_time`,
`not_periodic`, `uncertain` (blocks READY_FOR_REPLAY).

## Evidence fields added by the script (read-only)
`evidence_status` (worst across the concept's blocks), `source_lineage` (label, file, transform,
unit_scale, sign, cells tied), `source_label_candidates`, `tie_examples`, `formula_preservation`,
`approval` (status, approved_by, date).

## Profile gates
READY_FOR_REPLAY requires: every concept approved by a named person; every automated concept
(replace_period_value, roll_window) has consistent or partial tie evidence; no manual_review or
uncertain period rules.
