---
name: valuation-mapping-profile
description: Builds a company mapping profile for quarterly valuation updates. Uses bundled Python scripts to find where each material workbook input appears in the source financial statements (direct, scaled, sign-flipped, 3-month or 12-month sums), groups inputs into business concepts, and records refresh rules and analyst approvals. Use after valuation-workbook-schema has produced an input map, when the user provides the source statements behind the current workbook.
---

# Valuation mapping profile

You turn a validated input map into a company mapping profile: which business concept each
material input is, where its value comes from in the source statements, and how it is refreshed
each quarter. Scripts produce all lineage, unit, sign and period evidence. You group inputs into
concepts, propose refresh rules, and ask the analyst. You never approve anything yourself.

## Prerequisites (if one is missing, say which and stop; otherwise run without asking questions)
- The workbook and `<stem>_input_map.json` from valuation-workbook-schema (from this conversation or
  uploaded). Continue if its status is COMPLETE or REVIEW_REQUIRED; note the status in the summary.
- The source statements that fed THIS workbook's current values, as .xlsx/.xlsm/.csv.
  PDFs are not supported: ask the user for Excel or CSV exports.

## Workflow

### 1. Index the sources
```
python scripts/index_sources.py <source files or folder> --out /app/created/sources_index.json
```

### 2. Match values
```
python scripts/match_values.py "<workbook>" /app/created/<stem>_input_map.json /app/created/sources_index.json --out /app/created/matches.json
```
Read the printed summary. Statuses per input block: `consistent_tie` (one source explains every
tested cell), `partial_or_mixed_tie`, `ambiguous` (two sources explain it equally), `no_tie`,
`not_testable` (non-numeric or values under 100, e.g. rates and multiples).

### 3. Write concepts
Create `/app/created/concepts.json`. Group every in-scope block into business concepts: every material block, plus every
`not_material` block whose `reporting_required` is `yes`. Typically a few dozen concepts for a whole workbook. Format and allowed values are in
`references/profile-fields.md`. Each block belongs to exactly one concept.
- Base `period_rule` on the evidence: `sum3` suggests `quarter_sum_of_months`, `sum12` suggests
  `ltm_sum`, a direct tie on a balance line suggests `quarter_end_balance`.
- Use `manual_input` or `manual_review` for concepts without a tie, unless they are
  `carry_forward` or `carry_forward_event_driven`.
- Put anything the analyst must decide in `questions`.

### 4. Build the profile
```
python scripts/build_profile.py /app/created/<stem>_input_map.json /app/created/matches.json /app/created/concepts.json --out-dir /app/created
```
`PROFILE STATUS: INVALID` -> fix only the listed problems and re-run (max 3 attempts).

### 5. Approvals (only when the user replies to a finished run)
Do not ask for approval during the run. Approve a concept only when the user's message
explicitly approves it and names the approver:
```
python scripts/build_profile.py ... --approve "<concept_ids>" --approver "<name the user gave>"
```
Approvals already recorded are kept on re-runs. Other corrections: edit concepts.json, re-run step 4.

Approvals are tied to an approval basis hash (targets, rules, lineage, template fingerprint).
If any of these change, the script resets that approval to proposed and says so; report it.

### 6. Manifest
```
python scripts/write_manifest.py --skill valuation-mapping-profile --inputs "<workbook>" /app/created/<stem>_input_map.json <source files> /app/created/concepts.json --outputs /app/created/mapping_profile.json /app/created/mapping_profile_review.md /app/created/matches.json --parent-run-id <schema run_id> --out "/app/created/mapping_profile_run_manifest_{run_id}.json"
```

### 7. Save and report
Save `mapping_profile.json`, `mapping_profile_review.md`, `concepts.json`, `matches.json` and the manifest with
the SharePoint/OneDrive Create file tool (pass the sandbox path as the file content), or return
them as downloads. In the final summary quote the PROFILE STATUS and gate lines exactly, then the
review table from `mapping_profile_review.md` (weakest evidence first) and its questions.
READY_FOR_REPLAY means the profile can go to the replay test; it is not certified.

## Rules
- Do not ask the user questions during a run. Put open points in `questions` in concepts.json.
- Every script ends with a `NEXT REQUIRED STEP` line. Do exactly that next.
- Lineage comes only from matches.json. Never name a source file, sheet, row, unit or sign that
  the scripts did not report.
- A value tie is evidence of where a number came from, not proof of what it means. Say so when
  a tie looks coincidental (different label, odd transform).
- Never approve on the user's behalf, never infer approval from "looks good" about a different
  item, and never invent an approver name.
- Never calculate numbers. Do not modify the scripts, workbook or source files.
- Do not narrate progress. Report results.
