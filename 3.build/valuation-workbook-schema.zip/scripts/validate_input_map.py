# validate_input_map.py - checks an agent-written input map against the extractor's skeleton
# Usage: python validate_input_map.py <stem>_inputs_skeleton.json <stem>_input_map.json
# Prints VALID or INVALID plus a list of problems. Exit code 0 only when VALID.
import json, sys

TYPES = {"financial_statement", "assumption", "prior_period", "constant", "uncertain"}
CHANGES = {"yes", "no", "uncertain"}
FIELDS = {"id", "sheet", "range", "label", "header", "n_cells", "sample_values",
          "type", "source", "changes_each_quarter", "notes"}
LOCKED = ("sheet", "range", "n_cells", "sample_values")


def main(skel_path, map_path):
    skel = json.load(open(skel_path, encoding="utf-8"))
    try:
        m = json.load(open(map_path, encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"INVALID\n- input map is not valid JSON: {e}")
        return 1
    sk = {e["id"]: e for e in skel["inputs"]}
    errs, seen = [], {}
    for i, e in enumerate(m.get("inputs", [])):
        if not isinstance(e, dict) or "id" not in e:
            errs.append(f"entry {i}: must be an object with an id")
            continue
        eid = e["id"]
        if eid not in sk:
            errs.append(f"{eid}: not in the skeleton (do not invent or rename ids)")
            continue
        if eid in seen:
            errs.append(f"{eid}: duplicate entry")
        seen[eid] = e
        if set(e) - FIELDS:
            errs.append(f"{eid}: unknown fields {sorted(set(e) - FIELDS)}")
        for f in LOCKED:
            if e.get(f) != sk[eid].get(f):
                errs.append(f"{eid}: '{f}' was changed; copy it from the skeleton unchanged")
        if e.get("type") not in TYPES:
            errs.append(f"{eid}: type must be one of {sorted(TYPES)}")
        if e.get("changes_each_quarter") not in CHANGES:
            errs.append(f"{eid}: changes_each_quarter must be one of {sorted(CHANGES)}")
        if e.get("type") == "financial_statement" and not e.get("source"):
            errs.append(f"{eid}: financial_statement inputs need a source (statement and line item)")
    for eid in sk:
        if eid not in seen:
            errs.append(f"{eid}: missing from the input map")

    if errs:
        print("INVALID")
        print("\n".join(f"- {x}" for x in errs[:100]))
        if len(errs) > 100:
            print(f"- ... {len(errs) - 100} more")
        return 1
    counts = {t: sum(1 for e in seen.values() if e["type"] == t) for t in sorted(TYPES)}
    unsure = [eid for eid, e in seen.items()
              if e["type"] == "uncertain" or e["changes_each_quarter"] == "uncertain"]
    print("VALID")
    print("counts: " + ", ".join(f"{k}={v}" for k, v in counts.items()))
    print("needs user confirmation: " + (", ".join(unsure) if unsure else "(none)"))
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("usage: python validate_input_map.py <skeleton.json> <input_map.json>")
        sys.exit(2)
    sys.exit(main(sys.argv[1], sys.argv[2]))
