# extract_schema.py - deterministic Excel workbook schema extractor
# Usage: python extract_schema.py <workbook.xlsx> [--out DIR]
# Prints a compact, LLM-readable schema and writes two files to --out:
#   <stem>_schema.md             full schema text (same format as printed)
#   <stem>_inputs_skeleton.json  every input block, for the agent to annotate
# Only needs openpyxl. Never modifies the workbook.
import os, re, glob, json, argparse
from collections import defaultdict
from openpyxl import load_workbook
from openpyxl.utils import column_index_from_string as col_idx, get_column_letter as col_let
from openpyxl.utils import range_boundaries

MAX_ITEMS_PER_SECTION = 120   # max lines per section per sheet
MAX_OUTPUT_CHARS = 30000      # printed output cap (full version saved to schema_full.txt)
MAX_RANGE_CELLS = 20000       # ranges bigger than this are resolved against existing cells only


def find_file():
    for root in ["/app", os.getcwd(), "/mnt/data", "/tmp"]:
        hits = [h for ext in ("xlsx", "xlsm")
                for h in glob.glob(os.path.join(root, "**", "*." + ext), recursive=True)]
        hits = [h for h in hits if not os.path.basename(h).startswith("~$") and "/created/" not in h]
        if hits:
            return sorted(hits)[0]
    raise FileNotFoundError("no .xlsx or .xlsm file found in sandbox")


STR_LIT = re.compile(r'"[^"]*"')
REF = re.compile(
    r"(?<![A-Za-z0-9_.])"
    r"(?:(?:'((?:[^']|'')+)'|([A-Za-z_][A-Za-z0-9_.]*))!)?"
    r"(\$?)([A-Z]{1,3})(\$?)([0-9]+)"
    r"(?::(\$?)([A-Z]{1,3})(\$?)([0-9]+))?"
    r"(?![A-Za-z0-9_(])")
NUM = re.compile(r"(?<![A-Za-z0-9_.\[\]$])(\d+(?:\.\d+)?%?)(?![A-Za-z0-9_\[\]])")


def parse_refs(formula, cur_sheet):
    out = []
    for m in REF.finditer(STR_LIT.sub('""', formula)):
        sheet = m.group(1) or m.group(2)
        sheet = sheet.replace("''", "'") if sheet else cur_sheet
        c1, r1 = col_idx(m.group(4)), int(m.group(6))
        c2, r2 = (col_idx(m.group(8)), int(m.group(10))) if m.group(8) else (c1, r1)
        out.append((sheet, min(r1, r2), min(c1, c2), max(r1, r2), max(c1, c2)))
    return out


def rel_key(formula, row, col):
    """Formula rewritten with relative offsets, so copied-across formulas share one key."""
    def one(ca, c, ra, r):
        ci, ri = col_idx(c), int(r)
        return (f"R{ri}" if ra else f"R[{ri-row}]") + (f"C{ci}" if ca else f"C[{ci-col}]")

    def sub(m):
        s = m.group(1) or m.group(2) or ""
        s = s + "!" if s else ""
        s += one(m.group(3), m.group(4), m.group(5), m.group(6))
        if m.group(8):
            s += ":" + one(m.group(7), m.group(8), m.group(9), m.group(10))
        return s
    return REF.sub(sub, STR_LIT.sub('""', formula))


def hardcodes(formula):
    f = REF.sub("", STR_LIT.sub('""', formula))
    return sorted({n for n in NUM.findall(f) if n not in ("0", "1")})


def fmt(v):
    if v is None:
        return "(blank)"
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, (int, float)):
        return f"{v:,.0f}" if abs(v) >= 1000 else f"{v:.4g}"
    s = str(v).replace("\n", " ").strip()
    return s[:40] + ("..." if len(s) > 40 else "")


def addr(r, c1, c2=None):
    a = f"{col_let(c1)}{r}"
    return a + (f":{col_let(c2)}{r}" if c2 and c2 != c1 else "")


def main(path, out_dir):
    wbf = load_workbook(path, data_only=False)
    wbv = load_workbook(path, data_only=True)

    formulas, consts = {}, {}
    texts = defaultdict(dict)
    sheet_cells = defaultdict(list)
    for ws in wbf.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if v is None:
                    continue
                key = (ws.title, cell.row, cell.column)
                sheet_cells[ws.title].append((cell.row, cell.column))
                ftxt = str(getattr(v, "text", v))
                if cell.data_type == "f" or (isinstance(v, str) and v.startswith("=")):
                    formulas[key] = ftxt if ftxt.startswith("=") else "=" + ftxt
                else:
                    consts[key] = v
                    if isinstance(v, str) and v.strip():
                        texts[ws.title][(cell.row, cell.column)] = v.strip()

    # named ranges
    names = {}
    try:
        items = list(wbf.defined_names.items())
    except Exception:
        items = [(d.name, d) for d in getattr(wbf.defined_names, "definedName", [])]
    for ws in wbf.worksheets:
        try:
            items += list(ws.defined_names.items())
        except Exception:
            pass
    for n, d in items:
        try:
            dests = list(d.destinations)
        except Exception:
            dests = []
        names[n] = (getattr(d, "attr_text", ""), dests)
    name_re = None
    if names:
        name_re = re.compile(r"(?<![A-Za-z0-9_.])(" + "|".join(
            sorted(map(re.escape, names), key=len, reverse=True)) + r")(?![A-Za-z0-9_(])", re.I)
    lower_names = {n.lower(): n for n in names}

    # dependencies
    referenced = set()
    edges = defaultdict(int)
    external = []

    def mark(rs, r1, c1, r2, c2, from_sheet):
        if rs != from_sheet:
            edges[(rs, from_sheet)] += 1
        if (r2 - r1 + 1) * (c2 - c1 + 1) <= MAX_RANGE_CELLS:
            for rr in range(r1, r2 + 1):
                for cc in range(c1, c2 + 1):
                    referenced.add((rs, rr, cc))
        else:
            for (rr, cc) in sheet_cells.get(rs, []):
                if r1 <= rr <= r2 and c1 <= cc <= c2:
                    referenced.add((rs, rr, cc))

    for (s, r, c), f in formulas.items():
        if re.search(r"\[\d+\]", f) or ".xls" in f.lower():
            external.append(f"{s}!{addr(r, c)}")
        for ref in parse_refs(f, s):
            mark(*ref, s)
        if name_re:
            for m in name_re.finditer(STR_LIT.sub('""', f)):
                for dsheet, coord in names[lower_names[m.group(1).lower()]][1]:
                    try:
                        c1, r1, c2, r2 = range_boundaries(coord.replace("$", ""))
                        mark(dsheet, r1, c1, r2 or r1, c2 or c1, s)
                    except Exception:
                        pass

    def val(s, r, c):
        return wbv[s].cell(row=r, column=c).value

    def label(s, r, c):
        t = texts.get(s, {})
        left = next((t[(r, cc)] for cc in range(c - 1, 0, -1) if (r, cc) in t), "")
        up = next((t[(rr, c)] for rr in range(r - 1, max(0, r - 40), -1) if (rr, c) in t), "")
        return fmt(left) if left else "?", fmt(up) if up else ""

    def group_row(cells, keyfn):
        groups = []
        for (r, c) in sorted(cells):
            k = keyfn(r, c)
            g = groups[-1] if groups else None
            if g and g["r"] == r and g["c2"] == c - 1 and g["k"] == k:
                g["c2"] = c
                g["cells"].append((r, c))
            else:
                groups.append({"r": r, "c1": c, "c2": c, "k": k, "cells": [(r, c)]})
        return groups

    def capped(lines):
        if len(lines) > MAX_ITEMS_PER_SECTION:
            return lines[:MAX_ITEMS_PER_SECTION] + [f"... TRUNCATED: {len(lines) - MAX_ITEMS_PER_SECTION} more lines"]
        return lines

    out = []
    tot_in = tot_out = 0
    sheet_blocks = []
    global_flags = []
    skeleton = []
    for ws in wbf.worksheets:
        s = ws.title
        f_cells = [(r, c) for (ss, r, c) in formulas if ss == s]
        in_cells = [(r, c) for (ss, r, c), v in consts.items()
                    if ss == s and (s, r, c) in referenced]
        unref_nums = sum(1 for (ss, r, c), v in consts.items()
                         if ss == s and isinstance(v, (int, float)) and (s, r, c) not in referenced)

        # inputs
        in_lines = []
        for g in group_row(in_cells, lambda r, c: "in"):
            left, up1 = label(s, g["r"], g["c1"])
            up2 = label(s, g["r"], g["c2"])[1]
            hdr = up1 if up1 == up2 or not up2 else f"{up1}..{up2}"
            vals = [fmt(consts[(s, r, c)]) for (r, c) in g["cells"]]
            vtxt = ", ".join(vals[:6]) + (f", ... ({len(vals)} cells)" if len(vals) > 6 else "")
            rng = addr(g['r'], g['c1'], g['c2'])
            in_lines.append(f"{rng} [input] {left}" + (f" | {hdr}" if hdr else "") + f" = {vtxt}")
            skeleton.append({"id": f"{s}!{rng}", "sheet": s, "range": rng, "label": left, "header": hdr,
                             "n_cells": len(vals), "sample_values": vals[:6],
                             "type": None, "source": None, "changes_each_quarter": None, "notes": None})

        # formulas
        f_lines, row_groups = [], defaultdict(list)
        n_out = 0
        for g in group_row(f_cells, lambda r, c: rel_key(formulas[(s, r, c)], r, c)):
            row_groups[g["r"]].append(g)
            r, c1 = g["r"], g["c1"]
            is_out = not any((s, rr, cc) in referenced for (rr, cc) in g["cells"])
            n_out += len(g["cells"]) if is_out else 0
            left, up1 = label(s, r, c1)
            up2 = label(s, r, g["c2"])[1]
            hdr = up1 if up1 == up2 or not up2 else f"{up1}..{up2}"
            vals = [val(s, rr, cc) for (rr, cc) in g["cells"]]
            vtxt = ", ".join(fmt(v) for v in vals[:3]) + (", ..." if len(vals) > 3 else "")
            n = len(g["cells"])
            line = (f"{addr(r, c1, g['c2'])} [{'output' if is_out else 'calc'}] {left}"
                    + (f" | {hdr}" if hdr else "")
                    + f" {formulas[(s, r, c1)]}" + (f"  (same pattern x{n})" if n > 1 else "")
                    + f" -> {vtxt}")
            hc = hardcodes(formulas[(s, r, c1)])
            if hc:
                line += f"  FLAG:hardcoded {','.join(hc)}"
            errs = [v for v in vals if isinstance(v, str) and v.startswith("#")]
            if errs:
                line += f"  FLAG:error {errs[0]}"
                global_flags.append(f"{s}!{addr(r, c1, g['c2'])} error {errs[0]}")
            if all(v is None for v in vals):
                line += "  FLAG:no cached value"
            f_lines.append(line)

        # pattern breaks: A,B,A in one row where B is a single cell
        for r, gs in row_groups.items():
            for i in range(1, len(gs) - 1):
                a, b, c_ = gs[i - 1], gs[i], gs[i + 1]
                if a["k"] == c_["k"] and len(b["cells"]) == 1 and a["c2"] + 1 == b["c1"] and b["c2"] + 1 == c_["c1"]:
                    global_flags.append(f"{s}!{addr(r, b['c1'])} breaks the formula pattern of its row")

        reads = sorted({a for (a, b) in edges if b == s})
        read_by = sorted({b for (a, b) in edges if a == s})
        tot_in += len(in_cells)
        tot_out += n_out
        block = [f"\n=== SHEET: {s} ===",
                 f"state: {ws.sheet_state} | used range: {ws.dimensions} | formulas: {len(f_cells)}"
                 f" | inputs: {len(in_cells)} | output cells: {n_out} | unreferenced numbers: {unref_nums}",
                 f"reads from: {', '.join(reads) or '-'} | read by: {', '.join(read_by) or '-'}",
                 "-- INPUTS --"] + (capped(in_lines) or ["(none)"]) + \
                ["-- FORMULAS --"] + (capped(f_lines) or ["(none)"])
        sheet_blocks.append(block)

    out.append("=== WORKBOOK SCHEMA ===")
    out.append(f"file: {os.path.basename(path)} | sheets: {len(wbf.sheetnames)} | formula cells: {len(formulas)}"
               f" | input cells: {tot_in} | output cells: {tot_out}")
    out.append("legend: [input]=hardcoded value used by a formula; [calc]=formula used by other formulas; "
               "[output]=formula nothing else in the workbook uses; values after -> are Excel's last saved results; "
               "'same pattern xN' = one formula copied across N cells (formula shown for the first cell); "
               "labels are 'row label | column header' taken from nearby text and may be wrong")
    out.append("sheet order: " + ", ".join(f"{ws.title}{' (hidden)' if ws.sheet_state != 'visible' else ''}"
                                          for ws in wbf.worksheets))
    out.append("\n=== SHEET FLOW (source -> uses it: reference count) ===")
    out += [f"{a} -> {b}: {n}" for (a, b), n in sorted(edges.items(), key=lambda x: -x[1])] or ["(no cross-sheet references)"]
    out.append("\n=== NAMED RANGES ===")
    out += [f"{n} = {t}" for n, (t, _) in sorted(names.items())] or ["(none)"]
    for b in sheet_blocks:
        out += b
    out.append("\n=== FLAGS ===")
    if external:
        global_flags.insert(0, f"external workbook links in {len(external)} cells, e.g. {', '.join(external[:5])}")
    out += global_flags[:MAX_ITEMS_PER_SECTION] or ["(none)"]
    out.append("\n=== END OF SCHEMA ===")

    full = "\n".join(out)
    os.makedirs(out_dir, exist_ok=True)
    stem = re.sub(r"[^A-Za-z0-9_-]+", "_", os.path.splitext(os.path.basename(path))[0])
    schema_path = os.path.join(out_dir, f"{stem}_schema.md")
    skel_path = os.path.join(out_dir, f"{stem}_inputs_skeleton.json")
    with open(schema_path, "w", encoding="utf-8") as fh:
        fh.write(full)
    with open(skel_path, "w", encoding="utf-8") as fh:
        json.dump({"workbook": os.path.basename(path), "generated_by": "extract_schema.py",
                   "inputs": skeleton}, fh, indent=1, default=str)
    if len(full) > MAX_OUTPUT_CHARS:
        full = full[:MAX_OUTPUT_CHARS] + "\n... OUTPUT TRUNCATED (read the full schema file)\n=== END OF SCHEMA ==="
    print(full)
    print(f"\nFILES WRITTEN:\n{schema_path}\n{skel_path}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("workbook", nargs="?", help="path to .xlsx/.xlsm (searched for if omitted)")
    ap.add_argument("--out", default="/app/created" if os.path.isdir("/app") else os.getcwd())
    a = ap.parse_args()
    try:
        main(a.workbook or find_file(), a.out)
    except Exception as e:
        print(f"EXTRACTION_ERROR: {type(e).__name__}: {e}")
        raise SystemExit(1)
