# Reading the Workbook Schema

## Line format
`<range> [<role>] <row label> | <column header> <formula> (same pattern xN) -> <values>  FLAG:...`

- `[input]` a hardcoded value that at least one formula uses. Python decided this; trust it.
- `[calc]` a formula that other formulas use.
- `[output]` a formula nothing else in the workbook uses. Usually a final result, sometimes a
  check or a leftover.
- `same pattern xN` one formula copied across N cells; the formula shown is the first cell's.
- `-> values` are the results Excel saved last time the file was saved. `(blank)` or
  `FLAG:no cached value` means the file was never recalculated in Excel.
- Labels (`row label | column header`) are the nearest text to the left and above. They can
  be wrong, especially column headers far below a header row.

## Sections
- SHEET FLOW: `A -> B: n` means sheet B has n references into sheet A.
- NAMED RANGES: names used in formulas and the cells they point to.
- FLAGS: errors, external workbook links, and single cells breaking their row's formula
  pattern. `FLAG:hardcoded` inside a formula line lists numbers typed directly into the formula
  (e.g. `*1.02`, or year exponents like `^3`). Report them; do not judge them.

## Input map fields (the only fields you fill)
- `type`, exactly one of:
  - `financial_statement` comes from the company's statements (revenue, EBITDA, cash, debt...)
  - `assumption` a judgement input (discount rate, growth, multiple, discount for illiquidity)
  - `prior_period` carried forward from the previous valuation
  - `constant` fixed values that should not change (tax rate, share count if fixed, unit factors)
  - `uncertain` you cannot tell from the schema
- `source`: for `financial_statement`, the statement and line item in plain words, e.g.
  `Income statement: Revenue`. Otherwise `null` or a short description.
- `changes_each_quarter`: `yes`, `no`, or `uncertain`.
- `notes`: at most one sentence, citing cells. `null` if nothing to add.
