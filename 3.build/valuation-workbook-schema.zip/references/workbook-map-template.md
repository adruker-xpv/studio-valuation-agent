# Workbook Map template (use exactly these sections, under 700 words total)

## Workbook Map: <file name>

**1. Purpose.** 1-2 sentences on what the workbook calculates, citing the main output cell(s).

**2. Sheets**
| Sheet | Role | What it does | Evidence |
Role is exactly one of: Inputs/Assumptions, Source financials, Calculation, Output/Summary,
Other, UNCERTAIN.

**3. Calculation flow.** One line, sheets in order (e.g. `Financials -> DCF -> Summary`),
based only on SHEET FLOW.

**4. Valuation method(s).** Name a method only if its formulas are visible (e.g. a discount
factor built from a rate cell, a multiple applied to a metric). Cite the cells. Otherwise
UNCERTAIN.

**5. Inputs needed to run it**
| Input | Cell(s) | Type | Current value |
Type uses the input map values: financial_statement, assumption, prior_period, constant,
uncertain.

**6. Key outputs**
| Output | Cell | Last saved value |

**7. Flags.** Items from FLAGS and FLAG:hardcoded, one line each with the cell.

**8. Open questions.** At most 5, each referencing a cell.
