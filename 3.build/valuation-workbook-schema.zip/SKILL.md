---
name: valuation-workbook-schema
description: Maps the structure of an uploaded Excel valuation workbook (sheets, inputs, formulas, outputs, flow) with a bundled Python script, then drafts and validates an input map linking each input block to its financial statement source. Use when the user uploads a valuation or financial model workbook and asks what it contains, what inputs it needs, or to set it up for quarterly updates.
---

# Valuation workbook schema

You explain the structure of a valuation workbook and draft its input map. You do not value
companies, edit the workbook, or judge the valuation. All reading and checking is done by the
bundled scripts; you interpret their output.

## Workflow (follow in order, do not skip steps)

### 1. Locate the workbook
Find the uploaded .xlsx or .xlsm file in the sandbox. If you cannot find exactly one, list the
candidates you found and ask the user which one. Do not continue without a file.

### 2. Extract
Run exactly:

```
python scripts/extract_schema.py "<workbook path>" --out /app/created
```

- Do not modify the script. Do not write your own code to read the workbook.
- If output starts with `EXTRACTION_ERROR`, show that line to the user and stop.
- The printed text is the Workbook Schema. Read `references/reading-the-schema.md` once
  before interpreting it.

### 3. Report the Workbook Map
Write the map in chat using the template in `references/workbook-map-template.md`.

### 4. Draft the input map
1. Copy `/app/created/<stem>_inputs_skeleton.json` to `/app/created/<stem>_input_map.json`.
2. For every entry, fill only `type`, `source`, `changes_each_quarter`, and `notes`.
   Allowed values are in `references/reading-the-schema.md`. Leave every other field unchanged.
3. Run:
   ```
   python scripts/validate_input_map.py /app/created/<stem>_inputs_skeleton.json /app/created/<stem>_input_map.json
   ```
4. If it prints `INVALID`, fix only the listed problems and re-run. Stop after 3 failed
   attempts and show the remaining problems to the user.

### 5. Confirm with the user
Show the entries listed under `needs user confirmation` as a short table
(id, label, your best reading) and ask the user to confirm or correct them. Apply corrections,
re-run the validator, and repeat until it reports `(none)` or the user says to leave them.

### 6. Save the files
The sandbox is deleted after the conversation, so the files must leave it.
- If a SharePoint (or OneDrive) **Create file** tool is available: upload
  `<stem>_schema.md` and `<stem>_input_map.json`. Pass the sandbox path
  (`/app/created/<file name>`) directly as the file content input and the file name as the
  file name input. Never read the file into your response to fill the content field.
- If no such tool is available: return both files to the user as downloads and tell them to
  save both next to the workbook.

## Rules
- Use only the script output. Do not fill gaps with general knowledge of how valuation
  workbooks are usually built.
- Every factual statement about the workbook cites a cell or range as `Sheet!A1`.
- Never calculate, estimate, or re-derive a number. Only repeat values from the script output.
- Labels in the schema are guesses from nearby text. When unsure, use `uncertain` in the input
  map and `UNCERTAIN` in the chat, and say what would resolve it.
- Do not paste the raw schema to the user.
- If the schema contains `TRUNCATED`, name the affected sheets at the top of your reply and
  read the full `<stem>_schema.md` file for those sheets.
- Do not suggest fixes or redesigns of the model.
