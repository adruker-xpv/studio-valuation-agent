#!/usr/bin/env python3
"""Diagnostic only: can the script sandbox see a file the agent fetched from OneDrive?

Searches the usual sandbox locations for a file by name and reports where it
is, its size, and whether it contains the expected text. Read-only: it never
creates, moves or changes files.

Usage:
    python scripts/probe_sandbox.py --name bridge-test.json --expect-text "hello from onedrive"

Always exits 0.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

ROOTS = [Path.cwd(), Path("/mnt/data"), Path("/mnt/user-data"), Path("/mnt"), Path("/tmp"),
         Path.home(), Path(__file__).resolve().parent.parent]
MAX_DEPTH = 4
MAX_FILES_LISTED = 40


def walk(root: Path):
    root_depth = len(root.parts)
    for dirpath, dirnames, filenames in os.walk(root, onerror=lambda e: None):
        if len(Path(dirpath).parts) - root_depth >= MAX_DEPTH:
            dirnames[:] = []
        dirnames[:] = [d for d in dirnames if d not in {"proc", "sys", "__pycache__", "node_modules", ".git"}]
        for f in filenames:
            yield Path(dirpath) / f


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--name", required=True)
    ap.add_argument("--expect-text")
    a = ap.parse_args()
    report = {"cwd": str(Path.cwd()), "roots_checked": [], "matches": [], "recent_files": [],
              "conclusion": None}
    seen, recent = set(), []
    target = a.name.lower()
    for root in ROOTS:
        exists = root.is_dir()
        report["roots_checked"].append({"root": str(root), "exists": exists})
        if not exists:
            continue
        for p in walk(root):
            try:
                rp = p.resolve()
                if rp in seen or not rp.is_file():
                    continue
                seen.add(rp)
                st = rp.stat()
                recent.append((st.st_mtime, str(rp), st.st_size))
                if target in rp.name.lower():
                    head = rp.read_bytes()[:400].decode("utf-8", errors="replace")
                    report["matches"].append({
                        "path": str(rp), "size": st.st_size, "starts_with": head[:200],
                        "contains_expected_text": (a.expect_text in head) if a.expect_text else None})
            except (OSError, PermissionError):
                continue
    recent.sort(reverse=True)
    report["recent_files"] = [{"path": p, "size": s} for _, p, s in recent[:MAX_FILES_LISTED]]
    if any(m["contains_expected_text"] for m in report["matches"]):
        report["conclusion"] = "FOUND_WITH_CONTENT: the sandbox can see the fetched file. Use this path."
    elif report["matches"]:
        report["conclusion"] = ("FOUND_BUT_CONTENT_DIFFERS: a file with this name exists but not with the "
                                "expected text (it may be a link, metadata, or encoded content).")
    else:
        report["conclusion"] = "NOT_FOUND: the fetched file is not visible to scripts in this sandbox."
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
