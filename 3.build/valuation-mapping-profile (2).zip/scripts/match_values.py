# match_values.py - finds where each material workbook input value appears in the source statements
# Usage: python match_values.py <workbook.xlsx> <input_map.json> <sources_index.json> --out /app/created/matches.json
# Evidence types: direct, scaled (x1000 etc.), sign-flipped, sum of 3 (quarter from months),
# sum of 12 (LTM). A value tie is evidence of lineage; it is not proof of meaning.
import sys, json, bisect, argparse
from collections import Counter
from openpyxl import load_workbook
from openpyxl.utils import range_boundaries, get_column_letter as col_let

SCALES = [1, 0.001, 1000, 0.000001, 1000000]   # workbook value = source value * scale * sign
MIN_ABS = 100                                   # smaller values are too generic to match


def main(wb_path, map_path, idx_path, out):
    m = json.load(open(map_path, encoding="utf-8"))
    idx = json.load(open(idx_path, encoding="utf-8"))
    wb = load_workbook(wb_path, data_only=True)
    pool = [dict(x, transform="direct") for x in idx["values"]] + \
           [dict(x, transform=f"sum{x['n']}") for x in idx["row_sums"]]
    pool.sort(key=lambda x: x["value"])
    keys = [x["value"] for x in pool]

    def find(v):
        tol = 0.51 if float(v).is_integer() else max(abs(v) * 1e-9, 1e-6)
        hits = []
        for sc in SCALES:
            for sg in (1, -1):
                target = v / (sc * sg)
                t = tol / sc
                lo, hi = bisect.bisect_left(keys, target - t), bisect.bisect_right(keys, target + t)
                for x in pool[lo:hi]:
                    hits.append(dict(x, scale=sc, sign=sg,
                                     rank=(x["transform"] != "direct", sc != 1, sg != 1)))
        hits.sort(key=lambda h: h["rank"])
        return hits

    def sig(h):
        return (h["label"], h["file"], h["sheet"], h["transform"], h["scale"], h["sign"])

    def slim(h):
        return {k: h[k] for k in ("file", "sheet", "cell", "label", "period", "transform", "scale", "sign")}

    blocks, tally = [], Counter()
    for e in m["inputs"]:
        if not e.get("material") or e.get("type") == "not_material":
            continue
        c1, r1, c2, r2 = range_boundaries(e["range"])
        cells, hits_by_cell = [], {}
        for r in range(r1, (r2 or r1) + 1):
            for c in range(c1, (c2 or c1) + 1):
                v = wb[e["sheet"]].cell(row=r, column=c).value
                ref = f"{e['sheet']}!{col_let(c)}{r}"
                cell = {"cell": ref, "value": v}
                if not isinstance(v, (int, float)) or isinstance(v, bool) or abs(v) < MIN_ABS:
                    cell["result"] = "not_testable"
                else:
                    hits_by_cell[ref] = find(float(v))
                cells.append(cell)
        # choose the source signature that explains the most cells in the block
        cover = {}
        for ref, hits in hits_by_cell.items():
            for h in hits:
                k = sig(h)
                cover.setdefault(k, {"cells": set(), "rank": h["rank"]})["cells"].add(ref)
        ranked = sorted(cover.items(), key=lambda kv: (-len(kv[1]["cells"]), kv[1]["rank"]))
        tested = len(hits_by_cell)
        best_sig = ranked[0][0] if ranked else None
        best_n = len(ranked[0][1]["cells"]) if ranked else 0
        rivals = [k for k, v in ranked if len(v["cells"]) == best_n and v["rank"] == ranked[0][1]["rank"]] if ranked else []
        for cell in cells:
            hits = hits_by_cell.get(cell["cell"])
            if hits is None:
                continue
            chosen = [h for h in hits if sig(h) == best_sig]
            if not hits:
                cell["result"] = "no_tie"
            elif chosen:
                cell["result"] = "tie" if len(rivals) == 1 else "ambiguous"
                cell["candidates"] = [slim(chosen[0])] + [slim(h) for h in hits if sig(h) != best_sig][:4]
            else:
                cell["result"] = "other_source_only"
                cell["candidates"] = [slim(h) for h in hits[:5]]
        if not tested:
            status = "not_testable"
        elif not ranked:
            status = "no_tie"
        elif len(rivals) > 1:
            status = "ambiguous"
        elif best_n == tested:
            status = "consistent_tie"
        else:
            status = "partial_or_mixed_tie"
        tally[status] += 1
        dom = None
        if best_sig and len(rivals) == 1:
            lbl, fn, sh, tr, sc, sg = best_sig
            dom = {"label": lbl, "file": fn, "sheet": sh, "transform": tr, "scale": sc, "sign": sg, "cells": best_n}
        alt = [{"label": k[0], "file": k[1], "transform": k[3], "scale": k[4], "sign": k[5]} for k in rivals] if len(rivals) > 1 else []
        blocks.append({"id": e["id"], "type": e.get("type"), "status": status,
                       "cells_tested": tested, "cells_tied": best_n if dom else 0,
                       "dominant_source": dom, "ambiguous_between": alt, "cells": cells})
    json.dump({"workbook": wb_path.split("/")[-1], "blocks": blocks}, open(out, "w", encoding="utf-8"), indent=1, default=str)
    print(f"MATCH SUMMARY: {len(blocks)} material blocks | " + ", ".join(f"{k}={v}" for k, v in sorted(tally.items())))
    for b in blocks:
        d = b["dominant_source"]
        src = (f"{d['label']} [{d['file']}] {d['transform']} x{d['scale']}" + (" sign-flip" if d["sign"] == -1 else "")) if d else "-"
        print(f"{b['id']} | {b['status']} | tied {b['cells_tied']}/{b['cells_tested']} | {src}")
    print(f"FILE WRITTEN: {out}")
    print("NEXT REQUIRED STEP: write concepts.json (references/profile-fields.md), then run build_profile.py.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("workbook"); ap.add_argument("input_map"); ap.add_argument("sources_index")
    ap.add_argument("--out", default="/app/created/matches.json")
    a = ap.parse_args()
    try:
        main(a.workbook, a.input_map, a.sources_index, a.out)
    except Exception as e:
        print(f"MATCH_ERROR: {type(e).__name__}: {e}")
        sys.exit(1)
