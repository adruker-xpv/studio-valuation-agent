# index_sources.py - indexes every number in the source statements (xlsx/xlsm/csv)
# Usage: python index_sources.py <file or folder> [more ...] --out /app/created/sources_index.json
# Records each numeric cell with its row label and period header, plus rolling row sums of
# 3 and 12 consecutive numbers (quarter-from-months and LTM candidates). Never modifies files.
import os, sys, csv, json, glob, argparse, datetime
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter as col_let


def fmt_hdr(v):
    if isinstance(v, datetime.datetime):
        return v.strftime("%Y-%m-%d")
    return str(v).strip()[:40]


def grids(path):
    if path.lower().endswith(".csv"):
        with open(path, newline="", encoding="utf-8-sig") as fh:
            g = {}
            for r, row in enumerate(csv.reader(fh), 1):
                for c, v in enumerate(row, 1):
                    v = v.strip()
                    if not v:
                        continue
                    try:
                        g[(r, c)] = float(v.replace(",", "").replace("$", "").replace("(", "-").replace(")", ""))
                    except ValueError:
                        g[(r, c)] = v
            yield "csv", g
        return
    wb = load_workbook(path, data_only=True)
    for ws in wb.worksheets:
        yield ws.title, {(c.row, c.column): c.value for row in ws.iter_rows() for c in row if c.value is not None}


def is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def main(paths, out):
    files = []
    for p in paths:
        if os.path.isdir(p):
            files += [f for ext in ("xlsx", "xlsm", "csv") for f in glob.glob(os.path.join(p, "**", "*." + ext), recursive=True)]
        else:
            files.append(p)
    files = sorted(f for f in files if not os.path.basename(f).startswith("~$"))
    if not files:
        raise FileNotFoundError("no .xlsx/.xlsm/.csv source files found")
    values, sums = [], []
    for f in files:
        fn = os.path.basename(f)
        for sheet, g in grids(f):
            def label(r, c):
                for cc in range(c - 1, 0, -1):
                    v = g.get((r, cc))
                    if isinstance(v, str) and v.strip():
                        return v.strip()[:60]
                return "?"

            def period(r, c):
                for rr in range(r - 1, max(0, r - 60), -1):
                    v = g.get((rr, c))
                    if isinstance(v, (str, datetime.datetime)) and str(v).strip():
                        return fmt_hdr(v)
                return ""
            rows = {}
            for (r, c), v in g.items():
                if is_num(v):
                    rows.setdefault(r, []).append(c)
                    values.append({"file": fn, "sheet": sheet, "cell": f"{col_let(c)}{r}",
                                   "label": label(r, c), "period": period(r, c), "value": float(v)})
            for r, cols in rows.items():
                cols.sort()
                runs, cur = [], [cols[0]]
                for c in cols[1:]:
                    if c == cur[-1] + 1:
                        cur.append(c)
                    else:
                        runs.append(cur)
                        cur = [c]
                runs.append(cur)
                for run in runs:
                    for n in (3, 12):
                        for i in range(len(run) - n + 1):
                            w = run[i:i + n]
                            sums.append({"file": fn, "sheet": sheet,
                                         "cell": f"{col_let(w[0])}{r}:{col_let(w[-1])}{r}",
                                         "label": label(r, w[0]), "period": f"{period(r, w[0])}..{period(r, w[-1])}",
                                         "n": n, "value": float(sum(g[(r, c)] for c in w))})
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    json.dump({"files": [os.path.basename(f) for f in files], "values": values, "row_sums": sums},
              open(out, "w", encoding="utf-8"))
    print(f"SOURCES INDEXED: {len(files)} files | numeric cells: {len(values)} | row sums: {len(sums)}")
    for f in files:
        print(f"- {os.path.basename(f)}")
    print(f"FILE WRITTEN: {out}")
    print("NEXT REQUIRED STEP: run match_values.py.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="+")
    ap.add_argument("--out", default="/app/created/sources_index.json")
    a = ap.parse_args()
    try:
        main(a.paths, a.out)
    except Exception as e:
        print(f"INDEX_ERROR: {type(e).__name__}: {e}")
        sys.exit(1)
