# concepts.json format

```json
{"concepts": [
  {"concept_id": "is.revenue",
   "name": "Revenue",
   "targets": ["Quarterly!B2:E2"],
   "write_mode": "roll_window",
   "period_rule": "quarter_sum_of_months",
   "notes": "feeds Valuation!B5 via Quarterly!B5 -> Valuation!B1",
   "questions": ["Is the newest quarter always the right-most column?"]}
]}
```
Only these seven fields. The script adds evidence, lineage and approval fields itself.
`concept_id`: lowercase `area.name` (is., bs., cf., cap., asm., comp., adj., fx.).
`targets`: ids exactly as in the input map.

## write_mode
- `replace_period_value` overwrite the current-period cell(s) with the new value
- `roll_window` shift periods left and write the newest period (quarterly/monthly rows, LTM windows)
- `carry_forward` keep last quarter's value unless the analyst changes it
- `carry_forward_event_driven` keep unless a capital or instrument event is evidenced (cap table,
  share counts, options, instrument terms); requires evidence of no change each quarter
- `manual_input` the analyst enters it each quarter (judgement assumptions, add-backs)
- `manual_review` rule not yet known; blocks READY_FOR_REPLAY

## period_rule
`month`, `quarter_sum_of_months`, `quarter_end_balance`, `ltm_sum`, `ytd`, `point_in_time`,
`not_periodic`, `uncertain` (blocks READY_FOR_REPLAY).

## Evidence fields added by the script (read-only)
`evidence_status` (worst across the concept's blocks), `source_lineage` (label, file, transform,
unit_scale, sign, cells tied), `source_label_candidates`, `tie_examples`, `formula_preservation`,
`approval` (status, approved_by, date).

## Profile gates
READY_FOR_REPLAY requires: every concept approved by a named person; every automated concept
(replace_period_value, roll_window) has consistent or partial tie evidence; no manual_review or
uncertain period rules.
