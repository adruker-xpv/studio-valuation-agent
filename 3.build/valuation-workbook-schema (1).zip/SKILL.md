---
name: valuation-workbook-schema
description: Maps an uploaded Excel valuation workbook with bundled Python scripts (sheets, inputs, formulas, outputs, dependencies, flags), traces which inputs feed the confirmed key outputs, and builds a validated input map with a completeness status. Use when the user uploads a valuation or financial model workbook and asks what it contains, what inputs it needs, or to prepare it for quarterly updates.
---

# Valuation workbook schema

You map a valuation workbook and draft its input map. You do not value companies, edit the
workbook, or judge the valuation. The scripts do all reading, counting, tracing and checking.
You interpret their output and ask the user to resolve what the scripts cannot.

## Workflow (in order; do not skip or merge steps)

### 1. Locate the workbook
Find the uploaded .xlsx/.xlsm in the sandbox. If there is not exactly one, list what you found
and ask which to use.

### 2. Discovery run
```
python scripts/extract_schema.py "<workbook>" --out /app/created
```
If output starts with `EXTRACTION_ERROR`, show that line and stop. Otherwise read the printed
OVERVIEW and the `<stem>_outputs.md` file.

### 3. Confirm key outputs with the user
Propose up to 15 key output cells (e.g. enterprise value, equity value, the fund's share,
IRR, multiple), each with its cell and last saved value from the outputs file. Ask the user
to confirm or edit the list. Do not continue until they confirm.

### 4. Final run
```
python scripts/extract_schema.py "<workbook>" --out /app/created --key-outputs "<confirmed refs, comma-separated>"
```
Quote sheet names containing spaces: `'Cap Table'!H15`. This run defines which inputs are
MATERIAL (they feed a key output) and lists BLOCKING ISSUES.

### 5. Read the sheets
Open every sheet file listed in the OVERVIEW that has material input cells, and read each one
to its `=== END OF SHEET ===` line. Files are complete and never truncated; read long files in
parts rather than stopping early. Read `references/reading-the-schema.md` once first.

### 6. Report the Workbook Map
Use `references/workbook-map-template.md`.

### 7. Build the input map
1. Copy `<stem>_inputs_skeleton.json` to `<stem>_input_map.json`.
2. Fill only `type`, `expected_source`, `changes_each_quarter`, `notes` (allowed values in
   `references/reading-the-schema.md`). Never change other fields; never add, split, merge,
   or delete entries.
3. Entries with `"material": false` may be set to `not_material`.
4. Classify each material entry individually. Its `notes` must cite the cells that justify
   the type (e.g. "feeds Valuation!B2 via Valuation!B1"). If an entry has `flags`, the notes
   must address each flag.
5. Validate:
   ```
   python scripts/validate_input_map.py /app/created/<stem>_inputs_skeleton.json /app/created/<stem>_input_map.json
   ```
6. `STATUS: INVALID` -> fix only the listed problems and re-run. After 3 failed attempts,
   show the remaining problems to the user and stop.

### 8. Resolve with the user
If `STATUS: REVIEW_REQUIRED`, show the failed gates, the unresolved entries (material first),
and the blocking issues as short tables. Ask the user to resolve them. Apply the answers,
re-run the validator, and repeat. If the user chooses to leave items open, stop there; the
status stays REVIEW_REQUIRED.

### 9. Save
The sandbox is deleted after the conversation. Save `<stem>_input_map.json` and
`<stem>_schema.md`.
- With a SharePoint/OneDrive **Create file** tool: pass the sandbox path
  (`/app/created/<file>`) directly as the file content and the file name as the file name.
  Never read a file into your response to fill a tool input.
- Without one: return both files as downloads.

### 10. Final report
Quote the validator's `STATUS` line, reconciliation line, and gate lines exactly. Then state
where the files were saved. Call the map complete only if the status is `COMPLETE`, and even
then say it is not proof that a new workbook can be generated correctly.

## Rules
- Use only script output. Do not fill gaps with general knowledge of how workbooks are built.
- Cite a cell or range (`Sheet!A1`) for every factual statement about the workbook.
- Never calculate, estimate, or re-derive a number.
- Never dismiss content as junk, legacy, or unimportant, and never decide you have "enough".
  Anything you think is irrelevant gets a disposition in the input map (`not_material` when
  allowed, otherwise a type and a note) or goes to the user.
- `expected_source` describes where a value should come from each quarter. Never write it as
  if you have seen that source document.
- Report named ranges by the categories the script assigns; do not skip them.
- Do not narrate progress ("moving on to..."). Report results.
- Do not suggest fixes or redesigns of the model.
