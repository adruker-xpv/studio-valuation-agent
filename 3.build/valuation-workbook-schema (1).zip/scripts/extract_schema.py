# extract_schema.py - deterministic Excel workbook schema extractor (v2)
# Usage:
#   python extract_schema.py <workbook.xlsx> [--out DIR] [--key-outputs "Sheet!B3,'My Sheet'!C10:C12"]
# Prints a bounded OVERVIEW. Writes complete, never-truncated files to --out:
#   <stem>_schema.md              full schema (overview + every sheet)
#   <stem>_sheets/<sheet>.md      one complete file per sheet
#   <stem>_outputs.md             every output cell
#   <stem>_inputs_skeleton.json   every input block, for the agent to annotate
# Only needs openpyxl. Never modifies the workbook.
import os, re, glob, json, argparse, datetime
from collections import defaultdict, deque
from openpyxl import load_workbook
from openpyxl.utils import column_index_from_string as col_idx, get_column_letter as col_let
from openpyxl.utils import range_boundaries

MAX_RANGE_CELLS = 20000     # larger ranges are resolved against existing cells only
OVERVIEW_LIST_CAP = 60      # max list lines in the printed overview (files are never capped)

STR_LIT = re.compile(r'"[^"]*"')
REF = re.compile(
    r"(?<![A-Za-z0-9_.])"
    r"(?:(?:'((?:[^']|'')+)'|([A-Za-z_][A-Za-z0-9_.]*))!)?"
    r"(\$?)([A-Z]{1,3})(\$?)([0-9]+)"
    r"(?::(\$?)([A-Z]{1,3})(\$?)([0-9]+))?"
    r"(?![A-Za-z0-9_(])")
NUM = re.compile(r"(?<![A-Za-z0-9_.\[\]$])(\d+(?:\.\d+)?%?)(?![A-Za-z0-9_\[\]])")
KEY_REF = re.compile(r"(?:'((?:[^']|'')+)'|([^!,']+))!(\$?[A-Z]{1,3}\$?\d+(?::\$?[A-Z]{1,3}\$?\d+)?)")
MONEY_WORDS = re.compile(r"amount|value|price|revenue|cost|cash|debt|balance|ebitda|proceeds|\$|total", re.I)
DATE_WORDS = re.compile(r"\bdate\b|as of|as at|maturity date|issue date", re.I)


def find_file():
    for root in ["/app", os.getcwd(), "/mnt/data", "/tmp"]:
        hits = [h for ext in ("xlsx", "xlsm")
                for h in glob.glob(os.path.join(root, "**", "*." + ext), recursive=True)]
        hits = [h for h in hits if not os.path.basename(h).startswith("~$") and "/created/" not in h]
        if hits:
            return sorted(hits)[0]
    raise FileNotFoundError("no .xlsx or .xlsm file found in sandbox")


def parse_refs(formula, cur_sheet):
    out = []
    for m in REF.finditer(STR_LIT.sub('""', formula)):
        sheet = m.group(1) or m.group(2)
        sheet = sheet.replace("''", "'") if sheet else cur_sheet
        c1, r1 = col_idx(m.group(4)), int(m.group(6))
        c2, r2 = (col_idx(m.group(8)), int(m.group(10))) if m.group(8) else (c1, r1)
        out.append((sheet, min(r1, r2), min(c1, c2), max(r1, r2), max(c1, c2)))
    return out


def rel_key(formula, row, col):
    def one(ca, c, ra, r):
        ci, ri = col_idx(c), int(r)
        return (f"R{ri}" if ra else f"R[{ri-row}]") + (f"C{ci}" if ca else f"C[{ci-col}]")

    def sub(m):
        s = m.group(1) or m.group(2) or ""
        s = s + "!" if s else ""
        s += one(m.group(3), m.group(4), m.group(5), m.group(6))
        if m.group(8):
            s += ":" + one(m.group(7), m.group(8), m.group(9), m.group(10))
        return s
    return REF.sub(sub, STR_LIT.sub('""', formula))


def hardcodes(formula):
    f = REF.sub("", STR_LIT.sub('""', formula))
    return sorted({n for n in NUM.findall(f) if n not in ("0", "1")})


def fmt(v):
    if v is None:
        return "(blank)"
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, datetime.datetime):
        return v.strftime("%Y-%m-%d") if v.time() == datetime.time(0) else v.isoformat(sep=" ")
    if isinstance(v, (int, float)):
        return f"{v:,.0f}" if abs(v) >= 1000 else f"{v:.4g}"
    s = str(v).replace("\n", " ").strip()
    return s[:40] + ("..." if len(s) > 40 else "")


def addr(r, c1, c2=None):
    a = f"{col_let(c1)}{r}"
    return a + (f":{col_let(c2)}{r}" if c2 and c2 != c1 else "")


def qs(sheet):
    return f"'{sheet}'" if re.search(r"[^A-Za-z0-9_]", sheet) else sheet


def main(path, out_dir, key_outputs_arg):
    wbf = load_workbook(path, data_only=False)
    wbv = load_workbook(path, data_only=True)
    sheetnames = wbf.sheetnames

    # ---------- collect cells ----------
    formulas, consts = {}, {}
    texts = defaultdict(dict)          # label lookup text (merged-cell aware)
    sheet_cells = defaultdict(list)
    for ws in wbf.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if v is None:
                    continue
                key = (ws.title, cell.row, cell.column)
                sheet_cells[ws.title].append((cell.row, cell.column))
                ftxt = str(getattr(v, "text", v))
                if cell.data_type == "f" or (isinstance(v, str) and v.startswith("=")):
                    formulas[key] = ftxt if ftxt.startswith("=") else "=" + ftxt
                else:
                    consts[key] = v
                    if isinstance(v, str) and v.strip():
                        texts[ws.title][(cell.row, cell.column)] = v.strip()
        for mr in ws.merged_cells.ranges:   # spread merged header text across its range
            t = texts[ws.title].get((mr.min_row, mr.min_col))
            if t:
                for rr in range(mr.min_row, mr.max_row + 1):
                    for cc in range(mr.min_col, mr.max_col + 1):
                        texts[ws.title].setdefault((rr, cc), t)

    # ---------- named ranges ----------
    items = []
    try:
        items = list(wbf.defined_names.items())
    except Exception:
        items = [(d.name, d) for d in getattr(wbf.defined_names, "definedName", [])]
    for ws in wbf.worksheets:
        try:
            items += [(n, d) for n, d in ws.defined_names.items()]
        except Exception:
            pass
    names = {}
    for n, d in items:
        try:
            dests = list(d.destinations)
        except Exception:
            dests = []
        names[n] = {"refers_to": getattr(d, "attr_text", "") or "", "dests": dests}
    name_re = None
    if names:
        name_re = re.compile(r"(?<![A-Za-z0-9_.])(" + "|".join(
            sorted(map(re.escape, names), key=len, reverse=True)) + r")(?![A-Za-z0-9_(])", re.I)
    lower_names = {n.lower(): n for n in names}
    used_names = set()

    # ---------- dependency graph ----------
    prec = defaultdict(set)            # formula cell -> cells it reads
    referenced = set()
    edges = defaultdict(int)
    external = set()

    def expand(rs, r1, c1, r2, c2):
        if (r2 - r1 + 1) * (c2 - c1 + 1) <= MAX_RANGE_CELLS:
            return [(rs, rr, cc) for rr in range(r1, r2 + 1) for cc in range(c1, c2 + 1)]
        return [(rs, rr, cc) for (rr, cc) in sheet_cells.get(rs, []) if r1 <= rr <= r2 and c1 <= cc <= c2]

    for key, f in formulas.items():
        s = key[0]
        if re.search(r"\[\d+\]", f) or ".xls" in f.lower():
            external.add(key)
        refs = list(parse_refs(f, s))
        if name_re:
            for m in name_re.finditer(STR_LIT.sub('""', f)):
                n = lower_names[m.group(1).lower()]
                used_names.add(n)
                for dsheet, coord in names[n]["dests"]:
                    try:
                        c1, r1, c2, r2 = range_boundaries(coord.replace("$", ""))
                        refs.append((dsheet, r1, c1, r2 or r1, c2 or c1))
                    except Exception:
                        pass
        for (rs, r1, c1, r2, c2) in refs:
            if rs != s:
                edges[(rs, s)] += 1
            cells = expand(rs, r1, c1, r2, c2)
            prec[key].update(cells)
            referenced.update(cells)

    for n, info in names.items():
        t = info["refers_to"]
        if n.lower().startswith("_xlnm.") or n.lower() in ("print_area", "print_titles"):
            cat = "print_or_builtin"
        elif "#REF" in t.upper():
            cat = "broken"
        elif re.search(r"\[\d+\]", t) or ".xls" in t.lower():
            cat = "external"
        elif n in used_names:
            cat = "referenced"
        else:
            cat = "unused"
        info["category"] = cat

    def val(k):
        return wbv[k[0]].cell(row=k[1], column=k[2]).value

    # ---------- outputs and materiality ----------
    output_cells = sorted(k for k in formulas if k not in referenced)
    key_outputs, key_errors = [], []
    if key_outputs_arg:
        for m in KEY_REF.finditer(key_outputs_arg):
            sh = (m.group(1) or m.group(2)).strip().replace("''", "'")
            if sh not in sheetnames:
                key_errors.append(f"unknown sheet in key outputs: {sh}")
                continue
            c1, r1, c2, r2 = range_boundaries(m.group(3).replace("$", ""))
            for rr in range(r1, (r2 or r1) + 1):
                for cc in range(c1, (c2 or c1) + 1):
                    if (sh, rr, cc) in formulas or (sh, rr, cc) in consts:
                        key_outputs.append((sh, rr, cc))
                    else:
                        key_errors.append(f"key output is an empty cell: {sh}!{addr(rr, cc)}")
    if key_errors:
        raise ValueError("; ".join(key_errors))

    def backward(starts):
        seen, q = set(starts), deque(starts)
        while q:
            k = q.popleft()
            for p in prec.get(k, ()):
                if p not in seen:
                    seen.add(p)
                    q.append(p)
        return seen

    targets = key_outputs or output_cells
    reach = backward(targets)
    feeds = defaultdict(set)
    if key_outputs:
        for ko in key_outputs[:50]:
            for k in backward([ko]):
                feeds[k].add(f"{ko[0]}!{addr(ko[1], ko[2])}")

    # ---------- labels / grouping ----------
    def label(s, r, c):
        t = texts.get(s, {})
        left = next((t[(r, cc)] for cc in range(c - 1, 0, -1) if (r, cc) in t), "")
        up = next((t[(rr, c)] for rr in range(r - 1, max(0, r - 40), -1) if (rr, c) in t), "")
        return (fmt(left) if left else "?"), (fmt(up) if up else "")

    def group_row(cells, keyfn):
        groups = []
        for (r, c) in sorted(cells):
            k = keyfn(r, c)
            g = groups[-1] if groups else None
            if g and g["r"] == r and g["c2"] == c - 1 and g["k"] == k:
                g["c2"] = c
                g["cells"].append((r, c))
            else:
                groups.append({"r": r, "c1": c, "c2": c, "k": k, "cells": [(r, c)]})
        return groups

    def type_flags(lbl, hdr, values):
        fl = []
        text = f"{lbl} {hdr}"
        if MONEY_WORDS.search(text) and any(isinstance(v, (datetime.date, datetime.datetime)) for v in values):
            fl.append("label_type_mismatch: money-like label but date value")
        if DATE_WORDS.search(lbl) and any(isinstance(v, (int, float)) and not isinstance(v, bool) for v in values):
            fl.append("label_type_mismatch: date-like label but numeric value")
        return fl

    skeleton, sheet_texts, sheet_summ = [], {}, []
    flags_all = defaultdict(list)       # category -> list of strings
    blocking = []
    for ws in wbf.worksheets:
        s = ws.title
        f_cells = [(r, c) for (ss, r, c) in formulas if ss == s]
        in_cells = [(r, c) for (ss, r, c) in consts if ss == s and (s, r, c) in referenced]
        unref_nums = sum(1 for (ss, r, c), v in consts.items()
                         if ss == s and isinstance(v, (int, float)) and (s, r, c) not in referenced)
        lines = []
        # inputs
        in_lines, mat_cells = [], 0
        for g in group_row(in_cells, lambda r, c: ((s, r, c) in reach)):
            keys = [(s, r, c) for (r, c) in g["cells"]]
            material = (s, g["r"], g["c1"]) in reach
            mat_cells += len(keys) if material else 0
            left, up1 = label(s, g["r"], g["c1"])
            up2 = label(s, g["r"], g["c2"])[1]
            hdr = up1 if up1 == up2 or not up2 else f"{up1}..{up2}"
            raw = [consts[k] for k in keys]
            vals = [fmt(v) for v in raw]
            rng = addr(g["r"], g["c1"], g["c2"])
            fl = type_flags(left, hdr, raw)
            fed = sorted(set().union(*[feeds.get(k, set()) for k in keys])) if key_outputs else []
            vtxt = ", ".join(vals[:6]) + (f", ... ({len(vals)} cells)" if len(vals) > 6 else "")
            line = (f"{rng} [input] {left}" + (f" | {hdr}" if hdr else "") + f" = {vtxt}"
                    + ("  MATERIAL" if material else "  not-material"))
            if fed:
                line += f"  feeds: {', '.join(fed[:5])}" + (f" +{len(fed) - 5}" if len(fed) > 5 else "")
            for x in fl:
                line += f"  FLAG:{x}"
                flags_all["label_type_mismatch"].append(f"{s}!{rng}")
            in_lines.append(line)
            skeleton.append({"id": f"{s}!{rng}", "sheet": s, "range": rng, "label": left, "header": hdr,
                             "n_cells": len(vals), "sample_values": vals[:6], "material": material,
                             "feeds_key_outputs": fed, "flags": fl,
                             "type": None, "expected_source": None, "changes_each_quarter": None,
                             "notes": None})
        # formulas
        f_lines, row_groups, n_out = [], defaultdict(list), 0
        for g in group_row(f_cells, lambda r, c: rel_key(formulas[(s, r, c)], r, c)):
            row_groups[g["r"]].append(g)
            r, c1 = g["r"], g["c1"]
            keys = [(s, rr, cc) for (rr, cc) in g["cells"]]
            is_out = not any(k in referenced for k in keys)
            is_key = any(k in key_outputs for k in keys)
            n_out += len(keys) if is_out else 0
            left, up1 = label(s, r, c1)
            up2 = label(s, r, g["c2"])[1]
            hdr = up1 if up1 == up2 or not up2 else f"{up1}..{up2}"
            vals = [val(k) for k in keys]
            vtxt = ", ".join(fmt(v) for v in vals[:3]) + (", ..." if len(vals) > 3 else "")
            n = len(keys)
            role = "KEY OUTPUT" if is_key else ("output" if is_out else "calc")
            rng = addr(r, c1, g["c2"])
            line = (f"{rng} [{role}] {left}" + (f" | {hdr}" if hdr else "")
                    + f" {formulas[keys[0]]}" + (f"  (same pattern x{n})" if n > 1 else "")
                    + f" -> {vtxt}")
            hc = hardcodes(formulas[keys[0]])
            if hc:
                line += f"  FLAG:hardcoded {','.join(hc)}"
                flags_all["hardcoded_in_formula"].append(f"{s}!{rng} ({','.join(hc)})")
            errs = [v for v in vals if isinstance(v, str) and v.startswith("#")]
            if errs:
                line += f"  FLAG:error {errs[0]}"
                flags_all["error"].append(f"{s}!{rng} {errs[0]}")
                if any(k in reach for k in keys):
                    blocking.append(f"error {errs[0]} in {s}!{rng} feeds "
                                    + ("key outputs" if key_outputs else "workbook outputs"))
            if any(k in external for k in keys):
                line += "  FLAG:external_link"
                flags_all["external_link"].append(f"{s}!{rng}")
                if any(k in reach for k in keys):
                    blocking.append(f"external workbook link in {s}!{rng} feeds "
                                    + ("key outputs" if key_outputs else "workbook outputs"))
            if all(v is None for v in vals):
                line += "  FLAG:no cached value"
                flags_all["no_cached_value"].append(f"{s}!{rng}")
            f_lines.append(line)
        for r, gs in row_groups.items():
            for i in range(1, len(gs) - 1):
                a, b, c_ = gs[i - 1], gs[i], gs[i + 1]
                if (a["k"] == c_["k"] and len(b["cells"]) == 1
                        and a["c2"] + 1 == b["c1"] and b["c2"] + 1 == c_["c1"]):
                    flags_all["pattern_break"].append(f"{s}!{addr(r, b['c1'])}")

        reads = sorted({a for (a, b) in edges if b == s})
        read_by = sorted({b for (a, b) in edges if a == s})
        header = (f"state: {ws.sheet_state} | used range: {ws.dimensions} | formulas: {len(f_cells)}"
                  f" | input cells: {len(in_cells)} (material: {mat_cells}) | output cells: {n_out}"
                  f" | unreferenced numbers: {unref_nums}")
        lines = [f"=== SHEET: {s} ===", header,
                 f"reads from: {', '.join(reads) or '-'} | read by: {', '.join(read_by) or '-'}",
                 "-- INPUTS --"] + (in_lines or ["(none)"]) + ["-- FORMULAS --"] + (f_lines or ["(none)"]) + \
                ["=== END OF SHEET ==="]
        sheet_texts[s] = "\n".join(lines)
        sheet_summ.append((s, ws.sheet_state, len(f_cells), len(in_cells), mat_cells, n_out))

    # ---------- write files ----------
    os.makedirs(out_dir, exist_ok=True)
    stem = re.sub(r"[^A-Za-z0-9_-]+", "_", os.path.splitext(os.path.basename(path))[0])
    sdir = os.path.join(out_dir, f"{stem}_sheets")
    os.makedirs(sdir, exist_ok=True)
    sheet_files = {}
    for i, s in enumerate(sheetnames, 1):
        fn = os.path.join(sdir, f"{i:02d}_{re.sub(r'[^A-Za-z0-9_-]+', '_', s)}.md")
        with open(fn, "w", encoding="utf-8") as fh:
            fh.write(sheet_texts[s])
        sheet_files[s] = fn
    out_lines = [f"{qs(k[0])}!{addr(k[1], k[2])} = {fmt(val(k))}  {label(k[0], k[1], k[2])[0]}"
                 for k in output_cells]
    outputs_file = os.path.join(out_dir, f"{stem}_outputs.md")
    with open(outputs_file, "w", encoding="utf-8") as fh:
        fh.write("=== ALL OUTPUT CELLS (formulas nothing else uses) ===\n" + "\n".join(out_lines or ["(none)"]))

    n_blocks = len(skeleton)
    n_cells = sum(e["n_cells"] for e in skeleton)
    m_blocks = sum(1 for e in skeleton if e["material"])
    m_cells = sum(e["n_cells"] for e in skeleton if e["material"])
    basis = "confirmed key outputs" if key_outputs else "ALL output cells (key outputs NOT set)"

    def capped(xs):
        return xs[:OVERVIEW_LIST_CAP] + ([f"... {len(xs) - OVERVIEW_LIST_CAP} more in the files"]
                                         if len(xs) > OVERVIEW_LIST_CAP else [])

    ov = ["=== WORKBOOK OVERVIEW ===",
          f"file: {os.path.basename(path)} | sheets: {len(sheetnames)} | formula cells: {len(formulas)}",
          f"input blocks: {n_blocks} | input cells: {n_cells} | material blocks: {m_blocks}"
          f" | material cells: {m_cells} | output cells: {len(output_cells)}",
          f"materiality basis: {basis}",
          "legend: [input]=hardcoded value a formula uses; [calc]=formula other formulas use; "
          "[output]=formula nothing uses; MATERIAL=input that feeds the materiality basis; "
          "values after -> are Excel's last saved results; labels are guesses from nearby text",
          "completeness: every sheet file is complete and untruncated; overview lists may be capped",
          "", "=== SHEETS (read the file for each sheet with material inputs) ==="]
    for (s, st, nf, ni, nm, no) in sheet_summ:
        ov.append(f"{s}{' (' + st + ')' if st != 'visible' else ''}: formulas {nf}, input cells {ni}"
                  f" (material {nm}), outputs {no} -> {sheet_files[s]}")
    ov += ["", "=== SHEET FLOW (source -> uses it: reference count) ==="]
    ov += [f"{a} -> {b}: {n}" for (a, b), n in sorted(edges.items(), key=lambda x: -x[1])] or ["(none)"]
    ov += ["", "=== NAMED RANGES (category: name = refers to) ==="]
    ov += capped([f"{i['category']}: {n} = {i['refers_to']}" for n, i in sorted(
        names.items(), key=lambda x: (x[1]["category"], x[0]))]) or ["(none)"]
    ov += ["", f"=== KEY OUTPUTS ==="]
    ov += ([f"{k[0]}!{addr(k[1], k[2])} = {fmt(val(k))}  {label(k[0], k[1], k[2])[0]}" for k in key_outputs]
           or [f"NOT SET. Candidates: see {outputs_file} ({len(output_cells)} output cells)."])
    ov += ["", "=== BLOCKING ISSUES (errors or external links that feed the materiality basis) ==="]
    ov += capped(sorted(set(blocking))) or ["(none)"]
    ov += ["", "=== FLAG COUNTS (full detail in sheet files) ==="]
    ov += [f"{k}: {len(v)} (e.g. {', '.join(v[:5])})" for k, v in sorted(flags_all.items())] or ["(none)"]
    ov += ["", "=== END OF OVERVIEW ==="]
    overview = "\n".join(ov)

    schema_path = os.path.join(out_dir, f"{stem}_schema.md")
    with open(schema_path, "w", encoding="utf-8") as fh:
        fh.write(overview + "\n\n" + "\n\n".join(sheet_texts[s] for s in sheetnames)
                 + "\n\n" + open(outputs_file, encoding="utf-8").read())
    skel_path = os.path.join(out_dir, f"{stem}_inputs_skeleton.json")
    with open(skel_path, "w", encoding="utf-8") as fh:
        json.dump({"workbook": os.path.basename(path), "generated_by": "extract_schema.py v2",
                   "key_outputs": [f"{k[0]}!{addr(k[1], k[2])}" for k in key_outputs],
                   "materiality_basis": basis,
                   "totals": {"blocks": n_blocks, "cells": n_cells,
                              "material_blocks": m_blocks, "material_cells": m_cells},
                   "named_ranges": [{"name": n, "refers_to": i["refers_to"], "category": i["category"]}
                                    for n, i in sorted(names.items())],
                   "blocking_issues": sorted(set(blocking)),
                   "inputs": skeleton}, fh, indent=1, default=str)
    print(overview)
    print(f"\nFILES WRITTEN:\n{schema_path}\n{skel_path}\n{outputs_file}\n{sdir}/ ({len(sheetnames)} sheet files)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("workbook", nargs="?", help="path to .xlsx/.xlsm (searched for if omitted)")
    ap.add_argument("--out", default="/app/created" if os.path.isdir("/app") else os.getcwd())
    ap.add_argument("--key-outputs", default="", help="comma-separated Sheet!A1 refs confirmed by the user")
    a = ap.parse_args()
    try:
        main(a.workbook or find_file(), a.out, a.key_outputs)
    except Exception as e:
        print(f"EXTRACTION_ERROR: {type(e).__name__}: {e}")
        raise SystemExit(1)
