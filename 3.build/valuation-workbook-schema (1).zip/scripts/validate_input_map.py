# validate_input_map.py - gates an agent-written input map against the extractor's skeleton (v2)
# Usage: python validate_input_map.py <stem>_inputs_skeleton.json <stem>_input_map.json
# Prints one STATUS line first:
#   STATUS: INVALID          shape errors; fix and re-run            (exit 1)
#   STATUS: REVIEW_REQUIRED  shape OK, but not ready                 (exit 3)
#   STATUS: COMPLETE         every gate passed                       (exit 0)
# COMPLETE means the map is complete and reviewed. It does NOT mean the workbook can be
# regenerated correctly; that needs the replay test.
import json, sys

TYPES = {"financial_statement", "assumption", "prior_period", "constant",
         "carry_forward_event_driven", "reference_data", "not_material", "uncertain"}
CHANGES = {"yes", "no", "on_event", "uncertain"}
FILL = {"type", "expected_source", "changes_each_quarter", "notes"}
LOCKED = ("sheet", "range", "label", "header", "n_cells", "sample_values",
          "material", "feeds_key_outputs", "flags")


def main(skel_path, map_path):
    skel = json.load(open(skel_path, encoding="utf-8"))
    try:
        m = json.load(open(map_path, encoding="utf-8"))
    except json.JSONDecodeError as e:
        print(f"STATUS: INVALID\n- input map is not valid JSON: {e}")
        return 1
    sk = {e["id"]: e for e in skel["inputs"]}
    errs, seen = [], {}
    for i, e in enumerate(m.get("inputs", [])):
        if not isinstance(e, dict) or "id" not in e:
            errs.append(f"entry {i}: must be an object with an id")
            continue
        eid = e["id"]
        if eid not in sk:
            errs.append(f"{eid}: not in the skeleton (do not invent, rename, split or merge ids)")
            continue
        if eid in seen:
            errs.append(f"{eid}: duplicate entry")
        seen[eid] = e
        extra = set(e) - FILL - set(LOCKED) - {"id"}
        if extra:
            errs.append(f"{eid}: unknown fields {sorted(extra)}")
        for f in LOCKED:
            if e.get(f) != sk[eid].get(f):
                errs.append(f"{eid}: '{f}' was changed; copy it from the skeleton unchanged")
        t, ch = e.get("type"), e.get("changes_each_quarter")
        if t not in TYPES:
            errs.append(f"{eid}: type must be one of {sorted(TYPES)}")
        elif t == "not_material":
            if sk[eid]["material"]:
                errs.append(f"{eid}: marked not_material but it feeds the materiality basis")
        else:
            if ch not in CHANGES:
                errs.append(f"{eid}: changes_each_quarter must be one of {sorted(CHANGES)}")
            if t == "carry_forward_event_driven" and ch not in ("on_event", "uncertain"):
                errs.append(f"{eid}: carry_forward_event_driven needs changes_each_quarter 'on_event'")
            if t == "financial_statement" and not e.get("expected_source"):
                errs.append(f"{eid}: financial_statement needs expected_source (statement and line item)")
            if sk[eid]["material"] and not e.get("notes"):
                errs.append(f"{eid}: material input needs notes citing the cells that justify its type")
    missing = [eid for eid in sk if eid not in seen]
    for eid in missing:
        errs.append(f"{eid}: missing from the input map (every block needs a disposition)")

    tot = skel["totals"]
    got_blocks = len(seen)
    got_cells = sum(sk[eid]["n_cells"] for eid in seen)
    recon = (f"reconciliation: blocks {got_blocks}/{tot['blocks']}, cells {got_cells}/{tot['cells']}"
             f" (material cells {tot['material_cells']})")
    if errs:
        print("STATUS: INVALID")
        print(recon)
        print("\n".join(f"- {x}" for x in errs[:100]))
        if len(errs) > 100:
            print(f"- ... {len(errs) - 100} more")
        return 1

    unresolved = [eid for eid, e in seen.items()
                  if e["type"] == "uncertain" or e.get("changes_each_quarter") == "uncertain"]
    unresolved_mat = [eid for eid in unresolved if sk[eid]["material"]]
    flagged = [f"{eid}: {x}" for eid in seen for x in sk[eid]["flags"]]
    blocking = skel.get("blocking_issues", [])
    broken_names = [n["name"] for n in skel.get("named_ranges", []) if n["category"] in ("broken", "external")]
    gates = {
        "key outputs confirmed": bool(skel.get("key_outputs")),
        "no unresolved entries": not unresolved,
        "no blocking issues": not blocking,
        "no label/type mismatches left unexplained": all(seen[f.split(': ')[0]].get("notes") for f in flagged),
    }
    status = "COMPLETE" if all(gates.values()) else "REVIEW_REQUIRED"
    counts = {t: sum(1 for e in seen.values() if e["type"] == t) for t in sorted(TYPES)}
    print(f"STATUS: {status}")
    print(recon)
    for g, ok in gates.items():
        print(f"gate {'PASS' if ok else 'FAIL'}: {g}")
    print("types: " + ", ".join(f"{k}={v}" for k, v in counts.items() if v))
    print(f"unresolved: {len(unresolved)} (material: {len(unresolved_mat)})"
          + (": " + ", ".join(unresolved[:60]) + (" ..." if len(unresolved) > 60 else "") if unresolved else ""))
    print(f"blocking issues: {len(blocking)}" + ("".join(f"\n- {b}" for b in blocking[:30])))
    print(f"label/type flags: {len(flagged)}" + ("".join(f"\n- {f}" for f in flagged[:30])))
    print(f"broken or external named ranges: {len(broken_names)}"
          + (": " + ", ".join(broken_names[:30]) if broken_names else ""))
    print("note: COMPLETE means the map is complete and reviewed, not that regeneration is proven.")
    return 0 if status == "COMPLETE" else 3


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("usage: python validate_input_map.py <skeleton.json> <input_map.json>")
        sys.exit(2)
    sys.exit(main(sys.argv[1], sys.argv[2]))
