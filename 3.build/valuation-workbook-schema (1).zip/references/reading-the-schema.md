# Reading the schema

## Files
- OVERVIEW (printed): counts, sheet list with file paths, flow, named ranges, key outputs,
  blocking issues, flag counts. Lists here may be capped.
- `<stem>_sheets/NN_<sheet>.md`: complete per-sheet detail. Never truncated.
- `<stem>_outputs.md`: every output cell. `<stem>_schema.md`: everything in one file.

## Line format
`<range> [<role>] <row label> | <column header> <formula or = values> -> <saved values>  MARKERS`
- `[input]` hardcoded value used by at least one formula. Decided by Python; trust it.
- `[calc]` formula used by other formulas. `[output]` formula nothing uses.
  `[KEY OUTPUT]` a user-confirmed key output.
- `MATERIAL` the input feeds a key output (or, before key outputs are set, any output).
  `feeds:` lists which key outputs.
- `same pattern xN` one formula copied across N cells; the first cell's formula is shown.
- `-> values` are Excel's last saved results. `FLAG:no cached value` = never recalculated.
- Labels come from the nearest text left and above (merged headers are spread across their
  range). They can still be wrong.

## Flags
- `FLAG:hardcoded` numbers typed inside a formula (includes year exponents like `^3`).
- `FLAG:error`, `FLAG:external_link`: blocking when they feed a key output.
- `FLAG:label_type_mismatch`: the label suggests one kind of value but the cell holds another
  (e.g. "Amount" over a date). Usually a wrong header pairing. Your note must address it.
- `pattern_break`: a single cell whose formula differs from both neighbours in its row.

## Named range categories
`referenced` used by formulas; `unused`; `broken` (#REF); `external` (points to another file);
`print_or_builtin`.

## Input map fields (the only fields you fill)
- `type`:
  - `financial_statement` comes from the company's statements each period
  - `assumption` judgement input (discount rate, multiple, growth, weighting, discount %)
  - `prior_period` carried from the previous valuation (e.g. last quarter's value)
  - `constant` fixed by definition (unit factors, fixed contractual rates)
  - `carry_forward_event_driven` carries forward unless an event changes it (cap-table
    holdings, share counts, option grants, instrument terms). Needs `changes_each_quarter: on_event`.
  - `reference_data` external market data blocks (comparables, FX tables)
  - `not_material` allowed only when `"material": false`
  - `uncertain` you cannot tell from the schema
- `expected_source`: where the value should come from each quarter, in plain words
  (e.g. `Balance sheet: Cash and cash equivalents`). Required for `financial_statement`.
- `changes_each_quarter`: `yes`, `no`, `on_event`, `uncertain`.
- `notes`: required for material entries; cite cells. One or two sentences.
