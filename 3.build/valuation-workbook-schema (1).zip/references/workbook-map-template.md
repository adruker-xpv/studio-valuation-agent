# Workbook Map template (use exactly these sections; under 800 words)

## Workbook Map: <file name>
**Status.** Validator STATUS line and reconciliation line, quoted exactly (or "not yet
validated" before step 7).

**1. Purpose.** 1-2 sentences, citing the key output cells.

**2. Sheets**
| Sheet | Role | What it does | Evidence |
Role is one of: Inputs/Assumptions, Source financials, Calculation, Output/Summary, Other,
UNCERTAIN. Mark hidden sheets.

**3. Calculation flow.** One line, from SHEET FLOW only.

**4. Valuation method(s).** Only methods whose formulas are visible; cite cells. Else UNCERTAIN.

**5. Key outputs**
| Output | Cell | Last saved value |

**6. Material inputs** (summarise by concept, not cell by cell)
| Concept | Cells | Type | Count of blocks |

**7. Blocking issues and flags.** Blocking issues first, then flag counts with examples,
then broken/external named ranges.

**8. Open questions.** At most 5, each referencing a cell.
