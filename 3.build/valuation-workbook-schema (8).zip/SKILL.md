---
name: valuation-workbook-schema
description: Automatically maps an uploaded Excel valuation workbook end to end - extracts sheets, inputs, formulas, outputs and dependencies with bundled Python scripts, selects key outputs, traces which inputs feed them, classifies those inputs, validates the input map, and writes a run report listing every decision for analyst review. Use when the user uploads a valuation or financial model workbook and asks what it contains, what inputs it needs, or to prepare it for quarterly updates.
---

# Valuation workbook schema (autonomous)

Run the whole workflow without stopping to ask questions. Make the judgment calls yourself,
record each one in a decision file, and let the scripts do everything deterministic. Everything
you decide is a proposal; the run report lists it for the analyst at the end.

## Division of labour
| Step | Who | Does what | Writes |
|---|---|---|---|
| P1 | Python | discovery extraction, candidate outputs ranked by upstream inputs | schema, skeleton |
| J1 | You | choose key outputs and define controls (references/key-output-rules.md) | key_outputs.json |
| P2 | Python | final extraction, materiality, dependency paths, blocking issues | schema, skeleton |
| J2 | You | classify every MATERIAL input block (references/classification-rules.md) | classifications.json |
| P3 | Python | merge (non-material set automatically), validate | input_map.json, STATUS |
| P4 | Python | run report: status, controls, gates, every decision, open items; run manifest | run_report.md, run_manifest |
| J3 | You | Workbook Map prose (references/workbook-map-template.md) | chat only |
| P5 | Tool | save files | SharePoint or downloads |

Every script ends with a `NEXT REQUIRED STEP` line. Do exactly that next.

## Steps
Use `<stem>` = workbook file name without extension, as printed by the scripts. All files go
in `/app/created`.

**Reuse:** if the user uploaded a saved `<stem>_input_map.json`, skip J1 and J2: pass it as
`--key-outputs-file` in P2 and as the classifications file in P3.

1. **P1** `python scripts/extract_schema.py "<workbook>" --out /app/created`
   On `EXTRACTION_ERROR`: report that line and stop (the only reason to stop early).
2. **J1** Read the OVERVIEW and the OUTPUTS BY SHEET section (line range in the INDEX). Write
   `/app/created/key_outputs.json` following `references/key-output-rules.md`.
3. **P2** `python scripts/extract_schema.py "<workbook>" --out /app/created --key-outputs-file /app/created/key_outputs.json`
   If it errors on a key output cell, fix key_outputs.json and re-run (max 3 attempts).
4. **J2** Read, from `<stem>_schema.md`, every sheet section in the INDEX with material input cells,
   through its `=== END OF SHEET ===` line. Then write `/app/created/classifications.json` with one
   entry per MATERIAL block, following `references/classification-rules.md`. Skip non-material
   blocks; P3 handles them.
5. **P3** `python scripts/apply_classifications.py /app/created/<stem>_inputs_skeleton.json /app/created/classifications.json --out /app/created/<stem>_input_map.json`
   then `python scripts/validate_input_map.py /app/created/<stem>_inputs_skeleton.json /app/created/<stem>_input_map.json`
   On problems or `STATUS: INVALID`: fix classifications.json and repeat P3 (max 3 attempts).
   `REVIEW_REQUIRED` is a normal outcome: do not ask the user, continue.
6. **P4** `python scripts/build_report.py /app/created/<stem>_inputs_skeleton.json /app/created/<stem>_input_map.json --out /app/created/<stem>_run_report.md`
   then `python scripts/write_manifest.py --skill valuation-workbook-schema --inputs "<workbook>" /app/created/key_outputs.json /app/created/classifications.json [scope.json] --outputs /app/created/<stem>_schema.md /app/created/<stem>_input_map.json /app/created/<stem>_run_report.md --parent-run-id <run_id of a reused input map's run, if known> --out "/app/created/<stem>_run_manifest_{run_id}.json"`
   `BLOCKED` (a blocking control fails, or an error/external link feeds a key output) is a normal
   outcome: continue to the report, do not ask the user.
7. **J3** Write the Workbook Map (template) for the final summary.
8. **P5** Save `<stem>_schema.md`, `<stem>_input_map.json`, `<stem>_run_report.md` and the run manifest. With a
   SharePoint/OneDrive Create file tool, pass the sandbox path as the file content. Without one,
   return them as downloads. (The input map holds the key outputs and classifications, so it is
   all that is needed to reuse this run.)
9. **Final summary** (only now), in this order:
   1. First line exactly as build_report.py prints it: `Structure initialization: technical status <X>; business review <Y>.`
   2. The reconciliation line.
   3. The Workbook Map (short).
   4. The report's "Needs analyst input" table unchanged, plus its cadence and scope lines.
   5. Controls that did not pass, one line each.
   6. Where the files were saved, the run_id, and one line on how to correct or confirm.
   Never say analyst input is "none", or that passing gates means the mapping is correct.

## Corrections (when the user replies to a finished run)
- Key output changes: edit key_outputs.json, then repeat from P2.
- Classification changes: write only the changed ids to classifications.json and run
  `apply_classifications.py <skeleton> <current input_map.json> classifications.json --out <input_map.json>`,
  then validate and report (P3-P4).
- Record the user's words in the entry's notes (e.g. "analyst: management adjustment factor"),
  set confidence to high, set `reviewed_by` to the name the user gave, and re-run through P4.
- Confirmations ("confirm all financial_statement blocks - reviewed by <name>"): set `reviewed_by`
  on exactly the blocks named, change nothing else, re-run from P3.
- Reporting scope ("Reporting scope: LP Report yes, Comp Detail no - reviewed by <name>"): write
  `/app/created/scope.json` = `{"reviewed_by": "<name>", "sheets": {"LP Report": "yes"}, "blocks": {}}`
  and re-run P3 with `--scope /app/created/scope.json`, passing the current input map as the
  classifications file. Never set scope without the user's explicit instruction and name.
- Control changes ("Control X: boolean, expected TRUE, blocking"): update key_outputs.json and
  repeat from P2. Never change a control's expected value to make it pass.
- Valuation scope changes ("add these key outputs"): edit key_outputs.json and repeat from P2; keep existing
  classifications with `apply_classifications.py <skeleton> <previous input_map.json> classifications.json --out ...`,
  where classifications.json holds only the newly material blocks it reports as missing.

## Rules
- Do not ask the user questions during a run. Unclear items are `uncertain` or `low` confidence
  and go in the report.
- Use only script output. Cite a cell or range for every factual statement about the workbook.
- Never calculate, estimate, or re-derive a number. Show values exactly as the scripts print them:
  no added currency symbols, units (k, $, %), or conversions (0.15 stays 0.15).
- Never dismiss content as junk or unimportant; every block gets a disposition.
- An unlabeled input stays unlabeled and `uncertain`; do not borrow a label from a nearby formula.
- `expected_source` describes where a value should come from; never write it as if you saw it.
- No claims from general knowledge (e.g. "changes with market conditions"); cite cells instead.
- Do not suggest fixes to the model, including for flagged errors.
- Do not modify, import, or debug the scripts. Do not write your own code to read the workbook.
- Do not narrate progress or list every scan in your messages.
- Never claim what broken named ranges do or do not affect; report the counts the script gives.
