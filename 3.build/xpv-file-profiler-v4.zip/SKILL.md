---
name: xpv-file-profiler
description: >-
  Profile one Excel workbook (.xlsx, .xlsm) received as valuation evidence: inventory every sheet
  including hidden and very hidden ones, record labels, periods, formulas and number formats, and
  produce an evidence-cited profile (file role, status, family, company, period end, currencies,
  units, sheet types, headline valuation cells). Use when a new file needs profiling or the File
  Register asks for a profile. Do not use to deduplicate files, update the register, build or
  change valuation schemas, assess confidence, or calculate valuations.
---
# XPV File Profiler

Produce a profile of one workbook in which facts come from code and judgments come with citations. The scripts read the file and write every output file. You decide what the observations mean, in a small interpretation file, and the builder checks each claim against the workbook before anything is saved.

Paths below are relative to this skill's folder, the one containing this SKILL.md. Use one working folder per file, shown here as `<work>`.

## Workflow

1. **Observe.** Run:
   `python scripts/profile_workbook.py --input <file> --output <work>/observations.json`
   Read the one-line result it prints. If `profile_status` is `processing_error`, skip to step 5 and build without an interpretation. Do not try to open the file another way.

2. **Read.** Open `<work>/observations.json`. For each sheet, look at `candidate_types`, `representative_labels`, `date_like_headers`, `number_formats`, and `truncated`. Also read `identity/filename_analysis` and `observations/workbook`.

3. **Drill down only where evidence is missing.** Run:
   `python scripts/inspect_region.py --input <file> --supplements <work>/supplements.json --reason "<why>" --region "<Sheet>!<A1:H30>" [--region ...]`
   Headline valuation values are never in the overview, so for a valuation workbook you will almost always drill around the output labels. Batch regions into one call, keep each region small, and use at most four calls per file. See section 5 of the guide.

4. **Interpret.** Read `references/interpretation-guide.md`, copy `templates/interpretation.template.json` to `<work>/interpretation.json`, and fill it in:
   - Every non-null value cites JSON pointers into the observations.
   - Do not type cell values; the builder copies them from the workbook.
   - Anything unsupported stays null. An honest null with a question is a better profile than a plausible guess.

   This file is small on purpose. Never write or copy the observations into it.

5. **Build.** Run:
   `python scripts/build_profile.py --observations <work>/observations.json --interpretation <work>/interpretation.json --supplements <work>/supplements.json --output <work>/profile.json --summary <work>/profile-summary.md`
   - Omit `--interpretation` for a processing error.
   - Omit `--supplements` if you never drilled down.

6. **If `build_status` is `invalid`**, the printed errors say exactly which field or pointer failed. Correct only `interpretation.json`, or run one more drill-down if an error asks for it, then rebuild. Try this at most twice. If the build is still invalid, stop and report `interpretation_invalid` with the errors.

7. **Return** `profile.json` and `profile-summary.md` to the calling agent so it can save them through the configured OneDrive tool; the sandbox does not keep files. In chat, show the summary's key lines and the open questions, not the JSON.

## Rules

- Use only the bundled scripts. Do not write, modify, or debug code during a run, even when a script reports an error. A script error is a result to report, not a problem to fix, because improvised code is what made earlier runs unreliable.
- Never edit `observations.json`, `supplements.json`, or `profile.json` by hand. The builder is the only writer of the final profile.
- Never guess acronyms, entity relationships, methodology, approval status, formula meaning, dates, currencies, units, or locations.
- Do not alter the source workbook, deduplicate, update registers, create schemas, calculate confidence, or calculate valuations.

`references/sheet-classification.md` explains how the script's type suggestions are scored.
