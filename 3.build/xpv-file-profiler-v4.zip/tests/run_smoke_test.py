#!/usr/bin/env python3
"""Smoke test for the xpv-file-profiler package.

Builds a small synthetic workbook, runs the whole pipeline, and checks that
the builder accepts good interpretations and rejects bad ones. Run it once
in the Copilot Studio sandbox after upload:

    python tests/run_smoke_test.py

Prints a JSON report with "passed": true/false. Always exits 0.
"""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
S = ROOT / "scripts"


def run(script, *args):
    p = subprocess.run([sys.executable, str(S / script), *map(str, args)], capture_output=True, text=True)
    try:
        return json.loads(p.stdout)
    except json.JSONDecodeError:
        return {"unparseable_stdout": p.stdout[-2000:], "stderr": p.stderr[-2000:], "returncode": p.returncode}


def make_workbook(path: Path):
    from openpyxl import Workbook
    from openpyxl.chart import BarChart, Reference
    from openpyxl.workbook.defined_name import DefinedName

    wb = Workbook()
    cover = wb.active
    cover.title = "Cover"
    cover["A1"] = "Acme Water Ltd."
    cover["A2"] = "Quarterly valuation - DRAFT"
    cover.merge_cells("A1:D1")

    pl = wb.create_sheet("P&L")
    pl["A1"] = "Income Statement (CAD $000s)"
    months = ["Jan 2026", "Feb 2026", "Mar 2026"]
    for i, m in enumerate(months):
        pl.cell(row=2, column=2 + i, value=m)
        pl.cell(row=3, column=2 + i, value="Actual")
    pl["A4"], pl["A5"], pl["A6"] = "Revenue", "Operating expenses", "EBITDA"
    for col in "BCD":
        pl[f"{col}4"] = 1000
        pl[f"{col}5"] = 600
        pl[f"{col}6"] = f"={col}4-{col}5"
        for r in (4, 5, 6):
            pl[f"{col}{r}"].number_format = '#,##0,'

    val = wb.create_sheet("Valuation Summary")
    val["A1"] = "Valuation summary"
    val["A3"], val["C3"] = "LTM EBITDA", "=SUM('P&L'!B6:D6)*4"
    val["A4"], val["C4"] = "EV/EBITDA multiple", 12.5
    val["A5"], val["C5"] = "Enterprise Value", "=C3*C4"
    val["C5"].number_format = '"$"#,##0'

    wb.create_sheet("Sep 2026")["A1"] = "Monthly package"
    calc = wb.create_sheet("Calc")
    calc["A1"] = "Workings"
    calc.sheet_state = "hidden"
    hidden = wb.create_sheet("Lookups")
    hidden["A1"] = "codes"
    hidden.sheet_state = "veryHidden"

    chart = BarChart()
    chart.add_data(Reference(pl, min_col=2, min_row=4, max_col=4, max_row=4))
    wb.create_chartsheet("Chart1").add_chart(chart)

    dn = DefinedName("EV", attr_text="'Valuation Summary'!$C$5")
    try:
        wb.defined_names["EV"] = dn          # openpyxl >= 3.1
    except TypeError:
        wb.defined_names.append(dn)          # openpyxl 3.0
    wb.save(path)


def idx(items, pred):
    return next(i for i, x in enumerate(items) if pred(x))


def main():
    checks = []

    def check(name, ok, detail=None):
        checks.append({"check": name, "ok": bool(ok), "detail": None if ok else detail})

    with tempfile.TemporaryDirectory() as d:
        d = Path(d)
        wbp = d / "Acme Valuation Q3 2026 v2 DRAFT (1).xlsx"
        make_workbook(wbp)

        r = run("profile_workbook.py", "--input", wbp, "--output", d / "observations.json")
        check("profile completed", r.get("profile_status") == "completed", r)
        obs = json.loads((d / "observations.json").read_text())
        sheets = obs["observations"]["sheets"]
        by = {s["observed_name"]: s for s in sheets}
        check("all 7 sheets found incl. chartsheet", len(sheets) == 7, [s["observed_name"] for s in sheets])
        check("hidden + veryHidden recorded",
              by["Calc"]["visibility"] == "hidden" and by["Lookups"]["visibility"] == "veryHidden")
        check("chartsheet recorded", by["Chart1"]["sheet_kind"] == "chartsheet")
        check("sheet name pattern", by["Sep 2026"]["normalized_name_pattern"] == "{Mon} {YYYY}",
              by["Sep 2026"]["normalized_name_pattern"])
        check("P&L candidate is income_statement",
              by["P&L"]["candidate_types"][:1] and by["P&L"]["candidate_types"][0]["type"] == "income_statement",
              by["P&L"]["candidate_types"])
        fa = obs["identity"]["filename_analysis"]
        check("filename family candidate", fa["family_candidate"] == "acme valuation", fa)
        check("upload suffix stripped", fa["upload_suffix"] == "(1)", fa)
        check("defined name read", any(n["name"] == "EV" for n in obs["observations"]["workbook"]["defined_names"]))
        check("thousands number format observed",
              any(f["format"] == "#,##0," for f in by["P&L"]["number_formats"]), by["P&L"]["number_formats"])

        r = run("inspect_region.py", "--input", wbp, "--supplements", d / "supplements.json",
                "--reason", "find EV", "--region", "Valuation Summary!A1:D6", "--region", "Nope!A1:B2")
        check("drill-down added one region", len(r.get("added", [])) == 1, r)
        check("bad region reported, not crashed", len(r.get("region_errors", [])) == 1, r)
        sup = json.loads((d / "supplements.json").read_text())
        cells = sup["supplements"][0]["cells"]

        vpos = by["Valuation Summary"]["position"]
        cpos = by["Cover"]["position"]
        ppos = by["P&L"]["position"]
        cover_labels = by["Cover"]["representative_labels"]
        pl_labels = by["P&L"]["representative_labels"]
        good = json.loads((ROOT / "templates" / "interpretation.template.json").read_text())
        good["file_role"] = {"value": "valuation_workbook",
                             "evidence": [f"/observations/sheets/{vpos}/observed_name"]}
        good["status"] = {"value": "draft", "evidence": ["/identity/filename_analysis/status_tokens/0"]}
        good["family"] = {"value": "acme valuation", "evidence": ["/identity/filename_analysis/family_candidate"]}
        good["company_name_in_file"] = {"value": "Acme Water Ltd.", "evidence": [
            f"/observations/sheets/{cpos}/representative_labels/{idx(cover_labels, lambda x: x['text'] == 'Acme Water Ltd.')}"]}
        cad = f"/observations/sheets/{ppos}/representative_labels/{idx(pl_labels, lambda x: 'CAD' in x['text'])}"
        good["currencies"] = [{"value": "CAD", "evidence": [cad]}]
        good["units"] = [{"value": "thousands", "evidence": [cad]}]
        good["sheets"] = [{"observed_name": "P&L", "type": "income_statement", "purpose_observed": "Monthly P&L",
                           "evidence": []},
                          {"observed_name": "Cover", "type": "notes", "purpose_observed": "Title page",
                           "evidence": [f"/observations/sheets/{cpos}/representative_labels/0"]}]
        ev_label = idx(cells, lambda c: c["value"] == "Enterprise Value")
        good["valuation_outputs"] = [{"label": "enterprise_value", "label_text": "Enterprise Value",
                                      "sheet": "Valuation Summary", "cell": "C5",
                                      "evidence": [f"/observations/supplements/0/cells/{ev_label}"]}]
        (d / "good.json").write_text(json.dumps(good))
        r = run("build_profile.py", "--observations", d / "observations.json", "--interpretation", d / "good.json",
                "--supplements", d / "supplements.json", "--output", d / "profile.json",
                "--summary", d / "profile-summary.md")
        check("good interpretation builds", r.get("build_status") == "valid", r)
        if r.get("build_status") == "valid":
            prof = json.loads((d / "profile.json").read_text())
            vo = prof["interpretation"]["valuation_outputs"][0]
            check("EV formula copied from workbook", vo["observed_formula"] == "=C3*C4", vo)
            check("unresolved fields became questions",
                  any(q["field"] == "period_end" and q["source"] == "builder" for q in prof["open_questions"]))
            psheet = next(s for s in prof["interpretation"]["sheets"] if s["observed_name"] == "P&L")
            check("confirmed candidate gets auto evidence",
                  psheet["decided_by"] == "agent_confirmed_candidate" and psheet["evidence"], psheet)

        def expect_invalid(name, mutate):
            bad = json.loads(json.dumps(good))
            mutate(bad)
            (d / "bad.json").write_text(json.dumps(bad))
            rr = run("build_profile.py", "--observations", d / "observations.json", "--interpretation",
                     d / "bad.json", "--supplements", d / "supplements.json", "--output", d / "bad-profile.json",
                     "--summary", d / "bad-summary.md")
            check(name, rr.get("build_status") == "invalid", rr)

        expect_invalid("rejects pointer that does not exist",
                       lambda b: b["family"].update(evidence=["/observations/sheets/99/observed_name"]))
        expect_invalid("rejects company name from filename only",
                       lambda b: b["company_name_in_file"].update(evidence=["/identity/file_name"]))
        expect_invalid("rejects value with no evidence",
                       lambda b: b["period_end"].update(value="2026-09-30", evidence=[]))
        expect_invalid("rejects valuation cell not observed",
                       lambda b: b["valuation_outputs"][0].update(cell="Z99"))
        expect_invalid("rejects unknown sheet name",
                       lambda b: b["sheets"].append({"observed_name": "PnL", "type": "other", "evidence": []}))
        expect_invalid("rejects impossible date",
                       lambda b: b["period_end"].update(value="2026-02-30", evidence=["/identity/file_name"]))

        bad_file = d / "notes.csv"
        bad_file.write_text("a,b\n1,2\n")
        r = run("profile_workbook.py", "--input", bad_file, "--output", d / "err-observations.json")
        check("unsupported file -> processing_error", r.get("profile_status") == "processing_error", r)
        r = run("build_profile.py", "--observations", d / "err-observations.json",
                "--output", d / "err-profile.json", "--summary", d / "err-summary.md")
        check("error profile still builds", r.get("build_status") == "valid", r)

    passed = all(c["ok"] for c in checks)
    print(json.dumps({"passed": passed, "total": len(checks),
                      "failed": [c for c in checks if not c["ok"]]}, indent=2, default=str))


if __name__ == "__main__":
    main()
