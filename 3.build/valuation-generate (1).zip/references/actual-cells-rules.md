# Choosing cells in the actual workbook (actual_cells.json)

Map each metric below to ONE cell in the analyst's actual workbook, only when the schema shows
that cell's formula or label clearly is that metric. Skip a metric rather than guess. List every
choice, with its label and formula, in the final summary for the analyst to confirm.

| Metric | What it is |
|---|---|
| `ltm_revenue` | the LTM revenue the valuation uses |
| `valuation_ebitda` | the EBITDA the multiple is applied to (after the workbook's own adjustments) |
| `ev_ebitda_multiple` | the EV/EBITDA multiple input |
| `enterprise_value` | enterprise value (after weighting, if the workbook blends methods) |
| `net_debt` | net debt used in the equity bridge (if the workbook holds cash and debt separately, skip it) |
| `equity_value` | equity value before any discount |
| `fair_value` | equity value after the discount |
| `xpv_value` | XPV's share of value |

Source of truth for choosing: the actual workbook's input map `key_outputs` and
`key_output_reasons` if uploaded; otherwise run `valuation-workbook-schema` on the actual workbook
first and use its key outputs and sheet sections.

```json
{"enterprise_value": "Valuation!B2", "valuation_ebitda": "Valuation!B1", "fair_value": "Valuation!B5"}
```
