---
name: valuation-generate
description: Generates a valuation workbook for a company from its financial statements plus a few analyst answers, using a generic XPV concept library (revenue, EBITDA, debt, cash and their common labels) and a standard EV-multiple template built entirely from Excel formulas. Optionally compares the result with the analyst's real workbook and explains the gap. Use when the user uploads financial statements for a new company, asks to generate or build a valuation from statements, or asks how a generated valuation compares with an actual one.
---

# Valuation generate (new company)

Python maps statement lines to generic concepts, copies the source values, and writes a workbook
whose every calculation is an Excel formula. You record any answers the user already gave, choose
comparison cells in an actual workbook (if one is given), and report. The only pause is the Excel step:
never ask questions during a run. Missing answers become flagged assumptions; ambiguous lines are resolved
by rule and flagged; everything goes to the analyst in the final summary.

## Division of labour
| Step | Who | Does |
|---|---|---|
| 1 index, 2 map | Python | find statement lines by label, pick the LTM window and period-end values by header date |
| answers | Analyst (optional, any time) | units, multiple(s) and weights, adjustments, discount, ownership, claims (references/analyst-questions.md); missing ones become flagged assumptions |
| 3 build | Python | generic workbook: Inputs, Source Data, Valuation, Checks, Lineage (formulas only) |
| 4 recalc | Analyst | open in desktop Excel, save, upload |
| 5 compare | You + Python | you choose actual cells (references/actual-cells-rules.md); Python compares and explains the gap |

Every script ends with a `NEXT REQUIRED STEP` line. Do exactly that next. Copy commands exactly.

## Steps
1. `python scripts/index_sources.py <statements> --out /app/created/sources_index.json`
2. If the user's messages contain answers, write `/app/created/answers.json` first (format in
   `references/analyst-questions.md`), copying values exactly. Then:
   `python scripts/map_financials.py --sources-index /app/created/sources_index.json [--answers /app/created/answers.json] --out /app/created/mapping.json`
   `READY_WITH_ASSUMPTIONS` -> continue; list every ASSUMPTION line in the final summary.
   `CANNOT_BUILD` -> stop and report every BLOCKER line (e.g. fewer than twelve months of statements).
   When the user later replies with answers or corrections, update answers.json (or `label_overrides`)
   and re-run from this step.
3. `python scripts/build_workbook.py --mapping /app/created/mapping.json --answers /app/created/answers.json --out "/app/created/<Company>_valuation_<period end>.xlsx"`
4. `python scripts/write_manifest.py --skill valuation-generate --inputs <statements> /app/created/answers.json --outputs /app/created/<workbook> /app/created/mapping.json /app/created/<workbook stem>_outputs.json --out "/app/created/<Company>_generate_manifest_{run_id}.json"`
   Return the workbook, mapping.json and manifest with `references/excel-step.md`. End your turn.
5. When the saved workbook is uploaded:
   - with an actual workbook: write `/app/created/actual_cells.json` per `references/actual-cells-rules.md`, then
     `python scripts/compare_to_actual.py --generated "<saved workbook>" --outputs /app/created/<workbook stem>_outputs.json --actual "<actual workbook>" --actual-cells /app/created/actual_cells.json --out-dir /app/created`
   - without one: `python scripts/read_values.py --generated "<saved workbook>" --outputs /app/created/<workbook stem>_outputs.json`

## Self-test
"Run the valuation-generate self-test" -> `python tests/run_selftest.py`; show its output unchanged.

## Final summary
1. The MAPPING, BUILD and COMPARE (or VALUES) status lines exactly.
2. Which statement line was used for each concept, every FLAG and ASSUMPTION line, and the statement-pack
   (layout) checks. These are the analyst's review items, in one list.
3. The comparison report's Review list unchanged and in its order (impact x uncertainty), then the
   comparison table and EV gap explanation. List the actual cells you chose.
4. Files saved, with run_id. One line on the next action.

## Rules
- Never calculate, estimate or adjust a number. Answers are copied exactly from the user.
- Never edit the generated workbook or the scripts; never write your own code to read statements.
- The generic template is a baseline, not the company's method. Present differences as findings.
- Do not narrate progress.
