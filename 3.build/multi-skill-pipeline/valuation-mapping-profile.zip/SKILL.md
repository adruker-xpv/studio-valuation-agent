---
name: valuation-mapping-profile
description: Builds a company mapping profile for quarterly valuation updates. Uses bundled Python scripts to find where each material workbook input appears in the source financial statements (direct, scaled, sign-flipped, 3-month or 12-month sums), groups inputs into business concepts, and records refresh rules and analyst approvals. Use after valuation-workbook-schema has produced an input map, when the user provides the source statements behind the current workbook.
---

# Valuation mapping profile

You turn a validated input map into a company mapping profile: which business concept each
material input is, where its value comes from in the source statements, and how it is refreshed
each quarter. Scripts produce all lineage, unit, sign and period evidence. You group inputs into
concepts, propose refresh rules, and ask the analyst. You never approve anything yourself.

## Prerequisites (if one is missing, say which and stop; otherwise run without asking questions)
- Supply the statements for the SAME period as the workbook: for a quarterly workbook, every monthly
  file of the latest quarter (more history lets more cells be reproduced).
- The workbook and `<stem>_input_map.json` from valuation-workbook-schema (from this conversation or
  uploaded). Continue if its status is COMPLETE or REVIEW_REQUIRED; note the status in the summary.
- The source statements that fed THIS workbook's current values, as .xlsx/.xlsm/.csv.
  PDFs are not supported: ask the user for Excel or CSV exports.

## Workflow

### 1. Index the sources
Statement packs vary: one file with months across columns, one file per month, or one sheet per month,
with current, YTD, budget and variance columns. The indexer handles each and reports pack problems;
they never stop the run and go in the final summary.
```
python scripts/index_sources.py <source files or folder> --out /app/created/sources_index.json
```

### 2. Discover rules
```
python scripts/match_values.py "<workbook>" /app/created/<stem>_input_map.json /app/created/sources_index.json --out /app/created/matches.json [--period-end YYYY-MM-DD]
```
It tries every statement line (across all monthly files) with every operation (value at the period,
3- or 12-month sums, YTD differences), scale and sign, and keeps the rule that reproduces the workbook.
Block statuses: `reproduced_all`, `reproduced_some` (typically earlier periods the statements do not
cover), `ambiguous` (two rules reproduce it equally), `no_rule`, `not_testable` (rates, multiples,
values under 100).

### 3. Write concepts
Create `/app/created/concepts.json`: group every in-scope block (every material block, plus every
`not_material` block with `reporting_required: yes`) into business concepts, a few dozen for a whole
workbook. Format in `references/profile-fields.md`. Each block belongs to exactly one concept.
- Automated concepts (replace_period_value, roll_window) get their executable rule from the
  discovery automatically. Add an `execution` rule only when the analyst states one that was not
  discovered; copy the analyst's words into notes.
- Put open points in `questions`.

### 4. Build the profile
```
python scripts/build_profile.py /app/created/<stem>_input_map.json /app/created/matches.json /app/created/concepts.json --out-dir /app/created
```
`PROFILE STATUS: INVALID` -> fix only the listed problems (max 3 attempts). `DRAFT` is a normal outcome:
list the EXCEPTION concepts and what each needs, then continue to the summary.

### 5. Corrections and approvals (only when the user replies to a finished run)
- Rule corrections ("revenue is the sum of monthly Total Revenue, statements in units"): add or edit that
  concept's `execution` rule, re-run step 4, and report which approvals were reset.
- Approvals are optional and never required to replay or backtest. Record one only when the user's
  message approves named concepts and names the approver:
  `python scripts/build_profile.py ... --approve "<ids>" --approver "<name>"`.

### 6. Manifest
```
python scripts/write_manifest.py --skill valuation-mapping-profile --inputs "<workbook>" /app/created/<stem>_input_map.json <source files> /app/created/concepts.json --outputs /app/created/mapping_profile.json /app/created/mapping_profile_review.md /app/created/matches.json --parent-run-id <schema run_id> --out "/app/created/mapping_profile_run_manifest_{run_id}.json"
```

### 7. Save and report
Save `mapping_profile.json`, `mapping_profile_review.md`, `concepts.json`, `matches.json` and the manifest with
the SharePoint/OneDrive Create file tool (pass the sandbox path as the file content), or return
them as downloads. In the final summary quote the PROFILE STATUS and gate lines exactly, then the
Review list from `mapping_profile_review.md`, unchanged and in its order (impact x uncertainty).
READY_FOR_REPLAY means the profile can go to the replay test; it is not certified.

## Rules
- Do not ask the user questions during a run. Put open points in `questions` in concepts.json.
- Every script ends with a `NEXT REQUIRED STEP` line. Do exactly that next.
- Rules come only from matches.json or the analyst's stated rule. Never name a source file, sheet, row, unit or sign that
  the scripts did not report.
- A value tie is evidence of where a number came from, not proof of what it means. Say so when
  a tie looks coincidental (different label, odd transform).
- Never approve on the user's behalf, never infer approval from "looks good" about a different
  item, and never invent an approver name.
- Never calculate numbers. Do not modify the scripts, workbook or source files.
- Do not narrate progress. Report results.
