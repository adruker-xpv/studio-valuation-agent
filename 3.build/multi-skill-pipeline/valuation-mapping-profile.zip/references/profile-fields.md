# concepts.json format (v2)

```json
{"concepts": [
  {"concept_id": "is.revenue", "name": "Revenue", "entity": "LuminUltra",
   "targets": ["Financial Summary!AH9:AI9"],
   "write_mode": "roll_window", "period_rule": "quarter_sum_of_months",
   "missing_source_behavior": "block_and_flag",
   "source_filename_pattern": "<Company>_Consolidated_Financial_Statements_<Month>_<DD>__<YYYY>.xlsx",
   "reconciliation_rule": "three months sum to the quarter",
   "notes": "feeds Valuation!B5 via Valuation!B2",
   "questions": []}
]}
```
Allowed fields only: concept_id, name, entity, targets, write_mode, period_rule, missing_source_behavior,
source_filename_pattern, reconciliation_rule, execution, notes, questions.

## The executable rule (the most important part)
match_values.py DISCOVERS each automated concept's rule by reproducing the workbook's values from the
statements. Do not write `execution` when a rule was discovered. Write `execution` ONLY when the analyst
states a rule the discovery did not find (for example because the statements supplied do not cover the
periods, or the rule combines several lines). Text in notes or reconciliation_rule is never executed.

```json
"execution": {"operation": "sum_months", "months": 3,
              "source": {"sheet": "Income Statements", "label": "Total Revenue", "role": "current"},
              "scale": 0.001, "sign": 1}
```
| operation | meaning | extra fields |
|---|---|---|
| `value_at` | the value for the period: balances, reported figures | - |
| `sum_months` | sum of N consecutive monthly values ending at the period | `months` |
| `ytd_difference` | YTD(period) - YTD(previous quarter end); first fiscal quarter = YTD(period) | `fiscal_year_start_month` |
| `components` | sum of sub-rules, each with its own `sign` (e.g. several debt lines, revenue minus costs) | `components`: list of rules |

`source.role`: `current` (current-period column), `ytd`, or `prior_year`. Budget and variance columns are
never used. `scale` converts statement units to workbook units (0.001 = statements in units, workbook in
thousands). `sign` is 1 or -1.

## write_mode
`replace_period_value` (overwrite the current-period cells), `roll_window` (current period by rule, earlier
periods rolled forward from the base workbook), `carry_forward`, `carry_forward_event_driven`,
`manual_input`, `manual_review` (unknown; blocks READY_FOR_REPLAY).

## period_rule
`month`, `quarter_sum_of_months`, `quarter_end_balance`, `ltm_sum`, `ytd`, `ytd_difference`, `point_in_time`,
`not_periodic`, `uncertain` (blocks READY_FOR_REPLAY). For roll_window it sets the spacing between cells
(quarterly = 3 months) when earlier cells' periods are inferred from the layout.

## missing_source_behavior
`block_and_flag` (exception; default for financial data), `carry_forward_and_flag`, `manual_input`.

## Concept statuses (set by build_profile.py)
| Status | Meaning |
|---|---|
| EXECUTABLE | a runnable rule that reproduced the workbook |
| EXECUTABLE_UNVERIFIED | an analyst-specified rule not yet reproduced; the replay is its first test |
| MANUAL | manual input or carry-forward |
| EXCEPTION | automated, but no runnable rule: needs an `execution` rule or a different write_mode |

READY_FOR_REPLAY = no EXCEPTION and no manual_review/uncertain rules. Approvals are NOT needed to test;
a named person certifies after a replay or backtest passes. Any change to a concept's rule, targets or
template resets its recorded approval.
