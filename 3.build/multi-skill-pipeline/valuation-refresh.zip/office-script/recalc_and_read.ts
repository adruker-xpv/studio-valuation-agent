// recalc_and_read.ts - Office Script for Excel on the web (Automate tab > New script).
// Fully recalculates the workbook and returns the requested cells as JSON:
//   input  cellsJson: '["Valuation!B5", "Valuation Summary!F44"]'   (the input map's key_outputs + control cells)
//   output '{"Valuation!B5": 28812.875, "Valuation Summary!F44": true}'
// Save the output as values.json and pass it to check_result.py with --values-json.
function main(workbook: ExcelScript.Workbook, cellsJson: string): string {
  const cells: string[] = JSON.parse(cellsJson);
  workbook.getApplication().calculate(ExcelScript.CalculationType.full);
  const out: { [ref: string]: string | number | boolean | null } = {};
  for (const ref of cells) {
    const i = ref.lastIndexOf("!");
    const sheetName = ref.substring(0, i).replace(/^'|'$/g, "").replace(/''/g, "'");
    const ws = workbook.getWorksheet(sheetName);
    out[ref] = ws ? (ws.getRange(ref.substring(i + 1)).getValue() as string | number | boolean) : null;
  }
  return JSON.stringify(out);
}
