# Automating the Excel step (production, not needed for testing)

Replaces "open in Excel, save, upload" with a Power Automate flow.

1. In Excel on the web, open any workbook, go to Automate > New script, paste `recalc_and_read.ts`,
   and save it as `recalc_and_read`.
2. In Power Automate, create a flow the agent can call (Copilot Studio: Tools > Add a tool > New
   agent flow) with inputs `file` (SharePoint path of the draft) and `cells` (JSON list).
3. Add the action Excel Online (Business) > Run script: location = the company's SharePoint site,
   file = `file`, script = `recalc_and_read`, cellsJson = `cells`.
4. Add Create file (SharePoint): save the script result as `<draft>_values.json` next to the draft.
5. Return the file path to the agent.

Open question to test before relying on it: getting `<draft>_values.json` from SharePoint into the
sandbox without the agent retyping values. If the agent can only receive the values as text,
keep the manual Excel step: an LLM should not transcribe the numbers that the check depends on.
