# apply_writes.py - writes the plan into a copy of the workbook (never touches formulas)
# Usage: python apply_writes.py --workbook <base.xlsx> --plan write_plan.json --out <stem>_<mode>_draft.xlsx
# replay/backtest: every planned cell is CLEARED first, then filled, so every value provably comes from the plan.
# The draft is set to fully recalculate when opened in Excel.
import sys, json, argparse, os
from openpyxl import load_workbook


def main(a):
    plan = json.load(open(a.plan, encoding="utf-8"))
    keep_vba = a.workbook.lower().endswith(".xlsm")
    wb = load_workbook(a.workbook, keep_vba=keep_vba)
    written = cleared = skipped = 0
    for p in plan["writes"]:
        sh, cell = p["cell"].rsplit("!", 1)
        c = wb[sh][cell]
        if c.data_type == "f":
            p["written"] = False
            skipped += 1
            continue
        if plan["mode"] in ("replay", "backtest"):
            c.value = None
            cleared += 1
        if p["status"] in ("ok", "flag", "historical") and p["value"] is not None:
            c.value = p["value"]
            p["written"] = True
            written += 1
        else:
            p["written"] = False
            skipped += 1
    try:
        wb.calculation.fullCalcOnLoad = True
    except Exception:
        pass
    wb.save(a.out)
    log = a.out.rsplit(".", 1)[0] + "_write_log.json"
    json.dump(plan, open(log, "w", encoding="utf-8"), indent=1, default=str)
    print(f"DRAFT WRITTEN: {a.out} | written: {written} | cleared first: {cleared} | not written: {skipped}")
    print(f"WRITE LOG: {log}")
    print("NEXT REQUIRED STEP: run write_manifest.py, then give the user the draft with these instructions: open it in "
          "desktop Excel, wait for calculation to finish, save (keep .xlsx), and upload the saved file here. Then run "
          "check_result.py. This is the one step that needs the user.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--workbook", required=True); ap.add_argument("--plan", required=True); ap.add_argument("--out", required=True)
    a = ap.parse_args()
    try:
        main(a)
    except Exception as e:
        print(f"APPLY_ERROR: {type(e).__name__}: {e}"); sys.exit(1)
