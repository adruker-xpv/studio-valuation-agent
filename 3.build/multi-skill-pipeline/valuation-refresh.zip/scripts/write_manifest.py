# write_manifest.py - writes an immutable run manifest (hashes of every input, output and script)
# Usage: python write_manifest.py --skill <name> --inputs <files...> --outputs <files...>
#        [--parent-run-id <id>] [--company <name>] [--period <e.g. 2026-Q1>] --out <stem>_run_manifest_<run_id>.json
# If --out contains {run_id}, it is replaced with the generated id.
import os, sys, json, glob, hashlib, argparse, datetime, uuid

SKILL_VERSION = "1.0"


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main(a):
    run_id = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:6]
    here = os.path.dirname(os.path.abspath(__file__))
    scripts = {os.path.basename(p): sha(p) for p in sorted(glob.glob(os.path.join(here, "*.py")))}
    files = lambda xs: [{"file": os.path.basename(p), "sha256": sha(p), "bytes": os.path.getsize(p)}
                        for p in xs if os.path.isfile(p)]
    missing = [p for p in (a.inputs or []) + (a.outputs or []) if not os.path.isfile(p)]
    facts = {}
    for p in a.outputs or []:
        if p.endswith(".json") and os.path.isfile(p):
            try:
                d = json.load(open(p, encoding="utf-8"))
                for k in ("template_fingerprint", "key_outputs", "status", "materiality_basis"):
                    if k in d:
                        facts[f"{os.path.basename(p)}:{k}"] = d[k]
            except Exception:
                pass
    man = {"run_id": run_id, "parent_run_id": a.parent_run_id, "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "skill": a.skill, "skill_version": SKILL_VERSION, "company": a.company, "valuation_period": a.period,
           "scripts": scripts, "inputs": files(a.inputs or []), "outputs": files(a.outputs or []),
           "facts": facts, "missing_files": missing}
    out = a.out.replace("{run_id}", run_id)
    json.dump(man, open(out, "w", encoding="utf-8"), indent=1, default=str)
    print(f"MANIFEST WRITTEN: {out}\nrun_id: {run_id}")
    if missing:
        print("warning: files not found: " + ", ".join(missing))
    print("NEXT REQUIRED STEP: save the manifest with the other output files and include the run_id in the final summary.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--skill", required=True); ap.add_argument("--inputs", nargs="*"); ap.add_argument("--outputs", nargs="*")
    ap.add_argument("--parent-run-id", default=None); ap.add_argument("--company", default=None)
    ap.add_argument("--period", default=None); ap.add_argument("--out", required=True)
    main(ap.parse_args())
