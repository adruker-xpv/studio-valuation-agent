---
name: valuation-refresh
description: Rebuilds valuation workbooks by running the mapping profile's executable rules (values at a period, monthly sums across monthly statement files, YTD differences, components). Replay rebuilds the profile's own period; backtest predicts a real later period from the prior workbook and checks it against the analyst's actual workbook; refresh builds the next quarter's draft. Use when the user asks to replay, backtest, certify, refresh, roll forward or produce a quarterly draft, or to run the valuation-refresh self-test.
---

# Valuation refresh (replay, backtest, refresh)

Python plans and writes every value and checks the result. You run the scripts exactly as written
below (copy the commands; do not guess arguments), write `manual_inputs.json` from values the user
gives you, and report. The one pause is the Excel step (the sandbox cannot recalculate).

## Which mode
| Mode | Base workbook | Statements | Also needs | What a pass proves |
|---|---|---|---|---|
| replay | the profile's own workbook | same period | - | the rules rebuild every current-period input and the outputs |
| backtest | the PRIOR period's final | the next period | --actual: the analyst's real next-period workbook | the rules predicted a period they never saw (strongest) |
| refresh | last period's final | the new period | certification.json (CERTIFIED), manual inputs | produces the draft for review |

Certify with a backtest whenever a prior-period workbook exists. A replay-only certification is
allowed but every refresh will note it. Approvals of individual concepts are not needed: a named person
certifies the whole profile after a pass.

## Steps (all modes)
`<period end>` is the last day of the period being built, e.g. `2026-06-30`. Take it from the user's
message; for replay it may be omitted (inferred from the evidence).
1. `python scripts/index_sources.py <statements> --out /app/created/sources_index.json [--expect-layout <mapping_profile.json>]`
   It reports each file's layout (one period per file, months across columns, sheet per month) and pack
   problems (undated files, duplicate or missing months, repeated labels, a changed layout). These never
   stop the run; list them in the final summary.
2. Plan:
   - replay: `python scripts/plan_writes.py --mode replay --workbook "<workbook>" --input-map <input_map> --profile <mapping_profile.json> --sources-index /app/created/sources_index.json --out /app/created/write_plan.json`
   - backtest: `python scripts/plan_writes.py --mode backtest --workbook "<prior workbook>" --actual "<actual workbook>" --input-map <input_map> --profile <mapping_profile.json> --sources-index /app/created/sources_index.json --period-end <period end> --out /app/created/write_plan.json`
   - refresh: `python scripts/plan_writes.py --mode refresh --workbook "<last final>" --input-map <input_map> --profile <mapping_profile.json> --certification <certification.json> --sources-index /app/created/sources_index.json --period-end <period end> [--manual /app/created/manual_inputs.json] --out /app/created/write_plan.json`
   `PLAN STATUS: REFUSED` -> report the reasons and stop.
   `PLAN STATUS: BLOCKED` -> STOP. Exceptions mean a rule could not run; a replay or backtest with exceptions
   proves nothing. Report each exception (cell, concept, reason) and do not do the Excel step.
   `historical kept` cells (earlier periods the statements do not cover) are allowed in a replay but are
   not proof; list them. In backtest and refresh, earlier periods roll forward from the base workbook.
3. `python scripts/apply_writes.py --workbook "<the --workbook from step 2>" --plan /app/created/write_plan.json --out /app/created/<stem>_<mode>_draft.xlsx`
4. `python scripts/write_manifest.py --skill valuation-refresh --inputs <all input files> --outputs /app/created/<stem>_<mode>_draft.xlsx /app/created/<stem>_<mode>_draft_write_log.json --out "/app/created/<stem>_<mode>_manifest_{run_id}.json"`
   Return the draft, write log and manifest with the instructions in `references/excel-step.md`. End your turn.
5. When the saved file is uploaded:
   `python scripts/check_result.py --mode <mode> --base "<the --workbook from step 2>" [--actual "<actual workbook>" (backtest only)] --draft /app/created/<stem>_<mode>_draft.xlsx --input-map <input_map> --plan /app/created/<stem>_<mode>_draft_write_log.json --result "<saved file>" --out-dir /app/created`
6. Report (final summary below). Then write a manifest for the check.

## Sign-offs (only when the user's latest message says so and names the person)
- "Certify ... - <name>" after a REPLAY_PASS or BACKTEST_PASS: re-run step 5 with `--certified-by "<name>"`.
- "Approve refresh draft - <name>": record it in the final summary and the manifest notes.

## Manual inputs (refresh)
Write `/app/created/manual_inputs.json` as `{"values": {"Inputs!B3": 9.0}}`, copying numbers exactly
as the user gave them, one entry per target cell. Missing values are allowed; they become exceptions.
In backtest, manual inputs come from the actual workbook automatically.

## Self-test
"Run the valuation-refresh self-test" -> `python tests/run_selftest.py`; show its output unchanged.

## Final summary
1. `CHECK STATUS` or `PLAN STATUS` line exactly, then each check line.
2. The report's key output, by-concept and control tables unchanged.
3. The report's Review list, unchanged and in its order: it ranks exceptions, failed checks, variance
   flags, flagged writes, historical cells and statement-pack notes by impact x uncertainty.
4. Files saved, with locations and run_id. One line on the next action.

## Rules
- Never calculate, estimate or adjust a number. Manual inputs are copied from the user's words.
- Never edit the draft, the plan or the scripts. Never write your own code to fill a workbook.
- If a command fails on its arguments, re-read this file and use the command exactly as written.
- A failed replay or backtest is a finding: report which concepts and cells did not reproduce.
- Never certify or approve without an explicit instruction naming the person.
- Do not narrate progress.
