# Classifying material inputs (J2)

## File format
```json
{"classifications": [
  {"id": "Quarterly!B2:E2", "type": "financial_statement",
   "expected_source": "Income statement: Revenue by quarter",
   "changes_each_quarter": "yes", "confidence": "high",
   "notes": "Revenue row; path Quarterly!B2 -> Quarterly!B5 -> Valuation!B1",
   "reviewed_by": null}
]}
```
One entry per MATERIAL block, ids copied exactly from the skeleton. Nothing else.

## type
- `financial_statement` comes from the company's statements each period (revenue, costs, EBITDA,
  cash, debt). `expected_source` required, e.g. `Balance sheet: Cash and cash equivalents`.
- `assumption` judgement input (multiple, discount %, weighting, add-backs).
- `prior_period` carried from the previous valuation.
- `constant` fixed by definition (unit factors, fixed contractual rates).
- `carry_forward_event_driven` carries forward unless an event changes it (cap-table holdings,
  share counts, options, instrument terms). Use `changes_each_quarter: on_event`.
- `reference_data` external market data blocks (comparables, FX tables).
- `uncertain` no label, or the label and the formula path disagree.

## changes_each_quarter
`yes`, `no`, `on_event`, `uncertain`. A single workbook cannot show how often a value changes, so
this field is always a proposal. For assumptions, end the notes with "cadence proposed, not
evidenced". Cadence never raises confidence.

## confidence (evidence, not a feeling)
- `high` the label and the dependency path both support the type (e.g. "Revenue" row feeding EBITDA).
- `medium` either the label or the path supports it, not both.
- `low` based only on sheet name, column position, or similar patterns. Also use for anything
  with a FLAG.
- `uncertain` type always pairs with `low`.

## notes (required, one or two sentences)
Cite the label and the path from `paths_to_key_outputs`. If the block has `flags`, address each
flag. No general-knowledge claims.

## Non-material blocks
You do not classify these; the script sets `type: not_material` and `reporting_required:
unconfirmed`. Only the analyst sets reporting scope (yes/no), through a scope file.
`not_material` means "does not feed a key output", not "irrelevant".

## reviewed_by
Always `null` when you classify. Set it to a person's name only when the user's latest message
confirms that block (or a group it names, e.g. "all financial_statement blocks") and gives the
name. Never infer a reviewer.

## Conflicts
If a block's label and its apparent purpose disagree (e.g. a label says one period or metric but
the path or formula suggests another), use confidence `low` and describe the conflict in notes.

## Comparable sets and other repeated rows
Existing comparable rows (transaction or trading comps) are historical reference data, not
separate update targets: use `reference_data`, `changes_each_quarter: on_event`, and a short
shared note such as "Transaction comp row; comp set reviewed as a whole (see <first id>)".
The mapping profile treats the whole set as one concept with one review rule.
Other blocks with the same label pattern may share wording, but each keeps its own entry and
confidence. Do not raise confidence because many blocks look alike.
