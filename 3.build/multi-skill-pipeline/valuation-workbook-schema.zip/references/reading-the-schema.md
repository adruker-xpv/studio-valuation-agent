# Reading the schema

## Files
- OVERVIEW (printed, and at the top of the schema file): counts, INDEX of line ranges, flow,
  named ranges, key outputs, blocking issues, flag counts. Lists in the overview may be capped.
- `<stem>_schema.md`: the overview, then OUTPUTS BY SHEET (copied-across rows collapsed), then
  one complete section per sheet. Never truncated. Use the INDEX line ranges to read a section.
- `<stem>_inputs_skeleton.json`: every input block, with `feeds_key_outputs` and
  `paths_to_key_outputs` (shortest dependency chain from the block to each key output).

## Line format
`<range> [<role>] <row label> | <column header> <formula or = values> -> <saved values>  MARKERS`
- `[input]` hardcoded value used by at least one formula. Decided by Python; trust it.
- `[calc]` formula used by other formulas. `[output]` formula nothing uses.
  `[KEY OUTPUT]` a user-confirmed key output.
- `MATERIAL` the input feeds a key output (or, before key outputs are set, any output).
  `feeds:` lists which key outputs. `path:` is the shortest chain to one of them;
  the skeleton has one path per key output.
- `same pattern xN` one formula copied across N cells; the first cell's formula is shown.
- `-> values` are Excel's last saved results. `FLAG:no cached value` = never recalculated.
- Labels come from the nearest text left and above (merged headers are spread across their
  range). They can still be wrong.

## Flags
- `FLAG:hardcoded` numbers typed inside a formula (includes year exponents like `^3`).
- `FLAG:error`, `FLAG:external_link`: blocking when they feed a key output.
- `FLAG:label_type_mismatch`: the label suggests one kind of value but the cell holds another
  (e.g. "Amount" over a date). Usually a wrong header pairing. Your note must address it.
- `pattern_break`: a single cell whose formula differs from both neighbours in its row.

## Named range categories
`referenced` used by formulas; `unused`; `broken` (#REF); `external` (points to another file);
`print_or_builtin`.

Classification rules are in `classification-rules.md`; key-output rules in `key-output-rules.md`.
