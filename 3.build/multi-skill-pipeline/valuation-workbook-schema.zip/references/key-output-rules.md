# Choosing key outputs (J1)

Key outputs are the cells the scripts trace backwards from. Inputs that feed none of them are
treated as not material, so choose the real valuation deliverables and controls.

## Include (5-15 cells), when the schema shows them
- Enterprise value, equity value, and the fund's (XPV's) value and cost
- The applied multiple and the metric it is applied to (e.g. TTM/LTM adjusted EBITDA, revenue)
- Cash and debt (or net debt) used in the equity bridge
- Ownership % used to allocate value to the fund
- MOIC and IRR
- Control cells: attribution totals and true checks. A true check COMPARES two things (a
  difference, `=`, or an IF test) and returns 0 or TRUE when the model ties. A cell labelled
  "check" that only averages, sums or displays a metric is NOT a control cell; exclude it.
- Intermediate formula cells are allowed; they need not be terminal outputs.

## Exclude
- Inputs and assumptions (discounts, multiples typed in as numbers): they are traced automatically.
- Display, formatting, growth-rate and memo cells, and prior-period copies of current metrics.
- Duplicates: when the same metric appears on several sheets (e.g. a summary and an LP report),
  choose the current-period cell on the valuation summary. Mention the duplicate cell in the reason.

## Signals
- `[upstream inputs: N from S sheets]` in OUTPUTS BY SHEET: deliverables usually draw on many
  inputs across several sheets. Cells with very few upstream inputs are usually display or checks.
- Labels are guesses; confirm with the formula in the sheet section before choosing.

## File format
```json
{"key_outputs": [
  {"cell": "'Valuation Summary'!F25", "reason": "XPV value; =F15*F29 (equity value x ownership)"},
  {"cell": "'LP Report'!D49:D51", "reason": "LP reconciliation metrics; duplicates of summary F25-F27"}
]}
```
For every true control cell, add a `control`:
```json
  {"cell": "'Valuation Summary-Prior Period'!F44", "reason": "Integrity check; =F42=F43",
   "control": {"control_type": "boolean", "expected": true, "severity": "blocking"}},
  {"cell": "'II. Attribution Summary'!D25", "reason": "Attribution check; =D17-D24",
   "control": {"control_type": "numeric", "expected": 0, "absolute_tolerance": 1, "severity": "blocking"}}
```
`expected` is what the cell returns when the model ties, read from the formula (a difference
should be 0, an `=` comparison should be TRUE). Use `blocking` unless the label or formula shows
it is informational (`warning`). Never choose `expected` from the cell's current value: a
control that currently fails must be reported as failing.

Quote sheet names containing spaces or punctuation. `reason` = metric, then the formula text
copied from the schema. 1-15 entries.

## Describing formulas faithfully
Describe a formula only by what its functions and references literally do. Never name a
statistic or method the formula does not contain: AVERAGE is an average, not a median; a cell
averaging two other cells is a blend of those cells. If the logic is unclear, quote the formula
and add "meaning UNCERTAIN".
