# validate_input_map.py - gates an input map against the extractor's skeleton (v3)
# Usage: python validate_input_map.py <stem>_inputs_skeleton.json <stem>_input_map.json
# STATUS: INVALID (exit 1) | REVIEW_REQUIRED (exit 3) | COMPLETE (exit 0)
# COMPLETE = structurally complete, no unresolved items, key outputs set. It is NOT proof that the
# classifications are right or that a new workbook can be generated; every classification is proposed.
import json, sys

TYPES = {"financial_statement", "assumption", "prior_period", "constant",
         "carry_forward_event_driven", "reference_data", "not_material", "uncertain"}
CHANGES = {"yes", "no", "on_event", "uncertain"}
CONF = {"high", "medium", "low"}
FILL = {"type", "expected_source", "changes_each_quarter", "confidence", "notes"}
LOCKED = ("sheet", "range", "label", "header", "n_cells", "sample_values",
          "material", "feeds_key_outputs", "paths_to_key_outputs", "flags")


def evaluate(skel_path, map_path):
    skel = json.load(open(skel_path, encoding="utf-8"))
    try:
        m = json.load(open(map_path, encoding="utf-8"))
    except json.JSONDecodeError as e:
        return {"status": "INVALID", "errors": [f"input map is not valid JSON: {e}"], "skel": skel}
    sk = {e["id"]: e for e in skel["inputs"]}
    errs, seen = [], {}
    for i, e in enumerate(m.get("inputs", [])):
        if not isinstance(e, dict) or "id" not in e:
            errs.append(f"entry {i}: must be an object with an id"); continue
        eid = e["id"]
        if eid not in sk:
            errs.append(f"{eid}: not in the skeleton"); continue
        if eid in seen:
            errs.append(f"{eid}: duplicate entry")
        seen[eid] = e
        extra = set(e) - FILL - set(LOCKED) - {"id"}
        if extra:
            errs.append(f"{eid}: unknown fields {sorted(extra)}")
        for f in LOCKED:
            if e.get(f) != sk[eid].get(f):
                errs.append(f"{eid}: '{f}' differs from the skeleton")
        t, ch = e.get("type"), e.get("changes_each_quarter")
        if t not in TYPES:
            errs.append(f"{eid}: type must be one of {sorted(TYPES)}")
        elif t == "not_material":
            if sk[eid]["material"]:
                errs.append(f"{eid}: not_material but it feeds a key output")
        else:
            if ch not in CHANGES:
                errs.append(f"{eid}: changes_each_quarter must be one of {sorted(CHANGES)}")
            if t == "carry_forward_event_driven" and ch not in ("on_event", "uncertain"):
                errs.append(f"{eid}: carry_forward_event_driven needs changes_each_quarter 'on_event'")
            if t == "financial_statement" and not e.get("expected_source"):
                errs.append(f"{eid}: financial_statement needs expected_source")
            if e.get("confidence") not in CONF:
                errs.append(f"{eid}: confidence must be one of {sorted(CONF)}")
            if sk[eid]["material"] and not e.get("notes"):
                errs.append(f"{eid}: material input needs notes citing cells")
    for eid in sk:
        if eid not in seen:
            errs.append(f"{eid}: missing from the input map")
    tot = skel["totals"]
    recon = (f"reconciliation: blocks {len(seen)}/{tot['blocks']}, cells "
             f"{sum(sk[i]['n_cells'] for i in seen)}/{tot['cells']} (material cells {tot['material_cells']})")
    if errs:
        return {"status": "INVALID", "errors": errs, "recon": recon, "skel": skel}
    unresolved = [i for i, e in seen.items() if e["type"] == "uncertain" or e.get("changes_each_quarter") == "uncertain"]
    low = [i for i, e in seen.items() if e.get("confidence") == "low" and i not in unresolved]
    flagged = [(i, x) for i in seen for x in sk[i]["flags"]]
    blocking = skel.get("blocking_issues", [])
    gates = {"key outputs set": bool(skel.get("key_outputs")),
             "no unresolved entries": not unresolved,
             "no blocking issues": not blocking,
             "flags addressed in notes": all(seen[i].get("notes") for i, _ in flagged)}
    return {"status": "COMPLETE" if all(gates.values()) else "REVIEW_REQUIRED", "errors": [], "recon": recon,
            "gates": gates, "unresolved": unresolved, "low_conf": low, "blocking": blocking,
            "flagged": flagged, "entries": seen, "skel": skel,
            "counts": {t: sum(1 for e in seen.values() if e["type"] == t) for t in sorted(TYPES)},
            "broken_names": [n["name"] for n in skel.get("named_ranges", []) if n["category"] in ("broken", "external")]}


def main(skel_path, map_path):
    r = evaluate(skel_path, map_path)
    print(f"STATUS: {r['status']}")
    if r.get("recon"):
        print(r["recon"])
    if r["status"] == "INVALID":
        print("\n".join(f"- {x}" for x in r["errors"][:100]))
        print("NEXT REQUIRED STEP: fix classifications.json for the problems above, re-run apply_classifications.py, "
              "then this validator (max 3 attempts; then run build_report.py anyway).")
        return 1
    for g, ok in r["gates"].items():
        print(f"gate {'PASS' if ok else 'FAIL'}: {g}")
    print("types: " + ", ".join(f"{k}={v}" for k, v in r["counts"].items() if v))
    print(f"unresolved: {len(r['unresolved'])}" + (": " + ", ".join(r["unresolved"][:60]) if r["unresolved"] else ""))
    print(f"low confidence: {len(r['low_conf'])}" + (": " + ", ".join(r["low_conf"][:60]) if r["low_conf"] else ""))
    print(f"blocking issues: {len(r['blocking'])}" + "".join(f"\n- {b}" for b in r["blocking"][:30]))
    print("note: every classification is PROPOSED until an analyst reviews it; COMPLETE is not proof of correctness.")
    print("NEXT REQUIRED STEP (P4): run build_report.py. Do not ask the user anything; open items go in the report.")
    return 0 if r["status"] == "COMPLETE" else 3


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("usage: python validate_input_map.py <skeleton.json> <input_map.json>"); sys.exit(2)
    sys.exit(main(sys.argv[1], sys.argv[2]))
