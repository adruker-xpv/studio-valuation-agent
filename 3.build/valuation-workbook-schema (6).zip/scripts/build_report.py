# build_report.py - writes the end-of-run report deterministically from the files (no LLM prose)
# Usage: python build_report.py <stem>_inputs_skeleton.json <stem>_input_map.json --out <stem>_run_report.md
import sys, os, argparse
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from validate_input_map import evaluate


def main(skel_path, map_path, out):
    r = evaluate(skel_path, map_path)
    skel = r["skel"]
    L = [f"# Run report: {skel['workbook']}", "",
         f"**STATUS: {r['status']}**  ", r.get("recon", ""), ""]
    if r["status"] == "INVALID":
        L += ["## Input map problems (not resolved by the agent)"] + [f"- {x}" for x in r["errors"][:50]]
    else:
        L += ["## Gates"] + [f"- {'PASS' if ok else 'FAIL'}: {g}" for g, ok in r["gates"].items()]
    L += ["", "## Decisions made by the agent (proposed; confirm or correct)", "",
          "### Key outputs chosen", "| Cell | Reason |", "|---|---|"]
    L += [f"| {c} | {skel.get('key_output_reasons', {}).get(c, '')} |" for c in skel["key_outputs"]] or ["| (none) | |"]
    if r["status"] != "INVALID":
        ents = r["entries"]
        L += ["", "### Classifications", "| Type | Blocks | high | medium | low |", "|---|---|---|---|---|"]
        for t, n in r["counts"].items():
            if n:
                cs = [e.get("confidence") for e in ents.values() if e["type"] == t]
                L.append(f"| {t} | {n} | {cs.count('high')} | {cs.count('medium')} | {cs.count('low')} |")
        L += ["", "### Needs analyst input (unresolved, then low confidence)",
              "| Input | Label | Current values | Agent note |", "|---|---|---|---|"]
        rows = r["unresolved"] + r["low_conf"]
        for i in rows[:80]:
            e = ents[i]
            L.append(f"| {i}{' (UNRESOLVED)' if i in r['unresolved'] else ''} | {e['label']} | "
                     f"{', '.join(e['sample_values'][:4])} | {(e.get('notes') or '').replace('|', '/')} |")
        if not rows:
            L.append("| (none) | | | |")
        L += ["", "## Blocking issues"] + ([f"- {b}" for b in r["blocking"]] or ["- (none)"])
        if r["broken_names"]:
            L += ["", "## Broken or external named ranges", "- " + ", ".join(r["broken_names"])]
    L += ["", "## How to correct",
          "Reply with corrections, e.g. `Inputs!B6: assumption, changes each quarter: yes, note: management adjustment factor` "
          "or `Key outputs: add Valuation!B4, remove Valuation!B7`. The agent updates its decision files and re-runs "
          "the scripts; nothing is recalculated by hand.",
          "", "_Every classification above is proposed by the agent. COMPLETE means structurally complete, "
          "not verified correct._"]
    open(out, "w", encoding="utf-8").write("\n".join(L))
    print(f"REPORT WRITTEN: {out}")
    print(f"STATUS: {r['status']}")
    print("NEXT REQUIRED STEP (J3/P5): save all files (see SKILL.md step 8), then give the final summary: "
          "quote the STATUS line, then the report's 'Needs analyst input' table. If source statements were "
          "uploaded, continue with the valuation-mapping-profile skill before the final summary.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("skeleton"); ap.add_argument("input_map"); ap.add_argument("--out", required=True)
    a = ap.parse_args()
    main(a.skeleton, a.input_map, a.out)
