# apply_classifications.py - merges the agent's classifications into the skeleton (deterministic)
# Usage: python apply_classifications.py <stem>_inputs_skeleton.json classifications.json --out <stem>_input_map.json
#        (classifications.json may also be a saved <stem>_input_map.json, to reuse earlier decisions)
# - Non-material blocks are set to not_material automatically (no LLM judgment needed).
# - Material blocks take type/expected_source/changes_each_quarter/confidence/notes from classifications.json.
# - Structural fields are always copied from the skeleton, so the agent cannot alter them.
# classifications.json: {"classifications": [{"id": "...", "type": "...", "expected_source": "...",
#                        "changes_each_quarter": "...", "confidence": "high|medium|low", "notes": "..."}]}
import json, sys, argparse, copy

FIELDS = ("type", "expected_source", "changes_each_quarter", "confidence", "notes")


def main(skel_path, cls_path, out):
    skel = json.load(open(skel_path, encoding="utf-8"))
    spec = json.load(open(cls_path, encoding="utf-8"))
    reuse = "inputs" in spec and "classifications" not in spec     # a saved input map, reused
    cls = spec.get("classifications") or [e for e in spec.get("inputs", []) if e.get("type") != "not_material"]
    by_id, problems = {}, []
    ids = {e["id"] for e in skel["inputs"]}
    for c in cls:
        cid = c.get("id")
        if cid not in ids:
            if not reuse:
                problems.append(f"{cid}: not a skeleton id (copy ids exactly)")
        elif cid in by_id:
            problems.append(f"{cid}: classified twice")
        else:
            by_id[cid] = c
    m = copy.deepcopy(skel)
    auto = filled = missing = 0
    for e in m["inputs"]:
        if not e["material"]:
            e.update(type="not_material", expected_source=None, changes_each_quarter=None,
                     confidence="high", notes="auto: does not feed any key output")
            auto += 1
            if e["id"] in by_id and not reuse:
                problems.append(f"{e['id']}: not material; remove it from classifications.json")
            continue
        c = by_id.get(e["id"])
        if not c:
            missing += 1
            problems.append(f"{e['id']}: material block missing from classifications.json")
            continue
        for f in FIELDS:
            e[f] = c.get(f)
        filled += 1
    m["generated_by"] = skel.get("generated_by", "") + " + apply_classifications.py"
    json.dump(m, open(out, "w", encoding="utf-8"), indent=1)
    print(f"MERGED: material classified {filled}, material missing {missing}, auto not_material {auto}")
    for p in problems[:100]:
        print(f"- {p}")
    print(f"FILE WRITTEN: {out}")
    print("NEXT REQUIRED STEP (P3): run validate_input_map.py on the skeleton and this input map."
          + (" Fix classifications.json first if problems are listed above." if problems else ""))
    return 1 if problems else 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("skeleton"); ap.add_argument("classifications"); ap.add_argument("--out", required=True)
    a = ap.parse_args()
    sys.exit(main(a.skeleton, a.classifications, a.out))
