---
name: valuation-workbook-schema
description: Automatically maps an uploaded Excel valuation workbook end to end - extracts sheets, inputs, formulas, outputs and dependencies with bundled Python scripts, selects key outputs, traces which inputs feed them, classifies those inputs, validates the input map, and writes a run report listing every decision for analyst review. Use when the user uploads a valuation or financial model workbook and asks what it contains, what inputs it needs, or to prepare it for quarterly updates.
---

# Valuation workbook schema (autonomous)

Run the whole workflow without stopping to ask questions. Make the judgment calls yourself,
record each one in a decision file, and let the scripts do everything deterministic. Everything
you decide is a proposal; the run report lists it for the analyst at the end.

## Division of labour
| Step | Who | Does what | Writes |
|---|---|---|---|
| P1 | Python | discovery extraction, candidate outputs ranked by upstream inputs | schema, skeleton |
| J1 | You | choose key outputs (references/key-output-rules.md) | key_outputs.json |
| P2 | Python | final extraction, materiality, dependency paths, blocking issues | schema, skeleton |
| J2 | You | classify every MATERIAL input block (references/classification-rules.md) | classifications.json |
| P3 | Python | merge (non-material set automatically), validate | input_map.json, STATUS |
| P4 | Python | run report: status, gates, every decision, open items | run_report.md |
| J3 | You | Workbook Map prose (references/workbook-map-template.md) | chat only |
| P5 | Tool | save files | SharePoint or downloads |

Every script ends with a `NEXT REQUIRED STEP` line. Do exactly that next.

## Steps
Use `<stem>` = workbook file name without extension, as printed by the scripts. All files go
in `/app/created`.

**Reuse:** if the user uploaded a saved `<stem>_input_map.json`, skip J1 and J2: pass it as
`--key-outputs-file` in P2 and as the classifications file in P3.

1. **P1** `python scripts/extract_schema.py "<workbook>" --out /app/created`
   On `EXTRACTION_ERROR`: report that line and stop (the only reason to stop early).
2. **J1** Read the OVERVIEW and the OUTPUTS BY SHEET section (line range in the INDEX). Write
   `/app/created/key_outputs.json` following `references/key-output-rules.md`.
3. **P2** `python scripts/extract_schema.py "<workbook>" --out /app/created --key-outputs-file /app/created/key_outputs.json`
   If it errors on a key output cell, fix key_outputs.json and re-run (max 3 attempts).
4. **J2** Read, from `<stem>_schema.md`, every sheet section in the INDEX with material input cells,
   through its `=== END OF SHEET ===` line. Then write `/app/created/classifications.json` with one
   entry per MATERIAL block, following `references/classification-rules.md`. Skip non-material
   blocks; P3 handles them.
5. **P3** `python scripts/apply_classifications.py /app/created/<stem>_inputs_skeleton.json /app/created/classifications.json --out /app/created/<stem>_input_map.json`
   then `python scripts/validate_input_map.py /app/created/<stem>_inputs_skeleton.json /app/created/<stem>_input_map.json`
   On problems or `STATUS: INVALID`: fix classifications.json and repeat P3 (max 3 attempts).
   `REVIEW_REQUIRED` is a normal outcome: do not ask the user, continue.
6. **P4** `python scripts/build_report.py /app/created/<stem>_inputs_skeleton.json /app/created/<stem>_input_map.json --out /app/created/<stem>_run_report.md`
7. **J3** Write the Workbook Map (template) for the final summary.
8. **P5** Save `<stem>_schema.md`, `<stem>_input_map.json`, `<stem>_run_report.md`. With a
   SharePoint/OneDrive Create file tool, pass the sandbox path as the file content. Without one,
   return them as downloads. (The input map holds the key outputs and classifications, so it is
   all that is needed to reuse this run.)
9. **Final summary** (only now): quote the STATUS and reconciliation lines exactly, then the
   Workbook Map, then the report's "Needs analyst input" table, then where files were saved.

## Corrections (when the user replies to a finished run)
- Key output changes: edit key_outputs.json, then repeat from P2.
- Classification changes: edit classifications.json for the named ids only, then repeat from P3.
- Record the user's words in the entry's notes (e.g. "analyst: management adjustment factor"),
  set confidence to high, and re-run through P4. Report the new STATUS.

## Rules
- Do not ask the user questions during a run. Unclear items are `uncertain` or `low` confidence
  and go in the report.
- Use only script output. Cite a cell or range for every factual statement about the workbook.
- Never calculate, estimate, or re-derive a number. Show values exactly as the scripts print them:
  no added currency symbols, units (k, $, %), or conversions (0.15 stays 0.15).
- Never dismiss content as junk or unimportant; every block gets a disposition.
- An unlabeled input stays unlabeled and `uncertain`; do not borrow a label from a nearby formula.
- `expected_source` describes where a value should come from; never write it as if you saw it.
- No claims from general knowledge (e.g. "changes with market conditions"); cite cells instead.
- Do not suggest fixes to the model, including for flagged errors.
- Do not modify, import, or debug the scripts. Do not write your own code to read the workbook.
- Do not narrate progress.
