# Workbook Map template (J3; under 400 words; the run report covers status, decisions and open items)

## Workbook Map: <file name>
**1. Purpose.** 1-2 sentences, citing the key output cells.

**2. Sheets**
| Sheet | Role | What it does | Evidence |
Role is one of: Inputs/Assumptions, Source financials, Calculation, Output/Summary, Other,
UNCERTAIN. Mark hidden sheets.

**3. Calculation flow.** One line per SHEET FLOW edge that matters, from SHEET FLOW only
(e.g. `Inputs -> Adjustments -> Valuation`, `Quarterly -> Valuation`). Never join edges that are
not listed.

**4. Valuation method(s).** Only methods whose formulas are visible; cite cells. Else UNCERTAIN.
