# Classifying material inputs (J2)

## File format
```json
{"classifications": [
  {"id": "Quarterly!B2:E2", "type": "financial_statement",
   "expected_source": "Income statement: Revenue by quarter",
   "changes_each_quarter": "yes", "confidence": "high",
   "notes": "Revenue row; path Quarterly!B2 -> Quarterly!B5 -> Valuation!B1"}
]}
```
One entry per MATERIAL block, ids copied exactly from the skeleton. Nothing else.

## type
- `financial_statement` comes from the company's statements each period (revenue, costs, EBITDA,
  cash, debt). `expected_source` required, e.g. `Balance sheet: Cash and cash equivalents`.
- `assumption` judgement input (multiple, discount %, weighting, add-backs).
- `prior_period` carried from the previous valuation.
- `constant` fixed by definition (unit factors, fixed contractual rates).
- `carry_forward_event_driven` carries forward unless an event changes it (cap-table holdings,
  share counts, options, instrument terms). Use `changes_each_quarter: on_event`.
- `reference_data` external market data blocks (comparables, FX tables).
- `uncertain` no label, or the label and the formula path disagree.

## changes_each_quarter
`yes`, `no`, `on_event`, `uncertain`. A single workbook cannot show how often a value changes, so
this field is always a proposal. For assumptions, end the notes with "cadence proposed, not
evidenced". Cadence never raises confidence.

## confidence (evidence, not a feeling)
- `high` the label and the dependency path both support the type (e.g. "Revenue" row feeding EBITDA).
- `medium` either the label or the path supports it, not both.
- `low` based only on sheet name, column position, or similar patterns. Also use for anything
  with a FLAG.
- `uncertain` type always pairs with `low`.

## notes (required, one or two sentences)
Cite the label and the path from `paths_to_key_outputs`. If the block has `flags`, address each
flag. No general-knowledge claims.

## Grouping many similar blocks
Blocks with the same label pattern on the same sheet may share wording, but each needs its own
entry and its own confidence. Do not raise confidence because many blocks look alike.
