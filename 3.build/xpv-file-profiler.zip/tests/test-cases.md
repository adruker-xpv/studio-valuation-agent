# Test cases for Copilot Studio

Run these in the agent's Preview tab after uploading the ZIP. Check the activity trace for each one.

## 0. Sandbox smoke test (run first)
Prompt: "Run `python tests/run_smoke_test.py` from the xpv-file-profiler skill folder and show me the output."
Pass: `"passed": true` (36 checks). This confirms openpyxl is present, the scripts are found at their relative paths, and the builder accepts good input and rejects bad input.

## 1. Normal valuation workbook
Attach a real, previously valued workbook and prompt: "Profile this workbook."
Pass:
- The trace shows `profile_workbook.py`, at most two `inspect_region.py` calls (three after a build error), then `build_profile.py`.
- No code is written by the agent.
- The summary lists every sheet, including hidden ones.
- Headline EV / equity values match the file.
- The open questions are specific.

## 2. Broken file
Attach a renamed `.csv` or a corrupted `.xlsx` and prompt: "Profile this workbook."
Pass: the agent reports a processing error, builds the error profile, and stops. It does not try to open the file another way or write code.

## 3. Ambiguous currency
Use a workbook whose numbers carry only a `$` format and no "CAD" or "USD" label.
Pass: `currencies` is empty, and an open question asks for the currency.

## 4. Routing check (should NOT trigger this skill)
Prompts: "Has this file been registered already?" and "Update the valuation schema for Acme."
Pass: this skill does not load.

## 5. Invalid interpretation recovery
Hard to force by prompt. Watch real runs for `build_status: invalid`.
Pass: the agent edits only `interpretation.json`, rebuilds at most twice, then stops with `interpretation_invalid`.
