#!/usr/bin/env python3
"""XPV File Profiler - drill-down reader.

Reads exact cell contents for one or more ranges and appends them to a
supplements file. Use it when the overview in observations.json is not
enough to support an interpretation (headline valuation cells, period
header rows, units notes, truncated sheets).

Usage:
    python scripts/inspect_region.py --input <workbook> \
        --region "Valuation Summary!A1:H40" --region "P&L!A1:Z6" \
        --reason "locate EV and period headers" \
        --supplements <work>/supplements.json

Region format: <sheet name>!<range>. The last "!" separates sheet and range.
Batch all regions for a question into one call. Always exits 0.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import date, datetime, time
from pathlib import Path

SCRIPT_VERSION = "3.1.0"
MAX_REGION_CELLS = 2500     # e.g. A1:Z96
MAX_CALL_CELLS = 7500
MAX_HIDDEN = 100
MAX_TEXT = 500


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def jsonable(x):
    if isinstance(x, (datetime, date, time)):
        return x.isoformat()
    if x is None or isinstance(x, (str, bool, int, float)):
        return x
    return str(x)


def parse_region(text: str):
    if "!" not in text:
        raise ValueError(f"region '{text}' must look like 'Sheet name!A1:H40'")
    sheet, rng = text.rsplit("!", 1)
    sheet = sheet.strip()
    if len(sheet) >= 2 and sheet[0] == sheet[-1] == "'":
        sheet = sheet[1:-1].replace("''", "'")
    return sheet, rng.strip().replace("$", "").upper()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", required=True)
    ap.add_argument("--region", action="append", required=True)
    ap.add_argument("--supplements", required=True)
    ap.add_argument("--reason", default=None)
    args = ap.parse_args()
    src, sup_path = Path(args.input), Path(args.supplements)
    result = {"status": "completed", "added": [], "already_present": [], "region_errors": [],
              "supplements": str(sup_path), "error": None}

    try:
        from openpyxl import load_workbook
        from openpyxl.utils.cell import range_boundaries, get_column_letter

        sha = digest(src)
        if sup_path.is_file():
            store = json.loads(sup_path.read_text(encoding="utf-8"))
            if store.get("sha256") != sha:
                raise ValueError("supplements file belongs to a different workbook (sha256 mismatch); "
                                 "use a new supplements path for this file")
        else:
            sup_path.parent.mkdir(parents=True, exist_ok=True)
            store = {"sha256": sha, "file_name": src.name, "script_version": SCRIPT_VERSION,
                     "supplements": []}

        existing = {(s["sheet"], s["range"]): s["supplement_id"]
                    for s in store["supplements"] if s.get("status") == "ok"}
        keep_vba = src.suffix.lower() in {".xlsm", ".xltm"}
        wb = load_workbook(src, data_only=False, keep_vba=keep_vba)
        cwb = load_workbook(src, data_only=True, keep_vba=keep_vba)
        worksheet_names = [ws.title for ws in wb.worksheets]
        call_cells = 0

        for raw in args.region:
            record = {"supplement_id": f"S{len(store['supplements']) + 1}", "requested": raw,
                      "sheet": None, "range": None, "reason": args.reason, "status": "ok",
                      "error": None, "cells": [], "merged_ranges": [], "hidden_rows": [],
                      "hidden_columns": [], "script_version": SCRIPT_VERSION}
            try:
                sheet, rng = parse_region(raw)
                record["sheet"], record["range"] = sheet, rng
                if sheet not in worksheet_names:
                    raise ValueError(f"worksheet '{sheet}' not found; worksheets are: {worksheet_names}")
                min_col, min_row, max_col, max_row = range_boundaries(rng)
                if None in (min_col, min_row, max_col, max_row):
                    raise ValueError("whole-row or whole-column ranges are not allowed; give a bounded range")
                n = (max_row - min_row + 1) * (max_col - min_col + 1)
                if n > MAX_REGION_CELLS:
                    raise ValueError(f"range has {n} cells; limit is {MAX_REGION_CELLS} per region. "
                                     "Request a smaller range")
                if call_cells + n > MAX_CALL_CELLS:
                    raise ValueError(f"call limit of {MAX_CALL_CELLS} cells reached; request this region in a later call")
                rng = f"{get_column_letter(min_col)}{min_row}:{get_column_letter(max_col)}{max_row}"
                record["range"] = rng
                if (sheet, rng) in existing:
                    result["already_present"].append({"region": raw, "supplement_id": existing[(sheet, rng)]})
                    continue
                call_cells += n

                ws, cws = wb[sheet], cwb[sheet]
                cells = getattr(ws, "_cells", {})
                ccells = getattr(cws, "_cells", {})
                for r in range(min_row, max_row + 1):
                    for c in range(min_col, max_col + 1):
                        cell = cells.get((r, c))
                        if cell is None or cell.value is None:
                            continue
                        v = cell.value
                        formula = (cell.data_type == "f" or (isinstance(v, str) and v.startswith("="))
                                   or type(v).__name__ in {"ArrayFormula", "DataTableFormula"})
                        cached = ccells.get((r, c))
                        entry = {"cell": cell.coordinate, "is_formula": formula,
                                 "number_format": cell.number_format}
                        if formula:
                            entry["formula"] = getattr(v, "text", None) or str(v)
                            entry["value"] = jsonable(cached.value) if cached is not None else None
                        else:
                            val = jsonable(v)
                            if isinstance(val, str) and len(val) > MAX_TEXT:
                                val = val[:MAX_TEXT] + "..."
                            entry["value"] = val
                        record["cells"].append(entry)

                for m in ws.merged_cells.ranges:
                    if not (m.max_row < min_row or m.min_row > max_row or
                            m.max_col < min_col or m.min_col > max_col):
                        record["merged_ranges"].append(str(m))
                record["hidden_rows"] = [r for r in range(min_row, max_row + 1)
                                         if r in ws.row_dimensions and ws.row_dimensions[r].hidden][:MAX_HIDDEN]
                record["hidden_columns"] = [get_column_letter(c) for c in range(min_col, max_col + 1)
                                            if get_column_letter(c) in ws.column_dimensions
                                            and ws.column_dimensions[get_column_letter(c)].hidden][:MAX_HIDDEN]
                store["supplements"].append(record)
                existing[(sheet, rng)] = record["supplement_id"]
                result["added"].append({"supplement_id": record["supplement_id"],
                                        "index": len(store["supplements"]) - 1,
                                        "sheet": sheet, "range": rng,
                                        "non_empty_cells": len(record["cells"])})
            except Exception as e:
                result["region_errors"].append({"region": raw, "error": f"{type(e).__name__}: {e}"})

        sup_path.write_text(json.dumps(store, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        result["status"] = "processing_error"
        result["error"] = {"error_type": type(e).__name__, "error_message": str(e),
                           "dependent_work_blocked": False, "retry_safe": False}

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
