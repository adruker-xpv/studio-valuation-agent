#!/usr/bin/env python3
"""XPV File Profiler - layer 1: deterministic workbook observations.

Reads one Excel workbook and writes an observations JSON file. It records
what is physically in the file and never interprets methodology.

Usage:
    python scripts/profile_workbook.py --input <workbook> --output <work>/observations.json

Always exits 0. Read `profile_status` in the output ("completed" or
"processing_error") to decide what happens next.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from collections import Counter
from datetime import date, datetime, time
from pathlib import Path

SCRIPT_VERSION = "3.2.0"
CONTRACT_VERSION = "3.2.0"

SUPPORTED_EXTENSIONS = {".xlsx", ".xlsm", ".xltx", ".xltm"}
MAX_ROWS = 2500            # scan window per worksheet
MAX_COLS = 300
MAX_LABELS = 120           # stored text labels per sheet
MAX_FORMULA_SAMPLES = 150  # stored formula cells per sheet
MAX_HEADERS = 120          # stored date/period-like cells per sheet
MAX_MERGED = 50
MAX_NUMBER_FORMATS = 15
MAX_DEFINED_NAMES = 200
MAX_TEXT = 250

SKILL_ROOT = Path(__file__).resolve().parent.parent
RULES_PATH = SKILL_ROOT / "references" / "classification-rules.json"

# ----------------------------------------------------------------------------
# Period / date token patterns (shared by sheet names, filenames and headers)
# ----------------------------------------------------------------------------
MONTH = (r"(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|"
         r"jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)")
YEAR4 = r"(?:19|20)\d{2}"

# (rule_id, regex, placeholder builder). First match wins; only one token is replaced.
NAME_PATTERNS = [
    ("month_year4", re.compile(rf"\b(?P<m>{MONTH})(?P<sep>[\s\-_.']*)(?P<y>{YEAR4})\b", re.I),
     lambda g: ("{Mon}" if len(g["m"]) <= 4 else "{Month}") + g["sep"] + "{YYYY}"),
    ("year4_month", re.compile(rf"\b(?P<y>{YEAR4})(?P<sep>[\-_./])(?P<mm>0?[1-9]|1[0-2])\b"),
     lambda g: "{YYYY}" + g["sep"] + "{MM}"),
    ("month_num_year4", re.compile(rf"\b(?P<mm>0?[1-9]|1[0-2])(?P<sep>[\-_./])(?P<y>{YEAR4})\b"),
     lambda g: "{MM}" + g["sep"] + "{YYYY}"),
    ("quarter_year", re.compile(rf"\bQ(?P<q>[1-4])(?P<sep>[\s\-_']*)(?P<y>{YEAR4}|\d{{2}})\b", re.I),
     lambda g: "Q{n}" + g["sep"] + ("{YYYY}" if len(g["y"]) == 4 else "{YY}")),
    ("year_quarter", re.compile(rf"\b(?P<y>{YEAR4})(?P<sep>[\s\-_]*)Q(?P<q>[1-4])\b", re.I),
     lambda g: "{YYYY}" + g["sep"] + "Q{n}"),
    ("fiscal_year", re.compile(rf"\bFY(?P<sep>[\s\-_']*)(?P<y>{YEAR4}|\d{{2}})\b", re.I),
     lambda g: "FY" + g["sep"] + ("{YYYY}" if len(g["y"]) == 4 else "{YY}")),
    ("month_year2", re.compile(rf"\b(?P<m>{MONTH})(?P<sep>[\s\-_.']*)(?P<y>\d{{2}})\b", re.I),
     lambda g: ("{Mon}" if len(g["m"]) <= 4 else "{Month}") + g["sep"] + "{YY}"),
    ("year4", re.compile(rf"\b(?P<y>{YEAR4})\b"), lambda g: "{YYYY}"),
]

HEADER_DATE_RE = re.compile(
    rf"\b{MONTH}\b|\b{YEAR4}\b|\bfy\s?\d{{2,4}}\b|\bq[1-4]\b|\bh[12]\b", re.I)
COLUMN_HINTS = {
    "actual": r"\bactuals?\b|\bact\b",
    "budget": r"\bbudget\b|\bbud\b|\bplan\b",
    "forecast": r"\bforecast\b|\bfcst\b|\bfcast\b|\breforecast\b",
    "prior_year": r"\bprior year\b|\bpy\b|\blast year\b",
    "variance": r"\bvariance\b|\bvar\b",
    "ytd": r"\bytd\b|\byear to date\b",
    "ltm": r"\bltm\b|\bttm\b|\blast twelve months\b",
    "quarterly": r"\bq[1-4]\b|\bqtd\b|\bquarter\b",
    "monthly": r"\bmtd\b|\bmonth\b",
}
COLUMN_HINT_RES = {k: re.compile(v, re.I) for k, v in COLUMN_HINTS.items()}

STATUS_TOKENS = {
    "final": "final", "approved": "final", "signed": "final", "executed": "final",
    "draft": "draft", "wip": "draft", "prelim": "draft", "preliminary": "draft",
}
VERSION_RE = re.compile(r"\b(?:v|ver|version|rev|revision)[\s._-]?\d+(?:\.\d+)*\b", re.I)
FULL_DATE_RE = re.compile(rf"\b{YEAR4}[-_.]?(?:0[1-9]|1[0-2])[-_.]?(?:0[1-9]|[12]\d|3[01])\b")
UPLOAD_SUFFIX_RES = [
    re.compile(r"\s*\(\d+\)$"),                                   # "Model (1)"
    re.compile(r"[\s_-]+copy(?:\s*\d+)?$", re.I),                 # "Model - Copy", "_copy2"
    re.compile(r"[\s_-][0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I),  # GUID
    re.compile(r"[\s_-](?=[0-9a-f]*\d)(?=[0-9a-f]*[a-f])[0-9a-f]{6,}$", re.I),               # hex hash
]


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def jsonable(x):
    if isinstance(x, (datetime, date, time)):
        return x.isoformat()
    if x is None or isinstance(x, (str, bool, int, float)):
        return x
    return str(x)


def clip(s: str) -> str:
    s = s.strip()
    return s if len(s) <= MAX_TEXT else s[:MAX_TEXT] + "..."


def name_pattern(name: str):
    """Replace the first supported period token in a name with a placeholder."""
    for rule_id, rx, build in NAME_PATTERNS:
        m = rx.search(name)
        if m:
            placeholder = build(m.groupdict())
            pattern = name[:m.start()] + placeholder + name[m.end():]
            return {"pattern": pattern, "matched_token": m.group(0), "rule": rule_id}
    return None


def normalize_text(s: str) -> str:
    s = s.lower().replace("&", " and ")
    s = re.sub(r"[^a-z0-9/]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def load_rules():
    try:
        data = json.loads(RULES_PATH.read_text(encoding="utf-8"))
        return data, None
    except Exception as e:  # rules file missing or malformed -> no candidates, but say so
        return None, f"classification rules not loaded: {type(e).__name__}: {e}"


def compile_rules(rules):
    compiled = {}
    for typ, groups in rules["types"].items():
        compiled[typ] = []
        for strength in ("strong", "weak"):
            for kw in groups.get(strength, []):
                norm = normalize_text(kw)
                rx = re.compile(rf"(?<![a-z0-9]){re.escape(norm)}(?![a-z0-9])")
                compiled[typ].append((kw, strength, rx))
    return compiled


def candidate_types(sheet_index, name, labels, compiled, scoring):
    """Keyword scoring. Returns suggestions with the pointers that justify them."""
    if not compiled:
        return []
    norm_name = normalize_text(name)
    norm_labels = [normalize_text(l["text"]) for l in labels]
    base = f"/observations/sheets/{sheet_index}"
    out = []
    for typ, entries in compiled.items():
        score, matched, pointers = 0, [], []
        for kw, strength, rx in entries:
            hit = False
            if rx.search(norm_name):
                score += scoring[f"{strength}_in_name"]
                pointers.append(f"{base}/observed_name")
                hit = True
            label_hits = [i for i, t in enumerate(norm_labels) if rx.search(t)]
            if label_hits:
                score += scoring[f"{strength}_in_labels"]
                pointers.extend(f"{base}/representative_labels/{i}" for i in label_hits[:3])
                hit = True
            if hit:
                matched.append({"keyword": kw, "strength": strength,
                                "in_name": bool(rx.search(norm_name)),
                                "label_hit_count": len(label_hits)})
        if score:
            out.append({"type": typ, "score": score, "matched": matched,
                        "evidence_pointers": sorted(set(pointers), key=pointers.index)})
    out.sort(key=lambda c: (-c["score"], c["type"]))
    return out[:5]


def iter_existing_cells(ws, max_row, max_col):
    """Yield only cells that exist in the file, in row/column order, inside the window."""
    cells = getattr(ws, "_cells", None)
    if isinstance(cells, dict):
        for key in sorted(k for k in cells if k[0] <= max_row and k[1] <= max_col):
            yield cells[key]
    else:  # fallback for a future openpyxl without _cells
        for row in ws.iter_rows(min_row=1, max_row=max_row, min_col=1, max_col=max_col):
            yield from row


def count_outside_window(ws, max_row, max_col):
    cells = getattr(ws, "_cells", None)
    if not isinstance(cells, dict):
        return None
    return sum(1 for (r, c), cell in cells.items()
               if (r > max_row or c > max_col) and cell.value is not None)


def cached_value(cached_ws, row, col):
    if cached_ws is None:
        return None
    cells = getattr(cached_ws, "_cells", None)
    if isinstance(cells, dict):
        c = cells.get((row, col))
        return jsonable(c.value) if c is not None else None
    return jsonable(cached_ws.cell(row=row, column=col).value)


def is_formula(cell) -> bool:
    v = cell.value
    return (cell.data_type == "f"
            or (isinstance(v, str) and v.startswith("="))
            or type(v).__name__ in {"ArrayFormula", "DataTableFormula"})


def formula_text(v) -> str:
    return getattr(v, "text", None) or str(v)


def bbox_update(box, r, c):
    if box is None:
        return [r, c, r, c]
    return [min(box[0], r), min(box[1], c), max(box[2], r), max(box[3], c)]


def bbox_str(box, get_column_letter):
    if box is None:
        return None
    return f"{get_column_letter(box[1])}{box[0]}:{get_column_letter(box[3])}{box[2]}"


def inspect_worksheet(index, ws, cached_ws, compiled, scoring, get_column_letter):
    used_rows = max(ws.max_row or 1, 1)
    used_cols = max(ws.max_column or 1, 1)
    scan_rows, scan_cols = min(used_rows, MAX_ROWS), min(used_cols, MAX_COLS)

    labels, formulas, headers = [], [], []
    populated = formula_count = hard_numeric = date_values = 0
    formula_box = hard_box = None
    formats = Counter()
    format_example = {}

    for cell in iter_existing_cells(ws, scan_rows, scan_cols):
        v = cell.value
        if v is None:
            continue
        populated += 1
        r, c = cell.row, cell.column
        if is_formula(cell):
            formula_count += 1
            formula_box = bbox_update(formula_box, r, c)
            if len(formulas) < MAX_FORMULA_SAMPLES:
                formulas.append({"cell": cell.coordinate, "formula": formula_text(v),
                                 "cached_value": cached_value(cached_ws, r, c),
                                 "number_format": cell.number_format})
            numeric_like = True
        elif isinstance(v, bool):
            numeric_like = False
        elif isinstance(v, (int, float)):
            hard_numeric += 1
            hard_box = bbox_update(hard_box, r, c)
            numeric_like = True
        elif isinstance(v, (datetime, date)):
            date_values += 1
            numeric_like = False
            if len(headers) < MAX_HEADERS:
                headers.append({"cell": cell.coordinate, "value": jsonable(v),
                                "kind": "date_value", "column_hints": []})
        elif isinstance(v, str) and v.strip():
            numeric_like = False
            text = clip(v)
            if len(labels) < MAX_LABELS:
                labels.append({"cell": cell.coordinate, "text": text})
            if len(text) <= 60 and len(headers) < MAX_HEADERS:
                hints = sorted(k for k, rx in COLUMN_HINT_RES.items() if rx.search(text))
                if HEADER_DATE_RE.search(text) or hints:
                    headers.append({"cell": cell.coordinate, "value": text,
                                    "kind": "period_text" if HEADER_DATE_RE.search(text) else "column_label",
                                    "column_hints": hints})
        else:
            numeric_like = False
        if numeric_like and cell.number_format and cell.number_format != "General":
            formats[cell.number_format] += 1
            format_example.setdefault(cell.number_format, cell.coordinate)

    try:
        merged = [str(m) for m in ws.merged_cells.ranges]
    except Exception:
        merged = []

    truncated = scan_rows < used_rows or scan_cols < used_cols
    pat = name_pattern(ws.title)
    return {
        "position": index,
        "observed_name": ws.title,
        "normalized_name_pattern": pat["pattern"] if pat else None,
        "name_pattern_detail": pat,
        "visibility": ws.sheet_state,
        "sheet_kind": "worksheet",
        "used_range": ws.calculate_dimension(),
        "scan_window": {"rows_scanned": scan_rows, "columns_scanned": scan_cols,
                        "used_rows": used_rows, "used_columns": used_cols},
        "truncated": truncated,
        "populated_cells_outside_window": count_outside_window(ws, scan_rows, scan_cols) if truncated else 0,
        "counts": {"populated_cells": populated, "formula_cells": formula_count,
                   "hardcoded_numeric_cells": hard_numeric, "date_value_cells": date_values,
                   "text_label_cells_stored": len(labels)},
        "formula_share": round(formula_count / populated, 6) if populated else 0,
        "formula_share_scope": "scan_window",
        "formula_bounding_range": bbox_str(formula_box, get_column_letter),
        "hardcoded_numeric_bounding_range": bbox_str(hard_box, get_column_letter),
        "number_formats": [{"format": f, "count": n, "example_cell": format_example[f]}
                           for f, n in formats.most_common(MAX_NUMBER_FORMATS)],
        "merged_ranges": merged[:MAX_MERGED],
        "merged_range_count": len(merged),
        "representative_labels": labels,
        "date_like_headers": headers,
        "formula_samples": formulas,
        "candidate_types": candidate_types(index, ws.title, labels, compiled, scoring),
    }


def chartsheet_entry(index, cs):
    pat = name_pattern(cs.title)
    return {"position": index, "observed_name": cs.title,
            "normalized_name_pattern": pat["pattern"] if pat else None,
            "name_pattern_detail": pat, "visibility": cs.sheet_state,
            "sheet_kind": "chartsheet", "truncated": False, "candidate_types": []}


def analyze_filename(file_name: str):
    """Mechanical filename decomposition. The agent confirms or rejects the result."""
    stem = Path(file_name).stem
    work = stem
    upload_suffix = None
    for rx in UPLOAD_SUFFIX_RES:
        m = rx.search(work)
        if m:
            upload_suffix = m.group(0).strip()
            work = work[:m.start()]
            break

    removed = []
    status_tokens = []
    for token in re.findall(r"[A-Za-z]+", work):
        meaning = STATUS_TOKENS.get(token.lower())
        if meaning:
            status_tokens.append({"token": token, "indicates": meaning})

    def strip(rx, kind):
        nonlocal work
        for m in list(rx.finditer(work)):
            removed.append({"token": m.group(0), "kind": kind})
        work = rx.sub(" ", work)

    strip(FULL_DATE_RE, "date")
    strip(VERSION_RE, "version")
    for rule_id, rx, _ in NAME_PATTERNS:
        strip(rx, "period:" + rule_id)
    for token in STATUS_TOKENS:
        strip(re.compile(rf"\b{token}\b", re.I), "status")

    family = normalize_text(re.sub(r"[_\-.]+", " ", work))
    return {
        "stem": stem,
        "upload_suffix": upload_suffix,
        "status_tokens": status_tokens,
        "removed_tokens": removed,
        "period_tokens": [t["token"] for t in removed if t["kind"].startswith("period") or t["kind"] == "date"],
        "version_tokens": [t["token"] for t in removed if t["kind"] == "version"],
        "family_candidate": family or None,
    }


def workbook_properties(wb):
    p = wb.properties
    keys = ["title", "subject", "creator", "lastModifiedBy", "created", "modified",
            "keywords", "description", "category"]
    return {k: jsonable(getattr(p, k, None)) for k in keys}


def defined_names(wb, warnings):
    out = []
    try:
        dn = wb.defined_names
        items = list(dn.items()) if hasattr(dn, "items") else [(d.name, d) for d in getattr(dn, "definedName", [])]
        for name, d in items:
            out.append({"name": name, "scope": "workbook", "refers_to": d.attr_text,
                        "hidden": bool(getattr(d, "hidden", False))})
        for ws in wb.worksheets:
            sdn = getattr(ws, "defined_names", None)
            if sdn and hasattr(sdn, "items"):
                for name, d in sdn.items():
                    out.append({"name": name, "scope": ws.title, "refers_to": d.attr_text,
                                "hidden": bool(getattr(d, "hidden", False))})
    except Exception as e:
        warnings.append(f"defined names not read: {type(e).__name__}: {e}")
    return out[:MAX_DEFINED_NAMES]


def error_output(identity, kind, e_type, message, warnings):
    return {
        "profile_contract_version": CONTRACT_VERSION,
        "script_version": SCRIPT_VERSION,
        "profile_status": "processing_error",
        "identity": identity,
        "observations": {"workbook": None, "sheets": []},
        "warnings": warnings,
        "processing_error": {"error_kind": kind, "error_type": e_type, "error_message": message,
                             "dependent_work_blocked": True, "retry_safe": False},
    }


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    src, dst = Path(args.input), Path(args.output)
    warnings: list[str] = []
    identity = {"file_name": src.name, "extension": src.suffix.lower(), "sha256": None,
                "size": None, "filename_analysis": analyze_filename(src.name)}

    try:
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not src.is_file():
            out = error_output(identity, "file_unreadable", "FileNotFoundError",
                               f"input file not found: {src}", warnings)
        else:
            identity["sha256"] = digest(src)
            identity["size"] = src.stat().st_size
            if identity["extension"] not in SUPPORTED_EXTENSIONS:
                out = error_output(identity, "unsupported_file_type", "UnsupportedFileType",
                                   f"extension {identity['extension']} is not an Excel Open XML workbook", warnings)
            else:
                out = profile(src, identity, warnings)
    except Exception as e:  # anything unexpected becomes a clean, reportable error
        out = error_output(identity, "file_unreadable", type(e).__name__, str(e), warnings)

    dst.write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    sheets = out["observations"]["sheets"]
    print(json.dumps({
        "profile_status": out["profile_status"],
        "sha256": identity["sha256"],
        "sheet_count": len(sheets),
        "hidden_sheets": [s["observed_name"] for s in sheets if s["visibility"] != "visible"],
        "truncated_sheets": [s["observed_name"] for s in sheets if s.get("truncated")],
        "error": out["processing_error"],
        "output": str(dst),
    }))


def profile(src, identity, warnings):
    from openpyxl import load_workbook
    from openpyxl.utils import get_column_letter

    keep_vba = identity["extension"] in {".xlsm", ".xltm"}
    wb = load_workbook(src, data_only=False, keep_vba=keep_vba)
    try:
        cached_wb = load_workbook(src, data_only=True, keep_vba=keep_vba)
        cached_by_name = {ws.title: ws for ws in cached_wb.worksheets}
    except Exception as e:
        cached_by_name = {}
        warnings.append(f"cached values unavailable: {type(e).__name__}: {e}")

    rules, rules_warning = load_rules()
    if rules_warning:
        warnings.append(rules_warning)
    compiled = compile_rules(rules) if rules else None
    scoring = rules["scoring"] if rules else None

    sheets = []
    chart_titles = {cs.title for cs in wb.chartsheets}
    for index, name in enumerate(wb.sheetnames):
        obj = wb[name]
        if name in chart_titles:
            sheets.append(chartsheet_entry(index, obj))
        else:
            sheets.append(inspect_worksheet(index, obj, cached_by_name.get(name),
                                            compiled, scoring, get_column_letter))

    if cached_by_name and all(
            f["cached_value"] is None for s in sheets for f in s.get("formula_samples", [])) \
            and any(s.get("formula_samples") for s in sheets):
        warnings.append("no cached formula values found; the file may never have been "
                        "recalculated in Excel, so formula results are unknown")

    return {
        "profile_contract_version": CONTRACT_VERSION,
        "script_version": SCRIPT_VERSION,
        "profile_status": "completed",
        "identity": identity,
        "observations": {
            "workbook": {
                "properties": workbook_properties(wb),
                "defined_names": defined_names(wb, warnings),
                "sheet_count": len(sheets),
                "worksheet_count": len(wb.worksheets),
                "chartsheet_count": len(wb.chartsheets),
                "rules_version": rules.get("rules_version") if rules else None,
                "limits": {"max_rows": MAX_ROWS, "max_cols": MAX_COLS, "max_labels": MAX_LABELS,
                           "max_formula_samples": MAX_FORMULA_SAMPLES},
            },
            "sheets": sheets,
        },
        "warnings": warnings,
        "processing_error": None,
    }


if __name__ == "__main__":
    main()
