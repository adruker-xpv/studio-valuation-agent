#!/usr/bin/env python3
"""XPV File Profiler - read-only viewer for observations and supplements.

Prints the observations in readable form, with the JSON pointer for each
item so it can be cited directly in interpretation.json. Use this instead
of opening or parsing the JSON yourself.

Usage:
    python scripts/view_observations.py --observations <work>/observations.json
        overview of the workbook: identity, properties, named ranges, one line per sheet
    python scripts/view_observations.py --observations <work>/observations.json --sheet 2
    python scripts/view_observations.py --observations <work>/observations.json --sheet "Valuation Summary"
        everything stored for one sheet: labels, period headers, formats, formulas, candidates
    python scripts/view_observations.py --observations <work>/observations.json --supplements <work>/supplements.json
        every drill-down cell with its pointer
Optional: --limit N (items per section, default 120). Always exits 0.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def out(line=""):
    print(line)


def show_overview(o):
    ident = o["identity"]
    fa = ident.get("filename_analysis") or {}
    out(f"FILE {ident['file_name']}  status={o['profile_status']}  sha256={str(ident.get('sha256'))[:12]}...")
    out(f"  /identity/filename_analysis/family_candidate = {fa.get('family_candidate')!r}")
    for i, t in enumerate(fa.get("status_tokens", [])):
        out(f"  /identity/filename_analysis/status_tokens/{i} = {t['token']!r} (indicates {t['indicates']})")
    for i, t in enumerate(fa.get("period_tokens", [])):
        out(f"  /identity/filename_analysis/period_tokens/{i} = {t!r}")
    for i, t in enumerate(fa.get("version_tokens", [])):
        out(f"  /identity/filename_analysis/version_tokens/{i} = {t!r}")
    if o.get("processing_error"):
        out(f"PROCESSING ERROR: {o['processing_error']}")
        return
    wb = o["observations"]["workbook"]
    out("WORKBOOK PROPERTIES")
    for k, v in (wb.get("properties") or {}).items():
        if v not in (None, ""):
            out(f"  /observations/workbook/properties/{k} = {v!r}")
    if wb.get("defined_names"):
        out("NAMED RANGES")
        for i, d in enumerate(wb["defined_names"]):
            out(f"  /observations/workbook/defined_names/{i}  {d['name']} -> {d['refers_to']} ({d['scope']})")
    out("SHEETS  (position | name | visibility | kind | pattern | truncated | populated/formulas | top candidate)")
    for s in o["observations"]["sheets"]:
        c = s.get("counts") or {}
        cand = s.get("candidate_types") or []
        top = f"{cand[0]['type']}({cand[0]['score']})" if cand else "-"
        out(f"  {s['position']} | {s['observed_name']!r} | {s['visibility']} | {s['sheet_kind']} | "
            f"{s.get('normalized_name_pattern') or '-'} | {'TRUNCATED' if s.get('truncated') else 'no'} | "
            f"{c.get('populated_cells', '-')}/{c.get('formula_cells', '-')} | {top}")
    for w in o.get("warnings", []):
        out(f"WARNING {w}")
    out("NEXT: view one sheet with --sheet <position or exact name>.")


def find_sheet(o, key):
    sheets = o["observations"]["sheets"]
    if key.isdigit() and int(key) < len(sheets):
        return sheets[int(key)]
    return next((s for s in sheets if s["observed_name"] == key), None)


def show_sheet(o, s, limit):
    p = f"/observations/sheets/{s['position']}"
    out(f"SHEET {s['position']} {s['observed_name']!r}  visibility={s['visibility']}  kind={s['sheet_kind']}")
    out(f"  {p}/observed_name   pattern={s.get('normalized_name_pattern')}")
    if s["sheet_kind"] != "worksheet":
        out("  chartsheet: no cells.")
        return
    out(f"  used_range={s.get('used_range')}  truncated={s.get('truncated')}  "
        f"formula_share={s.get('formula_share')}  formulas_in={s.get('formula_bounding_range')}  "
        f"hardcoded_numbers_in={s.get('hardcoded_numeric_bounding_range')}")
    out("CANDIDATE TYPES")
    for i, c in enumerate(s.get("candidate_types", [])):
        kws = ", ".join(m["keyword"] for m in c["matched"])
        out(f"  {p}/candidate_types/{i}  {c['type']} score={c['score']} keywords=[{kws}]")
    sections = [("LABELS", "representative_labels", lambda x: f"{x['cell']}: {x['text']!r}"),
                ("PERIOD / COLUMN HEADERS", "date_like_headers",
                 lambda x: f"{x['cell']}: {x['value']!r} {x['kind']} hints={x.get('column_hints')}"),
                ("NUMBER FORMATS", "number_formats",
                 lambda x: f"{x['format']!r} x{x['count']} e.g. {x['example_cell']}"),
                ("FORMULAS", "formula_samples",
                 lambda x: f"{x['cell']}: {x['formula']}  cached={x.get('cached_value')!r}")]
    for title, key, fmt in sections:
        items = s.get(key, [])
        out(f"{title} ({len(items)} stored)")
        for i, x in enumerate(items[:limit]):
            out(f"  {p}/{key}/{i}  {fmt(x)}")
        if len(items) > limit:
            out(f"  ... {len(items) - limit} more; rerun with a larger --limit")
    if s.get("merged_ranges"):
        out(f"MERGED RANGES ({s.get('merged_range_count')}): {', '.join(s['merged_ranges'][:20])}")
    out("NEXT: if a value cell or header is missing, drill down with inspect_region.py.")


def show_supplements(sup, limit):
    for i, r in enumerate(sup.get("supplements", [])):
        out(f"SUPPLEMENT {i} ({r['supplement_id']}) {r['sheet']!r}!{r['range']}  reason={r.get('reason')!r}")
        if r.get("hidden_rows") or r.get("hidden_columns"):
            out(f"  hidden rows={r.get('hidden_rows')} hidden columns={r.get('hidden_columns')}")
        for j, c in enumerate(r.get("cells", [])[:limit]):
            f = f"  formula={c['formula']}" if c.get("is_formula") else ""
            out(f"  /observations/supplements/{i}/cells/{j}  {c['cell']}: {c.get('value')!r}{f}  fmt={c.get('number_format')!r}")
        if len(r.get("cells", [])) > limit:
            out(f"  ... {len(r['cells']) - limit} more; rerun with a larger --limit")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--observations", required=True)
    ap.add_argument("--sheet")
    ap.add_argument("--supplements")
    ap.add_argument("--limit", type=int, default=120)
    a = ap.parse_args()
    try:
        o = json.loads(Path(a.observations).read_text(encoding="utf-8"))
        if a.supplements:
            show_supplements(json.loads(Path(a.supplements).read_text(encoding="utf-8")), a.limit)
        elif a.sheet is not None:
            s = find_sheet(o, a.sheet)
            if s is None:
                names = [x["observed_name"] for x in o["observations"]["sheets"]]
                out(f"No sheet {a.sheet!r}. Use a position or one of: {names}")
            else:
                show_sheet(o, s, a.limit)
        else:
            show_overview(o)
    except Exception as e:
        out(f"VIEW ERROR {type(e).__name__}: {e}. Report this; do not parse the JSON another way.")


if __name__ == "__main__":
    main()
