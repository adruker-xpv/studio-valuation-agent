#!/usr/bin/env python3
"""XPV File Profiler - builder. The only writer of the final profile.

Combines the script's observations (unchanged), optional drill-down
supplements, and the agent's small interpretation file. It checks every
citation, fills values from the workbook instead of trusting the agent's
transcription, adds open questions for anything unresolved, validates, and
writes the final profile JSON plus a short Markdown summary.

Usage:
    python scripts/build_profile.py \
        --observations <work>/observations.json \
        --interpretation <work>/interpretation.json \
        [--supplements <work>/supplements.json] \
        --output <work>/profile.json --summary <work>/profile-summary.md

For a processing_error observations file, omit --interpretation.
Always exits 0. Read "build_status": "valid" or "invalid".
"""
from __future__ import annotations

import argparse
import copy
import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from schema_check import validate  # noqa: E402

BUILDER_VERSION = "3.1.0"
CONTRACT_VERSION = "3.1.0"
SKILL_ROOT = Path(__file__).resolve().parent.parent
SCHEMAS = SKILL_ROOT / "schemas"

SCALAR_FIELDS = ["file_role", "status", "family", "company_name_in_file", "period_end",
                 "actuals_through", "periods_covered", "valuation_method_observation"]
LIST_FIELDS = ["roles_present", "entities", "currencies", "units"]
COMPLETENESS_FIELDS = ["file_role", "status", "family", "company_name_in_file", "period_end",
                       "actuals_through", "periods_covered", "entities", "currencies", "units"]
VALUATION_ONLY = ["valuation_outputs", "valuation_method_observation"]
ALLOWED_PREFIXES = ("/identity/", "/observations/")
QUESTION_TEXT = {
    "file_role": "What is this file's primary role? The workbook contents did not establish it.",
    "status": "Is this file final or draft? Neither the filename nor the contents established it.",
    "family": "Which file family does this belong to? The filename could not be reduced to a family.",
    "company_name_in_file": "Which company does this file cover? No company name was found inside the file.",
    "period_end": "What period end does this file represent?",
    "actuals_through": "Through which month are actuals included?",
    "periods_covered": "What date range and frequency does this file cover?",
    "entities": "Which legal entities or business units does this file cover?",
    "currencies": "What currency are the figures in? No explicit currency was established.",
    "units": "What units are the figures in (ones, thousands, millions)?",
    "valuation_outputs": "Where are the headline valuation outputs (EV, equity value, fund interest)?",
    "valuation_method_observation": "Which valuation method labels appear in this workbook?",
}


class BuildErrors(Exception):
    def __init__(self, errors):
        super().__init__(f"{len(errors)} error(s)")
        self.errors = errors


def resolve(doc, pointer):
    node = doc
    for raw in pointer[1:].split("/"):
        part = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(node, list):
            if not part.isdigit() or int(part) >= len(node):
                raise KeyError(pointer)
            node = node[int(part)]
        elif isinstance(node, dict):
            if part not in node:
                raise KeyError(pointer)
            node = node[part]
        else:
            raise KeyError(pointer)
    return node


def preview(value):
    if isinstance(value, dict):
        for key in ("text", "value", "formula", "name", "pattern", "family_candidate", "observed_name", "type"):
            if key in value and value[key] is not None:
                cell = value.get("cell")
                shown = f"{cell}: {value[key]}" if cell else value[key]
                return shown if isinstance(shown, str) else json.dumps(shown)[:200]
        return json.dumps(value, ensure_ascii=False)[:200]
    if isinstance(value, list):
        return f"[list of {len(value)}]"
    return value if not isinstance(value, str) else value[:200]


def check_pointers(doc, pointers, where, errors, need_observation=False):
    resolved = []
    for p in pointers:
        if not p.startswith(ALLOWED_PREFIXES):
            errors.append({"path": where, "message": f"evidence '{p}' must start with /identity/ or /observations/"})
            continue
        try:
            resolved.append({"pointer": p, "value": preview(resolve(doc, p))})
        except KeyError:
            errors.append({"path": where, "message": f"evidence '{p}' does not exist in the observations"})
    if need_observation and pointers and not any(p.startswith("/observations/") for p in pointers):
        errors.append({"path": where, "message": "needs at least one pointer inside the workbook "
                                                 "(/observations/...); the filename alone is not enough"})
    return resolved


def check_dates(interp, errors):
    for field in ("period_end", "actuals_through"):
        v = interp[field]["value"]
        if v:
            fmt = "%Y-%m-%d" if len(v) == 10 else "%Y-%m"
            try:
                datetime.strptime(v, fmt)
            except ValueError:
                errors.append({"path": f"/{field}/value", "message": f"{v!r} is not a real calendar date"})
    pc = interp["periods_covered"]["value"]
    if pc and pc.get("from") and pc.get("to") and pc["from"] > pc["to"]:
        errors.append({"path": "/periods_covered/value", "message": "'from' is after 'to'"})


def find_cell(doc, sheet_pos, sheet_name, cell):
    """Locate a cell in observations or supplements. Returns (pointer, value, formula) or None."""
    target = cell.replace("$", "").upper()
    sheet = doc["observations"]["sheets"][sheet_pos]
    for i, f in enumerate(sheet.get("formula_samples", [])):
        if f["cell"] == target:
            return f"/observations/sheets/{sheet_pos}/formula_samples/{i}", f.get("cached_value"), f["formula"]
    for i, sup in enumerate(doc["observations"]["supplements"]):
        if sup.get("sheet") != sheet_name:
            continue
        for j, c in enumerate(sup.get("cells", [])):
            if c["cell"] == target:
                return (f"/observations/supplements/{i}/cells/{j}", c.get("value"),
                        c.get("formula") if c.get("is_formula") else None)
    for i, lab in enumerate(sheet.get("representative_labels", [])):
        if lab["cell"] == target:
            return f"/observations/sheets/{sheet_pos}/representative_labels/{i}", lab["text"], None
    return None


def build_interpretation(doc, raw, errors):
    interp = copy.deepcopy(raw)
    auto_questions = []
    is_valuation = (interp["file_role"]["value"] == "valuation_workbook"
                    or any(r["value"] == "valuation_workbook" for r in interp["roles_present"]))
    asked = {q["field"] for q in interp["open_questions"]}

    def need_question(field, text=None):
        if field not in asked:
            auto_questions.append({"field": field, "question": text or QUESTION_TEXT.get(
                field, f"'{field}' could not be established from the file.")})
            asked.add(field)

    # Scalar fields: non-null needs resolvable evidence; null needs an open question.
    for field in SCALAR_FIELDS:
        f = interp[field]
        where = f"/{field}"
        if f["value"] is None:
            if f["evidence"]:
                errors.append({"path": where, "message": "value is null but evidence was given; "
                                                         "set a value or remove the evidence"})
            if field == "valuation_method_observation" and not is_valuation:
                f["evidence_resolved"] = []
                continue
            need_question(field)
            f["evidence_resolved"] = []
            continue
        if not f["evidence"]:
            errors.append({"path": where, "message": "a non-null value needs at least one evidence pointer"})
        f["evidence_resolved"] = check_pointers(doc, f["evidence"], where, errors,
                                                need_observation=(field == "company_name_in_file"))
    if interp["status"]["value"] == "conflict":
        need_question("status", "Filename and contents disagree about final/draft status. Which is correct?")

    # List fields: every item needs evidence; empty lists become questions.
    role = interp["file_role"]
    if role["value"] and not any(r["value"] == role["value"] for r in interp["roles_present"]):
        interp["roles_present"].insert(0, {"value": role["value"], "evidence": list(role["evidence"]),
                                           "note": "added by builder: roles_present must include file_role"})
    for field in LIST_FIELDS:
        items = interp[field]
        seen = set()
        for i, item in enumerate(items):
            if item["value"] in seen:
                errors.append({"path": f"/{field}/{i}", "message": f"duplicate value {item['value']!r}"})
            seen.add(item["value"])
            item["evidence_resolved"] = check_pointers(doc, item["evidence"], f"/{field}/{i}", errors)
        if not items and field != "roles_present":
            need_question(field)

    # Sheets: one entry per observed sheet, in workbook order.
    obs_sheets = doc["observations"]["sheets"]
    by_name = {}
    for i, s in enumerate(interp["sheets"]):
        if s["observed_name"] in by_name:
            errors.append({"path": f"/sheets/{i}", "message": f"sheet {s['observed_name']!r} listed twice"})
        by_name[s["observed_name"]] = s
    known = {s["observed_name"] for s in obs_sheets}
    for name in by_name:
        if name not in known:
            errors.append({"path": "/sheets", "message": f"sheet {name!r} is not in the workbook; "
                                                         "use the exact observed_name"})
    out_sheets, unreviewed = [], []
    for s in obs_sheets:
        pos = s["position"]
        cands = s.get("candidate_types", [])
        entry = {"position": pos, "observed_name": s["observed_name"], "visibility": s["visibility"],
                 "sheet_kind": s["sheet_kind"], "normalized_name_pattern": s.get("normalized_name_pattern"),
                 "type": None, "decided_by": "not_reviewed", "purpose_observed": None,
                 "evidence": [], "evidence_resolved": [], "note": None}
        agent = by_name.get(s["observed_name"])
        if agent:
            entry.update({"type": agent["type"], "purpose_observed": agent.get("purpose_observed"),
                          "evidence": list(agent["evidence"]), "note": agent.get("note"), "decided_by": "agent"})
            match = next((c for c in cands if c["type"] == agent["type"]), None)
            if match and not entry["evidence"]:
                entry["evidence"] = list(match["evidence_pointers"])
                entry["decided_by"] = "agent_confirmed_candidate"
            if entry["type"] is None:
                need_question(f"sheets/{s['observed_name']}",
                              f"What is the purpose of sheet {s['observed_name']!r}? Its type could not be established.")
            elif not entry["evidence"]:
                errors.append({"path": f"/sheets[{s['observed_name']}]",
                               "message": "type differs from every script candidate, so it needs evidence pointers"})
        elif cands and any(m["in_name"] for m in cands[0]["matched"]):
            entry.update({"type": cands[0]["type"], "decided_by": "script_candidate",
                          "evidence": list(cands[0]["evidence_pointers"])})
        else:
            unreviewed.append(s["observed_name"])
        entry["evidence_resolved"] = check_pointers(doc, entry["evidence"], f"/sheets[{s['observed_name']}]", errors)
        out_sheets.append(entry)
    interp["sheets"] = out_sheets
    if unreviewed:
        need_question("sheets/unreviewed", "These sheets were not classified and had no name-based "
                      f"candidate type: {', '.join(repr(n) for n in unreviewed)}. What are they?")

    # Valuation outputs: the value always comes from the workbook, never the agent.
    pos_by_name = {s["observed_name"]: s["position"] for s in obs_sheets if s["sheet_kind"] == "worksheet"}
    outputs = []
    for i, vo in enumerate(interp["valuation_outputs"]):
        where = f"/valuation_outputs/{i}"
        entry = dict(vo)
        entry["cell"] = vo["cell"].replace("$", "").upper()
        entry["evidence_resolved"] = check_pointers(doc, vo["evidence"], where, errors)
        if vo["sheet"] not in pos_by_name:
            errors.append({"path": where, "message": f"worksheet {vo['sheet']!r} not found"})
            continue
        found = find_cell(doc, pos_by_name[vo["sheet"]], vo["sheet"], entry["cell"])
        if not found:
            errors.append({"path": where, "message": f"cell {entry['cell']} on {vo['sheet']!r} is not in the "
                           "observations. Run inspect_region.py on a range that contains it, then rebuild"})
            continue
        pointer, value, formula = found
        entry.update({"observed_value": value, "observed_formula": formula, "value_source": pointer})
        if formula and value is None:
            entry["note"] = ((vo.get("note") or "") + " Cached value unavailable; the formula result is unknown.").strip()
            need_question(f"valuation_outputs/{vo['label']}",
                          f"{vo['label']} at {vo['sheet']}!{entry['cell']} is a formula with no cached value. "
                          "Can the file be opened and saved in Excel so its results are stored?")
        outputs.append(entry)
    interp["valuation_outputs"] = outputs
    if is_valuation and not outputs:
        need_question("valuation_outputs")

    interp.pop("open_questions", None)
    interp.pop("interpretation_version", None)
    return interp, auto_questions, is_valuation


def completeness(interp, is_valuation):
    fields = COMPLETENESS_FIELDS + (VALUATION_ONLY if is_valuation else [])
    missing = []
    for f in fields:
        v = interp[f]
        present = bool(v) if isinstance(v, list) else v.get("value") is not None
        if not present:
            missing.append(f)
    total = len(fields)
    return {"found": total - len(missing), "total": total,
            "ratio": round((total - len(missing)) / total, 4), "missing": missing}


def summary_md(profile):
    ident = profile["identity"]
    lines = [f"# File profile: {ident['file_name']}", ""]
    sha = (ident.get("sha256") or "")[:12]
    lines.append(f"Status: **{profile['profile_status']}** | SHA-256: `{sha}...` | Size: {ident.get('size')} bytes")
    if profile["profile_status"] == "processing_error":
        e = profile["processing_error"]
        lines += ["", f"Processing error ({e.get('error_kind')}): {e.get('error_message')}",
                  "", "Dependent work is blocked. Inputs were preserved."]
        return "\n".join(lines) + "\n"
    it = profile["interpretation"]
    pc = profile["profile_completeness"]
    lines += [f"Completeness: {pc['found']}/{pc['total']}", "", "| Field | Value | Evidence |", "|---|---|---|"]

    def cell(v):
        if isinstance(v, dict):
            v = f"{v.get('from')} to {v.get('to')} ({v.get('frequency')})"
        return "—" if v in (None, "", []) else str(v).replace("|", "/")
    for f in SCALAR_FIELDS:
        lines.append(f"| {f} | {cell(it[f]['value'])} | {len(it[f].get('evidence_resolved', []))} |")
    for f in LIST_FIELDS:
        vals = ", ".join(str(x["value"]) for x in it[f])
        lines.append(f"| {f} | {cell(vals)} | {sum(len(x.get('evidence_resolved', [])) for x in it[f])} |")
    lines += ["", "| # | Sheet | Visibility | Pattern | Type | Decided by |", "|---|---|---|---|---|---|"]
    for s in it["sheets"]:
        lines.append(f"| {s['position']} | {cell(s['observed_name'])} | {s['visibility']} | "
                     f"{cell(s['normalized_name_pattern'])} | {cell(s['type'])} | {s['decided_by']} |")
    if it["valuation_outputs"]:
        lines += ["", "| Output | Location | Value | Formula |", "|---|---|---|---|"]
        for v in it["valuation_outputs"]:
            lines.append(f"| {v['label']} | {cell(v['sheet'])}!{v['cell']} | {cell(v['observed_value'])} | "
                         f"{cell(v['observed_formula'])} |")
    if profile["open_questions"]:
        lines += ["", "## Open questions"]
        lines += [f"- **{q['id']}** ({q['field']}): {q['question']}" for q in profile["open_questions"]]
    if profile["warnings"]:
        lines += ["", "## Warnings"] + [f"- {w}" for w in profile["warnings"]]
    return "\n".join(lines) + "\n"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--observations", required=True)
    ap.add_argument("--interpretation")
    ap.add_argument("--supplements")
    ap.add_argument("--output", required=True)
    ap.add_argument("--summary", required=True)
    a = ap.parse_args()
    result = {"build_status": "invalid", "profile_status": None, "errors": [], "output": None, "summary": None}

    try:
        obs = json.loads(Path(a.observations).read_text(encoding="utf-8"))
        if obs.get("profile_contract_version") != CONTRACT_VERSION:
            raise BuildErrors([{"path": "/", "message": "observations were produced by a different profiler "
                                "version; rerun scripts/profile_workbook.py"}])
        doc = {"identity": obs["identity"],
               "observations": {"workbook": obs["observations"]["workbook"],
                                "sheets": obs["observations"]["sheets"], "supplements": []}}
        inspector_version = None
        if a.supplements and Path(a.supplements).is_file():
            sup = json.loads(Path(a.supplements).read_text(encoding="utf-8"))
            if sup.get("sha256") != obs["identity"]["sha256"]:
                raise BuildErrors([{"path": "/supplements", "message": "supplements belong to a different file"}])
            doc["observations"]["supplements"] = sup["supplements"]
            inspector_version = sup.get("script_version")

        profile = {"profile_contract_version": CONTRACT_VERSION,
                   "script_versions": {"profiler": obs["script_version"], "builder": BUILDER_VERSION,
                                       "inspector": inspector_version},
                   "profile_status": obs["profile_status"], "identity": doc["identity"],
                   "observations": doc["observations"], "interpretation": None, "open_questions": [],
                   "profile_completeness": None, "warnings": obs.get("warnings", []),
                   "processing_error": obs.get("processing_error")}

        if obs["profile_status"] == "completed":
            if not a.interpretation:
                raise BuildErrors([{"path": "/", "message": "--interpretation is required for a completed profile"}])
            raw = json.loads(Path(a.interpretation).read_text(encoding="utf-8"))
            schema = json.loads((SCHEMAS / "interpretation.schema.json").read_text(encoding="utf-8"))
            errors = validate(raw, schema)
            if errors:
                raise BuildErrors(errors)
            check_dates(raw, errors)
            interp, auto_q, is_val = build_interpretation(doc, raw, errors)
            if errors:
                raise BuildErrors(errors)
            questions = [dict(q, source="agent") for q in raw["open_questions"]] + \
                        [dict(q, source="builder") for q in auto_q]
            profile["open_questions"] = [{"id": f"Q{i + 1}", **q} for i, q in enumerate(questions)]
            profile["interpretation"] = interp
            profile["profile_completeness"] = completeness(interp, is_val)

        final_errors = validate(profile, json.loads((SCHEMAS / "file-profile.schema.json").read_text(encoding="utf-8")))
        if final_errors:
            raise BuildErrors([dict(e, message="builder output invalid (report this; do not edit): " + e["message"])
                               for e in final_errors])

        out, summ = Path(a.output), Path(a.summary)
        out.parent.mkdir(parents=True, exist_ok=True)
        summ.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(profile, indent=2, ensure_ascii=False), encoding="utf-8")
        summ.write_text(summary_md(profile), encoding="utf-8")
        result.update({"build_status": "valid", "profile_status": profile["profile_status"],
                       "open_question_count": len(profile["open_questions"]),
                       "completeness": profile["profile_completeness"],
                       "output": str(out), "summary": str(summ)})
    except BuildErrors as e:
        result["errors"] = e.errors[:50]
        result["error_count"] = len(e.errors)
    except Exception as e:
        result["errors"] = [{"path": "/", "message": f"{type(e).__name__}: {e}"}]

    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
