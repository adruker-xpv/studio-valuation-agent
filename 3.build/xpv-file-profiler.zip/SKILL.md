---
name: xpv-file-profiler
description: >-
  Profile one Excel workbook (.xlsx, .xlsm) received as valuation evidence: inventory every sheet
  including hidden and very hidden ones, record labels, periods, formulas and number formats, and
  produce an evidence-cited profile (file role, status, family, company, period end, currencies,
  units, sheet types, headline valuation cells). Use when a new file needs profiling or the File
  Register asks for a profile. Do not use to deduplicate files, update the register, build or
  change valuation schemas, assess confidence, or calculate valuations. Also use when explicitly
  asked to test, validate, or smoke-test the XPV File Profiler package.
---
# XPV File Profiler

Produce a profile of one workbook in which facts come from code and judgments come with citations. The scripts read the file and write every output file. You decide what the observations mean, in a small interpretation file, and the builder checks each claim against the workbook before anything is saved.

Paths below are relative to this skill's folder, the one containing this SKILL.md. Use one working folder per file, shown here as `<work>`.

## Workflow

1. **Observe.** Run:
   `python scripts/profile_workbook.py --input <file> --output <work>/observations.json`
   Read the one-line result it prints. If `profile_status` is `processing_error`, skip to step 5 and build without an interpretation. Do not try to open the file another way.

2. **Read with the viewer, never with your own code.** Run:
   - `python scripts/view_observations.py --observations <work>/observations.json` for an overview with one line per sheet.
   - Add `--sheet <position or exact name>` for one sheet's labels, period headers, number formats, formulas and type candidates.
   - Use `--supplements <work>/supplements.json` to see drill-down cells.

   Every line printed starts with the JSON pointer to cite. Do not open, parse or summarize the JSON files with Python or any other code; the viewer is the only way to read them.

3. **Drill down only where registration evidence is missing.** Run:
   `python scripts/inspect_region.py --input <file> --supplements <work>/supplements.json --reason "<why>" --region "<Sheet>!<A1:H30>" [--region ...]`
   Registration needs only the facts in "Registration depth" below. The script allows two calls, plus one more with `--after-build-error`; batch regions within them.

4. **Interpret.** Read `references/interpretation-guide.md`, copy `templates/interpretation.template.json` to `<work>/interpretation.json`, and fill it in:
   - Every non-null value cites JSON pointers into the observations.
   - Do not type cell values; the builder copies them from the workbook.
   - Anything unsupported stays null. An honest null with a question is a better profile than a plausible guess.

   This file is small on purpose. Never write or copy the observations into it.

5. **Build.** Run:
   `python scripts/build_profile.py --observations <work>/observations.json --interpretation <work>/interpretation.json --supplements <work>/supplements.json --output <work>/profile.json --summary <work>/profile-summary.md`
   - Omit `--interpretation` for a processing error.
   - Omit `--supplements` if you never drilled down.

6. **If `build_status` is `invalid`**, the printed errors say exactly which field or pointer failed. Rebuild at most twice, then stop and report `interpretation_invalid` with the errors.
   - **Permitted:** edit `interpretation.json`; add missing evidence with one `inspect_region.py --after-build-error` call; rerun the builder.
   - **Prohibited:** edit scripts; write helper code; parse JSON with your own code; bypass or skip the builder.

7. **Return** `profile.json` and `profile-summary.md` to the calling agent so it can save them through the configured OneDrive tool; the sandbox does not keep files. In chat, show the summary's key lines and the open questions, not the JSON.

## Registration depth

Profiling for the File Register (the default) establishes only:
- company name, file role, status, family, period end, actuals through (where explicit);
- entities, currencies and units;
- sheet types;
- headline valuation-output locations and types;
- open questions.

Do not extract cap tables, adjustment schedules, financial statements, comps, IRR schedules, ownership schedules, or historical values. Deeper extraction is for Onboarding and Maintenance (`--purpose deep_extraction` on `inspect_region.py` and `build_profile.py`).

## Rules

- Use only the bundled scripts. Do not write, modify, or debug code during a run, including small helper code to read or inspect files, even when a script reports an error. A script error is a result to report, not a problem to fix, because improvised code is what made earlier runs unreliable.
- Never edit `observations.json`, `supplements.json`, or `profile.json` by hand. The builder is the only writer of the final profile.
- Never guess acronyms, entity relationships, methodology, approval status, formula meaning, dates, currencies, units, or locations.
- Do not alter the source workbook, deduplicate, update registers, create schemas, calculate confidence, or calculate valuations.

`references/sheet-classification.md` explains how the script's type suggestions are scored.
