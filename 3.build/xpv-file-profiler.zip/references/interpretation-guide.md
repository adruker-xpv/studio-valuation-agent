# Interpretation guide

Read this before writing `interpretation.json`. The interpretation is the only part of the profile you author. It holds judgments; the builder checks them against the observations.

## Contents
1. Evidence pointers
2. Field rules
3. Sheets
4. Valuation outputs
5. When to drill down
6. Open questions
7. Worked example

## 1. Evidence pointers

Every non-null value cites one or more JSON pointers into the observations or identity. The builder rejects pointers that do not exist, so copy indexes from the files rather than estimating them.

| Evidence source | Pointer form |
|---|---|
| Filename | `/identity/file_name` |
| Filename decomposition | `/identity/filename_analysis/family_candidate`, `/identity/filename_analysis/status_tokens/0`, `/identity/filename_analysis/period_tokens/0` |
| Workbook properties | `/observations/workbook/properties/title` |
| Named range | `/observations/workbook/defined_names/3` |
| Sheet name | `/observations/sheets/2/observed_name` |
| Text label | `/observations/sheets/2/representative_labels/14` |
| Period header | `/observations/sheets/2/date_like_headers/5` |
| Number format | `/observations/sheets/2/number_formats/0` |
| Formula | `/observations/sheets/2/formula_samples/7` |
| Script type suggestion | `/observations/sheets/2/candidate_types/0` |
| Drill-down cell | `/observations/supplements/0/cells/12` |

Sheet indexes equal `position` (workbook tab order). Supplement indexes follow the order in `supplements.json` (the `index` value printed by `inspect_region.py`).

Cite the observation that actually shows the fact. A label that says "Enterprise Value" supports the label; the value cell next to it is found by the builder.

## 2. Field rules

**file_role**, one of: `valuation_workbook`, `monthly_financials_package`, `balance_sheet`, `cap_table`, `market_inputs`, `adjustment_support`, `pro_forma_support`, `lp_report`, `other`. Choose the file's main purpose.

**roles_present** lists whole-file roles only: what the file as a whole is delivered as. Usually this is just `file_role`, and the builder adds that for you. Add a second role only when the file itself is distributed as that deliverable, for example a cover titled "LP Report" on a valuation workbook.

A sheet is not a role. A valuation workbook with a cap-table tab is still one `valuation_workbook`, and the builder rejects a role supported only by a sheet name or type candidate. The builder lists sheet-level contents automatically as `content_components`, derived from the final sheet types.

**status**: `final`, `draft`, or `conflict`. Use `filename_analysis/status_tokens` and in-file labels such as "DRAFT" or "Final". If nothing indicates status, leave null; null means unknown, and the File Register will not supersede on it.

- A filename status token is an observed indicator, not approval evidence. Never use it to claim a valuation was approved.
- If the filename says draft and the workbook says final or approved (or the reverse), set `conflict` and cite both. The builder rejects a `final` or `draft` status that contradicts the filename token.

**family**: start from `/identity/filename_analysis/family_candidate`. Accept it if the removed tokens were dates, periods, versions, status words, or upload suffixes. Correct it only when a removed or kept token is clearly wrong, and explain in `note`.

**company_name_in_file**: must cite at least one pointer inside the workbook (a label, title, or property). The builder rejects a company name supported only by the filename. Write the name exactly as it appears in the file.

**period_end / actuals_through**: ISO `YYYY-MM-DD` or `YYYY-MM`. Use `YYYY-MM` when only the month is known; do not invent the day. Evidence: period headers, "Actuals through" labels, column hints (`actual` vs `budget` / `forecast`), filename period tokens. If contents and filename disagree, set null and ask.

**periods_covered**: `{ "from", "to", "frequency" }`, where frequency is `monthly`, `quarterly`, `annual`, or `mixed`.

**entities**: legal entities or business units named in the file, as written. Do not infer parent/subsidiary relationships.

**currencies**: ISO codes only (`CAD`, `USD`). A bare `$` in a number format or label is ambiguous between CAD and USD; do not resolve it by assumption. Record it only when a label, format, or title names the currency, otherwise leave the list empty and ask.

**units**: `ones`, `thousands`, `millions`, `billions`, `percent`, `multiple`, `other`. Evidence: labels such as "$000s" or "(in thousands)", or number formats ending in `,` (thousands) or `,,` (millions).

**valuation_method_observation**: one or two sentences on method labels that are explicitly present (for example: "Labels reference an EV/EBITDA multiple applied to LTM EBITDA"). This is an observation, not approved methodology. Only needed for valuation workbooks.

Never guess acronyms, entity relationships, methodology, approval status, formula meaning, dates, currencies, units, or locations. Null plus an open question is a correct answer.

## 3. Sheets

Add an entry for every sheet you can classify: `{ "observed_name", "type", "purpose_observed", "evidence" }`. Use the exact `observed_name`.

Types: `income_statement`, `balance_sheet`, `cash_flow`, `kpis`, `valuation_summary`, `comps_or_market_inputs`, `ebitda_adjustments`, `pro_forma`, `net_debt_or_equity_bridge`, `cap_table`, `inputs`, `calculation`, `notes`, `other`.

- **Agreeing with the script's top suggestion:** give the type and leave `evidence` empty. The builder copies the candidate's pointers and records `agent_confirmed_candidate`.
- **Choosing a different type:** evidence is required.
- **Unclear:** set `type` to null. The builder raises a question.
- **Sheets you skip:** the builder keeps the script's candidate only when the keyword is in the sheet name; the rest are listed in one open question.

Classification is descriptive. `ebitda_adjustments` means "the sheet shows adjustments", not "these adjustments are approved".

## 4. Valuation outputs

For each headline output, write:

```json
{ "label": "fund_interest_value", "label_text": "XPV Value", "value_type": "currency",
  "currency": "USD", "unit_scale": "ones", "sheet": "III. Valuation Summary", "cell": "F20",
  "label_evidence": ["/observations/supplements/0/cells/14"],
  "value_context_evidence": ["/observations/supplements/0/cells/3"], "note": null }
```

- **label**: `enterprise_value`, `equity_value`, `fund_interest_value`, `implied_multiple`, `valuation_date`, or `other`.
- **label_text**: copied exactly from the cited label. The builder rejects text that does not appear in the label evidence.
- **value_type**: `currency`, `currency_per_share`, `percentage`, `multiple`, `date`, `share_count`, `unit_count`, or `other`. The builder rejects:
  - a count type when the label says value, price or cost, or does not name shares, units or a count;
  - `currency_per_share` unless "per share" or "per unit" is in the label;
  - `currency` when the label is per share or describes a count;
  - `percentage` without a `%` format or a percent/IRR label;
  - `multiple` without an `x` format or a multiple label.
- **currency**: an ISO code already established in `currencies`, or null. Null raises a question; a guess is worse than a question. Must be null for non-currency types.
- **unit_scale**: `ones`, `thousands`, `millions`, `billions`, or null. The builder rejects a scale that contradicts the cell's number format (for example `#,##0,` means thousands). Must be null for percentage, multiple and date.
- **cell**: the value cell, not the label cell. Do not type the number; the builder reads the value and formula from the observations.
- **label_evidence**: the label that names the value.
- **value_context_evidence**: optional column or row headers that give it context, such as a date or scenario header.

## 5. When to drill down

The overview stores the first 120 labels and 150 formulas per sheet and no plain numbers.

**Registration depth (the default, `--purpose registration`).** Establish only:
- company name, file role, status, family, period end, actuals through (where explicit);
- entities, currencies and units;
- the sheet signature (sheet types);
- headline valuation-output locations for a valuation workbook;
- open questions.

Do not extract cap tables, adjustment schedules, financial statements, comparable-company tables, IRR schedules, attribution calculations, ownership schedules, or historical period values. That belongs to Onboarding, Maintenance, or the Valuation Run Builder, which use `--purpose deep_extraction`.

`inspect_region.py` allows two registration calls per file, plus one with `--after-build-error` when the builder reports missing evidence. Further calls are refused. Use the calls for the valuation summary area and the header or cover area. Keep regions tight, for example 8 columns by 30 rows around a label. If evidence is still missing, leave the field null and ask.

Read sheets with `view_observations.py --sheet` only when they are likely to hold registration facts: cover, title, valuation summary, and headers. Classifying the other sheets from the overview's candidate types is enough.

## 6. Open questions

Write `{ "field", "question" }` entries for anything a person must resolve. Make each question specific and answerable, and name the sheet or cell. The builder adds generic questions for any unresolved field you did not ask about, so ask your own when you have context that would help the reviewer.

## 7. Worked example

```json
{
  "interpretation_version": "3.2.0",
  "file_role": { "value": "valuation_workbook", "evidence": ["/observations/sheets/3/observed_name", "/observations/sheets/3/representative_labels/2"] },
  "roles_present": [],
  "status": { "value": "final", "evidence": ["/identity/filename_analysis/status_tokens/0"] },
  "family": { "value": "acme valuation", "evidence": ["/identity/filename_analysis/family_candidate"] },
  "company_name_in_file": { "value": "Acme Water Ltd.", "evidence": ["/observations/sheets/0/representative_labels/0"] },
  "period_end": { "value": "2026-06-30", "evidence": ["/observations/sheets/3/representative_labels/1"] },
  "actuals_through": { "value": null, "evidence": [] },
  "periods_covered": { "value": null, "evidence": [] },
  "entities": [],
  "currencies": [{ "value": "CAD", "evidence": ["/observations/sheets/3/representative_labels/4"] }],
  "units": [{ "value": "thousands", "evidence": ["/observations/sheets/3/number_formats/0"] }],
  "sheets": [
    { "observed_name": "Valuation Summary", "type": "valuation_summary", "purpose_observed": "Headline EV and equity bridge", "evidence": [] }
  ],
  "valuation_outputs": [
    { "label": "enterprise_value", "label_text": "Enterprise Value", "value_type": "currency", "currency": "CAD",
      "unit_scale": "thousands", "sheet": "Valuation Summary", "cell": "C8",
      "label_evidence": ["/observations/supplements/0/cells/9"], "value_context_evidence": [] }
  ],
  "valuation_method_observation": { "value": "Label 'EV/EBITDA multiple' appears beside LTM EBITDA.", "evidence": ["/observations/supplements/0/cells/5"] },
  "open_questions": [
    { "field": "actuals_through", "question": "The P&L shows Jan-Dec 2026 columns without Actual/Budget labels. Which months are actuals?" }
  ]
}
```
