# Interpretation guide

Read this before writing `interpretation.json`. The interpretation is the only part of the profile you author. It holds judgments; the builder checks them against the observations.

## Contents
1. Evidence pointers
2. Field rules
3. Sheets
4. Valuation outputs
5. When to drill down
6. Open questions
7. Worked example

## 1. Evidence pointers

Every non-null value cites one or more JSON pointers into the observations or identity. The builder rejects pointers that do not exist, so copy indexes from the files rather than estimating them.

| Evidence source | Pointer form |
|---|---|
| Filename | `/identity/file_name` |
| Filename decomposition | `/identity/filename_analysis/family_candidate`, `/identity/filename_analysis/status_tokens/0`, `/identity/filename_analysis/period_tokens/0` |
| Workbook properties | `/observations/workbook/properties/title` |
| Named range | `/observations/workbook/defined_names/3` |
| Sheet name | `/observations/sheets/2/observed_name` |
| Text label | `/observations/sheets/2/representative_labels/14` |
| Period header | `/observations/sheets/2/date_like_headers/5` |
| Number format | `/observations/sheets/2/number_formats/0` |
| Formula | `/observations/sheets/2/formula_samples/7` |
| Script type suggestion | `/observations/sheets/2/candidate_types/0` |
| Drill-down cell | `/observations/supplements/0/cells/12` |

Sheet indexes equal `position` (workbook tab order). Supplement indexes follow the order in `supplements.json` (the `index` value printed by `inspect_region.py`).

Cite the observation that actually shows the fact. A label that says "Enterprise Value" supports the label; the value cell next to it is found by the builder.

## 2. Field rules

**file_role**, one of: `valuation_workbook`, `monthly_financials_package`, `balance_sheet`, `cap_table`, `market_inputs`, `adjustment_support`, `pro_forma_support`, `lp_report`, `other`. Choose the file's main purpose. List every role the file serves in `roles_present` (the builder adds `file_role` if you leave it out).

**status**: `final`, `draft`, or `conflict`. Use `filename_analysis/status_tokens` and in-file labels such as "DRAFT" or "Final". If the filename and contents disagree, use `conflict` and cite both. If nothing indicates status, leave null; null means unknown, and the File Register will not supersede on it.

**family**: start from `/identity/filename_analysis/family_candidate`. Accept it if the removed tokens were dates, periods, versions, status words, or upload suffixes. Correct it only when a removed or kept token is clearly wrong, and explain in `note`.

**company_name_in_file**: must cite at least one pointer inside the workbook (a label, title, or property). The builder rejects a company name supported only by the filename. Write the name exactly as it appears in the file.

**period_end / actuals_through**: ISO `YYYY-MM-DD` or `YYYY-MM`. Use `YYYY-MM` when only the month is known; do not invent the day. Evidence: period headers, "Actuals through" labels, column hints (`actual` vs `budget` / `forecast`), filename period tokens. If contents and filename disagree, set null and ask.

**periods_covered**: `{ "from", "to", "frequency" }`, where frequency is `monthly`, `quarterly`, `annual`, or `mixed`.

**entities**: legal entities or business units named in the file, as written. Do not infer parent/subsidiary relationships.

**currencies**: ISO codes only (`CAD`, `USD`). A bare `$` in a number format or label is ambiguous between CAD and USD; do not resolve it by assumption. Record it only when a label, format, or title names the currency, otherwise leave the list empty and ask.

**units**: `ones`, `thousands`, `millions`, `billions`, `percent`, `multiple`, `other`. Evidence: labels such as "$000s" or "(in thousands)", or number formats ending in `,` (thousands) or `,,` (millions).

**valuation_method_observation**: one or two sentences on method labels that are explicitly present (for example: "Labels reference an EV/EBITDA multiple applied to LTM EBITDA"). This is an observation, not approved methodology. Only needed for valuation workbooks.

Never guess acronyms, entity relationships, methodology, approval status, formula meaning, dates, currencies, units, or locations. Null plus an open question is a correct answer.

## 3. Sheets

Add an entry for every sheet you can classify: `{ "observed_name", "type", "purpose_observed", "evidence" }`. Use the exact `observed_name`.

Types: `income_statement`, `balance_sheet`, `cash_flow`, `kpis`, `valuation_summary`, `comps_or_market_inputs`, `ebitda_adjustments`, `pro_forma`, `net_debt_or_equity_bridge`, `cap_table`, `inputs`, `calculation`, `notes`, `other`.

- **Agreeing with the script's top suggestion:** give the type and leave `evidence` empty. The builder copies the candidate's pointers and records `agent_confirmed_candidate`.
- **Choosing a different type:** evidence is required.
- **Unclear:** set `type` to null. The builder raises a question.
- **Sheets you skip:** the builder keeps the script's candidate only when the keyword is in the sheet name; the rest are listed in one open question.

Classification is descriptive. `ebitda_adjustments` means "the sheet shows adjustments", not "these adjustments are approved".

## 4. Valuation outputs

For each headline output, write `{ "label", "label_text", "sheet", "cell", "evidence" }`, where `label` is one of `enterprise_value`, `equity_value`, `fund_interest_value`, `implied_multiple`, `valuation_date`, `other`.

- `cell` is the value cell, not the label cell.
- `evidence` cites the label that names the value (for example, the "Enterprise Value" text).
- Do not type the number. The builder reads the value and formula from the observations. If the cell is not in the observations, the build fails with an instruction to drill down.

## 5. When to drill down

The overview stores the first 120 labels and 150 formulas per sheet and no plain numbers. Use `inspect_region.py` when:
- you need a valuation output cell (almost always: look around the label's cell);
- period header rows or "actuals through" labels are cut off;
- a sheet is `truncated`;
- units or currency notes probably sit near the top of a sheet but are not in the stored labels.

Keep regions tight, for example 8 columns by 30 rows around a label. Batch regions into one call, and use at most four calls per file. If the evidence still is not there, leave the field null and ask.

## 6. Open questions

Write `{ "field", "question" }` entries for anything a person must resolve. Make each question specific and answerable, and name the sheet or cell. The builder adds generic questions for any unresolved field you did not ask about, so ask your own when you have context that would help the reviewer.

## 7. Worked example

```json
{
  "interpretation_version": "3.1.0",
  "file_role": { "value": "valuation_workbook", "evidence": ["/observations/sheets/3/observed_name", "/observations/sheets/3/representative_labels/2"] },
  "roles_present": [],
  "status": { "value": "final", "evidence": ["/identity/filename_analysis/status_tokens/0"] },
  "family": { "value": "acme valuation", "evidence": ["/identity/filename_analysis/family_candidate"] },
  "company_name_in_file": { "value": "Acme Water Ltd.", "evidence": ["/observations/sheets/0/representative_labels/0"] },
  "period_end": { "value": "2026-06-30", "evidence": ["/observations/sheets/3/representative_labels/1"] },
  "actuals_through": { "value": null, "evidence": [] },
  "periods_covered": { "value": null, "evidence": [] },
  "entities": [],
  "currencies": [{ "value": "CAD", "evidence": ["/observations/sheets/3/representative_labels/4"] }],
  "units": [{ "value": "thousands", "evidence": ["/observations/sheets/3/number_formats/0"] }],
  "sheets": [
    { "observed_name": "Valuation Summary", "type": "valuation_summary", "purpose_observed": "Headline EV and equity bridge", "evidence": [] }
  ],
  "valuation_outputs": [
    { "label": "enterprise_value", "label_text": "Enterprise Value", "sheet": "Valuation Summary", "cell": "C8",
      "evidence": ["/observations/supplements/0/cells/9"] }
  ],
  "valuation_method_observation": { "value": "Label 'EV/EBITDA multiple' appears beside LTM EBITDA.", "evidence": ["/observations/supplements/0/cells/5"] },
  "open_questions": [
    { "field": "actuals_through", "question": "The P&L shows Jan-Dec 2026 columns without Actual/Budget labels. Which months are actuals?" }
  ]
}
```
