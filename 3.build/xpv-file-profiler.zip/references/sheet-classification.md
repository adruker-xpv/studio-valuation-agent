# How sheet-type suggestions are made

`profile_workbook.py` suggests sheet types with transparent keyword scoring. It is not fuzzy or AI matching. The agent makes the final call, and the suggestions exist so that call starts from visible evidence.

## Steps

1. **Normalize the text.** The sheet name and each stored label are lower-cased; `&` becomes `and`; punctuation other than `/` becomes a space. So `P&L`, `P & L`, and `p&l` all become `p and l`, and `Add-backs` becomes `add backs`.
2. **Match whole phrases only.** A keyword matches only as a complete word or phrase: `model` matches "Financial model" but not "remodel", and `notes` does not match "footnotes".
3. **Score.** Each keyword in `classification-rules.json` is marked strong or weak, and a sheet name is a stronger signal than a label deep in the sheet:

   | Where it matched | Strong keyword | Weak keyword |
   |---|---|---|
   | Sheet name | 6 | 3 |
   | Any stored label | 2 | 1 |

   Each keyword counts once per location, no matter how often it repeats.
4. **Report.** The top five types are returned with their score, the matching keywords, and `evidence_pointers` to the sheet name or labels that matched.

## Why not fuzzy matching

Fuzzy string matching (edit distance) would turn "Cash" into near-matches for unrelated words and produce confident-looking false positives. Meaning-level judgment ("this tab is really a bridge from EV to equity") is what the agent layer is for. The script stays exact so its output is identical on every run and easy to audit.

## Tuning

Edit `references/classification-rules.json`. No code change is needed, and `rules_version` is recorded in each profile so results can be traced back to the rules that produced them. Add a keyword when the same miss shows up repeatedly in reviewed profiles, not for one-off cases.
