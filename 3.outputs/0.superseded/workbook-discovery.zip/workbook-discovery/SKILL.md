---
name: workbook-discovery
description: XPV workbook reading test, build 11.7. Reads an approved valuation workbook without changing it, then checks that reading against Excel's own export of the same workbook and against an analyst's answers. Use for "run the program on", "compare", "make the answer form", "check the answer form", "save the answers", "run the demo" or "run the discovery tests". Never generates or updates a valuation.
---

# Workbook reading test (build 11.7)

Run ONE command at a time and post its printed lines. Never open, summarise or quote workbooks, forms, answers, results or
reports yourself. Pass every file **by name**, exactly as fetched or uploaded; the scripts find it.

## What the user says, and the command to run
| The user says | Run |
|---|---|
| "Run the discovery tests" | `python tests/run_tests.py` |
| "Run the demo" | `python tools/demo.py` – then offer `demo/comparison/comparison.xlsx` |
| "Run the program on <workbook> for quarter end <date>" | `python discovery/discover.py --workbook "<workbook>" --period-end <YYYY-MM-DD>` – then offer `program_answers.xlsx` from the folder it names |
| "... with the fund workbook <fund workbook> for <company>" | add `--fund-workbook "<fund workbook>" --company "<company as the fund workbook names it>"` |
| "... with the reported value in <fund workbook> cell <Sheet!Cell>" | add `--fund-workbook "<fund workbook>" --anchor-cell "<Sheet!Cell>"` |
| "Make the answer form for <workbook>, quarter end <date>" | `python benchmark/bench.py form --workbook "<workbook>" --quarter-end <YYYY-MM-DD> --out "answer form - <workbook without .xlsx>.xlsx"` – offer the form |
| "Check the answer form <form> against <workbook>" | `python benchmark/bench.py check-form --form "<form>" --workbook "<workbook>"` |
| "Save the answers by <name>" (form and workbook named, or the last ones used) | `python benchmark/bench.py save-answers --form "<form>" --workbook "<workbook>" --by "<name>" --out "analyst answers - <workbook without .xlsx>.json"` – offer the file |
| "Compare <workbook> with the Excel export <copy>" | `python benchmark/bench.py compare --workbook "<workbook>" --excel-export "<copy>"` |
| "Compare <workbook> with the answers <answers file>" | `python benchmark/bench.py compare --workbook "<workbook>" --answers "<answers file>"` |
| either, "and the previous result <result.json>" | add `--previous "<result.json>"` |
| both an export and answers named | give both `--excel-export` and `--answers` in one compare |
| "Fingerprint <workbook>" | `python benchmark/bench.py fingerprint --workbook "<workbook>"` |

After compare, offer `comparison.xlsx` and `result.json` from the folder it names. Expected test result: `ALL TESTS: PASS (49/49)`.

## Printed lines and exit codes
| Line | What you do |
|---|---|
| `PREFLIGHT:` | `OK`: carry on. `REFUSED`: tell the user exactly what it says (it names the fix) and stop |
| `DISCOVERY:` `ANCHOR:` `BENCHMARK:` `FORM:` `DEMO:` `ALL TESTS:` | post unchanged (they hold counts and plain instructions, not workbook content) |
| `STOPPED:` | tell the user exactly what it says; do nothing else |
| `DISCOVERY ERROR:` `BENCHMARK ERROR:` | a bug: post the line unchanged, offer the log file it names, stop |
| `NEXT:` | follow it literally |

Lines starting with `- ` belong to the line above them: post them too (for check-form they are the things to fix).
Exit codes: 0 done | 1 internal error (a bug) | 2 usage (a mistyped command: check it against this file) | 3 STOPPED (the user must act).

## Rules
- The program's answers (`program_answers.xlsx`) must never be shown or sent to the analyst before the analyst's answers are saved.
- Never edit a form, answers file, export copy or result yourself; never retry a command that printed STOPPED, REFUSED or ERROR.
- Never quote cells, sheet names or values from any file; they stay in this environment.
- This skill never generates, updates or values anything.
