# tests/dfixtures.py (build 11.5) - synthetic workbooks for the DISCOVERY failure modes (no real data). Saved values are
# injected as Excel would write them. Each fixture also returns the facts its author knows independently of discovery
# (expected precedents, periods, regions), so tests never use discovery's own conclusions as the answer.
import datetime, os, re, shutil, zipfile
import vp_fixtures as FX
from openpyxl.worksheet.formula import ArrayFormula
from openpyxl.worksheet.table import Table


def _date(y, m):
    return datetime.datetime.combine(FX.month_end(y, m), datetime.time())


def structures_workbook(path):
    """every graph-status case in one workbook: shared formulas, a dynamic-array spill, an Excel table, a defined name, a
    named constant, INDIRECT (literal and computed), INDEX, an unsupported-to-recompute function, #REF!, an external link,
    a circular pair, a hub date used by 24 formulas, a header/window conflict."""
    b = FX.Book()
    inp = b.sheet("Inputs")
    b.put(inp, "A1", "Valuation date"); b.put(inp, "B1", _date(2025, 12), fmt="yyyy-mm-dd")
    b.put(inp, "A3", "Line item")
    cols = [chr(66 + i) for i in range(12)]                       # B..M = Jan..Dec 2025
    for i, c in enumerate(cols):
        b.put(inp, f"{c}3", _date(2025, i + 1), fmt="yyyy-mm-dd")
    rev = [100_000 + 1_000 * i for i in range(12)]
    cost = [40_000 + 500 * i for i in range(12)]
    b.put(inp, "A4", "Revenue"); b.put(inp, "A5", "Costs")
    for i, c in enumerate(cols):
        b.put(inp, f"{c}4", rev[i]); b.put(inp, f"{c}5", cost[i])
    ca = b.sheet("Calc")
    b.put(ca, "B1", "Dec-25"); b.put(ca, "C1", "Dec-25")
    b.put(ca, "A2", "TTM revenue"); b.put(ca, "B2", formula="=SUM(Inputs!B4:M4)", cached=sum(rev))
    b.put(ca, "C2", formula="=SUM(Inputs!B4:L4)", cached=sum(rev[:11]))            # header Dec, window ends Nov: CONFLICTING
    b.put(ca, "A4", "Literal indirect"); b.put(ca, "B4", formula='=INDIRECT("Inputs!B4")', cached=rev[0])
    b.put(ca, "A5", "Computed indirect"); b.put(ca, "B5", formula='=INDIRECT("Inputs!B"&B10)', cached=rev[0])
    b.put(ca, "A6", "Lookup"); b.put(ca, "B6", formula="=INDEX(Inputs!B4:M4,3)", cached=rev[2])
    b.put(ca, "A7", "Volatility"); b.put(ca, "B7", formula="=STDEV(Inputs!B4:M4)", cached=3605.55)
    b.put(ca, "A8", "Broken"); b.put(ca, "B8", formula="=Inputs!#REF!*2", cached="#REF!")
    b.put(ca, "A9", "External rate"); b.put(ca, "B9", formula="=[1]Rates!B2", cached=0.0425)
    b.put(ca, "B10", 4)
    b.put(ca, "A11", "Circular A"); b.put(ca, "B11", formula="=B12+1", cached=2.0)
    b.put(ca, "A12", "Circular B"); b.put(ca, "B12", formula="=B11*0.5", cached=1.0)
    b.put(ca, "A13", "Table total"); b.put(ca, "B13", formula="=SUM(Sales[Amount])", cached=60)
    b.put(ca, "A14", "Named range"); b.put(ca, "B14", formula="=SUM(MyRange)", cached=sum(cost))
    b.put(ca, "A15", "Named constant"); b.put(ca, "B15", formula="=Growth*100", cached=5.0)
    b.put(ca, "A16", "TTM revenue dated"); b.put(ca, "B16", formula="=B2+Inputs!$B$1*0", cached=sum(rev))   # uses the hub too
    for j in range(24):                                            # 24 formulas use the valuation date: a hub
        b.put(ca, f"D{2 + j}", formula=f"=Inputs!$B$1+{j}", cached=_date(2025, 12) + datetime.timedelta(days=j))
    for j, c in enumerate(cols[:4]):                               # copied across: becomes ONE shared formula B30:E30
        b.put(ca, f"{chr(66 + j)}30", formula=f"=Inputs!{c}4*2", cached=rev[j] * 2)
    ca["G2"] = ArrayFormula("G2:G4", "=SEQUENCE(3)")
    b.put(ca, "G3", 2); b.put(ca, "G4", 3)
    b.put(ca, "H2", formula="=SUM(G2:G4)", cached=6)
    tb = b.sheet("Tbl")
    for r, (it, am) in enumerate([("Item", "Amount"), ("a", 10), ("b", 20), ("c", 30)], 1):
        b.put(tb, f"A{r}", it); b.put(tb, f"B{r}", am)
    tb.add_table(Table(displayName="Sales", ref="A1:B4"))
    no = b.sheet("Notes")
    b.put(no, "A1", "Notes only - no numbers used anywhere")
    from openpyxl.workbook.defined_name import DefinedName
    b.wb.defined_names["MyRange"] = DefinedName("MyRange", attr_text="Inputs!$B$5:$M$5")
    b.wb.defined_names["Growth"] = DefinedName("Growth", attr_text="0.05")
    b.wb.defined_names["BadName"] = DefinedName("BadName", attr_text="#REF!")       # a corrupt named range
    b.put(ca, "A17", "Uses a corrupt name"); b.put(ca, "B17", formula="=BadName*2", cached="#REF!")
    b.save(path)
    _shared_and_spill(path)
    FX.add_external_links(path, ["Rates Feed.xlsx", "Stale Old Pack.xlsx"])
    return {"rev": rev, "cost": cost}


def _shared_and_spill(path):
    """rewrite Calc!B30:E30 as ONE shared formula (as Excel stores copied formulas) and mark G2 as a dynamic array."""
    tmp = path + ".tmp"
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        names = zin.namelist()
        wbx = zin.read("xl/workbook.xml").decode()
        order = re.findall(r'<sheet [^>]*name="([^"]+)"', wbx)
        calc_part = f"xl/worksheets/sheet{order.index('Calc') + 1}.xml"
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == calc_part:
                x = data.decode()
                x = x.replace("<f>Inputs!B4*2</f>", '<f t="shared" ref="B30:E30" si="0">Inputs!B4*2</f>', 1)
                for c in "CDE":
                    x = x.replace(f"<f>Inputs!{c}4*2</f>", '<f t="shared" si="0"/>', 1)
                x = re.sub(r'<c r="G2"([^>]*)>(<f[^>]*>[^<]*</f>)(?:<v>\s*</v>|<v\s*/>)?', r'<c r="G2" cm="1"\1>\2<v>1</v>', x, count=1)
                data = x.encode()
            zout.writestr(item, data)
    shutil.move(tmp, path)


def pasted_workbook(path, stale_ev=False, balance_sheet=None):
    """a small valuation with a pasted value (Working!B5 typed into Valuation!B8), a disconnected scratch island, a
    round-number trap and an irrelevant notes sheet."""
    b = FX.Book()
    mo = b.sheet("Monthly")
    b.put(mo, "A3", "Line item")
    cols = [chr(66 + i) for i in range(12)]
    for i, c in enumerate(cols):
        b.put(mo, f"{c}3", _date(2025, i + 1), fmt="yyyy-mm-dd")
    e = [50_000 + 700 * i for i in range(12)]
    b.put(mo, "A4", "Revenue"); b.put(mo, "A5", "EBITDA")
    for i, c in enumerate(cols):
        b.put(mo, f"{c}4", 200_000 + 1_000 * i); b.put(mo, f"{c}5", e[i])
    if balance_sheet:                                   # a balance-sheet block: balanced, or off by 500 in June
        b.put(mo, "A7", "Total assets"); b.put(mo, "A8", "Total liabilities"); b.put(mo, "A9", "Total equity")
        for i, c in enumerate(cols):
            la, eq_ = 300_000 + 2_000 * i, 500_000 + 1_000 * i
            b.put(mo, f"{c}7", la + eq_ + (500 if balance_sheet == "off" and i == 5 else 0)); b.put(mo, f"{c}8", la); b.put(mo, f"{c}9", eq_)
    va = b.sheet("Valuation")
    ttm = sum(e)
    b.put(va, "A2", "Valuation date"); b.put(va, "B2", _date(2025, 12), fmt="yyyy-mm-dd")
    b.put(va, "A4", "TTM EBITDA"); b.put(va, "B4", formula="=SUM(Monthly!B5:M5)", cached=ttm)
    b.put(va, "A5", "Selected EV/EBITDA multiple"); b.put(va, "B5", 8.0)
    ev = 8.0 * ttm
    b.put(va, "A6", "Enterprise value"); b.put(va, "B6", formula="=B5*B4", cached=ev + (50_000 if stale_ev else 0))
    ev = ev + (50_000 if stale_ev else 0)
    b.put(va, "A7", "Cash"); b.put(va, "B7", 250_000)
    b.put(va, "A8", "Other debt-like items"); b.put(va, "B8", 123_457)
    eq = ev + 250_000 - 123_457
    b.put(va, "A9", "Equity value"); b.put(va, "B9", formula="=B6+B7-B8", cached=eq)
    b.put(va, "A10", "XPV fully diluted ownership"); b.put(va, "B10", 0.4)
    b.put(va, "A11", "XPV value"); b.put(va, "B11", formula="=B9*B10", cached=eq * 0.4)
    wk = b.sheet("Working")
    b.put(wk, "A1", "Debt-like items workings")
    for r, v in ((2, 100_000), (3, 20_000), (4, 3_457)):
        b.put(wk, f"B{r}", v)
    b.put(wk, "A5", "Total debt-like items"); b.put(wk, "B5", formula="=SUM(B2:B4)", cached=123_457)
    b.put(wk, "B6", formula="=B5/2", cached=61_728.5); b.put(wk, "B7", formula="=B6+B2", cached=161_728.5)
    b.put(wk, "B8", formula="=B7-B3", cached=141_728.5); b.put(wk, "B9", formula="=B8*1", cached=141_728.5)
    b.put(wk, "B10", formula="=B2*2.5", cached=250_000)            # a round number equal to cash: never a candidate
    sc = b.sheet("Scratch")
    b.put(sc, "C1", 7)
    prev = 7
    for r in range(2, 9):
        b.put(sc, f"C{r}", formula=f"=C{r - 1}+3", cached=prev + 3)
        prev += 3
    no = b.sheet("Notes")
    b.put(no, "A1", "Board notes")
    b.save(path)
    return {"ttm": ttm, "ev": ev, "equity": eq, "value": eq * 0.4}


def rename_sheet(path, old, new):
    """a sheet renamed the way Excel does it: the sheet name and every formula that names it change; values do not."""
    tmp = path + ".tmp"
    q = lambda s: f"'{s}'" if re.search(r"[^A-Za-z0-9_]", s) else s
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == "xl/workbook.xml":
                data = data.decode().replace(f'name="{old}"', f'name="{new}"').encode()
            elif item.filename.startswith("xl/worksheets/sheet"):
                data = re.sub(r"<f([^>]*)>([^<]*)</f>", lambda mm: f"<f{mm.group(1)}>{mm.group(2).replace(q(old) + '!', q(new) + '!')}</f>",
                              data.decode()).encode()
            zout.writestr(item, data)
    shutil.move(tmp, path)


def chain_workbook(path, fund_path=None, fx=None, anchor_value_override=None, second_chain=False, usd_row=True):
    """the failure modes of the first real run (build 11.6.1), rebuilt with made-up numbers: abbreviated labels on the real
    chain ('Adj. EBITDA (B)', 'Implied Enterprise Value (A*B)', 'Total Common Equity'); a comparables block whose summary row
    is labelled 'Enterprise Value' (an AVERAGE) with a COUNTIF count under an 'EV/EBITDA' header; an older, internally
    consistent prior-period column; an 'Equity Cost Base' typed equal to XPV's value; a legacy copy sheet with #REF!;
    an explicit 'TTM ending June 30, 2026' header. Optionally the fund valuation workbook that reports XPV's value."""
    b = FX.Book()
    mo = b.sheet("Monthly")
    b.put(mo, "A2", "Month")
    months = [(2024 + (6 + i) // 12, (6 + i) % 12 + 1) for i in range(24)]          # Jul 2024 .. Jun 2026
    cols = [FX.col_letter(2 + i) for i in range(24)]
    adj = [150_000 + 2_500 * i + (i % 3) * 1_200 for i in range(24)]
    for i, (y, m) in enumerate(months):
        b.put(mo, f"{cols[i]}2", _date(y, m), fmt="yyyy-mm-dd")
        b.put(mo, f"{cols[i]}3", adj[i])
    b.put(mo, "A3", "Adjusted EBITDA")
    va = b.sheet("Valuation Summary")
    b.put(va, "B2", "TTM ending June 30, 2025"); b.put(va, "C2", "TTM ending June 30, 2026")
    labels = {5: "Adj. EBITDA (B)", 6: "Multiple (A)", 7: "Implied Enterprise Value (A*B)", 8: "Cash", 9: "Debt", 10: "Total Common Equity"}
    for r, lab in labels.items():
        b.put(va, f"A{r}", lab)
    res = {}
    for col, (lo, hi), mult, cash in (("B", (0, 11), 9.25, 900_000.0), ("C", (12, 23), 10.1394, 1_583_937.05)):
        ttm = sum(adj[lo:hi + 1])
        ev = mult * ttm
        eq = ev + cash - 0
        b.put(va, f"{col}5", formula=f"=SUM(Monthly!{cols[lo]}3:{cols[hi]}3)", cached=ttm)
        b.put(va, f"{col}6", mult)
        b.put(va, f"{col}7", formula=f"={col}6*{col}5", cached=ev)
        b.put(va, f"{col}8", cash); b.put(va, f"{col}9", 0)
        b.put(va, f"{col}10", formula=f"={col}7+{col}8-{col}9", cached=eq)
        res[col] = {"ttm": ttm, "ev": ev, "equity": eq}
    ct = b.sheet("Cap Table")
    own = 0.9894
    b.put(ct, "A3", "XPV fully diluted ownership"); b.put(ct, "B3", own)
    val = res["C"]["equity"] * own
    b.put(ct, "A5", "XPV Value"); b.put(ct, "B5", formula="='Valuation Summary'!C10*B3", cached=val)
    b.put(ct, "A6", "Equity Cost Base"); b.put(ct, "B6", round(val, 2))                         # typed equal to XPV value
    b.put(ct, "A7", "Cost Base"); b.put(ct, "B7", 22_687_299)
    b.put(ct, "A9", "Invested capital"); b.put(ct, "B9", 19_000_000)
    b.put(ct, "A10", "MOIC"); b.put(ct, "B10", formula="=B5/B9", cached=val / 19_000_000)
    if fx:
        b.put(ct, "A12", "CAD/USD FX rate"); b.put(ct, "B12", fx)
        if usd_row:
            b.put(ct, "A13", "XPV Value (USD)"); b.put(ct, "B13", formula="=B5*B12", cached=val * fx)
    lp = b.sheet("LPAC")
    b.put(lp, "A53", "Comparable companies"); b.put(lp, "B54", "Company"); b.put(lp, "C54", "EV/EBITDA"); b.put(lp, "D54", "EBITDA"); b.put(lp, "E54", "EV")
    peers = [("Peer One", 11.2, 3_100_000), ("Peer Two", 9.8, 5_400_000), ("Peer Three", 12.5, 2_200_000)]
    for i, (nm, mu, eb) in enumerate(peers):
        r = 55 + i
        b.put(lp, f"B{r}", nm); b.put(lp, f"C{r}", mu); b.put(lp, f"D{r}", eb)
        b.put(lp, f"E{r}", formula=f"=C{r}*D{r}", cached=mu * eb)
    b.put(lp, "A60", "Enterprise Value"); b.put(lp, "E60", formula="=AVERAGE(E55:E57)", cached=sum(mu * eb for _, mu, eb in peers) / 3)
    b.put(lp, "A61", "EV/EBITDA multiple"); b.put(lp, "C61", formula='=COUNTIF(C55:C57,">0")', cached=3)
    b.put(lp, "A63", "Enterprise Value (CAD)"); b.put(lp, "E63", formula="=#REF!*1.35", cached="#REF!")
    old = b.sheet("Valuation Summary-Prior Period")
    b.put(old, "A7", "Implied Enterprise Value (A*B)"); b.put(old, "C7", formula="=#REF!*C5", cached="#REF!")
    b.put(old, "A10", "Total Common Equity"); b.put(old, "C10", 18_500_000)
    if second_chain:                                     # an identical, unconnected copy of the current chain: ambiguous
        sc = b.sheet("Scenario")
        for r, lab in labels.items():
            b.put(sc, f"A{r}", lab)
        b.put(sc, "C5", formula=f"=SUM(Monthly!{cols[12]}3:{cols[23]}3)", cached=res["C"]["ttm"])
        b.put(sc, "C6", 10.1394); b.put(sc, "C7", formula="=C6*C5", cached=res["C"]["ev"])
        b.put(sc, "C8", 1_583_937.05); b.put(sc, "C9", 0); b.put(sc, "C10", formula="=C7+C8-C9", cached=res["C"]["equity"])
        b.put(sc, "A12", "XPV Value (scenario)"); b.put(sc, "C12", formula="=C10*0.95", cached=res["C"]["equity"] * 0.95)   # a rival complete chain
    b.save(path)
    res.update(value=val, fx=fx)
    if fund_path:
        fb = FX.Book()
        fs = fb.sheet("Valuation Summary")
        for c_, t in zip("ABCDE", ["Company", "Invested capital", "Fair value Q1 2026", "Fair value Q2 2026", "MOIC"]):
            fb.put(fs, f"{c_}9", t)
        reported = anchor_value_override if anchor_value_override is not None else round(val * (fx or 1))
        rows = [("Other Holdings", 5_000_000, 6_100_000, 6_250_000), ("Demo Ocean Ltd", 19_000_000, 25_100_000, reported),
                ("Third Company", 8_000_000, 7_400_000, 7_900_000)]
        for i, (nm, inv, q1, q2) in enumerate(rows):
            r = 10 + i
            fb.put(fs, f"A{r}", nm); fb.put(fs, f"B{r}", inv); fb.put(fs, f"C{r}", q1); fb.put(fs, f"D{r}", q2)
            fb.put(fs, f"E{r}", formula=f"=D{r}/B{r}", cached=q2 / inv)
        fb.save(fund_path)
        res["reported"] = reported
    return res
