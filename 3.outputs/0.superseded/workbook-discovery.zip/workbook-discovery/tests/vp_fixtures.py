# fixtures.py (build 11) - synthetic test files, generated in code (no real company data anywhere in the package).
# Workbooks get Excel-style saved values ("cached values") injected into the XML, because openpyxl writes formulas
# without results. Every number here is computed in Python, so tests know the right answer.
import datetime, os, re, zipfile, shutil
from openpyxl import Workbook

EPOCH = datetime.date(1899, 12, 30)
MONTHS = 24                          # Jul 2024 .. Jun 2026 in Monthly!B:Y
FIRST = (2024, 7)
COLS = [chr(66 + i) for i in range(MONTHS)]          # B..Y


def month_end(y, m):
    nm = datetime.date(y + (m // 12), m % 12 + 1, 1)
    return nm - datetime.timedelta(days=1)


def months():
    y, m = FIRST
    out = []
    for _ in range(MONTHS):
        out.append((y, m))
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


def series():
    """the company's true monthly figures (units of currency), all multiples of 1,000."""
    out = []
    for i, (y, m) in enumerate(months()):
        rev = 800_000 + 12_000 * i + (i % 4) * 3_000
        cogs = round(0.45 * rev / 1000) * 1000
        opex = 150_000 + 2_000 * i
        rec = 5_000 if i % 5 == 0 else 0
        ma = 12_000 if i % 7 == 3 else 0
        cash = 300_000 + 5_000 * i
        debt = 1_200_000 - 10_000 * i
        out.append({"ym": (y, m), "rev": rev, "cogs": cogs, "gp": rev - cogs, "opex": opex, "ebitda": rev - cogs - opex,
                    "rec": rec, "ma": ma, "adj_ebitda": rev - cogs - opex + rec + ma, "cash": cash, "debt": debt,
                    "heads": 40 + i})
    return out


class Book:
    def __init__(self):
        self.wb = Workbook()
        self.wb.remove(self.wb.active)
        self.cached = {}

    def sheet(self, name):
        return self.wb.create_sheet(name)

    def put(self, ws, ref, value=None, formula=None, cached=None, fmt=None):
        if formula is not None:
            ws[ref] = formula
            self.cached[(ws.title, ref)] = cached
        else:
            ws[ref] = value
        if fmt:
            ws[ref].number_format = fmt

    def save(self, path):
        self.wb.save(path)
        inject(path, self.cached, self.wb.sheetnames)
        if getattr(self, "_external", None):
            add_external_link(path, self._external)
        return path


def _vxml(v):
    if isinstance(v, bool):
        return ' t="b"', str(int(v))
    if isinstance(v, (datetime.date, datetime.datetime)):
        d = v.date() if isinstance(v, datetime.datetime) else v
        return "", str((d - EPOCH).days)
    if isinstance(v, (int, float)):
        return "", repr(float(v)) if isinstance(v, float) else str(v)
    if isinstance(v, str) and v.startswith("#"):
        return ' t="e"', v
    return ' t="str"', str(v)


def inject(path, cached, sheetnames):
    """write saved values into openpyxl's empty <v></v> elements, as Excel would after a calculation."""
    tmp = path + ".tmp"
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            m = re.fullmatch(r"xl/worksheets/sheet(\d+)\.xml", item.filename)
            if m:
                sheet = sheetnames[int(m.group(1)) - 1]
                xml = data.decode("utf-8")
                for (sh, ref), v in cached.items():
                    if sh != sheet or v is None:
                        continue
                    t, txt = _vxml(v)
                    pat = re.compile(r'<c r="' + ref + r'"((?: [a-zA-Z:]+="[^"]*")*)><f>(.*?)</f><v\s*/?>(?:</v>)?</c>')
                    xml, n = pat.subn(lambda mm: f'<c r="{ref}"{re.sub(r" t=\"[^\"]*\"", "", mm.group(1))}{t}><f>{mm.group(2)}</f><v>{txt}</v></c>', xml)
                    if n != 1:
                        raise AssertionError(f"fixture: could not inject {sh}!{ref}")
                data = xml.encode("utf-8")
            zout.writestr(item, data)
    shutil.move(tmp, path)


def company_workbook(path, variant="ev_ebitda", fx=False, pasted_ttm=False, hardcoded_lp=False, ttm_off=False,
                     add_in=False, external=False, manual_calc=False, error_in_chain=False, formula_headers=False,
                     fname_company="Company A", shift=0, date_cell=datetime.datetime(2026, 6, 30), adj_in_rows=False,
                     add_in_error=False, noise_sheet=False, dynamic_ttm=False, sumif_bridge=False, linked_ttm=False):
    S = series()
    A_, Z_ = COLS[12 - shift], COLS[23 - shift]            # TTM window columns (shift moves the window back)
    b = Book()
    mo = b.sheet("Monthly")
    b.put(mo, "A1", f"{fname_company} - monthly financials")
    b.put(mo, "A3", "Line item")
    for i, (y, m) in enumerate(months()):
        c = COLS[i]
        if formula_headers and i > 0:
            b.put(mo, f"{c}3", formula=f"=EOMONTH({COLS[i - 1]}3,1)", cached=month_end(y, m), fmt="yyyy-mm-dd")
        else:
            b.put(mo, f"{c}3", datetime.datetime.combine(month_end(y, m), datetime.time()), fmt="yyyy-mm-dd")
    rows = {4: "Revenue", 5: "Cost of sales", 6: "Gross profit", 7: "Operating expenses", 8: "EBITDA",
            10: "Recruitment adjustment", 11: "M&A-related adjustment", 12: "Adjusted EBITDA", 14: "Cash",
            15: "Total debt", 17: "Headcount"}
    for r, lab in rows.items():
        b.put(mo, f"A{r}", lab)
    for i, s in enumerate(S):
        c = COLS[i]
        b.put(mo, f"{c}4", s["rev"]); b.put(mo, f"{c}5", s["cogs"])
        b.put(mo, f"{c}6", formula=f"={c}4-{c}5", cached=s["gp"])
        b.put(mo, f"{c}7", s["opex"])
        b.put(mo, f"{c}8", formula=f"={c}6-{c}7", cached=s["ebitda"])
        b.put(mo, f"{c}10", s["rec"]); b.put(mo, f"{c}11", s["ma"])
        b.put(mo, f"{c}12", formula=f"={c}8+{c}10+{c}11", cached=s["adj_ebitda"])
        b.put(mo, f"{c}14", s["cash"]); b.put(mo, f"{c}15", s["debt"]); b.put(mo, f"{c}17", s["heads"])
    last12 = S[12 - shift:24 - shift]
    ttm_rev = sum(s["rev"] for s in last12)
    ttm_e_window = S[-13:-1] if ttm_off else last12
    ttm_e = sum(s["ebitda"] for s in ttm_e_window) + (7_000 if linked_ttm else 0)   # a linked value: not this file's months
    ttm_adj = sum(s["rec"] + s["ma"] for s in last12)
    va = b.sheet("Valuation")
    b.put(va, "A1", f"{fname_company} - valuation")
    b.put(va, "A2", "Valuation date"); b.put(va, "B2", date_cell, fmt="yyyy-mm-dd")
    out = {"ttm_rev": ttm_rev, "ttm_ebitda": ttm_e, "ttm_adj": ttm_adj}
    if variant == "held_at_cost":
        b.put(va, "A4", "Valuation method"); b.put(va, "B4", "Held at cost")
        cost = 6_000_000
        lp = b.sheet("LP Summary")
        for c_, t in zip("ABCDE", ["Company", "Invested capital", "Current valuation", "Proceeds", "MOIC"]):
            b.put(lp, f"{c_}3", t)
        b.put(lp, "A4", fname_company); b.put(lp, "B4", cost)
        b.put(lp, "C4", formula="=B4", cached=cost); b.put(lp, "D4", 0)
        b.put(lp, "E4", formula="=(C4+D4)/B4", cached=1.0)
        if manual_calc:
            b.wb.calculation.calcMode = "manual"
        b.save(path)
        out.update(value=cost, cost=cost)
        return out
    b.put(va, "A4", "TTM revenue"); b.put(va, "B4", formula=f"=SUM(Monthly!{A_}4:{Z_}4)", cached=ttm_rev)
    b.put(va, "A5", "TTM EBITDA")
    if pasted_ttm:
        b.put(va, "B5", ttm_e)
    else:
        if linked_ttm:
            b.put(va, "B5", formula="=[1]Monthly!N8", cached=ttm_e)
        elif dynamic_ttm:
            b.put(va, "B5", formula='=SUMIFS(Monthly!B8:Y8,Monthly!B3:Y3,">"&EDATE(B2,-12),Monthly!B3:Y3,"<="&B2)', cached=ttm_e)
        else:
            b.put(va, "B5", formula="=SUM(Monthly!M8:X8)" if ttm_off else f"=SUM(Monthly!{A_}8:{Z_}8)", cached=ttm_e)
    if not adj_in_rows:
        b.put(va, "A6", "TTM adjustments"); b.put(va, "B6", formula=f"=SUM(Monthly!{A_}10:{Z_}11)", cached=ttm_adj)
    other = 0.0
    if error_in_chain:
        b.put(va, "A20", "Other adjustment"); b.put(va, "B20", formula='=VLOOKUP("x",A1:A2,2,FALSE)', cached="#N/A")
        b.put(va, "A7", "TTM Adjusted EBITDA"); b.put(va, "B7", formula="=B5+B6+IFERROR(B20,0)", cached=ttm_e + ttm_adj)
    elif adj_in_rows:
        b.put(va, "A7", "TTM Adjusted EBITDA"); b.put(va, "B7", formula=f"=SUM(Monthly!{A_}12:{Z_}12)", cached=ttm_e + ttm_adj)
    else:
        b.put(va, "A7", "TTM Adjusted EBITDA"); b.put(va, "B7", formula="=B5+B6", cached=ttm_e + ttm_adj)
    adj_e = ttm_e + ttm_adj + other
    b.put(va, "A9", "Comparable companies")
    comps = [10.5, 9.0, 11.2, 8.7]
    for j, cm in enumerate(comps):
        r = 10 + j
        b.put(va, f"A{r}", f"Comp {j + 1}")
        if add_in_error and j == 0:
            b.put(va, f"B{r}", formula='=_xll.PB.MULTIPLE("COMP1","EV/EBITDA")', cached="#NOTAUTH")
        elif add_in and j == 0:
            b.put(va, f"B{r}", formula='=_xll.PB.MULTIPLE("COMP1","EV/EBITDA")', cached=cm)
        elif external and j == 2:
            b.put(va, f"B{r}", formula="=[1]Comps!B5", cached=cm)
            b._external = external if isinstance(external, str) else None
        else:
            b.put(va, f"B{r}", cm)
    if add_in_error:
        avg = sum(comps[1:]) / 3
        b.put(va, "A14", "Average multiple"); b.put(va, "B14", formula="=IFERROR(AVERAGE(B10:B13),AVERAGE(B11:B13))", cached=avg)
    else:
        avg = sum(comps) / 4
        b.put(va, "A14", "Average multiple"); b.put(va, "B14", formula="=AVERAGE(B10:B13)", cached=avg)
    b.put(va, "A15", "Liquidity discount"); b.put(va, "B15", 0.25)
    mult = avg * (1 - 0.25)
    b.put(va, "A16", "Selected EV/EBITDA multiple"); b.put(va, "B16", formula="=B14*(1-B15)", cached=mult)
    if variant in ("blended", "ev_revenue"):
        b.put(va, "A17", "Selected EV/Revenue multiple"); b.put(va, "B17", 1.6)
    if variant == "blended":
        b.put(va, "A18", "Revenue weight"); b.put(va, "B18", 0.25)
        b.put(va, "A19", "EBITDA weight"); b.put(va, "B19", formula="=1-B18", cached=0.75)
        ev = 0.25 * 1.6 * ttm_rev + 0.75 * mult * adj_e
        b.put(va, "A21", "Enterprise value"); b.put(va, "B21", formula="=B18*B17*B4+B19*B16*B7", cached=ev)
    elif variant == "ev_revenue":
        ev = 1.6 * ttm_rev
        b.put(va, "A21", "Enterprise value"); b.put(va, "B21", formula="=B17*B4", cached=ev)
    else:
        ev = mult * adj_e
        b.put(va, "A21", "Enterprise value"); b.put(va, "B21", formula="=B16*B7", cached=ev)
    cash, debt = S[23 - shift]["cash"], S[23 - shift]["debt"]
    b.put(va, "A22", "Cash"); b.put(va, "B22", formula=f"=Monthly!{Z_}14", cached=cash)
    b.put(va, "A23", "Total debt"); b.put(va, "B23", formula=f"=Monthly!{Z_}15", cached=debt)
    eq = ev + cash - debt
    if sumif_bridge:
        for r, (lab, v) in {33: ("Loan - shareholder", 300_000), 34: ("Loan - vendor", 200_000), 35: ("Accrued interest", 50_000)}.items():
            b.put(va, f"A{r}", lab); b.put(va, f"B{r}", v)
        eq -= 500_000
        b.put(va, "A24", "Equity value"); b.put(va, "B24", formula='=B21+B22-B23-SUMIF(A33:A35,"Loan*",B33:B35)', cached=eq)
    else:
        b.put(va, "A24", "Equity value"); b.put(va, "B24", formula="=B21+B22-B23", cached=eq)
    b.put(va, "A25", "XPV fully diluted ownership"); b.put(va, "B25", 0.4)
    if fx:
        loc = eq * 0.4
        b.put(va, "A26", "XPV value (CAD)"); b.put(va, "B26", formula="=B24*B25", cached=loc)
        b.put(va, "A27", "CAD/USD rate"); b.put(va, "B27", 1.37)
        val = loc / 1.37
        b.put(va, "A28", "XPV value"); b.put(va, "B28", formula="=B26/B27", cached=val)
        vref = "Valuation!B28"
    else:
        val = eq * 0.4
        b.put(va, "A26", "XPV value"); b.put(va, "B26", formula="=B24*B25", cached=val)
        vref = "Valuation!B26"
    b.put(va, "A30", "Memo: employees"); b.put(va, "B30", 57)
    lp = b.sheet("LP Summary")
    for c_, t in zip("ABCDE", ["Company", "Invested capital", "Current valuation", "Proceeds", "MOIC"]):
        b.put(lp, f"{c_}3", t)
    cost = 6_000_000
    b.put(lp, "A4", fname_company); b.put(lp, "B4", cost)
    if hardcoded_lp:
        b.put(lp, "C4", val)
    else:
        b.put(lp, "C4", formula=f"={vref}", cached=val)
    b.put(lp, "D4", 0)
    b.put(lp, "E4", formula="=(C4+D4)/B4", cached=val / cost)
    if noise_sheet:
        nz = b.sheet("Data dump")
        for r in range(1, 51):
            for c in range(1, 21):
                nz.cell(r, c, r * 100 + c)
    if manual_calc:
        b.wb.calculation.calcMode = "manual"
    b.save(path)
    out.update(ev=ev, equity=eq, value=val, mult=mult, adj_ebitda=adj_e, cash=cash, debt=debt, cost=cost)
    return out


MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
               "November", "December"]


def statements(folder, yms, scale=1000, rename_revenue=False, mismatch=None, company="CompanyA"):
    """one file per month, values in thousands. mismatch=(line_key, (y, m), delta_in_thousands)."""
    os.makedirs(folder, exist_ok=True)
    by_ym = {s["ym"]: s for s in series()}
    paths = []
    for (y, m) in yms:
        s = by_ym.get((y, m))
        if s is None:                      # months after the workbook: extend the pattern
            i = (y * 12 + m) - (2024 * 12 + 7)
            rev = 800_000 + 12_000 * i + (i % 4) * 3_000
            cogs = round(0.45 * rev / 1000) * 1000
            opex = 150_000 + 2_000 * i
            s = {"rev": rev, "cogs": cogs, "gp": rev - cogs, "opex": opex, "ebitda": rev - cogs - opex,
                 "cash": 300_000 + 5_000 * i, "debt": 1_200_000 - 10_000 * i}
        d = month_end(y, m)
        name = f"{company}_Financial_Statements_{MONTH_NAMES[m - 1]}_{d.day}__{y}.xlsx"
        wb = Workbook()
        ws = wb.active
        ws.title = "Income Statement"
        ws["A1"] = company
        ws["A2"] = f"For the month ended {MONTH_NAMES[m - 1]} {d.day}, {y}"
        ws["B4"] = "Month"
        ws["C4"] = "Year to date"
        lines = [("Sales" if rename_revenue else "Revenue", "rev"), ("Cost of sales", "cogs"), ("Gross profit", "gp"),
                 ("Operating expenses", "opex"), ("EBITDA", "ebitda")]
        ytd_months = [(y, mm) for mm in range(1, m + 1)]
        for r, (lab, key) in enumerate(lines, 5):
            ws[f"A{r}"] = lab
            val = s[key] / scale
            if mismatch and mismatch[0] == key and mismatch[1] == (y, m):
                val += mismatch[2]
            ws[f"B{r}"] = val
            ws[f"C{r}"] = sum(by_ym[x][key] for x in ytd_months if x in by_ym) / scale
        bs = wb.create_sheet("Balance Sheet")
        bs["A2"] = f"As at {MONTH_NAMES[m - 1]} {d.day}, {y}"
        bs["B4"] = "Balance"
        bs["A5"] = "Cash"; bs["B5"] = s["cash"] / scale
        bs["A6"] = "Total debt"; bs["B6"] = s["debt"] / scale
        p = os.path.join(folder, name)
        wb.save(p)
        paths.append(p)
    return paths


def quarterly_workbook(path, fname_company="Company Q"):
    """quarterly columns (text headers 'Q3-24'..'Q2-26'): flows are 3-month sums, balances are quarter-end values."""
    S = series()
    qs = [S[i:i + 3] for i in range(0, 24, 3)]
    b = Book()
    qu = b.sheet("Quarterly")
    b.put(qu, "A1", "($)")
    cols = [chr(66 + i) for i in range(8)]
    for j, q in enumerate(qs):
        y, m = q[-1]["ym"]
        b.put(qu, f"{cols[j]}1", f"Q{(m - 1) // 3 + 1}-{str(y)[2:]}")
    for r, lab in {2: "Revenue", 3: "Cost of sales", 4: "Operating expenses", 5: "EBITDA", 6: "Cash", 7: "Total debt"}.items():
        b.put(qu, f"A{r}", lab)
    for j, q in enumerate(qs):
        c = cols[j]
        rev, cogs, opex = (sum(x[k] for x in q) for k in ("rev", "cogs", "opex"))
        b.put(qu, f"{c}2", rev); b.put(qu, f"{c}3", cogs); b.put(qu, f"{c}4", opex)
        b.put(qu, f"{c}5", formula=f"={c}2-{c}3-{c}4", cached=rev - cogs - opex)
        b.put(qu, f"{c}6", q[-1]["cash"]); b.put(qu, f"{c}7", q[-1]["debt"])
    last4 = qs[-4:]
    ttm_e = sum(x["ebitda"] for q in last4 for x in q)
    va = b.sheet("Valuation")
    b.put(va, "A2", "Valuation date"); b.put(va, "B2", datetime.datetime(2026, 6, 30), fmt="yyyy-mm-dd")
    b.put(va, "A4", "LTM EBITDA"); b.put(va, "B4", formula="=SUM(Quarterly!F5:I5)", cached=ttm_e)
    b.put(va, "A5", "Selected EV/EBITDA multiple"); b.put(va, "B5", 8.0)
    ev = 8.0 * ttm_e
    b.put(va, "A6", "Enterprise value"); b.put(va, "B6", formula="=B5*B4", cached=ev)
    cash, debt = qs[-1][-1]["cash"], qs[-1][-1]["debt"]
    b.put(va, "A7", "Cash"); b.put(va, "B7", formula="=Quarterly!I6", cached=cash)
    b.put(va, "A8", "Total debt"); b.put(va, "B8", formula="=Quarterly!I7", cached=debt)
    eq = ev + cash - debt
    b.put(va, "A9", "Equity value"); b.put(va, "B9", formula="=B6+B7-B8", cached=eq)
    b.put(va, "A10", "XPV fully diluted ownership"); b.put(va, "B10", 0.3)
    b.put(va, "A11", "XPV value"); b.put(va, "B11", formula="=B9*B10", cached=eq * 0.3)
    b.save(path)
    return {"ttm_ebitda": ttm_e, "ev": ev, "equity": eq, "value": eq * 0.3}


def month_vals(i, factor=1.0):
    """month i after Jul 2024 (negative = earlier) for one entity, multiples of 1,000."""
    r = lambda x: round(x * factor / 1000) * 1000
    rev = r(800_000 + 12_000 * i + (i % 4) * 3_000)
    cogs = r(0.45 * (800_000 + 12_000 * i + (i % 4) * 3_000))
    opex = r(150_000 + 2_000 * i)
    return {"rev": rev, "cogs": cogs, "opex": opex, "ebitda": rev - cogs - opex, "cash": r(300_000 + 5_000 * i),
            "debt": r(1_200_000 - 10_000 * i), "other": r(4_000 + 100 * i)}


def proforma_workbook(path, quarter="Q2", xpv_shares=3_000_000, extra_row=False, acquisition_note=False):
    """two entities -> 'Pro Forma Financials (Qn)' (consolidation + EBITDA adjustments + TTM) -> valuation -> cap table
    (liquidation preference, MAX waterfall) -> LP summary. quarter='Q1' gives the previous quarter (months end Mar 2026)."""
    first = -3 if quarter == "Q1" else 0
    idx = list(range(first, first + 24))
    ym = lambda i: ((2024 * 12 + 6 + i) // 12, (2024 * 12 + 6 + i) % 12 + 1)
    b = Book()
    ent = {"Entity A Monthly": 0.6, "Entity B Monthly": 0.4}
    vals = {sh: [month_vals(i, f) for i in idx] for sh, f in ent.items()}
    for sh in ent:
        ws = b.sheet(sh)
        b.put(ws, "A3", "Line item")
        for j, i in enumerate(idx):
            y, m = ym(i)
            b.put(ws, f"{COLS[j]}3", datetime.datetime.combine(month_end(y, m), datetime.time()), fmt="yyyy-mm-dd")
        for r, lab in {4: "Revenue", 5: "Cost of sales", 6: "Operating expenses", 7: "EBITDA", 9: "Cash", 10: "Total debt"}.items():
            b.put(ws, f"A{r}", lab)
        if extra_row and sh == "Entity A Monthly":
            b.put(ws, "A8", "Other income")
        for j, v in enumerate(vals[sh]):
            c = COLS[j]
            b.put(ws, f"{c}4", v["rev"]); b.put(ws, f"{c}5", v["cogs"]); b.put(ws, f"{c}6", v["opex"])
            if extra_row and sh == "Entity A Monthly":
                b.put(ws, f"{c}8", v["other"])
                b.put(ws, f"{c}7", formula=f"={c}4-{c}5-{c}6+{c}8", cached=v["ebitda"] + v["other"])
            else:
                b.put(ws, f"{c}7", formula=f"={c}4-{c}5-{c}6", cached=v["ebitda"])
            b.put(ws, f"{c}9", v["cash"]); b.put(ws, f"{c}10", v["debt"])
    pf_name = f"Pro Forma Financials ({quarter})"
    pf = b.sheet(pf_name)
    qa, qb = "'Entity A Monthly'", "'Entity B Monthly'"
    b.put(pf, "A3", "Pro forma (Entity A + Entity B)")
    for j, i in enumerate(idx):
        y, m = ym(i)
        b.put(pf, f"{COLS[j]}3", datetime.datetime.combine(month_end(y, m), datetime.time()), fmt="yyyy-mm-dd")
    for r, lab in {4: "Revenue", 5: "EBITDA", 7: "Recruitment adjustment", 8: "M&A-related adjustment", 9: "Adjusted EBITDA",
                   11: "Cash", 12: "Total debt", 14: "TTM revenue", 15: "TTM EBITDA", 16: "TTM adjustments", 17: "TTM Adjusted EBITDA"}.items():
        b.put(pf, f"A{r}", lab)
    pfv = []
    for j, i in enumerate(idx):
        c = COLS[j]
        a_, b_ = vals["Entity A Monthly"][j], vals["Entity B Monthly"][j]
        e_a = a_["ebitda"] + (a_["other"] if extra_row else 0)
        rec = 5_000 if i % 5 == 0 else 0
        ma = 12_000 if i % 7 == 3 else 0
        row = {"rev": a_["rev"] + b_["rev"], "ebitda": e_a + b_["ebitda"], "rec": rec, "ma": ma,
               "cash": a_["cash"] + b_["cash"], "debt": a_["debt"] + b_["debt"]}
        row["adj"] = row["ebitda"] + rec + ma
        pfv.append(row)
        b.put(pf, f"{c}4", formula=f"={qa}!{c}4+{qb}!{c}4", cached=row["rev"])
        b.put(pf, f"{c}5", formula=f"={qa}!{c}7+{qb}!{c}7", cached=row["ebitda"])
        b.put(pf, f"{c}7", rec); b.put(pf, f"{c}8", ma)
        b.put(pf, f"{c}9", formula=f"={c}5+{c}7+{c}8", cached=row["adj"])
        b.put(pf, f"{c}11", formula=f"={qa}!{c}9+{qb}!{c}9", cached=row["cash"])
        b.put(pf, f"{c}12", formula=f"={qa}!{c}10+{qb}!{c}10", cached=row["debt"])
    if acquisition_note:
        b.put(pf, "A20", "Pre-acquisition EBITDA of Entity B (acquired Jan 2025) included in pro forma")
    last12 = pfv[12:]
    t_rev, t_e = sum(x["rev"] for x in last12), sum(x["ebitda"] for x in last12)
    t_adj = sum(x["rec"] + x["ma"] for x in last12)
    b.put(pf, "AA14", formula="=SUM(N4:Y4)", cached=t_rev)
    b.put(pf, "AA15", formula="=SUM(N5:Y5)", cached=t_e)
    b.put(pf, "AA16", formula="=SUM(N7:Y8)", cached=t_adj)
    b.put(pf, "AA17", formula="=AA15+AA16", cached=t_e + t_adj)
    q = f"'{pf_name}'"
    va = b.sheet("Valuation")
    end = ym(idx[-1])
    b.put(va, "A2", "Valuation date"); b.put(va, "B2", datetime.datetime.combine(month_end(*end), datetime.time()), fmt="yyyy-mm-dd")
    adj_e = t_e + t_adj
    b.put(va, "A4", "LTM Adjusted EBITDA"); b.put(va, "B4", formula=f"={q}!AA17", cached=adj_e)
    comps = [9.0, 10.0, 11.0]
    for j, cm in enumerate(comps):
        b.put(va, f"A{6 + j}", f"Comp {j + 1}"); b.put(va, f"B{6 + j}", cm)
    avg = sum(comps) / 3
    b.put(va, "A9", "Average multiple"); b.put(va, "B9", formula="=AVERAGE(B6:B8)", cached=avg)
    b.put(va, "A10", "Liquidity discount"); b.put(va, "B10", 0.2)
    mult = avg * 0.8
    b.put(va, "A11", "Selected EV/EBITDA multiple"); b.put(va, "B11", formula="=B9*(1-B10)", cached=mult)
    ev = mult * adj_e
    b.put(va, "A12", "Enterprise value"); b.put(va, "B12", formula="=B11*B4", cached=ev)
    cash, debt = pfv[-1]["cash"], pfv[-1]["debt"]
    b.put(va, "A13", "Cash"); b.put(va, "B13", formula=f"={q}!Y11", cached=cash)
    b.put(va, "A14", "Total debt"); b.put(va, "B14", formula=f"={q}!Y12", cached=debt)
    eq = ev + cash - debt
    b.put(va, "A15", "Equity value"); b.put(va, "B15", formula="=B12+B13-B14", cached=eq)
    ct = b.sheet("Cap Table")
    common, pref_sh, opts = 6_000_000, 3_000_000, 1_000_000
    fd = common + pref_sh + opts
    own = xpv_shares / fd
    lpref = 5_000_000
    val = max(lpref, own * eq)
    for r, (lab, v) in enumerate([("Common shares", common), ("Series A preferred shares", pref_sh), ("Options outstanding", opts)], 3):
        b.put(ct, f"A{r}", lab); b.put(ct, f"B{r}", v)
    b.put(ct, "A6", "Fully diluted shares"); b.put(ct, "B6", formula="=SUM(B3:B5)", cached=fd)
    b.put(ct, "A7", "XPV shares"); b.put(ct, "B7", xpv_shares)
    b.put(ct, "A8", "XPV fully diluted ownership"); b.put(ct, "B8", formula="=B7/B6", cached=own)
    b.put(ct, "A9", "XPV liquidation preference"); b.put(ct, "B9", lpref)
    b.put(ct, "A10", "XPV value"); b.put(ct, "B10", formula="=MAX(B9,B8*Valuation!B15)", cached=val)
    lp = b.sheet("LP Summary")
    for c_, t in zip("ABCDE", ["Company", "Invested capital", "Current valuation", "Proceeds", "MOIC"]):
        b.put(lp, f"{c_}3", t)
    b.put(lp, "A4", "Delta Water"); b.put(lp, "B4", 8_000_000)
    b.put(lp, "C4", formula="='Cap Table'!B10", cached=val); b.put(lp, "D4", 0)
    b.put(lp, "E4", formula="=(C4+D4)/B4", cached=val / 8_000_000)
    b.save(path)
    return {"ev": ev, "equity": eq, "value": val, "ownership": own}


def entity_statements(folder, entity, factor, yms):
    os.makedirs(folder, exist_ok=True)
    paths = []
    for (y, m) in yms:
        i = (y * 12 + m) - (2024 * 12 + 7)
        v = month_vals(i, factor)
        d = month_end(y, m)
        wb = Workbook()
        ws = wb.active
        ws.title = "Income Statement"
        ws["A1"] = entity
        ws["A2"] = f"For the month ended {MONTH_NAMES[m - 1]} {d.day}, {y}"
        ws["B4"] = "Month"
        for r, (lab, k) in enumerate([("Revenue", "rev"), ("Cost of sales", "cogs"), ("Operating expenses", "opex"), ("EBITDA", "ebitda")], 5):
            ws[f"A{r}"] = lab
            ws[f"B{r}"] = v[k] / 1000
        bs = wb.create_sheet("Balance Sheet")
        bs["A2"] = f"As at {MONTH_NAMES[m - 1]} {d.day}, {y}"
        bs["B4"] = "Balance"
        bs["A5"] = "Cash"; bs["B5"] = v["cash"] / 1000
        bs["A6"] = "Total debt"; bs["B6"] = v["debt"] / 1000
        p = os.path.join(folder, f"{entity}_Financial_Statements_{MONTH_NAMES[m - 1]}_{d.day}__{y}.xlsx")
        wb.save(p)
        paths.append(p)
    return paths


def cap_table_file(path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Cap table"
    for r, (lab, v) in enumerate([("Common shares", 6_000_000), ("Series A preferred shares", 3_000_000),
                                  ("Fully diluted shares", 10_000_000), ("Liquidation preference", 5_000_000)], 1):
        ws[f"A{r}"] = lab
        ws[f"B{r}"] = v
    wb.save(path)
    return path


def add_external_link(path, target_name):
    """give the workbook an external-link part naming the linked file (as Excel stores it)."""
    tmp = path + ".tmp"
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            zout.writestr(item, zin.read(item.filename))
        zout.writestr("xl/externalLinks/externalLink1.xml",
                      '<externalLink xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><externalBook r:id="rId1" '
                      'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/></externalLink>')
        zout.writestr("xl/externalLinks/_rels/externalLink1.xml.rels",
                      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" '
                      'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/externalLinkPath" '
                      f'Target="https://example.sharepoint.com/Shared%20Documents/Monthly/{target_name.replace(" ", "%20")}" TargetMode="External"/></Relationships>')
    shutil.move(tmp, path)


# ================================================================================================ build 11.3 (WP7)
# Synthetic fixture factory: one valuation layout with toggleable structural challenges, so each test reproduces one
# real-file challenge without real data. Every value is computed here, so tests know the right answer.
#   older           an older valuation period side by side (left of the requested one), internally consistent
#   column_roles    Actual / Budget / Variance columns for each period (budget_first puts Budget left of Actual)
#   decoy           "comparable": the applied multiple is the MEDIAN of an odd comparable set (equals one peer) and
#                   has a weak label; "ambiguous_multiple": a second 'Selected EV/EBITDA multiple' that EV never uses
#   external        {"active": name, "stale": [names]}: one link a comparable reads, plus link records nothing uses
#   unsupported_ev  EV's formula uses syntax Python cannot re-compute (IF with a comparison)
#   acquisition     a pro forma pre-acquisition EBITDA row with historical months (before the acquisition date)
F_FIRST, F_MONTHS = (2024, 1), 30                     # Jan 2024 .. Jun 2026 on Monthly!B:AE


def col_letter(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def f_months():
    y, m = F_FIRST
    out = []
    for _ in range(F_MONTHS):
        out.append((y, m))
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


def fvals(i, factor=1.0):
    """month i after Jan 2024 for the factory company (multiples of 1,000)."""
    r = lambda x: round(x * factor / 1000) * 1000
    rev = r(900_000 + 10_000 * i + (i % 3) * 4_000)
    cogs = r(0.42 * (900_000 + 10_000 * i + (i % 3) * 4_000))
    opex = r(160_000 + 1_500 * i)
    return {"rev": rev, "cogs": cogs, "opex": opex, "ebitda": rev - cogs - opex, "rec": 6_000 if i % 4 == 1 else 0,
            "preacq": (20_000 + 500 * i) if i < 18 else 0, "cash": r(350_000 + 4_000 * i), "debt": r(1_500_000 - 12_000 * i)}


def ym_index(y, m):
    return (y * 12 + m) - (F_FIRST[0] * 12 + F_FIRST[1])


MON3 = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def factory_workbook(path, valuation=(2026, 3), older=None, column_roles=False, budget_first=False, decoy=None,
                     external=None, unsupported_ev=False, acquisition=False, company="Delta Water",
                     acquisition_label="Pro forma pre-acquisition EBITDA (Gamma, before Jul 2025)"):
    b = Book()
    mcols = [col_letter(2 + i) for i in range(F_MONTHS)]
    V = [fvals(i) for i in range(F_MONTHS)]
    mo = b.sheet("Monthly")
    b.put(mo, "A1", f"{company} - monthly financials")
    b.put(mo, "A3", "Line item")
    for i, (y, m) in enumerate(f_months()):
        b.put(mo, f"{mcols[i]}3", datetime.datetime.combine(month_end(y, m), datetime.time()), fmt="yyyy-mm-dd")
    labels = {4: "Revenue", 5: "Cost of sales", 6: "Operating expenses", 7: "EBITDA", 9: "Recruitment adjustment",
              10: "Adjusted EBITDA", 12: "Cash", 13: "Total debt"}
    if acquisition:
        labels[8] = acquisition_label
    for r, lab in labels.items():
        b.put(mo, f"A{r}", lab)
    for i, v in enumerate(V):
        c = mcols[i]
        b.put(mo, f"{c}4", v["rev"]); b.put(mo, f"{c}5", v["cogs"]); b.put(mo, f"{c}6", v["opex"])
        b.put(mo, f"{c}7", formula=f"={c}4-{c}5-{c}6", cached=v["ebitda"])
        b.put(mo, f"{c}9", v["rec"])
        pa = v["preacq"] if acquisition else 0
        if acquisition:
            b.put(mo, f"{c}8", pa)
            b.put(mo, f"{c}10", formula=f"={c}7+{c}8+{c}9", cached=v["ebitda"] + pa + v["rec"])
        else:
            b.put(mo, f"{c}10", formula=f"={c}7+{c}9", cached=v["ebitda"] + v["rec"])
        b.put(mo, f"{c}12", v["cash"]); b.put(mo, f"{c}13", v["debt"])
    # comparables
    co = b.sheet("Comps")
    b.put(co, "A1", "Comparable companies")
    b.put(co, "A3", "Company"); b.put(co, "B3", "EV/EBITDA")
    peers = [("Peer Alpha", 8.0), ("Peer Beta", 9.5), ("Peer Gamma", 11.0)]
    for j, (nm, x) in enumerate(peers):
        b.put(co, f"A{4 + j}", nm)
        if external and j == 2:
            b.put(co, f"B{4 + j}", formula="=[1]Peers!B6", cached=x)
        else:
            b.put(co, f"B{4 + j}", x)
    median = 9.5
    if decoy == "comparable":
        applied, applied_src = median, "=MEDIAN(Comps!B4:B6)"
    else:
        b.put(co, "A8", "Median"); b.put(co, "B8", formula="=MEDIAN(B4:B6)", cached=median)
        b.put(co, "A9", "Liquidity discount"); b.put(co, "B9", 0.2)
        applied = median * 0.8
        b.put(co, "A10", "Applied EV/EBITDA multiple"); b.put(co, "B10", formula="=B8*(1-B9)", cached=applied)
        applied_src = "=Comps!B10"
    # valuation summary: one group of columns per period
    va = b.sheet("Valuation Summary")
    b.put(va, "A1", f"{company} - valuation summary")
    b.put(va, "A3", "Valuation date")
    rows = {5: "TTM revenue", 6: "TTM EBITDA", 7: "TTM adjustments", 8: "TTM Adjusted EBITDA",
            10: "Multiple applied (x)" if decoy == "comparable" else "Selected EV/EBITDA multiple", 11: "Enterprise value",
            12: "Cash", 13: "Total debt", 14: "Equity value", 15: "XPV fully diluted ownership", 16: "XPV value"}
    for r, lab in rows.items():
        b.put(va, f"A{r}", lab)
    periods = ([older] if older else []) + [valuation]
    roles = (["Budget", "Actual", "Variance"] if budget_first else ["Actual", "Budget", "Variance"]) if column_roles else ["Actual"]
    col, out, actual_col = 2, {}, {}
    for p in periods:
        y, m = p
        end_i = ym_index(y, m)
        win = list(range(end_i - 11, end_i + 1))
        c0, c1 = mcols[win[0]], mcols[win[-1]]
        t_rev = sum(V[i]["rev"] for i in win)
        t_e = sum(V[i]["ebitda"] for i in win)
        t_adj = sum(V[i]["rec"] + (V[i]["preacq"] if acquisition else 0) for i in win)
        mult = applied if p == valuation else 7.0
        adj_e = t_e + t_adj
        ev = mult * adj_e
        cash, debt = V[end_i]["cash"], V[end_i]["debt"]
        eq = ev + cash - debt
        val = eq * 0.35
        vals = {5: t_rev, 6: t_e, 7: t_adj, 8: adj_e, 10: mult, 11: ev, 12: cash, 13: debt, 14: eq, 15: 0.35, 16: val}
        cols = {}
        for role in roles:
            c = col_letter(col)
            cols[role] = c
            col += 1
        a = cols["Actual"]
        actual_col[p] = a
        for role, c in cols.items():
            head = f"{MON3[m - 1]}-{str(y)[2:]}" + ("" if role == "Actual" else f" {role}")
            b.put(va, f"{c}2", head)
            if role == "Actual":
                b.put(va, f"{c}3", datetime.datetime.combine(month_end(y, m), datetime.time()), fmt="yyyy-mm-dd")
                b.put(va, f"{c}5", formula=f"=SUM(Monthly!{c0}4:{c1}4)", cached=t_rev)
                b.put(va, f"{c}6", formula=f"=SUM(Monthly!{c0}7:{c1}7)", cached=t_e)
                adj_rows = "8:" if acquisition else "9:"
                b.put(va, f"{c}7", formula=f"=SUM(Monthly!{c0}{adj_rows[:-1]}:{c1}9)", cached=t_adj)
                b.put(va, f"{c}8", formula=f"={c}6+{c}7", cached=adj_e)
                if p == valuation:
                    b.put(va, f"{c}10", formula=applied_src, cached=mult)
                else:
                    b.put(va, f"{c}10", formula=f"=ROUND({mult},4)", cached=mult)     # the older quarter's own multiple
                if unsupported_ev and p == valuation:
                    b.put(va, f"{c}11", formula=f"=IF({c}10>0,{c}10*{c}8,0)", cached=ev)
                else:
                    b.put(va, f"{c}11", formula=f"={c}10*{c}8", cached=ev)
                b.put(va, f"{c}12", formula=f"=Monthly!{c1}12", cached=cash)
                b.put(va, f"{c}13", formula=f"=Monthly!{c1}13", cached=debt)
                b.put(va, f"{c}14", formula=f"={c}11+{c}12-{c}13", cached=eq)
                b.put(va, f"{c}15", 0.35)
                b.put(va, f"{c}16", formula=f"={c}14*{c}15", cached=val)
            elif role == "Budget":
                for r in (5, 6, 7, 8, 11, 12, 13, 14, 16):
                    b.put(va, f"{c}{r}", round(vals[r] * 1.05, 2))
                b.put(va, f"{c}10", mult); b.put(va, f"{c}15", 0.35)
            else:
                bc = cols["Budget"]
                for r in (5, 6, 7, 8, 11, 14, 16):
                    b.put(va, f"{c}{r}", formula=f"={a}{r}-{bc}{r}", cached=vals[r] - round(vals[r] * 1.05, 2))
        out[p] = dict(vals, ev=ev, equity=eq, value=val, mult=mult, adj_ebitda=adj_e, col=a,
                      window=(f"{win[0] // 12 + F_FIRST[0]}-{win[0] % 12 + 1:02d}", f"{y}-{m:02d}"))
    if decoy == "ambiguous_multiple":
        su = b.sheet("Summary")
        b.put(su, "A1", "Board summary")
        b.put(su, "A5", "Selected EV/EBITDA multiple")
        b.put(su, "B5", formula=f"=ROUND('Valuation Summary'!{actual_col[valuation]}10,6)", cached=applied)
    lp = b.sheet("LP Summary")
    for c_, t in zip("ABCDE", ["Company", "Invested capital", "Current valuation", "Proceeds", "MOIC"]):
        b.put(lp, f"{c_}3", t)
    cur = out[valuation]
    b.put(lp, "A4", company); b.put(lp, "B4", 6_000_000)
    b.put(lp, "C4", formula=f"='Valuation Summary'!{cur['col']}16", cached=cur["value"]); b.put(lp, "D4", 0)
    b.put(lp, "E4", formula="=(C4+D4)/B4", cached=cur["value"] / 6_000_000)
    b.save(path)
    if external:
        add_external_links(path, [external["active"]] + list(external.get("stale", [])))
    return out


def add_external_links(path, names):
    """external-link parts as Excel stores them: workbook.xml <externalReferences> (order = the [n] in formulas),
    each with an externalLinkN.xml part and its relationship to the linked file."""
    tmp = path + ".tmp"
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == "xl/workbook.xml":
                refs = "".join(f'<externalReference r:id="rIdX{n}"/>' for n in range(1, len(names) + 1))
                data = data.decode("utf-8").replace(
                    "</sheets>", '</sheets><externalReferences xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
                    + refs + "</externalReferences>").encode("utf-8")
            elif item.filename == "xl/_rels/workbook.xml.rels":
                rel = "".join(f'<Relationship Id="rIdX{n}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/externalLink" '
                              f'Target="externalLinks/externalLink{n}.xml"/>' for n in range(1, len(names) + 1))
                data = data.decode("utf-8").replace("</Relationships>", rel + "</Relationships>").encode("utf-8")
            elif item.filename == "[Content_Types].xml":
                ov = "".join(f'<Override PartName="/xl/externalLinks/externalLink{n}.xml" '
                             'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.externalLink+xml"/>'
                             for n in range(1, len(names) + 1))
                data = data.decode("utf-8").replace("</Types>", ov + "</Types>").encode("utf-8")
            zout.writestr(item, data)
        for n, nm in enumerate(names, 1):
            zout.writestr(f"xl/externalLinks/externalLink{n}.xml",
                          '<externalLink xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><externalBook r:id="rId1" '
                          'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"/></externalLink>')
            zout.writestr(f"xl/externalLinks/_rels/externalLink{n}.xml.rels",
                          '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" '
                          'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/externalLinkPath" '
                          f'Target="https://example.sharepoint.com/Shared%20Documents/Data/{nm.replace(" ", "%20")}" TargetMode="External"/></Relationships>')
    shutil.move(tmp, path)


def factory_statements(folder, yms, entity="Delta_Water", heading=None, suffix="", delta=None, factor=1.0):
    """one statement file per month (thousands). heading: the entity named inside the file (default: the file's entity).
    delta=(key, (y, m), change in thousands) makes a revised or conflicting copy."""
    os.makedirs(folder, exist_ok=True)
    paths = []
    for (y, m) in yms:
        v = fvals(ym_index(y, m), factor)
        d = month_end(y, m)
        wb = Workbook()
        ws = wb.active
        ws.title = "Income Statement"
        ws["A1"] = heading if heading is not None else entity.replace("_", " ")
        ws["A2"] = f"For the month ended {MONTH_NAMES[m - 1]} {d.day}, {y}"
        ws["B4"] = "Month"
        for r, (lab, k) in enumerate([("Revenue", "rev"), ("Cost of sales", "cogs"), ("Operating expenses", "opex"), ("EBITDA", "ebitda")], 5):
            ws[f"A{r}"] = lab
            x = v[k] / 1000
            if delta and delta[0] == k and delta[1] == (y, m):
                x += delta[2]
            ws[f"B{r}"] = x
        bs = wb.create_sheet("Balance Sheet")
        bs["A2"] = f"As at {MONTH_NAMES[m - 1]} {d.day}, {y}"
        bs["B4"] = "Balance"
        bs["A5"] = "Cash"; bs["B5"] = v["cash"] / 1000
        bs["A6"] = "Total debt"; bs["B6"] = v["debt"] / 1000
        p = os.path.join(folder, f"{entity}_Financial_Statements_{MONTH_NAMES[m - 1]}_{d.day}__{y}{suffix}.xlsx")
        wb.save(p)
        paths.append(p)
    return paths


def consolidated_statements(folder, yms, company="Delta_Water"):
    """the consolidated pack for proforma_workbook's two entities (Entity A 0.6 + Entity B 0.4), thousands."""
    os.makedirs(folder, exist_ok=True)
    paths = []
    for (y, m) in yms:
        i = (y * 12 + m) - (2024 * 12 + 7)
        a_, b_ = month_vals(i, 0.6), month_vals(i, 0.4)
        d = month_end(y, m)
        wb = Workbook()
        ws = wb.active
        ws.title = "Income Statement"
        ws["A1"] = f"{company.replace('_', ' ')} - consolidated"
        ws["A2"] = f"For the month ended {MONTH_NAMES[m - 1]} {d.day}, {y}"
        ws["B4"] = "Month"
        for r, (lab, k) in enumerate([("Revenue", "rev"), ("EBITDA", "ebitda")], 5):
            ws[f"A{r}"] = lab
            ws[f"B{r}"] = (a_[k] + b_[k]) / 1000
        p = os.path.join(folder, f"{company}_Consolidated_Financial_Statements_{MONTH_NAMES[m - 1]}_{d.day}__{y}.xlsx")
        wb.save(p)
        paths.append(p)
    return paths
