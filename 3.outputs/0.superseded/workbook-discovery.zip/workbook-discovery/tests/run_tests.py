# tests/run_tests.py (build 11.7) - discovery and benchmark tests on synthetic workbooks, run through the command lines
# exactly as the agent runs them. D = discovery, B = benchmark, M = mutation (layout changes must not break meaning;
# P = pre-flight and file handling, I = invariants, E = errors, C = contracts and hygiene, S = schemas, R = rules;
# CH = chain-first key numbers (11.7: the failures of the first real run, rebuilt with made-up numbers);
# real changes must be caught), V = the vendored build 11.3 code is unchanged. Keys used here are written from what each
# fixture's author knows - never from discovery's output.
import ast, datetime, glob, hashlib, json, os, re, shutil, subprocess, sys, tempfile, traceback
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path[:0] = [HERE, os.path.join(PKG, "discovery", "vp"), PKG, os.path.join(PKG, "benchmark")]
import vp_fixtures as FX
import dfixtures as DF
from common.util import read_jsonl_gz, load, sha256_file, cell_text, canon, sha256_text
import xmlcount as XC

DISC = os.path.join(PKG, "discovery", "discover.py")
BENCH = os.path.join(PKG, "benchmark", "bench.py")
ROOT = tempfile.mkdtemp(prefix="wd_tests_")
NOW = "2026-10-08T12:00:00"
RESULTS, TESTS = [], []


def env(now=NOW):
    return dict(os.environ, VALUATION_NOW=now, PYTHONDONTWRITEBYTECODE="1")


def run(script, args, cwd, now=NOW):
    p = subprocess.run([sys.executable, script] + args, cwd=cwd, env=dict(env(now), WD_OUTPUT_ROOT=cwd), capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


def case(name):
    d = os.path.join(ROOT, re.sub(r"[^A-Za-z0-9]+", "_", name))
    os.makedirs(d)
    return d


def discover(d, wb, pe, out="map", now=NOW):
    rc, o = run(DISC, ["--workbook", wb, "--period-end", pe, "--out", out], d, now)
    assert rc == 0, o
    return o, load(os.path.join(d, out, "workbook_map.json")), {r["cell"]: r for r in read_jsonl_gz(os.path.join(d, out, "cells.jsonl.gz"))}


def test(name):
    def deco(fn):
        def w():
            try:
                fn()
                RESULTS.append((name, True, ""))
            except AssertionError as e:
                RESULTS.append((name, False, str(e)[:700]))
            except Exception as e:
                RESULTS.append((name, False, f"{type(e).__name__}: {e}\n{traceback.format_exc()[-900:]}"))
        TESTS.append(w)
        return w
    return deco


def has(text, *needles):
    for n in needles:
        assert n in text, f"expected {n!r} in:\n{text[-2000:]}"


def structures(name):
    d = case(name)
    DF.structures_workbook(os.path.join(d, "S.xlsx"))
    return (d,) + discover(d, "S.xlsx", "2025-12-31")


# ------------------------------------------------------------------------------------------------ D discovery
@test("D.1 physical inventory equals the independent standard-library checker (shared formulas, spill, table, links)")
def d1():
    d, o, M, C = structures("d1")
    rc, out = run(BENCH, ["physical", "--workbook", "S.xlsx", "--program", "map"], d)
    assert rc == 0, out
    x = XC.scan(os.path.join(d, "S.xlsx"))
    assert x["totals"]["formulas"] > 40 and x["totals"]["formulas"] == M["layer0"]["totals"]["formula_cells"], (x["totals"], M["layer0"]["totals"])
    has(out, f"formula cells {x['totals']['formulas']} of {x['totals']['formulas']} PASS", "array result cells 2 of 2 PASS")


@test("D.2 shared-formula members are formula cells; spilled cells are formula results, never typed inputs")
def d2():
    d, o, M, C = structures("d2")
    assert M["layer0"]["shared_formula_members"] == 3 and M["layer0"]["dynamic_array_formulas"] == 1, M["layer0"]
    assert C["Calc!D30"]["l0"]["kind"] == "formula" and C["Calc!D30"]["l1"]["refs"][0]["ref"] == "Inputs!D4", C["Calc!D30"]
    assert C["Calc!D30"]["l1"]["flags"]["value_verification"] == "RECOMPUTED", C["Calc!D30"]["l1"]["flags"]
    assert C["Calc!G3"]["l0"]["kind"] == "array_result", C["Calc!G3"]["l0"]


@test("D.3 every graph-status case is flagged: literal / computed INDIRECT, INDEX, STDEV, #REF!, external, circular, table, names")
def d3():
    d, o, M, C = structures("d3")
    f = lambda c: C[c]["l1"]["flags"]
    assert f("Calc!B4")["dynamic_resolution"] == "DYNAMIC_RESOLVED" and C["Calc!B4"]["l1"]["refs"][0]["ref"] == "Inputs!B4"
    assert f("Calc!B5")["dynamic_resolution"] == "DYNAMIC_UNRESOLVED"
    assert f("Calc!B6")["references_extracted"] == "OVER_APPROXIMATED"
    assert f("Calc!B7")["references_extracted"] == "COMPLETE" and f("Calc!B7")["value_verification"] == "NOT_RECOMPUTED"
    assert f("Calc!B8")["references_extracted"] == "MISSING"
    assert f("Calc!B9")["location"] == "EXTERNAL" and f("Calc!B9")["external_identified"] is True
    assert C["Calc!B9"]["l1"]["refs"][0]["link"] == "Rates Feed.xlsx"
    assert f("Calc!B11")["cycle"] == f("Calc!B12")["cycle"] == "CIRCULAR" and f("Calc!B2")["cycle"] == "ACYCLIC"
    assert C["Calc!B13"]["l1"]["refs"][0]["ref"] == "Tbl!B2:B4" and f("Calc!B13")["references_extracted"] == "COMPLETE", C["Calc!B13"]["l1"]
    assert C["Calc!B14"]["l1"]["refs"][0]["ref"] == "Inputs!B5:M5" and C["Calc!B14"]["l1"]["refs"][0]["via"] == "MyRange"
    assert f("Calc!B15")["references_extracted"] == "COMPLETE"
    assert f("Calc!B2")["value_verification"] == "RECOMPUTED"


@test("D.4 no silent truncation: every formula node carries all five graph-status flags")
def d4():
    d, o, M, C = structures("d4")
    forms = [r for r in C.values() if r["l0"]["kind"] == "formula"]
    assert forms and all(set(r["l1"]["flags"]) >= {"references_extracted", "dynamic_resolution", "location", "cycle", "value_verification"} for r in forms)
    assert len(forms) == M["layer0"]["totals"]["formula_cells"] == M["layer1"]["formula_nodes"]


@test("D.5 a date many formulas use is a hub and does not merge unrelated calculations into one region")
def d5():
    d, o, M, C = structures("d5")
    assert "Inputs!B1" in M["layer1"]["hubs"], M["layer1"]["hubs"]
    assert C["Calc!B16"]["l1"]["region"] == C["Calc!B2"]["l1"]["region"]          # B16 belongs with the TTM it uses
    assert C["Calc!D2"]["l1"]["region"] != C["Calc!B2"]["l1"]["region"]           # the hub date does not join them
    fam = [r for r in M["layer1"]["regions"] if r["id"] == C["Calc!D2"]["l1"]["region"]][0]
    assert fam.get("family", 1) >= 2, fam                                          # side-by-side copies: one family for review


@test("D.6 unreached calculation regions and sinks are reported for the analyst; Python never calls a region irrelevant")
def d6():
    d = case("d6")
    DF.pasted_workbook(os.path.join(d, "P.xlsx"))
    o, M, C = discover(d, "P.xlsx", "2025-12-31")
    regs = {r["id"]: r for r in M["layer1"]["regions"]}
    scratch = [r for r in regs.values() if r["sheets"] == ["Scratch"]]
    assert scratch and scratch[0]["proposed"] == "cannot_determine" and scratch[0]["sinks"] == ["Scratch!C8"], scratch
    assert all(r["proposed"] in ("reached_from_outputs", "cannot_determine", "small_unreached") for r in regs.values())
    from openpyxl import load_workbook
    ws = load_workbook(os.path.join(d, "map", "discovery_review.xlsx"))["Unreached regions"]
    assert any(row[0].value == scratch[0]["id"] for row in ws.iter_rows(min_row=3)), "review sheet lacks the island"


@test("D.7 a pasted value is a possible provenance match (SUPPORTED), unique; round numbers are never searched")
def d7():
    d = case("d7")
    DF.pasted_workbook(os.path.join(d, "P.xlsx"))
    o, M, C = discover(d, "P.xlsx", "2025-12-31")
    pc = M["layer2"]["pasted_value_candidates"]
    assert len(pc) == 1 and pc[0]["input"] == "Valuation!B8" and pc[0]["matches"] == ["Working!B5"], pc
    assert pc[0]["status"] == "SUPPORTED" and pc[0]["unique"] and "not proof" in pc[0]["meaning"]


@test("D.8 period decision table: block header PROVEN, window PROVEN, header only SUPPORTED, conflict, several periods AMBIGUOUS")
def d8():
    d, o, M, C = structures("d8")
    p = lambda c: C[c]["l2"]["period"]
    assert p("Inputs!C4")["status"] == "PROVEN" and p("Inputs!C4")["period"] == "2025-02"
    assert p("Calc!B2")["status"] == "PROVEN" and p("Calc!B2")["period"] == "2025-12"
    assert p("Calc!C2")["status"] == "CONFLICTING", p("Calc!C2")
    d2_ = case("d8b")
    FX.factory_workbook(os.path.join(d2_, "F.xlsx"), older=(2024, 12), column_roles=True)
    o, M2, C2 = discover(d2_, "F.xlsx", "2026-03-31")
    pf = C2["'Valuation Summary'!C10"]["l2"]["period"]                 # older multiple: typed-like formula, header only
    assert pf["status"] in ("SUPPORTED", "PROVEN") and pf["period"] == "2024-12", pf
    bud = [r for r in C2.values() if r["l2"]["period"]["column_role"] == "budget"]
    assert bud, "the budget column role was lost"


@test("D.9 the requested period is the target, never evidence: another request changes no cell's evidence")
def d9():
    d = case("d9")
    FX.factory_workbook(os.path.join(d, "F.xlsx"))
    o, M1, C1 = discover(d, "F.xlsx", "2026-03-31", "m1")
    o, M2, C2 = discover(d, "F.xlsx", "2025-06-30", "m2")
    assert all(C1[c]["l2"]["period"] == C2[c]["l2"]["period"] for c in C1)
    assert not any(e["kind"] == "request" for r in C1.values() for e in r["l2"]["period"]["evidence"])
    assert M1["meta"]["requested_period_target"] == "2026-03-31"


@test("D.10 material inputs: a monthly row is one terminal; each has a class and a separate source; no 'parameter'")
def d10():
    d = case("d10")
    FX.factory_workbook(os.path.join(d, "F.xlsx"), external={"active": "Peers Feed.xlsx", "stale": []})
    o, M, C = discover(d, "F.xlsx", "2026-03-31")
    T = M["layer2"]["terminals"]
    series = [t for t in T if t["kind"] == "series"]
    assert series and all(t["cells"] >= 12 for t in series if t["class"] == "typed financial data"), series
    assert not any("parameter" in t["class"] for t in T) and all("source_evidence" in t for t in T)
    ext = [t for t in T if t["class"] == "external-workbook value"]
    assert ext and "Peers Feed.xlsx" in ext[0]["source_evidence"], ext


@test("D.11 material-by-reference and material-by-contribution are reported separately")
def d11():
    d, o, M, C = structures("d11")
    d2_ = case("d11b")
    FX.factory_workbook(os.path.join(d2_, "F.xlsx"))
    o, M2, C2 = discover(d2_, "F.xlsx", "2026-03-31")
    L = M2["layer1"]
    assert L["material_by_reference"] > 0 and L["material_by_contribution"] > 0 and "material_formulas_contribution_unknown" in L


@test("D.12 deterministic: the same workbook, period and code give byte-identical map files")
def d12():
    d = case("d12")
    DF.structures_workbook(os.path.join(d, "S.xlsx"))
    discover(d, "S.xlsx", "2025-12-31", "a")
    discover(d, "S.xlsx", "2025-12-31", "b")
    for f in ("workbook_map.json", "cells.jsonl.gz"):
        assert open(os.path.join(d, "a", f), "rb").read() == open(os.path.join(d, "b", f), "rb").read(), f


@test("D.13 read-only: discovery never changes the workbook")
def d13():
    d = case("d13")
    FX.factory_workbook(os.path.join(d, "F.xlsx"))
    h = sha256_file(os.path.join(d, "F.xlsx"))
    discover(d, "F.xlsx", "2026-03-31")
    assert sha256_file(os.path.join(d, "F.xlsx")) == h


# ------------------------------------------------------------------------------------------------ B benchmark
sys.path.insert(0, os.path.join(PKG, "tools"))
import excel_standin as XS


@test("B.1 separation: no benchmark module imports program code (only common/ and the standard library / openpyxl)")
def b1():
    disc = {os.path.splitext(os.path.basename(p))[0] for p in glob.glob(os.path.join(PKG, "discovery", "**", "*.py"), recursive=True)}
    for p in glob.glob(os.path.join(PKG, "benchmark", "*.py")):
        tree = ast.parse(open(p).read())
        for n in ast.walk(tree):
            mods = [a.name for a in n.names] if isinstance(n, ast.Import) else [n.module or ""] if isinstance(n, ast.ImportFrom) else []
            for m_ in mods:
                top = m_.split(".")[0]
                assert top not in disc and top != "discovery", f"{os.path.basename(p)} imports program module {m_}"


def standin(d, wb, uses_override=None, name=None):
    name = name or os.path.splitext(wb)[0] + " - export.xlsx"
    XS.build(os.path.join(d, wb), os.path.join(d, name), uses_override)
    return name


def answers_file(d, wb, kn=None, months=None, method=None, areas=(), saved_at="2026-10-08T07:00:00", name="answers.json"):
    """what save-answers writes, built from what the workbook's author knows (never from the program)."""
    body = {"schema": "answers/1", "workbook": wb, "fingerprint": sha256_file(os.path.join(d, wb)), "quarter_end": "2026-03-31",
            "saved_by": "test author", "saved_at": saved_at,
            "answers": {"key_numbers": {k: {"sheet": v.split("!")[0].strip("'"), "cell": v.split("!")[1]} for k, v in (kn or {}).items()},
                        "months": months or {}, "method": method, "areas": [dict(a, row=i + 2) for i, a in enumerate(areas)]}}
    body["sha256"] = sha256_text(canon(body))
    json.dump(body, open(os.path.join(d, name), "w"))
    return name


def compare(d, prog="map", export=None, answers=None, extra=(), out="cmp"):
    args = ["compare", "--program", prog, "--out", out] + (["--excel-export", export] if export else []) + (["--answers", answers] if answers else []) + list(extra)
    rc, o = run(BENCH, args, d)
    res = load(os.path.join(d, out, "result.json")) if rc == 0 else None
    return rc, o, res


def factory_answers(d, vals, sheet="Valuation Summary", areas=(), **kw):
    c = vals[(2026, 3)]["col"]
    q = f"'{sheet}'"
    return answers_file(d, "F.xlsx", {"enterprise_value": f"{q}!{c}11", "equity_value": f"{q}!{c}14", "value_to_xpv": f"{q}!{c}16",
                                      "valuation_metric": f"{q}!{c}8", "selected_multiple": f"{q}!{c}10"},
                        {"metric_first_month": "2025-04", "metric_last_month": "2026-03"}, "EV/EBITDA multiple", areas, **kw)


def factory_case(name, **kw):
    d = case(name)
    vals = FX.factory_workbook(os.path.join(d, "F.xlsx"), **kw)
    discover(d, "F.xlsx", "2026-03-31")
    return d, vals


@test("B.2 file contents vs Excel: every cell matches; a missing row, a changed value and a changed formula are each caught; the two CSVs diff")
def b2():
    d, vals = factory_case("b2", older=(2024, 12))
    x = standin(d, "F.xlsx")
    rc, o, res = compare(d, export=x)
    assert rc == 0 and res["checks"]["file contents match Excel"] == "PASS", (o, res and res["cells"])
    assert open(os.path.join(d, "cmp", "excel_cells.csv")).read() == open(os.path.join(d, "cmp", "program_cells.csv")).read()
    import csv as _csv
    p = os.path.join(d, "map", "program_cells.csv")
    rows = list(_csv.reader(open(p)))
    rows = [r for r in rows if not (r[0] == "Comps" and r[1] == "B4")]                       # drop one cell
    for r in rows:
        if r[0] == "Monthly" and r[1] == "C4":
            r[3] = str(float(r[3]) + 1)                                                        # change a value
        if r[0] == "Monthly" and r[1] == "C7":
            r[2] = "=C4-C5"                                                                    # change a formula
    _csv.writer(open(p, "w", newline=""), lineterminator="\n").writerows(rows)
    rc, o, res = compare(d, export=x, out="cmp2")
    c = res["cells"]
    assert (c["missing in program"], c["value differs"], c["formula differs"]) == (1, 1, 1) and res["checks"]["file contents match Excel"] == "FAIL", c


@test("B.3 formula uses vs Excel: a reference the program misses is 'missed silently'; one it flagged is 'missed but flagged'")
def b3():
    d = case("b3")
    DF.structures_workbook(os.path.join(d, "S.xlsx"))
    discover(d, "S.xlsx", "2025-12-31")
    over = {("Calc", "B5"): "Calc!B10; Inputs!B4",                     # Excel resolves the computed INDIRECT; the program flags it
            ("Calc", "B6"): "Inputs!B4:M4; Inputs!B1",                # an extra reference only 'Excel' lists: a silent miss
            ("Calc", "B13"): "Tbl!B2:B4", ("Calc", "B14"): "Inputs!B5:M5"}   # table / name references the simple stand-in cannot read
    x = standin(d, "S.xlsx", over)
    rc, o, res = compare(d, export=x)
    u = res["uses"]
    assert u["missed but flagged"] == 1 and u["missed silently"] == 1 and u["extra"] == 0 and res["checks"]["formula uses match Excel"] == "FAIL", u


def fill_form(path, kn, months=None, method=None, areas=()):
    from openpyxl import load_workbook
    wb = load_workbook(path)
    k = wb["1 Key numbers"]
    labels = {"enterprise_value": "Enterprise value", "equity_value": "Equity value", "value_to_xpv": "XPV's value",
              "valuation_metric": "Earnings figure used", "selected_multiple": "Multiple applied"}
    for row in k.iter_rows(min_row=2):
        for key, lab in labels.items():
            if row[0].value == lab and key in kn:
                row[2].value, row[3].value = kn[key]
        if row[0].value == "First month the earnings figure covers":
            row[2].value = (months or {}).get("first")
        if row[0].value == "Last month the earnings figure covers":
            row[2].value = (months or {}).get("last")
        if row[0].value == "Valuation method":
            row[2].value = method
    a = wb["2 Areas"]
    for r in areas:
        a.append(r)
    wb.save(path)


@test("B.4 the form check catches a label cell instead of the number, a misspelt sheet and a badly written month - in plain words")
def b4():
    d, vals = factory_case("b4")
    rc, o = run(BENCH, ["form", "--workbook", "F.xlsx", "--quarter-end", "2026-03-31", "--out", "form.xlsx"], d)
    assert rc == 0 and "FORM: made form.xlsx" in o, o
    fill_form(os.path.join(d, "form.xlsx"), {"enterprise_value": ("Valuation Summary", "A11"), "equity_value": ("Valuation Sumary", "B14"),
                                             "value_to_xpv": ("Valuation Summary", "B16"), "valuation_metric": ("Valuation Summary", "B8"),
                                             "selected_multiple": ("Valuation Summary", "B10")}, {"first": "April 2025", "last": "2026-03"}, "EV/EBITDA multiple")
    rc, o = run(BENCH, ["check-form", "--form", "form.xlsx", "--workbook", "F.xlsx"], d)
    assert rc == 3, o
    has(o, "holds the text 'Enterprise value', not a number", "The first number to its right is in B11", "did you mean 'Valuation Summary'",
        "'April 2025' is not a month written year-month")
    fill_form(os.path.join(d, "form.xlsx"), {"enterprise_value": ("Valuation Summary", "B11"), "equity_value": ("Valuation Summary", "B14")},
              {"first": "2025-04", "last": "2026-03"}, "EV/EBITDA multiple")
    rc, o = run(BENCH, ["check-form", "--form", "form.xlsx", "--workbook", "F.xlsx"], d)
    assert rc == 0 and "FORM: OK" in o, o


@test("B.5 key numbers vs the analyst: right answers count as correct; a different answer the program was sure about is 'confidently wrong'")
def b5():
    d, vals = factory_case("b5", older=(2024, 12))
    rc, o = run(BENCH, ["form", "--workbook", "F.xlsx", "--quarter-end", "2026-03-31", "--out", "form.xlsx"], d)
    c = vals[(2026, 3)]["col"]
    q = "Valuation Summary"
    fill_form(os.path.join(d, "form.xlsx"), {"enterprise_value": (q, f"{c}11"), "equity_value": (q, f"{c}14"), "value_to_xpv": (q, f"{c}16"),
                                             "valuation_metric": (q, f"{c}8"), "selected_multiple": (q, f"{c}10")},
              {"first": "2025-04", "last": "2026-03"}, "EV/EBITDA multiple")
    rc, o = run(BENCH, ["save-answers", "--form", "form.xlsx", "--workbook", "F.xlsx", "--by", "Test Analyst", "--out", "ans.json"], d, "2026-10-08T07:00:00")
    assert rc == 0 and "FORM: answers saved" in o, o
    rc, o, res = compare(d, answers="ans.json")
    k = res["meaning"]["key"]
    assert (k["correct"], k["wrong"], k["confidently wrong"]) == (5, 0, 0) and res["meaning"]["months"]["months correct"] == 2, res["meaning"]
    a2 = answers_file(d, "F.xlsx", {"enterprise_value": "'Valuation Summary'!B11"}, name="older.json")    # the analyst says the older column
    rc, o, res = compare(d, answers=a2, out="cmp2")
    assert res["meaning"]["key"]["wrong"] == 1 and res["meaning"]["key"]["confidently wrong"] == 1, res["meaning"]["key"]
    has(o, "BENCHMARK: confidently wrong | 1")


@test("B.6 areas vs the analyst: the current quarter is used and dated right; old history is not used; reversed labels are caught")
def b6():
    d, vals = factory_case("b6", older=(2024, 12))
    good = [{"sheet": "Valuation Summary", "cells": "C5:C16", "what": "Current quarter's valuation", "month": "2026-03"},
            {"sheet": "Valuation Summary", "cells": "B5:B16", "what": "Old history", "month": "2024-12"}]
    rc, o, res = compare(d, answers=factory_answers(d, vals, areas=good))
    ar = res["meaning"]["areas"]
    assert ar["handled correctly"] == 2 and ar["month wrong"] == 0 and ar["month correct"] > 0, ar
    bad = [dict(good[0], cells="B5:B16"), dict(good[1], cells="C5:C16", month="2026-03")]
    rc, o, res = compare(d, answers=factory_answers(d, vals, areas=bad, name="bad.json"), out="cmp2")
    ar = res["meaning"]["areas"]
    assert ar["handled wrongly"] == 2 and ar["month wrong"] > 0 and res["checks"]["areas"] == "FAIL", ar


@test("B.7 wrong inputs stop with a clear line: edited answers, another workbook's answers, an unfinished or foreign Excel export")
def b7():
    d, vals = factory_case("b7")
    a_ = factory_answers(d, vals)
    j = load(os.path.join(d, a_))
    j["answers"]["method"] = "Held at cost"
    json.dump(j, open(os.path.join(d, "edited.json"), "w"))
    rc, o, _ = compare(d, answers="edited.json")
    assert rc == 3 and "edited after it was saved" in o, o
    j = load(os.path.join(d, a_))
    j["fingerprint"] = "0" * 64
    j["sha256"] = sha256_text(canon({k: v for k, v in j.items() if k != "sha256"}))
    json.dump(j, open(os.path.join(d, "other.json"), "w"))
    rc, o, _ = compare(d, answers="other.json")
    assert rc == 3 and "different version of the workbook" in o, o
    x = standin(d, "F.xlsx")
    from openpyxl import load_workbook
    wb = load_workbook(os.path.join(d, x))
    wb["XLX Info"]["B3"] = "In progress"
    wb.save(os.path.join(d, "unfinished - export.xlsx"))
    rc, o, _ = compare(d, export="unfinished - export.xlsx")
    assert rc == 3 and "run excel-export again until it says Finished" in o, o
    d2 = case("b7b")
    DF.pasted_workbook(os.path.join(d2, "P.xlsx"))
    shutil.copyfile(os.path.join(d2, standin(d2, "P.xlsx")), os.path.join(d, "foreign - export.xlsx"))
    rc, o, _ = compare(d, export="foreign - export.xlsx")
    assert rc == 3 and "different sheets" in o, o


@test("B.8 since the last comparison: improvements, regressions and changed program rules are reported")
def b8():
    d, vals = factory_case("b8")
    rc, o, res = compare(d, answers=factory_answers(d, vals))
    prev = load(os.path.join(d, "cmp", "result.json"))
    prev["checks"]["key numbers"] = "FAIL"
    prev["checks"]["areas"] = "PASS"
    prev["meta"]["rules_hashes"] = {"discovery_rules": "old"}
    json.dump(prev, open(os.path.join(d, "prev.json"), "w"))
    rc, o, res = compare(d, answers=factory_answers(d, vals, areas=[{"sheet": "Valuation Summary", "cells": "B5:B16", "what": "Old history", "month": None}],
                                                     name="a2.json"), extra=["--previous", "prev.json"], out="cmp2")
    s = res["since_last"]
    assert s["better"] == ["key numbers"] and s["worse"] == ["areas"] and s["rules_changed"], s
    has(o, "BENCHMARK: since last comparison | better 1 | worse 1 | rules changed yes")


@test("B.9 the summary lines hold no sheet names, cells, values or file names")
def b9():
    d, vals = factory_case("b9", external={"active": "Peers Feed.xlsx", "stale": []})
    rc, o, res = compare(d, export=standin(d, "F.xlsx"), answers=factory_answers(d, vals))
    body = "\n".join(l for l in o.splitlines() if l.startswith("BENCHMARK:"))
    for bad in ("Valuation", "Comps", "Monthly", "Delta", "Peers", ".xlsx", "!", "/", "'"):
        assert bad not in body, f"leaks {bad!r}:\n{body}"
    assert not re.search(r"\b[A-Z]{1,3}\d{1,7}\b", body), body


@test("B.10 the demo runs the whole process on a made-up workbook in one command and everything passes")
def b10():
    d = case("b10")
    p = subprocess.run([sys.executable, os.path.join(PKG, "tools", "demo.py")], cwd=d, env=dict(env(), WD_OUTPUT_ROOT=d), capture_output=True, text=True)
    assert p.returncode == 0, p.stdout + p.stderr
    has(p.stdout, "check-form says:", "holds the text 'Enterprise value'", "BENCHMARK: file contents vs Excel | cells match",
        "file contents match Excel PASS | formula uses match Excel PASS | key numbers PASS")


# ------------------------------------------------------------------------------------------------ M mutations
@test("M.1 inserted columns (an older quarter, Budget / Variance columns): the same key numbers are found at their new places")
def m1():
    for i, kw in enumerate([{}, {"older": (2024, 12)}, {"older": (2024, 12), "column_roles": True, "budget_first": True}]):
        d, vals = factory_case(f"m1_{i}", **kw)
        rc, o, res = compare(d, answers=factory_answers(d, vals))
        assert res["checks"]["key numbers"] == "PASS" and res["checks"]["months and method"] == "PASS", (kw, res["meaning"])


@test("M.2 a renamed sheet: formulas follow the new name and the same key numbers are found")
def m2():
    d = case("m2")
    vals = FX.factory_workbook(os.path.join(d, "F.xlsx"))
    DF.rename_sheet(os.path.join(d, "F.xlsx"), "Valuation Summary", "VS Q1 2026")
    discover(d, "F.xlsx", "2026-03-31")
    rc, o, res = compare(d, export=standin(d, "F.xlsx"), answers=factory_answers(d, vals, sheet="VS Q1 2026"))
    assert res["checks"]["key numbers"] == "PASS" and res["checks"]["file contents match Excel"] == "PASS", res["checks"]


@test("M.3 a decoy multiple and an irrelevant extra sheet change nothing that matters")
def m3():
    d, vals = factory_case("m3", decoy="ambiguous_multiple")
    rc, o, res = compare(d, answers=factory_answers(d, vals))
    assert res["checks"]["key numbers"] == "PASS", res["meaning"]
    d2_ = case("m3b")
    FX.company_workbook(os.path.join(d2_, "C.xlsx"), noise_sheet=True)
    discover(d2_, "C.xlsx", "2026-06-30")
    a_ = answers_file(d2_, "C.xlsx", {"enterprise_value": "Valuation!B21", "equity_value": "Valuation!B24", "value_to_xpv": "Valuation!B26"},
                      areas=[{"sheet": "Data dump", "cells": None, "what": "Scratch or working area", "month": None}])
    rc, o, res = compare(d2_, answers=a_)
    assert res["checks"]["key numbers"] == "PASS" and res["checks"]["areas"] == "PASS", res["meaning"]


@test("M.4 real changes are caught: a 12-month window ending a month early, and an area the analyst says is used but is not")
def m4():
    d = case("m4")
    FX.company_workbook(os.path.join(d, "C.xlsx"), ttm_off=True)
    discover(d, "C.xlsx", "2026-06-30")
    a_ = answers_file(d, "C.xlsx", {"enterprise_value": "Valuation!B21"}, {"metric_first_month": "2025-07", "metric_last_month": "2026-06"},
                      areas=[{"sheet": "Monthly", "cells": "B17:Y17", "what": "Monthly figures used by the valuation", "month": None}])
    rc, o, res = compare(d, answers=a_)
    assert res["checks"]["months and method"] == "FAIL" and res["checks"]["areas"] == "FAIL", res["meaning"]


# ------------------------------------------------------------------------------------------------ P pre-flight and files
@test("P.1 pre-flight refuses unreadable files with one clear line each (exit 3, no traceback); macros are noted")
def p1():
    d = case("p1")
    FX.factory_workbook(os.path.join(d, "good.xlsx"))
    open(os.path.join(d, "empty.xlsx"), "wb").close()
    ole = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\x00" * 600
    open(os.path.join(d, "legacy.xls"), "wb").write(ole)
    open(os.path.join(d, "locked.xlsx"), "wb").write(ole)
    open(os.path.join(d, "binary.xlsb"), "wb").write(b"PK\x03\x04junk")
    open(os.path.join(d, "broken.xlsx"), "wb").write(open(os.path.join(d, "good.xlsx"), "rb").read()[:400])
    import zipfile
    with zipfile.ZipFile(os.path.join(d, "notwb.xlsx"), "w") as z:
        z.writestr("hello.txt", "hi")
    open(os.path.join(d, "data.csv"), "w").write("a,b\n1,2\n")
    expect = {"empty.xlsx": "empty", "legacy.xls": "legacy .xls", "locked.xlsx": "password-protected", "binary.xlsb": ".xlsb",
              "broken.xlsx": "damaged", "notwb.xlsx": "no workbook part", "data.csv": "not an Excel workbook"}
    for name, words in expect.items():
        rc, o = run(DISC, ["--workbook", name, "--period-end", "2026-03-31", "--out", "m_" + name], d)
        assert rc == 3 and o.strip().startswith(f"PREFLIGHT: REFUSED {name}") and words in o and "Traceback" not in o, (name, o)
    rc, o = run(BENCH, ["fingerprint", "--workbook", "locked.xlsx"], d)
    assert rc == 3 and "PREFLIGHT: REFUSED" in o, o
    sys.path.insert(0, PKG)
    from common.preflight import check_workbook
    shutil.copyfile(os.path.join(d, "good.xlsx"), os.path.join(d, "macro.xlsm"))
    with zipfile.ZipFile(os.path.join(d, "macro.xlsm"), "a") as z:
        z.writestr("xl/vbaProject.bin", b"\x00" * 10)
    assert check_workbook(os.path.join(d, "macro.xlsm"))["macros"] is True


@test("P.2 files passed by name are found where knowledge files land; two different files with one name stop the run")
def p2():
    d = case("p2")
    os.makedirs(os.path.join(d, "kn", "a")); os.makedirs(os.path.join(d, "kn", "b")); os.makedirs(os.path.join(d, "run"))
    FX.factory_workbook(os.path.join(d, "kn", "a", "F.xlsx"))
    shutil.copyfile(os.path.join(d, "kn", "a", "F.xlsx"), os.path.join(d, "kn", "b", "F.xlsx"))      # same content twice: fine
    e = dict(env(), VALUATION_FILE_ROOTS=os.path.join(d, "kn"), WD_OUTPUT_ROOT=os.path.join(d, "run"))
    p = subprocess.run([sys.executable, DISC, "--workbook", "F.xlsx", "--period-end", "2026-03-31", "--out", os.path.join(d, "run", "m")],
                       cwd=os.path.join(d, "run"), env=e, capture_output=True, text=True)
    assert p.returncode == 0, p.stdout + p.stderr
    FX.factory_workbook(os.path.join(d, "kn", "b", "F.xlsx"), older=(2024, 12))                       # different content
    p = subprocess.run([sys.executable, DISC, "--workbook", "F.xlsx", "--period-end", "2026-03-31"], cwd=os.path.join(d, "run"), env=e,
                       capture_output=True, text=True)
    assert p.returncode == 3 and "different files are named 'F.xlsx'" in p.stdout, p.stdout


@test("D.14 a corrupt named range (#REF!) is flagged MISSING on the formulas that use it - no crash, no silent stop")
def d14():
    d, o, M, C = structures("d14")
    f = C["Calc!B17"]["l1"]
    assert f["flags"]["references_extracted"] == "MISSING" and any(r.get("via") == "BadName" for r in f["refs"]), f


# ------------------------------------------------------------------------------------------------ I invariants
@test("I.1 invariants hold on a consistent workbook; a profile can disable one; an unknown check in the registry stops")
def i1():
    d = case("i1")
    FX.factory_workbook(os.path.join(d, "F.xlsx"))
    o, M, C = discover(d, "F.xlsx", "2026-03-31")
    st = {r["id"]: r["status"] for r in M["layer2"]["invariants"]["results"]}
    assert all(st[i] == "HOLDS" for i in ("INV-01", "INV-02", "INV-03", "INV-04", "INV-05", "INV-06", "INV-07")) and st["INV-08"] == "NOT_APPLICABLE", st
    rc, o2 = run(DISC, ["--workbook", "F.xlsx", "--period-end", "2026-03-31", "--out", "m2", "--profile", "example-fx-company"], d)
    assert rc == 0 and load(os.path.join(d, "m2", "workbook_map.json"))["meta"]["invariant_profile"] == "example-fx-company"
    rc, o3 = run(DISC, ["--workbook", "F.xlsx", "--period-end", "2026-03-31", "--out", "m3", "--profile", "no-such-profile"], d)
    assert rc == 3 and "profile 'no-such-profile'" in o3, o3
    sys.path[:0] = [os.path.join(PKG, "discovery")]
    import invariants as IV
    keep = dict(IV.INVARIANTS)
    try:
        IV.INVARIANTS["invariants"] = keep["invariants"] + [{"id": "INV-X", "check": "made_up"}]
        from common.util import Stop
        try:
            IV.evaluate({"m": None, "g": None, "J": {}, "material": set(), "period_of": lambda k: None})
            raise AssertionError("an unknown check did not stop")
        except Stop as e:
            assert "unknown check 'made_up'" in str(e)
    finally:
        IV.INVARIANTS["invariants"] = keep["invariants"]


@test("I.2 invariants catch a stale enterprise value and a balance sheet that does not balance (naming the month)")
def i2():
    d = case("i2")
    DF.pasted_workbook(os.path.join(d, "P.xlsx"), stale_ev=True, balance_sheet="off")
    o, M, C = discover(d, "P.xlsx", "2025-12-31")
    st = {r["id"]: r for r in M["layer2"]["invariants"]["results"]}
    assert st["INV-01"]["status"] == "VIOLATED" and st["INV-07"]["status"] == "VIOLATED", st
    assert st["INV-08"]["status"] == "VIOLATED" and "2025-06" in st["INV-08"]["detail"], st["INV-08"]
    assert M["gates"]["invariants_violated"] >= 3
    d2_ = case("i2b")
    DF.pasted_workbook(os.path.join(d2_, "P.xlsx"), balance_sheet="balanced")
    o, M2, C2 = discover(d2_, "P.xlsx", "2025-12-31")
    assert {r["id"]: r["status"] for r in M2["layer2"]["invariants"]["results"]}["INV-08"] == "HOLDS"


@test("I.3 invariants are not ground truth: a consistent column of the wrong quarter passes them all; the analyst's answers catch it")
def i3():
    d = case("i3")
    vals = FX.factory_workbook(os.path.join(d, "F.xlsx"), older=(2024, 12))
    discover(d, "F.xlsx", "2024-12-31")                                    # asks for the older quarter: a consistent column
    M = load(os.path.join(d, "map", "workbook_map.json"))
    assert all(r["status"] in ("HOLDS", "NOT_APPLICABLE") for r in M["layer2"]["invariants"]["results"]), M["layer2"]["invariants"]
    rc, o, res = compare(d, answers=factory_answers(d, vals))              # the analyst's answers are for Q1 2026
    assert res["checks"]["key numbers"] == "FAIL", res["meaning"]

@test("E.1 an internal error prints one line (exit 1) and writes the traceback to run_error.log, not to the agent")
def e1():
    d = case("e1")
    FX.factory_workbook(os.path.join(d, "F.xlsx"))
    p = subprocess.run([sys.executable, DISC, "--workbook", "F.xlsx", "--period-end", "2026-03-31", "--out", "m"], cwd=d,
                       env=dict(env(), WD_TEST_FAULT="after_read", WD_OUTPUT_ROOT=d), capture_output=True, text=True)
    assert p.returncode == 1 and p.stdout.strip().splitlines()[-1].startswith("DISCOVERY ERROR: internal RuntimeError"), p.stdout
    assert "Traceback" not in p.stdout + p.stderr and "injected fault" in open(os.path.join(d, "m", "run_error.log")).read()


@test("S.1 a saved-answers file missing required parts is refused, saying what is missing")
def s1():
    d, vals = factory_case("s1")
    j = load(os.path.join(d, factory_answers(d, vals)))
    del j["answers"]["key_numbers"]
    json.dump(j, open(os.path.join(d, "bad.json"), "w"))
    rc, o, _ = compare(d, answers="bad.json")
    assert rc == 3 and "saved answers file is not valid" in o and "answers.key_numbers is missing" in o, o

@test("R.1 rules are data: the map records the hashes of the rule and invariant files it ran with")
def r1():
    d = case("r1")
    FX.factory_workbook(os.path.join(d, "F.xlsx"))
    o, M, C = discover(d, "F.xlsx", "2026-03-31")
    sys.path[:0] = [os.path.join(PKG, "discovery")]
    import rules as RU
    assert M["meta"]["rules_hashes"] == RU.HASHES and M["meta"]["invariants_version"] == RU.INVARIANTS["version"]


@test("C.1 the printed lines are the agent's contract: every line uses a prefix SKILL.md documents; exit codes documented")
def c1():
    skill = open(os.path.join(PKG, "SKILL.md"), encoding="utf-8").read()
    prefixes = ["PREFLIGHT:", "DISCOVERY:", "ANCHOR:", "DISCOVERY ERROR:", "BENCHMARK:", "BENCHMARK ERROR:", "FORM:", "DEMO:", "STOPPED:", "NEXT:", "ALL TESTS:"]
    for p_ in prefixes:
        assert f"`{p_}`" in skill, f"SKILL.md does not document {p_}"
    for code in ("0 done", "1 internal error", "2 usage", "3 STOPPED"):
        assert code in skill, f"SKILL.md does not document exit code '{code}'"
    d, vals = factory_case("c1")
    outs = [compare(d, export=standin(d, "F.xlsx"), answers=factory_answers(d, vals))[1],
            run(DISC, ["--workbook", "F.xlsx", "--period-end", "2026-03-31", "--out", "m2"], d)[1],
            run(DISC, ["--workbook", "missing.xlsx", "--period-end", "2026-03-31"], d)[1],
            run(BENCH, ["form", "--workbook", "F.xlsx", "--quarter-end", "2026-03-31", "--out", "t.xlsx"], d)[1],
            run(BENCH, ["check-form", "--form", "t.xlsx", "--workbook", "F.xlsx"], d)[1]]
    for text in outs:
        for line in text.splitlines():
            if line.strip() and not line.startswith(("- ", "  ")):
                assert line.startswith(tuple(prefixes)), f"undocumented printed line: {line[:90]}"

@test("C.3 outputs go where they are told: WD_OUTPUT_ROOT first, then the agent's downloads folder, then the current folder")
def c3():
    sys.path.insert(0, PKG)
    from common import files as FI
    keep = os.environ.get("WD_OUTPUT_ROOT")
    try:
        os.environ["WD_OUTPUT_ROOT"] = ROOT
        assert FI.out_root("x").startswith(ROOT)
        del os.environ["WD_OUTPUT_ROOT"]
        assert FI.output_base() == ("/app/created" if os.path.isdir("/app/created") else os.getcwd())
    finally:
        if keep is not None:
            os.environ["WD_OUTPUT_ROOT"] = keep


@test("C.2 hygiene: every module compiles, carries its build header, and has no placeholder code")
def c2():
    for p_ in glob.glob(os.path.join(PKG, "**", "*.py"), recursive=True):
        compile(open(p_, encoding="utf-8").read(), p_, "exec")             # in memory: never writes into the skill folder
        if "/vp/" in p_.replace(os.sep, "/") or p_.endswith("vp_fixtures.py"):
            continue                                                      # vendored build 11.3 code: unchanged by policy (V.1)
        src = open(p_, encoding="utf-8").read()
        assert re.search(r"^# \S+\.py \(build 11\.\d+(\.\d+)?\)", src), f"{p_}: no build header"
        for bad in ("TO" + "DO", "FIX" + "ME", "X" + "XX", "if " + "False"):
            assert bad not in src, f"{p_}: contains {bad}"



# ------------------------------------------------------------------------------------------------ CH chain-first key numbers
def chain_case(name, fund=True, extra=(), period="2026-06-30", **kw):
    d = case(name)
    res = DF.chain_workbook(os.path.join(d, "C.xlsx"), os.path.join(d, "Fund.xlsx") if fund else None, **kw)
    args = ["--workbook", "C.xlsx", "--period-end", period, "--out", "map"] + list(extra)
    rc, o = run(DISC, args, d)
    assert rc == 0, o
    M = load(os.path.join(d, "map", "workbook_map.json"))
    return d, res, o, M, {k: (M["layer2"]["junctions"][k]["cell"], M["layer2"]["junctions"][k]["status"])
                          for k in ("enterprise_value", "equity_value", "value_to_xpv", "valuation_metric", "selected_multiple")}


FUND = ["--fund-workbook", "Fund.xlsx", "--company", "Demo Ocean"]
TRUE_CHAIN = {"enterprise_value": "'Valuation Summary'!C7", "equity_value": "'Valuation Summary'!C10", "value_to_xpv": "'Cap Table'!B5",
              "valuation_metric": "'Valuation Summary'!C5", "selected_multiple": "'Valuation Summary'!C6"}


@test("CH.1 the first real run's failures, rebuilt: the label-based method falls for every decoy; chain-first finds the true chain, PROVEN")
def ch1():
    d, res, o, M, J = chain_case("ch1", extra=FUND)
    assert {k: v[0] for k, v in J.items()} == TRUE_CHAIN and all(v[1] == "PROVEN" for v in J.values()), J
    legacy = M["layer2"]["junctions"]["legacy_label_based"]
    assert legacy["enterprise_value"]["cell"] != TRUE_CHAIN["enterprise_value"], "the fixture no longer reproduces the label-based failure"
    assert legacy["equity_value"]["cell"] != TRUE_CHAIN["equity_value"], legacy["equity_value"]
    w = M["layer2"]["junctions"]["metric_window"]
    assert (w["first"], w["last"]) == ("2025-07", "2026-06"), w
    has(o, "DISCOVERY: valuation chain | proven")


@test("CH.2 every rival is rejected with its reason: older period, peers' rows, the ownership step; a count is never a multiple")
def ch2():
    d, res, o, M, J = chain_case("ch2", fund=False)
    why = {x["ev"]: x["rejected"] or "kept" for x in M["layer2"]["chain"]["options"]}
    assert why["'Valuation Summary'!B7"].startswith("its earnings figure ends in another month (2025-06)"), why
    assert why["'Cap Table'!B5"].startswith("it multiplies another chain's equity value"), why
    assert all("this one's period is unknown" in why[f"LPAC!E{r}"] for r in (55, 56, 57)), why   # the first rule that applies
    assert why["'Valuation Summary'!C7"] == "kept", why
    sys.path[:0] = [os.path.join(PKG, "discovery", "vp"), os.path.join(PKG, "discovery")]
    from workbook_model import Model
    import graph as GR, inventory as INV, chain as CHN
    p = os.path.join(d, "C.xlsx")
    facts = INV.xml_facts(p)
    m = Model(p)
    arr = INV.array_result_cells(facts)
    c = CHN.Chains(m, GR.Graph(m, facts, arr), lambda k: None)
    assert "a count (COUNTIF), not a multiple" == c.count_like(("LPAC", 61, 3)), c.count_like(("LPAC", 61, 3))


@test("CH.3 the fund workbook anchors the chain: the company's row and quarter column, the MOIC self-check, typed copies kept apart")
def ch3():
    d, res, o, M, J = chain_case("ch3", extra=FUND)
    a = M["layer2"]["chain"]["anchor"]
    assert a["status"] == "matched" and a["self_check"] == "holds" and a["value_column"] == "by quarter header", a
    assert a["matched"] == ["'Cap Table'!B5"] and "'Cap Table'!B6" in a["copies"], a
    assert J["equity_value"][0] != "'Cap Table'!B6"                      # 'Equity Cost Base' equals XPV value: never equity
    has(o, "ANCHOR: fund workbook | company row found", "MOIC self-check holds", "1 formula match(es), 1 typed copy(ies) | matched")


@test("CH.4 without a fund workbook the chain comes from structure and the requested month; another month picks that month's chain")
def ch4():
    d, res, o, M, J = chain_case("ch4", fund=False)
    assert {k: v[0] for k, v in J.items()} == TRUE_CHAIN and J["enterprise_value"][1] == "PROVEN", J
    has(o, "ANCHOR: none given")
    d, res, o, M, J = chain_case("ch4b", fund=False, period="2025-06-30")
    assert J["enterprise_value"][0] == "'Valuation Summary'!B7" and J["enterprise_value"][1] == "SUPPORTED", J


@test("CH.5 two complete chains: without the anchor nothing is guessed (review required); the reported value settles it")
def ch5():
    d, res, o, M, J = chain_case("ch5", fund=False, second_chain=True)
    assert all(v == (None, "AMBIGUOUS") for v in J.values()) and M["gates"]["key_numbers_review_required"] == 1, J
    has(o, "DISCOVERY: valuation chain | ambiguous")
    d, res, o, M, J = chain_case("ch5b", extra=FUND, second_chain=True)
    assert {k: v[0] for k, v in J.items()} == TRUE_CHAIN and J["enterprise_value"][1] == "PROVEN", J


@test("CH.6 a reported value found nowhere in the workbook is flagged for review and never PROVEN")
def ch6():
    d, res, o, M, J = chain_case("ch6", extra=FUND, anchor_value_override=31_000_000)
    assert J["enterprise_value"] == (TRUE_CHAIN["enterprise_value"], "SUPPORTED") and M["gates"]["reported_value_not_found"] == 1, J
    has(o, "| unanchored")


@test("CH.7 a value reported in another currency is matched through the workbook's own FX conversion or FX rate")
def ch7():
    d, res, o, M, J = chain_case("ch7", extra=FUND, fx=0.73)
    assert J["value_to_xpv"] == ("'Cap Table'!B13", "PROVEN"), J
    d, res, o, M, J = chain_case("ch7b", extra=FUND, fx=0.73, usd_row=False)
    assert J["value_to_xpv"] == ("'Cap Table'!B5", "PROVEN") and M["layer2"]["chain"]["anchor"]["via_fx"] == 1, (J, M["layer2"]["chain"]["anchor"])


@test("CH.8 periods: explicit 'TTM ending ...' headers (words and numeric dates) date the column; impossible years are never evidence")
def ch8():
    d, res, o, M, J = chain_case("ch8", fund=False)
    rows = {r["cell"]: r for r in read_jsonl_gz(os.path.join(d, "map", "cells.jsonl.gz"))}
    assert rows["'Valuation Summary'!C6"]["l2"]["period"]["period"] == "2026-06", rows["'Valuation Summary'!C6"]["l2"]["period"]
    sys.path[:0] = [os.path.join(PKG, "discovery", "vp"), os.path.join(PKG, "discovery")]
    import semantics as SEM
    assert SEM.numeric_header_date("TTM 6/30/2026") == (2026, 6) and SEM.numeric_header_date("TTM 30/06/2026") == (2026, 6)
    assert SEM.numeric_header_date("TTM 3/4/2026") is None                     # March or April: never guessed
    assert all(1990 <= int(r["l2"]["period"]["period"][:4]) <= 2100 for r in rows.values() if r["l2"]["period"]["period"])


@test("B.11 'right value, wrong cell' is counted on its own: a typed copy of the right number is still the wrong cell")
def b11():
    d, res, o, M, J = chain_case("b11", extra=FUND)
    a_ = answers_file(d, "C.xlsx", {"value_to_xpv": "'Cap Table'!B6"})                  # the analyst points at the typed copy
    rc, o2, r = compare(d, answers=a_)
    k = r["meaning"]["key"]
    assert k["wrong"] == 1 and k["right value, wrong cell"] == 1, k
    has(o2, "right value wrong cell 1")


# ------------------------------------------------------------------------------------------------ V vendored
@test("V.1 the vendored build 11.3 modules are byte-identical to build 11.3.0 (their 76 tests live in that package)")
def v1():
    for line in open(os.path.join(PKG, "discovery", "vp_hashes.txt")):
        h, name = line.split()
        assert hashlib.sha256(open(os.path.join(PKG, "discovery", "vp", name), "rb").read()).hexdigest() == h, name


def main():
    for t in TESTS:
        t()
    ok = sum(1 for _, p, _ in RESULTS if p)
    for n, p, w in RESULTS:
        print(f"- {'PASS' if p else 'FAIL'}: {n}" + ("" if p else f"\n    {w}"))
    print(f"ALL TESTS: {'PASS' if ok == len(RESULTS) else 'FAIL'} ({ok}/{len(RESULTS)})")
    shutil.rmtree(ROOT, ignore_errors=True)
    return 0 if ok == len(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())
