# benchmark/xmlcount.py (build 11.4) - INDEPENDENT STRUCTURAL TRIPWIRE. Standard library only (zipfile + ElementTree): a
# different, deliberately simple extraction path from discovery's reader. For Gold workbooks the physical truth is the
# Excel-side count (gold-facts.ts); this checker catches reader bugs on every synthetic and Gold run.
# Counting rules R1: populated cell = a <c> element with a value, a formula or an inline string; formula cell = a <c>
# with an <f> element (anchor or shared member); error cell = t="e"; spill / array result = a cell inside an array formula's
# ref range other than its anchor, holding a value and no formula; defined names = non-hidden <definedName> elements.
import posixpath, re, zipfile
import xml.etree.ElementTree as ET

NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
RID = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"


def _col(s):
    n = 0
    for ch in s:
        n = n * 26 + ord(ch) - 64
    return n


def _cell(r):
    m = re.match(r"([A-Z]+)(\d+)", r)
    return int(m.group(2)), _col(m.group(1))


def _rels(z, part):
    d, b = posixpath.split(part)
    p = posixpath.join(d, "_rels", b + ".rels")
    out = {}
    if p in z.namelist():
        for el in ET.fromstring(z.read(p)).iter():
            if el.tag.endswith("Relationship"):
                t = el.get("Target", "")
                full = t.lstrip("/") if t.startswith("/") else posixpath.normpath(posixpath.join(d, t))   # absolute = from the package root
                out[el.get("Id")] = (full, el.get("Type", "").rsplit("/", 1)[-1])
    return out


def scan(path, want_formulas=False):
    """-> {sheets: [{name, state, populated, formulas, errors, array_results, shared_members}], defined_names, external_links,
    tables, formulas?: [(sheet, r, c, text or None, flags)] , values?: typed numeric cells}"""
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = _rels(z, "xl/workbook.xml")
        dn = [d for d in wb.iter(NS + "definedName")]
        out = {"sheets": [], "defined_names": sum(1 for d in dn if d.get("hidden") not in ("1", "true")),
               "defined_name_list": [d.get("name") for d in dn if d.get("hidden") not in ("1", "true")],
               "external_links": sum(1 for n in names if re.match(r"xl/externalLinks/externalLink\d+\.xml$", n)),
               "tables": sum(1 for n in names if re.match(r"xl/tables/table\d+\.xml$", n)), "formulas": [], "typed_numbers": []}
        for s in wb.iter(NS + "sheet"):
            part = rels.get(s.get(RID), (None,))[0]
            rec = {"name": s.get("name"), "state": s.get("state", "visible"), "populated": 0, "formulas": 0, "errors": 0,
                   "array_results": 0, "shared_members": 0}
            out["sheets"].append(rec)
            if not part or part not in names:
                continue
            arrays, valued, shared_text = [], [], {}
            with z.open(part) as fh:
                for ev, el in ET.iterparse(fh):
                    if el.tag != NS + "c":
                        if el.tag == NS + "row":
                            el.clear()
                        continue
                    f, v, is_ = el.find(NS + "f"), el.find(NS + "v"), el.find(NS + "is")
                    r, c = _cell(el.get("r"))
                    if f is not None or v is not None or is_ is not None:
                        rec["populated"] += 1
                    if el.get("t") == "e":
                        rec["errors"] += 1
                    if f is not None:
                        rec["formulas"] += 1
                        t = f.get("t")
                        text = (f.text or "").strip() or None
                        if t == "shared":
                            if text:
                                shared_text[f.get("si")] = text
                            else:
                                rec["shared_members"] += 1
                                text = shared_text.get(f.get("si"))
                        if t == "array":
                            ref = f.get("ref") or el.get("r")
                            a, _, b = ref.partition(":")
                            arrays.append((_cell(a), _cell(b or a)))
                        if want_formulas:
                            out["formulas"].append((rec["name"], r, c, text, {"shared": t == "shared", "array": t == "array",
                                                                               "no_saved_value": v is None}))
                    elif v is not None:
                        valued.append((r, c))
                        if want_formulas and el.get("t") in (None, "n"):
                            out["typed_numbers"].append((rec["name"], r, c))
                    el.clear()
            for (r, c) in valued:
                if any(a[0] <= r <= b[0] and a[1] <= c <= b[1] and (r, c) != a for a, b in arrays):
                    rec["array_results"] += 1
    out["totals"] = {k: sum(s[k] for s in out["sheets"]) for k in ("populated", "formulas", "errors", "array_results", "shared_members")}
    return out
