# discovery/discover.py (build 11.7) - the DISCOVERY SYSTEM. Reads one workbook (never changes it) and writes its map:
#   workbook_map.json      summary: Layer 0 inventory, Layer 1 graph status counts / regions / hubs, Layer 2 proposals,
#                          completeness controls, run metadata (versions, hashes, requested period as TARGET)
#   cells.jsonl.gz         one record per stored formula / number / date cell: Layer 0 facts, Layer 1 references and
#                          flags, Layer 2 period evidence, materiality, terminal class
#   discovery_review.xlsx  unreached calculation regions for the analyst (after the blind answers are frozen)
#   run_log.json           timings, peak memory, versions (NOT part of the deterministic map)
#   program_cells.csv      every cell, in exactly the layout of Excel's own export (excel-export.ts), so the two diff
#   program_uses.csv       for every formula: the cells it uses, in Excel's address style
#   program_answers.xlsx   the program's key numbers, months, method and areas in the analyst's form layout
#   program_answers.json   the same, machine-readable (with the program's confidence for each answer)
# Prints only counts and categories (PREFLIGHT: / DISCOVERY: lines) - names, cells and values stay in the files.
# Exit codes: 0 done | 1 internal error (a bug: the traceback goes to run_error.log) | 2 usage | 3 STOPPED (the user must act).
import argparse, datetime, os, platform, resource, sys, time, traceback
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path[:0] = [os.path.join(HERE, "vp"), HERE, PKG]
from common.util import VERSION, dump, sha256_file, write_jsonl_gz, cell_text, now, Stop, EXIT_OK, EXIT_INTERNAL, EXIT_STOPPED
from common.files import find_input, out_root
from common.preflight import check_workbook
from rules import RULES, INVARIANTS, HASHES
import invariants as INVC
import chain as CH
import fund as FUND
import csv
from common.forms import write_form, CELL_COLUMNS, USES_COLUMNS, METHOD_OF_VARIANT
from common.cellfmt import formula_text, value_and_type
from common.util import split_sheet
from wbutil import norm_label
from workbook_model import Model
import inventory as INV
import graph as GR
import semantics as SE
import periods as PER


def jsonable(v):
    if isinstance(v, (datetime.datetime, datetime.date)):
        return v.isoformat()[:10]
    return v


def load_cells(m, path, boxes_by_sheet):
    """reads cells the 11.3 reader did not hold: whole sheets (boxes None) or given boxes. Rebuilds the model's indexes."""
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True, read_only=True, keep_links=False)
    for sh, boxes in boxes_by_sheet.items():
        added = 0
        for row in wb[sh].iter_rows():
            for c in row:
                if c.value is None or not getattr(c, "row", None) or (sh, c.row, c.column) in m._v:
                    continue
                if boxes is None or any(b[1] <= c.row <= b[3] and b[2] <= c.column <= b[4] for b in boxes):
                    m._v[(sh, c.row, c.column)] = c.value
                    added += 1
        m.skipped_cells[sh] = max(0, m.skipped_cells.get(sh, 0) - added)
        if not m.skipped_cells[sh]:
            del m.skipped_cells[sh]
    wb.close()
    m._index()
    m._blocks, m._prec = None, {}


def ensure_stored(m, g, path):
    """cells only a table / name / 3-D reference reaches (beyond what the 11.3 reader held): load exactly those."""
    need = {}
    for n in g.nodes.values():
        for r in n["refs"]:
            if r.get("why", "").startswith("referenced cells are on a sheet region") and r.get("box"):
                need.setdefault(r["box"][0], []).append(r["box"])
    if need:
        load_cells(m, path, need)
    return bool(need)


def options_sheet(path, ch):
    """every valuation chain the program considered, kept or rejected, with the reason - the justification."""
    from openpyxl import load_workbook
    wb = load_workbook(path)
    ws = wb.create_sheet("3 Options considered")
    ws.append([f"Decision: {ch['status']}", "Rules, in order: " + "; ".join(ch["rules"])])
    if ch.get("anchor"):
        a = ch["anchor"]
        ws.append(["Reported value", f"from {a.get('source')}; {a.get('status')}; matching cells: {', '.join(a.get('matched') or []) or 'none'}; "
                   f"typed copies: {', '.join(a.get('copies') or []) or 'none'}"])
    ws.append([])
    ws.append(["Enterprise value cell", "Earnings figure", "Multiple", "Equity", "XPV value", "Result", "Reason / notes"])
    for o in ch["options"]:
        ws.append([o["ev"], ", ".join(c["metric"] for c in o["components"]), ", ".join(c["multiple"] for c in o["components"]),
                   o["equity"], o["investor"], "kept" if not o["rejected"] else "rejected", o["rejected"] or "; ".join(o["notes"])])
    for col, w in zip("ABCDEFG", (34, 30, 26, 30, 30, 10, 80)):
        ws.column_dimensions[col].width = w
    wb.save(path)


def export_cells(m, g, out, wsha):
    """every cell the program read, written the way Excel's export writes it (Sheet, Cell, Formula, Value, Type)."""
    from common.util import col_let
    order = {s: i for i, s in enumerate(g.order)}
    keys = sorted(m.cells, key=lambda c: (order.get(c[0], 999), c[1], c[2]))
    with open(os.path.join(out, "program_cells.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(CELL_COLUMNS)
        for k in keys:
            f, v = m._f.get(k), m._v.get(k)
            if v is None and not f:
                continue
            val, typ = value_and_type(v)
            w.writerow([k[0], f"{col_let(k[2])}{k[1]}", formula_text(f), val, typ])
    with open(os.path.join(out, "program_uses.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(USES_COLUMNS)
        for k in sorted(g.nodes, key=lambda c: (order.get(c[0], 999), c[1], c[2])):
            n = g.nodes[k]
            uses = "; ".join(r["ref"] for r in n["refs"] if r.get("box")) or ""
            fl = n["flags"]
            note = ", ".join(x for x in (
                "over-approximated" if fl["references_extracted"] == "OVER_APPROXIMATED" else None,
                "could not read every reference" if fl["references_extracted"] == "UNSUPPORTED" else None,
                "deleted reference" if fl["references_extracted"] == "MISSING" else None,
                "address computed at calculation time" if fl["dynamic_resolution"] == "DYNAMIC_UNRESOLVED" else None,
                "reads another workbook" if fl["location"] == "EXTERNAL" else None, "circular" if fl["cycle"] == "CIRCULAR" else None) if x)
            w.writerow([k[0], f"{col_let(k[2])}{k[1]}", uses, note])


def program_answers(m, J, regs, rows):
    """the program's answers in the analyst form's terms, with its confidence for each."""
    def split(cell):
        if not cell:
            return {}
        sh, a = split_sheet(cell)
        return {"sheet": sh, "cell": a}
    kn = {}
    for j in ("enterprise_value", "equity_value", "value_to_xpv", "valuation_metric", "selected_multiple"):
        x = J.get(j) or {}
        kn[j] = dict(split(x.get("cell")), status=x.get("status"), notes=f"confidence {x.get('status', 'NOT_DETERMINABLE').lower().replace('_', ' ')}")
    w = J.get("metric_window") or {}
    per = {r["cell"]: r["l2"]["period"] for r in rows}
    areas = []
    for r in regs:
        for area in r["areas"]:
            sh, a = split_sheet(area)
            ms = {p["period"] for c, p in per.items() if c.startswith(area.split("!")[0] + "!") and p["status"] in ("PROVEN", "SUPPORTED")
                  and _inside(c, area)}
            areas.append({"sheet": sh, "cells": a, "what": "Used by the valuation" if r["proposed"] == "reached_from_outputs" else
                          "Not used by the valuation - a person must say what it is" if r["proposed"] == "cannot_determine" else "Small, not used",
                          "month": next(iter(ms)) if len(ms) == 1 else None, "notes": f"{r['formulas']} formulas"})
    return {"key_numbers": kn, "months": {"metric_first_month": w.get("first"), "metric_last_month": w.get("last"),
                                          "status": w.get("status")},
            "method": METHOD_OF_VARIANT.get((J.get("method") or {}).get("variant"), "Other"),
            "method_status": (J.get("method") or {}).get("status"), "areas": areas}


def _inside(cell, area):
    from common.util import parse_box, cell_key
    b, k = parse_box(area), cell_key(cell)
    return b and b[0] == k[0] and b[1] <= k[1] <= b[3] and b[2] <= k[2] <= b[4]


def anchor_from(a, period_end):
    """the reported value: from the fund workbook (company row, quarter column), a named fund-workbook cell, or a value."""
    if a.get("fund_workbook"):
        return FUND.read_anchor(a["fund_workbook"], a.get("company"), period_end, a.get("anchor_cell"))
    if a.get("anchor_value") is not None:
        return {"value": float(a["anchor_value"]), "source": "value given by the user", "self_check": "not available"}
    return None


def chain_junctions(m, ch, legacy, an, roots_legacy):
    """the key numbers from the chosen chain. No chain or several: nothing is guessed (the label-based answers are kept
    beside, for comparison only)."""
    from common.util import cell_key
    st = ch["status"]
    J = {"legacy_label_based": legacy, "chain_status": st}
    c = ch["chosen"]
    why = {"PROVEN": "chain-first: the valuation chain recomputes and reaches the reported value / the requested month",
           "SUPPORTED": "chain-first: the only complete valuation chain, but neither the reported value nor the month confirms it",
           "AMBIGUOUS": f"review required: {sum(1 for o in ch['options'] if not o['rejected'])} valuation chains remain",
           "NOT_DETERMINABLE": "no valuation chain found"}[st]
    for jid in ("enterprise_value", "equity_value", "value_to_xpv", "valuation_metric", "selected_multiple"):
        J[jid] = {"cell": None, "status": st if st in ("AMBIGUOUS",) else "NOT_DETERMINABLE", "basis": why, "alternatives": []}
    roots = roots_legacy
    if c:
        comp = c["components"][0] if len(c["components"]) == 1 else max(c["components"], key=lambda x: (x["weight"] is not None, 0))
        cells = {"enterprise_value": c["ev"], "equity_value": c["equity"], "value_to_xpv": c["investor"],
                 "valuation_metric": comp["metric"], "selected_multiple": comp["multiple"]}
        for jid, cell in cells.items():
            J[jid] = {"cell": cell, "status": st if cell else "NOT_DETERMINABLE", "basis": why,
                      "copies": ch["copies"].get(jid, []), "alternatives": [o["ev"] for o in ch["options"] if o["ev"] != c["ev"]][:4] if jid == "enterprise_value" else []}
        roots = [cell_key(x) for x in (c["ev"], c["equity"], c["investor"]) if x]
        mk = cell_key(comp["metric"])
        up = m.upstream([mk]) | {mk}
        ws_ = [w for w in an["metric_windows"] if w["months"] == 12 and SE.AN.parse_ref_str(w["via"]) in up]
        w = ws_[0] if ws_ and len({x["last"] for x in ws_}) == 1 else None
        J["metric_window"] = {"first": w["first"] if w else None, "last": w["last"] if w else None, "months": w["months"] if w else None,
                              "status": st if w else "NOT_DETERMINABLE"}
        lab = " ".join(norm_label(m.label(cell_key(x["metric"])) or "") for x in c["components"])
        variant = "blended" if len(c["components"]) > 1 else ("ev_revenue" if (" revenue" in f" {lab}" or " sale" in f" {lab}") and "ebitda" not in lab else "ev_ebitda")
        J["method"] = {"variant": variant, "status": st}
    else:
        J["metric_window"] = {"first": None, "last": None, "months": None, "status": "NOT_DETERMINABLE"}
        J["method"] = {"variant": legacy.get("method", {}).get("variant"), "status": "SUPPORTED" if legacy.get("method", {}).get("variant") == "held_at_cost" else "NOT_DETERMINABLE"}
    return J, roots


def run(path, period_end, out, profile=None, pre=None, anchor_args=None):
    os.makedirs(out, exist_ok=True)
    t0, timings, last = time.time(), {}, [time.time()]

    def lap(k):
        t = time.time()
        timings[k] = round(t - last[0], 3)
        last[0] = t
    facts = INV.xml_facts(path)
    m = Model(path)
    if m.skipped_cells and sum(m.skipped_cells.values()) <= RULES["storage"]["load_unreferenced_cells_up_to"]:
        load_cells(m, path, {sh: None for sh in list(m.skipped_cells)})    # small enough: hold everything (Layer 0 complete)
    lap("read")
    if os.environ.get("WD_TEST_FAULT") == "after_read":          # test hook: behave like an internal bug (test E.1)
        raise RuntimeError("injected fault")
    arr = INV.array_result_cells(facts)
    inv = INV.inventory(m, facts, arr)
    g = GR.Graph(m, facts, arr)
    if ensure_stored(m, g, path):                         # cells only a table / name reference reaches: read them, rebuild
        g = GR.Graph(m, facts, arr)
    lap("graph")
    cp = PER.CellPeriods(m)
    memo = {}
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 5000))

    def period_of(k):
        pe = SE.period_evidence(m, g, k, cp, SE.AN.value_window, memo)
        return pe["period"] if pe["status"] in ("PROVEN", "SUPPORTED") else None
    legacy, roots_legacy, an = SE.junctions(m, path, period_end)
    anchor = anchor_from(anchor_args or {}, period_end)
    ch = CH.resolve(m, g, period_of, period_end[:7], anchor)
    J, roots = chain_junctions(m, ch, legacy, an, roots_legacy)
    lap("junctions")
    mat_ref = g.closure(roots)
    g.verify_values(keep_used_for=mat_ref)
    mat_con = g.closure(roots, contributing=True)
    regs, hubs, dependents = g.regions(mat_ref)
    terms = SE.terminals(m, g, mat_ref)
    pasted = SE.pasted_candidates(m, g, terms, mat_ref)
    region_of = {c: r["id"] for r in regs for c in r["_members"]}
    rows, pcount = [], {}
    term_class = {}
    for t in terms:
        term_class[t["cell"]] = t["class"]
    for k in sorted(m.cells, key=lambda c: (g.order.index(c[0]) if c[0] in g.order else 999, c[1], c[2])):
        f, v = m._f.get(k), m._v.get(k)
        if not f and not isinstance(v, (int, float, datetime.date, datetime.datetime)) or isinstance(v, bool):
            continue
        pe = SE.period_evidence(m, g, k, cp, SE.AN.value_window, memo)
        pcount[pe["status"]] = pcount.get(pe["status"], 0) + 1
        n = g.nodes.get(k)
        b = m.block_of_cell(k)
        ct = cell_text(*k)
        rows.append({"cell": ct,
                     "l0": {"kind": "formula" if f else "array_result" if k in arr else "date" if isinstance(v, (datetime.date, datetime.datetime)) else "number",
                            "formula": f, "value": jsonable(v), "saved_value_missing": bool(f and v is None)},
                     "l1": {"refs": [{x: r[x] for x in ("ref", "kind", "status", "via", "link", "why") if x in r} for r in n["refs"]] if n else [],
                            "flags": n["flags"] if n else None, "reasons": n["reasons"] if n else [], "functions": n["functions"] if n else [],
                            "label": m.row_label(k), "column_header": m.col_header(k), "block_row": b[0] if b else None,
                            "region": region_of.get(k), "dependents": dependents.get(k, 0), "hub": k in set(hubs),
                            "contributing_known": k in g.contrib if n else None},
                     "l2": {"period": pe, "material_by_reference": k in mat_ref, "material_by_contribution": k in mat_con,
                            "terminal_class": term_class.get(ct)}})
    lap("cells")
    write_jsonl_gz(rows, os.path.join(out, "cells.jsonl.gz"))
    ctx = {"m": m, "g": g, "J": J, "material": mat_ref,
           "period_of": lambda k: (lambda pe: pe["period"] if pe["status"] in ("PROVEN", "SUPPORTED") else None)(
               SE.period_evidence(m, g, k, cp, SE.AN.value_window, memo))}
    invs = INVC.evaluate(ctx, profile)
    fl = {"references_extracted": {}, "dynamic_resolution": {}, "location": {}, "cycle": {}, "value_verification": {}}
    mfl = {k_: {} for k_ in fl}
    for k, n in g.nodes.items():
        for f_, v_ in n["flags"].items():
            if f_ in fl:
                fl[f_][v_] = fl[f_].get(v_, 0) + 1
                if k in mat_ref:
                    mfl[f_][v_] = mfl[f_].get(v_, 0) + 1
    heads = {j: g.headline(SE.AN.parse_ref_str(J[j]["cell"])) for j in ("enterprise_value", "equity_value", "value_to_xpv") if J[j].get("cell")}
    unsupported = sorted({(n["cell"], "; ".join(n["reasons"])) for k, n in g.nodes.items()
                          if n["flags"]["references_extracted"] in ("UNSUPPORTED", "MISSING") or n["flags"]["dynamic_resolution"] == "DYNAMIC_UNRESOLVED"})
    unreached_open = [r for r in regs if r["proposed"] == "cannot_determine"]
    unres_terms = [t for t in terms if t["class"] == "unresolved"]
    questions = [j for j, x in J.items() if j != "legacy_label_based" and isinstance(x, dict) and "status" in x and x.get("status") not in ("PROVEN",)]
    gates = {"material_outputs_not_fully_known": sum(1 for h in heads.values() if h != "FULL"),
             "material_formulas_truncated": sum(1 for k in mat_ref if k in g.nodes and (g.nodes[k]["flags"]["references_extracted"] in ("UNSUPPORTED", "MISSING")
                                                or g.nodes[k]["flags"]["dynamic_resolution"] == "DYNAMIC_UNRESOLVED")),
             "material_formulas_circular": sum(1 for k in mat_ref if k in g.nodes and g.nodes[k]["flags"]["cycle"] == "CIRCULAR"),
             "unreached_regions_cannot_determine": len(unreached_open), "unresolved_material_terminals": len(unres_terms),
             "pasted_value_candidates": len(pasted), "formulas_without_saved_value": inv["totals"]["formulas_without_saved_value"],
             "invariants_violated": sum(1 for r in invs["results"] if r["status"] == "VIOLATED"),
             "key_numbers_review_required": 1 if ch["status"] == "AMBIGUOUS" else 0,
             "reported_value_not_found": 1 if (ch["anchor"] or {}).get("status") == "unanchored" else 0}
    wsha = sha256_file(path)
    summary = {
        "meta": {"discovery_version": VERSION, "graph_rules": GR.RULES, "period_rules": SE.PERIOD_RULES, "terminal_classes": SE.TERMINAL_CLASSES,
                 "rules_hashes": HASHES, "invariants_version": INVARIANTS["version"], "invariant_profile": profile,
                 "preflight": pre, "workbook": os.path.basename(path), "workbook_sha256": wsha, "workbook_fingerprint": m.fingerprint(),
                 "requested_period_target": period_end, "run_at": now().isoformat(), "python_only": True, "ai_interpretations": 0},
        "layer0": inv,
        "layer1": {"formula_nodes": len(g.nodes), "flags": fl, "material_flags": mfl, "hubs": [cell_text(*h) for h in hubs][:50],
                   "hub_count": len(hubs), "regions": [{k_: v_ for k_, v_ in r.items() if k_ != "_members"} for r in regs],
                   "fully_interpreted": sum(1 for n in g.nodes.values() if n["flags"]["references_extracted"] == "COMPLETE"
                                            and n["flags"]["dynamic_resolution"] != "DYNAMIC_UNRESOLVED"
                                            and (n["flags"]["location"] == "INTERNAL" or n["flags"]["external_identified"])),
                   "material_by_reference": len(mat_ref), "material_by_contribution": len(mat_con),
                   "material_formulas_contribution_unknown": sum(1 for k in mat_ref if k in g.nodes and k not in g.contrib),
                   "unsupported_or_dynamic_examples": [{"cell": c, "why": w} for c, w in unsupported[:40]]},
        "layer2": {"junctions": J, "chain": ch, "output_headlines": heads, "terminals": terms, "pasted_value_candidates": pasted, "invariants": invs,
                   "period_status_counts": pcount, "analyst_confirmations_needed": len(questions), "questions": questions},
        "gates": gates}
    dump(summary, os.path.join(out, "workbook_map.json"))
    review(regs, os.path.join(out, "discovery_review.xlsx"), wsha)
    export_cells(m, g, out, wsha)
    answers = program_answers(m, J, regs, rows)
    dump(answers, os.path.join(out, "program_answers.json"))
    write_form(os.path.join(out, "program_answers.xlsx"), {"Workbook": os.path.basename(path), "Workbook fingerprint": wsha,
                                                             "Produced by": f"the program, build {VERSION}", "Quarter end": period_end},
               answers, title="The program's answers", who="program")
    options_sheet(os.path.join(out, "program_answers.xlsx"), ch)
    lap("write")
    dump({"discovery_version": VERSION, "timings_seconds": timings, "total_seconds": round(time.time() - t0, 2),
          "peak_memory_mb": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024, "python": platform.python_version(),
          "openpyxl": __import__("openpyxl").__version__, "formula_nodes": len(g.nodes), "stored_cells": len(m.cells)},
         os.path.join(out, "run_log.json"))
    return summary


def review(regs, path, wsha):
    from openpyxl import Workbook
    from openpyxl.worksheet.datavalidation import DataValidation
    wb = Workbook()
    ws = wb.active
    ws.title = "Unreached regions"
    ws.append(["Workbook SHA-256", wsha])
    ws.append(["Region", "Areas", "Formulas", "Sink labels (nearest row labels)", "Proposed by Python", "Analyst verdict", "Analyst note"])
    dv = DataValidation(type="list", formula1='"material,supporting,reference_only,historical,presentation,irrelevant,unsure"', allow_blank=True)
    ws.add_data_validation(dv)
    for r in regs:
        if r["proposed"] == "reached_from_outputs":
            continue
        ws.append([r["id"], "; ".join(r["areas"]), r["formulas"], "; ".join(x for x in r["sink_labels"] if x), r["proposed"], None, None])
        dv.add(f"F{ws.max_row}")
    wb.save(path)


def program_folder(path):
    """the results folder for a workbook: program_<workbook name without extension> (the benchmark finds it the same way)."""
    import re as _re
    return "program_" + _re.sub(r"[^A-Za-z0-9 ._-]", "_", os.path.splitext(os.path.basename(path))[0])[:80]


def main(argv=None):
    ap = argparse.ArgumentParser(prog="discover.py", description="Read one workbook (never changes it) and write its map.")
    ap.add_argument("--workbook", required=True, help="file name (searched where knowledge files and uploads land) or path")
    ap.add_argument("--period-end", required=True, help="the requested quarter end, YYYY-MM-DD: the TARGET, never evidence")
    ap.add_argument("--out", default=None, help="output folder (default: /app/created/program_<workbook name> or ./program_<workbook name>)")
    ap.add_argument("--profile", default=None, help="invariant profile in references/invariants.json (per-company overrides)")
    ap.add_argument("--fund-workbook", default=None, help="the fund valuation workbook: the company's reported value anchors the chain")
    ap.add_argument("--company", default=None, help="the company's name as the fund workbook shows it")
    ap.add_argument("--anchor-cell", default=None, help="the fund-workbook cell holding the reported value (skips the search)")
    ap.add_argument("--anchor-value", default=None, type=float, help="the reported value itself, if no fund workbook is available")
    ap.add_argument("--version", action="version", version=f"workbook-discovery {VERSION}")
    a = ap.parse_args(argv)
    out = None
    try:
        if not (len(a.period_end) == 10 and a.period_end[4] == "-" and a.period_end[7] == "-"):
            raise Stop(f"--period-end must be YYYY-MM-DD (got '{a.period_end}')", "usage")
        path = find_input(a.workbook, "workbook")
        pre = check_workbook(path, RULES["preflight"])
        print(f"PREFLIGHT: OK {pre['kind']} | {pre['bytes'] / 1e6:.1f} MB | {pre['parts']} parts | macros {'yes' if pre['macros'] else 'no'} | "
              f"external link parts {pre['external_link_parts']}" + "".join(f" | warning: {w}" for w in pre["warnings"]), flush=True)
        out = out_root(a.out or program_folder(path))
        anc = {"fund_workbook": find_input(a.fund_workbook, "fund valuation workbook") if a.fund_workbook else None,
               "company": a.company, "anchor_cell": a.anchor_cell, "anchor_value": a.anchor_value}
        if anc["fund_workbook"]:
            check_workbook(anc["fund_workbook"], RULES["preflight"])
        s = run(path, a.period_end, out, a.profile, pre, anc)
    except Stop as e:
        msg = str(e)
        print(msg if msg.startswith("PREFLIGHT:") else f"STOPPED: {msg}")
        return EXIT_STOPPED
    except Exception as e:                                   # a bug: one clear line here, the traceback in a file
        logp = os.path.join(out or os.getcwd(), "run_error.log")
        try:
            open(logp, "w").write(traceback.format_exc())
        except OSError:
            logp = "(not writable)"
        print(f"DISCOVERY ERROR: internal {type(e).__name__} - a bug, not a workbook problem; send this line and run_error.log to the maintainer")
        if os.environ.get("WD_DEBUG"):
            traceback.print_exc()
        return EXIT_INTERNAL
    t, l1, g = s["layer0"]["totals"], s["layer1"], s["gates"]
    re_ = l1["flags"]["references_extracted"]
    inv = s["layer2"]["invariants"]["results"]
    print(f"DISCOVERY: build {VERSION} | rules {GR.RULES['version']}/{SE.PERIOD_RULES['version']}/{INVARIANTS['version']} | python only")
    print(f"DISCOVERY: physical | worksheets {s['layer0']['worksheets']} | populated cells {t['populated_cells']} | formula cells {t['formula_cells']} | "
          f"array results {t['array_result_cells']} | defined names {s['layer0']['defined_names']} | tables {s['layer0']['tables']}")
    print(f"DISCOVERY: graph | formula nodes {l1['formula_nodes']} | complete {re_.get('COMPLETE', 0)} | over-approximated {re_.get('OVER_APPROXIMATED', 0)} | "
          f"unsupported {re_.get('UNSUPPORTED', 0)} | missing {re_.get('MISSING', 0)} | regions {len(l1['regions'])} | hubs {l1['hub_count']}")
    chn = s["layer2"]["chain"]
    an_ = chn.get("anchor")
    if an_:
        print(f"ANCHOR: {an_.get('source')} | " + (f"company row found (name match {an_['row_match']}) | value column {an_['value_column']} | "
              if an_.get("row_match") else "") + f"MOIC self-check {an_.get('self_check')} | in the company workbook: "
              f"{an_['formula_matches']} formula match(es), {an_['typed_copies']} typed copy(ies)" + (f", {an_['via_fx']} via an FX rate" if an_.get("via_fx") else "")
              + f" | {an_['status']}")
    else:
        print("ANCHOR: none given - the valuation chain was found from the workbook's structure only (give --fund-workbook to confirm it)")
    print(f"DISCOVERY: valuation chain | {chn['status'].lower().replace('_', ' ')} | options {len(chn['options'])} | "
          f"rejected {sum(1 for o in chn['options'] if o['rejected'])} | kept {sum(1 for o in chn['options'] if not o['rejected'])}")
    print("DISCOVERY: outputs | " + (" | ".join(f"{k} {v.lower()}" for k, v in s["layer2"]["output_headlines"].items()) or "none chosen"))
    print("DISCOVERY: invariants | " + " | ".join(f"{st.lower().replace('_', ' ')} {sum(1 for r in inv if r['status'] == st)}"
                                                 for st in ("HOLDS", "VIOLATED", "NOT_APPLICABLE", "NOT_EVALUATED")))
    print("DISCOVERY: gates | " + " | ".join(f"{k.replace('_', ' ')} {v}" for k, v in g.items()))
    print(f"DISCOVERY: files written to {os.path.basename(out)} - the program's answers are in program_answers.xlsx; "
          "keep every file in this environment and do not show them to the analyst before the analyst's answers are saved")
    return EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
