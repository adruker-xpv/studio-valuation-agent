# discovery/inventory.py (build 11.4) - LAYER 0: what the workbook file physically contains. Observation only.
#   xml_facts(path)        read straight from the .xlsx package (zip of XML parts): sheet order and visibility, calculation
#                          settings, defined names (with their text), Excel tables, array / dynamic-array (spill) formulas,
#                          shared formulas, data-table formulas, pivot tables, conditional formats, data validations,
#                          charts, external-link records
#   inventory(m, facts)    per-sheet counts from the workbook model (stored and counted-but-not-stored cells, formulas,
#                          numbers, dates, text, errors, formulas without a saved value, array / spill result cells)
# Counting rules: docs "Stage 0 counting rules" (R1). A formula cell is a cell with an <f> element (an anchor or a
# shared-formula member). A spill / array result cell is a cell inside an array formula's ref range, other than its
# anchor: it holds a value but is a formula RESULT, never a typed input.
import datetime, posixpath, re, zipfile
import xml.etree.ElementTree as ET

NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
RNS = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"


def _rels(z, part):
    d, b = posixpath.split(part)
    rp = posixpath.join(d, "_rels", b + ".rels")
    out = {}
    if rp in z.namelist():
        for el in ET.fromstring(z.read(rp)).iter():
            if el.tag.endswith("Relationship"):
                t = el.get("Target", "")
                full = posixpath.normpath(posixpath.join(d, t)) if not t.startswith("/") else t.lstrip("/")
                out[el.get("Id")] = {"target": full, "type": el.get("Type", "").rsplit("/", 1)[-1], "mode": el.get("TargetMode")}
    return out


def _unxml(s):
    return (s or "").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"').replace("&apos;", "'")


def xml_facts(path):
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        wrels = _rels(z, "xl/workbook.xml")
        sheets = []
        for i, s in enumerate(wb.iter(NS + "sheet"), 1):
            rid = s.get(RNS + "id")
            sheets.append({"name": s.get("name"), "order": i, "state": s.get("state", "visible"),
                           "part": wrels.get(rid, {}).get("target")})
        cp = next(wb.iter(NS + "calcPr"), None)
        calc = {"calc_mode": (cp.get("calcMode") if cp is not None else None) or "auto",
                "iterate": (cp.get("iterate") if cp is not None else None) in ("1", "true"),
                "full_calc_on_load": (cp.get("fullCalcOnLoad") if cp is not None else None) in ("1", "true")}
        dnames = []
        for d in wb.iter(NS + "definedName"):
            dnames.append({"name": d.get("name"), "text": _unxml(d.text), "local_sheet": d.get("localSheetId"),
                           "hidden": d.get("hidden") in ("1", "true")})
        tables, per_sheet = [], {}
        for s in sheets:
            part = s["part"]
            info = {"shared_formula_members": 0, "array_formulas": [], "data_table_formulas": 0, "pivot_tables": [],
                    "conditional_formats": 0, "data_validations": 0, "drawings": 0, "hidden_rows": 0, "hidden_cols": 0}
            per_sheet[s["name"]] = info
            if not part or part not in names:
                continue
            with z.open(part) as fh:                       # streamed: big sheets are never held whole
                for ev, el in ET.iterparse(fh, events=("end",)):
                    tag = el.tag[len(NS):] if el.tag.startswith(NS) else el.tag
                    if tag == "c":
                        f = el.find(NS + "f")
                        if f is not None:
                            t = f.get("t")
                            if t == "shared" and not (f.text or "").strip():
                                info["shared_formula_members"] += 1
                            elif t == "array":
                                info["array_formulas"].append({"cell": el.get("r"), "ref": f.get("ref") or el.get("r"),
                                                               "dynamic": el.get("cm") is not None})
                            elif t == "dataTable":
                                info["data_table_formulas"] += 1
                        el.clear()
                    elif tag == "row":
                        if el.get("hidden") in ("1", "true"):
                            info["hidden_rows"] += 1
                        el.clear()
                    elif tag == "col":
                        if el.get("hidden") in ("1", "true"):
                            info["hidden_cols"] += 1
                    elif tag == "conditionalFormatting":
                        info["conditional_formats"] += 1
                    elif tag == "dataValidation":
                        info["data_validations"] += 1
            for rid, r in _rels(z, part).items():
                if r["type"] == "table" and r["target"] in names:
                    t = ET.fromstring(z.read(r["target"]))
                    cols = [c.get("name") for c in t.iter(NS + "tableColumn")]
                    tables.append({"name": t.get("name"), "display_name": t.get("displayName") or t.get("name"),
                                   "sheet": s["name"], "ref": t.get("ref"), "columns": cols,
                                   "header_rows": int(t.get("headerRowCount", "1")), "totals_rows": int(t.get("totalsRowCount", "0") or 0)})
                elif r["type"] == "pivotTable" and r["target"] in names:
                    loc = next(ET.fromstring(z.read(r["target"])).iter(NS + "location"), None)
                    info["pivot_tables"].append({"ref": loc.get("ref") if loc is not None else None})
                elif r["type"] == "drawing":
                    info["drawings"] += 1
        charts = sum(1 for n in names if re.match(r"xl/charts/chart\d+\.xml$", n))
    return {"sheets": sheets, "calc": calc, "defined_names": dnames, "tables": tables, "per_sheet": per_sheet, "charts": charts}


def array_result_cells(facts):
    """cells inside array / spill formula ranges other than the anchor: formula RESULTS, never typed inputs."""
    from common.util import parse_box, box_cells
    out = {}
    for sh, info in facts["per_sheet"].items():
        for a in info["array_formulas"]:
            b = parse_box(a["ref"], sh)
            anchor = parse_box(a["cell"], sh)
            cells = box_cells(b, 100_000) if b else None
            for k in cells or ():
                if anchor and k != (sh, anchor[1], anchor[2]):
                    out[k] = (sh, anchor[1], anchor[2])
    return out


def inventory(m, facts, arr):
    """per-sheet physical counts. 'stored' cells are held in memory; 'counted' cells (formula-free sheets nothing refers
    to) are counted only - accounted for, not stored."""
    per = {}
    for s in facts["sheets"]:
        per[s["name"]] = {"order": s["order"], "state": s["state"], "stored_cells": 0, "counted_not_stored": m.skipped_cells.get(s["name"], 0),
                          "formula_cells": 0, "array_result_cells": 0, "numbers": 0, "dates": 0, "text": 0, "booleans": 0,
                          "errors": 0, "formulas_without_saved_value": 0}
    for k in m.cells:
        p = per.setdefault(k[0], {"stored_cells": 0, "counted_not_stored": 0, "formula_cells": 0, "array_result_cells": 0, "numbers": 0,
                                  "dates": 0, "text": 0, "booleans": 0, "errors": 0, "formulas_without_saved_value": 0})
        p["stored_cells"] += 1
        f, v = m._f.get(k), m._v.get(k)
        if f:
            p["formula_cells"] += 1
            if v is None:
                p["formulas_without_saved_value"] += 1
        elif k in arr:
            p["array_result_cells"] += 1
        if isinstance(v, bool):
            p["booleans"] += 1
        elif isinstance(v, (int, float)):
            p["numbers"] += 1
        elif isinstance(v, (datetime.datetime, datetime.date)):
            p["dates"] += 1
        elif isinstance(v, str):
            if v.startswith("#") and (v.endswith("!") or v.endswith("?") or v.isupper() or "/" in v):
                p["errors"] += 1
            else:
                p["text"] += 1
    tot = {k: sum(p.get(k, 0) for p in per.values()) for k in ("stored_cells", "counted_not_stored", "formula_cells",
                                                                "array_result_cells", "numbers", "dates", "text", "booleans", "errors",
                                                                "formulas_without_saved_value")}
    tot["populated_cells"] = tot["stored_cells"] + tot["counted_not_stored"]
    return {"sheets": per, "totals": tot, "worksheets": len(facts["sheets"]),
            "hidden_sheets": sum(1 for s in facts["sheets"] if s["state"] != "visible"),
            "defined_names": len(facts["defined_names"]), "visible_defined_names": sum(1 for d in facts["defined_names"] if not d["hidden"]),
            "external_link_records": len(getattr(m, "links", []) or []), "tables": len(facts["tables"]),
            "array_formulas": sum(len(i["array_formulas"]) for i in facts["per_sheet"].values()),
            "dynamic_array_formulas": sum(1 for i in facts["per_sheet"].values() for a in i["array_formulas"] if a["dynamic"]),
            "shared_formula_members": sum(i["shared_formula_members"] for i in facts["per_sheet"].values()),
            "data_table_formulas": sum(i["data_table_formulas"] for i in facts["per_sheet"].values()),
            "pivot_tables": sum(len(i["pivot_tables"]) for i in facts["per_sheet"].values()),
            "conditional_formats": sum(i["conditional_formats"] for i in facts["per_sheet"].values()),
            "data_validations": sum(i["data_validations"] for i in facts["per_sheet"].values()),
            "charts": facts["charts"], "calc": facts["calc"]}
