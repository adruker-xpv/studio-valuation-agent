# discovery/invariants.py (build 11.5) - consistency checks on the workbook discovery reads, selected and parameterised by
# references/invariants.json. Each result: HOLDS | VIOLATED | NOT_APPLICABLE | NOT_EVALUATED, with its detail.
# Invariants show arithmetic is consistent; they do NOT prove meaning (a whole column of the wrong period passes them all).
from common.util import Stop
from wbutil import norm_label, is_num, parse_ref_str
from rules import INVARIANTS

CHECKS = {}


def check(name):
    def deco(fn):
        CHECKS[name] = fn
        return fn
    return deco


def _v(ctx, jid):
    c = (ctx["J"].get(jid) or {}).get("cell")
    if not c:
        return None, None
    k = parse_ref_str(c)
    v = ctx["m"].v(k)
    return k, (float(v) if is_num(v) else None)


def _close(a, b, rel):
    return abs(a - b) <= max(1e-6, rel * max(abs(a), abs(b)))


@check("ev_equals_multiple_times_metric")
def _ev(ctx, p):
    variant = ctx["J"].get("method", {}).get("variant")
    if variant in ("blended", "weighted_methods", "held_at_cost"):
        return "NOT_APPLICABLE", f"method {variant} is not a single multiple x metric"
    _, ev = _v(ctx, "enterprise_value")
    _, mu = _v(ctx, "selected_multiple")
    _, me = _v(ctx, "valuation_metric")
    if None in (ev, mu, me):                      # applies whenever the junctions exist - even if the method was not
        return "NOT_EVALUATED", "a junction cell is missing or not numeric"   # proven (a stale EV must not hide here)
    ok = _close(ev, mu * me, p.get("tolerance_rel", 5e-4))
    return ("HOLDS" if ok else "VIOLATED"), "EV = multiple x metric" + ("" if ok else f" (off by {abs(ev - mu * me):,.2f})")


@check("equity_reconciles_to_ev")
def _eq(ctx, p):
    ke, _ = _v(ctx, "equity_value")
    kv, _ = _v(ctx, "enterprise_value")
    if not ke or not kv:
        return "NOT_EVALUATED", "equity or EV not found"
    n = ctx["g"].nodes.get(ke)
    if not n:
        return "VIOLATED", "equity value is a typed number, not calculated from EV"
    if kv not in ctx["g"].closure([ke]):
        return "VIOLATED", "equity value does not depend on enterprise value"
    vv = n["flags"]["value_verification"]
    if vv == "MISMATCH":
        return "VIOLATED", "equity's formula gives a different value from the saved one"
    return ("HOLDS" if vv == "RECOMPUTED" else "NOT_EVALUATED"), "equity is calculated from EV" + ("" if vv == "RECOMPUTED" else " (formula not re-computable)")


@check("value_to_xpv_not_above_equity")
def _val(ctx, p):
    _, eq = _v(ctx, "equity_value")
    _, va = _v(ctx, "value_to_xpv")
    if va is None or eq is None:
        return "NOT_EVALUATED", "value to XPV or equity not found"
    if va < -1e-6:
        return "VIOLATED", "value to XPV is negative"
    ok = eq <= 0 or va <= eq * p.get("max_ratio", 1.0005)
    return ("HOLDS" if ok else "VIOLATED"), "value to XPV is not above equity" + ("" if ok else " (set max_ratio by override if FX explains it)")


@check("ttm_window_twelve_months_ending_at_metric_period")
def _ttm(ctx, p):
    w = ctx["J"].get("metric_window") or {}
    k, _ = _v(ctx, "valuation_metric")
    if not w.get("last") or not k:
        return "NOT_APPLICABLE", "no metric window found"
    mp = ctx["period_of"](k)
    if w.get("months") != 12:
        return "VIOLATED", f"the metric window covers {w.get('months')} months"
    if mp and mp != w["last"]:
        return "VIOLATED", f"window ends {w['last']} but the metric cell's period is {mp}"
    return "HOLDS", f"12 months ending {w['last']}"


@check("junction_periods_agree")
def _jp(ctx, p):
    pers = {}
    for j in ("enterprise_value", "equity_value", "value_to_xpv", "valuation_metric"):
        k, _ = _v(ctx, j)
        if k:
            pp = ctx["period_of"](k)
            if pp:
                pers[j] = pp
    if not pers:
        return "NOT_EVALUATED", "no junction period determined"
    return ("HOLDS" if len(set(pers.values())) == 1 else "VIOLATED"), ", ".join(f"{j} {v}" for j, v in sorted(pers.items()))


@check("material_formulas_have_saved_values")
def _sv(ctx, p):
    miss = [k for k in ctx["material"] if k in ctx["g"].nodes and ctx["m"].v(k) is None]
    return ("HOLDS" if not miss else "VIOLATED"), f"{len(miss)} material formula(s) without a saved value"


@check("material_recomputed_formulas_match")
def _rc(ctx, p):
    bad = [k for k in ctx["material"] if k in ctx["g"].nodes and ctx["g"].nodes[k]["flags"]["value_verification"] == "MISMATCH"]
    return ("HOLDS" if not bad else "VIOLATED"), f"{len(bad)} material formula(s) whose saved value Python does not reproduce"


@check("balance_sheet_balances")
def _bs(ctx, p):
    m = ctx["m"]
    hit = lambda lab, ws: any(f" {norm_label(w)} " in f" {norm_label(lab)} " for w in ws)
    for b in m.blocks():
        rows = {r["label"]: r for r in b["rows"]}
        A = next((r for l, r in rows.items() if hit(l, p["assets_words"])), None)
        Lb = next((r for l, r in rows.items() if hit(l, p["liabilities_words"]) and not hit(l, p["equity_words"])), None)
        E = next((r for l, r in rows.items() if hit(l, p["equity_words"]) and not hit(l, p["liabilities_words"])), None)
        if A and Lb and E:
            months = sorted(set(A["cells"]) & set(Lb["cells"]) & set(E["cells"]))
            off = [i for i in months if abs(m.v(A["cells"][i]) - m.v(Lb["cells"][i]) - m.v(E["cells"][i])) > p.get("tolerance_abs", 1.0)]
            from wbutil import ym_str
            return ("HOLDS" if not off else "VIOLATED"), (f"assets = liabilities + equity in all {len(months)} months" if not off else
                                                          f"does not balance in {len(off)} of {len(months)} months, e.g. {ym_str(off[0])}")
    if m.skipped_cells:                              # could not look everywhere: never claim absence
        return "NOT_EVALUATED", f"{sum(m.skipped_cells.values())} cells on sheets nothing refers to were counted, not read"
    return "NOT_APPLICABLE", "no block with total assets, total liabilities and total equity rows"


def evaluate(ctx, profile=None):
    reg = INVARIANTS
    ov = reg["overrides"].get(profile, {}) if profile else {}
    if profile and profile not in reg["overrides"]:
        raise Stop(f"invariant profile '{profile}' is not in references/invariants.json", "invalid_document")
    out = []
    for inv in reg["invariants"]:
        if inv["check"] not in CHECKS:
            raise Stop(f"invariant {inv['id']} names an unknown check '{inv['check']}'", "invalid_document")
        if inv["id"] in ov.get("disable", []):
            out.append({"id": inv["id"], "check": inv["check"], "status": "NOT_APPLICABLE", "detail": f"disabled by profile {profile}"})
            continue
        params = dict(inv, **ov.get("params", {}).get(inv["id"], {}))
        try:
            st, detail = CHECKS[inv["check"]](ctx, params)
        except Stop:
            raise
        except Exception as e:                                         # a check bug must not hide other results
            st, detail = "NOT_EVALUATED", f"check failed: {type(e).__name__}"
        out.append({"id": inv["id"], "check": inv["check"], "status": st, "detail": detail})
    return {"version": reg["version"], "profile": profile, "results": out}
