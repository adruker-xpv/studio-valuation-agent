# discovery/vp_adapter.py (build 11.5) - the ONLY place the vendored build 11.3 code is adapted. Its analysis builds its own
# workbook model from a path; reading a large workbook twice would double memory. model_reused(m) hands it the model
# discovery already read, for the duration of one call. The vendored files stay byte-identical (test V.1).
import contextlib, threading
import analyze as AN

_LOCK = threading.Lock()


@contextlib.contextmanager
def model_reused(m):
    with _LOCK:
        original = AN.Model
        AN.Model = lambda _path: m
        try:
            yield AN
        finally:
            AN.Model = original
