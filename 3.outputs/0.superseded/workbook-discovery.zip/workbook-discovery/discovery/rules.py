# discovery/rules.py (build 11.5) - loads and validates the versioned rule files once. The map records each file's hash.
import json, os
from common.util import Stop, canon, sha256_text
from common.schema import validate

REF = os.path.join(os.path.dirname(os.path.abspath(__file__)), "references")
SPEC = {"graph": {"version": str, "over_approximating_functions": [str], "dynamic_functions": [str], "hub_min_dependents": int,
                  "region_min_formulas": int, "region_family_merge": str},
        "period": {"version": str},
        "terminals": {"classes": [str], "pasted": {"min_significant_digits": int, "max_per_input": int, "max_total": int}},
        "preflight": {"max_file_mb": int, "max_uncompressed_mb": int, "warn_file_mb": int},
        "storage": {"load_unreferenced_cells_up_to": int}}


def _load(name):
    with open(os.path.join(REF, name), encoding="utf-8") as fh:
        return json.load(fh)


RULES = validate(_load("discovery_rules.json"), SPEC, "discovery rules file")
INVARIANTS = validate(_load("invariants.json"), {"version": str, "invariants": [{"id": str, "check": str}], "overrides": dict}, "invariant registry")
HASHES = {"discovery_rules": sha256_text(canon(RULES))[:16], "invariants": sha256_text(canon(INVARIANTS))[:16]}
