# discovery/semantics.py (build 11.7) - LAYER 2 PROPOSALS: what the important cells appear to mean. Every conclusion lists
# its evidence; the requested period is the TARGET for choosing junctions and is never evidence (test D.12 enforces it).
#   junctions(...)        proposed output roots and valuation junctions (via the 11.3 analysis, reusing the model)
#   period_evidence(...)  decision table P1 (below): role-specific authority, conflicts, checks run, categorical status
#   terminals(...)        every material input: CLASS (what it is) and SOURCE EVIDENCE (where it comes from), separately
#   pasted_candidates()   possible provenance matches for typed inputs (distinctive values found in unreached formulas)
import datetime, math, re
from collections import defaultdict
from common.util import cell_text, box_text
import analyze as AN
import periods as PER
from rules import RULES
from vp_adapter import model_reused
from wbutil import ym_to_i, ym_str, norm_label, is_num

PERIOD_RULES = {
    "version": RULES["period"]["version"],
    "authoritative": ["block_header (the cell is inside a dated monthly / quarterly block)",
                      "window_from_references (a formula summing one block row: its window end)",
                      "value_matched_window (a single window of one block row reproduces the value)",
                      "single_source_month (a formula taking one block cell: that month)",
                      "precedents_period (every input with a determined period is PROVEN for the same month)",
                      "date_value (the cell's own value is a date)"],
    "supporting": ["column_header / row_header / sheet_name (a declared period near the cell)",
                   "referenced_block_range (an over-approximated range: the window it COULD cover)"],
    "status": {"PROVEN": "authoritative evidence, all evidence agrees, every applicable check ran",
               "SUPPORTED": "only supporting evidence, all agreeing",
               "AMBIGUOUS": "references block rows whose windows end in different months, or inputs from several periods",
               "CONFLICTING": "two pieces of evidence give different months",
               "NOT_DETERMINABLE": "no evidence"},
    "never_evidence": ["the requested period (it is the target)"]}
TERMINAL_CLASSES = RULES["terminals"]["classes"]
PASTED = RULES["terminals"]["pasted"]
ASSUMPTION = re.compile(r"discount|premium|weight|multiple|growth|rate|ownership|haircut|assumption|factor|probability|%", re.I)
FUND = re.compile(r"invested|cost basis|investor cost|proceeds|distribution|commitment|capital call", re.I)


def junctions(m, path, period_end):
    """the 11.3 analysis on the model already read: proposed LP outputs and valuation junctions."""
    with model_reused(m) as an_mod:
        an = an_mod.analyze(path, period_end)
    F = an["lp_fields"]
    comp = (an.get("method_components") or [{}])[0]
    mf = comp.get("metric") if comp.get("metric") in F else next((f for f in ("ebitda_adjusted", "ebitda_reported", "revenue_ttm") if f in F), None)
    mult = "multiple_revenue" if mf == "revenue_ttm" else "multiple_ebitda"
    traced = any(i["id"] == "I1" and "traced" in i["detail"] for i in an["identities"])

    def status(f):
        r = F.get(f)
        if not r:
            return "NOT_DETERMINABLE"
        if r["status"] == "verified":
            return "PROVEN" if (traced or f not in ("enterprise_value", mf, mult)) else "SUPPORTED"
        return "SUPPORTED" if r["status"] in ("mapped", "chosen") and not r.get("alternatives") else "AMBIGUOUS"
    J = {}
    for jid, f in (("enterprise_value", "enterprise_value"), ("equity_value", "equity_value"), ("value_to_xpv", "investor_value"),
                   ("valuation_metric", mf), ("selected_multiple", mult)):
        r = F.get(f) if f else None
        J[jid] = {"cell": r["cell"] if r else None, "field": f, "status": status(f) if f else "NOT_DETERMINABLE",
                  "basis": r["basis"] if r else "not found", "alternatives": [a["cell"] for a in (r or {}).get("alternatives", [])][:4]}
    w = next((w for w in an["metric_windows"] if w["field"] == mf), None)
    if not w and F.get(mf):                                   # windows of the metric's own inputs (11.3 lists them once)
        up = m.upstream([AN.parse_ref_str(F[mf]["cell"])])
        ws_ = [x for x in an["metric_windows"] if x["months"] == 12 and AN.parse_ref_str(x["via"]) in up]
        if ws_ and len({x["last"] for x in ws_}) == 1:
            w = dict(ws_[0], python_sum_matches_excel=all(x.get("python_sum_matches_excel") is not False for x in ws_))
    J["metric_window"] = {"first": w["first"] if w else None, "last": w["last"] if w else None, "months": w["months"] if w else None,
                          "status": "PROVEN" if w and w.get("python_sum_matches_excel") else "SUPPORTED" if w else "NOT_DETERMINABLE"}
    J["method"] = {"variant": an["method"]["variant"], "status": "PROVEN" if traced else "SUPPORTED" if an["method"]["variant"] not in ("unknown", "not_found") else "NOT_DETERMINABLE"}
    roots = [AN.parse_ref_str(J[j]["cell"]) for j in ("enterprise_value", "equity_value", "value_to_xpv") if J[j]["cell"]]
    return J, roots, an


def _months(m, cells):
    lines = defaultdict(set)
    for c in cells:
        b = m.block_of_cell(c)
        if not b:
            return None
        lines[b[0]].add((b[1], b[2]))
    return lines


def period_evidence(m, g, k, cp, value_window, memo=None, depth=0):
    memo = {} if memo is None else memo
    if k in memo:
        return memo[k]
    ev, checks = [], ["block_membership", "date_value", "window_from_references", "single_source_month", "precedents_period", "declared_header"]
    v = m.v(k)
    b = m.block_of_cell(k)
    if isinstance(v, (datetime.date, datetime.datetime)):
        ev.append({"kind": "date_value", "authority": "authoritative", "period": f"{v.year}-{v.month:02d}"})
    if b:
        ev.append({"kind": "block_header", "authority": "authoritative", "period": ym_str(b[1]), "where": b[0].split("|", 1)[0]})
    n = g.nodes.get(k)
    ambiguous, lines = False, None
    if n and not b:
        prec = [p for p in g.precedents(k) if is_num(m.v(p))]
        lines = _months(m, prec) if prec else None
        if lines:
            if len(prec) == 1:
                (ln, ms), = lines.items()
                ev.append({"kind": "single_source_month", "authority": "authoritative", "period": ym_str(min(ms)[0])})
            else:
                ends = {ln: max(x[0] for x in ms) for ln, ms in lines.items()}
                over = n["flags"]["references_extracted"] == "OVER_APPROXIMATED"
                if len(set(ends.values())) > 1:
                    ambiguous = True
                elif over:
                    checks.append("value_matched_window")
                    vw = value_window(m, k)
                    if vw:
                        ev.append({"kind": "value_matched_window", "authority": "authoritative", "period": vw["last"],
                                   "window": f"{vw['first']}..{vw['last']}"})
                    else:
                        e_ = list(ends.values())[0]
                        ev.append({"kind": "referenced_block_range", "authority": "supporting", "period": ym_str(e_)})
                else:
                    ms = set().union(*lines.values())               # one or several block rows ending in the same month
                    st = max(x[1] for x in ms) or 1
                    lo, hi = min(x[0] for x in ms), max(x[0] for x in ms)
                    ev.append({"kind": "window_from_references", "authority": "authoritative", "period": ym_str(hi),
                               "window": f"{ym_str(lo - st + 1)}..{ym_str(hi)}", "months": hi - lo + st})
    if n and not b and not lines and depth < 150:
        prec = [p for p in g.precedents(k) if is_num(m.v(p)) or p in g.nodes]
        sub = [period_evidence(m, g, p, cp, value_window, memo, depth + 1) for p in prec]
        det = [x for x in sub if x["status"] in ("PROVEN", "SUPPORTED")]
        if any(x["status"] in ("AMBIGUOUS", "CONFLICTING") for x in sub) or len({x["period"] for x in det}) > 1:
            ambiguous = True
        elif det and any(x["status"] == "PROVEN" for x in det):
            ev.append({"kind": "precedents_period", "authority": "authoritative", "period": det[0]["period"],
                       "inputs": len(det)})
    if not b:
        ctx = cp.of(k)
        if ctx["period"] is None:                          # numeric dates in a header, e.g. 'TTM 6/30/2026'
            nd = numeric_header_date(m.col_header(k))
            if nd:
                ctx = dict(ctx, period=nd[0] * 12 + nd[1] - 1, source="column header (numeric date)")
        if ctx["period"] is not None:
            kind = "column_header" if "column" in (ctx["source"] or "") else "row_header" if "row" in (ctx["source"] or "") else "sheet_name"
            ev.append({"kind": kind, "authority": "supporting", "period": ym_str(ctx["period"]), "where": ctx["source"],
                       "column_role": ctx["role"]})
    bad = [e for e in ev if not (1990 <= int(e["period"][:4]) <= 2100)]
    if bad:                                                # an impossible year is never evidence (e.g. a small number read as a date)
        ev = [e for e in ev if e not in bad]
        checks.append(f"ignored {len(bad)} implausible date(s)")
    pers = {e["period"] for e in ev}
    conflicts = [e for e in ev if len(pers) > 1]
    if ambiguous:
        status, period = "AMBIGUOUS", None
    elif len(pers) > 1:
        status, period = "CONFLICTING", None
    elif not ev:
        status, period = "NOT_DETERMINABLE", None
    elif any(e["authority"] == "authoritative" for e in ev):
        status, period = "PROVEN", next(iter(pers))
    else:
        status, period = "SUPPORTED", next(iter(pers))
    role = next((e.get("column_role") for e in ev if e.get("column_role") and e["column_role"] != "current"), None)
    out = {"period": period, "status": status, "evidence": ev, "conflicts": [e["kind"] for e in conflicts], "checks_run": checks,
           "column_role": role or "current", "rules": PERIOD_RULES["version"]}
    memo[k] = out
    return out


def numeric_header_date(text):
    """'6/30/2026', '30/06/2026', '2026-06-30' inside a header -> (year, month); None when the day and month could be
    swapped and would give different months (never guessed)."""
    t = str(text or "")
    m_ = re.search(r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b", t)
    if m_:
        return int(m_.group(1)), int(m_.group(2))
    m_ = re.search(r"\b(\d{1,2})/(\d{1,2})/(\d{4})\b", t)
    if not m_:
        return None
    a, b_, y = int(m_.group(1)), int(m_.group(2)), int(m_.group(3))
    if a > 12 and 1 <= b_ <= 12:
        return y, b_
    if b_ > 12 and 1 <= a <= 12:
        return y, a
    return (y, a) if a == b_ and 1 <= a <= 12 else None


def terminal_class(m, g, k):
    n = g.nodes.get(k)
    if n and n["flags"]["location"] == "EXTERNAL":
        return "external-workbook value"
    if n:
        from workbook_model import addin_function
        if any(addin_function(f) for f in n["functions"]):
            return "add-in/provider value"
    v = m.v(k)
    if isinstance(v, (datetime.date, datetime.datetime)):
        return "date input"
    lab = f"{m.row_label(k)} | {m.col_header(k)}"
    b = m.block_of_cell(k)
    if b:
        L = b[0].split("|", 1)[1]
        if AN.words_hit(L, AN.ROLE_WORDS["adjustments"]["label_words"]) or any(AN.words_hit(L, w) for w in AN.WORDS["adjustment_categories"].values()):
            return "EBITDA adjustment input"
        return "typed balance-sheet data" if AN.words_hit(L, AN.WORDS["balance_words"]) else "typed financial data"
    if AN.words_hit(lab, AN.WORDS["fx_words"]):
        return "FX input"
    if AN.words_hit(lab, AN.ROLE_WORDS["cap_table"]["label_words"]) or AN.words_hit(k[0], AN.ROLE_WORDS["cap_table"]["sheet_words"]):
        return "cap-table/share data"
    if FUND.search(lab):
        return "investment/fund record"
    if AN.words_hit(lab, AN.ROLE_WORDS["comparables"]["label_words"]) or AN.words_hit(k[0], AN.ROLE_WORDS["comparables"]["sheet_words"]):
        return "market/comparable input"
    if AN.words_hit(lab, AN.ROLE_WORDS["adjustments"]["label_words"]):
        return "EBITDA adjustment input"
    if AN.words_hit(lab, AN.WORDS["balance_words"]):
        return "typed balance-sheet data"
    if ASSUMPTION.search(lab):
        return "valuation assumption"
    return "unresolved"


_terminal_class_raw = terminal_class


def numeric_header_date(text):
    """'6/30/2026', '30/06/2026', '2026-06-30' inside a header -> (year, month); None when the day and month could be
    swapped and would give different months (never guessed)."""
    t = str(text or "")
    m_ = re.search(r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b", t)
    if m_:
        return int(m_.group(1)), int(m_.group(2))
    m_ = re.search(r"\b(\d{1,2})/(\d{1,2})/(\d{4})\b", t)
    if not m_:
        return None
    a, b_, y = int(m_.group(1)), int(m_.group(2)), int(m_.group(3))
    if a > 12 and 1 <= b_ <= 12:
        return y, b_
    if b_ > 12 and 1 <= a <= 12:
        return y, a
    return (y, a) if a == b_ and 1 <= a <= 12 else None


def terminal_class(m, g, k):                                   # every class must be one the rules file lists
    c = _terminal_class_raw(m, g, k)
    if c not in TERMINAL_CLASSES:
        raise AssertionError(f"terminal class {c!r} is not in discovery_rules.json")
    return c


def distinctive(v):
    if not is_num(v) or v == 0 or isinstance(v, bool):
        return False
    s = f"{abs(v):.6e}".split("e")[0].replace(".", "").rstrip("0")
    return len(s) >= PASTED["min_significant_digits"]


def pasted_candidates(m, g, terminals, material, cap_each=PASTED["max_per_input"], cap_all=PASTED["max_total"]):
    """a typed input on the material graph whose distinctive value also comes out of an UNREACHED formula: a possible
    provenance match (SUPPORTED, for investigation) - never proof: equal numbers can be coincidences."""
    pool = defaultdict(list)
    for k in g.nodes:
        v = m.v(k)
        if k not in material and distinctive(v):
            pool[round(float(v), 6)].append(k)
    keys = sorted(pool)
    import bisect
    out = []
    for t in terminals:
        if t["kind"] != "cell" or t["class"] in ("date input",):
            continue
        k = AN.parse_ref_str(t["cell"])
        v = m.v(k)
        if not distinctive(v):
            continue
        tol = max(0.5, 1e-9 * abs(v)) if abs(v) >= 100 else 1e-9 * abs(v)
        i = bisect.bisect_left(keys, v - tol)
        hits = []
        while i < len(keys) and keys[i] <= v + tol:
            hits += pool[keys[i]]
            i += 1
        if hits:
            hits.sort()
            out.append({"input": t["cell"], "matches": [cell_text(*h) for h in hits[:cap_each]], "match_count": len(hits),
                        "status": "SUPPORTED", "meaning": "possible provenance match - investigate; not proof",
                        "unique": len(hits) == 1})
    out.sort(key=lambda x: (not x["unique"], x["match_count"], x["input"]))
    return out[:cap_all]


def terminals(m, g, material):
    """material inputs, grouped by series (a monthly row is ONE terminal), each with class and source evidence."""
    series, singles = defaultdict(list), []
    for k in sorted(material):
        if k in g.nodes:
            n = g.nodes[k]
            if n["flags"]["location"] == "EXTERNAL" or terminal_class(m, g, k) == "add-in/provider value":
                singles.append(k)
            continue
        if k in g.arr:
            continue
        v = m.v(k)
        if not (is_num(v) or isinstance(v, (datetime.date, datetime.datetime))):
            continue
        b = m.block_of_cell(k)
        (series[b[0]].append(k) if b else singles.append(k))
    out = []
    for line, ks in sorted(series.items()):
        out.append({"kind": "series", "series": line, "cell": cell_text(*ks[0]), "cells": len(ks), "class": terminal_class(m, g, ks[0]),
                    "source_evidence": "none in this milestone (carried in the approved workbook)"})
    for k in singles:
        c = terminal_class(m, g, k)
        n = g.nodes.get(k)
        src = ("external workbook " + ", ".join(sorted({str(r.get("link")) for r in n["refs"] if r["status"] == "EXTERNAL"}))
               if c == "external-workbook value" else "data provider (add-in)" if c == "add-in/provider value"
               else "none in this milestone (carried in the approved workbook)")
        out.append({"kind": "cell", "cell": cell_text(*k), "cells": 1, "class": c, "source_evidence": src})
    return out
