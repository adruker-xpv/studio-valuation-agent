# discovery/fund.py (build 11.7) - the ANCHOR: the value XPV reported for one company, read from the fund valuation workbook
# (the workbook the LP report is made from). Deterministic: the company's row is the closest name match in a name column;
# the value column is the "fair value / carrying value / valuation" column for the requested quarter (by its header), or
# the only such column; MOIC = value / invested capital is checked when both columns exist. --anchor-cell skips the search.
import re
from common.util import Stop, cell_text, col_let
from wbutil import similarity, norm_label
from periods import header_period

VALUE = re.compile(r"fair value|carrying value|valuation|reported value|value to xpv|xpv value|\bvalue\b", re.I)
NOT_VALUE = re.compile(r"invested|cost|moic|irr|multiple|change|prior|%|enterprise|equity|ownership", re.I)
INVESTED = re.compile(r"invested|capital deployed|cost basis|investment cost", re.I)
MOIC = re.compile(r"\bmoic\b|multiple of invested|gross multiple|tvpi", re.I)


def read_anchor(path, company=None, quarter_end=None, cell=None):
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True, read_only=True)
    if cell:
        sh, _, a = cell.rpartition("!")
        sh = sh.strip("'")
        if sh not in wb.sheetnames:
            raise Stop(f"the fund workbook has no sheet '{sh}'", "user_action")
        v = wb[sh][a].value
        if not isinstance(v, (int, float)) or isinstance(v, bool):
            raise Stop(f"the fund workbook cell {cell} does not hold a number", "user_action")
        return {"value": float(v), "source": "fund workbook (cell named by the user)", "self_check": "not available", "row_match": None}
    if not company:
        raise Stop("to read the fund workbook, give --company (the company's name as the fund workbook shows it) or --anchor-cell", "usage")
    want = (int(quarter_end[:4]), int(quarter_end[5:7])) if quarter_end else None
    best = None
    for ws in wb.worksheets:
        rows = [list(r) for r in ws.iter_rows(max_row=2000, values_only=True)]
        for hi, head in enumerate(rows[:60]):
            texts = {j: str(v) for j, v in enumerate(head) if isinstance(v, str) and v.strip()}
            vals = [j for j, t in texts.items() if VALUE.search(t) and not NOT_VALUE.search(t)]
            if not vals:
                continue
            dated = [j for j in vals if header_period(texts[j]) == want] if want else []
            undated = [j for j in vals if not header_period(texts[j])]
            vcol = dated[0] if len(dated) == 1 else undated[0] if not dated and len(undated) == 1 else None
            if vcol is None:
                continue
            inv = next((j for j, t in texts.items() if INVESTED.search(t)), None)
            mo = next((j for j, t in texts.items() if MOIC.search(t)), None)
            for ri in range(hi + 1, len(rows)):
                for j, v in enumerate(rows[ri][:max(vcol, 1)]):
                    if isinstance(v, str) and v.strip():
                        s = similarity(norm_label(v), norm_label(company))
                        if s >= 0.6 and (best is None or s > best[0]):
                            best = (s, ws.title, ri, vcol, inv, mo, rows, "by quarter header" if dated else "the only value column")
    if not best:
        raise Stop("could not find the company's row and a value column in the fund workbook: give --anchor-cell 'Sheet!Cell' "
                   "(the cell holding the company's reported value)", "user_action")
    s, sh, ri, vcol, inv, mo, rows, how = best
    row = rows[ri]
    val = row[vcol]
    if not isinstance(val, (int, float)) or isinstance(val, bool):
        raise Stop("the company's value cell in the fund workbook is not a number: give --anchor-cell", "user_action")
    check = "not available"
    if inv is not None and mo is not None and isinstance(row[inv], (int, float)) and isinstance(row[mo], (int, float)) and row[inv]:
        check = "holds" if abs(val / row[inv] - row[mo]) <= 0.01 else "fails"
    return {"value": float(val), "source": "fund workbook", "cell": cell_text(sh, ri + 1, vcol + 1), "row_match": round(s, 2),
            "value_column": how, "self_check": check}
