# periods.py (build 11.3, WP1) - request-anchored periods: prove PERIOD and MEANING before math.
#   cell_period(m, k)   the period a cell belongs to and its column role: its column header (a date in a header row or
#                       a 'Valuation date' row, or period text such as 'Mar-26', 'Q1 2026', 'Mar-26 Budget'), else a period
#                       down its row, else a period in its sheet name. Role: current (actual), budget, variance, prior_year, ytd
#   anchor(m, C, req_i) keeps the candidates of the requested month (or of no stated period); sets aside other periods
#                       and budget / variance / prior-year / YTD columns with a reason, so identities are only solved
#                       between cells of the requested quarter. A field with no candidate of that period keeps its
#                       candidates, flagged, so the conflict is reported rather than hidden
#   check_roles(...)    every dependency of the LP numbers checked by its role's own period rule (see RULES)
import bisect, datetime, re
from wbutil import (parse_period, parse_date_text, norm_label, ym_to_i, ym_str, ref_str, is_num, label_score, ref_data,
                    parse_ref_str, month_end)

FIELDS = ref_data("lp_fields.json")
VD_SYN = FIELDS["fields"]["valuation_date"]["synonyms"]
ROLE_WORDS = [("variance", {"variance", "var", "diff", "difference", "delta"}), ("budget", {"budget", "bud", "plan", "forecast", "fcst", "target"}),
              ("ytd", {"ytd", "fytd"}), ("prior_year", {"py", "ly"}), ("current", {"actual", "act", "current"})]
FILLER = {"ttm", "ltm", "last", "twelve", "month", "quarter", "fy", "valuation", "a", "at", "of", "value", "period", "end",
          "ended", "ending", "total", "x", "v", "the", "for", "date", "q"}
PERIOD_TOKEN = re.compile(r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\b|\b(19|20)\d{2}\b|\bq[1-4]\b|\bfy\d*\b|"
                          r"\b\d{1,2}\b", re.I)
RULES = {
    "lp_output": "the LP number is the requested quarter's cell (its column / row / sheet period is the valuation month)",
    "ttm_metric": "exactly 12 consecutive months ending at the valuation month, and Python's sum equals Excel's",
    "metric_window": "the metric's window ends at the valuation month",
    "monthly_history": "every month of the window is present in the monthly row (no gaps)",
    "period_end_balance": "the balance is taken at the valuation month",
    "valuation_assumption": "multiples, weights, ownership and FX are the requested quarter's (when a period is stated)",
    "investment_cash_flow": "dated investment records are on or before the valuation date",
    "pro_forma_adjustment": "acquisition / pro forma rows cover their own stated period inside the metric window",
}


def strip_period(text):
    return PERIOD_TOKEN.sub(" ", str(text or ""))


def header_role(text):
    """'Budget', 'Mar-26 Budget', 'Var %' -> role; 'Mar-26', 'Q1 2026', 'Actual' -> 'current'; a label -> None."""
    words = norm_label(strip_period(text)).split()
    if "prior" in words and "year" in words:
        return "prior_year"
    if "year" in words and "to" in words and "date" in words:
        return "ytd"
    found = [role for role, ws in ROLE_WORDS if set(words) & ws]
    rest = [w for w in words if w not in FILLER and not any(w in ws for _, ws in ROLE_WORDS)
            and w not in ("prior", "year", "to")]
    if rest:
        return None
    return found[0] if found else ("current" if PERIOD_TOKEN.search(str(text or "")) or not words else None)


def header_period(text):
    """'Mar-26', 'Q1 2026', 'Mar-26 Budget', 'Valuation as at 31 March 2026' -> (year, month); labels -> None."""
    t = str(text or "").strip()
    if not t or len(t) > 40:
        return None
    p = parse_period(t)
    if p:
        return p
    words = [w for w in norm_label(t).split() if not any(w in ws for _, ws in ROLE_WORDS)]
    p = parse_period(" ".join(words)) if words else None
    return p or (parse_date_text(t) if PERIOD_TOKEN.search(t) else None)


class CellPeriods:
    def __init__(self, m):
        self.m = m
        self._row_kind = {}
        self._cache = {}
        self._sheet = {s: parse_date_text(s) for s in m.sheets}

    def _header_row(self, sh, r):
        """a row holding 2+ dates or period texts is a header row."""
        key = (sh, r)
        if key not in self._row_kind:
            n = 0
            for c in self.m.rows[sh].get(r, []):
                v = self.m.v((sh, r, c))
                if isinstance(v, (datetime.datetime, datetime.date)) or (isinstance(v, str) and header_period(v)):
                    n += 1
                    if n >= 2:
                        break
            self._row_kind[key] = n >= 2
        return self._row_kind[key]

    def _date_is_header(self, k):
        return self._header_row(k[0], k[1]) or label_score(self.m.row_label(k), VD_SYN) >= 3

    def of(self, k):
        if k in self._cache:
            return self._cache[k]
        m, (sh, r, c) = self.m, k
        rows = m.head_col[sh].get(c, [])
        j = bisect.bisect_left(rows, r)
        period, role, src, seen = None, None, None, 0
        for idx in range(j - 1, -1, -1):
            hr = rows[idx]
            if r - hr > 60 or seen >= 4:
                break
            hk = (sh, hr, c)
            seen += 1
            v = m.v(hk)
            if isinstance(v, (datetime.datetime, datetime.date)):
                if not self._date_is_header(hk):
                    break
                if period is None:
                    period, src = ym_to_i((v.year, v.month)), f"column header {ref_str(hk)}"
                continue
            t = m.texts.get(hk)
            if not t:
                continue
            hrole, hp = header_role(t), header_period(t)
            if hrole is None and hp is None:
                break                                         # a label or title: we have left the header region
            if hp and period is None:
                period, src = ym_to_i(hp), f"column header {ref_str(hk)}"
            if hrole and hrole != "current" and role is None:
                role = hrole
        if period is None:
            cols = m.rows[sh].get(r, [])
            left = [cc for cc in cols if cc < c]
            if left:
                lk = (sh, r, left[0])
                v = m.v(lk)
                p = (v.year, v.month) if isinstance(v, (datetime.datetime, datetime.date)) else parse_period(v) if isinstance(v, str) else None
                if p:
                    period, src = ym_to_i(p), f"row header {ref_str(lk)}"
        if period is None and self._sheet.get(sh):
            period, src = ym_to_i(self._sheet[sh]), f"sheet name '{sh}'"
        out = {"period": period, "role": role or "current", "source": src}
        self._cache[k] = out
        return out


def anchor(m, C, req_i, cp=None):
    """-> (candidates, set_aside). Budget / variance / prior-year / YTD columns are always set aside; other periods only
    when a valuation date was requested."""
    cp = cp or CellPeriods(m)
    out, aside = {}, {}
    for field, cands in C.items():
        kind = FIELDS["fields"].get(field, {}).get("kind")
        keep, wrong = [], []
        for c in cands:
            if kind == "date" and isinstance(c["value"], (datetime.datetime, datetime.date)):
                ctx = {"period": ym_to_i((c["value"].year, c["value"].month)), "role": "current", "source": f"date value {ref_str(c['key'])}"}
            else:
                ctx = cp.of(c["key"])
            c = dict(c, period=ym_str(ctx["period"]) if ctx["period"] is not None else None, period_source=ctx["source"],
                     column_role=ctx["role"])
            if ctx["role"] != "current":
                wrong.append(dict(c, reason="wrong_column_role"))
            elif req_i is not None and ctx["period"] is not None and ctx["period"] != req_i:
                wrong.append(dict(c, reason="wrong_period"))
            elif req_i is not None and ctx["period"] == req_i:
                keep.append(dict(c, score=c["score"] + 2.0, period_match=True))
            else:
                keep.append(c)
        keep.sort(key=lambda x: (-x["score"], x["key"]))
        if keep:
            out[field] = keep
            if wrong:
                aside[field] = wrong
        else:
            out[field] = [dict(c, period_conflict=c["reason"]) for c in wrong]
    return out, aside


def _month_of_source(m, cp, k):
    """the month a value is taken at: its own monthly-block month, else the block month of a direct precedent, else its
    column / row / sheet period."""
    b = m.block_of_cell(k)
    if b:
        return b[1], f"monthly row {b[0].split('|', 1)[1]}"
    for p in sorted(m.precedents(k)):
        bp = m.block_of_cell(p)
        if bp:
            return bp[1], f"monthly row {bp[0].split('|', 1)[1]} ({ref_str(p)})"
    ctx = cp.of(k)
    return ctx["period"], ctx["source"]


PRO_FORMA = re.compile(r"pro\s*forma|proforma|pre[\s-]*acquisition|acquired|acquisition|run[\s-]*rate", re.I)
BEFORE = re.compile(r"\b(before|until|to|through|prior to)\s+([A-Za-z]{3,9}\.?\s*\d{2,4})", re.I)
FROM = re.compile(r"\b(from|after|since)\s+([A-Za-z]{3,9}\.?\s*\d{2,4})", re.I)


def _pro_forma(m, add, row, lab, sheet, need):
    """an acquisition / pro forma row: its non-zero months must lie inside its own stated period ('before Jul 2025')."""
    nz = sorted(i for i in need if row["cells"].get(i) is not None and is_num(m.v(row["cells"][i])) and m.v(row["cells"][i]) != 0)
    b, f = BEFORE.search(lab), FROM.search(lab)
    cut_b = parse_date_text(b.group(2)) if b else None
    cut_f = parse_date_text(f.group(2)) if f else None
    span = f"non-zero in {ym_str(nz[0])}..{ym_str(nz[-1])}" if nz else "zero in every window month"
    if not cut_b and not cut_f:
        add("pro_forma_adjustment", lab, sheet, "ok", span, "no stated period in its label: confirm it at review", "its stated period")
        return
    lo = ym_to_i(cut_f) if cut_f else None
    hi = ym_to_i(cut_b) - (1 if b and b.group(1).lower() in ("before", "prior to") else 0) if cut_b else None
    outside = [i for i in nz if (hi is not None and i > hi) or (lo is not None and i < lo)]
    stated = (f"{ym_str(lo)}" if lo is not None else "") + ".." + (f"{ym_str(hi)}" if hi is not None else "")
    add("pro_forma_adjustment", lab, sheet, "outside_stated_period" if outside else "ok", span,
        ("values outside its stated period: " + ", ".join(ym_str(i) for i in outside[:4])) if outside else "inside its stated period", stated)


def check_roles(m, F, win_rows, block_rows, items, val_i, cp=None):
    """-> (results, findings). Every result: role, subject, cell, rule, expected, got, result, detail."""
    cp = cp or CellPeriods(m)
    res, fnd = [], []
    if val_i is None:
        return res, fnd
    want = ym_str(val_i)

    def add(role, subject, cell, result, got=None, detail="", expected=None):
        res.append({"role": role, "subject": subject, "cell": cell, "rule": RULES[role], "expected": expected or want,
                    "got": got, "result": result, "detail": detail})
        if result in ("wrong_period", "missing_months", "future_dated", "outside_stated_period"):
            fnd.append({"check": "P", "kind": result, "role": role, "cell": cell, "expected": expected or want, "got": got,
                        "subject": subject,
                        "text": f"[{role.replace('_', ' ')}] {subject.replace('_', ' ')}"
                                + (f" at {cell}" if cell else "") + f": expected {expected or want}, got {got}"
                                + (f" ({detail})" if detail else "")})
    for f in ("enterprise_value", "equity_value", "investor_value", "investor_value_local", "moic"):
        if f not in F:
            continue
        k = F[f]["key"]
        ctx = cp.of(k)
        if ctx["role"] != "current":
            add("lp_output", f, ref_str(k), "wrong_period", ctx["role"], f"a {ctx['role'].replace('_', ' ')} column ({ctx['source']})")
        elif ctx["period"] is None:
            add("lp_output", f, ref_str(k), "not_determinable", None, "no period header; checked through its inputs")
        else:
            add("lp_output", f, ref_str(k), "ok" if ctx["period"] == val_i else "wrong_period", ym_str(ctx["period"]), ctx["source"])
    seen = set()
    rows_by_line = {r["line"]: r for r in block_rows}
    for w in win_rows:
        if (w["field"], w["via"]) in seen:
            continue
        seen.add((w["field"], w["via"]))
        role = "ttm_metric" if w["months"] == 12 else "metric_window"
        got = f"{w['first']}..{w['last']}"
        exp = f"{ym_str(val_i - 11)}..{want}" if role == "ttm_metric" else f"..{want}"
        if w["_last_i"] != val_i:
            add(role, w["field"], w["via"], "wrong_period", got, w.get("described", ""), exp)
        elif w.get("python_sum_matches_excel") is False:
            add(role, w["field"], w["via"], "formula_mismatch", got, "Python's sum differs from Excel's saved value", exp)
        else:
            add(role, w["field"], w["via"], "ok", got, w.get("described", ""), exp)
        if w["_last_i"] == val_i:
            for line in w.get("lines", []):
                row = rows_by_line.get(line)
                if not row:
                    continue
                st = row.get("step", 1) or 1
                need = [val_i - j * st for j in range(w["months"] // st)]
                miss = [ym_str(i) for i in need if row["cells"].get(i) is None or not is_num(m.v(row["cells"][i]))]
                key = ("hist", line)
                if key in seen:
                    continue
                seen.add(key)
                lab = line.split("|", 1)[1]
                if PRO_FORMA.search(lab):
                    _pro_forma(m, add, row, lab, line.split("|", 1)[0], need)
                    continue
                add("monthly_history", lab, line.split("|", 1)[0], "missing_months" if miss else "ok",
                    f"{len(need) - len(miss)} of {len(need)} months", ("missing " + ", ".join(sorted(set(miss))[:6])) if miss else "",
                    f"{len(need)} of {len(need)} months")
    for f in ("cash", "debt", "net_debt"):
        if f not in F:
            continue
        k = F[f]["key"]
        mi, src = _month_of_source(m, cp, k)
        if mi is None:
            add("period_end_balance", f, ref_str(k), "not_determinable", None, "no month found for the balance")
        else:
            add("period_end_balance", f, ref_str(k), "ok" if mi == val_i else "wrong_period", ym_str(mi), src)
    for f in ("multiple_ebitda", "multiple_revenue", "weight_revenue", "weight_ebitda", "ownership", "fx_rate"):
        if f not in F:
            continue
        k = F[f]["key"]
        ctx = cp.of(k)
        if ctx["role"] != "current":
            add("valuation_assumption", f, ref_str(k), "wrong_period", ctx["role"], ctx["source"])
        elif ctx["period"] is None:
            add("valuation_assumption", f, ref_str(k), "ok", "no period stated", "carried assumption")
        else:
            add("valuation_assumption", f, ref_str(k), "ok" if ctx["period"] == val_i else "wrong_period", ym_str(ctx["period"]), ctx["source"])
    end = datetime.date.fromisoformat(month_end(val_i))
    for i in items:
        if i["class"] == "date":
            try:
                d = datetime.date.fromisoformat(str(i["value"])[:10])
            except ValueError:
                continue
            if d > end and label_score(i["label"], VD_SYN) < 3:
                add("investment_cash_flow", i["label"] or "date", i["cell"], "future_dated", d.isoformat(),
                    "a dated record after the valuation date", f"on or before {end.isoformat()}")
    return res, fnd


def summary(results):
    """role -> {result: count}"""
    out = {}
    for r in results:
        out.setdefault(r["role"], {}).setdefault(r["result"], 0)
        out[r["role"]][r["result"]] += 1
    return out
