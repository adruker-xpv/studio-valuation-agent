# catalog.py (build 11.1) - what a file is and how a valuation is built, from the files themselves.
#   classify_file      valuation workbook / statement pack / monthly summary / LP report / cap table / document
#   company_from_filename, bare_name   names for matching files to a company
#   features_of, pattern_of            structure of a valuation (parts, features such as pro forma, acquisitions,
#                                      waterfalls, linked workbooks) - structure only, never numbers
# No stored archive: SharePoint and the knowledge sources are the record of files; each company's map, facts and
# approvals live in its company file.
import os, re
from wbutil import stable_name, parse_date_text, norm_label

FEATURE_WORDS = {
    "acquisition": ["acquisition", "acquired", "add on", "add-on", "purchase price", "earn out", "earnout", "pre acquisition",
                    "closing date", "target company", "bolt on", "tuck in"],
    "waterfall": ["waterfall", "liquidation preference", "participation", "seniority", "preferred return", "hurdle"],
    "pro_forma": ["pro forma", "proforma", "consolidated", "combined"],
    "debt_facility": ["term loan", "revolver", "credit facility", "line of credit", "senior debt", "subordinated"],
    "fx": ["exchange rate", "fx rate", "cad usd", "usd cad"],
}
NAME_NOISE = re.compile(r"\b(valuation|valuations|workbook|model|draft|final|approved|copy|fmv|fair|value|v\d+|rev\d*|"
                        r"financial|financials|statement|statements|monthly|backup|detailed|pack|fs|report|management|accounts|"
                        r"q[1-4]|fy\d*|20\d{2}|\d{1,2}|jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec|january|february|"
                        r"march|april|june|july|august|september|october|november|december)\b", re.I)


def company_from_filename(name):
    """'2026_Q2_-_Metron_Farnier_Valuation__30_Jun_2026__v2.xlsx' -> 'Metron Farnier'."""
    stem = re.sub(r"[_\-\.]+", " ", os.path.splitext(stable_name(name))[0])
    words = NAME_NOISE.sub(" ", stem).split()
    return " ".join(words) or stem


def features_of(model):
    out = {}
    for (sh, r, c), t in sorted(model.texts.items()):
        for f, words in FEATURE_WORDS.items():
            L = f" {norm_label(t)} "
            if any(f" {norm_label(w)} " in L for w in words):
                lst = out.setdefault(f, [])
                if len(lst) < 6:
                    lst.append({"sheet": sh, "label": t[:60]})
    for s in model.sheets:
        for f, words in FEATURE_WORDS.items():
            if any(f" {norm_label(w)} " in f" {norm_label(s)} " for w in words):
                lst = out.setdefault(f, [])
                if not any(x.get("sheet") == s and x.get("label") == "(sheet name)" for x in lst):
                    lst.insert(0, {"sheet": s, "label": "(sheet name)"})
    return out


def pattern_of(rec):
    """structure only - no numbers."""
    b = rec.get("build") or {}
    parts = [{"sheet": p["sheet"], "role": p["role"], "inputs": [i["class"] for i in p.get("inputs", [])],
              "per_quarter_sheet": p.get("per_quarter_sheet", False)} for p in b.get("parts", [])]
    dg = rec.get("diagnostics", {})
    roles = {p["role"] for p in parts}
    return {"method": (rec.get("method") or {}).get("type"),
            "components": [{k: c.get(k) for k in ("metric", "multiple_cell", "metric_cell", "weight", "period_basis")}
                           for c in (rec.get("method") or {}).get("components", [])],
            "metric_convention": {k: (rec.get("period") or {}).get(k) for k in ("windows", "alignment", "lag_months")},
            "parts": parts, "features": rec.get("features", {}),
            "flags": {"pro_forma": "pro_forma" in roles, "multi_entity": sum(1 for p in parts if p["role"] == "financials") >= 2,
                      "cap_table": "cap_table" in roles, "add_ins": bool(dg.get("add_ins", {}).get("count")),
                      "linked_workbooks": bool(dg.get("external_links", {}).get("count")),
                      "quarter_named_sheets": any(p["per_quarter_sheet"] for p in parts),
                      "acquisition": bool(rec.get("features", {}).get("acquisition")),
                      "quarterly_columns": any("quarterly" in d for d in dg.get("period_structures", {}).get("detail", []))},
            "linked_workbooks": dg.get("external_links", {}).get("linked_workbooks", []),
            "labels": {f: v.get("label") for f, v in (rec.get("lp_fields") or {}).get("fields", {}).items()}}


def bare_name(name):
    n = os.path.splitext(stable_name(str(name).replace("%20", " ")))[0].lower()
    return re.sub(r"[^a-z0-9]+", "", n)


def classify_file(path):
    """what a file is, from its name and content: valuation workbook, statement pack, monthly summary, LP report,
    cap table, or document."""
    nm = os.path.basename(path).lower().replace("_", " ")
    if re.search(r"\blp\b|lp report|lpreport|investor report|partners report|quarterly report to", nm):
        return {"kind": "LP report", "period": None, "entity": None}
    out = _classify(path)
    if re.search(r"monthly summar|summary", nm) and out["kind"] in ("statement pack", "supporting workbook (classify with the analyst)"):
        out["kind"] = "monthly summary"
    return out


def _classify(path):
    ext = os.path.splitext(path)[1].lower()
    if ext not in (".xlsx", ".xlsm", ".csv"):
        return {"kind": "document (evidence; numbers used only after the analyst says where they go)", "period": None, "entity": None}
    if ext == ".csv":
        import statements as ST
        idx = ST.index_files([path])
        f = idx["files"][0]
        return {"kind": "statement pack", "period": f["statement_period"], "entity": ST.entity_of(path)}
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=False)
    formulas, texts = 0, []
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                v = c.value
                if isinstance(v, str):
                    if v.startswith("="):
                        formulas += 1
                    elif len(texts) < 4000:
                        texts.append(v.lower())
    names = " ".join(s.lower() for s in wb.sheetnames)
    wb.close()
    blob = " | ".join(texts) + " | " + names
    has = lambda *w: any(x in blob for x in w)
    if formulas >= 20 and has("enterprise value", "equity value", "ev/ebitda", "valuation"):
        p = parse_date_text(os.path.splitext(os.path.basename(path))[0])
        return {"kind": "valuation workbook", "period": f"{p[0]}-{p[1]:02d}" if p else None, "entity": None}
    if has("fully diluted", "shares outstanding", "cap table", "capitalization", "liquidation preference") and not has("revenue"):
        return {"kind": "cap table", "period": None, "entity": None}
    import statements as ST
    idx = ST.index_files([path])
    f = idx["files"][0]
    if f["statement_period"] and has("revenue", "sales", "cash", "ebitda", "net income", "total assets"):
        return {"kind": "statement pack", "period": f["statement_period"], "entity": ST.entity_of(path)}
    return {"kind": "supporting workbook (classify with the analyst)", "period": f.get("statement_period"), "entity": None}


