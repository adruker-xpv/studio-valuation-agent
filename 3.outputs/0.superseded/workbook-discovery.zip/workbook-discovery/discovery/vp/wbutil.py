# wbutil.py (build 11.3) - shared helpers: determinism, hashing, cell references, labels, periods, files, SharePoint lines.
# Standard library + openpyxl only.
import os, re, glob, json, hashlib, datetime, shutil

VERSION = "11.3.0"
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
UPLOADS = "/app/uploads"
CREATED = "/app/created"
LIMIT = 4_000_000                     # largest file the SharePoint Create file tool accepts inline
UPLOAD_SUFFIX = re.compile(r"-[0-9a-f]{8}(?=\.[A-Za-z0-9]+$)")
COPY_SUFFIX = re.compile(r"(?:_\d{1,2}| \(\d{1,2}\))(?=\.[A-Za-z0-9]+$)")
LEGAL_SUFFIX = {"inc", "ltd", "limited", "llc", "lp", "llp", "corp", "corporation", "co", "company", "technologies",
                "technology", "holdings", "holding", "group", "plc", "gmbh", "ag", "sa", "bv", "ulc"}


# ------------------------------------------------------------------ determinism and hashing
def now():
    """The only clock. VALUATION_NOW (ISO date or datetime) makes runs reproducible."""
    s = os.environ.get("VALUATION_NOW")
    if s:
        return datetime.datetime.fromisoformat(s)
    return datetime.datetime.now().replace(microsecond=0)


def today():
    return now().date().isoformat()


def canon(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def sha(obj, n=64):
    return hashlib.sha256(canon(obj).encode("utf-8")).hexdigest()[:n]


def short_id(prefix, obj):
    return f"{prefix}-{sha(obj, 8)}"


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def dump(obj, path):
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=1, sort_keys=True, ensure_ascii=False, default=str)
    return path


def load_json(path, default=None):
    if path and os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    return default


def ref_data(name):
    return load_json(os.path.join(PKG, "references", name))


# ------------------------------------------------------------------ cell references
STR_LIT = re.compile(r'"[^"]*"')
SHEET_PFX = r"(?:(?:'((?:[^']|'')+)'|([A-Za-z_][A-Za-z0-9_.]*))!)?"
REF = re.compile(r"(?<![A-Za-z0-9_.\]])" + SHEET_PFX + r"(\$?)([A-Z]{1,3})(\$?)([0-9]+)"
                 r"(?::(\$?)([A-Z]{1,3})(\$?)([0-9]+))?(?![A-Za-z0-9_(])")
COLREF = re.compile(r"(?<![A-Za-z0-9_.$])" + SHEET_PFX + r"\$?([A-Z]{1,3}):\$?([A-Z]{1,3})(?![A-Za-z0-9_(])")
ROWREF = re.compile(r"(?<![A-Za-z0-9_.$:])" + SHEET_PFX + r"\$?([0-9]+):\$?([0-9]+)(?![A-Za-z0-9_(:])")
EXTERNAL = re.compile(r"\[\d+\]|\[[^\]]+\.xls[xmb]?\]", re.I)
FUNC = re.compile(r"([A-Za-z_][A-Za-z0-9_.]*)\s*\(")
NAME_TOKEN = re.compile(r"(?<![A-Za-z0-9_.!$'\]])([A-Za-z_\\][A-Za-z0-9_.]*)(?![A-Za-z0-9_.!(\[])")
MAX_ROW, MAX_COL = 1048576, 16384


def col_idx(s):
    n = 0
    for ch in s:
        n = n * 26 + (ord(ch) - 64)
    return n


def col_let(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def quote_sheet(sheet):
    return f"'{sheet}'" if re.search(r"[^A-Za-z0-9_]", sheet) else sheet


def ref_str(key):
    sheet, r, c = key
    return f"{quote_sheet(sheet)}!{col_let(c)}{r}"


def range_str(sheet, r1, c1, r2, c2):
    a = f"{col_let(c1)}{r1}"
    b = f"{col_let(c2)}{r2}"
    return f"{quote_sheet(sheet)}!{a}" + (f":{b}" if (r1, c1) != (r2, c2) else "")


def parse_ref_str(s):
    """'Sheet!B5', "'My Sheet'!B5" -> ('My Sheet', 5, 2)."""
    s = s.strip()
    sheet, _, addr = s.rpartition("!")
    sheet = sheet.strip()
    if sheet.startswith("'") and sheet.endswith("'"):
        sheet = sheet[1:-1].replace("''", "'")
    m = re.fullmatch(r"\$?([A-Z]{1,3})\$?([0-9]+)", addr.strip().upper())
    if not m:
        raise ValueError(f"not a cell reference: {s!r}")
    return (sheet, int(m.group(2)), col_idx(m.group(1)))


def clean_formula(formula):
    return STR_LIT.sub('""', formula or "")


def parse_refs(formula, cur_sheet):
    """-> [(sheet, r1, c1, r2, c2)] for single cells, ranges, whole columns and whole rows (external refs skipped)."""
    out, clean = [], clean_formula(formula)
    if EXTERNAL.search(clean):
        clean = re.sub(r"'?\[[^\]]+\][^!]*'?![$A-Z0-9:]+", "", clean)
    for m in REF.finditer(clean):
        sheet = (m.group(1) or m.group(2) or cur_sheet).replace("''", "'")
        c1, r1 = col_idx(m.group(4)), int(m.group(6))
        c2, r2 = (col_idx(m.group(8)), int(m.group(10))) if m.group(8) else (c1, r1)
        out.append((sheet, min(r1, r2), min(c1, c2), max(r1, r2), max(c1, c2)))
    for m in COLREF.finditer(clean):
        sheet = (m.group(1) or m.group(2) or cur_sheet).replace("''", "'")
        c1, c2 = sorted((col_idx(m.group(3)), col_idx(m.group(4))))
        out.append((sheet, 1, c1, MAX_ROW, c2))
    for m in ROWREF.finditer(clean):
        sheet = (m.group(1) or m.group(2) or cur_sheet).replace("''", "'")
        r1, r2 = sorted((int(m.group(3)), int(m.group(4))))
        out.append((sheet, r1, 1, r2, MAX_COL))
    return out


QUOTED_SHEET = re.compile(r"'(?:[^']|'')*'!")


def func_names(formula):
    """function names called by a formula. Quoted sheet names are removed first: in ='Pro Forma (Q2)'!A1 the
    "(Q2)" is part of a sheet name, not a function call."""
    return [f.upper() for f in FUNC.findall(QUOTED_SHEET.sub("S!", clean_formula(formula)))]


def name_tokens(formula):
    """identifiers that could be defined names (not functions, not cell refs, not sheet prefixes)."""
    clean = REF.sub(" ", QUOTED_SHEET.sub("S!", clean_formula(formula)))
    return {t for t in NAME_TOKEN.findall(clean) if not re.fullmatch(r"(TRUE|FALSE)", t, re.I)}


def is_external(formula):
    return bool(EXTERNAL.search(clean_formula(formula)))


def is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def is_error_value(v):
    return isinstance(v, str) and v.startswith("#") and (v.endswith("!") or v.endswith("?") or v.isupper() or "/" in v)


# ------------------------------------------------------------------ labels
def norm_label(s):
    """lowercase, '&' -> 'and', punctuation removed, simple plurals removed ('Revenues' == 'Revenue')."""
    s = str(s or "").lower().replace("&", " and ")
    s = re.sub(r"[^a-z0-9]+", " ", s)
    words = [w[:-1] if len(w) > 3 and w.endswith("s") and not w.endswith("ss") else w for w in s.split()]
    return " ".join(words)


def label_score(label, synonyms, exclude=()):
    """0..10: 10 exact, 4-6 whole-phrase containment, 0 no match or excluded."""
    L = norm_label(label)
    if not L:
        return 0.0
    for x in exclude:
        nx = norm_label(x)
        if nx and f" {nx} " in f" {L} ":
            return 0.0
    best = 0.0
    lw = L.split()
    for s in synonyms:
        S = norm_label(s)
        if not S:
            continue
        if L == S:
            return 10.0
        if f" {S} " in f" {L} ":
            best = max(best, max(3.0, 6.0 - 0.5 * (len(lw) - len(S.split()))))
    return best


def similarity(a, b):
    A, B = set(norm_label(a).split()), set(norm_label(b).split())
    return len(A & B) / len(A | B) if A and B else 0.0


# ------------------------------------------------------------------ periods
_MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
_MONTH_WORDS = ("january|february|march|april|may|june|july|august|september|october|november|december|"
                "jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec")


def _yr(y):
    y = int(y)
    return y + 2000 if y < 100 else y


def ym_to_i(ym):
    return ym[0] * 12 + ym[1] - 1


def i_to_ym(i):
    return (i // 12, i % 12 + 1)


def ym_str(i):
    y, m = i_to_ym(i)
    return f"{y}-{m:02d}"


def month_end(i):
    y, m = i_to_ym(i + 1)
    return (datetime.date(y, m, 1) - datetime.timedelta(days=1)).isoformat()


def parse_period(h):
    """Header -> (year, month) of the period END, or None. ISO dates, 'Jun-26', 'June 2026', '2026-06', '06/2026',
    'Q2-26', 'FY2026'. Totals, YTD, budget, variance -> None."""
    if h is None:
        return None
    if isinstance(h, (datetime.datetime, datetime.date)):
        return (h.year, h.month)
    s = str(h).strip().lower()
    if not s or any(w in s for w in ("ytd", "total", "budget", "forecast", "plan", "var", "%")):
        return None
    m = re.match(r"^(\d{4})-(\d{2})(?:-(\d{2}))?", s)
    if m:
        return (int(m.group(1)), int(m.group(2)))
    m = re.match(r"^([a-z]{3})[a-z]*[\s\-_']*(\d{2}|\d{4})$", s)
    if m and m.group(1) in _MONTHS:
        return (_yr(m.group(2)), _MONTHS[m.group(1)])
    m = re.match(r"^(\d{1,2})[/\-](\d{4})$", s)
    if m and 1 <= int(m.group(1)) <= 12:
        return (int(m.group(2)), int(m.group(1)))
    m = re.match(r"^q([1-4])[\s\-_']*(?:fy)?(\d{2}|\d{4})$", s) or re.match(r"^(?:fy)?(\d{2}|\d{4})[\s\-_']*q([1-4])$", s)
    if m:
        q, y = (m.group(1), m.group(2)) if s.startswith("q") else (m.group(2), m.group(1))
        return (_yr(y), int(q) * 3)
    m = re.match(r"^fy[\s\-_']*(\d{2}|\d{4})$", s)
    if m:
        return (_yr(m.group(1)), 12)
    return None


def parse_date_text(s):
    """Free text -> (year, month) or None: 'June 30, 2026', '30 June 2026', 'June_30__2026', '2026-06-30', 'Q2 2026'."""
    if s is None:
        return None
    if isinstance(s, (datetime.datetime, datetime.date)):
        return (s.year, s.month)
    t = re.sub(r"[_\.]+", " ", str(s).lower())
    m = re.search(r"(20\d{2})[-/ ]?(0[1-9]|1[0-2])(?:[-/ ]?(0[1-9]|[12]\d|3[01]))?(?!\d)", t)
    if m:
        return (int(m.group(1)), int(m.group(2)))
    m = re.search(rf"\b({_MONTH_WORDS})\b[\s,\-]*(?:\d{{1,2}}(?:st|nd|rd|th)?[\s,\-]+)?(20\d{{2}}|\d{{2}})\b", t)
    if m:
        return (_yr(m.group(2)), _MONTHS[m.group(1)[:3]])
    m = re.search(rf"\b\d{{1,2}}(?:st|nd|rd|th)?[\s\-]+({_MONTH_WORDS})\b[\s,\-]+(20\d{{2}}|\d{{2}})\b", t)
    if m:
        return (_yr(m.group(2)), _MONTHS[m.group(1)[:3]])
    m = re.search(rf"\b(20\d{{2}})[\s,\-]+({_MONTH_WORDS})\b", t)
    if m:
        return (int(m.group(1)), _MONTHS[m.group(2)[:3]])
    m = re.search(r"\bq([1-4])[\s\-]*(20\d{2}|\d{2})\b", t)
    if m:
        return (_yr(m.group(2)), int(m.group(1)) * 3)
    m = re.search(r"\b(20\d{2})[\s\-]*q([1-4])\b", t)
    if m:
        return (int(m.group(1)), int(m.group(2)) * 3)
    return None


def column_role(header_text):
    h = " " + re.sub(r"[^a-z0-9%]+", " ", str(header_text).lower()) + " "
    if re.search(r" (ytd|year to date|cumulative|fytd) ", h):
        return "ytd"
    if re.search(r" (budget|bud|plan|forecast|fcst|target) ", h):
        return "budget"
    if re.search(r" (var|variance|diff|difference|change) |%", h):
        return "variance"
    if re.search(r" (prior year|last year|py|ly) ", h):
        return "prior_year"
    return "current"


def quarter_of(i):
    y, m = i_to_ym(i)
    return f"{y}-Q{(m - 1) // 3 + 1}"


# ------------------------------------------------------------------ company id and files
def company_slug(name):
    words = re.findall(r"[A-Za-z0-9]+", name or "")
    core = [w for w in words if w.lower() not in LEGAL_SUFFIX] or words
    return "-".join(w.lower() for w in core)[:40] or "company"


def stable_name(path):
    return COPY_SUFFIX.sub("", UPLOAD_SUFFIX.sub("", os.path.basename(path)))


def find_file(name, dirs):
    """Files are passed by NAME. A chat upload may carry '-1a2b3c4d', a SharePoint download '_1' or ' (1)'.
    Exact name first, then the stable name; the newest match wins."""
    if not name:
        return None
    base = os.path.basename(name)
    files = [f for d in dirs if d and os.path.isdir(d)
             for f in glob.glob(os.path.join(d, "**", "*"), recursive=True)
             if os.path.isfile(f) and "/skills/" not in f.replace(os.sep, "/")]
    for test in (lambda f: os.path.basename(f) == base, lambda f: stable_name(f) == stable_name(base)):
        hits = [f for f in files if test(f)]
        if hits:
            return max(hits, key=lambda f: (os.path.getmtime(f), f))
    return None


def resolve(name, extra_dirs=(), broad=True):
    """a file passed by name: this run's folders first; then (broad) anywhere under /app, where files fetched from
    knowledge land - never other test runs. Company files are never looked up broadly."""
    if not name:
        return None
    if os.path.exists(name):
        return os.path.abspath(name)
    hit = find_file(name, [*extra_dirs, CREATED, UPLOADS, os.getcwd()])
    if hit or not broad or not os.path.isdir("/app"):
        return hit
    hit = find_file(name, ["/app"])
    return hit if hit and "_selftest_" not in hit else None


def upload_root():
    return os.environ.get("VALUATION_UPLOAD_ROOT") or (CREATED if os.path.isdir("/app") else None)


def sp_lines(company_id, sub, paths, folder=True):
    """Exact SharePoint tool inputs, so the agent copies them instead of working them out."""
    rel = f"Valuations/{company_id}/{sub}".rstrip("/")
    out = [f"SHAREPOINT: Create new folder | library: Documents | path: {rel}  (if it already exists, continue)"] if folder else []
    root = upload_root()
    for p in paths:
        if not p or not os.path.exists(p):
            continue
        b, n = os.path.getsize(p), os.path.basename(p)
        if b >= LIMIT:
            out.append(f"SHAREPOINT: SKIP {n} ({b / 1e6:.1f} MB is over the 4 MB tool limit) - give it to the user as a download")
        elif root and not os.path.abspath(p).startswith(root.rstrip("/") + "/"):
            out.append(f"SHAREPOINT: SKIP {n} - not in {root}; give it to the user as a download")
        else:
            out.append(f"SHAREPOINT: Create file | folderPath: /Shared Documents/{rel} | name: {n} | body: {os.path.abspath(p)}")
    return out


def copy_into(src, dest_dir, name=None):
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, name or stable_name(src))
    if os.path.abspath(src) != os.path.abspath(dest):
        shutil.copyfile(src, dest)
    return dest
