# company_file.py (build 11) - <company_id>_company.zip: the company's standing data, written deterministically.
#   parts      JSON files (profile, lp_map, inputs, blocks, silver_monthly, line_map, liveness, assumptions, ...)
#   ledger     evidence_ledger.jsonl - append-only events, each hashing the previous one (tampering is detected)
#   manifest   bundle_manifest.json - SHA-256 of every other file, written last, verified on every open
import io, json, zipfile, hashlib
from wbutil import canon, sha, now, VERSION

ZIP_DATE = (1980, 1, 1, 0, 0, 0)


class IntegrityError(Exception):
    pass


def _bytes(obj):
    return (json.dumps(obj, indent=1, sort_keys=True, ensure_ascii=False, default=str) + "\n").encode("utf-8")


def ledger_append(ledger, event, by=None, data=None):
    prev = ledger[-1]["hash"] if ledger else "0" * 64
    e = {"seq": len(ledger) + 1, "at": now().isoformat(), "event": event, "by": by, "data": data or {}, "prev": prev,
         "package_version": VERSION}
    e["hash"] = hashlib.sha256(canon(e).encode("utf-8")).hexdigest()
    return ledger + [e]


def verify_ledger(ledger):
    prev = "0" * 64
    for e in ledger:
        body = {k: v for k, v in e.items() if k != "hash"}
        if e.get("prev") != prev or hashlib.sha256(canon(body).encode("utf-8")).hexdigest() != e.get("hash"):
            raise IntegrityError(f"evidence ledger event {e.get('seq')} ({e.get('event')}) was changed or is out of order")
        prev = e["hash"]


def write(path, parts, ledger):
    files = {f"{name}.json": _bytes(obj) for name, obj in parts.items()}
    files["evidence_ledger.jsonl"] = ("".join(json.dumps(e, sort_keys=True, ensure_ascii=False, default=str) + "\n"
                                              for e in ledger)).encode("utf-8")
    manifest = {"package_version": VERSION, "files": {n: hashlib.sha256(b).hexdigest() for n, b in sorted(files.items())}}
    files["bundle_manifest.json"] = _bytes(manifest)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(files):
            zi = zipfile.ZipInfo(n, date_time=ZIP_DATE)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, files[n])
    return path


def read(path):
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        if "bundle_manifest.json" not in names:
            raise IntegrityError("the company file has no manifest (not a v10 company file?)")
        manifest = json.loads(z.read("bundle_manifest.json"))
        for n, h in manifest["files"].items():
            if n not in names:
                raise IntegrityError(f"the company file is missing {n}")
            if hashlib.sha256(z.read(n)).hexdigest() != h:
                raise IntegrityError(f"{n} in the company file was changed outside the pipeline")
        extra = names - set(manifest["files"]) - {"bundle_manifest.json"}
        if extra:
            raise IntegrityError(f"the company file has unexpected files: {', '.join(sorted(extra))}")
        parts = {n[:-5]: json.loads(z.read(n)) for n in manifest["files"] if n.endswith(".json")}
        ledger = [json.loads(l) for l in z.read("evidence_ledger.jsonl").decode("utf-8").splitlines() if l.strip()]
    verify_ledger(ledger)
    return parts, ledger


def method_hash(parts):
    """what an approval is bound to: field cells, method, input classes and the line map (not run-time values)."""
    lp = {f: v.get("cell") for f, v in parts.get("lp_map", {}).get("fields", {}).items()}
    inp = sorted((i["cell"], i["class"]) for i in parts.get("inputs", {}).get("items", []))
    lm = sorted((e["line"], (e.get("statement") or {}).get("label"), e.get("scale"), e.get("sign"))
                for e in parts.get("line_map", {}).get("entries", []))
    meth = parts.get("profile", {}).get("method")
    dec = sorted((d["item"], canon(d.get("value"))) for d in parts.get("decisions", {}).get("items", []))
    bld = sorted((p["sheet"], p["role"], tuple(sorted((i["class"], i["source"]) for i in p["inputs"])))
                 for p in parts.get("build", {}).get("parts", []))
    return sha({"lp": lp, "inputs": inp, "line_map": lm, "method": meth, "decisions": dec, "build": bld}, 16)
