# parts.py (build 11) - the build map. Works back from the LP row and answers, for any company layout:
#   which PARTS the reported numbers are built from (financials per entity, adjustments, pro forma, metrics,
#   comparables, valuation, cap table / waterfall, FX, fund records, LP outputs), in BUILD ORDER;
#   where EVERY input of every part comes from next quarter (statements, adjustment proposals, cap table, carried...);
#   which inputs have NO SOURCE (gaps) - so nothing the end numbers depend on is silently left stale;
#   with a prior approved workbook: what changed between the two quarters (which inputs really get updated) and which
#   sheets are rolled per quarter (e.g. 'Pro Forma Financials (Q1)' -> '(Q2)').
import re
from collections import defaultdict
from wbutil import ref_data, ref_str, parse_ref_str, norm_label, is_num, similarity, ym_str
from analyze import close, words_hit

RULES = ref_data("build_rules.json")
ROLES = [r["role"] for r in RULES["roles"]]
RW = {r["role"]: r for r in RULES["roles"]}
LABEL_PRIORITY = ["adjustments", "pro_forma", "cap_table", "fx", "fund_records", "comparables", "metrics", "valuation", "lp_output"]
FIELD_ROLE = {"enterprise_value": "valuation", "equity_value": "valuation", "cash": "valuation", "debt": "valuation",
              "net_debt": "valuation", "revenue_ttm": "metrics", "ebitda_reported": "metrics", "ebitda_adjusted": "metrics",
              "ebitda_adjustments": "metrics", "multiple_ebitda": "comparables", "multiple_revenue": "comparables",
              "weight_revenue": "comparables", "weight_ebitda": "comparables", "ownership": "cap_table", "fx_rate": "fx",
              "invested_capital": "fund_records", "proceeds": "fund_records", "moic": "lp_output", "irr": "lp_output"}
QUARTER_TOKEN = re.compile(r"\(?\bq[1-4]\b\)?|\b(19|20)\d{2}\b|\b\d{2}\b|\b(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\b", re.I)


def sheet_core(name):
    return " ".join(norm_label(QUARTER_TOKEN.sub(" ", name)).split())


def is_quarter_named(name):
    return bool(re.search(r"\bq[1-4]\b|\b20\d{2}\b|\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\b", name, re.I))


class Builder:
    def __init__(self, an, entries=None):
        self.an, self.m = an, an["model"]
        self.up = sorted(an["lp_upstream"])                  # sorted: the build map must be deterministic
        self.F = {f: parse_ref_str(r["cell"]) for f, r in an["lp_fields"].items()}
        self.field_of = {k: f for f, k in self.F.items()}
        self.cls = {i["cell"]: i["class"] for i in an["inputs"]}
        self.entries = {e["line"]: e for e in (entries or [])}
        self.have_statements = entries is not None and any(e.get("evidence") != "no_statements" for e in (entries or []))
        self._role = {}

    # ---------------------------------------------------------------- roles
    def _block_row_role(self, k):
        b = self.m.block_of_cell(k)
        line = b[0]
        lab = line.split("|", 1)[1]
        if words_hit(lab, RW["adjustments"]["label_words"]):
            return "adjustments"
        if words_hit(k[0], RW["pro_forma"]["sheet_words"]) or words_hit(lab, RW["pro_forma"]["label_words"]):
            return "pro_forma"
        if self.m.is_formula(k):
            src_sheets = {p[0] for p in self.m.precedents(k) if self.m.block_of_cell(p)}
            if len(src_sheets - {k[0]}) >= 2:          # a row built from 2+ other sheets' rows: a consolidation
                return "pro_forma"
        return "financials"

    def role(self, k):
        if k in self._role:
            return self._role[k]
        r = None
        if self.m.block_of_cell(k):
            r = self._block_row_role(k)
        elif k in self.field_of:
            f = self.field_of[k]
            r = FIELD_ROLE.get(f)
            if f in ("investor_value", "investor_value_local"):
                r = "cap_table" if words_hit(k[0], RW["cap_table"]["sheet_words"]) else "lp_output" if words_hit(k[0], RW["lp_output"]["sheet_words"]) else "valuation"
        if r is None:
            lab = self.m.label(k)
            r = next((x for x in LABEL_PRIORITY if words_hit(lab, RW[x]["label_words"])), None)
        if r is None:
            r = next((x for x in LABEL_PRIORITY + ["financials"] if words_hit(k[0], RW[x]["sheet_words"])), None)
        self._role[k] = r
        return r

    # ---------------------------------------------------------------- inputs and their sources
    def input_class(self, k):
        if k in self.m._f:
            f = self.m.f(k)
            from wbutil import is_external
            if is_external(f):
                return "external"
            from workbook_model import addin_function
            from wbutil import func_names
            if any(addin_function(n) for n in func_names(f)):
                return "add_in"
            return None
        if not (is_num(self.m.v(k)) or hasattr(self.m.v(k), "year")):
            return None
        b = self.m.block_of_cell(k)
        if b:
            e = self.entries.get(b[0])
            lab = b[0].split("|", 1)[1]
            if words_hit(lab, RW["adjustments"]["label_words"]) or (e and e.get("adjustment")):
                return "adjustment"
            if e is None or e.get("evidence") in ("no_statements", "no_overlap", "entity_statements_missing"):
                return "statement_pending"
            if e.get("statement"):
                return "statement_line"
            return "statement_gap"
        c = self.cls.get(ref_str(k), "parameter")
        return {"pasted_calculation": "pasted_calculation"}.get(c, c)

    def build(self, prior=None, balance_evidence=None):
        m = self.m
        parts = {}

        def part_of(k):
            r = self.role(k) or "calculation"
            return (k[0], r)
        # resolve unlabelled cells to their sheet's dominant role
        dom = defaultdict(lambda: defaultdict(int))
        for k in self.up:
            r = self.role(k)
            if r:
                dom[k[0]][r] += 1
        for k in self.up:
            if self._role.get(k) is None:
                d = dom.get(k[0])
                self._role[k] = max(d.items(), key=lambda t: (t[1], -ROLES.index(t[0])))[0] if d else "calculation"
        edges = defaultdict(set)
        for k in self.up:
            pk = part_of(k)
            parts.setdefault(pk, {"sheet": k[0], "role": pk[1], "cells": 0, "inputs": defaultdict(list)})
            parts[pk]["cells"] += 1
            if k in m._f:
                for p in m.precedents(k):
                    if p in self.up and part_of(p) != pk:
                        edges[pk].add(part_of(p))
            ic = self.input_class(k)
            if ic:
                parts[pk]["inputs"][ic].append(k)
        # build order: inputs first (Kahn), ties by role order then sheet order
        order, done = [], set()
        rank = lambda pk: (ROLES.index(pk[1]) if pk[1] in ROLES else len(ROLES), m.sheets.index(pk[0]) if pk[0] in m.sheets else 99)
        pending = set(parts)
        while pending:
            ready = sorted((p for p in pending if not (edges[p] - done - {p})), key=rank) or sorted(pending, key=rank)[:1]
            for p in ready:
                order.append(p)
                done.add(p)
                pending.discard(p)
        pid = {pk: f"P{i}" for i, pk in enumerate(order, 1)}
        learned = learn(self.an, prior) if prior else None
        changed = learned["changed_cells"] if learned else {}
        out, gaps, actions = [], [], []
        for pk in order:
            p = parts[pk]
            ins = []
            for ic, keys in sorted(p["inputs"].items()):
                src = RULES["sources"].get(ic, RULES["sources"]["parameter"])
                ent = sorted({((self.entries.get(m.block_of_cell(k)[0]) or {}).get("statement") or {}).get("entity") or "" for k in keys if m.block_of_cell(k)} - {""})
                lines = sorted({m.block_of_cell(k)[0].split("|", 1)[1] for k in keys if m.block_of_cell(k)})
                rows_n = len({m.block_of_cell(k)[0] for k in keys if m.block_of_cell(k)})
                rec = {"class": ic, "count": len(keys), "rows_count": rows_n, "source": src["source"], "each_quarter": src["each_quarter"],
                       "cells": [ref_str(k) for k in keys[:40]], "labels": sorted({m.label(k) for k in keys if not m.block_of_cell(k)})[:8],
                       "rows": lines[:12], "entities": ent}
                if learned and not rows_n:
                    ch = [ref_str(k) for k in keys if ref_str(k) in changed]
                    rec["last_quarter"] = {"changed": len(ch), "unchanged": len([k for k in keys if ref_str(k) in learned["matched_cells"]]) - len(ch),
                                           "examples": [changed[c] for c in ch[:4]]}
                if ic == "balance" and balance_evidence:
                    rec["evidence"] = [balance_evidence[ref_str(k)] for k in keys if ref_str(k) in balance_evidence][:4]
                ins.append(rec)
                if src["each_quarter"] == "gap":
                    seen_rows = set()
                    for k in keys:
                        b = m.block_of_cell(k)
                        if b:                                       # one gap per row, not per month
                            if b[0] in seen_rows:
                                continue
                            seen_rows.add(b[0])
                        gaps.append({"part": pid[pk], "cell": ref_str(k), "label": (b[0] if b else m.label(k)), "class": ic,
                                     "why": src["source"], "months": sum(1 for x in keys if b and m.block_of_cell(x) and m.block_of_cell(x)[0] == b[0]) or None})
                        if len(gaps) >= 40:
                            break
            needs = sorted({i["each_quarter"] for i in ins if i["each_quarter"] not in ("automatic", "automatic once proven", "carried, analyst may change")})
            status = "gap" if any(i["each_quarter"] == "gap" for i in ins) else "needs action each quarter" if needs else \
                     "carried" if ins and all(i["each_quarter"].startswith("carried") for i in ins) else "automatic"
            rolled = is_quarter_named(pk[0])
            prior_name = learned["sheet_map"].get(pk[0]) if learned else None
            rec = {"id": pid[pk], "sheet": pk[0], "role": pk[1], "title": RW.get(pk[1], {}).get("title", "Calculation"),
                   "depends_on": sorted((pid[d] for d in edges[pk] if d in pid), key=lambda x: int(x[1:])),
                   "cells": p["cells"], "inputs": ins, "status": status, "needs": needs,
                   "per_quarter_sheet": bool(rolled), "prior_quarter_sheet": prior_name if prior_name and prior_name != pk[0] else None}
            out.append(rec)
            if needs:
                actions.append(f"{pid[pk]} {pk[0]} [{pk[1]}]: " + "; ".join(
                    (f"{i['rows_count']} {i['class'].replace('_', ' ')} row(s)" if i.get("rows_count") else f"{i['count']} {i['class'].replace('_', ' ')} input(s)")
                    + f" - {i['each_quarter']}" for i in ins if i["each_quarter"] in needs))
        trace = {}
        for f in ("investor_value", "equity_value", "enterprise_value", "ebitda_adjusted", "moic"):
            if f not in self.F or self.F[f] not in self.up:
                continue
            start = part_of(self.F[f])
            seen, frontier, chain = {start}, [start], []
            while frontier:
                chain.append(sorted({pid[p] for p in frontier}, key=lambda x: int(x[1:])))
                nxt = set()
                for p in frontier:
                    nxt |= {d for d in edges[p] if d not in seen}
                seen |= nxt
                frontier = sorted(nxt, key=rank)
            trace[f] = chain
        return {"parts": out, "trace": trace, "gaps": gaps, "actions_each_quarter": actions, "learned": learned,
                "part_names": {pid[pk]: f"{pk[0]} [{pk[1]}]" for pk in order}}


def learn(an, prior):
    """compare the current approved workbook with the previous quarter's approved workbook (both analysed)."""
    m, pm = an["model"], prior["model"]
    pcore = defaultdict(list)
    for s in pm.sheets:
        pcore[sheet_core(s)].append(s)
    sheet_map = {}
    for s in m.sheets:
        c = sheet_core(s)
        if s in pm.sheets:
            sheet_map[s] = s
        elif pcore.get(c):
            sheet_map[s] = pcore[c][0]
        else:
            best = max(pm.sheets, key=lambda x: similarity(sheet_core(x), c), default=None)
            if best and similarity(sheet_core(best), c) >= 0.6:
                sheet_map[s] = best
    index = {}
    for k, v in pm._v.items():
        if k in pm._f:
            continue
        key = (k[0], norm_label(pm.row_label(k)), norm_label(pm.col_header(k)))
        index.setdefault(key, k)
    changed, matched = {}, set()
    for i in an["inputs"]:
        k = parse_ref_str(i["cell"])
        ps = sheet_map.get(k[0])
        if not ps:
            continue
        pk = index.get((ps, norm_label(m.row_label(k)), norm_label(m.col_header(k))))
        if pk is None and (ps, k[1], k[2]) in pm._v and (ps, k[1], k[2]) not in pm._f:
            pk = (ps, k[1], k[2])
        if pk is None:
            continue
        matched.add(i["cell"])
        a, b = pm.v(pk), m.v(k)
        same = close(a, b, 1e-9) if is_num(a) and is_num(b) else str(a) == str(b)
        if not same:
            changed[i["cell"]] = {"cell": i["cell"], "label": i["label"], "class": i["class"], "previous": a, "current": b}
    by_class = defaultdict(lambda: {"changed": 0, "unchanged": 0})
    for i in an["inputs"]:
        if i["cell"] in matched:
            by_class[i["class"]]["changed" if i["cell"] in changed else "unchanged"] += 1
    cur, prv = (an.get("period") or {}).get("detected_calculation_month"), (prior.get("period") or {}).get("detected_calculation_month")
    shift = None
    if cur and prv:
        y1, m1 = map(int, cur.split("-"))
        y0, m0 = map(int, prv.split("-"))
        shift = (y1 * 12 + m1) - (y0 * 12 + m0)
    return {"prior_workbook": prior["workbook"]["name"], "sheet_map": sheet_map,
            "rolled_sheets": [{"current": s, "previous": p} for s, p in sheet_map.items() if s != p],
            "new_sheets": [s for s in m.sheets if s not in sheet_map], "dropped_sheets": [p for p in pm.sheets if p not in sheet_map.values()],
            "by_class": dict(by_class), "changed_cells": changed, "matched_cells": sorted(matched), "window_shift_months": shift}


def balance_sources(an, index, val_i):
    """prove where each period-end balance input comes from: one statement line, or the sum across entities."""
    from statements import build_series, SCALES
    if not index or val_i is None:
        return {}
    series = {k: s for k, s in build_series(index["values"]).items() if k[3] == "current"}
    out = {}
    for i in an["inputs"]:
        if i["class"] != "balance" or not is_num(i["value"]):
            continue
        v = i["value"]
        cands = [(k, s[val_i]["value"]) for k, s in series.items() if val_i in s and similarity(i["label"], k[2]) >= 0.5]
        hit = None
        for k_ in SCALES:
            one = [k for k, x in cands if abs(v - k_ * x) <= max(0.5 * max(k_, 1), 1e-6 * abs(v))]
            if one:
                hit = f"{one[0][2]} ({one[0][0]}, x{k_:g})"
                break
            by_label = defaultdict(list)
            for k, x in cands:
                by_label[norm_label(k[2])].append((k, x))
            for lab, grp in by_label.items():
                ents = {k[0] for k, _ in grp}
                if len(ents) >= 2 and abs(v - k_ * sum(x for _, x in grp)) <= max(0.5 * max(k_, 1) * len(grp), 1e-6 * abs(v)):
                    hit = f"sum of '{grp[0][0][2]}' across {len(ents)} entities ({', '.join(sorted(ents))}, x{k_:g})"
                    break
            if hit:
                break
        out[i["cell"]] = {"cell": i["cell"], "label": i["label"], "proven_from": hit or "not proven (refresh asks)"}
    return out
