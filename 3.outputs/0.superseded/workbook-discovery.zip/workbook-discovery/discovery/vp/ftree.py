# ftree.py (build 11.3, WP2) - reads a formula into a small expression tree so the pipeline can see HOW a value is built,
# instead of finding cells whose numbers happen to multiply out.
#   parse(m, key)            -> node, or None when the formula uses syntax this reader does not support (never guessed)
#   trace_ev(m, key, ...)    EV's formula tree: aliases followed, then multiple x metric (x weight / factors), or a weighted
#                            sum of such components (blended); each component's multiple, metric and weight are CELLS
#                            the formula really uses; Python re-computes the tree and keeps it only if it gives Excel's value
#   provenance(m, key)       how a multiple is built: analyst-entered, aggregate (average / median ...) of comparables,
#                            discounted, weighted - comparables may feed the selected multiple but are never it
import formula_eval as FE
from wbutil import col_idx, is_num, ref_str, label_score, norm_label, ref_data

AGG = {"AVERAGE", "MEDIAN", "MIN", "MAX", "AVERAGEA", "TRIMMEAN", "PERCENTILE", "QUARTILE", "LARGE", "SMALL"}
WRAP = {"ROUND", "ROUNDUP", "ROUNDDOWN", "IFERROR", "IFNA"}
DISCOUNT_WORDS = ("discount", "premium", "haircut", "illiquidity", "liquidity", "size adjustment", "control")
FIELDS = ref_data("lp_fields.json")["fields"]


class _P:
    def __init__(self, m, sheet, formula):
        self.m, self.sheet = m, sheet
        self.t, self.i = FE.tokens(formula), 0

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else (None, None)

    def take(self):
        tok = self.t[self.i]
        self.i += 1
        return tok

    def ref(self, tok):
        sh = self.sheet
        if "!" in tok:
            sh, tok = tok.rsplit("!", 1)
            sh = sh.strip("'").replace("''", "'")
        real = self.m.sheet_lc.get(sh.lower())
        if not real:
            raise FE.Unsupported(f"unknown sheet {sh}")
        a, _, b = tok.replace("$", "").partition(":")
        import re
        ma, mb = re.match(r"([A-Z]+)(\d+)", a), re.match(r"([A-Z]+)(\d+)", b or a)
        r1, c1, r2, c2 = int(ma.group(2)), col_idx(ma.group(1)), int(mb.group(2)), col_idx(mb.group(1))
        if (r1, c1) == (r2, c2):
            return ("ref", (real, r1, c1))
        return ("range", real, min(r1, r2), min(c1, c2), max(r1, r2), max(c1, c2))

    def expr(self):
        v = self.term()
        while self.peek()[1] in ("+", "-"):
            op = self.take()[1]
            v = ("bin", op, v, self.term())
        return v

    def term(self):
        v = self.unary()
        while self.peek()[1] in ("*", "/"):
            op = self.take()[1]
            v = ("bin", op, v, self.unary())
        return v

    def unary(self):
        if self.peek()[1] in ("+", "-"):
            op = self.take()[1]
            v = self.unary()
            return ("neg", v) if op == "-" else v
        return self.power()

    def power(self):
        v = self.atom()
        while self.peek()[1] == "%":
            self.take()
            v = ("bin", "/", v, ("num", 100.0))
        if self.peek()[1] == "^":
            self.take()
            v = ("bin", "^", v, self.unary())
        return v

    def atom(self):
        kind, tok = self.take()
        if kind == "num":
            return ("num", float(tok))
        if kind == "ref":
            return self.ref(tok)
        if kind == "name":
            boxes = self.m.names.get(tok.upper())
            if not boxes or len(boxes) != 1:
                raise FE.Unsupported(f"name {tok}")
            (sh, r1, c1, r2, c2), = boxes
            return ("ref", (sh, r1, c1)) if (r1, c1) == (r2, c2) else ("range", sh, r1, c1, r2, c2)
        if kind == "op" and tok == "(":
            v = self.expr()
            if self.take()[1] != ")":
                raise FE.Unsupported("missing )")
            return v
        if kind == "func":
            name, args = tok.upper().replace("_XLFN.", ""), []
            if self.peek()[1] == ")":
                self.take()
                return ("func", name, args)
            while True:
                args.append(self.expr())
                sep = self.take()[1]
                if sep == ")":
                    return ("func", name, args)
                if sep != ",":
                    raise FE.Unsupported("bad argument list")
        raise FE.Unsupported(f"unexpected {tok}")


def parse(m, key):
    f = m.f(key)
    if not f:
        return None
    try:
        p = _P(m, key[0], f)
        n = p.expr()
        if p.i != len(p.t):
            return None
        return n
    except (FE.Unsupported, IndexError, AttributeError):
        return None


def unwrap(n):
    while n and n[0] == "func" and n[1] in WRAP and n[2]:
        n = n[2][0]
    return n


def factors(n):
    n = unwrap(n)
    if n[0] == "bin" and n[1] == "*":
        return factors(n[2]) + factors(n[3])
    if n[0] == "bin" and n[1] == "/":
        return factors(n[2]) + [("inv", n[3])]
    if n[0] == "func" and n[1] == "PRODUCT":
        out = []
        for a in n[2]:
            out += factors(a)
        return out
    return [n]


def addends(n, sign=1):
    n = unwrap(n)
    if n[0] == "bin" and n[1] in ("+", "-"):
        return addends(n[2], sign) + addends(n[3], sign if n[1] == "+" else -sign)
    if n[0] == "neg":
        return addends(n[1], -sign)
    return [(sign, n)]


def cells_of(m, n):
    out = []
    if n is None:
        return out
    if n[0] == "ref":
        out.append(n[1])
    elif n[0] == "range":
        out += m.cells_in(n[1], n[2], n[3], n[4], n[5])
    elif n[0] in ("bin",):
        out += cells_of(m, n[2]) + cells_of(m, n[3])
    elif n[0] in ("neg", "inv"):
        out += cells_of(m, n[1])
    elif n[0] == "func":
        for a in n[2]:
            out += cells_of(m, a)
    return out


def value(m, n):
    """re-computes a node from saved values (the functions formula_eval supports, plus MEDIAN and PRODUCT)."""
    k = n[0]
    if k == "num":
        return n[1]
    if k == "ref":
        v = m.v(n[1])
        if not is_num(v):
            raise FE.Unsupported("not a number")
        return float(v)
    if k == "neg":
        return -value(m, n[1])
    if k == "inv":
        d = value(m, n[1])
        if d == 0:
            raise FE.ExcelError("#DIV/0!")
        return 1.0 / d
    if k == "bin":
        a, b = value(m, n[2]), value(m, n[3])
        if n[1] == "+":
            return a + b
        if n[1] == "-":
            return a - b
        if n[1] == "*":
            return a * b
        if n[1] == "/":
            if b == 0:
                raise FE.ExcelError("#DIV/0!")
            return a / b
        if n[1] == "^":
            return a ** b
    if k == "func":
        name = n[1]
        if name in WRAP and name.startswith("IF"):
            try:
                return value(m, n[2][0])
            except FE.ExcelError:
                return value(m, n[2][1])
        nums = []
        for a in n[2]:
            if a[0] == "range":
                nums += [float(m.v(c)) for c in m.cells_in(a[1], a[2], a[3], a[4], a[5]) if is_num(m.v(c))]
            else:
                nums.append(value(m, a))
        if name == "ROUND" and len(nums) == 2:
            q = 10.0 ** int(nums[1])
            x = abs(nums[0]) * q
            return (1 if nums[0] >= 0 else -1) * float(int(x + 0.5 + 1e-9)) / q
        if name == "SUM":
            return sum(nums)
        if name == "PRODUCT":
            out = 1.0
            for x in nums:
                out *= x
            return out
        if name == "AVERAGE" and nums:
            return sum(nums) / len(nums)
        if name == "MEDIAN" and nums:
            s = sorted(nums)
            h = len(s) // 2
            return s[h] if len(s) % 2 else (s[h - 1] + s[h]) / 2
        if name == "MIN" and nums:
            return min(nums)
        if name == "MAX" and nums:
            return max(nums)
    raise FE.Unsupported(f"cannot re-compute {k}")


def describe(m, n):
    n = unwrap(n)
    if n[0] == "ref":
        return f"{m.label(n[1]) or ref_str(n[1])} ({ref_str(n[1])})"
    if n[0] == "num":
        return f"{n[1]:g}"
    if n[0] == "func" and n[1] in AGG:
        cells = [c for c in cells_of(m, n) if is_num(m.v(c))]
        return f"{n[1].lower()} of {len(cells)} cell(s)"
    if n[0] == "bin" and n[1] == "-" and n[2] == ("num", 1.0):
        return f"(1 - {describe(m, n[3])})"
    if n[0] == "bin" and n[1] == "+" and n[2] == ("num", 1.0):
        return f"(1 + {describe(m, n[3])})"
    if n[0] == "inv":
        return f"/ {describe(m, n[1])}"
    return "calculation"


METRIC_FIELDS = ("ebitda_adjusted", "ebitda_reported", "revenue_ttm")


def metric_field(m, k, C):
    for f in METRIC_FIELDS:
        if any(c["key"] == k for c in C.get(f, [])):
            return f
    lab = m.label(k)
    best = max(((label_score(lab, FIELDS[f]["synonyms"], FIELDS[f].get("exclude", [])), f) for f in METRIC_FIELDS), default=(0, None))
    if best[0] >= 3:
        return best[1]
    L = f" {norm_label(lab)} "
    if " revenue " in L or " sale " in L:
        return "revenue_ttm"
    if " ebitda " in L:
        return "ebitda_adjusted" if (" adj " in L or " adjusted " in L) else "ebitda_reported"
    return None


def _is_weight(m, k):
    v = m.v(k)
    return is_num(v) and 0 < v <= 1 and "weight" in norm_label(m.label(k))


def _component(m, sign, n, C):
    fs = factors(n)
    comp = {"sign": sign, "multiple_cell": None, "multiple_inline": None, "metric_cell": None, "metric_field": None,
            "weight_cell": None, "weight": None, "other": []}
    rest = []
    for f in fs:
        u = unwrap(f)
        if u[0] == "ref":
            k = u[1]
            mf = metric_field(m, k, C)
            v = m.v(k)
            if mf and comp["metric_cell"] is None and is_num(v) and abs(v) >= 100:
                comp["metric_cell"], comp["metric_field"] = k, mf
            elif _is_weight(m, k) and comp["weight_cell"] is None:
                comp["weight_cell"], comp["weight"] = k, float(v)
            else:
                rest.append(u)
        elif u[0] == "num" and 0 < u[1] < 1 and comp["weight"] is None:
            comp["weight"] = u[1]
        else:
            rest.append(u)
    mults = [r for r in rest if r[0] == "ref" and is_num(m.v(r[1])) and 0.05 <= m.v(r[1]) <= 100]
    if len(mults) == 1:
        comp["multiple_cell"] = mults[0][1]
        rest = [r for r in rest if r is not mults[0]]
    else:
        agg = [r for r in rest if r[0] == "func" and r[1] in AGG]
        if len(agg) == 1:
            comp["multiple_inline"] = describe(m, agg[0])
            rest = [r for r in rest if r is not agg[0]]
    comp["other"] = [describe(m, r) for r in rest]
    return comp


def trace_ev(m, key, C):
    """-> {'cell', 'aliases', 'structure', 'components', 'python_value', 'reproduces', 'reason'} or None."""
    k, aliases = key, []
    for _ in range(6):
        n = parse(m, k)
        if n is None:
            return {"cell": k, "aliases": aliases, "structure": "not traced", "components": [], "reproduces": False,
                    "reason": "EV's formula uses syntax Python does not read (e.g. comparisons, text, lookups)" if m.f(k) else "EV is a typed number"}
        u = unwrap(n)
        if u[0] == "ref" and m.f(u[1]):
            aliases.append(k)
            k = u[1]
            continue
        break
    adds = addends(n)
    comps = [_component(m, sg, a, C) for sg, a in adds]
    good = [c for c in comps if c["metric_cell"] and (c["multiple_cell"] or c["multiple_inline"])]
    structure = ("product" if len(comps) == 1 and good else "blended" if len(good) >= 2 and len(good) == len(comps) else "other")
    try:
        pv = value(m, n)
    except (FE.Unsupported, FE.ExcelError):
        pv = None
    sv = m.v(k)
    ok = pv is not None and is_num(sv) and abs(pv - sv) <= max(1e-6, 5e-4 * max(abs(pv), abs(sv)))
    return {"cell": k, "aliases": aliases, "structure": structure, "components": good if structure != "other" else comps,
            "python_value": pv, "reproduces": ok,
            "reason": None if ok else ("Python could not re-compute EV's formula" if pv is None else "the formula tree does not give Excel's value")}


def provenance(m, key, depth=0):
    """how a multiple is built. -> {'kind', 'cell', 'comparables': [keys], 'discounts': [keys], 'text'}"""
    out = {"cell": key, "comparables": [], "discounts": [], "via": []}
    if not m.f(key):
        out.update(kind="analyst_entered", text=f"analyst-entered ({ref_str(key)})")
        return out
    n = parse(m, key)
    if n is None:
        out.update(kind="not_traced", text=f"formula not traced ({ref_str(key)})")
        return out
    u = unwrap(n)
    if u[0] == "ref" and depth < 6:
        p = provenance(m, u[1], depth + 1)
        p["via"] = [key] + p.get("via", [])
        return p
    if u[0] == "func" and u[1] in AGG:
        comps = [c for c in cells_of(m, u) if is_num(m.v(c))]
        out.update(kind="aggregate", stat=u[1].lower(), comparables=comps,
                   text=f"{u[1].lower()} of {len(comps)} comparable(s) ({ref_str(comps[0])}..{ref_str(comps[-1])})" if comps else u[1].lower())
        return out
    fs = factors(u)
    base, disc = [], []
    for f in fs:
        f = unwrap(f)
        if f[0] == "bin" and f[1] in ("-", "+") and f[2] == ("num", 1.0) and depth < 6:
            disc += [c for c in cells_of(m, f[3])]
        elif f[0] == "ref" and any(w in norm_label(m.label(f[1])) for w in DISCOUNT_WORDS) and is_num(m.v(f[1])) and m.v(f[1]) <= 1.5:
            disc.append(f[1])
        else:
            base.append(f)
    if disc and len(base) == 1:
        b = base[0]
        inner = provenance(m, b[1], depth + 1) if b[0] == "ref" else (
            {"kind": "aggregate", "stat": b[1].lower(), "comparables": [c for c in cells_of(m, b) if is_num(m.v(c))], "discounts": [],
             "text": describe(m, b)} if b[0] == "func" and b[1] in AGG else {"kind": "calculated", "comparables": [], "discounts": [], "text": describe(m, b)})
        out.update(kind="discounted", discounts=disc + inner.get("discounts", []), comparables=inner.get("comparables", []),
                   text=f"{inner['text']} x (1 - discount {', '.join(ref_str(d) for d in disc)})")
        return out
    if u[0] == "func" and u[1] == "SUMPRODUCT":
        cells = cells_of(m, u)
        out.update(kind="weighted", comparables=[c for c in cells if is_num(m.v(c)) and 0.05 <= m.v(c) <= 100],
                   text=f"weighted (SUMPRODUCT of {len(cells)} cells)")
        return out
    out.update(kind="calculated", text=f"calculated ({ref_str(key)})")
    return out
