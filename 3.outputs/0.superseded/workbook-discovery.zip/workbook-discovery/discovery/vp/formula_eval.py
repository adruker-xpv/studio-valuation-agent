# formula_eval.py (build 11.3) - re-computes ONE formula from the saved values of its precedents, so Python can check that
# Excel's saved result is what the formula gives (stale values, manual calculation, pasted-over formulas).
# Supports + - * / ^ %, parentheses, numbers, cell references (with sheets), defined names of single cells,
# and SUM, AVERAGE, MEDIAN, PRODUCT, MIN, MAX, ABS, ROUND, IFERROR over cells and ranges (MEDIAN, PRODUCT: 11.3). Anything else -> Unsupported (never guessed).
import re
from wbutil import col_idx, is_num, is_error_value

TOK = re.compile(r"\s*(?:(?P<num>\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)|"
                 r"(?P<ref>(?:(?:'(?:[^']|'')+'|[A-Za-z_][A-Za-z0-9_.]*)!)?\$?[A-Z]{1,3}\$?\d+(?::\$?[A-Z]{1,3}\$?\d+)?)|"
                 r"(?P<func>[A-Za-z_][A-Za-z0-9_.]*)\s*\(|(?P<name>[A-Za-z_][A-Za-z0-9_.]*)|(?P<op>[-+*/^%(),]))")
FUNCS = {"SUM", "AVERAGE", "MIN", "MAX", "ABS", "ROUND", "IFERROR", "MEDIAN", "PRODUCT"}


class Unsupported(Exception):
    pass


class ExcelError(Exception):
    pass


def tokens(formula):
    s, pos, out = formula.lstrip("="), 0, []
    while pos < len(s):
        if s[pos:].strip() == "":
            break
        m = TOK.match(s, pos)
        if not m or m.end() == pos:
            raise Unsupported(f"cannot read formula near '{s[pos:pos + 12]}'")
        kind = m.lastgroup
        out.append((kind, m.group(kind)))
        pos = m.end()
    return out


class Evaluator:
    def __init__(self, model, sheet):
        self.m, self.sheet = model, sheet
        self.used = set()

    def _range(self, ref):
        sh = self.sheet
        if "!" in ref:
            sh, ref = ref.rsplit("!", 1)
            sh = sh.strip("'").replace("''", "'")
        real = self.m.sheet_lc.get(sh.lower())
        if not real:
            raise Unsupported(f"unknown sheet {sh}")
        a, _, b = ref.replace("$", "").partition(":")
        ma, mb = re.match(r"([A-Z]+)(\d+)", a), re.match(r"([A-Z]+)(\d+)", b or a)
        r1, c1, r2, c2 = int(ma.group(2)), col_idx(ma.group(1)), int(mb.group(2)), col_idx(mb.group(1))
        if (r1, c1) == (r2, c2):
            return [(real, r1, c1)], True
        return self.m.cells_in(real, min(r1, r2), min(c1, c2), max(r1, r2), max(c1, c2)), False

    def _val(self, k):
        self.used.add(k)
        v = self.m.v(k)
        if is_error_value(v):
            raise ExcelError(v)
        if v is None:
            return 0.0
        if isinstance(v, bool):
            return 1.0 if v else 0.0
        if not is_num(v):
            raise Unsupported(f"text value in arithmetic at {k}")
        return float(v)

    def run(self, formula):
        self.t, self.i = tokens(formula), 0
        v = self.expr()
        if self.i != len(self.t):
            raise Unsupported("trailing tokens")
        return v

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else (None, None)

    def take(self):
        tok = self.t[self.i]
        self.i += 1
        return tok

    def expr(self):
        v = self.term()
        while self.peek()[1] in ("+", "-"):
            op = self.take()[1]
            r = self.term()
            v = v + r if op == "+" else v - r
        return v

    def term(self):
        v = self.unary()
        while self.peek()[1] in ("*", "/"):
            op = self.take()[1]
            r = self.unary()
            if op == "/" and r == 0:
                raise ExcelError("#DIV/0!")
            v = v * r if op == "*" else v / r
        return v

    def unary(self):
        if self.peek()[1] in ("+", "-"):
            op = self.take()[1]
            v = self.unary()
            return -v if op == "-" else v
        return self.power()

    def power(self):
        v = self.atom()
        while self.peek()[1] == "%":
            self.take()
            v /= 100.0
        if self.peek()[1] == "^":
            self.take()
            v = v ** self.unary()
        return v

    def args(self):
        out = []
        if self.peek()[1] == ")":
            self.take()
            return out
        while True:
            kind, tok = self.peek()
            if kind == "ref" and ":" in tok and self.i + 1 < len(self.t) and self.t[self.i + 1][1] in (",", ")"):
                self.take()
                keys, _ = self._range(tok)
                out.append(("range", keys))
            else:
                start = self.i
                try:
                    out.append(("value", self.expr()))
                except ExcelError as e:
                    out.append(("error", str(e)))
                    depth = 0
                    while self.i < len(self.t) and not (depth == 0 and self.t[self.i][1] in (",", ")")):
                        depth += {"(": 1, ")": -1}.get(self.t[self.i][1], 0)
                        self.i += 1
            sep = self.take()[1]
            if sep == ")":
                return out
            if sep != ",":
                raise Unsupported("bad argument list")

    def atom(self):
        kind, tok = self.take()
        if kind == "num":
            return float(tok)
        if kind == "ref":
            keys, single = self._range(tok)
            if not single:
                raise Unsupported("range outside a function")
            return self._val(keys[0])
        if kind == "name":
            ranges = self.m.names.get(tok.upper())
            if not ranges or len(ranges) != 1:
                raise Unsupported(f"name {tok}")
            (sh, r1, c1, r2, c2), = ranges
            if (r1, c1) != (r2, c2):
                raise Unsupported(f"name {tok} is a range")
            return self._val((sh, r1, c1))
        if kind == "op" and tok == "(":
            v = self.expr()
            if self.take()[1] != ")":
                raise Unsupported("missing )")
            return v
        if kind == "func":
            f = tok.upper().replace("_XLFN.", "")
            if f not in FUNCS:
                raise Unsupported(f"function {f}")
            a = self.args()
            if f == "IFERROR":
                if len(a) != 2:
                    raise Unsupported("IFERROR arguments")
                first = a[0]
                if first[0] == "error":
                    return self._num(a[1])
                return self._num(first)
            nums = []
            for kind_, x in a:
                if kind_ == "error":
                    raise ExcelError(x)
                if kind_ == "range":
                    for k in x:
                        self.used.add(k)
                        v = self.m.v(k)
                        if is_error_value(v):
                            raise ExcelError(v)
                        if is_num(v):
                            nums.append(float(v))
                else:
                    nums.append(x)
            if f == "SUM":
                return sum(nums)
            if f == "AVERAGE":
                if not nums:
                    raise ExcelError("#DIV/0!")
                return sum(nums) / len(nums)
            if f == "MEDIAN":
                if not nums:
                    raise ExcelError("#NUM!")
                srt, h = sorted(nums), len(nums) // 2
                return srt[h] if len(srt) % 2 else (srt[h - 1] + srt[h]) / 2
            if f == "PRODUCT":
                out = 1.0
                for x in nums:
                    out *= x
                return out
            if f == "MIN":
                return min(nums) if nums else 0.0
            if f == "MAX":
                return max(nums) if nums else 0.0
            if f == "ABS":
                return abs(nums[0])
            if f == "ROUND":
                n = int(nums[1]) if len(nums) > 1 else 0
                q = 10.0 ** n
                x = abs(nums[0]) * q
                return (1 if nums[0] >= 0 else -1) * float(int(x + 0.5 + 1e-9)) / q    # Excel rounds half away from zero
        raise Unsupported(f"unexpected {tok}")

    def _num(self, arg):
        kind, x = arg
        if kind == "error":
            raise ExcelError(x)
        if kind == "range":
            raise Unsupported("range as a value")
        return x


def evaluate(model, key):
    """-> (value, precedents used) or raises Unsupported / ExcelError."""
    f = model.f(key)
    if not f:
        raise Unsupported("not a formula")
    ev = Evaluator(model, key[0])
    return ev.run(f), ev.used
