# discovery/chain.py (build 11.7) - CHAIN-FIRST valuation cells. Instead of choosing each key number by its label, find
# the coherent valuation chain in the formula graph, then name its cells by their place in it:
#     earnings figure x multiple = ENTERPRISE VALUE  ->  EV + cash - debt = EQUITY  ->  ownership / cap table = XPV VALUE
# 1. every formula shaped like "multiple x metric" (or a weighted sum of them) is an EV option
# 2. each option is followed downstream through the formula graph: an additive formula using it is the equity bridge; a
#    product of equity and an ownership share (or the reported-value cell) is XPV's value
# 3. options are eliminated by fixed rules, in order, each with its reason (kept in the option list). A saved value that
#    does not match its formula is a FLAG (a stale workbook), never a reason to drop the real chain
# 4. one survivor -> chosen (PROVEN when it reaches the reported value from the fund workbook, else SUPPORTED);
#    several -> AMBIGUOUS, review required (never a guess); none -> NOT_DETERMINABLE
# Labels are recorded for people; they never decide.
import re
from collections import defaultdict
import ftree as FT
import formula_eval as FE
from common.util import cell_text, cell_key
from wbutil import is_num, norm_label

COUNT_FUNCS = {"COUNT", "COUNTA", "COUNTIF", "COUNTIFS", "COUNTBLANK", "ROWS", "COLUMNS"}
FX_WORDS = re.compile(r"\bfx\b|exchange rate|cad\s*/\s*usd|usd\s*/\s*cad|rate \(fx\)", re.I)


def _close(a, b, rel=5e-4):
    return abs(a - b) <= max(1e-6, rel * max(abs(a), abs(b)))


class Chains:
    def __init__(self, m, g, period_of):
        self.m, self.g, self.period_of = m, g, period_of
        self.dep = defaultdict(set)
        for k in g.nodes:
            for p in g.precedents(k):
                self.dep[p].add(k)

    def num(self, k):
        v = self.m.v(k)
        return float(v) if is_num(v) and not isinstance(v, bool) else None

    def count_like(self, k):
        """a count of things (COUNTIF, ROWS ...) or a typed whole number labelled as a count - never a multiple."""
        n = self.g.nodes.get(k)
        if n and set(n["functions"]) & COUNT_FUNCS:
            return "a count (" + "/".join(sorted(set(n["functions"]) & COUNT_FUNCS)) + "), not a multiple"
        v = self.num(k)
        if n is None and v is not None and float(v).is_integer() and re.search(r"count|number of|#", self.m.row_label(k) or "", re.I):
            return "a typed count, not a multiple"
        return None

    def aliases(self, k):
        """cells that are only '=k' (or '=alias'), followed downstream."""
        out, todo = set(), [k]
        while todo:
            x = todo.pop()
            for d in self.dep.get(x, ()):
                if d in out:
                    continue
                node = FT.parse(self.m, d)
                u = FT.unwrap(node) if node else None
                if u and u[0] == "ref" and u[1] == x:
                    out.add(d)
                    todo.append(d)
        return out

    def ev_options(self):
        out = []
        for k, n in self.g.nodes.items():
            v = self.num(k)
            if v is None or abs(v) < 1000 or "*" not in (self.m.f(k) or ""):
                continue
            node = FT.parse(self.m, k)
            if node is None:
                continue
            comps, ok = [], True
            for sign, a in FT.addends(node):
                refs, other = [], []
                for f in FT.factors(a):
                    u = FT.unwrap(f)
                    (refs if u[0] == "ref" else other).append(u)
                nums = [r[1] for r in refs if self.num(r[1]) is not None]
                wts = [x for x in nums if 0 < self.num(x) <= 1 and "weight" in norm_label(self.m.label(x) or "")]
                mets = [x for x in nums if abs(self.num(x)) >= 1000]
                mults = [x for x in nums if x not in wts and 0.1 <= self.num(x) <= 100]
                if len(mets) != 1 or len(mults) != 1:
                    ok = False
                    break
                comps.append({"metric": mets[0], "multiple": mults[0], "weight": wts[0] if wts else None, "sign": sign,
                              "other_factors": len(other)})
            if not ok or not comps:
                continue
            try:
                pv = FT.value(self.m, node)
            except (FE.Unsupported, FE.ExcelError):
                pv = None
            out.append({"ev": k, "components": comps, "recomputes": pv is not None and _close(pv, v)})
        return out

    def bridges(self, ev):
        """additive formulas that use EV (or an alias of it) with a plus sign and at least one other term: the equity bridge."""
        src = {ev} | self.aliases(ev)
        out = []
        for s in src:
            for d in self.dep.get(s, ()):
                node = FT.parse(self.m, d)
                if node is None:
                    continue
                adds = FT.addends(node)
                hit = [sg for sg, a in adds if FT.unwrap(a)[0] == "ref" and FT.unwrap(a)[1] in src]
                rows = {(x[0], x[1]) for x in src}
                others = [FT.unwrap(a)[1] for sg, a in adds if FT.unwrap(a)[0] == "ref" and FT.unwrap(a)[1] not in src]
                if any((o[0], o[1]) in rows for o in others):
                    continue                              # EV minus a cell on its own row (e.g. budget): a comparison, not a bridge
                if hit == [1] and len(adds) >= 2:
                    try:
                        pv = FT.value(self.m, node)
                    except (FE.Unsupported, FE.ExcelError):
                        pv = None
                    v = self.num(d)
                    out.append({"equity": d, "recomputes": pv is not None and v is not None and _close(pv, v)})
        return out

    def investors(self, eq, anchor_cells):
        """XPV's value: an anchor-matched formula downstream of equity; else a product of equity and an ownership share."""
        src = {eq} | self.aliases(eq)
        down, todo = set(), list(src)
        while todo:
            x = todo.pop()
            for d in self.dep.get(x, ()):
                if d not in down:
                    down.add(d)
                    todo.append(d)
        hits = [k for k in anchor_cells if k in down]
        if hits:
            return [{"investor": k, "basis": "reaches the reported value"} for k in sorted(hits)]
        out = []
        for d in sorted(down):
            node = FT.parse(self.m, d)
            if node is None:
                continue
            fs = [FT.unwrap(f) for f in FT.factors(node)]
            if any(f[0] == "ref" and f[1] in src for f in fs):
                share = [f for f in fs if (f[0] == "ref" and f[1] not in src and self.num(f[1]) is not None and 0 < self.num(f[1]) <= 1)
                         or (f[0] == "num" and 0 < f[1] <= 1)]
                if share:
                    out.append({"investor": d, "basis": "equity x ownership share"})
        return out


def resolve(m, g, period_of, requested_i, anchor=None):
    """-> {'status', 'chosen', 'options': [...], 'anchor': {...}, 'copies': {...}} using only Python's own checks."""
    C = Chains(m, g, period_of)
    anchor_info, anchor_cells = None, []
    if anchor and anchor.get("value") is not None:
        anchor_info, anchor_cells = match_anchor(m, g, anchor)
    options = []
    evo = C.ev_options()
    equities = set()
    for o in evo:                                         # every equity bridge of every option: a product applied to one is
        for b in C.bridges(o["ev"]):                      # an ownership step, not a valuation
            equities.add(b["equity"])
            equities |= C.aliases(b["equity"])
    for o in evo:
        rec = {"ev": cell_text(*o["ev"]), "components": [{"metric": cell_text(*c["metric"]), "multiple": cell_text(*c["multiple"]),
                                                          "weight": cell_text(*c["weight"]) if c["weight"] else None} for c in o["components"]],
               "equity": None, "investor": None, "rejected": None, "notes": [], "_k": o}
        if any(isinstance(m.v(x), str) and str(m.v(x)).startswith("#") for c in o["components"] for x in (c["metric"], c["multiple"])):
            rec["rejected"] = "an Excel error in its inputs"
        elif any(C.count_like(c["multiple"]) for c in o["components"]):
            rec["rejected"] = next(C.count_like(c["multiple"]) for c in o["components"] if C.count_like(c["multiple"]))
        elif any(c["metric"] in equities for c in o["components"]):
            rec["rejected"] = "it multiplies another chain's equity value by a share (an ownership step, not a valuation)"
        else:
            if not o["recomputes"]:                       # still the EV cell - its saved value is stale: flagged, never hidden
                rec["notes"].append("its saved value does not match its formula (stale?) - the invariants report it")
            pers = [period_of(c["metric"]) for c in o["components"]]
            wrong = [p for p in pers if p and requested_i and p != requested_i]
            if wrong:
                rec["rejected"] = f"its earnings figure ends in another month ({wrong[0]})"
            elif not any(pers):
                rec["notes"].append("the earnings figure's period could not be determined")
        if not rec["rejected"]:
            br = C.bridges(o["ev"])
            ranked = sorted(br, key=lambda b: (not C.investors(b["equity"], anchor_cells), not b["recomputes"], b["equity"]))
            if ranked:                                    # the bridge that leads on to XPV's value wins
                eq = ranked[0]["equity"]
                rec["equity"] = cell_text(*eq)
                inv = C.investors(eq, anchor_cells)
                if inv:
                    rec["investor"] = cell_text(*inv[0]["investor"])
                    rec["notes"].append(f"XPV's value: {inv[0]['basis']}")
            if anchor_cells and not (rec["investor"] and any(cell_text(*a) == rec["investor"] for a in anchor_cells)):
                rec["rejected"] = "does not lead to the value reported in the fund workbook"
            elif not rec["equity"]:
                rec["notes"].append("no equity bridge uses it (incomplete chain)")
        options.append(rec)
    alive = [o for o in options if not o["rejected"]]
    if requested_i:                                       # a chain dated to the requested month beats chains of unknown period
        dated = [o for o in alive if all(period_of(cell_key(c["metric"])) == requested_i for c in o["components"])]
        if dated:
            for o in alive:
                if o not in dated:
                    o["rejected"] = "another chain's earnings figure is confirmed for the requested month; this one's period is unknown"
            alive = dated
    complete = [o for o in alive if o["equity"] and o["investor"]]
    pool = complete or alive
    for o in alive:
        if pool is complete and o not in complete:
            o["rejected"] = "a complete chain (EV -> equity -> XPV value) exists elsewhere; this one stops short"
    chosen, status = None, "NOT_DETERMINABLE"
    if len(pool) == 1:
        chosen = pool[0]
        period_ok = bool(requested_i) and all(period_of(c["metric"]) == requested_i for c in chosen["_k"]["components"])
        complete_ = bool(chosen["investor"] and chosen["equity"])
        unanchored = bool(anchor_info) and anchor_info["status"] == "unanchored"
        stale = any("saved value does not match" in n_ for n_ in chosen["notes"])
        status = "PROVEN" if complete_ and not unanchored and not stale and (bool(anchor_cells) or period_ok) else "SUPPORTED"
        if unanchored:
            chosen["notes"].append("the value reported in the fund workbook was not found in this workbook: review")
    elif len(pool) > 1:
        status = "AMBIGUOUS"
    copies = {}
    if chosen:
        for role, c in (("enterprise_value", chosen["ev"]), ("equity_value", chosen["equity"]), ("value_to_xpv", chosen["investor"])):
            if c:
                copies[role] = typed_copies(m, g, c)
    metric_keys = [c["metric"] for c in chosen["_k"]["components"]] if chosen else []
    for o in options:
        o.pop("_k", None)
    return {"metric_keys": metric_keys, "status": status, "chosen": chosen, "options": options, "anchor": anchor_info, "copies": copies,
            "rules": ["an Excel error in its inputs", "a count is never a multiple", "an ownership step is not a valuation", "earnings figure must end in the requested month",
                      "must lead to the reported value (when the fund workbook is given)", "a chain dated to the requested month beats one of unknown period",
                      "a complete chain beats an incomplete one",
                      "more than one survivor = review required"]}


def _tolerance(a):
    """the reported value's own rounding: 26,281,000 -> +/- 500; 26,280,918 -> +/- 1."""
    if float(a).is_integer():
        s = str(int(abs(a)))
        z = len(s) - len(s.rstrip("0"))
        return max(1.0, 0.5 * 10 ** min(z, 6))
    return 0.01


def match_anchor(m, g, anchor):
    a = float(anchor["value"])
    tol = _tolerance(a)
    fx = [k for k in m.cells if is_num(m.v(k)) and 0.3 <= float(m.v(k)) <= 3 and FX_WORDS.search(f"{m.row_label(k)} {m.col_header(k)}")]
    formula, typed, via_fx = [], [], []
    for k in m.cells:
        v = m.v(k)
        if not is_num(v) or isinstance(v, bool):
            continue
        v = float(v)
        if abs(v - a) <= tol:
            (formula if k in g.nodes else typed).append(k)
        else:
            for f in fx:
                r = float(m.v(f))
                if abs(v * r - a) <= tol * 1.01 or abs(v / r - a) <= tol * 1.01:
                    if k in g.nodes:
                        via_fx.append((k, f))
    cells = sorted(formula) or sorted(k for k, _ in via_fx)
    info = dict({k: v for k, v in anchor.items() if k != "value"}, tolerance=tol, formula_matches=len(formula), typed_copies=len(typed),
                via_fx=len(via_fx) if not formula else 0, status="matched" if cells else "unanchored",
                matched=[cell_text(*k) for k in cells][:10], copies=[cell_text(*k) for k in sorted(typed)][:10])
    return info, cells


def typed_copies(m, g, c):
    from common.util import cell_key
    k = cell_key(c)
    v = m.v(k)
    if not is_num(v):
        return []
    s = f"{abs(float(v)):.6e}".split("e")[0].replace(".", "").rstrip("0")
    if len(s) < 4:
        return []
    return [cell_text(*x) for x in sorted(m.cells) if x not in g.nodes and x != k and is_num(m.v(x))
            and abs(float(m.v(x)) - float(v)) <= max(0.5, 1e-9 * abs(float(v)))][:10]
