# discovery/graph.py (build 11.5) - LAYER 1: the formula relationship graph, built from formulas and Excel references only
# (never from labels). Every formula cell is a node with FIVE independent flags - nothing stops silently:
#   references_extracted  COMPLETE | OVER_APPROXIMATED | UNSUPPORTED | MISSING
#   dynamic_resolution    STATIC | DYNAMIC_RESOLVED | DYNAMIC_UNRESOLVED
#   location              INTERNAL | EXTERNAL            (with whether the external target is identified)
#   cycle                 ACYCLIC | CIRCULAR
#   value_verification    RECOMPUTED | NOT_RECOMPUTED | MISMATCH   (separate from graph completeness)
# Edges: REFERENCED (the formula names these cells) and CONTRIBUTING (Python's re-computation actually read them; unknown
# where Python cannot re-compute the formula). Regions: connected groups of formulas and their inputs once hub cells
# (dates and typed scalars many formulas use) are set aside; sinks: formulas nothing else uses.
import datetime, re
from collections import defaultdict
from openpyxl.formula.tokenizer import Tokenizer, Token
from common.util import parse_box, box_text, cell_text, col_idx

from rules import RULES as _ALL
RULES = _ALL["graph"]
OVER = set(RULES["over_approximating_functions"])
DYNAMIC = set(RULES["dynamic_functions"])
EXT = re.compile(r"^'?\[([^\]]+)\]")
STRUCT = re.compile(r"^([A-Za-z_\\][\w.]*)?\[(.*)\]$", re.S)
THREE_D = re.compile(r"^'?([^'!:\[]+):([^'!\[]+)'?!(.+)$")
SEVERITY = {"MISSING": 3, "UNSUPPORTED": 2, "OVER_APPROXIMATED": 1, "COMPLETE": 0}


class Graph:
    def __init__(self, m, facts, arr):
        self.m, self.facts, self.arr = m, facts, arr
        self.order = [s["name"] for s in facts["sheets"]]
        self.tables = {}
        for t in facts["tables"]:
            self.tables[t["display_name"].lower()] = t
            self.tables[(t["name"] or "").lower()] = t
        self.names = {}
        for d in facts["defined_names"]:
            self.names.setdefault(d["name"].lower(), d)
        self.links = {l["index"]: l for l in m.links}
        self.max_stored = defaultdict(lambda: (0, 0))
        for (sh, r, c) in m.cells:
            mr, mc = self.max_stored[sh]
            self.max_stored[sh] = (max(mr, r), max(mc, c))
        self.nodes = {k: self._node(k, f) for k, f in sorted(m._f.items())}
        self._prec = {}
        self._cycles()

    # ------------------------------------------------------------------ reference extraction
    def _table_box(self, t, spec, cur):
        b = parse_box(t["ref"], t["sheet"])
        if not b:
            return None, "table range unreadable"
        sh, r1, c1, r2, c2 = b
        d1, d2 = r1 + t["header_rows"], r2 - t["totals_rows"]
        items = re.findall(r"\[([^\[\]]*)\]", spec) if spec.strip().startswith("[") else [spec]
        items = [i.strip() for i in items if i.strip()]
        cols = [i for i in items if not i.startswith("#")]
        special = {i.lower() for i in items if i.startswith("#")}
        rows = (r1, r2) if "#all" in special else (r1, r1) if "#headers" in special else (r2, r2) if "#totals" in special else (d1, d2)
        if "#this row" in special:
            if not (d1 <= cur[1] <= d2):
                return None, "#This Row outside the table"
            rows = (cur[1], cur[1])
        names = [c.lower() for c in t["columns"]]
        if not cols:
            return (sh, rows[0], c1, rows[1], c2), None
        try:
            idx = [names.index(c.replace("'", "").lower()) for c in cols]
        except ValueError:
            return None, "unknown table column"
        return (sh, rows[0], c1 + min(idx), rows[1], c1 + max(idx)), None

    def _operand(self, text, k, over_ctx, depth=0):
        """-> list of refs: {ref, kind, status, box?, via?, link?, identified?, over?}"""
        t = text.strip()
        cur = k[0]
        if "#REF!" in t.upper():
            return [{"ref": t, "kind": "error", "status": "MISSING", "why": "#REF! (a deleted reference)"}]
        e = EXT.match(t)
        if e:
            tok = e.group(1)
            l = self.links.get(int(tok)) if tok.isdigit() else next((x for x in self.links.values() if (x.get("target") or "").lower() == tok.lower()), None)
            return [{"ref": t, "kind": "external", "status": "EXTERNAL", "link": (l or {}).get("target") or tok,
                     "identified": bool(l and l.get("target")) or not tok.isdigit()}]
        if t.endswith("#"):                                       # spill reference A1#
            a = parse_box(t[:-1], cur)
            anchor = next((x for x in self.facts["per_sheet"].get(a[0] if a else "", {}).get("array_formulas", [])
                           if a and parse_box(x["cell"], a[0])[1:3] == a[1:3]), None) if a else None
            if anchor:
                return self._boxes([parse_box(anchor["ref"], a[0])], "spill", over_ctx)
            return [{"ref": t, "kind": "spill", "status": "UNSUPPORTED", "why": "spill reference without an array formula"}]
        s = STRUCT.match(t)
        if s and not re.match(r"^\$?[A-Z]{1,3}\$?\d", t):
            tname = (s.group(1) or "").lower()
            tbl = self.tables.get(tname) if tname else next((x for x in self.facts["tables"] if x["sheet"] == cur and
                                                            parse_box(x["ref"], cur) and parse_box(x["ref"], cur)[1] <= k[1] <= parse_box(x["ref"], cur)[3]), None)
            if not tbl:
                return [{"ref": t, "kind": "table", "status": "UNSUPPORTED", "why": "unknown table"}]
            box, why = self._table_box(tbl, s.group(2), k)
            if not box:
                return [{"ref": t, "kind": "table", "status": "UNSUPPORTED", "why": why}]
            return self._boxes([box], "table", over_ctx, via=t)
        d3 = THREE_D.match(t)
        if d3 and d3.group(1) in self.order and d3.group(2) in self.order:
            i, j = sorted((self.order.index(d3.group(1)), self.order.index(d3.group(2))))
            boxes = [parse_box(d3.group(3), sh) for sh in self.order[i:j + 1]]
            if all(boxes):
                return self._boxes(boxes, "3d", over_ctx)
        b = parse_box(t, cur)
        if b:
            real = self.m.sheet_lc.get((b[0] or "").lower())
            if not real:
                return [{"ref": t, "kind": "cell", "status": "MISSING", "why": f"sheet not in the workbook"}]
            return self._boxes([(real,) + b[1:]], None, over_ctx)
        nm = self.names.get(t.lower())
        if t.lower() in self.tables and not nm:
            tb = self.tables[t.lower()]
            return self._boxes([parse_box(tb["ref"], tb["sheet"])], "table", over_ctx, via=t)
        if nm and depth < 4:
            body = (nm["text"] or "").lstrip("=")
            parts = [p for p in re.split(r",(?=(?:[^']*'[^']*')*[^']*$)", body) if p.strip()]
            boxes = [parse_box(p) for p in parts]
            if parts and all(boxes):
                return [dict(r, via=nm["name"]) for r in self._boxes([(self.m.sheet_lc.get((x[0] or "").lower(), x[0]),) + x[1:] for x in boxes],
                                                                         "name", over_ctx)]
            sub = self._parse_formula("=" + body, k, depth + 1)       # a named formula: its own references
            return [dict(r, via=nm["name"]) for r in sub["refs"]] or [{"ref": t, "kind": "name", "status": "COMPLETE", "via": nm["name"],
                                                                         "why": "named constant"}]
        return [{"ref": t, "kind": "name", "status": "UNSUPPORTED", "why": "unresolved name"}]

    def _boxes(self, boxes, kind, over_ctx, via=None):
        out = []
        for bx in boxes:
            sh, r1, c1, r2, c2 = bx
            whole = r2 - r1 >= 1_000_000 or c2 - c1 >= 16_000
            multi = (r1, c1) != (r2, c2)
            st = "OVER_APPROXIMATED" if (whole or (multi and over_ctx)) else "COMPLETE"
            mr, mc = self.max_stored[sh]
            if self.m.skipped_cells.get(sh) and (r2 > mr + 2 or c2 > mc):
                st, why = "UNSUPPORTED", "referenced cells are on a sheet region the reader did not store"
            else:
                why = "whole column / row" if whole else "range read by a lookup or conditional function" if st == "OVER_APPROXIMATED" else None
            out.append({"ref": box_text(bx), "kind": kind or ("range" if multi else "cell"), "status": st, "box": list(bx),
                        **({"why": why} if why else {}), **({"via": via} if via else {})})
        return out

    def _parse_formula(self, f, k, depth=0):
        try:
            items = Tokenizer(f).items
        except Exception as e:
            return {"refs": [], "functions": [], "tokenize_error": f"{type(e).__name__}: {str(e)[:60]}", "literal_indirect": 0}
        refs, funcs, stack, lit = [], [], [], 0
        for i, t in enumerate(items):
            if t.type == Token.FUNC and t.subtype == Token.OPEN:
                nm = t.value[:-1].upper().replace("_XLFN.", "").replace("_XLWS.", "")
                funcs.append(nm)
                stack.append(nm)
                if nm == "INDIRECT" and i + 2 < len(items) and items[i + 1].type == Token.OPERAND and items[i + 1].subtype == Token.TEXT \
                        and items[i + 2].type == Token.FUNC and items[i + 2].subtype == Token.CLOSE:
                    lit += 1
                    refs += [dict(r, kind="indirect_literal") for r in self._operand(items[i + 1].value.strip('"'), k, False, depth)]
            elif t.type == Token.FUNC and t.subtype == Token.CLOSE:
                if stack:
                    stack.pop()
            elif t.type == Token.OPERAND and t.subtype == Token.RANGE:
                refs += self._operand(t.value, k, bool(OVER & set(stack)), depth)
            elif t.type == Token.OPERAND and t.subtype == Token.ERROR and t.value.upper().startswith("#REF"):
                refs.append({"ref": t.value, "kind": "error", "status": "MISSING", "why": "#REF! (a deleted reference)"})
        return {"refs": refs, "functions": sorted(set(funcs)), "tokenize_error": None, "literal_indirect": lit}

    def _node(self, k, f):
        p = self._parse_formula(f, k)
        refs = p["refs"]
        st = "UNSUPPORTED" if p["tokenize_error"] else "COMPLETE"
        for r in refs:
            if r["status"] in SEVERITY and SEVERITY[r["status"]] > SEVERITY[st]:
                st = r["status"]
        fn = set(p["functions"])
        dyn = ("DYNAMIC_UNRESOLVED" if ((fn & DYNAMIC) - {"INDIRECT"} or ("INDIRECT" in fn and p["literal_indirect"] == 0))
               else "DYNAMIC_RESOLVED" if "INDIRECT" in fn else "STATIC")
        ext = [r for r in refs if r["status"] == "EXTERNAL"]
        return {"cell": cell_text(*k), "refs": refs, "functions": p["functions"],
                "flags": {"references_extracted": st, "dynamic_resolution": dyn, "location": "EXTERNAL" if ext else "INTERNAL",
                          "external_identified": all(r.get("identified") for r in ext) if ext else None,
                          "cycle": "ACYCLIC", "value_verification": "NOT_RECOMPUTED"},
                "reasons": sorted({r["why"] for r in refs if r.get("why")} | ({p["tokenize_error"]} if p["tokenize_error"] else set()))}

    # ------------------------------------------------------------------ traversal
    def precedents(self, k):
        """cells a formula references (present cells only); a spill result cell leads to its anchor."""
        if k in self._prec:
            return self._prec[k]
        out = set()
        if k in self.arr:
            out.add(self.arr[k])
        n = self.nodes.get(k)
        for r in (n["refs"] if n else []):
            if r.get("box"):
                sh, r1, c1, r2, c2 = r["box"]
                out.update(self.m.cells_in(sh, r1, c1, r2, c2))
        out.discard(k)
        self._prec[k] = out
        return out

    def _cycles(self):
        """Tarjan's strongly connected components (iterative): formulas on a cycle are CIRCULAR."""
        idx, low, onstack, stack, counter = {}, {}, set(), [], [0]
        for root in self.nodes:
            if root in idx:
                continue
            work = [(root, iter(sorted(p for p in self.precedents(root) if p in self.nodes or p in self.arr)))]
            idx[root] = low[root] = counter[0]; counter[0] += 1
            stack.append(root); onstack.add(root)
            while work:
                v, it = work[-1]
                nxt = next(it, None)
                if nxt is not None:
                    w = self.arr.get(nxt, nxt) if nxt not in self.nodes else nxt
                    if w not in self.nodes:
                        continue
                    if w not in idx:
                        idx[w] = low[w] = counter[0]; counter[0] += 1
                        stack.append(w); onstack.add(w)
                        work.append((w, iter(sorted(p for p in self.precedents(w) if p in self.nodes or p in self.arr))))
                    elif w in onstack:
                        low[v] = min(low[v], idx[w])
                    continue
                work.pop()
                if work:
                    low[work[-1][0]] = min(low[work[-1][0]], low[v])
                if low[v] == idx[v]:
                    comp = []
                    while True:
                        w = stack.pop(); onstack.discard(w); comp.append(w)
                        if w == v:
                            break
                    if len(comp) > 1 or v in self.precedents(v):
                        for w in comp:
                            self.nodes[w]["flags"]["cycle"] = "CIRCULAR"

    def verify_values(self, keep_used_for=()):
        """re-computes each formula from its precedents' saved values (formula_eval); records contributing cells."""
        import formula_eval as FE
        self.contrib = {}
        keep = set(keep_used_for)
        for k, n in self.nodes.items():
            sv = self.m.v(k)
            if sv is None or not isinstance(sv, (int, float)) or isinstance(sv, bool):
                continue
            try:
                val, used = FE.evaluate(self.m, k)
            except Exception:
                continue
            ok = abs(val - sv) <= max(1e-6, 1e-9 * max(abs(val), abs(sv)))
            n["flags"]["value_verification"] = "RECOMPUTED" if ok else "MISMATCH"
            if ok and k in keep:
                self.contrib[k] = set(used)

    def closure(self, roots, contributing=False):
        seen, q = set(), [r for r in roots if r in self.m.cells or r in self.nodes]
        while q:
            k = q.pop()
            if k in seen:
                continue
            seen.add(k)
            nxt = self.contrib.get(k) if contributing and k in getattr(self, "contrib", {}) else self.precedents(k)
            q.extend(p for p in nxt if p not in seen)
        return seen

    def headline(self, root):
        """FULL: every formula upstream has complete (or resolved) references and stays internal or ends at an identified
        external workbook; PARTIAL: over-approximated or circular somewhere; UNKNOWN: missing, unsupported, dynamically
        unresolved or an unidentified external reference somewhere. Value verification is reported beside, not in it."""
        worst = "FULL"
        for k in self.closure([root]):
            n = self.nodes.get(k)
            if not n:
                continue
            f = n["flags"]
            if f["references_extracted"] in ("MISSING", "UNSUPPORTED") or f["dynamic_resolution"] == "DYNAMIC_UNRESOLVED" or \
                    (f["location"] == "EXTERNAL" and not f["external_identified"]):
                return "UNKNOWN"
            if f["references_extracted"] == "OVER_APPROXIMATED" or f["cycle"] == "CIRCULAR":
                worst = "PARTIAL"
        return worst

    # ------------------------------------------------------------------ regions, hubs, sinks
    def regions(self, material):
        dependents = defaultdict(int)
        for k in self.nodes:
            for p in self.precedents(k):
                dependents[p] += 1
        hubs = set()
        for p, n_ in dependents.items():
            v = self.m.v(p)
            if n_ >= RULES["hub_min_dependents"] and (isinstance(v, (datetime.date, datetime.datetime)) or
                                                       (p not in self.nodes and isinstance(v, (int, float, str)))):
                hubs.add(p)
        parent = {}

        def find(x):
            parent.setdefault(x, x)
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[max(ra, rb)] = min(ra, rb)
        for k in self.nodes:
            find(k)
            for p in self.precedents(k):
                if p not in hubs:
                    union(k, p)
        groups = defaultdict(list)
        for x in parent:
            groups[find(x)].append(x)
        out = []
        sort_key = lambda c: (self.order.index(c[0]) if c[0] in self.order else 999, c[1], c[2])
        for members in sorted(groups.values(), key=lambda g: sort_key(min(g, key=sort_key))):
            forms = [c for c in members if c in self.nodes]
            if not forms:
                continue
            sinks = sorted((c for c in forms if dependents.get(c, 0) == 0), key=sort_key)
            reached = [c for c in members if c in material]
            bbox = {}
            for (sh, r, c) in members:
                b = bbox.get(sh)
                bbox[sh] = (min(b[0], r), min(b[1], c), max(b[2], r), max(b[3], c)) if b else (r, c, r, c)
            cls = ("reached_from_outputs" if reached else "cannot_determine" if len(forms) >= RULES["region_min_formulas"] else "small_unreached")
            out.append({"id": f"G{len(out) + 1}", "cells": len(members), "formulas": len(forms), "typed_inputs": len(members) - len(forms),
                        "sheets": sorted(bbox, key=lambda s: self.order.index(s) if s in self.order else 999),
                        "areas": [box_text((sh, b[0], b[1], b[2], b[3])) for sh, b in sorted(bbox.items(), key=lambda t: self.order.index(t[0]) if t[0] in self.order else 999)],
                        "sinks": [cell_text(*c) for c in sinks[:20]], "sink_count": len(sinks),
                        "sink_labels": [self.m.row_label(c) for c in sinks[:3]],
                        "reached_cells": len(reached), "proposed": cls, "_members": members})
        out = self._merge_families(out, material, sort_key)
        return out, sorted(hubs), dependents

    def _merge_families(self, regs, material, sort_key):
        """unreached regions with the same sheets whose areas sit side by side with the same shape (e.g. one region per
        historical month column) are ONE family for review - every member cell is kept."""
        boxes = lambda r: {sh: parse_box(a)[1:] for sh, a in zip(r["sheets"], r["areas"])}
        def adjacent(a, b):
            A, B = boxes(a), boxes(b)
            if set(A) != set(B):
                return False
            for sh in A:
                (r1, c1, r2, c2), (s1, d1, s2, d2) = A[sh], B[sh]
                if not (((r1, r2) == (s1, s2) and (d1 == c2 + 1 or c1 == d2 + 1 or not (d2 < c1 or c2 < d1))) or
                        ((c1, c2) == (d1, d2) and (s1 == r2 + 1 or r1 == s2 + 1 or not (s2 < r1 or r2 < s1)))):
                    return False
            return True
        reached = [r for r in regs if r["proposed"] == "reached_from_outputs"]
        rest = [r for r in regs if r["proposed"] != "reached_from_outputs"]
        changed = True
        while changed:
            changed = False
            for i in range(len(rest)):
                for j in range(i + 1, len(rest)):
                    if adjacent(rest[i], rest[j]):
                        a, b = rest[i], rest.pop(j)
                        mem = a["_members"] + b["_members"]
                        bbox = {}
                        for (sh, r, c) in mem:
                            x = bbox.get(sh)
                            bbox[sh] = (min(x[0], r), min(x[1], c), max(x[2], r), max(x[3], c)) if x else (r, c, r, c)
                        forms = [c for c in mem if c in self.nodes]
                        a.update(_members=mem, cells=len(mem), formulas=len(forms), typed_inputs=len(mem) - len(forms),
                                 areas=[box_text((sh, *bbox[sh])) for sh in a["sheets"]], sinks=sorted(set(a["sinks"] + b["sinks"]))[:20],
                                 sink_count=a["sink_count"] + b["sink_count"], family=a.get("family", 1) + b.get("family", 1),
                                 proposed="cannot_determine" if len(forms) >= RULES["region_min_formulas"] else "small_unreached")
                        changed = True
                        break
                if changed:
                    break
        out = sorted(reached + rest, key=lambda r: sort_key(min(r["_members"], key=sort_key)))
        for i, r in enumerate(out, 1):
            r["id"] = f"G{i}"
        return out
