# common/forms.py (build 11.6) - ONE layout for the answer form, used for the analyst's form and for the program's own
# answers, so the two can be compared line by line. Layout only: nothing here decides an answer.
KEY_NUMBERS = [
    ("enterprise_value", "Enterprise value", "The final enterprise value of the quarter being valued"),
    ("equity_value", "Equity value", "Enterprise value after debt, cash and other adjustments"),
    ("value_to_xpv", "XPV's value", "XPV's share - the number that goes into the investor (LP) report"),
    ("valuation_metric", "Earnings figure used", "The earnings (or revenue) figure the multiple is applied to, e.g. adjusted EBITDA"),
    ("selected_multiple", "Multiple applied", "The multiple actually used (not one of the comparable companies)"),
]
MONTHS = [("metric_first_month", "First month the earnings figure covers", "e.g. 2025-04"),
          ("metric_last_month", "Last month the earnings figure covers", "e.g. 2026-03")]
METHODS = {"EV/EBITDA multiple": "ev_ebitda", "EV/Revenue multiple": "ev_revenue", "Blend of multiples": "blended",
           "Held at cost": "held_at_cost", "Other": "other"}
METHOD_OF_VARIANT = {"ev_ebitda": "EV/EBITDA multiple", "ev_revenue": "EV/Revenue multiple", "blended": "Blend of multiples",
                     "weighted_methods": "Blend of multiples", "held_at_cost": "Held at cost"}
AREA_KINDS = ["Current quarter's valuation", "Monthly figures used by the valuation", "Old history",
              "Scratch or working area", "Presentation or report page", "Not sure"]
SHOULD_BE_USED = {"Current quarter's valuation": True, "Monthly figures used by the valuation": True, "Old history": False,
                  "Scratch or working area": False, "Presentation or report page": False}
CELL_COLUMNS = ["Sheet", "Cell", "Formula", "Value", "Type"]          # the cell export, identical for Excel and the program
USES_COLUMNS = ["Sheet", "Cell", "Uses", "Note"]


def write_form(path, header, answers=None, title="Answer form", who="analyst"):
    """the workbook the analyst fills in - or, with answers, the program's own answers in the same layout."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.worksheet.datavalidation import DataValidation
    bold, grey, yellow = Font(bold=True), PatternFill("solid", fgColor="EEEEEE"), PatternFill("solid", fgColor="FFF2CC")
    wb = Workbook()
    s = wb.active
    s.title = "Start here"
    lines = [title, ""] + [f"{k}: {v}" for k, v in header.items()] + [""]
    if who == "analyst":
        lines += ["What to do",
                  "1. Fill in the yellow boxes on '1 Key numbers' and '2 Areas'. Use only the workbook itself.",
                  "2. Do not look at anything the program produced until you have saved your answers.",
                  "3. Give the cell that holds the NUMBER, not the cell with its name.",
                  "   Example: if row 4 shows 'Adjusted EBITDA' in A4 and 2,754,000 in B4, write Sheet = Valuation and Cell = B4.",
                  "4. Write the sheet name exactly as it appears on the tab at the bottom of Excel.",
                  "5. Months are written year-month, e.g. 2026-03 for March 2026.",
                  "6. On '2 Areas', add one row per area you know about. Leave 'Cells' empty to mean the whole sheet.",
                  "   Examples: Sheet = Valuation, Cells = F5:F40, What it is = Current quarter's valuation, Month = 2026-03",
                  "             Sheet = Monthly, Cells = B5:M40, What it is = Old history",
                  "7. If you are not sure about something, leave it empty or choose 'Not sure'. Guessing is worse than leaving it."]
    else:
        lines += ["These are the program's answers, in the same layout as the analyst's form.",
                  "Do not show them to the analyst before the analyst's answers are saved."]
    for ln in lines:
        s.append([ln])
    s["A1"].font = Font(bold=True, size=14)
    s.column_dimensions["A"].width = 120
    k = wb.create_sheet("1 Key numbers")
    k.append(["Item", "What we mean", "Sheet", "Cell with the NUMBER", "Notes"])
    for c in k[1]:
        c.font, c.fill = bold, grey
    a = answers or {}
    for key, label, meaning in KEY_NUMBERS:
        v = (a.get("key_numbers") or {}).get(key) or {}
        k.append([label, meaning, v.get("sheet"), v.get("cell"), v.get("notes")])
    k.append([])
    k.append(["Item", "What we mean", "Answer", None, "Notes"])
    for c in k[k.max_row]:
        c.font, c.fill = bold, grey
    for key, label, ex in MONTHS:
        k.append([label, ex, (a.get("months") or {}).get(key), None, None])
    k.append(["Valuation method", "Pick from the list", a.get("method"), None, a.get("method_notes")])
    dv = DataValidation(type="list", formula1=f'"{",".join(METHODS)}"', allow_blank=True)
    k.add_data_validation(dv)
    dv.add(f"C{k.max_row}")
    for r in list(range(2, 2 + len(KEY_NUMBERS))):
        for col in "CD":
            k[f"{col}{r}"].fill = yellow
            k[f"{col}{r}"].number_format = "@"              # text: Excel must not turn B4 or 2026-03 into something else
    for r in range(k.max_row - 2, k.max_row + 1):
        k[f"C{r}"].fill = yellow
        k[f"C{r}"].number_format = "@"
    for col, w in zip("ABCDE", (34, 70, 26, 22, 40)):
        k.column_dimensions[col].width = w
    ar = wb.create_sheet("2 Areas")
    ar.append(["Sheet", "Cells (empty = whole sheet)", "What it is", "Month it shows (only if it is all one month)", "Notes"])
    for c in ar[1]:
        c.font, c.fill = bold, grey
    for x in (a.get("areas") or []):
        ar.append([x.get("sheet"), x.get("cells"), x.get("what"), x.get("month"), x.get("notes")])
    dv2 = DataValidation(type="list", formula1=f'"{",".join(AREA_KINDS)}"', allow_blank=True)
    ar.add_data_validation(dv2)
    dv2.add("C2:C200")
    for col, w in zip("ABCDE", (26, 28, 38, 36, 50)):
        ar.column_dimensions[col].width = w
    if who == "analyst":
        for r in range(2, 16):
            for col in "ABCD":
                ar[f"{col}{r}"].fill = yellow
                ar[f"{col}{r}"].number_format = "@"
    wb.save(path)


def month_text(v):
    """'2026-03', a date Excel made from it, or '2026-03-31' -> '2026-03'; anything else is returned as typed (for the check)."""
    import datetime
    if v is None or v == "":
        return None
    if isinstance(v, (datetime.datetime, datetime.date)):
        return f"{v.year}-{v.month:02d}"
    s = str(v).strip()
    import re
    m = re.match(r"^(\d{4}-\d{2})(-\d{2})?([ T].*)?$", s)
    return m.group(1) if m else s


def read_form(path):
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True)
    head = {}
    for row in wb["Start here"].iter_rows(values_only=True):
        if row and isinstance(row[0], str) and ": " in row[0]:
            kk, _, vv = row[0].partition(": ")
            head[kk] = vv
    rows = list(wb["1 Key numbers"].iter_rows(values_only=True))
    kn, months, method = {}, {}, None
    labels = {lab: key for key, lab, _ in KEY_NUMBERS}
    mlabels = {lab: key for key, lab, _ in MONTHS}
    for r in rows:
        if not r or not r[0]:
            continue
        if r[0] in labels:
            kn[labels[r[0]]] = {"sheet": (str(r[2]).strip() if r[2] is not None else None), "cell": (str(r[3]).strip().upper().replace("$", "") if r[3] is not None else None),
                                "notes": r[4]}
        elif r[0] in mlabels:
            months[mlabels[r[0]]] = month_text(r[2])
        elif r[0] == "Valuation method":
            method = r[2]
    areas = []
    for i, r in enumerate(list(wb["2 Areas"].iter_rows(values_only=True))[1:], 2):
        if r and (r[0] or r[2]):
            areas.append({"row": i, "sheet": str(r[0]).strip() if r[0] else None, "cells": str(r[1]).strip().upper().replace("$", "") if r[1] else None,
                          "what": r[2], "month": month_text(r[3]), "notes": r[4]})
    return {"header": head, "key_numbers": kn, "months": months, "method": method, "areas": areas}
