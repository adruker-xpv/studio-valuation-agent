# common/preflight.py (build 11.5) - can this file be read at all? Checked BEFORE any parsing, so an unreadable file is a
# clear STOPPED line with what to do, never a traceback. Physical checks only - nothing about meaning.
import os, zipfile
from common.util import Stop

OLE = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"          # compound file: legacy .xls, or an encrypted / password-protected workbook
LIMITS = {"max_file_mb": 200, "max_uncompressed_mb": 2000, "warn_file_mb": 25}


def check_workbook(path, limits=None):
    """-> {'kind', 'bytes', 'parts', 'macros', 'external_link_parts', 'warnings'} or raises Stop."""
    L = dict(LIMITS, **(limits or {}))
    name = os.path.basename(path)
    if not os.path.isfile(path):
        raise Stop(f"PREFLIGHT: REFUSED {name}: the file does not exist", "preflight")
    size = os.path.getsize(path)
    if size == 0:
        raise Stop(f"PREFLIGHT: REFUSED {name}: the file is empty (a failed download?): fetch it again", "preflight")
    ext = os.path.splitext(name)[1].lower()
    with open(path, "rb") as fh:
        head = fh.read(8)
    if head == OLE:
        why = ("a legacy .xls workbook: open it in Excel and save it as .xlsx" if ext == ".xls" else
               "encrypted or password-protected: remove the password in Excel (File > Info > Protect Workbook), save, and try again")
        raise Stop(f"PREFLIGHT: REFUSED {name}: {why}", "preflight")
    if ext == ".xlsb":
        raise Stop(f"PREFLIGHT: REFUSED {name}: a binary workbook (.xlsb) cannot be read here: save it as .xlsx", "preflight")
    if ext not in (".xlsx", ".xlsm"):
        raise Stop(f"PREFLIGHT: REFUSED {name}: '{ext or 'no extension'}' is not an Excel workbook (.xlsx or .xlsm)", "preflight")
    if size > L["max_file_mb"] * 1e6:
        raise Stop(f"PREFLIGHT: REFUSED {name}: {size / 1e6:.0f} MB is above the {L['max_file_mb']} MB limit for this environment", "preflight")
    try:
        with zipfile.ZipFile(path) as z:
            bad = z.testzip()
            infos = z.infolist()
            names = {i.filename for i in infos}
    except zipfile.BadZipFile:
        raise Stop(f"PREFLIGHT: REFUSED {name}: the file is damaged (not a valid workbook package): fetch it again or re-save it in Excel", "preflight")
    if bad:
        raise Stop(f"PREFLIGHT: REFUSED {name}: part '{bad}' is damaged: re-save the workbook in Excel", "preflight")
    if "xl/workbook.xml" not in names:
        raise Stop(f"PREFLIGHT: REFUSED {name}: no workbook part inside: this is not an Excel workbook", "preflight")
    unz = sum(i.file_size for i in infos)
    if unz > L["max_uncompressed_mb"] * 1e6:
        raise Stop(f"PREFLIGHT: REFUSED {name}: {unz / 1e6:.0f} MB uncompressed is above the {L['max_uncompressed_mb']} MB limit", "preflight")
    warnings = []
    if size > L["warn_file_mb"] * 1e6:
        warnings.append(f"large file ({size / 1e6:.0f} MB): discovery may be slow")
    links = sum(1 for n in names if n.startswith("xl/externalLinks/externalLink"))
    return {"kind": ext[1:], "bytes": size, "uncompressed_bytes": unz, "parts": len(names), "macros": "xl/vbaProject.bin" in names,
            "external_link_parts": links, "warnings": warnings}
