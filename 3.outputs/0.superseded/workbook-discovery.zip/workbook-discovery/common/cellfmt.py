# common/cellfmt.py (build 11.6) - how one cell is WRITTEN in the cell exports (Excel's and the program's), so the two
# files line up and can be diffed. Representation only. The comparison itself parses numbers from both sides and compares
# them numerically, so a formatting slip here cannot hide a real difference.
import datetime
EPOCH = datetime.datetime(1899, 12, 30)


def excel_number(v):
    """dates as Excel serial numbers (Excel keeps dates as numbers); numbers in shortest round-trip form."""
    if isinstance(v, datetime.datetime):
        v = (v - EPOCH).total_seconds() / 86400
    elif isinstance(v, datetime.date):
        v = (datetime.datetime.combine(v, datetime.time()) - EPOCH).days
    f = float(v)
    return str(int(f)) if f.is_integer() and abs(f) < 1e15 else repr(f)


def formula_text(f):
    """what Excel shows in the formula bar: no internal _xlfn. / _xlws. prefixes."""
    if not f:
        return ""
    for p in ("_xlfn._xlws.", "_xlfn.", "_xlws.", "_xludf."):
        f = f.replace(p, "")
    return f if f.startswith("=") else "=" + f


def value_and_type(v):
    if v is None:
        return "", "empty"
    if isinstance(v, bool):
        return ("TRUE" if v else "FALSE"), "boolean"
    if isinstance(v, (int, float, datetime.date, datetime.datetime)):
        return excel_number(v), "number"
    s = str(v)
    if s.startswith("#") and (s.endswith("!") or s.endswith("?") or s in ("#N/A", "#NULL!", "#NUM!", "#VALUE!", "#REF!", "#NAME?", "#DIV/0!",
                                                                         "#SPILL!", "#CALC!", "#GETTING_DATA", "#FIELD!", "#BLOCKED!", "#CONNECT!", "#BUSY!")):
        return s, "error"
    return s, "text"
