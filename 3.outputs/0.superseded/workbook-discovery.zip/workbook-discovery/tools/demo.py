# demo.py (build 11.6) - see the whole process and its reports in about a minute, on a made-up workbook (no real data):
# the program reads the workbook, a stand-in for Excel's export is made, an "analyst" fills the form (first with a typical
# mistake, which check-form catches), the answers are saved, and the comparison report is produced.
import os, shutil, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path[:0] = [PKG, os.path.join(PKG, "tests"), os.path.join(PKG, "discovery", "vp")]
from common.files import out_root
from common.forms import write_form, read_form


def run(args, cwd):
    p = subprocess.run([sys.executable] + args, cwd=cwd, capture_output=True, text=True, env=dict(os.environ, VALUATION_FILE_ROOTS=cwd))
    return p.returncode, p.stdout.strip()


def fill(path, ev_cell, areas=True):
    from openpyxl import load_workbook
    wb = load_workbook(path)
    k = wb["1 Key numbers"]
    answers = {"Enterprise value": ("Valuation Summary", ev_cell), "Equity value": ("Valuation Summary", "C14"),
               "XPV's value": ("Valuation Summary", "C16"), "Earnings figure used": ("Valuation Summary", "C8"),
               "Multiple applied": ("Valuation Summary", "C10")}
    for row in k.iter_rows(min_row=2):
        lab = row[0].value
        if lab in answers:
            row[2].value, row[3].value = answers[lab]
        elif lab == "First month the earnings figure covers":
            row[2].value = "2025-04"
        elif lab == "Last month the earnings figure covers":
            row[2].value = "2026-03"
        elif lab == "Valuation method":
            row[2].value = "EV/EBITDA multiple"
    a = wb["2 Areas"]
    for r in ([] if not areas else (["Valuation Summary", "C5:C16", "Current quarter's valuation", "2026-03"], ["Valuation Summary", "B5:B16", "Old history", "2024-12"],
              ["Monthly", "B4:M13", "Old history", None])):
        a.append(r)
    wb.save(path)


def main():
    import vp_fixtures as FX
    d = out_root("demo")
    for f in os.listdir(d):
        p = os.path.join(d, f)
        shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
    wb = os.path.join(d, "Demo Water - Q1 2026 valuation.xlsx")
    FX.factory_workbook(wb, older=(2024, 12))
    print("DEMO: 1 made a sample workbook with two quarters side by side (Dec 2024 and Mar 2026)")
    rc, o = run([os.path.join(PKG, "benchmark", "bench.py"), "form", "--workbook", os.path.basename(wb), "--quarter-end", "2026-03-31",
                 "--out", os.path.join(d, "answer_form.xlsx")], d)
    fill(os.path.join(d, "answer_form.xlsx"), "A11")          # the typical mistake: the label cell instead of the number
    rc, o = run([os.path.join(PKG, "benchmark", "bench.py"), "check-form", "--form", "answer_form.xlsx", "--workbook", os.path.basename(wb)], d)
    print("DEMO: 2 the analyst wrote A11 (the label) for enterprise value; check-form says:")
    print("\n".join("      " + l for l in o.splitlines()))
    fill(os.path.join(d, "answer_form.xlsx"), "C11", areas=False)
    rc, o = run([os.path.join(PKG, "benchmark", "bench.py"), "save-answers", "--form", "answer_form.xlsx", "--workbook", os.path.basename(wb),
                 "--by", "Demo Analyst", "--out", os.path.join(d, "analyst_answers.json")], d)
    print("DEMO: 3 corrected to C11 and saved: " + o.splitlines()[-1][:80])
    rc, o = run([os.path.join(PKG, "discovery", "discover.py"), "--workbook", os.path.basename(wb), "--period-end", "2026-03-31",
                 "--out", os.path.join(d, "program")], d)
    print("DEMO: 4 the program read the workbook (its answers: demo/program/program_answers.xlsx)")
    sys.path.insert(0, HERE)
    import excel_standin
    excel_standin.build(wb, os.path.join(d, "Demo Water - Q1 2026 valuation - export.xlsx"))
    print("DEMO: 5 made a STAND-IN for Excel's export (in real use, the excel-export script in Excel makes this)")
    rc, o = run([os.path.join(PKG, "benchmark", "bench.py"), "compare", "--program", os.path.join(d, "program"),
                 "--excel-export", "Demo Water - Q1 2026 valuation - export.xlsx", "--answers", "analyst_answers.json",
                 "--out", os.path.join(d, "comparison")], d)
    print("DEMO: 6 compared - the summary lines you would send:")
    print("\n".join("      " + l for l in o.splitlines() if l.startswith("BENCHMARK:")))
    print(f"DEMO: open {os.path.join('demo', 'comparison', 'comparison.xlsx')} to see the full report, and diff "
          "demo/comparison/excel_cells.csv against demo/comparison/program_cells.csv")
    return 0 if rc == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
