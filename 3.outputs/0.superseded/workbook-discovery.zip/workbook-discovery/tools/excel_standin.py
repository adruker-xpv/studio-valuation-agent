# excel_standin.py (build 11.6) - a STAND-IN for the excel-export script, for the synthetic tests and the demo only.
# Real benchmarks always use Excel's own export. This reads the workbook with openpyxl and lists what formulas use with
# a deliberately simple text scan (not the program's parser). It writes a file shaped exactly like Excel's export.
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from common.cellfmt import formula_text, value_and_type
from common.util import col_let, col_idx

REF = re.compile(r"(?<![A-Za-z0-9_.])(?:(?:'((?:[^']|'')+)'|([A-Za-z_][A-Za-z0-9_.]*))(!))?\$?([A-Z]{1,3})\$?(\d+)(?::\$?([A-Z]{1,3})\$?(\d+))?(?![A-Za-z0-9_(])")


def _r1c1(f, r, c):
    def rep(m):
        out = (m.group(1) or m.group(2) or "") + (m.group(3) or "")
        for col, row in ((m.group(4), m.group(5)), (m.group(6), m.group(7))):
            if col:
                out += f"R[{int(row) - r}]C[{col_idx(col) - c}]" + ("" if col == m.group(6) else "")
        return out
    return REF.sub(rep, f)


def build(src, dst, uses_override=None):
    from openpyxl import load_workbook, Workbook
    wf = load_workbook(src, read_only=True)
    wv = load_workbook(src, read_only=True, data_only=True)
    out = Workbook()
    info = out.active
    info.title = "XLX Info"
    info.append(["Excel export", "STAND-IN (tests / demo only - not Excel)"])
    info.append(["Workbook", os.path.basename(dst)])
    info.append(["Status", "Finished"])
    for _ in range(6):                          # rows 4-9 empty: the table starts on row 10, as excel-export.ts writes it
        info.append([])
    info.append(["Sheet", "Visibility", "Rows total", "Rows done", "Cells exported", "Patterns total", "Patterns checked", "Done"])
    cells, uses = out.create_sheet("XLX Cells"), out.create_sheet("XLX Uses")
    cells.append(["Sheet", "Cell", "Formula", "Value", "Type"])
    uses.append(["Sheet", "Cell", "Uses", "Note"])
    for name in wf.sheetnames:
        info.append([name, "Visible", "", "", "", "", "", "yes"])
        vals = {}
        for row in wv[name].iter_rows():
            for c in row:
                if getattr(c, "row", None) and c.value is not None:
                    vals[(c.row, c.column)] = c.value
        seen = set()
        for row in wf[name].iter_rows():
            for c in row:
                if not getattr(c, "row", None):
                    continue
                f = c.value
                f = ("=" + f.text.lstrip("=")) if hasattr(f, "text") else f
                isf = isinstance(f, str) and f.startswith("=")
                v = vals.get((c.row, c.column))
                if not isf and v is None:
                    continue
                val, typ = value_and_type(v)
                addr = f"{col_let(c.column)}{c.row}"
                cells.append([name, addr, formula_text(f) if isf else "", val, typ])
                for cc in cells[cells.max_row]:
                    cc.data_type = "s"                    # stored as TEXT, as excel-export.ts does with the Text format
                if isf:
                    pat = _r1c1(f, c.row, c.column)
                    if pat in seen:
                        continue
                    seen.add(pat)
                    if uses_override is not None and (name, addr) in uses_override:
                        u = uses_override[(name, addr)]
                    else:
                        u = "; ".join(_refs(f, name))
                    uses.append([name, addr, u, ""])
                    for cc in uses[uses.max_row]:
                        cc.data_type = "s"
    out.save(dst)
    return dst


def _refs(f, sheet):
    out = []
    for m in REF.finditer(f.replace("$", "")):
        if "[" in f[max(0, m.start() - 3):m.start()]:
            continue
        sh = (m.group(1) or m.group(2)) if m.group(3) else None
        q = sh.replace("''", "'") if sh else sheet
        qs = f"'{q}'" if re.search(r"[^A-Za-z0-9_]", q) else q
        a = f"{m.group(4)}{m.group(5)}" + (f":{m.group(6)}{m.group(7)}" if m.group(6) else "")
        out.append(f"{qs}!{a}")
    return out


if __name__ == "__main__":
    print(build(sys.argv[1], sys.argv[2]))
