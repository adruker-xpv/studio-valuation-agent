# release.py (build 11.5) - the only way a release zip is made:
#   1. every test passes (tests/run_tests.py)      2. the package check passes (junk, nested skills, size, deny-list)
#   3. a deterministic zip is written               4. RELEASE_MANIFEST.json: version, test result, SHA-256 of every file
# python tools/release.py [--deny-list terms.txt] --out <folder>
import argparse, hashlib, json, os, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)
sys.path.insert(0, PKG)
from common.util import VERSION


def main():
    ap = argparse.ArgumentParser(prog="release.py")
    ap.add_argument("--out", required=True)
    ap.add_argument("--deny-list", default=None)
    a = ap.parse_args()
    t = subprocess.run([sys.executable, os.path.join(PKG, "tests", "run_tests.py")], capture_output=True, text=True)
    last = (t.stdout.strip().splitlines() or ["(no output)"])[-1]
    if t.returncode != 0:
        print(t.stdout[-3000:])
        print(f"RELEASE: REFUSED - tests failed ({last})")
        return 1
    os.makedirs(a.out, exist_ok=True)
    z = os.path.join(a.out, "workbook-discovery.zip")
    cmd = [sys.executable, os.path.join(HERE, "check_package.py"), PKG, "--zip-out", z] + (["--deny-list", a.deny_list] if a.deny_list else [])
    c = subprocess.run(cmd, capture_output=True, text=True)
    if c.returncode != 0:
        print(c.stdout[-2000:])
        print("RELEASE: REFUSED - package check failed")
        return 1
    files = {}
    for root, dirs, fs in os.walk(PKG):
        dirs[:] = sorted(d for d in dirs if d != "__pycache__")
        for f in sorted(fs):
            p = os.path.join(root, f)
            files[os.path.relpath(p, PKG).replace(os.sep, "/")] = hashlib.sha256(open(p, "rb").read()).hexdigest()
    man = {"package": "workbook-discovery", "version": VERSION, "tests": last, "package_check": c.stdout.strip().splitlines()[0],
           "zip_sha256": hashlib.sha256(open(z, "rb").read()).hexdigest(), "files": files}
    json.dump(man, open(os.path.join(a.out, "RELEASE_MANIFEST.json"), "w"), indent=1, sort_keys=True)
    print(f"RELEASE: workbook-discovery {VERSION} | {last} | {len(files)} files | zip {man['zip_sha256'][:16]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
