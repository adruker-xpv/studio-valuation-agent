---
name: valuation-pipeline
description: One-command valuation pipeline for companies that already have a valuation workbook. Onboards a workbook (structure, key outputs, material inputs, statement rules discovered by reproduction, mapping profile), then replays, backtests or refreshes it from new financial statements, checks the Excel-recalculated result, and writes one ranked review list. Use for any workbook mapping, onboarding, replay, backtest, certification, quarterly refresh or pipeline self-test request.
---

# Valuation pipeline

`scripts/pipeline.py` runs every deterministic stage and carries state between them. You do three
things only: write the judgment files it asks for, hand over the Excel step, and post its final
report. Never open, re-read or summarise intermediate files; never run the stage scripts yourself.

## Commands (copy exactly; <out> is /app/created)
| Job | Command |
|---|---|
| Self-test | `python scripts/pipeline.py selftest` |
| Onboard a workbook | `python scripts/pipeline.py onboard --workbook "<workbook>" --statements <files...> [--input-map "<saved input map>"] [--company "<name>"] [--period-end YYYY-MM-DD]` |
| Replay / backtest / refresh | `python scripts/pipeline.py run --mode replay\|backtest\|refresh --workbook "<workbook>" --statements <files...> --bundle "<Company>_company_files.zip" [--actual "<actual workbook>"] [--period-end YYYY-MM-DD] [--manual /app/created/manual_inputs.json]` (or `--input-map` and `--profile` [and `--certification`] instead of `--bundle`) |
| After the Excel step | `python scripts/pipeline.py check --saved "<uploaded saved file>" [--certify "<name>"]` |
| After the Excel step, in a NEW chat | same, plus `--resume "<uploaded ..._resume.json>"` (upload the files it names too) |

Backtest: --workbook = the prior quarter's final, --actual = the analyst's real workbook for the new quarter.
The company files travel as one zip, `<Company>_company_files.zip` (input map, profile, certification): the user
uploads it with the workbook and statements. SharePoint file reads return text, not files, so never try to load
company files from SharePoint into the sandbox.
Refresh: --workbook = last quarter's final, --certification required. A missing file: say which and stop.

## Exit codes and what to do
- **10 JUDGMENT NEEDED**: write the named file in /app/created, then re-run the SAME command. If nothing needs
  judgment the pipeline does not stop. Save the files on any `SAVE (to resume ...)` line before continuing.
  - `key_outputs.json`: start from `key_outputs_suggested.json` (a deterministic draft, including likely check
    cells); fix it using the shortlist in `judgment_key_outputs.md`. Search the schema only if a metric is missing.
  - `classifications.json`: `{"accept_suggestions": true, "classifications": [...]}` with one entry per id
    in `needs_judgment` of `judgment_classifications.json` (fields that differ from its suggestion only).
    Rules: `references/classification-rules.md`. Unknown meaning stays `uncertain`; never guess.
- **20 EXCEL STEP**: save the files on the `SAVE (to resume ...)` line, return the draft with
  `references/excel-step.md`, and end your turn.
- **3 STOPPED** (plan refused or blocked): post the printed reasons as one list; do not do the Excel step.
- **0 DONE**: carry out every `SHAREPOINT:` line exactly (see Saving), then post the printed report section unchanged.

## Saving (the `SHAREPOINT:` lines)
Each line gives the exact tool and inputs; copy them, do not work them out. The site is the fixed Site Address.
- `Create new folder | library: Documents | path: ...` -> Create new folder with those values (skip if it exists).
- `Create file | folderPath: ... | name: ... | body: /app/created/<file>` -> Create file with the body set to that
  path, exactly. Never read, paste, encode (base64) or retype file content; never save from another folder.
- Create file replaces an existing file of the same name (SharePoint keeps the old one as a version), so never use
  Update file.
- `SKIP` lines: return those files as downloads and say so.
- A "Connection Required" card or any failure: say in one line which files were not saved and that the user should
  select Set up connection, then Retry. Never end the turn silently.
- **1 ERROR**: show the error lines and stop.

## Corrections at the end (only when the user replies to a finished run)
- Meaning or type of an input ("Inputs!B6 is a management adjustment factor"): add that id to
  classifications.json with the user's words in `notes`, confidence high; re-run `onboard` with the same
  files. "Confirm all - reviewed by <name>": add `"reviewed_by_all": "<name>"`, re-run `onboard`.
- A statement rule or write mode ("revenue is the sum of monthly Total Revenue"): write
  `concept_overrides.json` (`{"concepts": [{"concept_id": ..., "execution": {...}}]}`, format in
  `references/profile-fields.md`); re-run `onboard`.
- Key outputs or controls: edit key_outputs.json; re-run `onboard`.
- Manual inputs for a refresh: write `manual_inputs.json` as `{"values": {"Inputs!B3": 9.0}}`, numbers
  copied exactly from the user; re-run `run`.
- Certify or approve only when the user's latest message says so and names the person.

## Rules
- Never calculate, estimate or adjust numbers; never write code to read or fill workbooks.
- Do not narrate stages. Post only the final report section the pipeline prints.
