# run_pipeline_selftest.py - end-to-end check of pipeline.py in THIS sandbox (fixtures stand in for the Excel step)
import os, sys, subprocess, tempfile, shutil
HERE = os.path.dirname(os.path.abspath(__file__)); PIPE = os.path.join(HERE, "..", "scripts", "pipeline.py")
F = os.path.join(HERE, "fixtures")


def run(*args):
    p = subprocess.run([sys.executable, PIPE] + list(args), capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


def main():
    t = tempfile.mkdtemp(); o = os.path.join(t, "o"); cases = []
    d = lambda n: os.path.join(F, "demo", n); pf = lambda n: os.path.join(F, "pipeline", n)
    base = os.path.join(t, "tricky_valuation.xlsx"); shutil.copy(d("base_q2.xlsx"), base)
    ob = ["onboard", "--workbook", base, "--statements", d("src_q2_statements.xlsx"), "--out", o, "--company", "Test Co"]
    rc, out = run(*ob)
    cases.append(("onboard stops once for key outputs", rc == 10 and "key_outputs.json" in out))
    shutil.copy(pf("key_outputs.json"), os.path.join(o, "key_outputs.json"))
    rc, out = run(*ob)
    cases.append(("classification judgment needed for 1 of 8 blocks only", rc == 10 and "1 of 8" in out))
    open(os.path.join(o, "classifications.json"), "w").write('{"accept_suggestions": true, "classifications": []}')
    rc, out = run(*ob)
    cases.append(("onboard completes: profile REVIEW_REQUIRED (unlabelled input)", rc == 0 and "Mapping profile: REVIEW_REQUIRED" in out))
    im, pr = os.path.join(o, "tricky_valuation_input_map.json"), os.path.join(o, "mapping_profile.json")
    rp = ["run", "--mode", "replay", "--workbook", base, "--statements", d("src_q2_statements.xlsx"), "--input-map", im, "--profile", pr, "--out", o]
    rc, out = run(*rp)
    cases.append(("replay reaches the Excel step", rc == 20 and "PLAN STATUS: READY" in out))
    rc, out = run("check", "--saved", d("replay_saved_by_excel.xlsx"), "--certify", "Test Analyst", "--out", o)
    cases.append(("certification refused while meaning is unresolved", "REPLAY_PASS" in out and "status REPLAY_PASSED" in out))
    shutil.copy(pf("classifications_after_review.json"), os.path.join(o, "classifications.json"))
    rc, out = run(*ob)
    cases.append(("analyst answer -> profile INPUT_REQUIRED, business review CONFIRMED",
                  "Mapping profile: INPUT_REQUIRED" in out and "business review CONFIRMED" in out))
    run(*rp)
    rc, out = run("check", "--saved", d("replay_saved_by_excel.xlsx"), "--certify", "Test Analyst", "--out", o)
    cases.append(("replay certified", "status CERTIFIED" in out))
    rc, out = run("run", "--mode", "refresh", "--workbook", d("replay_saved_by_excel.xlsx"), "--statements", d("src_q3_statements.xlsx"),
                  "--input-map", im, "--profile", pr, "--certification", os.path.join(o, "certification.json"),
                  "--period-end", "2026-09-30", "--out", o)
    cases.append(("refresh without manual values: INPUT_REQUIRED, not blocked", rc == 20 and "PLAN STATUS: INPUT_REQUIRED" in out))
    rc, out = run("check", "--saved", d("refresh_saved_by_excel.xlsx"), "--out", o)
    cases.append(("refresh check ranks the SG&A spike first", "DRAFT_READY_FOR_REVIEW" in out and
                  out.index("Quarterly!E4") < out.index("carried forward")))
    ok = all(c[1] for c in cases)
    print(f"PIPELINE SELFTEST: {'PASS' if ok else 'FAIL'}")
    for n, p in cases:
        print(f"- {'PASS' if p else 'FAIL'}: {n}")
    shutil.rmtree(t, ignore_errors=True)
    sys.exit(0 if ok else 1)


main()
