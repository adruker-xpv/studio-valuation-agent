# pipeline.py - one command per job; carries all state between stages (deterministic)
#
#   python scripts/pipeline.py selftest
#   python scripts/pipeline.py onboard --workbook W --statements S [S ...] [--input-map M] [--company NAME] [--period-end YYYY-MM-DD]
#   python scripts/pipeline.py run --mode replay|backtest|refresh --workbook W --statements S [S ...]
#                                  --bundle <Company>_company_files.zip (or --input-map M --profile P [--certification C])
#                                  [--actual A] [--period-end D] [--manual J]
#   python scripts/pipeline.py check --saved F [--certify NAME] [--resume <mode>_resume.json]   (after the Excel step;
#                                  --resume in a NEW chat, with the files the resume file names re-uploaded)
#
# Exit codes: 0 done | 10 JUDGMENT NEEDED (write the named file, re-run the SAME command) | 20 EXCEL STEP | 1 error
# Judgment files (the only things the agent writes), all in the output folder:
#   key_outputs.json       references/key-output-rules.md
#   classifications.json   {"accept_suggestions": true, "classifications": [entries for needs_judgment ids only],
#                           "reviewed_by_all": "<name>" (only when the user confirms everything)}
#   concept_overrides.json optional, only for analyst corrections: {"concepts": [{"concept_id": ..., fields...}]}
#   manual_inputs.json     refresh: {"values": {"Sheet!A1": number}} copied from the user's words
import os, re, sys, json, glob, argparse, subprocess, datetime, zipfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from wbutil import norm_label, cells_of

ASSUMPTION_WORDS = re.compile(r"multiple|discount|rate|premium|haircut|weight|growth|wacc|factor|probability|%|x$", re.I)
CAP_WORDS = re.compile(r"share|units|option|warrant|ownership|holding|strike|exercise|preferred|pref\b|esop|dilut", re.I)
ADJ_WORDS = re.compile(r"add.?back|adjust|normali|one.?off|non.?recurring|pro.?forma", re.I)
OP_PERIOD = {"sum_months": lambda sp: {3: "quarter_sum_of_months", 12: "ltm_sum"}.get(int(sp.get("months", 3)), "month"),
             "ytd_difference": lambda sp: "ytd_difference", "value_at": lambda sp: "quarter_end_balance",
             "components": lambda sp: "point_in_time"}


def sh(args):
    p = subprocess.run([sys.executable] + args, capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


def line(out, key):
    for l in out.splitlines():
        if l.startswith(key):
            return l.split(":", 1)[1].strip()
    return ""


def S(n):
    return os.path.join(HERE, n)


def stem_of(path):
    return re.sub(r"[^A-Za-z0-9_-]+", "_", os.path.splitext(os.path.basename(path))[0])


def load(p, default=None):
    return json.load(open(p, encoding="utf-8")) if p and os.path.exists(p) else default


def save_state(out, **kw):
    p = os.path.join(out, "pipeline_state.json")
    st = load(p, {}); st.update(kw)
    json.dump(st, open(p, "w", encoding="utf-8"), indent=1)
    return st


def fail(out_text, stage):
    print(f"PIPELINE ERROR in {stage}:\n" + "\n".join(l for l in out_text.splitlines() if "ERROR" in l or l.startswith("-"))[:2000])
    sys.exit(1)


LIMIT = 4_000_000                              # current inline limit for connector file inputs


def sized(paths):
    """'name (123 KB)' for each file; files at or over the limit are marked for download instead."""
    out, big = [], []
    for p_ in paths:
        if p_ and os.path.exists(p_):
            b = os.path.getsize(p_)
            (big if b >= LIMIT else out).append(f"{os.path.basename(p_)} ({b / 1024:,.0f} KB)")
    return ", ".join(out) + (f" | TOO LARGE FOR SHAREPOINT UPLOAD (>= 4 MB), return as download: {', '.join(big)}" if big else "")


def sp_saves(company, sub, paths, root="Valuations"):
    """exact SharePoint tool inputs for each file, so the agent copies instead of improvising.
    Create new folder takes the library DISPLAY name ('Documents') and a path relative to it;
    Create file takes the library PATH ('/Shared Documents/...'), the file name, and the sandbox path as content."""
    co = re.sub(r"[^A-Za-z0-9 _-]+", "", company or "UnknownCompany").strip() or "UnknownCompany"
    rel = f"{root}/{co}/{sub}"
    lines = [f"SHAREPOINT: Create new folder | library: Documents | path: {rel}  (skip if List folder shows it exists)"]
    for p_ in paths:
        if not p_ or not os.path.exists(p_):
            continue
        b, n = os.path.getsize(p_), os.path.basename(p_)
        if b >= LIMIT:
            lines.append(f"SHAREPOINT: SKIP {n} ({b / 1024:,.0f} KB >= 4 MB) - return it as a download")
            continue
        if not os.path.abspath(p_).startswith("/app/created/") and os.path.isdir("/app"):
            lines.append(f"SHAREPOINT: SKIP {n} - not in /app/created, so it cannot be uploaded by path; return it as a download")
            continue
        lines.append(f"SHAREPOINT: Create file | folderPath: /Shared Documents/{rel} | name: {n} | body: {os.path.abspath(p_)}")
    return lines


def write_bundle(out, company, files):
    """one zip with the company files (input map, profile, certification): one upload next quarter."""
    co = re.sub(r"[^A-Za-z0-9_-]+", "_", company or "company").strip("_") or "company"
    path = os.path.join(out, f"{co}_company_files.zip")
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            if f and os.path.exists(f):
                z.write(f, os.path.basename(f))
    return path


def open_bundle(bundle, out):
    """-> (input_map, profile, certification) paths extracted from a company bundle."""
    d = os.path.join(out, "company_files"); os.makedirs(d, exist_ok=True)
    with zipfile.ZipFile(bundle) as z:
        z.extractall(d)
    pick = lambda pat: next((os.path.join(d, n) for n in sorted(os.listdir(d)) if re.search(pat, n)), None)
    return pick(r"_input_map\.json$"), pick(r"^mapping_profile\.json$"), pick(r"^certification\.json$")


def rank_line(i, r):
    return f"| {i} | {r[0]:.2f} | {r[1]} | {r[2].replace('|', '/')} |"


# ------------------------------------------------------------------------------------------ onboard
FS_WORDS = re.compile(r"revenue|sales|ebitda|ebit\b|cash|debt|borrow|loan|cogs|cost of|expense|income|margin|profit|"
                      r"assets|liabilit|capex|working capital|payable|receivable|inventory", re.I)
PRIOR_WORDS = re.compile(r"prior|previous|last quarter|last year|\bpq\b|\bpy\b|opening", re.I)
COMP_SHEET = re.compile(r"comp|peer|precedent|transaction|trading|market data", re.I)
CAP_SHEET = re.compile(r"cap ?table|capitali|shareholder|equity schedule|ownership|esop|option", re.I)
INSTR_SHEET = re.compile(r"pref|preferred|note|debenture|loan|instrument|convertible|safe|term sheet", re.I)
DATE_VAL = re.compile(r"^\d{4}-\d{2}-\d{2}")


def suggest(entry, block):
    """deterministic first-pass classification from rule evidence, sheet, header, label and value types.
    needs_judgment marks only what evidence cannot settle."""
    lab, flags = entry["label"], entry.get("flags") or []
    sheet, hdr = entry.get("sheet", ""), entry.get("header") or ""
    vals = [str(v) for v in entry.get("sample_values") or []]
    ctx = f"{lab} | {hdr}"
    path = next(iter((entry.get("paths_to_key_outputs") or {}).values()), [])
    via = " -> ".join(path[:4])
    spec = (block or {}).get("execution_spec")
    base = {"id": entry["id"], "reviewed_by": None}
    sheet_says = (COMP_SHEET.search(entry.get("sheet", "")) or CAP_SHEET.search(entry.get("sheet", ""))
                  or INSTR_SHEET.search(entry.get("sheet", "")))
    if spec and sheet_says and not FS_WORDS.search(lab):
        spec = None                   # a statement "match" on a cap-table / instrument / comps sheet is a coincidence
    if spec:
        rule = f"{spec['operation']}{'(' + str(spec['months']) + ')' if spec.get('months') else ''} of '{spec['source']['label']}'"
        s_ = dict(base, type="financial_statement", expected_source=f"{spec['source']['sheet']}: {spec['source']['label']} ({rule})",
                  changes_each_quarter="yes", confidence="high" if not flags else "medium",
                  notes=f"Statement rule {rule} reproduced the workbook value; path {via}.")
        return s_, bool(flags)
    if re.search(r"(months?|days?|years?|periods?) (until|to|remaining|left)|remaining (term|life)|time to (maturity|expiry)|"
                 r"\bage\b|elapsed|since (issue|investment)", lab, re.I):
        return (dict(base, type="assumption", expected_source=None, changes_each_quarter="yes", confidence="medium",
                     notes=f"'{lab}' counts time, so it changes every period by itself; carrying it forward would be stale; "
                           f"path {' -> '.join((next(iter((entry.get('paths_to_key_outputs') or {}).values()), []))[:4])}."), False)
    ev = lambda t, ch, why, conf="medium": (dict(base, type=t, expected_source=None, changes_each_quarter=ch, confidence=conf,
                                                  notes=f"{why}; path {via}. Cadence proposed, not evidenced."), bool(flags) and conf != "high")
    if PRIOR_WORDS.search(ctx):
        return ev("prior_period", "yes", f"'{ctx}' is labelled as a prior-period value", "high")
    if COMP_SHEET.search(sheet):
        return ev("reference_data", "on_event", f"on the comparables sheet '{sheet}' (comp set reviewed as a whole)")
    if CAP_SHEET.search(sheet) or CAP_WORDS.search(ctx):
        return ev("carry_forward_event_driven", "on_event", f"capitalization data on '{sheet}' ('{lab}')")
    if INSTR_SHEET.search(sheet) and not FS_WORDS.search(lab):
        return ev("carry_forward_event_driven", "on_event", f"instrument term on '{sheet}' ('{lab}')")
    if vals and all(DATE_VAL.match(v) for v in vals):
        return ev("carry_forward_event_driven", "on_event", f"date value(s) {', '.join(vals[:2])} ('{lab}')")
    if vals and all(v.strip().upper() in ("Y", "N", "YES", "NO", "TRUE", "FALSE") for v in vals):
        return ev("assumption", "on_event", f"switch or flag '{lab}' = {vals[0]}")
    if lab.strip() in ("?", ""):
        return dict(base, type="uncertain", expected_source=None, changes_each_quarter="uncertain", confidence="low",
                    notes=f"No label; path {via}."), True
    if re.search(r"multiple|discount|premium|haircut|weight|wacc|probability|growth rate|\brate\b|%", lab, re.I):
        return ev("assumption", "yes", f"'{lab}' is a valuation assumption")
    if FS_WORDS.search(lab):
        return (dict(base, type="financial_statement", expected_source=f"statements: {lab}", changes_each_quarter="yes",
                     confidence="medium", notes=f"Label '{lab}' is a statement line, but no rule reproduced it from the "
                     f"statements supplied (often an earlier period); path {via}."), False)
    if CAP_WORDS.search(lab):
        return dict(base, type="carry_forward_event_driven", expected_source=None, changes_each_quarter="on_event",
                    confidence="medium", notes=f"Label '{lab}' suggests capitalization data; path {via}. Cadence proposed, not evidenced."), bool(flags)
    if ADJ_WORDS.search(lab) or ASSUMPTION_WORDS.search(lab):
        return dict(base, type="assumption", expected_source=None, changes_each_quarter="yes", confidence="medium",
                    notes=f"Label '{lab}' suggests an analyst input; path {via}. Cadence proposed, not evidenced."), bool(flags)
    return dict(base, type="uncertain", expected_source=None, changes_each_quarter="uncertain", confidence="low",
                notes=f"Label '{lab}': no statement rule reproduces it and the label does not settle its type; path {via}."), True


KEY_METRICS = [("enterprise value", r"enterprise value|\bev\b(?!/)"), ("equity value", r"equity value|total equity"),
               ("fair / fund value", r"fair value|xpv.*value|fund.*value|nav\b|current value"),
               ("applied multiple", r"multiple"), ("EBITDA used", r"ebitda"), ("revenue used", r"revenue|sales"),
               ("net debt / cash / debt", r"net debt|\bcash\b|\bdebt\b"), ("ownership", r"ownership|fully diluted|fd %"),
               ("MOIC", r"moic|investment multiple|multiple of cost"), ("IRR", r"\birr\b")]
LINE = re.compile(r"^(\S+) \[(calc|output|KEY OUTPUT)\] (.*?) (=\S.*?)(?:  \(same pattern x\d+\))? -> (.*?)(?:  FLAG|$)")


def key_output_candidates(schema):
    """deterministic shortlist from every sheet section: metric-like formula cells and true check cells."""
    rows, sheet = [], None
    for l in schema.splitlines():
        if l.startswith("=== SHEET: "):
            sheet = l[len("=== SHEET: "):].rstrip(" =")
            continue
        m = LINE.match(l)
        if m and sheet:
            rng, role, lab, f, v = m.groups()
            rows.append((sheet, rng, role, lab, f, v.split(",")[0].strip()))
    cands, sugg, seen = [], [], set()
    VAR = re.compile(r"variance|var\b|change|chg|diff|delta|vs\.?\b|movement|%", re.I)
    PRIOR = re.compile(r"prior|previous|last|opening|budget|plan", re.I)
    simple_diff = lambda f: re.fullmatch(r"=\$?[A-Z]{1,3}\$?\d+\s*-\s*\$?[A-Z]{1,3}\$?\d+", f.replace(" ", ""))
    def is_variance(r):
        return bool(VAR.search(r[3].split("|")[-1]) or (simple_diff(r[4]) and VAR.search(r[3])))
    def num(v):
        try:
            return float(str(v).replace(",", ""))
        except ValueError:
            return None
    pref = lambda r: (0 if re.search(r"current", r[3], re.I) else 1,
                      0 if re.search(r"summary|valuation|lp report|report|output", r[0], re.I) else 1,
                      0 if r[2] != "output" else 1, len(r[1]))
    metric_rows = [r for r in rows if not is_variance(r) and not PRIOR.search(r[3])]
    for name, rx in KEY_METRICS:
        hits = sorted([r for r in metric_rows if re.search(rx, r[3], re.I) and r[5] not in ("(blank)", "0")], key=pref)[:4]
        for r in hits:
            cands.append(f"- {name}: '{r[0]}'!{r[1].split(':')[-1]} [{r[2]}] {r[3]} {r[4]} -> {r[5]}")
        if hits and hits[0][:2] not in seen:
            r = hits[0]; seen.add(r[:2])
            sugg.append({"cell": f"'{r[0]}'!{r[1].split(':')[-1]}", "reason": f"{name}; {r[4]} ({r[3]})"})
    for r in rows:
        f, lab = r[4], r[3]
        boolean = re.fullmatch(r"=[^=<>]+=[^=<>]+", f) and r[5] in ("True", "False")
        v = num(r[5])
        diff = (re.fullmatch(r"=[^=]+-[^=]+", f) and v is not None and abs(v) < 0.01
                and (re.search(r"check|tie|reconcil|error|proof|balance", lab, re.I) or r[2] == "output"))
        if boolean or diff:
            cell = f"'{r[0]}'!{r[1].split(':')[-1]}"
            cands.append(f"- CHECK: {cell} [{r[2]}] {lab} {f} -> {r[5]}")
            if len([x for x in sugg if x.get("control")]) < 4:
                sugg.append({"cell": cell, "reason": f"check; {f} ({lab})",
                             "control": {"control_type": "boolean", "expected": True, "severity": "blocking"} if boolean else
                                        {"control_type": "numeric", "expected": 0, "absolute_tolerance": 1, "severity": "blocking"}})
    return cands[:80], sugg[:15]


def auto_concepts(imap, matches, company, overrides):
    blocks = {b["id"]: b for b in matches["blocks"]}
    groups, order = {}, []
    for e in imap["inputs"]:
        in_scope = (e.get("material") and e.get("type") != "not_material") or e.get("reporting_required") == "yes"
        if not in_scope:
            continue
        spec = (blocks.get(e["id"]) or {}).get("execution_spec")
        if e.get("type") == "reference_data" and not spec:
            key = (f"comp set {e['sheet']}", None, "reference_data")          # a comp set is one concept
        else:
            key = (norm_label(e["label"]), json.dumps(spec, sort_keys=True) if spec else None, e.get("type"))
        if key not in groups:
            groups[key] = {"entries": [], "spec": spec, "type": e.get("type"),
                           "label": key[0] if key[0].startswith("comp set") else e["label"]}
            order.append(key)
        groups[key]["entries"].append(e)
    used, out = set(), []
    prefix = {"financial_statement": "fs", "assumption": "asm", "carry_forward_event_driven": "cap", "constant": "const",
              "reference_data": "ref", "prior_period": "prior", "uncertain": "unk", "not_material": "rpt"}
    for key in order:
        g = groups[key]
        slug = re.sub(r"[^a-z0-9]+", "_", norm_label(g["label"]).replace("#", "n")).strip("_")[:40] or "unlabelled"
        cid = f"{prefix.get(g['type'], 'x')}.{slug}"
        n = 2
        while cid in used:
            cid = f"{prefix.get(g['type'], 'x')}.{slug}_{n}"; n += 1
        used.add(cid)
        targets = [e["id"] for e in g["entries"]]
        multi = any(":" in t.split("!", 1)[1] for t in targets)
        c = {"concept_id": cid, "name": g["label"] if g["label"] != "?" else f"Unlabelled input {targets[0]}",
             "entity": company or "UNCERTAIN", "targets": targets, "questions": []}
        t, sp = g["type"], g["spec"]
        if sp and t in ("financial_statement", "reference_data", "prior_period", "not_material"):
            c.update(write_mode="roll_window" if multi else "replace_period_value",
                     period_rule=OP_PERIOD[sp["operation"]](sp), missing_source_behavior="block_and_flag")
        elif t == "reference_data":
            c.update(write_mode="carry_forward_event_driven", period_rule="not_periodic", missing_source_behavior="carry_forward_and_flag",
                     questions=["Comparable set: carried forward; review the set (add or remove companies or deals) when due."])
        elif t == "prior_period":
            c.update(write_mode="manual_input", period_rule="not_periodic", missing_source_behavior="carry_forward_and_flag",
                     questions=["Prior-period value: in a refresh it should become last quarter's current value. Confirm which "
                                "current-period cell it comes from (a backtest will test this)."])
        elif t in ("financial_statement", "not_material"):
            c.update(write_mode="manual_input", period_rule="uncertain", missing_source_behavior="carry_forward_and_flag",
                     questions=["Expected in the statements, but no rule reproduces it: name the statement line, or confirm it is entered by hand."])
        elif t == "carry_forward_event_driven":
            c.update(write_mode="carry_forward_event_driven", period_rule="not_periodic", missing_source_behavior="carry_forward_and_flag")
        elif t == "constant":
            c.update(write_mode="carry_forward", period_rule="not_periodic", missing_source_behavior="carry_forward_and_flag")
        elif t == "assumption" and re.search(r"(months?|days?|years?|periods?) (until|to|remaining|left)|remaining (term|life)|"
                                             r"time to (maturity|expiry)|\bage\b|elapsed|since (issue|investment)", g["label"], re.I):
            c.update(write_mode="manual_input", period_rule="not_periodic", missing_source_behavior="block_and_flag",
                     questions=["Counts time, so it changes every period: a carried-forward value would be stale. Make it a "
                                "formula in the workbook (from the dates), or give its value each quarter."])
        elif t == "assumption":
            c.update(write_mode="manual_input", period_rule="not_periodic", missing_source_behavior="carry_forward_and_flag")
        else:
            c.update(write_mode="manual_input", period_rule="uncertain", missing_source_behavior="carry_forward_and_flag",
                     questions=["Meaning unknown: what does this input represent, where does it come from, and how often does it change?"])
        out.append(c)
    for ov in (overrides or {}).get("concepts", []):
        hit = next((c for c in out if c["concept_id"] == ov.get("concept_id") or set(ov.get("targets", [])) & set(c["targets"])), None)
        if hit:
            hit.update({k: v for k, v in ov.items() if k != "targets" or v})
        else:
            out.append(ov)
    return {"concepts": out}


def onboard(a):
    out = a.out
    os.makedirs(out, exist_ok=True)
    wb, stem = a.workbook, stem_of(a.workbook)
    skel = os.path.join(out, f"{stem}_inputs_skeleton.json")
    reuse = load(a.input_map)
    ko_path = os.path.join(out, "key_outputs.json")
    ko_src = a.input_map if reuse else (ko_path if os.path.exists(ko_path) else None)
    if not ko_src:
        rc, o = sh([S("extract_schema.py"), wb, "--out", out])
        if "EXTRACTION_ERROR" in o:
            fail(o, "extract (discovery)")
        schema = open(os.path.join(out, f"{stem}_schema.md"), encoding="utf-8").read()
        sec = schema[schema.index("=== OUTPUTS BY SHEET"):schema.index("=== END OF OUTPUTS ===")]
        cands, sugg = key_output_candidates(schema)
        json.dump({"key_outputs": sugg}, open(os.path.join(out, "key_outputs_suggested.json"), "w", encoding="utf-8"), indent=1)
        open(os.path.join(out, "judgment_key_outputs.md"), "w", encoding="utf-8").write(
            "# Choose key outputs (rules: references/key-output-rules.md)\n\n"
            "A first draft is in key_outputs_suggested.json. Copy it to key_outputs.json, then remove, add or fix entries "
            "using the candidates below. Do not search the schema file unless a needed metric is missing here.\n\n"
            "## Likely key metrics and checks (any sheet; formula, last value)\n" + "\n".join(cands) + "\n\n" + sec)
        print(f"JUDGMENT NEEDED: key_outputs.json (draft in key_outputs_suggested.json, {len(sugg)} entries; candidates in "
              "judgment_key_outputs.md). Write it, then re-run the same command.")
        print("SAVE (to resume in another chat): key_outputs.json once written")
        sys.exit(10)
    rc, o = sh([S("extract_schema.py"), wb, "--out", out, "--key-outputs-file", ko_src])
    if "EXTRACTION_ERROR" in o:
        fail(o, "extract (final)")
    idx = os.path.join(out, "sources_index.json")
    rc, o = sh([S("index_sources.py")] + a.statements + ["--out", idx])
    if "INDEX_ERROR" in o:
        fail(o, "index statements")
    mt = os.path.join(out, "matches.json")
    args = [S("match_values.py"), wb, skel, idx, "--out", mt] + (["--period-end", a.period_end] if a.period_end else [])
    rc, o = sh(args)
    if "MATCH_ERROR" in o:
        fail(o, "rule discovery")
    sk, matches = load(skel), load(mt)
    blocks = {b["id"]: b for b in matches["blocks"]}
    # classifications: suggestions from evidence, judgment only where needed
    sugg, need = {}, []
    for e in sk["inputs"]:
        if not e["material"]:
            continue
        s_, j = suggest(e, blocks.get(e["id"]))
        sugg[e["id"]] = s_
        if j:
            need.append(e["id"])
    cls_path = os.path.join(out, "classifications.json")
    agent = load(cls_path)
    if reuse is None and agent is None and not need:
        agent = {"accept_suggestions": True, "classifications": []}      # evidence settled everything: no stop
        json.dump(agent, open(cls_path, "w", encoding="utf-8"))
    if reuse is None and agent is None:
        js = {"instructions": "Write classifications.json = {\"accept_suggestions\": true, \"classifications\": [...]} with one "
                              "entry per needs_judgment id (and any suggestion you disagree with). Rules: references/classification-rules.md. "
                              "Entries may give only the fields that differ from the suggestion.",
              "needs_judgment": [{"id": i, "label": next(e["label"] for e in sk["inputs"] if e["id"] == i),
                                  "values": next(e["sample_values"] for e in sk["inputs"] if e["id"] == i),
                                  "flags": next(e["flags"] for e in sk["inputs"] if e["id"] == i),
                                  "suggestion": sugg[i]} for i in need],
              "accepted_if_you_agree": [{"id": i, "label": next(e["label"] for e in sk["inputs"] if e["id"] == i),
                                         "type": s_["type"], "confidence": s_["confidence"]} for i, s_ in sugg.items() if i not in need]}
        json.dump(js, open(os.path.join(out, "judgment_classifications.json"), "w", encoding="utf-8"), indent=1)
        print(f"JUDGMENT NEEDED: classifications.json for {len(need)} of {len(sugg)} material blocks "
              f"(see judgment_classifications.json). Write it, then re-run the same command.")
        print("SAVE (to resume in another chat): key_outputs.json now; classifications.json once written")
        sys.exit(10)
    merged = dict(sugg)
    for c in (agent or {}).get("classifications", []):
        if c.get("id") in merged:
            merged[c["id"]] = {**merged[c["id"]], **c}
        else:
            merged[c.get("id")] = c
    if agent is not None and not agent.get("accept_suggestions", True):
        merged = {c["id"]: c for c in agent.get("classifications", [])}
    if agent and agent.get("reviewed_by_all"):                      # "Confirm all - reviewed by <name>"
        for c in merged.values():
            c["reviewed_by"] = agent["reviewed_by_all"]
    full = os.path.join(out, "classifications_full.json")
    json.dump({"classifications": list(merged.values())}, open(full, "w", encoding="utf-8"), indent=1)
    imap = os.path.join(out, f"{stem}_input_map.json")
    files = ([a.input_map] if reuse else []) + ([full] if agent is not None or not reuse else [])
    scope = os.path.join(out, "scope.json")
    rc, o = sh([S("apply_classifications.py"), skel] + files + ["--out", imap] + (["--scope", scope] if os.path.exists(scope) else []))
    rc, o = sh([S("validate_input_map.py"), skel, imap])
    if "STATUS: INVALID" in o:
        fail(o, "input map validation (fix classifications.json)")
    sh([S("build_report.py"), skel, imap, "--out", os.path.join(out, f"{stem}_run_report.md")])
    con = auto_concepts(load(imap), matches, a.company, load(os.path.join(out, "concept_overrides.json")))
    cp = os.path.join(out, "concepts.json")
    json.dump(con, open(cp, "w", encoding="utf-8"), indent=1)
    rc, o = sh([S("build_profile.py"), imap, mt, cp, "--out-dir", out])
    if "PROFILE STATUS: INVALID" in o:
        fail(o, "profile build")
    report = onboard_report(out, stem, skel, imap)
    rc, mo = sh([S("write_manifest.py"), "--skill", "valuation-pipeline onboard", "--inputs", wb] + a.statements +
                [x for x in (ko_src, full) if x] + ["--outputs", imap, os.path.join(out, "mapping_profile.json"), report,
                os.path.join(out, f"{stem}_schema.md"), "--company", a.company or "",
                "--period", (load(os.path.join(out, "mapping_profile.json")) or {}).get("period_end") or "", "--out",
                os.path.join(out, f"{stem}_onboard_manifest_{{run_id}}.json")])
    save_state(out, workbook=wb, input_map=imap, profile=os.path.join(out, "mapping_profile.json"), company=a.company)
    print(open(report, encoding="utf-8").read().split("## Key outputs")[0])
    print(f"FINAL REPORT: {report}\n{line(mo, 'run_id') and 'run_id: ' + line(mo, 'run_id')}")
    print("SAVE: company files -> " + sized([imap, os.path.join(out, "mapping_profile.json")])
          + "; run files -> " + sized([report, os.path.join(out, f"{stem}_schema.md")]))
    per = (load(os.path.join(out, "mapping_profile.json")) or {}).get("period_end") or "period"
    q = f"{per[:4]}-Q{(int(per[5:7]) - 1) // 3 + 1}" if re.match(r"\d{4}-\d{2}", per) else per
    bundle = write_bundle(out, a.company, [imap, os.path.join(out, "mapping_profile.json")])
    for l in sp_saves(a.company, "company", [bundle]) + \
             sp_saves(a.company, q, [report, os.path.join(out, f"{stem}_schema.md")]):
        print(l)
    print("NEXT: save the files, then post the FINAL REPORT's top section unchanged. Do not re-read intermediate files.")


def onboard_report(out, stem, skel, imap):
    from validate_input_map import evaluate
    r = evaluate(skel, imap)
    prof = load(os.path.join(out, "mapping_profile.json"))
    ents = r.get("entries", {})
    kos = len(r["skel"].get("key_outputs") or []) or 1
    rv = {}

    def item(key, pr, what, why):
        if key not in rv or rv[key][0] < pr:
            rv[key] = (round(pr, 2), what, why if key not in rv else f"{why}; {rv[key][2]}")
    for c in r.get("controls", []):
        if c["result"] != "PASS":
            item(c["cell"], 3.0 if c["severity"] == "blocking" else 1.8, c["cell"], f"control {c['result']} (value {c['value']}, expected {c['expected']})")
    for b in r.get("blocking", []):
        item(b, 3.0, "blocking issue", b)
    for lst, unc, tag in ((r.get("unresolved", []), 1.0, "meaning unresolved"), (r.get("low_conf", []), 0.7, "low confidence"),
                          (r.get("medium_conf", []), 0.4, "medium confidence")):
        grp = {}
        for i in lst:
            grp.setdefault((ents[i]["sheet"], ents[i]["type"]), []).append(i)
        for (sh_, ty), ids in grp.items():
            if len(ids) >= 3 and unc < 1.0:
                imp = 2 + min(1.0, max(len(ents[i].get("feeds_key_outputs") or []) for i in ids) / kos)
                item(f"grp {sh_} {ty} {tag}", imp * unc, f"{sh_}: {len(ids)} blocks ({ids[0]} ... {ids[-1]})",
                     f"{tag}: classified {ty}; spot-check a few")
                continue
            for i in ids:
                e = ents[i]
                item(i, (2 + min(1.0, len(e.get("feeds_key_outputs") or []) / kos)) * unc, f"{i} ({e['label']})",
                     f"{tag}: {e['type']}. {(e.get('notes') or '')[:120]}")
    manual, rules = [], 0
    for c in prof["concepts"]:
        for q in c.get("questions") or []:
            if q.startswith("Counts time"):
                item(c["concept_id"], 2.4, f"{c['name']} ({', '.join(c['targets'][:3])})", q)
            elif q.startswith("Comparable set"):
                item(c["concept_id"], 0.8, f"{c['name']} ({len(c['targets'])} rows)", q)
            elif q.startswith("Prior-period"):
                item(c["concept_id"], 1.5, f"{c['name']} ({', '.join(c['targets'][:3])})", q)
            else:
                for t in c["targets"]:
                    item(t, 3.0 if c["period_rule"] == "uncertain" else 1.2, f"{t} ({c['name']})", q)
        if c["status"] == "EXCEPTION":
            item(c["concept_id"], 3.0, c["name"], "automated input without a runnable rule")
        elif c["status"] == "EXECUTABLE_UNVERIFIED":
            item(c["concept_id"], 1.8, c["name"], "analyst-stated rule not yet reproduced from the statements")
        elif c["write_mode"] == "manual_input" and c["period_rule"] != "uncertain":
            manual.append(c["name"])
        elif c["status"] == "EXECUTABLE":
            rules += 1
    if manual:
        item("manual", 0.6, "known manual inputs", f"{len(manual)} values entered each quarter (carried forward and flagged if not given): {', '.join(manual)}")
    if rules:
        item("rules", 0.3, "statement rules", f"{rules} rules reproduced the workbook; spot-check one or two")
    scope = {}
    for i in r.get("scope_open", []):
        scope[ents[i]["sheet"]] = scope.get(ents[i]["sheet"], 0) + 1
    for s_, n in scope.items():
        item("scope " + s_, 0.5, f"reporting scope: {s_}", f"{n} blocks do not feed a key output; do they need a quarterly refresh?")
    if r.get("cadence_unconfirmed"):
        item("cadence", 0.4, "refresh cadence", f"{len(r['cadence_unconfirmed'])} blocks have a proposed, unconfirmed cadence")
    for x in prof.get("layout_checks", []):
        item("pack " + x[:40], 0.6 if any(w in x for w in ("layout", "same month", "missing", "no date")) else 0.4, "statement pack", x)
    ranked = sorted(rv.values(), key=lambda x: -x[0])
    ps = prof["status"]
    L = [f"# Onboarding report: {r['skel']['workbook']}", "",
         f"**Structure: technical {r['status']}, business review {r.get('business', 'PENDING')}** | "
         f"**Mapping profile: {ps}**  ", r.get("recon", ""), "",
         "Profile status: READY = complete; INPUT_REQUIRED = complete, known manual inputs needed each quarter; "
         "REVIEW_REQUIRED = some meaning is unresolved (runs still work; resolve before certifying).", "",
         "## Review list (highest priority first: impact x uncertainty)", "| # | Priority | Item | Why |", "|---|---|---|---|"]
    L += [rank_line(i, x) for i, x in enumerate(ranked, 1)] or ["| - | - | nothing to review | |"]
    L += ["", "Reply with corrections in plain words (e.g. `Inputs!B6 is a management adjustment factor, entered each quarter`) "
          "or confirmations (`Confirm all - reviewed by <name>`); the pipeline re-runs only what they affect.", ""]
    L += ["## Key outputs", "| Cell | Reason |", "|---|---|"] + \
         [f"| {c} | {r['skel'].get('key_output_reasons', {}).get(c, '')} |" for c in r["skel"].get("key_outputs", [])]
    L += ["", "## Concepts", "| Concept | Status | Rule / mode | Targets |", "|---|---|---|---|"]
    for c in prof["concepts"]:
        sp = c.get("execution")
        rule = (f"{sp['operation']}{'(' + str(sp.get('months')) + ')' if sp.get('months') else ''} '{sp.get('source', {}).get('label', '')}' x{sp.get('scale', 1)}"
                if sp else c["write_mode"])
        L.append(f"| {c['name']} | {c['status']} | {rule} | {', '.join(c['targets'])} |")
    rp = os.path.join(out, f"{stem}_onboarding_report.md")
    open(rp, "w", encoding="utf-8").write("\n".join(L))
    return rp


# ------------------------------------------------------------------------------------------ run / check
def run(a):
    out = a.out
    os.makedirs(out, exist_ok=True)
    if a.bundle:
        im, pr, ce = open_bundle(a.bundle, out)
        a.input_map, a.profile = a.input_map or im, a.profile or pr
        a.certification = a.certification or ce
    if not (a.input_map and a.profile):
        print("PIPELINE ERROR: give --bundle <Company>_company_files.zip (or --input-map and --profile)"); sys.exit(1)
    stem = stem_of(a.workbook)
    idx = os.path.join(out, "sources_index.json")
    rc, o = sh([S("index_sources.py")] + a.statements + ["--out", idx, "--expect-layout", a.profile])
    if "INDEX_ERROR" in o:
        fail(o, "index statements")
    plan = os.path.join(out, "write_plan.json")
    args = [S("plan_writes.py"), "--mode", a.mode, "--workbook", a.workbook, "--input-map", a.input_map, "--profile", a.profile,
            "--sources-index", idx, "--out", plan]
    for flag, v in (("--certification", a.certification), ("--actual", a.actual), ("--period-end", a.period_end), ("--manual", a.manual)):
        if v:
            args += [flag, v]
    rc, o = sh(args)
    ps = line(o, "PLAN STATUS")
    print(f"PLAN STATUS: {ps}")
    if ps.startswith("REFUSED") or ps.startswith("BLOCKED") or "PLAN_ERROR" in o:
        for l in o.splitlines():
            if l.startswith("- ") or l.startswith("note:"):
                print(l)
        print("NEXT: stop. Report the reasons above in one ranked list; do not do the Excel step.")
        sys.exit(3)
    draft = os.path.join(out, f"{stem}_{a.mode}_draft.xlsx")
    rc, o2 = sh([S("apply_writes.py"), "--workbook", a.workbook, "--plan", plan, "--out", draft])
    if "APPLY_ERROR" in o2:
        fail(o2, "write draft")
    log = draft.rsplit(".", 1)[0] + "_write_log.json"
    st = save_state(out, mode=a.mode, base=a.workbook, actual=a.actual, input_map=a.input_map, profile=a.profile,
                    draft=draft, plan_log=log)
    resume = os.path.join(out, f"{stem}_{a.mode}_resume.json")
    json.dump({k: (os.path.basename(v) if isinstance(v, str) and os.sep in v else v) for k, v in st.items()},
              open(resume, "w", encoding="utf-8"), indent=1)
    print(f"EXCEL STEP: return {os.path.basename(draft)} with references/excel-step.md; when the saved file is uploaded run: "
          f"python scripts/pipeline.py check --saved <uploaded file>")
    print(f"SAVE (to resume in another chat): {sized([draft, log, resume])}")
    plan_d = load(plan) or {}
    per = plan_d.get("period_end", "period")
    q = f"{per[:4]}-Q{(int(per[5:7]) - 1) // 3 + 1}" if re.match(r"\d{4}-\d{2}", per) else per
    co = st.get("company") or (load(a.profile) or {}).get("concepts", [{}])[0].get("entity")
    save_state(out, quarter=q, company=co)
    for l in sp_saves(co, q, [draft, log, resume]):
        print(l)
    sys.exit(20)


UPLOAD_SUFFIX = re.compile(r"-[0-9a-f]{8}(?=\.[A-Za-z0-9]+$)")


def find_file(name, dirs):
    """a saved file, re-uploaded in a new chat, may carry an upload suffix: match on the stable name."""
    want = UPLOAD_SUFFIX.sub("", name)
    for d in dirs:
        for f in glob.glob(os.path.join(d, "**", "*"), recursive=True):
            if os.path.isfile(f) and UPLOAD_SUFFIX.sub("", os.path.basename(f)) == want:
                return f
    return None


def check(a):
    os.makedirs(a.out, exist_ok=True)
    st = load(os.path.join(a.out, "pipeline_state.json"), {})
    need = ["mode", "base", "draft", "input_map", "plan_log"]
    if any(not st.get(k) for k in need) and a.resume:
        rs, dirs = load(a.resume), [os.path.dirname(os.path.abspath(a.resume)), "/app/uploads", a.out]
        st = {k: (find_file(v, dirs) if isinstance(v, str) and "." in v and k != "mode" else v) for k, v in rs.items()}
        missing = [k for k in need if not st.get(k)] + (["actual"] if st.get("mode") == "backtest" and not st.get("actual") else [])
        if missing:
            print("PIPELINE ERROR: to resume, upload these files too: " + ", ".join(str(rs.get(k)) for k in missing)); sys.exit(1)
    if any(not st.get(k) for k in need):
        print("PIPELINE ERROR: no run state in this conversation. Upload the <workbook>_<mode>_resume.json saved at the "
              "Excel step with the files it names, and add --resume <that file>.")
        sys.exit(1)
    args = [S("check_result.py"), "--mode", st["mode"], "--base", st["base"], "--draft", st["draft"], "--input-map", st["input_map"],
            "--plan", st["plan_log"], "--result", a.saved, "--out-dir", a.out]
    if st["mode"] == "backtest":
        args += ["--actual", st["actual"]]
    if a.certify:
        args += ["--certified-by", a.certify]
    rc, o = sh(args)
    if "CHECK_ERROR" in o:
        fail(o, "check")
    rep = line(o, "REPORT WRITTEN")
    per = (load(st["plan_log"]) or {}).get("period_end")
    rc, mo = sh([S("write_manifest.py"), "--skill", f"valuation-pipeline {st['mode']}", "--company", st.get("company") or "",
                 "--period", per or "", "--inputs", st["base"], a.saved,
                 st["input_map"], st["profile"], "--outputs", st["draft"], rep] +
                ([os.path.join(a.out, "certification.json")] if st["mode"] != "refresh" else []) +
                ["--out", os.path.join(a.out, f"{stem_of(st['draft'])}_check_manifest_{{run_id}}.json")])
    text = open(rep, encoding="utf-8").read()
    print(f"CHECK STATUS: {line(o, 'CHECK STATUS')}")
    cert = line(o, "CERTIFICATION FILE")
    if cert:
        print(f"CERTIFICATION: {cert}")
    print(text.split("## Checks")[0])
    print(f"FINAL REPORT: {rep}\nrun_id: {line(mo, 'run_id')}")
    man = sorted(glob.glob(os.path.join(a.out, f"{stem_of(st['draft'])}_check_manifest_*.json")))[-1:]
    co, q = st.get("company"), st.get("quarter") or "run"
    for l in sp_saves(co, q, [rep] + man):
        print(l)
    if st["mode"] != "refresh" and os.path.exists(os.path.join(a.out, "certification.json")):
        cert = load(os.path.join(a.out, "certification.json")) or {}
        if cert.get("status") == "CERTIFIED":
            bundle = write_bundle(a.out, co, [st["input_map"], st["profile"], os.path.join(a.out, "certification.json")])
            for l in sp_saves(co, "company", [bundle])[1:]:
                print(l)
    print("NEXT: save the files, then post the report's Review list unchanged. Certify or approve only when the user's "
          "latest message says so and names the person.")


def selftest(a):
    t = os.path.join(HERE, "..", "tests")
    rc, o = sh([os.path.join(t, "run_engine_selftest.py")])
    rc2, o2 = sh([os.path.join(t, "run_pipeline_selftest.py")])
    print(o.strip()); print(o2.strip())
    sys.exit(0 if rc == 0 and rc2 == 0 else 1)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    for n in ("selftest", "onboard", "run", "check"):
        p = sub.add_parser(n)
        p.add_argument("--out", default="/app/created" if os.path.isdir("/app") else os.getcwd())
    sub.choices["onboard"].add_argument("--workbook", required=True)
    sub.choices["onboard"].add_argument("--statements", nargs="+", required=True)
    sub.choices["onboard"].add_argument("--input-map"); sub.choices["onboard"].add_argument("--company")
    sub.choices["onboard"].add_argument("--period-end")
    r_ = sub.choices["run"]
    r_.add_argument("--mode", choices=["replay", "backtest", "refresh"], required=True)
    r_.add_argument("--workbook", required=True); r_.add_argument("--statements", nargs="+", required=True)
    r_.add_argument("--input-map"); r_.add_argument("--profile"); r_.add_argument("--bundle")
    for f in ("--certification", "--actual", "--period-end", "--manual"):
        r_.add_argument(f)
    c_ = sub.choices["check"]
    c_.add_argument("--saved", required=True); c_.add_argument("--certify"); c_.add_argument("--resume")
    a = ap.parse_args()
    {"selftest": selftest, "onboard": onboard, "run": run, "check": check}[a.cmd](a)
