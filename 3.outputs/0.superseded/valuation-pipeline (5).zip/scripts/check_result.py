# check_result.py - checks a draft after Excel recalculated it (deterministic)
# Usage:
#   python check_result.py --mode replay|backtest|refresh --base <base.xlsx> [--actual <true new-period workbook> (backtest)] --draft <draft.xlsx> --input-map <map.json>
#          --plan <draft>_write_log.json (--result <saved_after_excel.xlsx> | --values-json <office_script_output.json>)
#          --out-dir /app/created [--certified-by "<name>"] [--input-threshold 0.25] [--output-threshold 0.15]
# Checks: 1) inputs written as planned  2) formulas unchanged vs base  3) Excel actually recalculated
#         4) replay: outputs equal the base; backtest: inputs AND outputs equal the actual workbook;
#            refresh: variance vs base  5) controls pass
import sys, json, argparse, os, hashlib, datetime
from openpyxl import load_workbook
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from wbutil import formulas_of, norm_formula, parse_ref, ref, is_num, cells_of


def close(a, b):
    if is_num(a) and is_num(b):
        return abs(a - b) <= max(1e-6, 1e-7 * max(abs(a), abs(b)))
    return a == b


def main(a):
    imap = json.load(open(a.input_map, encoding="utf-8"))
    plan = json.load(open(a.plan, encoding="utf-8"))
    base_f = load_workbook(a.base, data_only=False)
    base_v = load_workbook(a.base, data_only=True)
    truth_v = load_workbook(a.actual, data_only=True) if a.mode == "backtest" else base_v
    draft_f = load_workbook(a.draft, data_only=False)
    L, fails = [], []

    # 1) inputs written as planned
    bad_in = []
    AUTO = ("replace_period_value", "roll_window")
    cur_not_rebuilt = [p["cell"] for p in plan["writes"] if p["write_mode"] in AUTO and p.get("offset_months") == 0
                       and (p.get("origin") or {}).get("type") != "rule"]
    historical = [p for p in plan["writes"] if p["status"] == "historical"]
    for p in plan["writes"]:
        if not p.get("written") or p["status"] == "historical":
            continue
        sh, cell = p["cell"].rsplit("!", 1)
        got = draft_f[sh][cell].value
        if not close(got, p["value"]):
            bad_in.append(f"{p['cell']}: planned {p['value']}, draft has {got}")
        if a.mode == "replay" and not close(p["value"], p["base_value"]):
            bad_in.append(f"{p['cell']}: rebuilt {p['value']} != original {p['base_value']} [{p['concept_id']}]")
        if a.mode == "backtest" and not close(p["value"], p.get("actual_value")):
            bad_in.append(f"{p['cell']}: predicted {p['value']} != actual {p.get('actual_value')} [{p['concept_id']}]")
    exceptions = [p for p in plan["writes"] if p["status"] == "exception"]

    # 2) formulas unchanged
    fb, fd = formulas_of(base_f), formulas_of(draft_f)
    changed = [ref(k) for k in fb if k not in fd or norm_formula(fb[k]) != norm_formula(fd[k])]
    added = [ref(k) for k in fd if k not in fb]
    if a.result:
        fr = formulas_of(load_workbook(a.result, data_only=False))
        changed += [ref(k) for k in fb if k not in fr or norm_formula(fb[k]) != norm_formula(fr[k])]
    changed = sorted(set(changed))

    # 3) recalculated values for key outputs and controls
    kos = imap.get("key_outputs", [])
    ctrls = imap.get("controls", [])
    cells = sorted(set(kos + [c["cell"] for c in ctrls]))
    if a.values_json:
        got = json.load(open(a.values_json, encoding="utf-8"))
        rv = lambda c: got.get(c)
    else:
        res_v = load_workbook(a.result, data_only=True)
        def rv(c):
            k = parse_ref(c)
            return res_v[k[0]].cell(row=k[1], column=k[2]).value
    bv = lambda c: (lambda k: truth_v[k[0]].cell(row=k[1], column=k[2]).value)(parse_ref(c))
    not_calc = [c for c in cells if rv(c) is None and bv(c) is not None]

    # 4) outputs
    out_rows, out_bad, var_flags = [], [], []
    for c in kos:
        o, n = bv(c), rv(c)
        if a.mode in ("replay", "backtest"):
            ok = close(o, n)
            out_rows.append(f"| {c} | {o} | {n} | {'MATCH' if ok else 'DIFFERENT'} |")
            if not ok:
                out_bad.append(c)
        else:
            chg = (n - o) / abs(o) if is_num(o) and is_num(n) and o != 0 else None
            flag = chg is not None and abs(chg) > a.output_threshold
            out_rows.append(f"| {c} | {o} | {n} | {'' if chg is None else f'{chg:+.1%}'}{' FLAG' if flag else ''} |")
            if flag:
                var_flags.append(f"key output {c} moved {chg:+.1%}")
    if a.mode == "refresh":
        for p in plan["writes"]:
            o, n = p["base_value"], p["value"]
            if p.get("written") and is_num(o) and is_num(n) and o != 0 and abs((n - o) / abs(o)) > a.input_threshold:
                var_flags.append(f"input {p['cell']} [{p['concept_id']}] moved {(n - o) / abs(o):+.1%}")

    # 5) controls
    c_rows, c_block = [], []
    for c in ctrls:
        v = rv(c["cell"])
        if isinstance(v, str) and v.startswith("#"):
            res = "FAIL"
        elif c["control_type"] == "boolean":
            res = "PASS" if isinstance(v, bool) and v == bool(c["expected"]) else "FAIL"
        else:
            res = "PASS" if is_num(v) and abs(v - c["expected"]) <= float(c.get("absolute_tolerance", 0)) else "FAIL"
        c_rows.append(f"| {c['cell']} | {v} | {c['expected']} | {res} | {c['severity']} |")
        if res == "FAIL" and c["severity"] == "blocking":
            c_block.append(c["cell"])

    in_label = {"replay": " and equal to the original", "backtest": " and equal to the actual workbook", "refresh": ""}[a.mode]
    out_label = {"replay": "key outputs reproduce the original", "backtest": "key outputs match the actual workbook",
                 "refresh": "no variance flags (inputs or key outputs)"}[a.mode]
    checks = {"every current-period input rebuilt by its rule": not cur_not_rebuilt,
              "inputs written as planned" + in_label: not bad_in,
              "no planned cell left as an exception": not exceptions,
              "formulas unchanged": not changed and not added,
              "Excel recalculated the draft": not not_calc,
              out_label: not out_bad if a.mode in ("replay", "backtest") else not var_flags,
              "blocking controls pass": not c_block}
    if a.mode in ("replay", "backtest"):
        status = f"{a.mode.upper()}_PASS" if all(checks.values()) else f"{a.mode.upper()}_FAIL"
    else:
        hard = [k for k in checks if k != "no variance flags (inputs or key outputs)" and not checks[k]]
        status = "DRAFT_BLOCKED" if hard else "DRAFT_READY_FOR_REVIEW"

    by_concept = {}
    for p in plan["writes"]:
        target = p.get("actual_value") if a.mode == "backtest" else p["base_value"]
        d = by_concept.setdefault(p["concept_id"], {"cells": 0, "rule": 0, "rolled": 0, "manual/carry": 0,
                                                    "historical": 0, "exception": 0, "matches": 0})
        d["cells"] += 1
        kind = (p.get("origin") or {}).get("type")
        d["rule" if kind == "rule" else "rolled" if kind == "shifted" else "historical" if p["status"] == "historical"
          else "exception" if p["status"] == "exception" else "manual/carry"] += 1
        if p.get("written") and p["status"] != "historical" and close(p["value"], target):
            d["matches"] += 1
    # ---- why does each differing key output differ? (deterministic attribution to precedents)
    feeds = {}
    for e in imap.get("inputs", []):
        for k in cells_of(e["id"]):
            feeds[ref(k)] = set(e.get("feeds_key_outputs") or [])
    target_of = lambda p: p.get("actual_value") if a.mode == "backtest" else p["base_value"]
    changed_in = [p for p in plan["writes"] if p.get("written") and not close(p["value"], target_of(p))]
    fprec = {k: set(v) for k, v in (imap.get("key_output_formula_precedents") or {}).items()}
    explain = {}
    for c in out_bad:
        ins = [p for p in changed_in if c in feeds.get(p["cell"], set())]
        fs_ = [x for x in changed + added if x in fprec.get(c, set())]
        explain[c] = (ins, fs_)
    unexplained = [c for c, (ins, fs_) in explain.items() if not ins and not fs_]
    fx_irrelevant = [x for x in changed + added if not any(x in v for v in fprec.values())] if fprec else []

    # ---- one review list, ordered by priority = impact x uncertainty (highest first)
    review = []
    def item(impact, unc, what, why):
        review.append((round(impact * unc, 2), impact, unc, what, why))
    for p in exceptions:
        item(3, 1.0, f"{p['cell']} [{p['concept_id']}]", f"not written: {p['message']}")
    for c in c_block:
        item(3, 1.0, c, "blocking control fails")
    for c in cur_not_rebuilt:
        item(3, 1.0, c, "current-period input not rebuilt by its rule")
    for x in bad_in:
        item(3, 0.9, x.split(":")[0], x)
    for c in out_bad:
        ins, fs_ = explain[c]
        why = ("UNEXPLAINED: no written input or changed formula feeds it - check external links, volatile functions "
               "(TODAY, NOW, OFFSET) and the recalculation") if c in unexplained else (
               "explained by " + "; ".join([f"{p['cell']} [{p['concept_id']}] {target_of(p)} -> {p['value']}" for p in ins[:4]]
                                           + [f"formula {x} changed" for x in fs_[:3]])
               + (f" (+{len(ins) + len(fs_) - 7} more)" if len(ins) + len(fs_) > 7 else ""))
        item(3, 1.0, f"key output {c}", why)
    relevant = [x for x in changed + added if x not in fx_irrelevant]
    for x in relevant:
        item(3, 0.9, x, "formula changed or added, and it feeds a key output")
    if fx_irrelevant:
        item(1, 0.4, f"{len(fx_irrelevant)} changed formulas ({fx_irrelevant[0]} ...)",
             "formula changed or added, but it feeds no key output (display or notes); confirm")
    for c in not_calc:
        item(3, 0.8, c, "not recalculated by Excel")
    for f_ in var_flags:
        pct = abs(float(f_.rsplit("moved ", 1)[1].rstrip("%"))) / 100 if "moved " in f_ else 0
        thr = a.output_threshold if f_.startswith("key output") else a.input_threshold
        item(3 if f_.startswith("key output") else 2, min(1.0, 0.4 + 0.3 * pct / max(thr, 1e-9)),
             f_.split(" moved")[0], f_)
    groups = {}
    for p in plan["writes"]:
        if p["status"] in ("flag", "historical"):
            groups.setdefault((p["status"], p["concept_id"], p["message"]), []).append(p["cell"])
    for (st_, cid, msg), cells_ in groups.items():
        what = f"{cells_[0]} [{cid}]" if len(cells_) == 1 else f"{cid}: {len(cells_)} cells ({cells_[0]} ... {cells_[-1]})"
        item(2 if st_ == "flag" else 1.5, 0.5 if st_ == "flag" else 0.3, what, msg)
    for n in plan.get("notes", []):
        item(1.5 if "layout differs" in n or "replay only" in n else 1, 0.4, "statement pack / basis", n)
    review.sort(key=lambda r: -r[0])
    stem = os.path.splitext(os.path.basename(a.draft))[0]
    L = [f"# {a.mode.title()} check: {plan['workbook']}", "", f"**{status}**", "",
         "## Review list (highest priority first: impact x uncertainty)",
         "| # | Priority | Item | Why |", "|---|---|---|---|"]
    L += [f"| {i} | {r[0]:.2f} | {r[3]} | {r[4].replace('|', '/')} |" for i, r in enumerate(review, 1)] or ["| - | - | nothing to review | |"]
    L += ["", "_Impact: 3 = changes a key output or blocks the run, 2 = an input that feeds key outputs, 1-1.5 = context. "
          "Uncertainty: 1.0 = not resolved, 0.3 = likely fine but unproven._", "", "## Checks"]
    L += [f"- {'PASS' if ok else 'FAIL'}: {k}" for k, ok in checks.items()]
    L += ["", "## Key outputs", "| Cell | Original | New | " + ("Result" if a.mode == "replay" else "Change") + " |",
          "|---|---|---|---|"] + out_rows
    if explain:
        L += ["", "## Why key outputs differ", "| Key output | Explained by (changed precedents) |", "|---|---|"]
        for c, (ins, fs_) in explain.items():
            L.append(f"| {c} | " + ("**UNEXPLAINED**" if c in unexplained else
                     "; ".join([f"{p['cell']} [{p['concept_id']}]: {target_of(p)} -> {p['value']}" for p in ins]
                               + [f"formula {x}" for x in fs_]).replace("|", "/")) + " |")
    L += ["", "## By concept", "| Concept | Cells | Rebuilt by rule | Rolled forward | Manual / carried | Historical kept | "
          "Exceptions | " + ("Match " + ("original" if a.mode == "replay" else "actual") if a.mode != "refresh" else "") + " |",
          "|---|---|---|---|---|---|---|---|"]
    L += [f"| {cid} | {d['cells']} | {d['rule']} | {d['rolled']} | {d['manual/carry']} | {d['historical']} | {d['exception']} | "
          f"{d['matches'] if a.mode != 'refresh' else ''} |" for cid, d in by_concept.items()]
    if historical:
        L += ["", f"_{len(historical)} earlier-period cells were kept from the workbook because the supplied statements do "
              "not cover those periods. They are not proof; supply earlier statements to rebuild them._"]
    if plan.get("notes"):
        L += ["", "## Notes"] + [f"- {n}" for n in plan["notes"]]
    L += ["", "## Controls", "| Cell | Value | Expected | Result | Severity |", "|---|---|---|---|---|"] + (c_rows or ["| (none) | | | | |"])
    if a.mode == "refresh" and exceptions:
        L += ["", "_Exception cells still hold LAST period's value in the draft. The draft cannot be approved until they are resolved._"]
    for title, items in [("Current-period inputs not rebuilt by their rule", cur_not_rebuilt), ("Input problems", bad_in), ("Exceptions (not written)",
                          [f"{p['cell']} [{p['concept_id']}]: {p['message']}" for p in exceptions]),
                         ("Formula changes", changed + [f"added: {x}" for x in added]),
                         ("Not recalculated", not_calc), ("Variance flags", var_flags),
                         ("Flagged writes (review)", [f"{p['cell']} [{p['concept_id']}]: {p['message']}"
                                                      for p in plan["writes"] if p["status"] == "flag"])]:
        if items:
            L += ["", f"## {title}"] + [f"- {x}" for x in items[:80]]
    if not_calc:
        L += ["", "_Open the draft in desktop Excel, let it calculate, save, and upload the saved file again._"]
    rep = os.path.join(a.out_dir, f"{stem}_check_report.md")
    open(rep, "w", encoding="utf-8").write("\n".join(L))

    if a.mode in ("replay", "backtest"):
        cert_path = os.path.join(a.out_dir, "certification.json")
        cert = {"status": f"{a.mode.upper()}_PASSED" if status.endswith("_PASS") else f"{a.mode.upper()}_FAILED",
                "basis": a.mode, "cells_rebuilt_by_rule": sum(d["rule"] for d in by_concept.values()),
                "cells_historical_not_rebuilt": len(historical),
                "profile_hash": plan["profile_hash"], "template_fingerprint": plan["template_fingerprint"],
                "replay_report": os.path.basename(rep), "checked_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "certified_by": None, "certified_date": None}
        if a.certified_by:
            if not status.endswith("_PASS"):
                print(f"CERTIFICATION REFUSED: the {a.mode} did not pass.")
            elif plan.get("profile_status") == "REVIEW_REQUIRED":
                print("CERTIFICATION REFUSED: the profile still has unresolved meaning (REVIEW_REQUIRED). Resolve the "
                      "review items, rebuild the profile, and re-run.")
            else:
                cert.update(status="CERTIFIED", certified_by=a.certified_by,
                            certified_date=datetime.date.today().isoformat())
        json.dump(cert, open(cert_path, "w", encoding="utf-8"), indent=1)
        print(f"CERTIFICATION FILE: {cert_path} (status {cert['status']})")
    print(f"CHECK STATUS: {status}")
    if unexplained:
        print(f"UNEXPLAINED DIFFERENCES: {', '.join(unexplained)}")
    print(f"REVIEW LIST: {len(review)} items, highest priority first" + (f"; top: {review[0][3]} ({review[0][4][:80]})" if review else ""))
    for k, ok in checks.items():
        print(f"check {'PASS' if ok else 'FAIL'}: {k}")
    print(f"REPORT WRITTEN: {rep}")
    if not_calc:
        print("NEXT REQUIRED STEP: tell the user the file was not recalculated; ask them to open it in desktop Excel, "
              "save, and upload it again.")
    else:
        print("NEXT REQUIRED STEP: run write_manifest.py, save the files, and give the final summary: quote CHECK STATUS "
              "and the check lines, then the report's Review list unchanged and in its order, then the tables. Certify only if the user's latest message says so and "
              "names the certifier.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["replay", "backtest", "refresh"], required=True)
    ap.add_argument("--actual", help="backtest: the analyst's real workbook for the new period")
    ap.add_argument("--base", required=True); ap.add_argument("--draft", required=True)
    ap.add_argument("--input-map", required=True); ap.add_argument("--plan", required=True)
    ap.add_argument("--result"); ap.add_argument("--values-json")
    ap.add_argument("--out-dir", default="/app/created"); ap.add_argument("--certified-by", default="")
    ap.add_argument("--input-threshold", type=float, default=0.25)
    ap.add_argument("--output-threshold", type=float, default=0.15)
    a = ap.parse_args()
    if a.mode == "backtest" and not a.actual:
        print("CHECK_ERROR: backtest needs --actual"); sys.exit(1)
    if not (a.result or a.values_json):
        print("CHECK_ERROR: give --result (workbook saved by Excel) or --values-json (Office Script output)"); sys.exit(1)
    try:
        main(a)
    except Exception as e:
        print(f"CHECK_ERROR: {type(e).__name__}: {e}"); sys.exit(1)
