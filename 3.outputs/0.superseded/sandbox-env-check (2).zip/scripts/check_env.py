# check_env.py - reports what this sandbox can do for Excel automation. Read-only except a temp test file.
import sys, os, shutil, subprocess, importlib, tempfile, platform

def pkg(name):
    try:
        m = importlib.import_module(name)
        return f"yes ({getattr(m, '__version__', 'version unknown')})"
    except Exception:
        return "no"

print("=== SANDBOX ENVIRONMENT CHECK ===")
print(f"python: {sys.version.split()[0]} | os: {platform.platform()}")
print(f"working dir: {os.getcwd()}")
for d in ["/app", "/app/created", "/mnt/data", "/tmp"]:
    if os.path.isdir(d):
        print(f"dir {d}: exists, writable={os.access(d, os.W_OK)}, entries={sorted(os.listdir(d))[:15]}")
print("\n-- Python packages --")
for p in ["openpyxl", "formulas", "pycel", "pandas", "xlsxwriter", "xlrd", "pyxlsb", "docx", "pypdf", "pdfplumber"]:
    print(f"{p}: {pkg(p)}")
print("\n-- Programs --")
for b in ["soffice", "libreoffice", "unoconv", "excel"]:
    print(f"{b}: {shutil.which(b) or 'not found'}")

print("\n-- Recalculation test --")
try:
    from openpyxl import Workbook, load_workbook
    tmp = tempfile.mkdtemp()
    src = os.path.join(tmp, "recalc_test.xlsx")
    wb = Workbook(); ws = wb.active; ws["A1"] = 41; ws["B1"] = "=A1+1"; wb.save(src)
    before = load_workbook(src, data_only=True).active["B1"].value
    print(f"openpyxl write: ok | cached B1 before recalc: {before} (None is expected)")
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if soffice:
        outd = os.path.join(tmp, "out")
        r = subprocess.run([soffice, "--headless", "--convert-to", "xlsx", "--outdir", outd, src],
                           capture_output=True, text=True, timeout=120)
        f = os.path.join(outd, "recalc_test.xlsx")
        v = load_workbook(f, data_only=True).active["B1"].value if os.path.exists(f) else None
        print(f"LibreOffice recalc: {'WORKS (B1=' + str(v) + ')' if v == 42 else 'FAILED (' + (r.stderr.strip()[:200] or 'no output') + ')'}")
    else:
        print("LibreOffice recalc: not available")
    if pkg("formulas").startswith("yes"):
        try:
            import formulas
            sol = formulas.ExcelModel().loads(src).finish().calculate()
            vals = [v.value[0][0] for k, v in sol.items() if k.upper().endswith("!B1")]
            print(f"formulas package recalc: {'WORKS (B1=' + str(vals[0]) + ')' if vals and vals[0] == 42 else 'FAILED'}")
        except Exception as e:
            print(f"formulas package recalc: FAILED ({type(e).__name__}: {e})")
    else:
        print("formulas package recalc: not installed")
    if pkg("pycel").startswith("yes"):
        try:
            from pycel import ExcelCompiler
            v = ExcelCompiler(filename=src).evaluate(f"{ws.title}!B1")
            print(f"pycel recalc: {'WORKS (B1=' + str(v) + ')' if v == 42 else 'FAILED'}")
        except Exception as e:
            print(f"pycel recalc: FAILED ({type(e).__name__}: {e})")
    else:
        print("pycel recalc: not installed")
except Exception as e:
    print(f"recalculation test error: {type(e).__name__}: {e}")
print("\n=== END OF CHECK ===")
