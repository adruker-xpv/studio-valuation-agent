---
name: sandbox-env-check
description: Checks what this agent's sandbox can do for Excel automation - Python version, installed packages (openpyxl, formulas, pycel, pandas), available programs (LibreOffice), writable folders, and whether a workbook can actually be recalculated. Use when the user asks what the environment can do, which libraries are installed, or whether workbooks can be recalculated.
---

# Sandbox environment check

1. Run exactly: `python scripts/check_env.py`
2. Show the user the full output unchanged, inside a code block.
3. Below it, write two lines only:
   - `Recalculation available: yes (<method>)` or `Recalculation available: no`
   - `Workbook reading available: yes` if openpyxl is installed, otherwise `no`
4. Do not install packages, modify the script, or run other commands.
