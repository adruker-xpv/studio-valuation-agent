# gold_validate.py (build 13.2, test bench) - checks a gold-mvp/3 key BEFORE anything is scored against it, and holds the helpers
# gold_score.py shares (reference parsing, deterministic text matching, workbook loading, the copy-link graph, period proof).
# Build 13.2 additions (all optional, additive; a 13.1 key validates exactly as before):
#   metric_period.header_anchor / value_anchor  - the date headers and the 12 monthly values, graded separately. With the workbooks the
#       header must hold 12 consecutive months first_month..last_month, the values must be 12 numbers that line up with it (same sheet) and,
#       when valuation_metric.value is given, sum to it. An old single primary_anchor is read as the header evidence.
#   "support": "component" on a supporting anchor (optional "component": "cash" | "debt") - a part of the answer, never an equivalent of it.
#   material_discrepancies[].basis {"type": "ROUNDING", "decimals": 0-6} - the declared rounding rule, checked against the workbooks.
#   immaterial_below (a dollar amount) on a discrepancy, or materiality.immaterial_below for the whole key - Gold-defined only; absent means
#       no automatic immateriality. Percentages are not accepted in this build.
# Gold keys are test-bench only: they are authored by an analyst from the workbooks and never go to the extractor or reviewer agents.
#
# Checks (errors make the key invalid; warnings do not):
#   schema is gold-mvp/3; certification.material_truth_complete == YES and nothing listed as missing; no placeholder text anywhere
#   (FILL_IN, TBD, TODO, <angle-bracket template text>); every referenced source id (W1..Wn) exists in source_files; references parse;
#   required fields present and typed; enums (relationship MATCH|DIFFERENT|UNRESOLVED; discrepancy REAL|ROUNDING|UNRESOLVED;
#   human judgments are UNRESOLVED); ids unique; the key agrees with itself (EV + cash - debt = equity; relationship numbers).
#   With --workbooks (the frozen files): every Gold file is present (by SHA-256 when Gold gives one, else by file name), its SHA-256
#   matches, every anchor's sheet and cell exist, and numeric answers equal the anchor's saved value (or its $000s / $m scaling).
#   Without --workbooks those checks are skipped and said so (a warning).
# Matching metadata (optional, additive) on rivals, discrepancies and human judgments: id, cells ["W1:'Sheet'!A1"], keywords ["a|b", "c"].
#   An item with no id, cells or keywords stays valid but cannot be matched deterministically, so scoring reports it UNSCORED.
# Usage: python gold_validate.py --gold KEY.json [--workbooks A.xlsx B.xlsx ...] [--out validation.json]
import argparse, copy, hashlib, html, json, os, re, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from xlsx_evidence import (Book as XBook, norm_file, split_ref, parse_cell, parse_range, ref_contains, formula_refs, addr, num)  # noqa: E402

SCHEMA = "gold-mvp/3"
KNOWN = ["valuation_method", "valuation_metric", "metric_period", "applied_multiple", "enterprise_value", "equity_bridge",
         "ownership_or_waterfall", "company_value", "fund_reported_value", "company_to_fund_relationship"]
OPTIONAL_NUMERIC = {"valuation_metric"}      # Gold states the metric semantically (answer); a numeric value is optional and is never borrowed from another concept
NUMERIC = {"valuation_metric": "value", "applied_multiple": "answer", "enterprise_value": "answer", "equity_bridge": "equity_value",
           "company_value": "answer", "fund_reported_value": "answer"}
RELATIONSHIPS = {"MATCH", "DIFFERENT", "UNRESOLVED"}
DISC_STATUS = {"REAL", "ROUNDING", "UNRESOLVED"}
SUPPORT = ("exact", "rounded", "scaled", "context", "component")
COMPONENTS = ("cash", "debt")
PLACEHOLDER = re.compile(r"FILL[_ ]?IN|<[A-Za-z][^<>]*>|^\s*(TBD|TODO|XXX|\?\?\?)\s*$", re.I)
SCALES = (1, 1e-3, 1e-6)


# ---------------- shared helpers ----------------
def skey(name):
    """a worksheet name as a comparison key: reader escaping undone (&amp; ...), non-breaking spaces read as spaces, leading/trailing whitespace
    trimmed, runs of internal whitespace collapsed, case ignored (Excel itself treats sheet names case-insensitively). Everything else is
    preserved ('Valuation Summary-Prior Period' stays distinct from 'Valuation Summary')."""
    return " ".join(html.unescape(str(name)).replace("\xa0", " ").split()).lower()


def resolve_gold_sheet(book, name):
    """a Gold sheet name against a workbook's ACTUAL worksheet names -> (raw name, method, problem).
    1. EXACT raw match; 2. NORMALIZED_WHITESPACE (skey) match, only when exactly one worksheet matches; several matches are ambiguous
    (BENCHMARK_INTEGRITY); none is a missing sheet. Gold is never rewritten: the report shows what Gold wrote and the raw name."""
    names = book.sheet_names()
    if name in names:
        return name, "EXACT", None
    hit = [n for n in names if skey(n) == skey(name)]
    if len(hit) == 1:
        return hit[0], "NORMALIZED_WHITESPACE", None
    if len(hit) > 1:
        return None, None, f"ambiguous sheet: {len(hit)} worksheets normalise to {name!r}: {hit}"
    return None, None, f"has no sheet {name!r}"


def range_populated(book, sheet, rng):
    """does at least one cell inside the (possibly open-ended) range hold a value or formula?"""
    b = parse_range(rng)
    if not b:
        return False
    r1, c1, r2, c2 = b
    return any((r1 is None or r1 <= r) and (r2 is None or r <= r2) and (c1 is None or c1 <= c) and (c2 is None or c <= c2) for (r, c) in book.cells(sheet))


def canon_name(name):
    """a file name reduced to what survives upload renaming: no folder, no extension, a browser '(1)' dropped, punctuation and underscores
    read as spaces, case ignored, and a trailing runtime hash token ('-1a2b3c4d': 6-12 hex characters including a letter) removed.
    'Company Valuation.xlsx' and 'Company_Valuation-1a2b3c4d.xlsx' both become 'company valuation'. Used on BOTH sides of every name
    comparison; a name that normalises to the same text as another file's is ambiguous and is never guessed."""
    b = re.sub(r"\.(xlsx|xlsm|xls|xltx)$", "", os.path.basename(str(name or "")), flags=re.I)
    b = re.sub(r"\s*\(\d{1,2}\)$", "", b)
    toks = re.sub(r"[^a-z0-9]+", " ", b.lower()).split()
    if len(toks) > 1 and re.fullmatch(r"[0-9a-f]{6,12}", toks[-1]) and re.search(r"[a-f]", toks[-1]):
        toks.pop()
    return " ".join(toks)


def strip_upload_number(name):
    """build 13.1: a SUPPLIED file's name without a trailing '-<6 to 12 digits>' upload number
    ('2026_Book_V2-11963866.xlsx' -> '2026_Book_V2.xlsx'). canon_name keeps an all-digit ending (it may be a date), so this is
    used only as a SECOND try, after the normal name match finds no file, and a match still needs exactly one file."""
    b = os.path.basename(str(name or ""))
    return re.sub(r"-\d{6,12}(?=(\s*\(\d{1,2}\))?(\.(xlsx|xlsm|xls|xltx))?$)", "", b, flags=re.I)


def name_tier(supplied, gold_file):
    """how a supplied (or extraction-recorded) file name matches a Gold file name: 'file name (normalised)',
    'file name (normalised, upload number removed)' or None. The first tier is the build 13.0 rule, unchanged."""
    if canon_name(supplied) == canon_name(gold_file):
        return "file name (normalised)"
    if canon_name(strip_upload_number(supplied)) == canon_name(gold_file):
        return "file name (normalised, upload number removed)"
    return None


def name_candidates(items, gold_file, name_of):
    """items whose name matches gold_file: the first tier if any match it, else the second tier -> (items, how)."""
    for tier in ("file name (normalised)", "file name (normalised, upload number removed)"):
        hit = [x for x in items if name_tier(name_of(x), gold_file) == tier]
        if hit:
            return hit, tier
    return [], None


def rounding_basis(rel, err=None):
    """build 13.1, optional: company_to_fund_relationship.relationship_basis = {"type": "ROUNDING", "decimals": 0-6}.
    Returns the decimals, or None when absent or malformed (malformed is an error when err is given). No other tolerance exists."""
    b = rel.get("relationship_basis") if isinstance(rel, dict) else None
    if b is None:
        return None
    d = b.get("decimals") if isinstance(b, dict) else None
    if not isinstance(b, dict) or str(b.get("type", "")).upper() != "ROUNDING" or not isinstance(d, int) or isinstance(d, bool) or not 0 <= d <= 6:
        if err:
            err('company_to_fund_relationship.relationship_basis must be {"type": "ROUNDING", "decimals": 0 to 6}')
        return None
    return d


def rounds_to(a, b, decimals):
    """exactly one of the two values, rounded to the declared decimals, equals the other (no tolerance beyond float representation)."""
    x, y = num(a), num(b)
    if x is None or y is None:
        return False
    eq = lambda p, q: abs(p - q) <= 1e-9 * max(1.0, abs(q))
    return eq(round(x, decimals), y) or eq(round(y, decimals), x)


def iid(item):
    """a Gold item's id: 'id' or 'gold_id'"""
    return (item.get("id") or item.get("gold_id")) if isinstance(item, dict) else None


def apply_manifest(gold, manifest):
    """merge a frozen source manifest ({'W1': {'file', 'sha256'}} or {'source_files': {...}}) into Gold's source_files. Gold's own SHA-256 wins;
    a manifest SHA-256 that disagrees with Gold's is an error. Returns (effective gold, [errors])."""
    errs, g = [], copy.deepcopy(gold)
    m = (manifest or {}).get("source_files", manifest or {})
    sf = g.setdefault("source_files", {})
    for wid, v in m.items():
        sha = ((v.get("sha256") if isinstance(v, dict) else None) or "").lower() or None
        if wid not in sf:
            errs.append(f"the source manifest names {wid}, which Gold's source_files does not have")
            continue
        cur = sf[wid] if isinstance(sf[wid], dict) else {"file": sf[wid]}
        if cur.get("sha256") and sha and cur["sha256"].lower() != sha:
            errs.append(f"{wid}: the manifest's SHA-256 {sha[:12]}... differs from Gold's {cur['sha256'][:12]}...")
        elif sha and not cur.get("sha256"):
            cur = {**cur, "sha256": sha}
        sf[wid] = cur
    return g, errs


def find_workbook(s, opened):
    """tie one Gold source {file, sha256} to one supplied workbook -> (book, how, problem). SHA-256 first; else the normalised file name,
    only when exactly one supplied file matches; never a guess."""
    if s["sha256"]:
        hit = [b for b in opened if b.sha256 == s["sha256"]]
        if hit:
            return hit[0], "sha256", None
    cands, how = name_candidates(opened, s["file"], lambda b: b.file)
    if len(cands) == 1:
        b = cands[0]
        if s["sha256"] and b.sha256 != s["sha256"]:
            return None, None, (f"a supplied file ('{b.file}') has this name but SHA-256 {b.sha256[:12]}... differs from Gold's "
                                f"{s['sha256'][:12]}... (not the frozen binary)")
        return b, how, None
    if len(cands) > 1:
        return None, None, f"ambiguous: {len(cands)} supplied files normalise to this name ({', '.join(b.file for b in cands)}); give Gold a sha256"
    return None, None, "not among the supplied workbooks"

def read_json(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def source_files(gold):
    """{'W1': {'file': name, 'sha256': hex or None}} - Gold writes either a file name or {file, sha256}."""
    out = {}
    for k, v in (gold.get("source_files") or {}).items():
        out[k] = {"file": v.get("file"), "sha256": (v.get("sha256") or "").lower() or None} if isinstance(v, dict) else {"file": v, "sha256": None}
    return out


def parse_ref(s):
    """\"W1:'Valuation Summary'!F11\" -> ('W1', 'Valuation Summary', 'F11'); \"W1:'Cap Table'\" -> ('W1', 'Cap Table', None); bad -> None."""
    m = re.match(r"^\s*(W\d+):(.+?)\s*$", s) if isinstance(s, str) else None
    if not m:
        return None
    wid, rest = m.groups()
    if "!" in rest:
        sheet, cell = split_ref(rest)
        return (wid, sheet, cell) if sheet and cell and parse_range(cell) else None
    sheet = rest.strip()
    if sheet.startswith("'") and sheet.endswith("'") and len(sheet) > 2:
        sheet = sheet[1:-1].replace("''", "'")
    return (wid, sheet, None) if sheet else None


def gnode(ref):
    """a Gold reference as a comparison node (wid, sheet lower-case, cell upper-case or None for a whole sheet)."""
    p = parse_ref(ref)
    return (p[0], skey(p[1]), p[2].upper() if p[2] else None) if p else None


def anchors_of(concept):
    """(kind, ref) for every anchor of a concept. kind: primary | supporting (an equivalent representation) | component (build 13.2: a part
    of the answer such as cash or debt, never an equivalent) | header | value (build 13.2: metric_period evidence)."""
    out = []
    if isinstance(concept.get("primary_anchor"), dict):
        out.append(("primary", concept["primary_anchor"].get("ref")))
    for a in concept.get("supporting_anchors") or []:
        if isinstance(a, dict):
            out.append(("component" if a.get("support") == "component" else "supporting", a.get("ref")))
    for k in ("header", "value"):
        if isinstance(concept.get(f"{k}_anchor"), dict):
            out.append((k, concept[f"{k}_anchor"].get("ref")))
    return out


def threshold(item, gold):
    """build 13.2: the Gold-defined dollar threshold below which a difference is immaterial: the item's immaterial_below, else the key's
    materiality.immaterial_below, else None (no automatic immateriality)."""
    t = item.get("immaterial_below") if isinstance(item, dict) else None
    if t is None:
        t = ((gold or {}).get("materiality") or {}).get("immaterial_below") if isinstance((gold or {}).get("materiality"), dict) else None
    return num(t)


def item_basis(item, err=None):
    """build 13.2: a discrepancy's declared rounding rule {"type": "ROUNDING", "decimals": 0-6} -> decimals or None."""
    return rounding_basis({"relationship_basis": item.get("basis")} if isinstance(item, dict) and "basis" in item else {}, err)


# ---------------- period proof (build 13.2) ----------------
def _ym(p):
    return int(p[:4]) * 12 + int(p[5:7]) if p else None


def consecutive_months(first, last):
    """['2025-07', ..., '2026-06'] for 12 months ending at last, or None if first..last is not 12 months."""
    a, b = _ym(first), _ym(last)
    if a is None or b is None or b - a != 11:
        return None
    return [f"{(m - 1) // 12:04d}-{(m - 1) % 12 + 1:02d}" for m in range(a, b + 1)]


def line_cells(rng):
    """a one-row or one-column range -> ([(row, col)...], 'row' | 'column'), else (None, None)."""
    b = parse_range(rng or "")
    if not b or None in b:
        return None, None
    r1, c1, r2, c2 = b
    if r1 == r2:
        return [(r1, c) for c in range(c1, c2 + 1)], "row"
    if c1 == c2:
        return [(r, c1) for r in range(r1, r2 + 1)], "column"
    return None, None


def months_at(book, sheet, cells):
    from verify import parse_period
    cs = book.cells(sheet)
    return [parse_period(cs.get(rc, (None,))[0]) for rc in cells]


def header_for(book, sheet, value_rng, max_steps=40):
    """checking code: the date headers that label a 12-cell value range - scanning up (row ranges) or left (column ranges) for the nearest line
    whose 12 cells all read as months in a row. -> (months, header range) or (None, None). Numbers alone never count as a header."""
    cells, how = line_cells(value_rng)
    if not cells or len(cells) != 12:
        return None, None
    for step in range(1, max_steps + 1):
        hdr = [(r - step, c) for r, c in cells] if how == "row" else [(r, c - step) for r, c in cells]
        if any(x < 1 for rc in hdr for x in rc):
            break
        ms = months_at(book, sheet, hdr)
        if None not in ms and all(_ym(ms[i + 1]) - _ym(ms[i]) == 1 for i in range(11)):
            return ms, f"{addr(*hdr[0])}:{addr(*hdr[-1])}"
    return None, None


def node_match(g, e):
    """does an extraction node e satisfy Gold node g? same source and sheet; a whole-sheet Gold node accepts any cell on the sheet; a
    Gold cell accepts that cell, and a Gold range accepts a cell or range inside it. Numeric equality is never a match."""
    if not g or not e or g[0] is None or e[0] != g[0] or e[1] != g[1]:
        return False
    if g[2] is None:
        return True
    if e[2] is None:
        return False
    if g[2] == e[2]:
        return True
    gb, eb = parse_range(g[2]), parse_range(e[2])
    if not gb or not eb or None in gb or None in eb:
        return False
    return gb[0] <= eb[0] and gb[1] <= eb[1] and eb[2] <= gb[2] and eb[3] <= gb[3]


def norm_text(s):
    t = re.sub(r"[^a-z0-9]+", " ", str(s).lower()).split()
    return " " + " ".join(w[:-1] if len(w) > 3 and w.endswith("s") else w for w in t) + " "


def kw_match(keywords, text):
    """every keyword must be present as whole normalised words; 'a|b' accepts either; no fuzzy similarity of any kind."""
    if not keywords:
        return False
    hay = norm_text(text)
    return all(any(norm_text(alt) in hay for alt in str(k).split("|") if alt.strip()) for k in keywords)


def refs_in_text(text, sheets):
    """cell references written in free text ('Valuation Summary!F26', \"W1:'Cap Table'!M38\") -> {(sheet lower, CELL)}; the sheet part must
    end with a sheet name that Gold or a loaded workbook knows, so 'see Valuation Summary!F26' reads correctly."""
    out = set()
    for m in re.finditer(r"!\$?([A-Za-z]{1,3})\$?(\d+)", str(text)):
        before = skey(str(text)[:m.start()].rstrip("'"))
        for sh in sorted(sheets, key=len, reverse=True):          # the longest name wins ('Valuation Summary', not 'Summary')
            if before.endswith(sh):
                out.add((sh, (m.group(1) + m.group(2)).upper()))
                break
    return out


def tol_eq(a, b):
    return abs(a - b) <= (0.5 if abs(b) >= 1000 else 1e-6 * max(1.0, abs(b)))


def is_rounded(v, g, decimals=None):
    """v is g rounded to `decimals` places (any of 0..4 when not stated): a presentation cell showing 10.14 for 10.1394..."""
    return any(abs(v - round(g, d)) <= 1e-9 * max(1.0, abs(v)) for d in ([decimals] if decimals is not None else range(5)))


def is_scaled(v, g, factor=None, decimals=None):
    """v is g x factor ($000s, $m), exactly or rounded; factor 1e-3 or 1e-6 when not stated"""
    return any(tol_eq(v, g * f) or is_rounded(v, g * f, decimals) for f in ([factor] if factor else [1e-3, 1e-6]))


def val_exact(v, gold):
    v, g = num(v), num(gold)
    return v is not None and g is not None and tol_eq(v, g)


def val_match(v, gold):
    """a workbook value against a Gold number, for the SCORER's information: 'match', 'rounded_match', 'scaled_match', or 'mismatch'."""
    v, g = num(v), num(gold)
    if v is None or g is None:
        return "mismatch"
    if tol_eq(v, g):
        return "match"
    if is_rounded(v, g):
        return "rounded_match"
    return "scaled_match" if is_scaled(v, g) else "mismatch"


def load_workbooks(paths, gold_sources, cache_dir=None):
    """open the supplied workbooks and tie each Gold id to one of them (find_workbook).
    Returns (books {wid: XBook}, notes [(kind, text)], how {wid: how it was matched}); kind is 'error' or 'warning'."""
    cache_dir = cache_dir or tempfile.mkdtemp(prefix="gold_xl_")
    opened = [XBook(p, cache_dir) for p in paths]
    books, notes, used, how = {}, [], set(), {}
    for wid, s in sorted(gold_sources.items()):
        b, h, problem = find_workbook(s, opened)
        if not b:
            notes.append(("error", f"{wid} '{s['file']}': {problem}"))
            continue
        books[wid], how[wid] = b, h
        used.add(b.path)
    for b in opened:
        if b.path not in used:
            notes.append(("warning", f"supplied workbook '{b.file}' is not in Gold's source_files"))
    return books, notes, how


def copy_target(formula, here, book):
    """if a formula only copies ONE cell - =A1, =A1*0.001, =A1/1000, =-A1, =ROUND(A1,0) - return (ext, sheet, cell); else None.
    A formula that combines cells, sums a range or calls any other function is never a copy."""
    if not formula or not formula.startswith("="):
        return None
    core = formula[1:]
    if re.search(r"[:+,]", core.lstrip("+")) and not re.match(r"^[-+]?ROUND(UP|DOWN)?\(", core, re.I):    # cheap exits before tokenising: ranges, sums, lists
        return None
    if len(re.findall(r"\$?\b[A-Za-z]{1,3}\$?\d+\b", core)) > 1 or "[" in core and len(re.findall(r"\]", core)) > 1:
        return None
    try:
        from openpyxl.formula.tokenizer import Tokenizer
        toks = [t for t in Tokenizer(formula).items if t.type != "WHITE-SPACE"]
    except Exception:
        return None
    refs = [t for t in toks if t.type == "OPERAND" and t.subtype == "RANGE"]
    if len(refs) != 1:
        return None
    for t in toks:
        ok = ((t.type == "OPERAND" and t.subtype in ("RANGE", "NUMBER")) or (t.type == "OPERATOR-INFIX" and t.value in ("*", "/"))
              or (t.type == "OPERATOR-PREFIX" and t.value in ("-", "+")) or t.type in ("PAREN", "SEP")
              or (t.type == "FUNC" and (t.subtype == "CLOSE" or t.value.upper() in ("ROUND(", "ROUNDUP(", "ROUNDDOWN("))))
        if not ok:
            return None
    got = formula_refs(formula, here, book)
    if len(got) != 1:
        return None
    ext, sheet, rng = got[0]
    b = parse_range(rng)
    if not b or None in b or (b[0], b[1]) != (b[2], b[3]):
        return None
    return ext, sheet, rng.replace("$", "")


class Graph:
    """undirected 'is a copy of' graph over cells of the supplied workbooks, keyed (wid, sheet lower, CELL)."""

    def __init__(self, books):
        self.books, self.adj = books, {}
        by_name = {norm_file(b.file): wid for wid, b in books.items()}
        for wid, b in books.items():
            for sh in b.sheet_names():
                for (r, c), cell in b.cells(sh).items():
                    t = copy_target(cell[1], sh, b)
                    if not t:
                        continue
                    ext, rs, rng = t
                    twid = wid if ext is None else by_name.get(norm_file(b.ext_file(ext) or ""))
                    if not twid:
                        continue
                    ts = books[twid].resolve_sheet(rs) or rs
                    n1, n2 = (wid, skey(sh), addr(r, c).upper()), (twid, skey(ts), rng.upper())
                    self.adj.setdefault(n1, set()).add(n2)
                    self.adj.setdefault(n2, set()).add(n1)

    def linked(self, a, g, depth=8):
        """a chain of pure copies from node a to Gold node g (a cell, or a whole sheet) -> list of nodes, else None."""
        a = tuple(a[:3])
        if a[0] is None or a[2] is None or None in (parse_range(a[2]) or (None,)):
            return None
        seen, frontier = {a: None}, [a]
        for _ in range(depth):
            nxt = []
            for n in frontier:
                if n != a and node_match(g, n):
                    path = [n]
                    while seen[path[-1]] is not None:
                        path.append(seen[path[-1]])
                    return list(reversed(path))
                for m in self.adj.get(n, ()):
                    if m not in seen:
                        seen[m] = n
                        nxt.append(m)
            frontier = nxt
        for n in frontier:
            if node_match(g, n):
                path = [n]
                while seen[path[-1]] is not None:
                    path.append(seen[path[-1]])
                return list(reversed(path))
        return None


def show_node(n):
    return f"{n[0]}:'{n[1]}'!{n[2]}" if n[2] else f"{n[0]}:'{n[1]}'"


# ---------------- validation ----------------
def walk_strings(x, path=""):
    if isinstance(x, str):
        yield path, x
    elif isinstance(x, dict):
        for k, v in x.items():
            yield from walk_strings(v, f"{path}.{k}" if path else str(k))
    elif isinstance(x, list):
        for i, v in enumerate(x):
            yield from walk_strings(v, f"{path}[{i}]")


def validate(gold, workbook_paths=None, cache_dir=None, manifest=None):
    """-> {'errors': [...], 'warnings': [...], 'books': {wid: XBook} or None, 'how': {wid: how matched}, 'gold': the effective key}.
    Every error starts with its owner: [GOLD_METADATA] (the key is wrong or unfinished), [BENCHMARK_INTEGRITY] (the files are not the
    frozen ones), [TESTBENCH_VALIDATION] (the key could not be read)."""
    E, W = [], []
    err = lambda m, c="GOLD_METADATA": E.append(f"[{c}] {m}")
    warn = W.append
    if not isinstance(gold, dict):
        return {"errors": ["[TESTBENCH_VALIDATION] Gold is not a JSON object"], "warnings": [], "books": None, "how": {}, "gold": gold}
    if manifest:
        gold, merr = apply_manifest(gold, manifest)
        for m in merr:
            err(m, "BENCHMARK_INTEGRITY")
    if gold.get("schema") != SCHEMA:
        err(f"schema is {gold.get('schema')!r}; this validator reads {SCHEMA!r} only")
    if not str(gold.get("case_id") or "").strip():
        err("case_id is missing")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(gold.get("quarter_end") or "")):
        err("quarter_end must be YYYY-MM-DD")
    cert = gold.get("certification") or {}
    # material_truth_complete = YES means the key captures all the material truth the analyst expects the extraction to discover from this
    # evidence package. It does not mean every approval is known or every ambiguity resolved: UNRESOLVED is a legitimate Gold answer.
    if cert.get("material_truth_complete") != "YES":
        err(f"certification.material_truth_complete is {cert.get('material_truth_complete')!r}, not YES")
    if cert.get("missing"):
        err(f"certification lists material truth the key does not yet capture: {cert.get('missing')}")
    for path, s in walk_strings(gold):
        if PLACEHOLDER.search(s):
            err(f"placeholder text at {path}: {s[:60]!r}")
    src = source_files(gold)
    if not src:
        err("source_files is missing or empty")
    for wid, s in src.items():
        if not re.fullmatch(r"W\d+", wid):
            err(f"source id {wid!r} must look like W1")
        if not s["file"]:
            err(f"{wid}: no file name")
        if s["sha256"] and not re.fullmatch(r"[0-9a-f]{64}", s["sha256"]):
            err(f"{wid}: sha256 must be 64 hex characters")
    answers = gold.get("answers")
    if not isinstance(answers, dict) or not answers:
        err("answers is missing or empty")
        answers = {}
    refs = []                                                       # (where, ref string)

    def need_ref(where, ref):
        if not isinstance(ref, str) or not parse_ref(ref):
            hint = " (the sheet name goes inside the quotes and the ! after the closing quote: W1:'Sheet Name'!A1)" if isinstance(ref, str) and re.search(r"'[^']*!'", ref) else ""
            err(f"{where}: reference {ref!r} is not W<n>:'Sheet'!Cell or W<n>:'Sheet'{hint}")
            return
        refs.append((where, ref))
        if parse_ref(ref)[0] not in src:
            err(f"{where}: source {parse_ref(ref)[0]} is not in source_files")

    for key, c in answers.items():
        if not isinstance(c, dict):
            err(f"answers.{key} is not an object")
            continue
        if c.get("answer") in (None, ""):
            err(f"answers.{key}.answer is missing")
        if key not in KNOWN:
            warn(f"answers.{key} is not a concept this build knows; scoring will report NOT_EXPRESSIBLE_IN_SCHEMA")
        if key != "company_to_fund_relationship":
            if not isinstance(c.get("primary_anchor"), dict) and not (key == "metric_period" and isinstance(c.get("header_anchor"), dict)):
                err(f"answers.{key}.primary_anchor is missing")
        for a in c.get("supporting_anchors") or []:
            if isinstance(a, dict) and a.get("support") == "component" and a.get("component") is not None and a.get("component") not in COMPONENTS:
                err(f"answers.{key}: a component anchor's component must be one of {list(COMPONENTS)}, not {a.get('component')!r}")
        for kind, ref in anchors_of(c):
            need_ref(f"answers.{key}.{kind}_anchor", ref)
        field = NUMERIC.get(key)
        if field:
            if c.get(field) is None:
                if key not in OPTIONAL_NUMERIC:
                    err(f"answers.{key}.{field} must be a number")
            elif num(c.get(field)) is None:
                err(f"answers.{key}.{field} must be a number when given")
    for k in KNOWN:
        if k not in answers:
            warn(f"answers.{k} is absent: that concept is not scored")
    mp = answers.get("metric_period") or {}
    for f in ("first_month", "last_month"):
        if mp and not re.fullmatch(r"\d{4}-\d{2}", str(mp.get(f) or "")):
            err(f"answers.metric_period.{f} must be YYYY-MM")
    rel = answers.get("company_to_fund_relationship")
    if isinstance(rel, dict):
        if rel.get("answer") not in RELATIONSHIPS:
            err("answers.company_to_fund_relationship.answer must be MATCH, DIFFERENT or UNRESOLVED")
        cv, fv = (answers.get("company_value") or {}).get("answer"), (answers.get("fund_reported_value") or {}).get("answer")
        if num(rel.get("company_value")) is not None and num(cv) is not None and num(rel["company_value"]) != num(cv):
            err("company_to_fund_relationship.company_value differs from answers.company_value")
        if num(rel.get("fund_reported_value")) is not None and num(fv) is not None and num(rel["fund_reported_value"]) != num(fv):
            err("company_to_fund_relationship.fund_reported_value differs from answers.fund_reported_value")
        dec = rounding_basis(rel, err)
        if num(cv) is not None and num(fv) is not None:
            if rel.get("answer") == "MATCH" and cv != fv:
                if dec is not None and rounds_to(cv, fv, dec):
                    warn(f"relationship is MATCH under the declared rounding to {dec} decimal(s): the company value rounds to the fund value")
                elif dec is not None:
                    err(f"relationship is MATCH with rounding to {dec} decimal(s), but the company value does not round to the fund value")
                else:
                    err("relationship is MATCH but the company and fund values differ")
            if rel.get("answer") == "DIFFERENT" and cv == fv:
                err("relationship is DIFFERENT but the company and fund values are equal")
    br, ev = answers.get("equity_bridge") or {}, (answers.get("enterprise_value") or {}).get("answer")
    if all(num(x) is not None for x in (br.get("cash"), br.get("debt"), br.get("equity_value"), ev)):
        if abs(num(ev) + num(br["cash"]) - num(br["debt"]) - num(br["equity_value"])) > 0.5:
            err("Gold disagrees with itself: enterprise value + cash - debt != equity value")
    mat = gold.get("materiality")
    if mat is not None:
        t = mat.get("immaterial_below") if isinstance(mat, dict) else None
        if not isinstance(mat, dict) or num(t) is None or num(t) < 0:
            err("materiality must be {\"immaterial_below\": <dollar amount, 0 or more>}; percentages are not accepted in this build")
    seen = set()
    for key, label, allowed in (("known_rivals", "rival", None), ("material_discrepancies", "discrepancy", DISC_STATUS), ("human_judgments", "judgment", None)):
        items = gold.get(key)
        if items is None:
            items = []
        if not isinstance(items, list):
            err(f"{key} must be a list")
            continue
        for i, it in enumerate(items):
            w = f"{key}[{i}]"
            if not isinstance(it, dict):
                err(f"{w} is not an object")
                continue
            if iid(it):
                if iid(it) in seen:
                    err(f"{w}: duplicate id {iid(it)!r}")
                seen.add(iid(it))
            for ref in it.get("cells") or []:
                need_ref(f"{w}.cells", ref)
            if allowed and it.get("status") not in allowed:
                err(f"{w}.status must be one of {sorted(allowed)}")
            if key == "human_judgments" and it.get("answer") != "UNRESOLVED":
                err(f"{w}.answer must be UNRESOLVED (this build scores only judgments the workbooks cannot settle)")
            if key == "known_rivals" and not (it.get("candidate") and it.get("why_not_the_answer")):
                err(f"{w} needs candidate and why_not_the_answer")
            if key == "material_discrepancies" and not it.get("item"):
                err(f"{w} needs item")
            if key == "human_judgments" and not it.get("question"):
                err(f"{w} needs question")
            if not (iid(it) or it.get("cells") or it.get("keywords")):
                warn(f"[UNSCORED_MATCHING_METADATA] {w} has no id, cells or keywords: it cannot be matched deterministically and will score UNSCORED "
                     f"(gold_suggest.py lists what to add)")
            if "immaterial_below" in it and (num(it.get("immaterial_below")) is None or num(it["immaterial_below"]) < 0):
                err(f"{w}.immaterial_below must be a dollar amount, 0 or more (percentages are not accepted in this build)")
            if "basis" in it:
                if key != "material_discrepancies" or it.get("status") != "ROUNDING":
                    err(f"{w}.basis is only for a ROUNDING discrepancy")
                elif item_basis(it) is None:
                    err(f'{w}.basis must be {{"type": "ROUNDING", "decimals": 0 to 6}}')
            kws = it.get("keywords")
            if kws is not None and not (isinstance(kws, list) and all(isinstance(k, str) and k.strip() for k in kws)):
                err(f"{w}.keywords must be a list of non-empty strings")
    books, how, sheets_log = None, {}, []
    if workbook_paths:
        books, notes, how = load_workbooks(workbook_paths, src, cache_dir)
        for kind, text in notes:
            if kind == "error":
                err(text, "BENCHMARK_INTEGRITY")
            else:
                warn(text)
        for wid, b in books.items():
            if how.get(wid) != "sha256":
                warn(f"{wid}: matched '{b.file}' by file name (normalised); Gold has no sha256, so the frozen binary is {b.sha256[:12]}... "
                     f"(gold_sources.py writes a manifest)")
        seen_sheet = set()
        for where, ref in refs:
            wid, sheet, cell = parse_ref(ref)
            b = books.get(wid)
            if not b:
                continue
            raw, method, problem = resolve_gold_sheet(b, sheet)
            if problem:
                err(f"{where}: {wid} {problem}", "BENCHMARK_INTEGRITY" if problem.startswith("ambiguous") else "GOLD_METADATA")
                continue
            if (wid, sheet) not in seen_sheet:
                seen_sheet.add((wid, sheet))
                sheets_log.append({"wid": wid, "gold": sheet, "raw": raw, "method": method})
                if method != "EXACT":
                    warn(f"{wid}: Gold wrote sheet {sheet!r}; the workbook's raw sheet name is {raw!r} ({method})")
            if cell and parse_cell(cell):
                if b.get(raw, cell) is None:
                    err(f"{where}: {wid}:'{raw}'!{cell} is empty in the workbook")
            elif cell and not range_populated(b, raw, cell):
                err(f"{where}: {wid}:'{raw}'!{cell} holds no values or formulas in the workbook")
        # numeric answers. PRIMARY anchor = the authoritative location: it must reproduce Gold's number (floating-point tolerance), or declare an
        # explicit scaling ("support": "scaled", optional "factor"). SUPPORTING anchor = corroboration: it must exist; its number is compared only
        # as its declared or stated support class says (exact | rounded [decimals] | scaled [factor] | context), where `support` is an optional key
        # on the anchor and, when absent, the class is read from `shows` ("rounded", "$000s"/"thousands"/"scaled"); with neither, a rounded or
        # scaled display is recognised and an unrelated number is only a warning. Whole-sheet anchors are never compared to any number.
        for key, field in NUMERIC.items():
            c = answers.get(key)
            if not isinstance(c, dict) or num(c.get(field)) is None:
                continue
            g = num(c[field])
            for kind, anchor in [("primary", c.get("primary_anchor"))] + [("supporting", x) for x in c.get("supporting_anchors") or []]:
                ref = anchor.get("ref") if isinstance(anchor, dict) else None
                p = parse_ref(ref) if isinstance(ref, str) else None
                if not p or not p[2] or not parse_cell(p[2]) or p[0] not in books:
                    continue
                b = books[p[0]]
                raw, _, problem = resolve_gold_sheet(b, p[1])
                if problem or b.get(raw, p[2]) is None:
                    continue
                v = b.value(raw, p[2])
                what = f"answers.{key}: Gold says {c[field]} but {kind} anchor {ref} holds {v}"
                decl = anchor.get("support")
                dec, fac = anchor.get("decimals"), anchor.get("factor")
                if kind == "primary":
                    if decl in (None, "exact"):
                        if not val_exact(v, g):
                            err(what + " (a primary anchor must reproduce Gold's answer; if it is a scaled copy, declare \"support\": \"scaled\" with a factor)")
                    elif decl == "scaled":
                        if not is_scaled(num(v) if num(v) is not None else float("nan"), g, fac, dec):
                            err(what + f" (declared scaled{'' if not fac else ' x ' + str(fac)})")
                    else:
                        err(f"answers.{key}: a primary anchor may be exact or explicitly scaled, not {decl!r}")
                    continue
                shows = str(anchor.get("shows") or "")
                if decl is None:
                    if re.search(r"\brounded\b|\b\d decimals?\b", shows, re.I):
                        decl = "rounded"
                    elif re.search(r"\$?000s|thousands|in millions|\bscaled\b", shows, re.I):
                        decl = "scaled"
                    decl_from = "shows" if decl else None
                else:
                    decl_from = "support"
                nv = num(v)
                if decl == "context":
                    continue
                if decl == "component":
                    part = anchor.get("component")
                    if nv is None:
                        err(f"answers.{key}: component anchor {ref} holds no number")
                    elif part and num(c.get(part)) is not None and not val_exact(v, c[part]):
                        err(f"answers.{key}: component anchor {ref} holds {v}, but Gold's {part} is {c[part]}")
                    continue
                ok = {"exact": lambda: val_exact(v, g), "rounded": lambda: nv is not None and is_rounded(nv, g, dec),
                      "scaled": lambda: nv is not None and is_scaled(nv, g, fac, dec)}
                if decl in ok:
                    if not ok[decl]():
                        err(what + f" (this supporting anchor is stated as {decl} via {decl_from}; its value does not fit)")
                elif decl is not None:
                    err(f"answers.{key}: supporting anchor support must be exact, rounded, scaled, context or component, not {decl!r}")
                elif nv is None or not (val_exact(v, g) or is_rounded(nv, g) or is_scaled(nv, g)):
                    warn(f"answers.{key}: supporting anchor {ref} holds {v}, which is not Gold's {c[field]}, a rounding of it, or a scaling of it; accepted as corroboration "
                         f"(add \"support\": \"component\" for a part such as cash or debt, or \"context\")")
        check_period(answers, books, err, warn)
        check_rounding_items(gold, books, err)
    else:
        warn("workbooks not supplied: file presence, SHA-256, anchor cells and numeric answers were not checked against the workbooks")
    return {"errors": E, "warnings": W, "books": books, "how": how, "gold": gold, "sheets": sheets_log}


def _cell_of(books, ref):
    """(book, raw sheet, cell range) for a Gold reference with a cell, or None."""
    p = parse_ref(ref) if isinstance(ref, str) else None
    if not p or not p[2] or p[0] not in books:
        return None
    raw, _, problem = resolve_gold_sheet(books[p[0]], p[1])
    return None if problem else (books[p[0]], raw, p[2])


def check_period(answers, books, err, warn):
    """build 13.2: header_anchor and value_anchor together must establish the period."""
    mp = answers.get("metric_period") or {}
    if not isinstance(mp, dict) or not (mp.get("header_anchor") or mp.get("value_anchor")):
        return
    want = consecutive_months(mp.get("first_month"), mp.get("last_month"))
    if not want:
        err("answers.metric_period: first_month..last_month is not 12 months")
        return
    h = _cell_of(books, (mp.get("header_anchor") or {}).get("ref"))
    v = _cell_of(books, (mp.get("value_anchor") or {}).get("ref"))
    hc = vc = None
    if mp.get("header_anchor"):
        if not h:
            err("answers.metric_period.header_anchor must be a 12-cell row or column of date headers in a supplied workbook")
        else:
            hc, _ = line_cells(h[2])
            got = months_at(h[0], h[1], hc) if hc else None
            if not hc or len(hc) != 12:
                err("answers.metric_period.header_anchor must cover exactly 12 cells in one row or one column")
            elif got != want:
                err(f"answers.metric_period.header_anchor reads {got}, not the 12 months {want[0]}..{want[-1]}")
    if mp.get("value_anchor"):
        if not v:
            err("answers.metric_period.value_anchor must be a 12-cell row or column of monthly values in a supplied workbook")
        else:
            vc, vhow = line_cells(v[2])
            cs = v[0].cells(v[1])
            vals = [num(cs.get(rc, (None,))[0]) for rc in vc] if vc else []
            if not vc or len(vc) != 12:
                err("answers.metric_period.value_anchor must cover exactly 12 cells in one row or one column")
            elif None in vals:
                err("answers.metric_period.value_anchor: every one of the 12 cells must hold a number")
            else:
                mv = num((answers.get("valuation_metric") or {}).get("value"))
                if mv is not None and abs(sum(vals) - mv) > max(1.0, 1e-6 * abs(mv)):
                    err(f"answers.metric_period.value_anchor sums to {sum(vals)}, not valuation_metric.value {mv}")
                if h and hc and len(hc) == 12:
                    if (h[0] is v[0]) and skey(h[1]) == skey(v[1]):
                        hhow = line_cells(h[2])[1]
                        aligned = hhow == vhow and all((a[1] if vhow == "row" else a[0]) == (b[1] if vhow == "row" else b[0]) for a, b in zip(hc, vc))
                        if not aligned:
                            err("answers.metric_period: header_anchor and value_anchor do not line up (different columns or rows)")
                    else:
                        warn("answers.metric_period: header_anchor and value_anchor are on different sheets, so their alignment is not proven; "
                             "the header proves the months and the values are checked on their own")
                elif not mp.get("header_anchor"):
                    ms, _ = header_for(v[0], v[1], v[2])
                    if ms != want:
                        err("answers.metric_period.value_anchor: no date header labels these cells with the 12 months "
                            f"{want[0]}..{want[-1]} (add a header_anchor)")


def check_rounding_items(gold, books, err):
    """build 13.2: a ROUNDING discrepancy with a declared basis must really round, in the workbooks."""
    for i, it in enumerate(gold.get("material_discrepancies") or []):
        if not isinstance(it, dict) or it.get("status") != "ROUNDING" or item_basis(it) is None:
            continue
        vals = []
        for r in it.get("cells") or []:
            c = _cell_of(books, r)
            if c and parse_cell(c[2]):
                vals.append(c[0].value(c[1], c[2]))
        if len(vals) < 2 or None in vals[:2]:
            err(f"material_discrepancies[{i}]: a ROUNDING basis needs its first two cells to hold the two values")
        elif not rounds_to(vals[0], vals[1], item_basis(it)):
            err(f"material_discrepancies[{i}]: {vals[0]} and {vals[1]} do not round to each other at {item_basis(it)} decimal(s)")


def main(argv=None):
    ap = argparse.ArgumentParser(description="validate a gold-mvp/3 key")
    ap.add_argument("--gold", required=True)
    ap.add_argument("--workbooks", nargs="*")
    ap.add_argument("--sources", help="frozen source manifest (from gold_sources.py) supplying SHA-256s Gold does not yet carry")
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    try:
        gold = read_json(a.gold)
    except Exception as e:
        print(f"GOLD INVALID: [TESTBENCH_VALIDATION] cannot read {os.path.basename(a.gold)}: {e}")
        return 2
    r = validate(gold, a.workbooks, manifest=read_json(a.sources) if a.sources else None)
    gold = r["gold"] if isinstance(r["gold"], dict) else gold
    cid = gold.get("case_id") if isinstance(gold, dict) else "?"
    n = lambda k: len(gold.get(k) or []) if isinstance(gold, dict) else 0
    if r["errors"]:
        print(f"GOLD INVALID: {cid} | {len(r['errors'])} errors | {len(r['warnings'])} warnings")
    else:
        print(f"GOLD VALID: {cid} | {SCHEMA} | {len((gold.get('answers') or {}))} concepts, {n('known_rivals')} rivals, "
              f"{n('material_discrepancies')} discrepancies, {n('human_judgments')} unresolved decisions | {len(r['warnings'])} warnings")
    for e in r["errors"]:
        print(f"- ERROR: {e}")
    for w in r["warnings"]:
        print(f"- WARN: {w}")
    for wid, h in sorted(r["how"].items()):
        print(f"- SOURCE {wid}: matched by {h}")
    for x in r.get("sheets") or []:
        print(f"- SHEET {x['wid']}: Gold wrote {x['gold']!r} | workbook raw sheet {x['raw']!r} | {x['method']}")
    if a.out:
        json.dump({"valid": not r["errors"], "errors": r["errors"], "warnings": r["warnings"]}, open(a.out, "w"), indent=1)
    return 1 if r["errors"] else 0


if __name__ == "__main__":
    sys.exit(main())
