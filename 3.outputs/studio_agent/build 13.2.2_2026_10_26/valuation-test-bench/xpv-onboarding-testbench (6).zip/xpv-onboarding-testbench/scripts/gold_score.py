# gold_score.py (build 13.2, test bench) - GOLD ACCURACY: did the extraction discover and interpret the material truth an analyst wrote
# down in a gold-mvp/3 key? Native (the key is never translated into the older trial-key format), deterministic (no LLM judge, no
# free-text similarity), and SEPARATE from workbook verification: verify.py answers "are its checkable claims supported by the
# workbooks?"; this answers "did it find what matters?". The two are printed side by side and never merged.
#
# What is scored, per Gold section
#   answers (core concepts)   CORRECT | WRONG | OMITTED | NOT_EXPRESSIBLE_IN_SCHEMA (| NEEDS_ANALYST when it cannot be decided)
#       cell concepts are decided by the extraction's anchor: EXACT_ANCHOR (Gold's primary), GOLD_EQUIVALENT_ANCHOR (Gold lists it as a
#       supporting anchor), VERIFIED_LINKED_EQUIVALENT (a chain of pure copies - =A1, =A1/1000, =ROUND(A1,0) - from a Gold anchor, found
#       in the supplied workbooks), WRONG_ANCHOR, MISSING; UNVERIFIED when a link check was needed but no workbooks were supplied.
#       Numeric equality is never a link. Labels (method) are normalised ("EV/EBITDA" = "EV/EBITDA multiple"); the period is compared
#       as months; the waterfall by the sheet Gold names; the company-to-fund relationship from the extraction's discrepancies and edges.
#   known_rivals              CORRECTLY_REJECTED | SELECTED_RIVAL | NOT_ADDRESSED (neither used nor rejected: did not distinguish)
#   material_discrepancies    FOUND | MISINTERPRETED | OMITTED
#   human_judgments (UNRESOLVED)  PRESERVED_UNRESOLVED | UNSUPPORTED_CONCLUSION | OMITTED
#   Matching of rivals / discrepancies / judgments to extraction items, in this order only: explicit id (the extraction item's own
#   "gold_id"), the cells they reference (Gold's cells vs the item's cells, or cell references written in its text), normalised
#   keywords, otherwise NEEDS_ANALYST (referenced somewhere but not where expected) or UNSCORED (Gold gave no matching metadata).
# Source identity: Gold W1..Wn are tied to extraction source ids by SHA-256 when Gold gives one, else by file name; with workbooks the
# supplied files' SHA-256 is recomputed. A failure is an INTEGRITY error, never a valuation-answer error (affected items become
# NEEDS_ANALYST).
# Build 13.2 (additive; a 13.1 key scores as before):
#   metric_period is graded three ways - the answer (months), the header evidence and the value evidence. A range other than Gold's is
#       accepted (anchor VERIFIED_SAME_PERIOD) only when checking code reads its date headers as Gold's 12 months AND its 12 values sum to the
#       metric; matching numbers alone never prove a period.
#   component anchors (cash, debt) support the bridge and are never an equivalent of the equity value.
#   ROUNDING discrepancy recorded as a checkable edge (e.g. rounded_match) = FOUND only when checking code confirms Gold's declared rounding
#       rule on the workbook values.
#   Gold UNRESOLVED / REAL vs an extraction that explains it or calls it immaterial: FOUND when checking code shows the difference is below
#       Gold's own dollar threshold (immaterial_below); NEEDS_ANALYST when checking code confirms the difference and the extraction cites driver
#       cells beyond the two compared; otherwise MISINTERPRETED / UNSUPPORTED_CONCLUSION as before. The extraction never overrules Gold.
#   Extraction discrepancies Gold does not list: FOUND_NOT_IN_GOLD when checking code (or a fresh verification.json) confirms them,
#       else EXTRA_NOT_VERIFIED; no credit or penalty either way, and never added to Gold automatically.
#   "Unresolved decisions" is the display name of human_judgments (the JSON field keeps its name).
# Usage: python gold_score.py --gold KEY.json --extraction extraction.json [--workbooks A.xlsx ...] [--verification verification.json] [--out report.json]
import argparse, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gold_validate as GV  # noqa: E402
from gold_validate import (gnode, anchors_of, node_match, kw_match, refs_in_text, val_match, show_node, parse_ref, Graph, canon_name, iid, skey, name_tier, name_candidates, rounding_basis,  # noqa: E402
                           rounds_to, threshold, item_basis, consecutive_months, line_cells, months_at, header_for)
from xlsx_evidence import split_ref, parse_range, parse_cell, num, addr  # noqa: E402
from onboarding_schema import CHECKABLE  # noqa: E402

CORE_ROLES = {"valuation_metric": "valuation_metric", "applied_multiple": "selected_multiple", "enterprise_value": "enterprise_value",
              "equity_bridge": "equity_value", "company_value": "value_to_xpv", "fund_reported_value": "fund_cell"}
OK_ANCHOR = {"EXACT_ANCHOR", "GOLD_EQUIVALENT_ANCHOR", "VERIFIED_LINKED_EQUIVALENT", "VERIFIED_SAME_PERIOD"}
EQUIV_KINDS = ("primary", "supporting")          # build 13.2: only these anchors stand for the answer (component / header / value do not)
METHODS = {"ev ebitda", "ev revenue", "blend of", "held at cost", "other"}
METHOD_ALIAS = {"ebitda": "ev ebitda", "enterprise value ebitda": "ev ebitda", "revenue": "ev revenue", "ev sales": "ev revenue",
                "ev revenue": "ev revenue", "sales": "ev revenue"}


def canon_method(s):
    t = re.sub(r"[^a-z0-9/ ]", " ", str(s).lower())
    t = re.sub(r"\b(multiples?|method|valuation|approach|based|the|a)\b", " ", t)
    t = re.sub(r"\benterprise value\b", "ev", t)
    t = re.sub(r"\bto\b|/", " ", t)
    t = " ".join(t.split())
    return METHOD_ALIAS.get(t, t)


def month(s):
    m = re.match(r"^\s*(\d{4})-(\d{2})", str(s or ""))
    return f"{m.group(1)}-{m.group(2)}" if m else None


def gids(item):
    g = item.get("gold_id") if isinstance(item, dict) else None
    return set(g) if isinstance(g, list) else ({g} if g else set())


def item_text(d):
    return " - ".join(str(d.get(k)) for k in ("what", "why", "driver", "question", "text") if d.get(k))


def source_integrity(gsrc, ex_sources, books, allow=False):
    """compare, per Gold workbook, the FROZEN binary (the supplied workbook's SHA-256; else the SHA-256 Gold or its manifest carries) with the
    SHA-256 the historical extraction recorded for the file it read.
      SAME_BINARY       the extraction read exactly this binary
      DIFFERENT_BINARY  it read a file with the same (normalised) name but another SHA-256: a re-saved or re-downloaded copy
      NOT_COMPARABLE    the frozen binary or the extraction's SHA-256 is not known, so only the name ties them
      MISSING           no extraction source matches (or the name is ambiguous)
    A different binary is a BENCHMARK_INTEGRITY problem, never a wrong answer: its concepts are not scored (NEEDS_ANALYST) unless the run is
    explicitly told to score a different saved copy (allow=True), which is then stated in the report.
    Returns (gmap ext id -> Gold id, g2e, rows, blocking problems)."""
    gmap, g2e, rows, bad = {}, {}, [], []
    for wid, s in sorted(gsrc.items()):
        frozen = books[wid].sha256 if wid in books else s["sha256"]
        sup = books[wid].file if wid in books else None
        row = {"wid": wid, "file": s["file"], "filename_match": None if not sup else "EXACT" if sup == s["file"] else "NORMALIZED" if name_tier(sup, s["file"]) else "DIFFERENT (tied by SHA-256)", "frozen_sha256": frozen, "frozen_from": "supplied workbook" if wid in books else ("Gold/manifest sha256" if frozen else None),
               "extraction_id": None, "extraction_sha256": None, "matched_by": None}
        cand = next((x for x in ex_sources if frozen and (x.get("sha256") or "").lower() == frozen), None)
        by = "sha256"
        if not cand:
            same, how = name_candidates(ex_sources, s["file"], lambda x: x.get("file"))
            if len(same) > 1:
                row["status"] = "MISSING"
                row["note"] = f"ambiguous: {len(same)} extraction sources share this normalised name"
            elif same:
                cand, by = same[0], how
        if cand:
            xs = (cand.get("sha256") or "").lower() or None
            row.update(extraction_id=cand["id"], extraction_sha256=xs, matched_by=by)
            row["status"] = "SAME_BINARY" if by == "sha256" else "NOT_COMPARABLE" if not (xs and frozen) else "SAME_BINARY" if xs == frozen else "DIFFERENT_BINARY"
        elif "status" not in row:
            row["status"] = "MISSING"
            row["note"] = "not among the extraction's sources"
        ok = row["status"] in ("SAME_BINARY", "NOT_COMPARABLE") or (row["status"] == "DIFFERENT_BINARY" and allow)
        if ok and cand["id"] in gmap:
            bad.append(f"{wid} and {gmap[cand['id']]} both map to extraction source {cand['id']}")
            row["status"], ok = "MISSING", False
        if ok:
            gmap[cand["id"]], g2e[wid] = wid, cand["id"]
        elif row["status"] == "DIFFERENT_BINARY":
            bad.append(f"{wid} '{s['file']}': the extraction recorded SHA-256 {row['extraction_sha256'][:12]}... but the benchmark binary is {frozen[:12]}... (a different saved copy)")
        elif row["status"] == "MISSING":
            bad.append(f"{wid} '{s['file']}': {row.get('note', 'not among the extraction sources')}")
        rows.append(row)
    return gmap, g2e, rows, bad


def integrity_summary(rows, allow):
    n = len(rows)
    same = sum(1 for r in rows if r["status"] == "SAME_BINARY")
    diff = sum(1 for r in rows if r["status"] == "DIFFERENT_BINARY")
    miss = sum(1 for r in rows if r["status"] == "MISSING")
    if diff or miss:
        t = f"MISMATCH ({diff} different binary, {miss} missing)"
        return t + (" - scoring a different saved copy was explicitly allowed" if allow and not miss else "")
    return f"SAME_BINARY ({same}/{n})" if same == n else f"NOT COMPARABLE ({n - same} of {n} can be tied to the extraction by name only)"


class Scorer:
    def __init__(self, gold, doc, books=None, allow_different=False, verification=None):
        self.gold, self.doc, self.books = gold, doc, books or {}
        self.verif = verification if isinstance(verification, dict) else None      # a FRESH verification.json only (never the copy inside the extraction)
        self.used = set()                                                            # id() of extraction discrepancies a Gold item or concept accounts for
        self.ans = gold.get("answers") or {}
        self.ch = doc.get("chain") or {}
        self.gmap, self.g2e, self.rows, self.integrity = source_integrity(GV.source_files(gold), doc.get("sources") or [], self.books, allow_different)
        self.allow_different = allow_different
        self.graph = Graph(self.books) if self.books else None
        self.sets = {k: [n for n in (gnode(r) for kind, r in anchors_of(c) if kind in EQUIV_KINDS) if n and n[2]] for k, c in self.ans.items() if isinstance(c, dict)}
        self.sheets = {}                                        # sheet lower -> {wid} (from every Gold reference and every loaded book)
        for it in [c for c in self.ans.values() if isinstance(c, dict)] + [i for k in ("known_rivals", "material_discrepancies", "human_judgments")
                                                                         for i in gold.get(k) or []]:
            refs = [r for _, r in anchors_of(it)] + list(it.get("cells") or [])
            for r in refs:
                n = gnode(r)
                if n:
                    self.sheets.setdefault(n[1], set()).add(n[0])
        for wid, b in self.books.items():
            for sh in b.sheet_names():
                self.sheets.setdefault(skey(sh), set()).add(wid)
        self.disc = [d for d in doc.get("discrepancies") or [] if isinstance(d, dict)]
        self.rej = [d for d in doc.get("rejected") or [] if isinstance(d, dict)]
        self.edges = [e for k in ("provenance", "downstream") for e in doc.get(k) or [] if isinstance(e, dict)]
        self.qs = [q if isinstance(q, dict) else {"question": str(q)} for q in doc.get("open_questions") or []]

    # ---- extraction side ----
    def node(self, ref, default=None):
        if not isinstance(ref, dict):
            return None
        s, cell = ref.get("source") or default, ref.get("cell") or ref.get("cells")
        if not s or not isinstance(cell, str):
            return None
        sheet, a = split_ref(cell)
        if not sheet or not a:
            return None
        return (self.gmap.get(s), skey(sheet), a.upper(), f"{s}:{cell}")

    def role_node(self, role):
        d = self.ch.get(role)
        return self.node(d, None if role == "fund_cell" else self.ch.get("source"))

    def all_refs(self):
        out = []
        dflt = self.ch.get("source")
        for k, v in self.ch.items():
            if isinstance(v, dict) and (v.get("cell") or v.get("cells")):
                out.append((self.node(v, dflt), f"chain.{k}"))
            elif isinstance(v, list):
                out += [(self.node(x, dflt), f"chain.{k}") for x in v if isinstance(x, dict)]
        out += [(self.node(x), "path") for x in self.doc.get("path") or [] if isinstance(x, dict)]
        for e in self.edges:
            out += [(self.node(e.get("from")), f"edge {e.get('id', '')}"), (self.node(e.get("to")), f"edge {e.get('id', '')}")]
        for d in self.disc:
            out += [(self.node(d.get("a")), f"discrepancy {d.get('id', '')}"), (self.node(d.get("b")), f"discrepancy {d.get('id', '')}")]
            out += [(self.node(x), f"discrepancy {d.get('id', '')}") for x in d.get("driver_cells") or []]
        out += [(self.node(r), "rejected") for r in self.rej]
        out += [(self.node(x), "inputs") for x in self.doc.get("inputs") or [] if isinstance(x, dict)]
        return [(n, w) for n, w in out if n]

    def texts(self):
        out = [("how_it_works", self.doc.get("how_it_works") or "")]
        out += [("open_questions", item_text(q)) for q in self.qs]
        out += [("deferred", str(x)) for x in self.doc.get("deferred") or []]
        out += [(f"discrepancy {d.get('id', '')}", item_text(d)) for d in self.disc]
        out += [("rejected", item_text(r)) for r in self.rej]
        out += [(f"edge {e.get('id', '')}", item_text(e)) for e in self.edges]
        return [(w, t) for w, t in out if t]

    def text_nodes(self, text):
        out = []
        for sh, cell in refs_in_text(text, set(self.sheets)):
            out += [(w, sh, cell, "text") for w in self.sheets.get(sh, ())]
        return out

    # ---- equivalence and anchors ----
    def equiv(self, g, e):
        """is extraction node e the same economic cell as Gold node g? exact | gold_equivalent (both in one concept's cell-level anchors)
        | verified_link (chain of pure copies in the supplied workbooks) | None."""
        if not g or not e or e[0] is None or g[2] is None:
            return None
        if node_match(g, e):
            return "exact"
        for nodes in self.sets.values():
            if any(node_match(n, g) for n in nodes) and any(node_match(n, e) for n in nodes):
                return "gold_equivalent"
        if self.graph and self.graph.linked(e, g):
            return "verified_link"
        return None

    def classify(self, concept, e):
        anchors = [(k, gnode(r), r) for k, r in anchors_of(concept) if k in EQUIV_KINDS]
        anchors = [(k, g, r) for k, g, r in anchors if g]
        if e is None:
            return "MISSING", ""
        miss = sorted({g[0] for _, g, _ in anchors if g[0] not in self.g2e})
        if e[0] is None or miss:
            return "UNVERIFIED", "integrity: " + (f"Gold source {', '.join(miss)} not identified in the extraction" if miss else "extraction source not identified")
        for k, g, r in anchors:
            if k == "primary" and node_match(g, e):
                return "EXACT_ANCHOR", ""
        for k, g, r in anchors:
            if k == "supporting" and node_match(g, e):
                return "GOLD_EQUIVALENT_ANCHOR", f"Gold lists {r} as a supporting anchor"
        if self.graph:
            for k, g, r in anchors:
                path = self.graph.linked(e, g) if g[2] else None          # a whole-sheet anchor is matched by sheet only, never by a copy
                if path:
                    return "VERIFIED_LINKED_EQUIVALENT", "pure-copy link: " + " <- ".join(show_node(n) for n in path)
            return "WRONG_ANCHOR", ""
        return "UNVERIFIED", "not one of Gold's anchors; the link check needs the workbooks"

    def value_at(self, e):
        b = self.books.get(e[0]) if e and e[0] else None
        if not b:
            return None
        sh = next((x for x in b.sheet_names() if skey(x) == e[1]), None)
        rg = parse_range(e[2])
        if not sh or not rg or None in rg or (rg[0], rg[1]) != (rg[2], rg[3]):
            return None
        return b.value(sh, e[2])

    def sheet_of(self, e):
        b = self.books.get(e[0]) if e and e[0] else None
        return (b, next((x for x in b.sheet_names() if skey(x) == e[1]), None)) if b else (None, None)

    def gold_value(self, ref):
        g = gnode(ref) if isinstance(ref, str) else None
        if not g or not g[2] or not parse_cell(g[2]):
            return None
        b, sh = self.sheet_of(g)
        return b.value(sh, g[2]) if b and sh else None

    def metric_value(self):
        m = self.ans.get("valuation_metric") or {}
        return num(m.get("value")) if num(m.get("value")) is not None else num(self.gold_value((m.get("primary_anchor") or {}).get("ref")))

    # ---- checking code on the extraction's own discrepancy claims (build 13.2) ----
    def confirm(self, d):
        """does the stated difference (b - a) reproduce from the supplied workbooks? -> (CONFIRMED | CONFIRMED_BY_VERIFIER | CONTRADICTED |
        NOT_CHECKABLE, computed difference or None). The fallback is a fresh verification.json listing the item as confirmed."""
        va, vb = num(self.value_at(self.node(d.get("a")))), num(self.value_at(self.node(d.get("b"))))
        if va is not None and vb is not None:
            comp, stated = vb - va, num(d.get("difference"))
            ok = comp != 0 if stated is None else abs(stated - comp) <= 0.005 + 1e-6 * abs(comp)
            return ("CONFIRMED" if ok else "CONTRADICTED"), comp
        for x in (self.verif or {}).get("discrepancies") or []:
            if isinstance(x, dict) and x.get("id") and x.get("id") == d.get("id") and x.get("status") == "confirmed":
                return "CONFIRMED_BY_VERIFIER", num(x.get("difference"))
        return "NOT_CHECKABLE", None

    def driver_backed(self, d):
        """the extraction cites at least one driver cell beyond the two compared cells, and every such cell holds a value in the workbooks"""
        ab = {tuple(n[:3]) for n in (self.node(d.get("a")), self.node(d.get("b"))) if n}
        extra = [n for n in (self.node(x) for x in d.get("driver_cells") or [] if isinstance(x, dict)) if n and tuple(n[:3]) not in ab]
        return bool(extra) and all(self.value_at(n) is not None for n in extra)

    def elsewhere(self, c, anchors=True):
        why = []
        if anchors:
            gs = [g for g in (gnode(r) for _, r in anchors_of(c)) if g]
            for n, where in self.all_refs():
                if any(node_match(g, n) for g in gs):
                    why.append(f"{n[3]} appears in {where}")
                    break
        if c.get("keywords"):
            for where, t in self.texts():
                if kw_match(c["keywords"], t):
                    why.append(f"its keywords appear in {where}")
                    break
        return why

    # ---- core concepts ----
    def res(self, key, c, status, anchor="N/A", ext=None, detail="", **kw):
        p = (c.get("primary_anchor") or {}).get("ref") if isinstance(c, dict) else None
        return {"concept": key, "status": status, "anchor": anchor, "extraction": ext, "gold": p, "detail": detail, **kw}

    def score_concept(self, key, c):
        if key not in GV.KNOWN or not isinstance(c, dict):
            return self.res(key, c, "NOT_EXPRESSIBLE_IN_SCHEMA", detail="the extraction schema has no slot for this concept; consider extending the schema")
        if key == "valuation_method":
            return self.c_method(key, c)
        if key == "metric_period":
            return self.c_period(key, c)
        if key == "ownership_or_waterfall":
            return self.c_waterfall(key, c)
        if key == "company_to_fund_relationship":
            return self.c_relationship(key, c)
        return self.c_cell(key, c)

    def omitted_or_elsewhere(self, key, c, anchor, detail, anchors=True):
        w = self.elsewhere(c, anchors)
        if w:
            return self.res(key, c, "NEEDS_ANALYST", anchor, None, f"{detail}; but {'; '.join(w)}")
        return self.res(key, c, "OMITTED", anchor, None, detail)

    def c_method(self, key, c):
        ext = self.ch.get("method")
        if not ext:
            return self.omitted_or_elsewhere(key, c, "N/A", "the extraction states no valuation method", anchors=False)
        g, e = canon_method(c.get("answer")), canon_method(ext)
        if g == e:
            return self.res(key, c, "CORRECT", ext=ext, detail=f"'{ext}' is the same method as Gold's '{c.get('answer')}'")
        if g in METHODS and e in METHODS:
            return self.res(key, c, "WRONG", ext=ext, detail=f"extraction says '{ext}'; Gold says '{c.get('answer')}'")
        return self.res(key, c, "NEEDS_ANALYST", ext=ext, detail=f"cannot normalise '{ext}' against '{c.get('answer')}' deterministically")

    def window_node(self):
        mw = self.ch.get("metric_window") or {}
        return self.node({"source": mw.get("source"), "cell": mw.get("cells")}) if mw.get("cells") else None

    def period_evidence(self, c, e):
        """build 13.2: header evidence and value evidence for the extraction's 12-month window, each graded on its own.
        header: EXACT (on Gold's header) | VERIFIED_SAME_PERIOD (checking code reads Gold's 12 months over these cells) | DIFFERENT_PERIOD |
        NOT_PROVEN (no date header found) | NOT_CHECKED (no workbooks). value: EXACT (Gold's value anchor) | SUMS_TO_METRIC | DOES_NOT_SUM | NOT_CHECKED."""
        want = consecutive_months(c.get("first_month"), c.get("last_month"))
        mw = self.ch.get("metric_window") or {}
        gh = gnode((c.get("header_anchor") or c.get("primary_anchor") or {}).get("ref"))
        gv = gnode((c.get("value_anchor") or {}).get("ref"))
        eh = self.node({"source": mw.get("source"), "cell": mw.get("header_cells")}) if mw.get("header_cells") else None
        ev = {"header": "NOT_CHECKED", "value": "NOT_CHECKED", "header_cells": None, "months_read": None}
        if gv and e and node_match(gv, e):
            ev["value"] = "EXACT"
        b, sh = self.sheet_of(e) if e else (None, None)
        if not (b and sh):
            if gh and (eh or e) and node_match(gh, eh or e):
                ev["header"] = "EXACT"
            return ev
        if eh:
            hb, hsh = self.sheet_of(eh)
            cells, _ = line_cells(eh[2])
            ms = months_at(hb, hsh, cells) if hb and hsh and cells else None
            hloc, hname = eh, hsh
        else:
            ms, rng = header_for(b, sh, e[2])
            hloc, hname = ((e[0], e[1], rng) if rng else None), sh
        ev["header_cells"] = f"{hloc[0]}:'{hname}'!{hloc[2]}" if hloc and hloc[2] else None
        ev["months_read"] = f"{ms[0]}..{ms[-1]}" if ms and None not in ms else None
        if not ms or None in ms:
            ev["header"] = "NOT_PROVEN"
        elif ms != want:
            ev["header"] = "DIFFERENT_PERIOD"
        elif gh and hloc and node_match(gh, hloc):
            ev["header"] = "EXACT"
        else:
            ev["header"] = "VERIFIED_SAME_PERIOD"
        if ev["value"] != "EXACT":
            cells, _ = line_cells(e[2])
            cs = b.cells(sh)
            vals = [num(cs.get(rc, (None,))[0]) for rc in cells] if cells else []
            metric = self.metric_value()
            if metric is not None and len(vals) == 12:
                ok = None not in vals and abs(sum(vals) - metric) <= max(1.0, 1e-6 * abs(metric))
                ev["value"] = "SUMS_TO_METRIC" if ok else "DOES_NOT_SUM"
        return ev

    def c_period(self, key, c):
        mw = self.ch.get("metric_window") or {}
        f, l = month(mw.get("first")), month(mw.get("last"))
        e = self.window_node()
        cls, why = self.classify(c, e)
        if not (f or l):
            return self.omitted_or_elsewhere(key, c, cls, "the extraction states no TTM window", anchors=False)
        ok = f == c.get("first_month") and l == c.get("last_month")
        ev = self.period_evidence(c, e) if e else None
        if ev and cls not in ("EXACT_ANCHOR", "GOLD_EQUIVALENT_ANCHOR", "VERIFIED_LINKED_EQUIVALENT") and e[0] is not None:
            if ev["value"] == "EXACT" and ev["header"] in ("EXACT", "VERIFIED_SAME_PERIOD", "NOT_CHECKED"):
                cls, why = "EXACT_ANCHOR", "on Gold's value anchor"
            elif ev["header"] in ("EXACT", "VERIFIED_SAME_PERIOD") and ev["value"] in ("EXACT", "SUMS_TO_METRIC"):
                cls, why = "VERIFIED_SAME_PERIOD", f"checking code: headers {ev['header_cells']} read {ev['months_read']} and the 12 values sum to the metric"
            elif ev["header"] == "DIFFERENT_PERIOD":
                why = f"checking code: the headers over these cells read {ev['months_read']}, not Gold's months"
            elif ev["header"] == "NOT_PROVEN" and cls == "WRONG_ANCHOR":
                why = "checking code found no date header over these cells (matching numbers alone never prove a period)"
        d = f"extraction {f}..{l}; Gold {c.get('first_month')}..{c.get('last_month')}" + (f" | window anchor {cls}" + (f" ({why})" if why else "") if cls != "EXACT_ANCHOR" else "")
        r = self.res(key, c, "CORRECT" if ok else "WRONG", cls, e[3] if e else None, d)
        if ev:
            r["period_evidence"] = {"answer": "CORRECT" if ok else "WRONG", **ev}
        return r

    def c_cell(self, key, c):
        role = CORE_ROLES[key]
        e = self.role_node(role)
        cls, why = self.classify(c, e)
        if cls == "MISSING":
            return self.omitted_or_elsewhere(key, c, cls, f"the extraction's chain has no {role}")
        status = "CORRECT" if cls in OK_ANCHOR else "WRONG" if cls == "WRONG_ANCHOR" else "NEEDS_ANALYST"
        r = self.res(key, c, status, cls, e[3], why)
        field = GV.NUMERIC.get(key)
        v = self.value_at(e) if field else None
        if v is not None and c.get(field) is not None:
            vc = val_match(v, c[field])
            r["value_check"] = vc
            if cls == "WRONG_ANCHOR" and vc != "mismatch":
                r["detail"] = "the cell's value equals Gold's answer but it is not linked to a Gold anchor (numeric equality is not a link)"
            if cls in OK_ANCHOR and vc == "mismatch":
                r["detail"] = (r["detail"] + "; " if r["detail"] else "") + f"VALUE DISAGREES: the cell holds {v}, Gold says {c[field]}"
        if key == "equity_bridge":
            comps = []
            for a in c.get("supporting_anchors") or []:
                if isinstance(a, dict) and a.get("support") == "component":
                    g, part = gnode(a.get("ref")), a.get("component")
                    hit = next((x for x in self.ch.get("bridge") or [] if isinstance(x, dict) and node_match(g, self.node(x, self.ch.get("source")))), None)
                    comps.append({"component": part or "component", "gold": a.get("ref"),
                                  "status": "IN_BRIDGE" if hit else "NOT_IN_BRIDGE", "extraction": (self.node(hit, self.ch.get("source")) or [None] * 4)[3] if hit else None})
            if comps:
                r["components"] = comps
        if key == "equity_bridge" and status == "CORRECT" and self.books and c.get("cash") is not None and c.get("debt") is not None:
            sums = {1: 0.0, -1: 0.0}
            n_found = 0
            for x in self.ch.get("bridge") or []:
                nb = self.node(x, self.ch.get("source"))
                val = self.value_at(nb) if nb else None
                if isinstance(val, (int, float)) and x.get("sign") in (1, -1):
                    sums[x["sign"]] += abs(val)
                    n_found += 1
            if n_found:
                bad = [n for n, tot, want in (("cash", sums[1], c["cash"]), ("debt", sums[-1], c["debt"])) if val_match(tot, want) == "mismatch"]
                if bad:
                    r["status"], r["detail"] = "WRONG", f"the bridge cells do not match Gold's {' and '.join(bad)}"
        return r

    def c_waterfall(self, key, c):
        wf = [self.node(x, self.ch.get("source")) for x in self.ch.get("waterfall") or [] if isinstance(x, dict)]
        wf = [n for n in wf if n]
        if not wf:
            return self.omitted_or_elsewhere(key, c, "MISSING", "the extraction's chain reports no waterfall")
        got = [(self.classify(c, n), n) for n in wf]
        rank = ["EXACT_ANCHOR", "GOLD_EQUIVALENT_ANCHOR", "VERIFIED_LINKED_EQUIVALENT", "UNVERIFIED", "WRONG_ANCHOR"]
        (cls, why), n = sorted(got, key=lambda x: rank.index(x[0][0]))[0]
        status = "CORRECT" if cls in OK_ANCHOR else "WRONG" if cls == "WRONG_ANCHOR" else "NEEDS_ANALYST"
        return self.res(key, c, status, cls, n[3], why or f"{len(wf)} waterfall cells reported")

    def derive_relationship(self):
        ok = lambda k, n: n is not None and self.classify(self.ans.get(k) or {}, n)[0] in OK_ANCHOR
        company = lambda n: ok("company_value", n)
        fund = lambda n: ok("fund_reported_value", n)
        for d in self.disc:
            a, b = self.node(d.get("a")), self.node(d.get("b"))
            if (company(a) and fund(b)) or (company(b) and fund(a)):
                self.used.add(id(d))                                  # the relationship concept accounts for this discrepancy
                return "DIFFERENT", d.get("status"), f"discrepancy {d.get('id', '')} ({d.get('status')})"
        for e in self.edges:
            a, b = self.node(e.get("from")), self.node(e.get("to"))
            if e.get("class") in CHECKABLE and ((company(a) and fund(b)) or (company(b) and fund(a))):
                return "MATCH", None, f"edge {e.get('id', '')} ({e.get('class')})"
        return None, None, None

    def match_edge(self):
        """a checkable edge between the company value and the fund value (build 13.1 helper)."""
        ok = lambda k, n: n is not None and self.classify(self.ans.get(k) or {}, n)[0] in OK_ANCHOR
        for e in self.edges:
            a, b = self.node(e.get("from")), self.node(e.get("to"))
            if e.get("class") in CHECKABLE and ((ok("company_value", a) and ok("fund_reported_value", b)) or (ok("company_value", b) and ok("fund_reported_value", a))):
                return e
        return None

    def c_relationship(self, key, c):
        dec = rounding_basis(c)
        if dec is not None and c.get("answer") == "MATCH":
            # build 13.1: Gold declares MATCH after rounding. A checkable edge (e.g. rounded_match) is decisive; a discrepancy the extraction
            # calls "explained" may be that same rounding and cannot be told apart deterministically, so it is NEEDS_ANALYST, not WRONG.
            e = self.match_edge()
            if e is not None:
                return self.res(key, c, "CORRECT", ext="MATCH", detail=f"extraction: MATCH via edge {e.get('id', '')} ({e.get('class')}); Gold: MATCH after rounding to {dec} decimal(s)")
            kind, status, via = self.derive_relationship()
            if kind == "DIFFERENT" and status == "explained":
                return self.res(key, c, "NEEDS_ANALYST", ext="DIFFERENT (explained)", detail=f"extraction: an explained difference via {via}; Gold: MATCH after rounding to {dec} decimal(s) - check whether its explanation is that rounding")
        kind, status, via = self.derive_relationship()
        if not kind:
            return self.omitted_or_elsewhere(key, c, "N/A", "the extraction states no relationship between the company value and the fund value", anchors=False)
        want = c.get("answer")
        if want == "UNRESOLVED":
            good = kind == "DIFFERENT" and status == "unresolved"
        else:
            good = kind == want
        return self.res(key, c, "CORRECT" if good else "WRONG", ext=kind, detail=f"extraction: {kind} via {via}; Gold: {want}")

    # ---- matching items ----
    def find(self, item, pool, mode="all"):
        """(object, via) by id, then cells, then keywords; pool = [(object, nodes, text)]."""
        gid = iid(item)
        if gid:
            for o, _, _ in pool:
                if gid in gids(o):
                    return o, "id"
        gs = [g for g in (gnode(r) for r in item.get("cells") or []) if g]
        if gs:
            for o, nodes, _ in pool:
                nodes = [n for n in nodes if n]
                if mode == "rival":
                    hit = any(node_match(g, n) and g[2] for g in gs for n in nodes if n[0] is not None)
                else:
                    hit = bool(nodes) and all(any(self.equiv(g, n) for n in nodes) for g in gs)
                if hit:
                    return o, "cells"
        if item.get("keywords"):
            for o, _, t in pool:
                if kw_match(item["keywords"], t):
                    return o, "keywords"
        return None, None

    def disc_pool(self):
        return [(d, [self.node(d.get("a")), self.node(d.get("b"))] + [self.node(x) for x in d.get("driver_cells") or []], item_text(d)) for d in self.disc]

    def q_pool(self):
        return [(q, self.text_nodes(item_text(q)) + [self.node(x) for x in q.get("cells") or [] if isinstance(x, dict)], item_text(q)) for q in self.qs]

    def narrative_hit(self, item):
        """is the item mentioned outside its own typed list? (how_it_works / deferred): by cells written in the text, or keywords"""
        gs = [g for g in (gnode(r) for r in item.get("cells") or []) if g]
        for where, t in [("how_it_works", self.doc.get("how_it_works") or "")] + [("deferred", str(x)) for x in self.doc.get("deferred") or []]:
            nodes = self.text_nodes(t)
            if gs and nodes and all(any(self.equiv(g, n) for n in nodes) for g in gs):
                return where
            if item.get("keywords") and kw_match(item["keywords"], t):
                return where
        return None

    # ---- known rivals ----
    def score_rival(self, r):
        base = {"id": iid(r), "candidate": r.get("candidate")}
        cells = [g for g in (gnode(x) for x in r.get("cells") or []) if g]
        if not (iid(r) or cells or r.get("keywords")):
            return {**base, "status": "UNSCORED", "detail": "Gold gave no id, cells or keywords for this rival"}
        for key, role in CORE_ROLES.items():
            n = self.role_node(role)
            if n and n[0] is not None and any(g[2] and node_match(g, n) for g in cells):
                return {**base, "status": "SELECTED_RIVAL", "detail": f"{n[3]} is the extraction's {role}"}
        pool = [(x, [self.node(x)], item_text(x)) for x in self.rej]
        o, via = self.find(r, pool, mode="rival")
        if o:
            return {**base, "status": "CORRECTLY_REJECTED", "detail": f"rejected ({via}): {item_text(o)[:90]}"}
        for n, where in self.all_refs():
            if n[0] is not None and any(g[2] and node_match(g, n) for g in cells):
                return {**base, "status": "NEEDS_ANALYST", "detail": f"{n[3]} appears in {where} but is neither rejected nor chosen"}
        for where, t in self.texts():
            if r.get("keywords") and kw_match(r["keywords"], t):
                return {**base, "status": "NEEDS_ANALYST", "detail": f"its keywords appear in {where} but it is not rejected"}
        return {**base, "status": "NOT_ADDRESSED", "detail": "the extraction neither used nor rejected it (it did not distinguish the rival)"}

    # ---- material discrepancies ----
    def rounding_edge(self, m):
        """build 13.2: a checkable edge whose two ends are Gold's two cells (or verified equivalents)"""
        gs = [g for g in (gnode(r) for r in m.get("cells") or []) if g]
        if len(gs) < 2:
            return None
        for e in self.edges:
            nodes = [n for n in (self.node(e.get("from")), self.node(e.get("to"))) if n]
            if e.get("class") in CHECKABLE and nodes and all(any(self.equiv(g, n) for n in nodes) for g in gs[:2]):
                return e
        return None

    def rounding_check(self, m):
        """checking code: do Gold's first two cells round to each other under the declared rule? -> (True | False | None, why)"""
        dec = item_basis(m)
        rel = self.ans.get("company_to_fund_relationship") or {}
        if dec is None:
            dec = rounding_basis(rel)
        if dec is None:
            return None, "Gold declares no rounding rule (basis decimals) for this item"
        if not self.books:
            return None, "checking code needs the workbooks"
        vals = [self.gold_value(r) for r in (m.get("cells") or [])[:2]]
        if len(vals) < 2 or None in vals:
            return None, "Gold's first two cells do not both hold values"
        return rounds_to(vals[0], vals[1], dec), f"{vals[0]} and {vals[1]} at {dec} decimal(s)"

    def immaterial(self, m, d):
        """(True, why) when checking code shows the difference is below Gold's own dollar threshold"""
        t = threshold(m, self.gold)
        if t is None:
            return False, ""
        conf, comp = self.confirm(d)
        if conf.startswith("CONFIRMED") and comp is not None and abs(comp) < t:
            return True, f"checking code: the difference {comp:.6g} is below Gold's immaterial threshold ${t:,.2f}"
        return False, ""

    def score_discrepancy(self, m):
        base = {"id": iid(m), "item": m.get("item"), "gold_status": m.get("status")}
        if not (iid(m) or m.get("cells") or m.get("keywords")):
            return {**base, "status": "UNSCORED", "detail": "Gold gave no id, cells or keywords for this discrepancy"}
        d, via = self.find(m, self.disc_pool())
        gold = m.get("status")
        if not d:
            if gold == "ROUNDING":
                e = self.rounding_edge(m)
                if e is not None:
                    ok, why = self.rounding_check(m)
                    if ok:
                        return {**base, "status": "FOUND", "detail": f"edge {e.get('id', '')} ({e.get('class')}); checking code confirms Gold's rounding rule: {why}"}
                    return {**base, "status": "NEEDS_ANALYST", "detail": f"edge {e.get('id', '')} ({e.get('class')}) joins the two values, but the rounding is not confirmed: {why}"}
            w = self.narrative_hit(m)
            o, _ = self.find(m, self.q_pool())
            if o or w:
                return {**base, "status": "NEEDS_ANALYST", "detail": f"mentioned in {'open_questions' if o else w} but not recorded as a discrepancy"}
            return {**base, "status": "OMITTED", "detail": "the extraction records no such discrepancy"}
        self.used.add(id(d))
        diff, material, st = d.get("difference"), d.get("material"), d.get("status")
        d_txt = f"discrepancy {d.get('id', '')} ({via}); status {st}"
        small, why_small = self.immaterial(m, d)
        if gold == "REAL":
            if (isinstance(diff, (int, float)) and diff == 0) or material is False:
                if small:
                    return {**base, "status": "FOUND", "detail": f"{d_txt}: called immaterial; {why_small}"}
                return {**base, "status": "MISINTERPRETED", "detail": f"{d_txt}: Gold says the difference is real; the extraction treats it as nil or immaterial"}
        elif gold == "UNRESOLVED":
            if st == "explained":
                if small:
                    return {**base, "status": "FOUND", "detail": f"{d_txt}: explained; {why_small}"}
                conf, _ = self.confirm(d)
                if conf.startswith("CONFIRMED") and self.driver_backed(d):
                    return {**base, "status": "NEEDS_ANALYST", "detail": f"{d_txt}: the extraction explains it with driver cells and checking code confirms the "
                                                                         f"difference, but Gold says the cause is unresolved - an analyst decides; update the key to score it"}
                return {**base, "status": "MISINTERPRETED", "detail": f"{d_txt}: Gold says it is unresolved; the extraction calls it explained"}
        elif gold == "ROUNDING":
            if not ((isinstance(diff, (int, float)) and diff == 0) or material is False):
                return {**base, "status": "NEEDS_ANALYST", "detail": f"{d_txt}: cannot tell deterministically whether the extraction treats it as rounding"}
        return {**base, "status": "FOUND", "detail": d_txt}

    # ---- unresolved decisions (human_judgments) ----
    def score_judgment(self, h):
        base = {"id": iid(h), "question": h.get("question")}
        if not (iid(h) or h.get("cells") or h.get("keywords")):
            return {**base, "status": "UNSCORED", "detail": "Gold gave no id, cells or keywords for this unresolved decision"}
        q, via = self.find(h, self.q_pool())
        if q:
            return {**base, "status": "PRESERVED_UNRESOLVED", "detail": f"raised as an open question ({via})"}
        d, via = self.find(h, self.disc_pool())
        if d:
            self.used.add(id(d))
        if d and d.get("status") == "explained":
            conf, _ = self.confirm(d)
            if conf.startswith("CONFIRMED") and self.driver_backed(d):
                return {**base, "status": "NEEDS_ANALYST", "detail": f"discrepancy {d.get('id', '')} ({via}) is explained with driver cells and checking code confirms the "
                                                                     f"difference, but Gold says this is unresolved - an analyst decides; update the key to score it"}
            return {**base, "status": "UNSUPPORTED_CONCLUSION",
                    "detail": f"discrepancy {d.get('id', '')} ({via}) is closed as 'explained': {item_text(d)[:90]}; Gold says the workbooks cannot settle this"}
        w = self.narrative_hit(h) or ("discrepancy list" if d else None)
        if w:
            return {**base, "status": "NEEDS_ANALYST", "detail": f"mentioned in {w} but not raised as an open question"}
        return {**base, "status": "OMITTED", "detail": "the extraction never raises this question"}

    # ---- found by the extraction, not in Gold (build 13.2) ----
    def extras(self):
        out = []
        for d in self.disc:
            if id(d) in self.used:
                continue
            conf, comp = self.confirm(d)
            if conf.startswith("CONFIRMED"):
                st, why = "FOUND_NOT_IN_GOLD", ("checking code reproduces the difference" + (f" ({comp:,.6g})" if comp is not None else "")
                                               if conf == "CONFIRMED" else "confirmed by the supplied verification.json")
            else:
                st, why = "EXTRA_NOT_VERIFIED", ("the stated difference does not reproduce from the workbooks" if conf == "CONTRADICTED"
                                                 else "checking code could not reproduce it (no workbooks, or the cells are not two single numbers)")
            out.append({"extraction_id": d.get("id"), "what": (d.get("what") or "")[:160], "extraction_status": d.get("status"),
                        "material": d.get("material"), "status": st, "detail": why + "; proposed for human review, never added to Gold automatically"})
        return out

    def score_all(self):
        core = [self.score_concept(k, c) for k, c in self.ans.items()]
        R = {"concepts": core, "rivals": [self.score_rival(r) for r in self.gold.get("known_rivals") or []],
             "discrepancies": [self.score_discrepancy(m) for m in self.gold.get("material_discrepancies") or []],
             "judgments": [self.score_judgment(h) for h in self.gold.get("human_judgments") or []]}
        R["found_not_in_gold"] = self.extras()
        for k in ("concepts", "rivals", "discrepancies", "judgments"):
            for x in R[k]:
                x["class"] = owner(x)
        return R


OWNER = {"WRONG": "EXTRACTION_REASONING", "SELECTED_RIVAL": "EXTRACTION_REASONING", "MISINTERPRETED": "EXTRACTION_REASONING",
         "UNSUPPORTED_CONCLUSION": "EXTRACTION_REASONING", "OMITTED": "EXTRACTION_COVERAGE", "NOT_ADDRESSED": "EXTRACTION_COVERAGE",
         "NOT_EXPRESSIBLE_IN_SCHEMA": "EXTRACTION_SCHEMA", "UNSCORED": "UNSCORED_MATCHING_METADATA"}


def owner(x):
    """who owns a result that is not a clean success: the extraction's reasoning, its coverage, its schema, the Gold's matching metadata, or the benchmark's files"""
    st = x["status"]
    if st == "NEEDS_ANALYST":
        d = x.get("detail", "").lower()
        if "an analyst decides" in d:
            return "ANALYST_DECISION"                    # build 13.2: evidence-backed explanation vs a Gold that says unresolved
        return "BENCHMARK_INTEGRITY" if "integrity" in d else "UNSCORED_MATCHING_METADATA"
    return OWNER.get(st)


def summarise(R):
    C, V, D, H = R["concepts"], R["rivals"], R["discrepancies"], R["judgments"]
    n = lambda xs, st: sum(1 for x in xs if x["status"] == st)
    decided = [x for x in C if x["status"] in ("CORRECT", "WRONG", "OMITTED")]
    anch = [x for x in C if x["anchor"] not in ("N/A",) and x["status"] != "NOT_EXPRESSIBLE_IN_SCHEMA"]
    s = {
        "core_correct": n(C, "CORRECT"), "core_total": len(decided), "core_wrong": n(C, "WRONG"), "core_omitted": n(C, "OMITTED"),
        "not_expressible": n(C, "NOT_EXPRESSIBLE_IN_SCHEMA"),
        "anchors_exact": sum(1 for x in anch if x["anchor"] == "EXACT_ANCHOR"), "anchors_total": len(anch),
        "anchors_gold_equivalent": sum(1 for x in anch if x["anchor"] == "GOLD_EQUIVALENT_ANCHOR"),
        "anchors_verified_linked": sum(1 for x in anch if x["anchor"] == "VERIFIED_LINKED_EQUIVALENT"),
        "rivals_handled": n(V, "CORRECTLY_REJECTED"), "rivals_total": sum(1 for x in V if x["status"] in ("CORRECTLY_REJECTED", "SELECTED_RIVAL", "NOT_ADDRESSED")),
        "discrepancies_found": n(D, "FOUND"), "discrepancies_total": sum(1 for x in D if x["status"] in ("FOUND", "MISINTERPRETED", "OMITTED")),
        "judgments_preserved": n(H, "PRESERVED_UNRESOLVED"), "judgments_total": sum(1 for x in H if x["status"] in ("PRESERVED_UNRESOLVED", "UNSUPPORTED_CONCLUSION", "OMITTED")),
    }
    s["wrong_material_answers"] = n(C, "WRONG")
    s["false_material_claims"] = n(C, "WRONG") + n(V, "SELECTED_RIVAL") + n(H, "UNSUPPORTED_CONCLUSION") + n(D, "MISINTERPRETED")
    s["material_gold_items_missed"] = n(C, "OMITTED") + n(V, "NOT_ADDRESSED") + n(D, "OMITTED") + n(H, "OMITTED")
    s["needs_analyst"] = sum(n(xs, "NEEDS_ANALYST") for xs in (C, V, D, H))
    s["unscored"] = sum(n(xs, "UNSCORED") for xs in (C, V, D, H))
    s["anchors_verified_period"] = sum(1 for x in anch if x["anchor"] == "VERIFIED_SAME_PERIOD")
    X = R.get("found_not_in_gold") or []
    s["found_not_in_gold"] = n(X, "FOUND_NOT_IN_GOLD")
    s["extra_not_verified"] = n(X, "EXTRA_NOT_VERIFIED")
    return s


def render(case, R, S, integrity, verification, rows=(), integ="", warnings=(), recorded=False):
    """build 13.2 layout: header, Gold validation, source integrity, the score lines, the breakdown, what needs attention, then one section per
    topic - core answers, evidence, known rivals, discrepancies, unresolved decisions, found not in key, integrity, checking-code verification."""
    C, V, D, H, X = R["concepts"], R["rivals"], R["discrepancies"], R["judgments"], R.get("found_not_in_gold") or []
    cnt = lambda xs, st: sum(1 for x in xs if x["status"] == st)
    ac = lambda c: sum(1 for x in C if x["anchor"] == c)
    ver_line = (f"{verification}" + (" (as recorded in extraction.json; run verify.py for a fresh check)" if recorded else "")
                + (" [DETERMINISTIC_VERIFIER]" if verification not in ("VERIFIED", "not verified") else ""))
    L = [f"GOLD SCORE: {case}", "", f"GOLD VALIDATION: PASS ({len(warnings)} warnings)"] + [f"- WARN: {w}" for w in warnings]
    L += [f"SOURCE INTEGRITY: {integ}", "SOURCE IDENTITY (Gold file | filename match to the supplied workbook | binary vs the extraction):"]
    for r in rows:
        L.append(f"- {r['wid']} filename {r['filename_match'] or 'not checked (no workbooks)'} + {r['status']} | {r['file']} | extraction source {r['extraction_id'] or '-'}"
                 + (f" | matched by {r['matched_by']}" if r["matched_by"] else "") + (f" | {r['note']}" if r.get("note") else "")
                 + (f" | frozen sha256 {r['frozen_sha256'][:12]}... ({r['frozen_from']})" if r["frozen_sha256"] else " | frozen sha256 unknown"))
    L += ["",
          f"Core semantic answers: {S['core_correct']}/{S['core_total']}", f"Exact primary anchors: {S['anchors_exact']}/{S['anchors_total']}",
          f"Equivalent linked anchors: {S['anchors_gold_equivalent'] + S['anchors_verified_linked']} "
          f"(Gold-listed {S['anchors_gold_equivalent']}, verified by workbook link {S['anchors_verified_linked']})",
          f"Period proven by checking code on another range: {S['anchors_verified_period']}",
          f"Wrong material answers: {S['wrong_material_answers']}", f"Material Gold items omitted: {S['material_gold_items_missed']}",
          f"Known rivals: {S['rivals_handled']}/{S['rivals_total']}", f"Material discrepancies: {S['discrepancies_found']}/{S['discrepancies_total']}",
          f"Unresolved decisions: {S['judgments_preserved']}/{S['judgments_total']}", f"False material claims: {S['false_material_claims']}",
          f"Found by the extraction, not in the key: {S['found_not_in_gold']} confirmed by checking code / {S['extra_not_verified']} not verified (no credit, no penalty)",
          f"Not expressible in schema: {S['not_expressible']}", f"Needs analyst / unscored: {S['needs_analyst']} / {S['unscored']}",
          f"Integrity: {'OK' if not integrity else 'FAILED (' + str(len(integrity)) + ')'}",
          f"Workbook verification (separate, not part of the Gold score): {ver_line}", "",
          "BREAKDOWN",
          f"Core semantic answers: correct {cnt(C, 'CORRECT')} / wrong {cnt(C, 'WRONG')} / omitted {cnt(C, 'OMITTED')} / needs analyst {cnt(C, 'NEEDS_ANALYST')} / not expressible {cnt(C, 'NOT_EXPRESSIBLE_IN_SCHEMA')}",
          f"Anchors: exact {ac('EXACT_ANCHOR')} / Gold-equivalent {ac('GOLD_EQUIVALENT_ANCHOR')} / verified-linked-equivalent {ac('VERIFIED_LINKED_EQUIVALENT')} / "
          f"period proven {ac('VERIFIED_SAME_PERIOD')} / wrong {ac('WRONG_ANCHOR')} / missing {ac('MISSING')} / unverified {ac('UNVERIFIED')}",
          f"Known rivals: correctly rejected {cnt(V, 'CORRECTLY_REJECTED')} / selected incorrectly {cnt(V, 'SELECTED_RIVAL')} / omitted {cnt(V, 'NOT_ADDRESSED')} / "
          f"unscored {cnt(V, 'UNSCORED')} / needs analyst {cnt(V, 'NEEDS_ANALYST')}",
          f"Material discrepancies: found {cnt(D, 'FOUND')} / materially misinterpreted {cnt(D, 'MISINTERPRETED')} / omitted {cnt(D, 'OMITTED')} / "
          f"unscored {cnt(D, 'UNSCORED')} / needs analyst {cnt(D, 'NEEDS_ANALYST')}",
          f"Unresolved decisions: preserved unresolved {cnt(H, 'PRESERVED_UNRESOLVED')} / unsupported conclusion {cnt(H, 'UNSUPPORTED_CONCLUSION')} / omitted {cnt(H, 'OMITTED')} / "
          f"unscored {cnt(H, 'UNSCORED')} / needs analyst {cnt(H, 'NEEDS_ANALYST')}", ""]
    tag = lambda x: f" [{x['class']}]" if x.get("class") else ""
    label = lambda x: x.get("id") or x.get("candidate") or x.get("item") or x.get("question")

    def sec(title, rows_):
        L.append(title)
        L.extend(rows_ or ["- none"])
        L.append("")
    good = {"CORRECT", "CORRECTLY_REJECTED", "FOUND", "PRESERVED_UNRESOLVED"}
    sec("NEEDS ATTENTION (everything that is not a clean success, with its owner)",
        [f"- {x['concept']}: {x['status']} | {x['detail']}{tag(x)}" for x in C if x["status"] not in good]
        + [f"- {k} {label(x)}: {x['status']} | {x['detail']}{tag(x)}" for k, xs in (("rival", V), ("discrepancy", D), ("unresolved decision", H))
           for x in xs if x["status"] not in good])
    sec("CORE ANSWERS", [f"- {x['concept']}: {x['status']}" + (f" | extraction {x['extraction']}" if x.get("extraction") else "") for x in C])
    ev = []
    for x in C:
        if x["anchor"] == "N/A" and not x.get("period_evidence"):
            continue
        ev.append(f"- {x['concept']}: anchor {x['anchor']}" + (f" | Gold primary {x['gold']}" if x.get("gold") else "") + (f" | {x['detail']}" if x["detail"] else ""))
        pe = x.get("period_evidence")
        if pe:
            ev.append(f"    period: answer {pe['answer']} | header evidence {pe['header']}" + (f" ({pe['header_cells']} reads {pe['months_read']})" if pe.get("header_cells") else "")
                      + f" | value evidence {pe['value']}")
        for cp in x.get("components") or []:
            ev.append(f"    component {cp['component']}: {cp['status']} (Gold {cp['gold']}" + (f"; extraction {cp['extraction']}" if cp.get("extraction") else "") + ")")
    sec("EVIDENCE (anchors; the period answer, header and value evidence graded separately; bridge components)", ev)
    sec("KNOWN RIVALS", [f"- {label(x)}: {x['status']} | {x['detail']}{tag(x)}" for x in V])
    sec("DISCREPANCIES", [f"- {label(x)} (Gold {x.get('gold_status')}): {x['status']} | {x['detail']}{tag(x)}" for x in D])
    sec("UNRESOLVED DECISIONS", [f"- {label(x)}: {x['status']} | {x['detail']}{tag(x)}" for x in H])
    sec("FOUND BY THE EXTRACTION, NOT IN THE KEY (for human review only; the key is never changed automatically)",
        [f"- {x['extraction_id']}: {x['status']} | {x['what']} | {x['detail']}" for x in X])
    if any(x["status"] == "NOT_EXPRESSIBLE_IN_SCHEMA" for x in C):
        sec("NOT EXPRESSIBLE IN SCHEMA", [f"- {x['concept']}: {x['detail']}{tag(x)}" for x in C if x["status"] == "NOT_EXPRESSIBLE_IN_SCHEMA"])
    sec("INTEGRITY", [f"- {x} [BENCHMARK_INTEGRITY]" for x in integrity])
    sec("CHECKING-CODE VERIFICATION (separate from the Gold score)", [f"- {ver_line}"])
    return "\n".join(L).rstrip()


def main(argv=None):
    ap = argparse.ArgumentParser(description="score an extraction against a gold-mvp/3 key")
    ap.add_argument("--gold", required=True)
    ap.add_argument("--extraction", required=True)
    ap.add_argument("--workbooks", nargs="*")
    ap.add_argument("--sources", help="frozen source manifest (from gold_sources.py) supplying SHA-256s Gold does not carry")
    ap.add_argument("--allow-different-binary", action="store_true",
                    help="score against a re-saved copy of the workbooks (an explicit, separate mode; the default historical benchmark requires the same binaries)")
    ap.add_argument("--verification")
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    gold = GV.read_json(a.gold)
    v = GV.validate(gold, a.workbooks, manifest=GV.read_json(a.sources) if a.sources else None)
    cid = gold.get("case_id") if isinstance(gold, dict) else "?"
    if v["errors"]:
        print(f"GOLD VALIDATION: FAIL | {cid} | {len(v['errors'])} errors | nothing was scored")
        print(f"GOLD INVALID: {cid} | {len(v['errors'])} errors | nothing was scored")
        for e in v["errors"]:
            print(f"- ERROR: {e}")
        return 2
    gold = v["gold"]
    doc = GV.read_json(a.extraction)
    sc = Scorer(gold, doc, v["books"], a.allow_different_binary, GV.read_json(a.verification) if a.verification else None)
    R = sc.score_all()
    S = summarise(R)
    recorded = False
    if a.verification:
        ver = GV.read_json(a.verification).get("status") or "not verified"
    else:
        ver = (doc.get("verification") or {}).get("status")
        recorded = bool(ver)
        ver = ver or "not verified"
    integ = integrity_summary(sc.rows, a.allow_different_binary)
    print(render(cid, R, S, sc.integrity, ver, sc.rows, integ, v["warnings"], recorded))
    if a.out:
        json.dump({"case_id": cid, "gold_validation": "PASS", "validation_warnings": v["warnings"], "source_integrity": {"summary": integ, "rows": sc.rows},
                   "summary": S, "integrity": sc.integrity, "workbook_verification": ver, **R,
                   "link_check": "workbooks" if v["books"] else "not run"}, open(a.out, "w"), indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
