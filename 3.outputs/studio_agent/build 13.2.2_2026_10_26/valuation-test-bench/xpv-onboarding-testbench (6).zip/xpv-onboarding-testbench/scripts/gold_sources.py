# gold_sources.py (build 13.0, test bench) - freezes the benchmark's source identities and compares them with a historical extraction.
#   * Fingerprints (SHA-256) come ONLY from the workbook binaries supplied here. Nothing is copied from any extraction: a SHA-256 identifies
#     the exact binary, and a re-downloaded or re-saved workbook can be a different binary even when its content looks the same.
#   * Each Gold file (W1..Wn) is tied to a supplied workbook by Gold's sha256 when it has one, else by the normalised file name (so a runtime
#     rename such as 'Company_Valuation-1a2b3c4d.xlsx' still resolves to 'Company Valuation.xlsx'), only when exactly one file matches.
#     If neither identifies a workbook safely it fails: it never guesses.
#   * With --extraction it then compares the extraction's recorded SHA-256s with the frozen ones: SAME_BINARY / DIFFERENT_BINARY /
#     NOT_COMPARABLE / MISSING per workbook, and an overall SOURCE INTEGRITY line. A different binary is a BENCHMARK_INTEGRITY finding.
#   * --out writes a source manifest ({"source_files": {W1: {file, sha256, supplied_as}}}) that gold_validate.py and gold_score.py accept
#     with --sources. Gold itself is never modified.
# Usage: python gold_sources.py --gold KEY.json --workbooks A.xlsx ... [--extraction extraction.json] [--out source_manifest.json]
import argparse, json, os, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gold_validate as GV  # noqa: E402
from gold_score import source_integrity, integrity_summary  # noqa: E402
from xlsx_evidence import Book as XBook  # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description="freeze benchmark source identities")
    ap.add_argument("--gold", required=True)
    ap.add_argument("--workbooks", nargs="+", required=True)
    ap.add_argument("--extraction")
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    gold = GV.read_json(a.gold)
    src = GV.source_files(gold)
    cache = tempfile.mkdtemp(prefix="gold_src_")
    opened = [XBook(p, cache) for p in a.workbooks]
    books, bad, man = {}, [], {}
    print("SOURCE FINGERPRINTS (from the supplied binaries only; nothing is read from any extraction to make them)")
    for wid, s in sorted(src.items()):
        b, how, problem = GV.find_workbook(s, opened)
        if not b:
            bad.append(f"{wid} '{s['file']}': {problem}")
            continue
        books[wid] = b
        man[wid] = {"file": s["file"], "sha256": b.sha256, "supplied_as": b.file}
        print(f"- {wid} | {s['file']} | supplied as '{b.file}' | sha256 {b.sha256} | matched by {how}")
    for p in {b.path for b in opened} - {b.path for b in books.values()}:
        print(f"- note: supplied workbook '{os.path.basename(p)}' matches no Gold source")
    if bad:
        print(f"SOURCES: FAIL ({len(bad)} not identified) [BENCHMARK_INTEGRITY]")
        for m in bad:
            print(f"- {m}")
        return 1
    print(f"SOURCES: identified {len(books)}/{len(src)}")
    if a.out:
        json.dump({"schema": "gold-sources/1", "case_id": gold.get("case_id"), "source_files": man}, open(a.out, "w"), indent=1)
        print(f"MANIFEST: wrote {a.out} (use --sources with gold_validate.py and gold_score.py; Gold is unchanged)")
    if a.extraction:
        doc = GV.read_json(a.extraction)
        _, _, rows, _ = source_integrity({w: {**src[w], "sha256": m["sha256"]} for w, m in man.items()}, doc.get("sources") or [], books, False)
        print(f"SOURCE INTEGRITY (historical extraction vs these binaries): {integrity_summary(rows, False)}")
        for r in rows:
            print(f"- {r['wid']} {r['status']} | extraction source {r['extraction_id'] or '-'}"
                  + (f" | extraction sha256 {r['extraction_sha256'][:12]}..." if r["extraction_sha256"] else " | extraction recorded no sha256")
                  + (f" | benchmark sha256 {r['frozen_sha256'][:12]}..." if r["status"] == "DIFFERENT_BINARY" else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
