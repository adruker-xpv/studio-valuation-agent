# make_gold_fixture.py (build 13.2, test bench) - writes the synthetic Gold-mode fixtures G1 (unchanged since build 13.0, byte-for-byte) and,
# from build 13.2, G2 (a made-up company, "Harbourline Test Co") - see build_g2 below - and, from build 13.2.1, G3 ("Kestrel Test Co"), a free-text
# key built to reproduce the suggestion failures seen on a real key (see build_g3), and, from build 13.2.2, G4 ("Osprey Test Co"), the next four
# real-review failures (see build_g4). G1 is "Meridian Test Co":
#   trial/set-G1/*.xlsx                      five small workbooks (raw Office Open XML with saved values, byte-for-byte deterministic)
#   trial/keys/gold-G1.json                  a gold-mvp/3 key (TEST BENCH ONLY - keys never go to the extractor or reviewer agents)
#   trial/reference/G1/extraction-flawed.json   a schema-3 extraction with two deliberate flaws (one omission, one false material claim)
#   trial/reference/G1/extraction-clean.json    the same extraction without the flaws
# Every value is invented. The workbooks carry the structure Gold mode has to understand:
#   Cap Table!M38 (investor proceeds by waterfall) -> Valuation Summary!F26 (formula link) -> LP Report!I13 (scaled copy, $000s)
#   Valuation Summary!H11 = prior-period EV (a rival for F11); Fund Summary!H10 differs from the company value (reason unresolved)
#   LP Report!I20 is a typed copy of I13 with the same number and NO formula (a decoy: numeric equality is not a link)
# Usage: python make_gold_fixture.py --out trial     (writes set-G1/, keys/gold-G1.json, reference/G1/, set-G2/, keys/gold-G2.json, reference/G2/, set-G3/, keys/gold-G3.json, set-G4/, keys/gold-G4.json)
import argparse, datetime, hashlib, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import make_fixture_set as MF  # noqa: E402

FILES = {"W1": "Meridian - Q2 2026 Company Valuation.xlsx", "W2": "Fund - Q2 2026 Valuation Summary.xlsx",
         "W3": "Meridian - June 2026 TTM Pro Forma.xlsx", "W4": "Meridian - Monthly Financials 2026.xlsx",
         "W5": "Meridian - Monthly Summary 2026.xlsx"}
VALUES = {"valuation_method": "EV/EBITDA", "metric": "Adjusted Pro Forma TTM EBITDA", "metric_value": 2_500_000, "multiple": 8.0,
          "enterprise_value": 20_000_000, "cash": 2_000_000, "debt": 1_000_000, "equity_value": 21_000_000,
          "investor_value": 19_500_000, "fund_reported_value": 20_500_000}
MONTHLY = [208_000] * 11 + [212_000]                                  # sums to exactly 2,500,000
assert sum(MONTHLY) == VALUES["metric_value"]


def build_workbooks(out):
    os.makedirs(out, exist_ok=True)
    months = MF.month_ends(2025, 7, 12)                              # Jul-25 .. Jun-26

    b = MF.Book()                                                      # W1 company valuation
    fs = b.sheet("Financial Summary")
    fs.put("A1", "Meridian Test Co - financial summary (TTM pro forma)"); fs.put("B4", "Month")
    for i, d in enumerate(months):
        fs.put(f"{MF.col(3 + i)}4", d, s=1)
    fs.put("O4", "TTM"); fs.put("B6", "Adjusted pro forma EBITDA"); fs.row(6, 3, MONTHLY)
    fs.put("O6", sum(MONTHLY), "SUM(C6:N6)", 2)
    cp = b.sheet("Comparables")
    cp.put("A1", "Comparable companies - EV/EBITDA"); cp.put("B4", "Peer")
    for i, (n, m) in enumerate([("Peer A", 7.0), ("Peer B", 7.5), ("Peer C", 8.0), ("Peer D", 8.5), ("Peer E", 9.0)]):
        cp.put(f"B{5 + i}", n); cp.put(f"C{5 + i}", m, s=3)
    cp.put("B11", "Median"); cp.put("C11", 8.0, "MEDIAN(C5:C9)", 3)
    vs = b.sheet("Valuation Summary")
    vs.put("A1", "Meridian Test Co - valuation summary"); vs.put("F6", "Q2 2026"); vs.put("H6", "Q1 2026 (prior period)")
    vs.put("B8", "Adjusted Pro Forma TTM EBITDA"); vs.put("F8", 2_500_000, "'Financial Summary'!O6", 2); vs.put("H8", 2_400_000, None, 2)
    vs.put("B9", "Applied EV/EBITDA multiple"); vs.put("F9", 8.0, "Comparables!C11", 3); vs.put("H9", 7.5, None, 3)
    vs.put("B11", "Enterprise value"); vs.put("F11", 20_000_000, "F8*F9", 2); vs.put("H11", 18_000_000, "H8*H9", 2)
    vs.put("B12", "Cash"); vs.put("F12", 2_000_000, None, 2)
    vs.put("B13", "Debt"); vs.put("F13", 1_000_000, None, 2)
    vs.put("B14", "Total equity value"); vs.put("F14", 21_000_000, "F11+F12-F13", 2)
    vs.put("B26", "Value to investor (carrying value)"); vs.put("F26", 19_500_000, "'Cap Table'!M38", 2)
    ct = b.sheet("Cap Table")
    ct.put("A1", "Cap table and waterfall"); ct.put("L31", "Calculation")
    ct.put("B32", "Total equity value"); ct.put("M32", 21_000_000, "'Valuation Summary'!F14", 2)
    ct.put("B33", "Investor liquidation preference"); ct.put("M33", 15_000_000, None, 2)
    ct.put("B34", "Remainder after preference"); ct.put("M34", 6_000_000, "M32-M33", 2)
    ct.put("B35", "Investor participation share"); ct.put("M35", 0.75, None, 4)
    ct.put("B36", "Participation proceeds"); ct.put("M36", 4_500_000, "M34*M35", 2)
    ct.put("B37", "Preference paid"); ct.put("M37", 15_000_000, "MIN(M33,M32)", 2)
    ct.put("B38", "Investor proceeds (waterfall)"); ct.put("M38", 19_500_000, "M37+M36", 2)
    lp = b.sheet("LP Report")
    lp.put("A1", "LP report - carrying values ($000s)"); lp.put("B13", "Meridian Test Co carrying value ($000s)")
    lp.put("I13", 19_500, "'Valuation Summary'!F26/1000", 2)
    lp.put("B20", "Draft carrying value ($000s, typed copy of I13 - no formula)"); lp.put("I20", 19_500, None, 2)     # decoy: same number, no link
    b.save(os.path.join(out, FILES["W1"]))

    b = MF.Book()                                                      # W2 fund valuation summary
    fu = b.sheet("Fund Summary")
    fu.put("A1", "Fund - valuation summary, 30 June 2026"); fu.put("H5", "Carrying value (USD)")
    fu.put("B10", "Meridian Test Co"); fu.put("H10", 20_500_000, None, 2)
    fu.put("B11", "Other holdings"); fu.put("H11", 7_000_000, None, 2)
    b.save(os.path.join(out, FILES["W2"]))

    b = MF.Book()                                                      # W3 TTM pro forma
    t = b.sheet("TTM Pro Forma")
    t.put("A1", "Meridian Test Co - TTM pro forma, June 2026"); t.put("B4", "Month")
    for i, d in enumerate(months):
        t.put(f"{MF.col(3 + i)}4", d, s=1)
    t.put("O4", "TTM"); t.put("B6", "Adjusted pro forma EBITDA"); t.row(6, 3, MONTHLY); t.put("O6", sum(MONTHLY), "SUM(C6:N6)", 2)
    b.save(os.path.join(out, FILES["W3"]))

    b = MF.Book()                                                      # W4 monthly financials
    m = b.sheet("Monthly P&L")
    m.put("A1", "Meridian Test Co - monthly financials"); m.put("B4", "Month")
    for i, d in enumerate(months):
        m.put(f"{MF.col(3 + i)}4", d, s=1)
    m.put("B6", "Reported EBITDA"); m.row(6, 3, [v - 8_000 for v in MONTHLY])
    m.put("B7", "Add-backs"); m.row(7, 3, [8_000] * 12)
    m.put("B8", "Adjusted EBITDA"); m.row(8, 3, MONTHLY, f=MF.SI(), shared="C6+C7")
    b.save(os.path.join(out, FILES["W4"]))

    b = MF.Book()                                                      # W5 monthly summary
    s = b.sheet("Summary")
    s.put("A1", "Meridian Test Co - monthly summary (prepared by the fund manager)"); s.put("B4", "TTM adjusted EBITDA"); s.put("C4", 2_500_000, None, 2)
    b.save(os.path.join(out, FILES["W5"]))


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def gold(shas):
    """the gold-mvp/3 key. source_files carries a sha256 for each file (optional in the schema)."""
    sf = {k: {"file": v, "sha256": shas[k]} for k, v in FILES.items()}
    a = lambda ref, shows: {"ref": ref, "shows": shows}
    return {
        "schema": "gold-mvp/3", "case_id": "G1", "quarter_end": "2026-06-30", "source_files": sf,
        "answers": {
            "valuation_method": {"answer": "EV/EBITDA", "implementation": "Selected EV/EBITDA multiple x Adjusted Pro Forma TTM EBITDA = Implied Enterprise Value",
                                 "primary_anchor": a("W1:'Valuation Summary'!F11", "Method actually used by valuation (EV = metric x multiple)"),
                                 "supporting_anchors": [a("W1:'Comparables'", "EV/EBITDA comparable multiples")]},
            "valuation_metric": {"answer": "Adjusted Pro Forma TTM EBITDA", "value": VALUES["metric_value"],
                                 "primary_anchor": a("W1:'Valuation Summary'!F8", "Metric actually used in valuation"),
                                 "supporting_anchors": [a("W1:'Financial Summary'", "TTM/pro forma financial presentation")]},
            "metric_period": {"answer": "TTM Jul 2025 - Jun 2026", "first_month": "2025-07", "last_month": "2026-06",
                              "primary_anchor": a("W1:'Financial Summary'", "Relevant TTM/pro forma period")},
            "applied_multiple": {"answer": VALUES["multiple"], "primary_anchor": a("W1:'Valuation Summary'!F9", "Multiple actually applied"),
                                 "supporting_anchors": [a("W1:'Comparables'!C11", "Source comparable calculation (median)")]},
            "enterprise_value": {"answer": VALUES["enterprise_value"], "calculation": "Applied multiple x valuation metric",
                                 "primary_anchor": a("W1:'Valuation Summary'!F11", "Enterprise value")},
            "equity_bridge": {"answer": "Enterprise Value + Cash - Debt = Total Equity", "cash": VALUES["cash"], "debt": VALUES["debt"],
                              "equity_value": VALUES["equity_value"],
                              "primary_anchor": a("W1:'Valuation Summary'!F14", "Equity value after bridge")},
            "ownership_or_waterfall": {"answer": "Total equity is split by a participating waterfall: the investor takes its liquidation preference first, "
                                                 "then 75% of the remainder.",
                                       "keywords": ["waterfall"],
                                       "primary_anchor": a("W1:'Cap Table'", "Ownership/waterfall calculation")},
            "company_value": {"answer": VALUES["investor_value"],
                              "primary_anchor": a("W1:'Cap Table'!M38", "Investor proceeds calculated by waterfall"),
                              "supporting_anchors": [a("W1:'Valuation Summary'!F26", "Linked investor-value summary"),
                                                     a("W1:'LP Report'!I13", "Investor-facing carrying-value copy ($000s)")]},
            "fund_reported_value": {"answer": VALUES["fund_reported_value"],
                                    "primary_anchor": a("W2:'Fund Summary'!H10", "Quarter-end carrying value reported by fund")},
            "company_to_fund_relationship": {"answer": "DIFFERENT", "company_value": VALUES["investor_value"],
                                             "fund_reported_value": VALUES["fund_reported_value"],
                                             "explanation": "The fund reports 1,000,000 more than the company waterfall; nothing supplied explains why."},
        },
        "known_rivals": [{"id": "R1", "candidate": "Valuation Summary H11 (prior-period enterprise value)", "looks_like": "current enterprise value (F11)",
                          "why_not_the_answer": "H11 sits in the Q1 2026 column; it is the prior quarter's EV.",
                          "cells": ["W1:'Valuation Summary'!H11"], "keywords": ["prior period", "enterprise value"]}],
        "material_discrepancies": [{"id": "MD1", "item": "Company investor value (19.5m) differs from the fund-reported value (20.5m)", "status": "REAL",
                                    "explanation": "Real difference of 1,000,000; the reason is unresolved from the supplied workbooks.",
                                    "cells": ["W1:'Valuation Summary'!F26", "W2:'Fund Summary'!H10"], "keywords": ["fund value", "company value"]}],
        "human_judgments": [{"id": "HJ1", "question": "Which carrying value was formally approved?", "answer": "UNRESOLVED",
                             "cells": ["W1:'Valuation Summary'!F26", "W2:'Fund Summary'!H10"], "keywords": ["approved carrying value"]}],
        "certification": {"material_truth_complete": "YES", "missing": [], "analyst_note": "synthetic test fixture - invented values"},
    }


def extraction(shas, flawed):
    src = lambda i, role, why: {"id": i, "file": FILES[i], "sha256": shas[i], "role": role, "period": "Q2 2026", "contributes": why, "reason": why}
    c = lambda s, cell, what, **k: {"source": s, "cell": cell, "what": what, **k}
    chain = {
        "source": "W1", "method": "EV/EBITDA multiple",
        "valuation_metric": c("W1", "'Valuation Summary'!F8", "TTM pro forma adjusted EBITDA", units="$"),
        "selected_multiple": c("W1", "'Valuation Summary'!F9", "applied EV/EBITDA multiple", units="x"),
        "enterprise_value": c("W1", "'Valuation Summary'!F11", "F8 x F9", units="$"),
        "bridge": [{"cell": "'Valuation Summary'!F12", "sign": 1, "what": "cash"}, {"cell": "'Valuation Summary'!F13", "sign": -1, "what": "debt"}],
        "equity_value": c("W1", "'Valuation Summary'!F14", "EV + cash - debt", units="$"),
        "value_to_xpv": c("W1", "'Valuation Summary'!F26", "investor value carried on the valuation summary", units="$"),
        "metric_window": {"source": "W1", "cells": "'Financial Summary'!C6:N6", "first": "2025-07", "last": "2026-06", "link": "arithmetic_transformation"},
        "fund_cell": {"source": "W2", "cell": "'Fund Summary'!H10", "units": "$"},
    }
    if not flawed:                                                    # the clean version also reports the waterfall
        chain["waterfall"] = [c("W1", "'Cap Table'!M32", "equity value (link)"), c("W1", "'Cap Table'!M33", "investor liquidation preference"),
                              c("W1", "'Cap Table'!M36", "participation proceeds"), c("W1", "'Cap Table'!M38", "investor proceeds")]
    doc = {
        "schema": "13.0.0", "company": "Meridian Test Co", "quarter_end": "2026-06-30", "status": "final",
        "sources": [src("W1", "company_valuation", "the valuation chain"), src("W2", "fund_valuation", "the value the fund reports"),
                    src("W3", "pro_forma", "TTM pro forma"), src("W4", "monthly_financials", "monthly figures"), src("W5", "monthly_summary", "monthly summary")],
        "external": [], "chain": chain,
        "provenance": [{"id": "E1", "from": {"source": "W3", "cell": "'TTM Pro Forma'!C6:N6"}, "to": {"source": "W1", "cell": "'Financial Summary'!C6:N6"},
                        "class": "pasted_exact_match", "what": "monthly adjusted EBITDA pasted into the financial summary"}],
        "downstream": [{"id": "E10", "from": {"source": "W1", "cell": "'Valuation Summary'!F26"}, "to": {"source": "W1", "cell": "'LP Report'!I13"},
                        "class": "direct_formula_link", "relation": {"op": "scale", "factor": 0.001}, "what": "LP report copy in $000s"}],
        "discrepancies": [{"id": "D1", "a": {"source": "W1", "cell": "'Valuation Summary'!F26"}, "b": {"source": "W2", "cell": "'Fund Summary'!H10"},
                           "difference": 1_000_000, "what": "the fund reports 1,000,000 more than the company value", "status": "unresolved", "material": True}],
        "rejected": [{"source": "W1", "cell": "'Valuation Summary'!H11", "what": "prior-period enterprise value (Q1 2026 column)",
                      "why": "it is the prior quarter's figure, not the current enterprise value"}],
        "inputs": [], "open_questions": [], "deferred": [],
        "how_it_works": "Draft: TTM pro forma adjusted EBITDA x 8.0 gives EV of 20m; plus cash, less debt gives equity of 21m; the investor's value is 19.5m. "
                        "The fund reports 20.5m.",
        "verification": {"status": "VERIFIED"},
    }
    if flawed:
        # flaw 1 (omission): no waterfall is reported anywhere (no Cap Table cell appears in the extraction)
        # flaw 2 (false material claim): the discrepancy is closed as 'explained' with an approval claim Gold says the workbooks cannot support
        doc["discrepancies"][0].update(status="explained", driver="the fund applies the approved carrying value, so the company figure is stale",
                                       driver_cells=[{"source": "W2", "cell": "'Fund Summary'!H10"}])
    else:
        doc["open_questions"] = ["Which carrying value was formally approved: the company's 19.5m (Valuation Summary!F26) or the fund's 20.5m (Fund Summary!H10)?"]
        doc["discrepancies"][0]["driver"] = "not explained by the supplied workbooks"
    return doc


def ext_ids(files=None):
    """the ids the evidence reader gives these files: W1..W5 in file-name order, NOT Gold's W1..W5 (so source mapping is really tested)."""
    files = files or FILES
    order = sorted(files, key=lambda k: files[k].lower())
    return {k: f"W{i + 1}" for i, k in enumerate(order)}


def remap(x, ids):
    if isinstance(x, dict):
        return {k: (ids[v] if k in ("source", "id") and isinstance(v, str) and v in ids and (k == "source" or "file" in x) else remap(v, ids))
                for k, v in x.items()}
    if isinstance(x, list):
        return [remap(v, ids) for v in x]
    return x


# ---------------- G2 (build 13.2): every new scoring rule, on invented numbers ----------------
# W1 company valuation (quarter end 31 Mar 2026; TTM Apr-25..Mar-26):
#   'Pro Forma' row 4 = month headers, row 8 = adjusted EBITDA (the extraction's window), O8 = TTM 3,000,000; row 11 = operating adjusted EBITDA
#   (a look-alike); row 13 = month headers one month EARLIER and row 14 = a prior-TTM row that also sums to 3,000,000 (numbers alone never prove a
#   period); 'Scratch' row 3 = the same 12 numbers with no headers at all.
#   'EBITDA Adjustments' E6:P6 headers + E8:P8 values = Gold's header_anchor and value_anchor (another sheet than the extraction's window).
#   'Valuation Summary' F9 multiple 10.0, F10 metric, F12 EV, F13 cash 1,250,000.50, F14 debt 500,000, F15 equity, F25 value to investor (link).
#   'Cap Table' H20 = investor value 24,600,000.40 (800,000 of 1,000,000 units).
# W2 fund: 'Valuation Summary'!D8 = 24,600,000 typed (a rounding of 24,600,000.40); 'Holding' C9 = 180,000 management units (the company's cap
#   table says 200,000: a real difference the key does not list).
# W3 monthly summary: 'PF LTM'!E16 = 2,999,999.90; its Aug-25 cell K16 is 249,999.90 where the valuation has 250,000 (the $0.10 cause).
G2_FILES = {"W1": "Harbourline - Q1 2026 Valuation Workbook.xlsx", "W2": "Fund IV - Valuation Summary Mar 31, 2026.xlsx",
            "W3": "Harbourline - Monthly Summary 2026.03.xlsx"}
G2_MONTHLY = [250_000.0] * 12
G2 = {"metric": 3_000_000.0, "multiple": 10.0, "ev": 30_000_000.0, "cash": 1_250_000.5, "debt": 500_000.0, "equity": 30_750_000.5,
      "units_inv": 800_000, "units_mgmt": 200_000, "fund_mgmt": 180_000}
G2["per_unit"] = G2["equity"] / (G2["units_inv"] + G2["units_mgmt"])
G2["investor"] = G2["units_inv"] * G2["per_unit"]
G2["fund"] = float(round(G2["investor"]))


def build_g2_workbooks(out):
    os.makedirs(out, exist_ok=True)
    months = MF.month_ends(2025, 4, 12)                              # Apr-25 .. Mar-26
    earlier = MF.month_ends(2025, 3, 12)                             # Mar-25 .. Feb-26 (the decoy header)
    b = MF.Book()
    pf = b.sheet("Pro Forma")
    pf.put("A1", "Harbourline Test Co - pro forma TTM"); pf.put("B4", "Month")
    for i, d in enumerate(months):
        pf.put(f"{MF.col(3 + i)}4", d, s=1)
    pf.put("O4", "TTM")
    pf.put("B6", "Reported EBITDA"); pf.row(6, 3, [v - 20_000 for v in G2_MONTHLY]); pf.put("O6", sum(G2_MONTHLY) - 240_000, "SUM(C6:N6)", 2)
    pf.put("B7", "Add-backs"); pf.row(7, 3, [20_000.0] * 12); pf.put("O7", 240_000.0, "SUM(C7:N7)", 2)
    pf.put("B8", "Adjusted EBITDA"); pf.row(8, 3, G2_MONTHLY, f=MF.SI(), shared="C6+C7"); pf.put("O8", G2["metric"], "SUM(C8:N8)", 2)
    pf.put("B10", "Platform adjustments"); pf.row(10, 3, [5_000.0] * 12); pf.put("O10", 60_000.0, "SUM(C10:N10)", 2)
    pf.put("B11", "Operating adjusted EBITDA (not used)"); pf.put("O11", G2["metric"] + 60_000, "O8+O10", 2)
    pf.put("B13", "Prior TTM month")
    for i, d in enumerate(earlier):
        pf.put(f"{MF.col(3 + i)}13", d, s=1)
    pf.put("B14", "Prior TTM adjusted EBITDA"); pf.row(14, 3, G2_MONTHLY); pf.put("O14", G2["metric"], "SUM(C14:N14)", 2)
    sc = b.sheet("Scratch")
    sc.put("A1", "Working numbers (no headers)"); sc.row(3, 3, G2_MONTHLY)
    ea = b.sheet("EBITDA Adjustments")
    ea.put("A1", "EBITDA adjustments schedule (presentation)"); ea.put("D6", "Month")
    for i, d in enumerate(months):
        ea.put(f"{MF.col(5 + i)}6", d, s=1)
    ea.put("D8", "Adjusted EBITDA")
    for i in range(12):
        ea.put(f"{MF.col(5 + i)}8", G2_MONTHLY[i], f"'Pro Forma'!{MF.col(3 + i)}8", 2)
    vs = b.sheet("Valuation Summary")
    vs.put("A1", "Harbourline Test Co - valuation summary"); vs.put("F7", "Current period"); vs.put("F8", datetime.date(2026, 3, 31), s=6)
    vs.put("B9", "EV/Adj. EBITDA multiple"); vs.put("F9", G2["multiple"], None, 3)
    vs.put("B10", "TTM adjusted EBITDA"); vs.put("F10", G2["metric"], "'Pro Forma'!O8", 2)
    vs.put("B12", "Enterprise value"); vs.put("F12", G2["ev"], "F9*F10", 2)
    vs.put("B13", "Cash"); vs.put("F13", G2["cash"], None, 2)
    vs.put("B14", "Debt"); vs.put("F14", G2["debt"], None, 2)
    vs.put("B15", "Equity value"); vs.put("F15", G2["equity"], "F12+F13-F14", 2)
    vs.put("B25", "Value to investor"); vs.put("F25", G2["investor"], "'Cap Table'!H20", 2)
    ct = b.sheet("Cap Table")
    ct.put("A1", "Cap table"); ct.put("B5", "Equity value"); ct.put("C5", G2["equity"], "'Valuation Summary'!F15", 2)
    ct.put("B8", "Investor units"); ct.put("C8", G2["units_inv"], None, 2)
    ct.put("B9", "Management units"); ct.put("C9", G2["units_mgmt"], None, 2)
    ct.put("B10", "Total units"); ct.put("C10", G2["units_inv"] + G2["units_mgmt"], "C8+C9", 2)
    ct.put("B12", "Value per unit"); ct.put("C12", G2["per_unit"], "C5/C10", 0)
    ct.put("B20", "Investor value"); ct.put("H20", G2["investor"], "C8*C12", 2)
    b.save(os.path.join(out, G2_FILES["W1"]))

    b = MF.Book()
    fv = b.sheet("Valuation Summary")
    fv.put("A1", "Fund IV - valuation summary"); fv.put("D6", "Valuation as of Mar 31, 2026")
    fv.put("B8", "Harbourline Test Co"); fv.put("D8", G2["fund"], None, 2)
    ho = b.sheet("Holding")
    ho.put("A1", "Harbourline Test Co - fund copy of the cap table")
    ho.put("B8", "Investor units"); ho.put("C8", G2["units_inv"], None, 2)
    ho.put("B9", "Management units"); ho.put("C9", G2["fund_mgmt"], None, 2)
    b.save(os.path.join(out, G2_FILES["W2"]))

    b = MF.Book()
    lt = b.sheet("PF LTM")
    lt.put("A1", "Harbourline Test Co - monthly summary, PF LTM"); lt.put("C4", datetime.date(2026, 3, 31), s=6)
    for i, d in enumerate(months):
        lt.put(f"{MF.col(7 + i)}14", d, s=1)
    vals = list(G2_MONTHLY)
    vals[4] = 249_999.9                                               # Aug-25 (column K): the $0.10 cause
    lt.put("D16", "PF LTM adjusted EBITDA"); lt.row(16, 7, vals); lt.put("E16", sum(vals), "SUM(G16:R16)", 2)
    b.save(os.path.join(out, G2_FILES["W3"]))


def gold_g2(shas):
    sf = {k: {"file": v, "sha256": shas[k]} for k, v in G2_FILES.items()}
    a = lambda ref, shows, **k: {"ref": ref, "shows": shows, **k}
    return {
        "schema": "gold-mvp/3", "case_id": "G2", "quarter_end": "2026-03-31", "source_files": sf,
        "answers": {
            "valuation_method": {"answer": "EV/EBITDA", "primary_anchor": a("W1:'Valuation Summary'!F12", "EV = multiple x metric")},
            "valuation_metric": {"answer": "TTM adjusted EBITDA", "value": G2["metric"], "primary_anchor": a("W1:'Valuation Summary'!F10", "Metric used")},
            "metric_period": {"answer": "TTM Apr 2025 - Mar 2026", "first_month": "2025-04", "last_month": "2026-03",
                              "header_anchor": a("W1:'EBITDA Adjustments'!E6:P6", "Month headers of the schedule"),
                              "value_anchor": a("W1:'EBITDA Adjustments'!E8:P8", "The 12 monthly adjusted EBITDA values")},
            "applied_multiple": {"answer": G2["multiple"], "primary_anchor": a("W1:'Valuation Summary'!F9", "Multiple applied")},
            "enterprise_value": {"answer": G2["ev"], "primary_anchor": a("W1:'Valuation Summary'!F12", "Enterprise value")},
            "equity_bridge": {"answer": "Enterprise Value + Cash - Debt = Total Equity", "cash": G2["cash"], "debt": G2["debt"], "equity_value": G2["equity"],
                              "primary_anchor": a("W1:'Valuation Summary'!F15", "Equity value"),
                              "supporting_anchors": [a("W1:'Valuation Summary'!F13", "Cash", support="component", component="cash"),
                                                     a("W1:'Valuation Summary'!F14", "Debt", support="component", component="debt")]},
            "ownership_or_waterfall": {"answer": "Equity per unit times the investor's units.", "primary_anchor": a("W1:'Cap Table'", "Cap table")},
            "company_value": {"answer": G2["investor"], "primary_anchor": a("W1:'Cap Table'!H20", "Investor value by cap table"),
                              "supporting_anchors": [a("W1:'Valuation Summary'!F25", "Linked summary copy")]},
            "fund_reported_value": {"answer": G2["fund"], "primary_anchor": a("W2:'Valuation Summary'!D8", "Fund-reported value")},
            "company_to_fund_relationship": {"answer": "MATCH", "relationship_basis": {"type": "ROUNDING", "decimals": 0},
                                             "explanation": "The fund shows the company value in whole dollars."},
        },
        "known_rivals": [
            {"id": "R1", "candidate": "Operating adjusted EBITDA", "looks_like": "the metric", "why_not_the_answer": "the summary links O8, not O11",
             "cells": ["W1:'Pro Forma'!O11"]},
            {"id": "R2", "candidate": "Prior TTM adjusted EBITDA", "looks_like": "the metric (same total)", "why_not_the_answer": "its headers are a month earlier",
             "cells": ["W1:'Pro Forma'!O14"]}],
        "material_discrepancies": [
            {"id": "MD1", "item": "Company value versus fund-reported value", "status": "ROUNDING", "basis": {"type": "ROUNDING", "decimals": 0},
             "explanation": "The fund types the company value rounded to whole dollars.", "cells": ["W1:'Valuation Summary'!F25", "W2:'Valuation Summary'!D8"]},
            {"id": "MD2", "item": "TTM adjusted EBITDA versus the monthly summary's PF LTM", "status": "UNRESOLVED",
             "explanation": "A $0.10 difference; its cause is not documented.", "cells": ["W1:'Pro Forma'!O8", "W3:'PF LTM'!E16"]}],
        "human_judgments": [
            {"id": "HJ1", "question": "Was the 10.0x multiple approved?", "answer": "UNRESOLVED", "cells": ["W1:'Valuation Summary'!F9"]},
            {"id": "HJ2", "question": "What causes the $0.10 difference between the metric and the PF LTM?", "answer": "UNRESOLVED",
             "cells": ["W1:'Pro Forma'!O8", "W3:'PF LTM'!E16"]}],
        "certification": {"material_truth_complete": "YES", "missing": [], "analyst_note": "synthetic test fixture - invented values"},
    }


def extraction_g2(shas):
    src = lambda i, role: {"id": i, "file": G2_FILES[i], "sha256": shas[i], "role": role, "period": "Q1 2026", "contributes": role, "reason": role}
    c = lambda s, cell, what, **k: {"source": s, "cell": cell, "what": what, **k}
    n = lambda s, cell: {"source": s, "cell": cell}
    return {
        "schema": "13.0.0", "company": "Harbourline Test Co", "quarter_end": "2026-03-31", "status": "final",
        "sources": [src("W1", "company_valuation"), src("W2", "fund_valuation"), src("W3", "monthly_summary")], "external": [],
        "chain": {"source": "W1", "method": "EV/EBITDA multiple",
                  "valuation_metric": c("W1", "'Valuation Summary'!F10", "TTM adjusted EBITDA"),
                  "selected_multiple": c("W1", "'Valuation Summary'!F9", "multiple"),
                  "enterprise_value": c("W1", "'Valuation Summary'!F12", "F9*F10"),
                  "bridge": [{"cell": "'Valuation Summary'!F13", "sign": 1, "what": "cash"}, {"cell": "'Valuation Summary'!F14", "sign": -1, "what": "debt"}],
                  "equity_value": c("W1", "'Valuation Summary'!F15", "EV + cash - debt"),
                  "waterfall": [c("W1", "'Cap Table'!C5", "equity link"), c("W1", "'Cap Table'!C12", "per unit"), c("W1", "'Cap Table'!H20", "investor value")],
                  "value_to_xpv": c("W1", "'Valuation Summary'!F25", "value to investor"),
                  "metric_window": {"source": "W1", "cells": "'Pro Forma'!C8:N8", "first": "2025-04", "last": "2026-03", "link": "arithmetic_transformation"},
                  "fund_cell": {"source": "W2", "cell": "'Valuation Summary'!D8"}},
        "provenance": [],
        "downstream": [{"id": "E1", "from": n("W1", "'Valuation Summary'!F25"), "to": n("W2", "'Valuation Summary'!D8"), "class": "rounded_match",
                        "relation": {"op": "round", "factor": 1, "decimals": 0}, "what": "company value typed into the fund summary in whole dollars"}],
        "discrepancies": [
            {"id": "D2", "a": n("W1", "'Pro Forma'!O8"), "b": n("W3", "'PF LTM'!E16"), "relation": {"op": "equal"}, "difference": -0.1,
             "what": "the monthly summary's PF LTM is $0.10 below the metric", "driver": "Aug-25: 249,999.90 in the summary vs 250,000 in the valuation",
             "driver_cells": [n("W3", "'PF LTM'!K16"), n("W1", "'Pro Forma'!G8")], "status": "explained", "material": False},
            {"id": "D3", "a": n("W1", "'Cap Table'!C9"), "b": n("W2", "'Holding'!C9"), "relation": {"op": "equal"}, "difference": -20_000,
             "what": "the fund's copy of the cap table has 180,000 management units, the company's 200,000", "status": "unresolved", "material": True},
            {"id": "D4", "a": n("W1", "'Cap Table'!C8"), "b": n("W2", "'Holding'!C8"), "relation": {"op": "equal"}, "difference": 1_000,
             "what": "investor units differ by 1,000 (a claim that does not reproduce)", "status": "unresolved", "material": True}],
        "rejected": [c("W1", "'Pro Forma'!O11", "operating adjusted EBITDA", why="the summary links O8"),
                     c("W1", "'Pro Forma'!O14", "prior TTM adjusted EBITDA", why="its headers are a month earlier")],
        "inputs": [], "deferred": [],
        "open_questions": ["Was the 10.0x multiple ('Valuation Summary'!F9) approved by the valuation committee?"],
        "how_it_works": "TTM adjusted EBITDA x 10.0 = EV; plus cash, less debt = equity; the investor holds 800,000 of 1,000,000 units.",
        "verification": {"status": "VERIFIED"},
    }


def build_g2(out):
    sd = os.path.join(out, "set-G2")
    build_g2_workbooks(sd)
    shas = {k: sha(os.path.join(sd, v)) for k, v in G2_FILES.items()}
    os.makedirs(os.path.join(out, "keys"), exist_ok=True)
    os.makedirs(os.path.join(out, "reference", "G2"), exist_ok=True)
    json.dump(gold_g2(shas), open(os.path.join(out, "keys", "gold-G2.json"), "w"), indent=1)
    json.dump(remap(extraction_g2(shas), ext_ids(G2_FILES)), open(os.path.join(out, "reference", "G2", "extraction.json"), "w"), indent=1)
    return shas


# ---------------- G3 (build 13.2.1): the real-key suggestion failures, on invented numbers ----------------
# A FREE-TEXT key (no id, cells or keywords, like a first analyst key) whose items reproduce: a fund sheet whose raw name has a trailing space
# ('Valuation Summary '), a metric anchor written as a whole row range ('III. Valuation Summary'!B10:F10), prior-period and prior-year columns,
# a later-quarter fund value, a rival on a named sheet with no cell, a rival found only by its row label, a cross-workbook $0.0962 difference,
# a same-total decoy in another sheet, a comparison with no second side in the files, and a cell written in the text that is blank.
G3_FILES = {"W1": "Kestrel - Q1 2026 Valuation Workbook DRAFT.xlsx", "W2": "Fund III - Valuation Summary_Jun 30, 2026.xlsx",
            "W3": "Kestrel - Monthly Summary 2026.03.xlsx"}
G3_MONTHLY = [166_666.6875] * 12                                        # sums to exactly 2,000,000.25
G3 = {"metric": 2_000_000.25, "multiple": 12.0, "cash": 400_000.0, "debt": 0.0}
G3["ev"] = G3["metric"] * G3["multiple"]
G3["equity"] = G3["ev"] + G3["cash"] - G3["debt"]
G3["investor"] = G3["equity"] * 0.8
G3["fund"] = float(round(G3["investor"]))


def build_g3_workbooks(out):
    os.makedirs(out, exist_ok=True)
    months = MF.month_ends(2025, 4, 12)
    b = MF.Book()
    vs = b.sheet("III. Valuation Summary")
    vs.put("A1", "Kestrel Test Co - valuation summary (DRAFT)")
    for c_, d in (("F", datetime.date(2026, 3, 31)), ("H", datetime.date(2025, 12, 31)), ("J", datetime.date(2025, 3, 31))):
        vs.put(f"{c_}8", d, s=6)
    rows = [("B9", "EV/Adj. EBITDA multiple", 9, (G3["multiple"], 11.5, 10.0), 3), ("B10", "Pro forma TTM adjusted EBITDA", 10, (G3["metric"], 1_900_000.0, 1_800_000.0), 2),
            ("B12", "Enterprise value", 12, (G3["ev"], 21_850_000.0, 18_000_000.0), 2), ("B15", "Equity value", 15, (G3["equity"], 22_250_000.0, 18_400_000.0), 2),
            ("B25", "Value to investor", 25, (G3["investor"], 17_800_000.0, 14_720_000.0), 2)]
    f_ = {9: None, 10: "'Pro Forma Financials'!D38", 12: "F9*F10", 15: "F12+F13-F14", 25: "'Cap Table (Mar 2026)'!J35"}
    for lab, text, r, vals, st_ in rows:
        vs.put(lab, text)
        vs.put(f"F{r}", vals[0], f_[r], st_); vs.put(f"H{r}", vals[1], None, st_); vs.put(f"J{r}", vals[2], None, st_)
    vs.put("B13", "Cash"); vs.put("F13", G3["cash"], "'Pro Forma Financials'!T45", 2)
    vs.put("B14", "Debt"); vs.put("F14", G3["debt"], "'Financial Summary'!I60", 2)
    pf = b.sheet("Pro Forma Financials")
    pf.put("A1", "Pro forma financials"); pf.put("D8", "TTM")
    for i, d in enumerate(months):
        pf.put(f"{MF.col(9 + i)}8", d, s=1)
    pf.put("B21", "Reported EBITDA"); pf.row(21, 9, [v - 30_000 for v in G3_MONTHLY]); pf.put("D21", G3["metric"] - 360_000, "SUM(I21:T21)", 2)
    pf.put("B38", "Adjusted EBITDA"); pf.row(38, 9, G3_MONTHLY); pf.put("D38", G3["metric"], "SUM(I38:T38)", 2)
    pf.put("B42", "Operating Adjusted EBITDA"); pf.put("D42", G3["metric"] + 300_000, None, 2)
    pf.put("B45", "Cash"); pf.put("T45", G3["cash"], None, 2)
    ea = b.sheet("IV. EBITDA Adjustments")
    ea.put("A1", "Schedule (presentation)")
    for i, d in enumerate(months):
        ea.put(f"{MF.col(5 + i)}6", d, s=1)
        ea.put(f"{MF.col(5 + i)}8", G3_MONTHLY[i], f"'Pro Forma Financials'!{MF.col(9 + i)}38", 2)
    fs = b.sheet("Financial Summary")
    fs.put("B54", "TTM adjusted EBITDA (parallel)"); fs.put("N54", G3["metric"], None, 2)       # a same-total decoy
    fs.put("B60", "Debt"); fs.put("I60", G3["debt"], None, 2)
    ct = b.sheet("Cap Table (Mar 2026)")
    ct.put("B4", "Equity value"); ct.put("D4", G3["equity"], "'III. Valuation Summary'!F15", 2)
    ct.put("B35", "Investor value (80%)"); ct.put("J35", G3["investor"], "D4*0.8", 2)
    b.save(os.path.join(out, G3_FILES["W1"]))

    b = MF.Book()
    fv = b.sheet("Valuation Summary ")                                    # the raw name has a trailing space
    fv.put("A1", "Fund III - valuation summary"); fv.put("D6", "Valuation as of Mar 31, 2026"); fv.put("H6", "Valuation as of Jun 30, 2026")
    fv.put("B8", "Kestrel Test Co"); fv.put("D8", G3["fund"], None, 2); fv.put("H8", 27_000_000.0, None, 2)
    b.save(os.path.join(out, G3_FILES["W2"]))

    b = MF.Book()
    lt = b.sheet("PF LTM Calculation")
    lt.put("C4", datetime.date(2026, 3, 31), s=6); lt.put("B16", "LTM Adjusted EBITDA"); lt.put("E16", G3["metric"] - 0.0962, None, 2)
    ad = b.sheet("EBITDA Adjustments")
    ad.put("B91", "Schedule total"); ad.put("E91", G3["metric"], None, 2)                       # equal to the metric: never the "other side"
    b.save(os.path.join(out, G3_FILES["W3"]))


def gold_g3(shas):
    sf = {k: {"file": v, "sha256": shas[k]} for k, v in G3_FILES.items()}
    a = lambda ref, shows: {"ref": ref, "shows": shows}
    return {
        "schema": "gold-mvp/3", "case_id": "G3", "quarter_end": "2026-03-31", "source_files": sf,
        "answers": {
            "valuation_method": {"answer": "EV/EBITDA", "primary_anchor": a("W1:'III. Valuation Summary'!F12", "EV")},
            "valuation_metric": {"answer": "TTM pro forma adjusted EBITDA", "primary_anchor": a("W1:'III. Valuation Summary'!B10:F10", "Metric row")},
            "metric_period": {"answer": "TTM Apr 2025 - Mar 2026", "first_month": "2025-04", "last_month": "2026-03",
                              "primary_anchor": a("W1:'IV. EBITDA Adjustments'!E6:P6", "Month headers")},
            "applied_multiple": {"answer": G3["multiple"], "primary_anchor": a("W1:'III. Valuation Summary'!F9", "Multiple")},
            "enterprise_value": {"answer": G3["ev"], "primary_anchor": a("W1:'III. Valuation Summary'!F12", "Enterprise value")},
            "equity_bridge": {"answer": "Enterprise Value + Cash - Debt = Total Equity", "cash": G3["cash"], "debt": G3["debt"], "equity_value": G3["equity"],
                              "primary_anchor": a("W1:'III. Valuation Summary'!F15", "Equity value"),
                              "supporting_anchors": [a("W1:'Pro Forma Financials'!T45", "Cash"), a("W1:'Financial Summary'!I60", "Debt")]},
            "ownership_or_waterfall": {"answer": "80% of equity to the investor.", "primary_anchor": a("W1:'Cap Table (Mar 2026)'", "Cap table")},
            "company_value": {"answer": G3["investor"], "primary_anchor": a("W1:'III. Valuation Summary'!F25", "Value to investor")},
            "fund_reported_value": {"answer": G3["fund"], "primary_anchor": a("W2:'Valuation Summary'!D8", "Fund-reported value")},
            "company_to_fund_relationship": {"answer": "MATCH", "relationship_basis": {"type": "ROUNDING", "decimals": 0}, "explanation": "Rounded to whole dollars."},
        },
        "known_rivals": [
            {"candidate": "Prior-period column in W1:'III. Valuation Summary'", "looks_like": "the current-period values", "why_not_the_answer": "it is the 31 Dec 2025 column"},
            {"candidate": "Prior-year column in W1:'III. Valuation Summary'", "looks_like": "the current-period values", "why_not_the_answer": "it is the 31 Mar 2025 column"},
            {"candidate": "W2 Kestrel valuation as of Jun 30 2026", "looks_like": "the fund-reported value", "why_not_the_answer": "it is the next quarter's value"},
            {"candidate": "W3:'PF LTM Calculation' LTM Adjusted EBITDA", "looks_like": "the metric", "why_not_the_answer": "it is not linked and differs slightly"},
            {"candidate": "Unadjusted (reported) EBITDA before approved adjustment categories", "looks_like": "the metric", "why_not_the_answer": "it excludes the add-backs"},
            {"candidate": "Draft value in W1:'III. Valuation Summary'!G25 or W1:'III. Valuation Summary'!B25", "looks_like": "the value to the investor",
             "why_not_the_answer": "a scratch cell"},
            {"candidate": "Parallel TTM adjusted EBITDA of 2,000,000.25 outside the chain", "looks_like": "the metric", "why_not_the_answer": "not referenced"}],
        "material_discrepancies": [
            {"item": "Valuation-workbook TTM Adjusted EBITDA versus monthly-summary PF LTM Adjusted EBITDA", "status": "UNRESOLVED", "explanation": "Not linked; differs slightly."},
            {"item": "Company value versus fund-reported March 31 value", "status": "ROUNDING", "explanation": "The fund types the value in whole dollars."},
            {"item": "Fund multiple versus company multiple, undocumented", "status": "UNRESOLVED", "explanation": "No supplied file holds the fund's multiple."}],
        "human_judgments": [
            {"question": "Was the 12.0x multiple formally approved for Q1 2026?", "answer": "UNRESOLVED"},
            {"question": "What causes the 0.0962 difference between W1 and W3 TTM Adjusted EBITDA?", "answer": "UNRESOLVED"}],
        "certification": {"material_truth_complete": "YES", "missing": [], "analyst_note": "synthetic test fixture - invented values"},
    }


def build_g3(out):
    sd = os.path.join(out, "set-G3")
    build_g3_workbooks(sd)
    shas = {k: sha(os.path.join(sd, v)) for k, v in G3_FILES.items()}
    os.makedirs(os.path.join(out, "keys"), exist_ok=True)
    json.dump(gold_g3(shas), open(os.path.join(out, "keys", "gold-G3.json"), "w"), indent=1)
    return shas


# ---------------- G4 (build 13.2.2): four more real-review failures, on invented numbers ----------------
#   R5-type: an "unadjusted / pro forma EBITDA" rival whose words also match a MULTIPLE label in a column headed "LTM" on the comparables sheet;
#   R3-type: a fund sheet with three Jun 30, 2026 columns (cost, valuation, gain): only the one worded like the anchor's own header is the value;
#   R4-type: a PF LTM sheet with a standalone "LTM Adjusted EBITDA" row, the intended "PF LTM Adjusted EBITDA" row and a "prior version" row;
#   MD1/HJ1-type: the second side of a W1-vs-W3 comparison, with a cell holding the stated difference itself, a formula copy of the PF LTM
#   value on another sheet, and a schedule total equal to the metric.
G4_FILES = {"W1": "Osprey - Q1 2026 Valuation Workbook DRAFT.xlsx", "W2": "Fund III - Valuation Summary_Jun 30, 2026.xlsx",
            "W3": "Osprey Water - Monthly Summary 2026.03.xlsx"}
G4_MONTHLY = [125_000.0] * 12
G4 = {"metric": 1_500_000.0, "multiple": 13.25, "cash": 250_000.0, "debt": 0.0, "diff": 0.0962098143}
G4["ev"] = G4["metric"] * G4["multiple"]
G4["equity"] = G4["ev"] + G4["cash"] - G4["debt"]
G4["investor"] = G4["equity"] * 0.9
G4["fund"] = float(round(G4["investor"]))


def build_g4_workbooks(out):
    os.makedirs(out, exist_ok=True)
    months = MF.month_ends(2025, 4, 12)
    b = MF.Book()
    vs = b.sheet("III. Valuation Summary")
    vs.put("F8", datetime.date(2026, 3, 31), s=6); vs.put("H8", datetime.date(2025, 12, 31), s=6)
    vs.put("B9", "EV / Pro Forma Adj. EBITDA Multiple"); vs.put("F9", G4["multiple"], "'V. Comparables'!D39", 3); vs.put("H9", 12.5, None, 3)
    vs.put("B10", "Pro Forma TTM Adj. EBITDA"); vs.put("F10", G4["metric"], "'Pro Forma Financials (Q1)'!D38", 2); vs.put("H10", 1_400_000.0, None, 2)
    vs.put("B12", "Enterprise Value"); vs.put("F12", G4["ev"], "F9*F10", 2)
    vs.put("B13", "Cash"); vs.put("F13", G4["cash"], None, 2)
    vs.put("B14", "Debt"); vs.put("F14", G4["debt"], None, 2)
    vs.put("B15", "Equity Value"); vs.put("F15", G4["equity"], "F12+F13-F14", 2)
    vs.put("B25", "XPV Value"); vs.put("F25", G4["investor"], "'Cap Table (Mar 2026)'!J35", 2)
    cp = b.sheet("V. Comparables")
    cp.put("C9", "Company"); cp.put("D9", "LTM")                         # a column headed LTM - of MULTIPLES
    cp.put("C11", "Peer A"); cp.put("D11", 14.0, None, 3); cp.put("C12", "Peer B"); cp.put("D12", 12.5, None, 3)
    cp.put("B39", "Selected EV / Pro Forma Adj. EBITDA multiple"); cp.put("D39", G4["multiple"], None, 3)
    pf = b.sheet("Pro Forma Financials (Q1)")
    pf.put("D8", "TTM")
    for i, d in enumerate(months):
        pf.put(f"{MF.col(9 + i)}8", d, s=1)
    pf.put("B21", "Reported EBITDA"); pf.row(21, 9, [v - 100_000 for v in G4_MONTHLY]); pf.put("D21", G4["metric"] - 1_200_000, "SUM(I21:T21)", 2)
    pf.put("B24", "Pro Forma EBITDA"); pf.row(24, 9, [v - 75_000 for v in G4_MONTHLY]); pf.put("D24", G4["metric"] - 900_000, "SUM(I24:T24)", 2)
    pf.put("B38", "Pro Forma Adjusted EBITDA"); pf.row(38, 9, G4_MONTHLY); pf.put("D38", G4["metric"], "SUM(I38:T38)", 2)
    ea = b.sheet("IV. EBITDA Adjustments")
    for i, d in enumerate(months):
        ea.put(f"{MF.col(5 + i)}6", d, s=1)
    ct = b.sheet("Cap Table (Mar 2026)")
    ct.put("D4", G4["equity"], "'III. Valuation Summary'!F15", 2); ct.put("B35", "XPV proceeds"); ct.put("J35", G4["investor"], "D4*0.9", 2)
    b.save(os.path.join(out, G4_FILES["W1"]))

    b = MF.Book()
    fv = b.sheet("Valuation Summary ")
    for c_, t in (("D", "Valuation as of Mar 31, 2026"), ("F", "Cost as of Jun 30, 2026"), ("H", "Valuation as of Jun 30, 2026"), ("J", "Unrealized Gain as of Jun 30, 2026")):
        fv.put(f"{c_}6", t)
    fv.put("B8", "Osprey Water"); fv.put("D8", G4["fund"], None, 2); fv.put("F8", 9_000_000.0, None, 2); fv.put("H8", 24_000_000.0, None, 2); fv.put("J8", 15_000_000.0, None, 2)
    fv.put("B9", "Other Co"); fv.put("D9", 5_000_000.0, None, 2); fv.put("F9", 4_000_000.0, None, 2); fv.put("H9", 5_500_000.0, None, 2); fv.put("J9", 1_500_000.0, None, 2)
    b.save(os.path.join(out, G4_FILES["W2"]))

    b = MF.Book()
    lt = b.sheet("PF LTM Calculation")
    lt.put("A1", "PF LTM Calculation"); lt.put("E14", "LTM")
    lt.put("B12", "Osprey LTM Adjusted EBITDA"); lt.put("E12", 1_100_000.0, None, 2)
    lt.put("B16", "PF LTM Adjusted EBITDA"); lt.put("E16", G4["metric"] - G4["diff"], None, 2)
    lt.put("B18", "PF LTM Adjusted EBITDA (prior version)"); lt.put("E18", G4["metric"] + 3.0, None, 2)
    lt.put("B20", "Difference to valuation"); lt.put("E20", G4["diff"], None, 0)          # the difference itself: never a side
    mc = b.sheet("March 2026 ")
    mc.put("B30", "Adjusted EBITDA"); mc.put("E30", G4["metric"] - G4["diff"], "'PF LTM Calculation'!E16", 2)    # a formula copy of E16
    ad = b.sheet("EBITDA Adjustments")
    ad.put("B91", "LTM Adj. EBITDA (schedule)"); ad.put("E91", G4["metric"], None, 2)                 # equal to the metric
    b.save(os.path.join(out, G4_FILES["W3"]))


def gold_g4(shas):
    sf = {k: {"file": v, "sha256": shas[k]} for k, v in G4_FILES.items()}
    a = lambda ref, shows: {"ref": ref, "shows": shows}
    return {
        "schema": "gold-mvp/3", "case_id": "G4", "quarter_end": "2026-03-31", "source_files": sf,
        "answers": {
            "valuation_method": {"answer": "EV/EBITDA", "primary_anchor": a("W1:'III. Valuation Summary'!F12", "EV")},
            "valuation_metric": {"answer": "Pro forma TTM adjusted EBITDA", "primary_anchor": a("W1:'III. Valuation Summary'!B10:F10", "Metric row")},
            "metric_period": {"answer": "TTM Apr 2025 - Mar 2026", "first_month": "2025-04", "last_month": "2026-03",
                              "primary_anchor": a("W1:'IV. EBITDA Adjustments'!E6:P6", "Month headers")},
            "applied_multiple": {"answer": G4["multiple"], "primary_anchor": a("W1:'III. Valuation Summary'!F9", "Multiple")},
            "enterprise_value": {"answer": G4["ev"], "primary_anchor": a("W1:'III. Valuation Summary'!F12", "EV")},
            "equity_bridge": {"answer": "Enterprise Value + Cash - Debt = Total Equity", "cash": G4["cash"], "debt": G4["debt"], "equity_value": G4["equity"],
                              "primary_anchor": a("W1:'III. Valuation Summary'!F15", "Equity")},
            "ownership_or_waterfall": {"answer": "90% to XPV.", "primary_anchor": a("W1:'Cap Table (Mar 2026)'", "Cap table")},
            "company_value": {"answer": G4["investor"], "primary_anchor": a("W1:'III. Valuation Summary'!F25", "XPV value")},
            "fund_reported_value": {"answer": G4["fund"], "primary_anchor": a("W2:'Valuation Summary'!D8", "Fund value, Mar 31")},
            "company_to_fund_relationship": {"answer": "MATCH", "relationship_basis": {"type": "ROUNDING", "decimals": 0}, "explanation": "Whole dollars."},
        },
        "known_rivals": [
            {"candidate": "W2 Osprey valuation as of Jun 30 2026", "looks_like": "the fund-reported value", "why_not_the_answer": "next quarter"},
            {"candidate": "W3:'PF LTM Calculation' LTM Adjusted EBITDA", "looks_like": "the metric", "why_not_the_answer": "not linked"},
            {"candidate": "Unadjusted or pro forma EBITDA before approved adjustment categories", "looks_like": "the metric", "why_not_the_answer": "before the add-backs"}],
        "material_discrepancies": [
            {"item": "Valuation-workbook TTM Adjusted EBITDA versus monthly-summary PF LTM Adjusted EBITDA", "status": "UNRESOLVED", "explanation": "Not linked."}],
        "human_judgments": [
            {"question": "What causes the 0.0962098143 difference between W1 and W3 TTM Adjusted EBITDA?", "answer": "UNRESOLVED"}],
        "certification": {"material_truth_complete": "YES", "missing": [], "analyst_note": "synthetic test fixture - invented values"},
    }


def build_g4(out):
    sd = os.path.join(out, "set-G4")
    build_g4_workbooks(sd)
    shas = {k: sha(os.path.join(sd, v)) for k, v in G4_FILES.items()}
    os.makedirs(os.path.join(out, "keys"), exist_ok=True)
    json.dump(gold_g4(shas), open(os.path.join(out, "keys", "gold-G4.json"), "w"), indent=1)
    return shas


def build(out):
    sd = os.path.join(out, "set-G1")
    build_workbooks(sd)
    shas = {k: sha(os.path.join(sd, v)) for k, v in FILES.items()}
    os.makedirs(os.path.join(out, "keys"), exist_ok=True)
    os.makedirs(os.path.join(out, "reference", "G1"), exist_ok=True)
    json.dump(gold(shas), open(os.path.join(out, "keys", "gold-G1.json"), "w"), indent=1)
    for name, flawed in (("extraction-flawed", True), ("extraction-clean", False)):
        json.dump(remap(extraction(shas, flawed), ext_ids()), open(os.path.join(out, "reference", "G1", name + ".json"), "w"), indent=1)
    return shas


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="trial")
    a = ap.parse_args()
    for k, v in build(a.out).items():
        print(f"{k} {FILES[k]} sha256 {v}")
    for k, v in build_g2(a.out).items():
        print(f"G2 {k} {G2_FILES[k]} sha256 {v}")
    for k, v in build_g3(a.out).items():
        print(f"G3 {k} {G3_FILES[k]} sha256 {v}")
    for k, v in build_g4(a.out).items():
        print(f"G4 {k} {G4_FILES[k]} sha256 {v}")
