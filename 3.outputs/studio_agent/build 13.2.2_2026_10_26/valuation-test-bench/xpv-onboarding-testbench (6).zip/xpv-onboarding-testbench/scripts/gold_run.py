# gold_run.py (build 13.2.1, test bench) - the real-run gates in order, stopping at the first one that fails. It adds no logic of its own: each gate is
# the script of that name, and the three dimensions (Gold validity, Gold accuracy, extraction verification) stay separate in the output.
#   GATE 1  gold_suggest   the matching metadata the key still needs (information; items without any score UNSCORED)
#   GATE 2  (a person approves the proposals in the review sheet - --review-out writes it - and gold_suggest.py --apply writes a NEW key;
#            a human step; --require-metadata stops here when anything is still missing)
#   GATE 3  gold_sources   freeze the SHA-256 of the supplied binaries; GATE 4 compare them with the historical extraction's hashes
#   GATE 5  gold_validate  only a valid key goes on
#   GATE 6  gold_score     Gold accuracy, with the verifier's status shown separately (GATE 7)
# Build 13.2.1: the run ends with a SUMMARY of four results that are never merged: 1. fixture tests (the synthetic suite, with --fixture-tests),
# 2. Gold-key readiness, 3. verified anchor coverage (the key's own cells reopened in the workbooks), 4. extraction score.
# Nothing here changes the extraction, the key or the workbooks. Usage:
#   python gold_run.py --gold KEY.json --workbooks A.xlsx ... --extraction extraction.json [--verification V.json] [--manifest-out M.json]
#                      [--require-metadata] [--allow-different-binary] [--review-out review.xlsx] [--fixture-tests] [--out report.json]
import argparse, json, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gold_validate as GV, gold_suggest, gold_sources, gold_score  # noqa: E402


def lacking(gold):
    return sum(1 for k in ("known_rivals", "material_discrepancies", "human_judgments") for it in gold.get(k) or []
               if isinstance(it, dict) and not (GV.iid(it) or it.get("cells") or it.get("keywords")))


def coverage(gold, books):
    """3. verified anchor coverage: the key's item cells reopened in the workbooks (blank or missing cells do not count)"""
    items = [(k, it) for k in ("known_rivals", "material_discrepancies", "human_judgments") for it in gold.get(k) or [] if isinstance(it, dict)]
    with_cells = [(k, it) for k, it in items if it.get("cells")]
    ok, cmp_n, cmp_ok = 0, 0, 0
    for k, it in with_cells:
        good = 0
        for r in it["cells"]:
            c = GV._cell_of(books, r)
            if c and GV.parse_cell(c[2]) and (c[0].get(c[1], c[2]) or (None,))[0] is not None:
                good += 1
            elif c and not GV.parse_cell(c[2]) and GV.range_populated(c[0], c[1], c[2]):
                good += 1
        ok += good == len(it["cells"])
        if k == "material_discrepancies":
            cmp_n += 1
            cmp_ok += good >= 2
    cmp_all = sum(1 for k, _ in items if k == "material_discrepancies")
    return (f"{len(with_cells)}/{len(items)} items have cells; {ok}/{len(with_cells)} of those reopen with a value in every cell; "
            f"{cmp_ok}/{cmp_all} discrepancies cite both sides")


def summary(parts):
    print("")
    print("== SUMMARY (four separate results; none is evidence for another)")
    for i, (name, text) in enumerate(parts, 1):
        print(f"{i}. {name}: {text}")


def main(argv=None):
    ap = argparse.ArgumentParser(description="run the Gold gates in order")
    ap.add_argument("--gold", required=True)
    ap.add_argument("--workbooks", nargs="+", required=True)
    ap.add_argument("--extraction", required=True)
    ap.add_argument("--verification")
    ap.add_argument("--manifest-out")
    ap.add_argument("--require-metadata", action="store_true")
    ap.add_argument("--allow-different-binary", action="store_true")
    ap.add_argument("--review-out", help="write gate 1's Approve / Correct / Reject review sheet here")
    ap.add_argument("--fixture-tests", action="store_true", help="also run the synthetic test suite (about a minute) for result 1")
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    gold = GV.read_json(a.gold)
    parts = {"Fixture tests": "NOT RUN (add --fixture-tests, or ask to run the onboarding tests)", "Gold-key readiness": "not reached",
             "Verified anchor coverage": "not reached", "Extraction score": "not reached"}
    if a.fixture_tests:
        r = subprocess.run([sys.executable, os.path.join(HERE, "test_onboarding.py")], capture_output=True, text=True)
        parts["Fixture tests"] = (r.stdout.strip().splitlines() or ["no output"])[-1] + " (synthetic fixtures only: proves the bench logic, not a real key or extraction)"
    try:
        return _run(a, gold, man_out=a.manifest_out, parts=parts)
    finally:
        summary(list(parts.items()))


def _run(a, gold, man_out, parts):
    man = man_out or os.path.join(tempfile.mkdtemp(prefix="gold_run_"), "source_manifest.json")
    print("== GATE 1: matching metadata (gold_suggest)")
    gold_suggest.main(["--gold", a.gold, "--workbooks", *a.workbooks] + (["--review", a.review_out] if a.review_out else []))
    n = lacking(gold) if isinstance(gold, dict) else 0
    print(f"== GATE 2: enrichment - {n} item(s) still lack id, cells and keywords" + (" (they will score UNSCORED; approve the proposals in the review "
          "sheet, then gold_suggest.py --gold KEY --apply REVIEW.xlsx --out NEW_KEY.json)" if n else ""))
    items = [(k, it) for k in ("known_rivals", "material_discrepancies", "human_judgments") for it in (gold.get(k) or [] if isinstance(gold, dict) else []) if isinstance(it, dict)]
    id_only = sum(1 for _, it in items if GV.iid(it) and not (it.get("cells") or it.get("keywords")))
    one_side = sum(1 for k, it in items if k == "material_discrepancies" and len(it.get("cells") or []) == 1)
    gaps = n + id_only + one_side
    parts["Gold-key readiness"] = (f"NOT READY - of {len(items)} rivals, discrepancies and unresolved decisions: {n} have no metadata (UNSCORED), "
                                   f"{id_only} have an id only (no cells or keywords, so an extraction cannot match them), {one_side} discrepancies cite one side only"
                                   if gaps else f"every one of {len(items)} items has cells or keywords, and every discrepancy cites two cells")
    if n and a.require_metadata:
        print("STOPPED at gate 2: --require-metadata is set; enrich the key and run again")
        return 3
    print("== GATE 3 and 4: source fingerprints and the historical extraction's hashes (gold_sources)")
    rc = gold_sources.main(["--gold", a.gold, "--workbooks", *a.workbooks, "--extraction", a.extraction, "--out", man])
    if rc:
        print("STOPPED at gate 3: the benchmark workbooks are not identified; nothing was validated or scored")
        return 1
    print("== GATE 5: Gold validation (gold_validate)")
    rc = GV.main(["--gold", a.gold, "--workbooks", *a.workbooks, "--sources", man])
    if rc:
        print("STOPPED at gate 5: the Gold key is not valid; nothing was scored")
        parts["Gold-key readiness"] = "INVALID - the key failed validation (see gate 5); " + parts["Gold-key readiness"]
        return 2
    v = GV.validate(gold, a.workbooks, manifest=GV.read_json(man))
    parts["Gold-key readiness"] = ("READY - valid, " if not gaps else "VALID but ") + parts["Gold-key readiness"]
    parts["Verified anchor coverage"] = coverage(v["gold"], v["books"] or {})
    print("== GATE 6 and 7: Gold score, with the extraction's verification shown separately (gold_score)")
    out = a.out or os.path.join(tempfile.mkdtemp(prefix="gold_run_"), "gold_report.json")
    args = ["--gold", a.gold, "--extraction", a.extraction, "--workbooks", *a.workbooks, "--sources", man]
    args += (["--verification", a.verification] if a.verification else []) + (["--allow-different-binary"] if a.allow_different_binary else []) + ["--out", out]
    rc = gold_score.main(args)
    if os.path.exists(out):
        R = json.load(open(out))
        S = R["summary"]
        parts["Extraction score"] = (f"core {S['core_correct']}/{S['core_total']}, wrong {S['wrong_material_answers']}, false claims {S['false_material_claims']}, "
                                     f"missed {S['material_gold_items_missed']}, needs analyst {S['needs_analyst']}, unscored {S['unscored']}, "
                                     f"found not in key {S.get('found_not_in_gold', 0)} (+{S.get('extra_not_verified', 0)} not verified) | "
                                     f"workbook verification {R.get('workbook_verification')} (separate) | source integrity {R['source_integrity']['summary']}")
    return rc


if __name__ == "__main__":
    sys.exit(main())
