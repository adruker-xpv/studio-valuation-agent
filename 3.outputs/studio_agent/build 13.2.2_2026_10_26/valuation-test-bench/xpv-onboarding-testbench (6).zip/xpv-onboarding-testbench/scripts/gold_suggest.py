# gold_suggest.py (build 13.2.2, test bench) - proposes the matching metadata a Gold key still needs, for a person to approve, and writes ONLY
# what they approved into a NEW key. Proposals come from the Gold key and the frozen workbooks only: never from an extraction, a reviewer
# output or any run result (a file that looks like one is refused), so the benchmark stays independent of what it grades.
#   Proposals, all mechanical: (1) a numbered id (R1, MD1, HJ1); (2) cells - references written in the item's own text; the anchor of a concept the
#   text names ("company value", "multiple"...); workbook cells holding a number written in the text (only when few cells hold it); (3) keyword
#   candidates from the item's own wording; (4) a support type for an answer anchor whose value is a part of the answer (cash, debt -> component)
#   or unrelated to it (context). Nothing is written to any key by the proposal step.
# Usage:
#   python gold_suggest.py --gold KEY.json [--workbooks A.xlsx ...] [--out suggestions.json] [--review review.xlsx]
#   python gold_suggest.py --gold KEY.json --apply review.xlsx --out NEW_KEY.json [--workbooks A.xlsx ...]
#   The review sheet has one row per proposal: Approve / Correct (type the corrected value) / Reject. --apply refuses a review made for another
#   version of the key, never overwrites a file, and records who reviewed it inside the new key (metadata_review).
import argparse, datetime, hashlib, json, os, re, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gold_validate as GV  # noqa: E402
from gold_validate import iid, refs_in_text, anchors_of, parse_ref, skey  # noqa: E402
from xlsx_evidence import num, addr  # noqa: E402

SECTIONS = [("known_rivals", "rival", "Known rival", "R", ("candidate", "looks_like", "why_not_the_answer")),
            ("material_discrepancies", "discrepancy", "Discrepancy", "MD", ("item", "explanation")),
            ("human_judgments", "judgment", "Unresolved decision", "HJ", ("question",))]
CONCEPT_WORDS = {"company_value": ("company value", "investor value", "value to xpv", "xpv value", "carrying value", "company investor value"),
                 "fund_reported_value": ("fund reported", "fund-reported", "fund value", "fund's value"),
                 "valuation_metric": ("adjusted ebitda", "ttm ebitda", "ltm ebitda", "valuation metric"),
                 "applied_multiple": ("multiple",), "enterprise_value": ("enterprise value",), "equity_bridge": ("equity value", "total equity")}
STOP = set("the a an of to in on for and or with by from as at is are was were be been this that these those its it versus vs than which what "
           "whether were all any not no nor their there into under over between formally approved approval valuation summary workbook value "
           "values sheet column row cell current quarter period what cause causes caused difference differences between".split())
ACTIONS = ("Approve", "Correct", "Reject")


def refuse_run_output(path):
    """True when a file is an extraction, a reviewer output or any run result: Gold metadata must never be derived from one."""
    if not str(path).lower().endswith(".json"):
        return False
    try:
        d = json.load(open(path, encoding="utf-8"))
    except Exception:
        return False
    return isinstance(d, dict) and (d.get("kind") in ("extraction", "review") or any(k in d for k in ("chain", "provenance", "downstream", "stage_hashes")))


def sha_file(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


VERIFIED, CANDIDATE = "verified", "candidate"
ROW_CONF = {"verified": "verified exact cell", "candidate": "candidate - review", "none": "no reliable candidate"}
GENERIC_SHEET = {"calculation", "calc", "sheet", "tab", "schedule", "the", "i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x"}
TOTAL_HEADERS = {"ttm", "ltm", "total", "ttm total", "ltm total", "pf ltm", "pf ttm"}
COMPARE = re.compile(r"\b(versus|vs\.?|between|differs?|difference|compared|against)\b", re.I)


def numbers_in(text, min_digits=4):
    """numbers written in the text with at least min_digits significant digits -> [(value, decimals)]; years (1990-2100) are skipped"""
    out = []
    for m in re.finditer(r"(?<![\w.])-?\d[\d,]*(?:\.\d+)?(?![\w.])", text):
        t = m.group().replace(",", "")
        if len(re.sub(r"[^0-9]", "", t).lstrip("0")) < min_digits:
            continue
        try:
            v = float(t)
        except ValueError:
            continue
        if "." not in t and 1990 <= v <= 2100:
            continue
        out.append((v, len(t.split(".")[1]) if "." in t else 0))
    return out


def all_numbers(text):
    return numbers_in(text, min_digits=1)


def tokens(text):
    return [w for w in GV.norm_text(text).split() if w]


SHORT_STOP = {"an", "of", "to", "in", "on", "as", "at", "is", "it", "be", "or", "by", "no", "if", "so", "do", "up", "we", "us", "my", "me", "he", "ok", "vs", "s"}
MULTIPLE_WORDS = {"multiple", "multiples", "ev", "x"}
ADJ_WORDS = {"adjusted", "adj"}


def content_words(text):
    """build 13.2.2: two-letter words count too ("PF" in "PF LTM"), except common short words"""
    return {w for w in tokens(text) if w not in STOP and w not in SHORT_STOP and (len(w) > 2 or w.isalpha()) and not re.fullmatch(r"w\d+|\d+", w)}


def negates_adjustment(text):
    low = text.lower()
    return bool(re.search(r"\bunadjusted\b|\bbefore (any |the |approved )*adjust", low))


def magnitude_ok(x, ref_, lo=0.01, hi=100.0):
    """a candidate for an EBITDA-type item must be on the scale of the related answer (a 13x multiple is not a $2m EBITDA)"""
    if ref_ is None or x is None:
        return True
    if ref_ == 0:
        return abs(x) < 1e9
    r = abs(x) / abs(ref_)
    return lo <= r <= hi


def row_label(cells, r, c):
    """the nearest text cell to the left on the same row"""
    for cc in range(c - 1, 0, -1):
        v = cells.get((r, cc), (None,))[0]
        if isinstance(v, str) and v.strip():
            return v
    return ""


def ref(wid, raw, cell):
    """a reference written with the workbook's EXACT sheet name (never a normalised spelling)"""
    return f"{wid}:'{raw}'!{cell}"


class Finder:
    """every proposal is reopened in the workbooks: (ref, confidence, reason). Nothing here reads an extraction."""

    def __init__(self, gold, books):
        self.gold, self.books, self.ans = gold, books or {}, gold.get("answers") or {}
        self.qe = str(gold.get("quarter_end") or "")[:7]

    # ---- workbook access ----
    def raw(self, wid, sheet):
        b = self.books.get(wid)
        if not b:
            return None
        name, _, problem = GV.resolve_gold_sheet(b, sheet)
        return None if problem else name

    def cell(self, wid, raw, a):
        b = self.books.get(wid)
        c = b.get(raw, a) if b and raw else None
        return c

    def kind(self, wid, raw, a):
        c = self.cell(wid, raw, a)
        if not c or (c[0] is None and not c[1]):
            return "blank", None
        v = num(c[0])
        return ("number", v) if v is not None else ("text", c[0])

    def gold_number(self, key):
        c = self.ans.get(key) or {}
        field = GV.NUMERIC.get(key)
        v = num(c.get(field)) if field else None
        if v is None and key == "valuation_metric":
            ev, mult = num((self.ans.get("enterprise_value") or {}).get("answer")), num((self.ans.get("applied_multiple") or {}).get("answer"))
            v = ev / mult if ev is not None and mult else None
        return v

    # ---- the key's own anchors, narrowed to one exact value cell ----
    def concept_cell(self, key):
        """-> (ref, confidence, reason) or (None, None, why not)"""
        pa = ((self.ans.get(key) or {}).get("primary_anchor") or {}).get("ref")
        p = parse_ref(pa) if pa else None
        if not p or not p[2]:
            return None, None, f"the key's {key.replace('_', ' ')} anchor is a whole sheet"
        if not self.books:
            return (pa, CANDIDATE, "the key's anchor (workbooks not supplied, so not reopened)") if GV.parse_cell(p[2]) else \
                   (None, None, "the key's anchor is a range; the workbooks are needed to find its value cell")
        raw = self.raw(p[0], p[1])
        if not raw:
            return None, None, f"sheet {p[1]!r} not found in {p[0]}"
        target = self.gold_number(key)
        if GV.parse_cell(p[2]):
            k, v = self.kind(p[0], raw, p[2])
            if k == "blank":
                return None, None, f"{ref(p[0], raw, p[2])} is blank: not proposed"
            if k == "text" and target is not None:
                return None, None, f"{ref(p[0], raw, p[2])} holds text, not the key's number: not proposed"
            return ref(p[0], raw, p[2]), VERIFIED, f"the key's {key.replace('_', ' ')} anchor, reopened" + (f" ({v:,.10g})" if v is not None else "")
        r1, c1, r2, c2 = GV.parse_range(p[2])
        nums = [(addr(r, c), v) for r in range(r1, r2 + 1) for c in range(c1, c2 + 1) for k, v in [self.kind(p[0], raw, addr(r, c))] if k == "number"]
        if target is not None:
            hit = [(a, v) for a, v in nums if GV.val_exact(v, target)]
            if len(hit) == 1:
                return ref(p[0], raw, hit[0][0]), VERIFIED, f"the one cell in the key's range {p[2]} holding the key's {key.replace('_', ' ')} ({hit[0][1]:,.10g})"
        if len(nums) == 1:
            return ref(p[0], raw, nums[0][0]), CANDIDATE, f"the only number in the key's range {p[2]}"
        return None, None, f"the key's range {p[2]} holds {len(nums)} numbers and none is confirmed as the answer"

    # ---- what the text names ----
    def workbooks_named(self, text):
        out = set(re.findall(r"\b(W\d+)\b", text))
        low = " " + " ".join(tokens(text)) + " "
        for wid, s in GV.source_files(self.gold).items():
            name = GV.canon_name(s["file"])
            toks = name.split()
            pairs = {f"{a} {b}" for a, b in zip(toks, toks[1:])}
            if any(f" {pr} " in low for pr in pairs if not any(t.isdigit() for t in pr.split())) or (toks and toks[0] == "fund" and " fund" in low):
                out.add(wid)
        return {w for w in out if w in self.books or not self.books}

    def sheets_named(self, text):
        out = []
        for m in re.finditer(r"(W\d+):'([^']+)'(?!!)", text):
            raw = self.raw(m.group(1), m.group(2))
            if raw:
                out.append((m.group(1), raw))
        seq = " " + " ".join(tokens(text)) + " "
        for wid, b in self.books.items():
            for sh in b.sheet_names():
                w = [x for x in tokens(sh) if x not in GENERIC_SHEET]
                phrase = " ".join(w)
                if w and f" {phrase} " in seq and (len(w) >= 2 or len(w[0]) >= 5) and (wid, sh) not in out:   # the sheet's words, as a phrase
                    out.append((wid, sh))
        return out

    def concepts_named(self, text):
        low = " " + text.lower() + " "
        return [k for k, ws in CONCEPT_WORDS.items() if any(w in low for w in ws)]

    def months_named(self, text):
        from verify import parse_period
        out = []
        low = text.lower()
        if self.qe and re.search(r"prior[\s-]*(period|quarter)|previous quarter|last quarter", low):
            out.append((self._shift(-3), "the prior period"))
        if self.qe and re.search(r"prior[\s-]*year|previous year|a year earlier|same quarter last year", low):
            out.append((self._shift(-12), "the prior year"))
        pats = [r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{1,2}(?:st|nd|rd|th)?,?\s+20\d{2}\b",
                r"\b\d{1,2}\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+20\d{2}\b",
                r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?[\s\-']+20\d{2}\b", r"\b20\d{2}-\d{2}(?:-\d{2})?\b", r"\bq[1-4]\s*20\d{2}\b"]
        for pt in pats:
            for m in re.finditer(pt, low):
                t = m.group()
                mm = re.match(r"(\d{1,2})\s+([a-z]+)\.?\s+(20\d{2})", t)
                pm = parse_period(f"{mm.group(2)} {mm.group(1)}, {mm.group(3)}" if mm else t)
                if pm and pm not in [x for x, _ in out]:
                    out.append((pm, f"the period {m.group()}"))
        return [(m_, w) for m_, w in out if m_ and m_ != self.qe]

    def _shift(self, n):
        y, m = int(self.qe[:4]), int(self.qe[5:7])
        t = y * 12 + m - 1 + n
        return f"{t // 12:04d}-{t % 12 + 1:02d}"

    # ---- searches (all reopened; all CANDIDATE unless the rule is exact) ----
    def period_cells(self, sheets, month, anchor_cells):
        """cells at (row of a key anchor on the sheet, column of the header that reads `month`). When several headers read that month
        (e.g. 'Cost as of Jun 30, 2026' and 'Valuation as of Jun 30, 2026'), build 13.2.2 keeps only the one whose wording, dates removed,
        matches the anchor column's own header ('Valuation as of Mar 31, 2026')."""
        from verify import parse_period
        out = []
        undated = lambda t: " ".join(w for w in tokens(re.sub(r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s*\d{0,2},?\s*(20\d{2})?|\b20\d{2}(-\d{2}){0,2}\b|\bq[1-4]\b", " ", str(t).lower()))
                                     if not w.isdigit())
        for wid, raw in sheets:
            own = [GV.parse_cell(p[2]) for p in (parse_ref(r) for r in anchor_cells) if p and p[0] == wid and skey(p[1]) == skey(raw) and GV.parse_cell(p[2])]
            if not own:
                continue
            rows, cols_own = sorted({r for r, _ in own}), {c for _, c in own}
            cs = self.books[wid].cells(raw)
            hdr = sorted({(r, c) for (r, c), cell in cs.items() if r < max(rows) and c not in cols_own and parse_period(cell[0]) == month})
            if not hdr:
                continue
            cols = sorted({c for _, c in hdr})
            how = "the one header reading"
            if len(cols) > 1:
                same = [c for c in cols if any(isinstance(cs.get((r, c), (None,))[0], str) and any(undated(cs.get((r, c), ("",))[0]) == undated(cs.get((r, oc), ("",))[0]) != ""
                                                                                                    for oc in cols_own) for r, cc in hdr if cc == c)]
                if len(same) == 1:
                    cols, how = same, "the one header reading"
            conf = VERIFIED if len(cols) == 1 else CANDIDATE
            for c in cols:
                for r in rows:
                    k, v = self.kind(wid, raw, addr(r, c))
                    if k == "number":
                        hdr_txt = next((cs[(rh, ch)][0] for rh, ch in hdr if ch == c and isinstance(cs[(rh, ch)][0], str)), None)
                        out.append((ref(wid, raw, addr(r, c)), conf, (f"row of a key anchor, under {how} {month}" + (f" worded like the anchor's own header ({hdr_txt!r})" if hdr_txt and len(hdr) > 1 else ""))
                                    if conf == VERIFIED else f"row of a key anchor, under one of {len(cols)} headers reading {month}"))
        return out

    def label_cells(self, sheets, text, near=None, related=None):
        """the row labels sharing the most words with the item (2 or more), each read in a TTM/LTM/total header column or at the number on
        its row nearest the related answer. Build 13.2.2: a label naming a multiple is skipped unless the item is about the multiple; an item
        about UNadjusted figures skips labels that say adjusted; a value off the related answer's scale is skipped; ties are broken by the
        value closest to the related answer."""
        want = content_words(text)
        neg = negates_adjustment(text)
        about_multiple = related == "applied_multiple"
        cands = []
        for wid, raw in sheets:
            cs = self.books[wid].cells(raw)
            for (r, c), cell in cs.items():
                if not isinstance(cell[0], str):
                    continue
                lw = content_words(cell[0])
                n = len(lw & want)
                if n < 2:
                    continue
                if not about_multiple and (lw & MULTIPLE_WORDS or re.search(r"/\s*\w|\bmultiple", cell[0].lower())):
                    continue
                if neg and lw & ADJ_WORDS:
                    continue
                tot = sorted({cc for (rr, cc), x in cs.items() if isinstance(x[0], str) and " ".join(tokens(x[0])) in TOTAL_HEADERS and rr < r})
                got = None
                for cc in tot:
                    k, v = self.kind(wid, raw, addr(r, cc))
                    if k == "number" and magnitude_ok(v, near):
                        got = (addr(r, cc), v, "the total column")
                        break
                if not got and near is not None:
                    row = [(cc, num(x[0])) for (rr, cc), x in sorted(cs.items()) if rr == r and num(x[0]) is not None]
                    row = [(cc, v) for cc, v in row if abs(v - near) <= max(1.0, 1e-4 * abs(near))]
                    if row:
                        cc, v = min(row, key=lambda t: abs(t[1] - near))
                        got = (addr(r, cc), v, "the number on that row nearest the related answer")
                if got:
                    cands.append((n, abs(got[1] - near) if near is not None else 0.0, wid, raw, got, cell[0]))
        if not cands:
            return []
        top = max(x[0] for x in cands)
        best = [x for x in cands if x[0] == top]
        if near is not None and len(best) > 1:
            d = min(x[1] for x in best)
            best = [x for x in best if x[1] == d]
        return [(ref(wid, raw, got[0]), CANDIDATE, f"label {label!r} matches the item's words; {got[2]} ({got[1]:,.10g})") for _, _, wid, raw, got, label in best]

    def other_side(self, text, v, exclude_wid, sheets):
        """the other value of a comparison, on the sheets the text names (else every sheet of the workbooks it names, other than side one's).
        A cell equal to side one, or off its scale (the stated difference itself, a multiple), is never a side. Ranked: differs by the difference
        the text states; then its row label shares most words with the item; then closest to side one. Returns the unique best, or every tie."""
        if v is None:
            return []
        diffs = [d for d, _ in all_numbers(text) if 0 < abs(d) < 0.01 * max(1.0, abs(v))]
        pool = [s_ for s_ in sheets if s_[0] != exclude_wid] or [(w, sh) for w in self.workbooks_named(text) if w != exclude_wid for sh in self.books[w].sheet_names()]
        want = content_words(text)
        cands = []
        for wid, raw in pool:
            cs = self.books[wid].cells(raw)
            for (r, c), cell in sorted(cs.items()):
                x = num(cell[0])
                if x is None or x == v or not magnitude_ok(x, v, 0.5, 2.0):
                    continue
                exact = any(abs(abs(x - v) - abs(d)) <= 5e-5 * max(1.0, abs(d)) + 1e-9 for d in diffs)
                if diffs and not exact:
                    continue
                if not diffs and abs(x - v) > max(1.0, 1e-5 * abs(v)):
                    continue
                lab = row_label(cs, r, c)
                cands.append((1 if exact else 0, len(content_words(lab) & want), -abs(x - v), wid, raw, addr(r, c), x, lab))
        if not cands:
            return []
        keys = {(t[3], skey(t[4]), t[5]) for t in cands}
        by_name = {GV.norm_file(b.file): w for w, b in self.books.items()}

        def copy_of_other(t):                                     # a pure formula copy of another candidate is the same value: keep the original
            b = self.books[t[3]]
            f = (b.get(t[4], t[5]) or (None, None))[1]
            ct = GV.copy_target(f, t[4], b) if f else None
            if not ct:
                return False
            ext, sh, cell = ct
            w = t[3] if ext is None else by_name.get(GV.norm_file(b.ext_file(ext) or ""))
            return (w, skey(b.resolve_sheet(sh) or sh), cell) in keys if w else False
        cands = [t for t in cands if not copy_of_other(t)] or cands
        cands.sort(reverse=True, key=lambda t: t[:3])
        best = [t for t in cands if t[:3] == cands[0][:3]]
        why = lambda t: ("differs from side one by the difference written in the text" if t[0] else "close to side one's value") + (f"; row label {t[7]!r}" if t[7] else "")
        return [(ref(t[3], t[4], t[5]), CANDIDATE, f"{why(t)} ({t[6]:,.10g})") for t in best][:3]

    def numbers(self, text, wids):
        out, notes = [], []
        for v, dec in numbers_in(text):
            hits = []
            for wid in sorted(wids or self.books):
                b = self.books.get(wid)
                for sh in (b.sheet_names() if b else []):
                    for (r, c), cell in b.cells(sh).items():
                        x = num(cell[0])
                        if x is not None and abs(round(x, dec) - v) <= 10 ** -(dec + 6) * max(1.0, abs(v)):
                            hits.append(ref(wid, sh, addr(r, c)))
            if 0 < len(hits) <= 4:
                for h in hits:
                    out.append((h, CANDIDATE, f"holds {v:,.10g}, a number written in the text" + (f" ({len(hits)} cells hold it)" if len(hits) > 1 else "")))
            elif len(hits) > 4:
                notes.append(f"{len(hits)} cells hold {v:,.10g}: too many to suggest")
        return out, notes

    def explicit(self, text):
        out, notes = [], []
        for m in re.finditer(r"(W\d+):('[^']+'|[^!\s']+)!\$?([A-Za-z]{1,3})\$?(\d+)", text):
            wid, sh, a = m.group(1), m.group(2).strip("'"), (m.group(3) + m.group(4)).upper()
            out += self._explicit_one(wid, sh, a, notes)
        named = {skey(sh): [(w, s_) for w, s_ in [(w, s_) for w, b in self.books.items() for s_ in b.sheet_names()] if skey(s_) == skey(sh)]
                 for w, b in self.books.items() for sh in b.sheet_names()}
        for shk, a in sorted(refs_in_text(re.sub(r"W\d+:('[^']+'|[^!\s']+)!\$?[A-Za-z]{1,3}\$?\d+", " ", text), set(named))):
            places = named[shk]
            for wid, raw in places:
                for x in self._explicit_one(wid, raw, a, notes):
                    out.append((x[0], x[1] if len(places) == 1 else CANDIDATE, x[2] + ("" if len(places) == 1 else " (this sheet name is in more than one workbook)")))
        return out, notes

    def _explicit_one(self, wid, sh, a, notes):
        if not self.books:
            return [(ref(wid, sh, a), CANDIDATE, "written in the item's text (workbooks not supplied, so not reopened)")]
        raw = self.raw(wid, sh)
        if not raw:
            notes.append(f"{wid}:'{sh}'!{a} is written in the text but that sheet is not in {wid}")
            return []
        k, v = self.kind(wid, raw, a)
        if k == "blank":
            notes.append(f"{ref(wid, raw, a)} is written in the text but is blank: not proposed")
            return []
        if k == "text":
            notes.append(f"{ref(wid, raw, a)} is written in the text but holds text, not a number: not proposed")
            return []
        return [(ref(wid, raw, a), VERIFIED, "written in the item's text, reopened" + (f" ({v:,.10g})" if v is not None else ""))]


def keyword_candidates(text):
    words, seen = [], set()
    for w in re.findall(r"[A-Za-z][A-Za-z\-']{3,}", text):
        lw = w.lower().strip("'")
        if lw in STOP or lw in seen or re.fullmatch(r"w\d+", lw):
            continue
        seen.add(lw)
        words.append(lw)
    return words[:2]


def proposals(gold, books):
    """-> list of rows {section, item, where, add, suggested, why, confidence}"""
    F = Finder(gold, books)
    answers = gold.get("answers") or {}
    concept = {k: F.concept_cell(k) for k in CONCEPT_WORDS}
    anchor_cells = [x[0] for x in concept.values() if x[0]]
    rows = []
    for key, label, title, pre, fields in SECTIONS:
        for i, it in enumerate(gold.get(key) or []):
            if not isinstance(it, dict):
                continue
            text = " ".join(str(it.get(f)) for f in fields if it.get(f))
            where, short = f"{key}[{i}]", text[:200]
            first = str(it.get(fields[0]) or "")
            if not iid(it):
                rows.append({"section": title, "item": short, "where": where, "add": "id", "suggested": f"{pre}{i + 1}", "why": "next number in this list",
                             "confidence": "new label"})
            cells_row = None
            if not it.get("cells"):
                found, notes = F.explicit(text)
                named = F.concepts_named(text if key != "known_rivals" else "")
                for k in named:
                    r_, conf, why = concept[k]
                    if r_:
                        found.append((r_, conf, why))
                    else:
                        notes.append(why)
                sheets = F.sheets_named(text)
                wids = F.workbooks_named(text)
                if books and key == "known_rivals":
                    related = F.concepts_named(text) or ["valuation_metric"]
                    rel_cells = [concept[k][0] for k in related if concept[k][0]]
                    for m_, mwhy in F.months_named(text):
                        scope = sheets or [(parse_ref(r)[0], parse_ref(r)[1]) for r in rel_cells + anchor_cells if parse_ref(r) and (not wids or parse_ref(r)[0] in wids)]
                        found += [(x, c, f"{w}; {mwhy}") for x, c, w in F.period_cells(list(dict.fromkeys(scope)), m_, anchor_cells)]
                    if not any(c == VERIFIED for _, c, _ in found):
                        wide = [(w, sh) for w in (wids or {parse_ref(r)[0] for r in rel_cells if parse_ref(r)}) for sh in books[w].sheet_names()]
                        near = F.gold_number(related[0]) if related else None
                        lab = F.label_cells(sheets, text, near, related[0]) if sheets else []
                        found += lab
                        if not any(c == VERIFIED for _, c, _ in found) and not lab:
                            found += F.label_cells(wide, text, near, related[0])
                is_cmp = key == "material_discrepancies" or (key == "human_judgments" and bool(COMPARE.search(text)))   # a rival is never a comparison
                if books and is_cmp:
                    sides = {parse_ref(x)[0] for x, _, _ in found if parse_ref(x)}
                    if len(found) < 2:
                        v1 = None
                        if found:
                            p = parse_ref(found[0][0])
                            k1, v1 = F.kind(p[0], p[1], p[2])
                        other = F.other_side(text, v1, next(iter(sides)) if sides else None, sheets) if found else []
                        if len(other) == 1:
                            found += other
                        elif len(other) > 1:
                            notes.append("possible other sides (keep one): " + "; ".join(f"{x} ({w})" for x, _, w in other))
                if books:
                    nums, nnotes = F.numbers(text, wids)
                    have = {x for x, _, _ in found}
                    if is_cmp and found:                         # a side must be on side one's scale: never the stated difference itself
                        p1 = parse_ref(found[0][0])
                        v1 = F.kind(p1[0], p1[1], p1[2])[1] if p1 else None
                        nums_side = [n for n in nums if (lambda p: p and magnitude_ok(F.kind(p[0], p[1], p[2])[1], v1, 0.5, 2.0))(parse_ref(n[0]))]
                    else:
                        nums_side = nums
                    if not is_cmp or len(found) < 2:
                        found += [n for n in nums_side if n[0] not in have and not (key == "known_rivals" and n[0] in anchor_cells)][: (2 - len(found)) if is_cmp else 4]
                    used = {x for x, _, _ in found}
                    if is_cmp:
                        notes += [f"found by value: {x} = {w} ({'proposed' if x in used else 'not proposed: one cell per side' if n_ in nums_side else 'not proposed: not on the scale of side one'})"
                                  for n_ in nums for x, _, w in [n_]]
                    notes += nnotes
                seen, uniq = set(), []
                for x in found:
                    if x[0] not in seen and not (key == "known_rivals" and x[0] in anchor_cells):
                        seen.add(x[0])
                        uniq.append(x)
                if is_cmp and len(uniq) == 1:
                    notes.append("other side missing: a comparison needs both cells - type the second one, or Reject")
                conf = "none" if not uniq else ("verified" if all(c == VERIFIED for _, c, _ in uniq) else "candidate")
                rconf = ROW_CONF[conf] + ("; one side only" if is_cmp and len(uniq) == 1 else "")
                why = "; ".join(f"{x} = {w} [{c}]" for x, c, w in uniq)
                if notes:
                    why = (why + "; " if why else "") + "; ".join(dict.fromkeys(notes))
                if not uniq:
                    why = (why + "; " if why else "") + "nothing reliable found in the key or the workbooks - type the cells (e.g. the rival's cell, or both values compared), or Reject"
                cells_row = {"section": title, "item": short, "where": where, "add": "cells", "suggested": "; ".join(x for x, _, _ in uniq), "why": why, "confidence": rconf}
                rows.append(cells_row)
            if not it.get("keywords"):
                verified = (cells_row and cells_row["confidence"] == ROW_CONF["verified"]) or (it.get("cells") and not cells_row)
                if verified:
                    rows.append({"section": title, "item": short, "where": where, "add": "keywords", "suggested": "",
                                 "why": "not offered: the cells are verified (keywords are a last-resort fallback that can reject a correct but differently worded answer)",
                                 "confidence": "not needed"})
                else:
                    kw = keyword_candidates(text)
                    rows.append({"section": title, "item": short, "where": where, "add": "keywords", "suggested": "; ".join(kw),
                                 "why": "fallback only, because no verified cell was found: every keyword must appear in the extraction's wording; write a|b to accept either",
                                 "confidence": "fallback - review" if kw else "no reliable candidate"})
    if books:
        for k, c in answers.items():
            if not isinstance(c, dict):
                continue
            for j, a in enumerate(c.get("supporting_anchors") or []):
                if not isinstance(a, dict) or a.get("support") or not a.get("ref"):
                    continue
                v = GV._cell_of(books, a["ref"])
                val = num(v[0].value(v[1], v[2])) if v and GV.parse_cell(v[2]) else None
                if val is None:
                    continue
                part = next((p for p in ("cash", "debt") if num(c.get(p)) is not None and GV.val_exact(val, c[p])), None)
                field = GV.NUMERIC.get(k)
                g = num(c.get(field)) if field else None
                if part:
                    rows.append({"section": "Answer anchor", "item": f"{k}: {a['ref']}", "where": f"answers.{k}.supporting_anchors[{j}]",
                                 "add": "support", "suggested": f"component ({part})", "why": f"the cell holds {val:g}, which is the key's {part}: a part of the answer",
                                 "confidence": ROW_CONF["verified"]})
                elif g is not None and not (GV.val_exact(val, g) or GV.is_rounded(val, g) or GV.is_scaled(val, g)):
                    rows.append({"section": "Answer anchor", "item": f"{k}: {a['ref']}", "where": f"answers.{k}.supporting_anchors[{j}]",
                                 "add": "support", "suggested": "context", "why": f"the cell holds {val:g}, not the answer or a rounding or scaling of it",
                                 "confidence": ROW_CONF["candidate"]})
    return rows


# ---------------- the review sheet ----------------
def write_review(path, gold, rows, key_sha):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation
    wb = Workbook()
    ws = wb.active
    ws.title = "Review"
    f = Font(name="Arial", size=10)
    bold = Font(name="Arial", size=10, bold=True)
    fill = PatternFill("solid", fgColor="FFF2CC")
    ws["A1"], ws["A1"].font = f"Answer-key metadata review - {gold.get('case_id')}", Font(name="Arial", size=12, bold=True)
    ws["A2"], ws["C2"] = "Reviewed by", "Date"
    ws["A2"].font = ws["C2"].font = bold
    ws["B2"].fill = ws["D2"].fill = fill
    heads = ["#", "Section", "Item", "Add", "Suggested", "Why suggested", "Action", "Your correction", "Comment", "Confidence"]
    shade = {"verified": PatternFill("solid", fgColor="D9EAD3"), "candidate": PatternFill("solid", fgColor="FCE5CD"),
             "fallback": PatternFill("solid", fgColor="FCE5CD"), "no reliable": PatternFill("solid", fgColor="EAD1DC")}
    for i, h in enumerate(heads, 1):
        c = ws.cell(row=4, column=i, value=h)
        c.font = bold
    for n, r in enumerate(rows, 1):
        vals = [n, r["section"], r["item"], r["add"], r["suggested"], r["why"], None, None, None, r.get("confidence")]
        for i, v in enumerate(vals, 1):
            c = ws.cell(row=4 + n, column=i, value=v)
            c.font = f
            c.alignment = Alignment(wrap_text=True, vertical="top")
        for col in (7, 8, 9):
            ws.cell(row=4 + n, column=col).fill = fill
        tone = next((v for k, v in shade.items() if str(r.get("confidence") or "").startswith(k)), None)
        if tone:
            ws.cell(row=4 + n, column=5).fill = ws.cell(row=4 + n, column=10).fill = tone
    dv = DataValidation(type="list", formula1='"Approve,Correct,Reject"', allow_blank=True)
    ws.add_data_validation(dv)
    if rows:
        dv.add(f"G5:G{4 + len(rows)}")
    for col, w in zip("ABCDEFGHIJ", (5, 18, 50, 10, 45, 55, 11, 35, 30, 24)):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A5"
    lg = wb.create_sheet("Legend")
    legend = [("Legend", ""), ("Answer key", "The analyst's answers, written before any agent run. Test bench only."),
              ("Item", "A known rival (a look-alike number), a discrepancy, or an unresolved decision in the key."),
              ("Add: id", "A stable label such as R1, MD1, HJ1."),
              ("Add: cells", "Workbook cells the item is about, separated by '; ', written as W1:'Sheet Name'!A1."),
              ("Add: keywords", "Words that must all appear in the extraction's wording, separated by '; '. Write a|b to accept either word. A fallback only."),
              ("Add: support", "component (cash) or component (debt) = a part of the answer; context = background only."),
              ("Approve", "Write the Suggested value into the new key."), ("Correct", "Write Your correction instead (required for this choice)."),
              ("Reject", "Write nothing for this row."),
              ("Confidence: verified exact cell", "Reopened in the workbook and found by an exact rule (written in the text, the key's own anchor, or a key anchor's row under the one matching period header). Green."),
              ("Confidence: candidate - review", "Found by value or label only, or by an ambiguous rule. Check it before approving. Orange."),
              ("Confidence: one side only", "A comparison with only one cell found: type the other cell, or Reject."),
              ("Confidence: no reliable candidate", "Nothing trustworthy found: type the cells, or Reject. Pink."),
              ("Keywords", "Offered only when no verified cell exists: a last-resort fallback."), ("Blank", "Not decided: nothing is written; the row is listed when the review is applied."),
              ("Safety", "Suggestions come only from the key and the frozen workbooks, never from an agent's output. Nothing changes until the "
                         "review is applied, and applying writes a new key file; the original is never overwritten.")]
    for i, (a, b) in enumerate(legend, 1):
        lg.cell(row=i, column=1, value=a).font = bold
        lg.cell(row=i, column=2, value=b).font = f
        lg.cell(row=i, column=2).alignment = Alignment(wrap_text=True)
    lg.column_dimensions["A"].width, lg.column_dimensions["B"].width = 32, 100
    ln = wb.create_sheet("_link")
    ln["A1"], ln["B1"] = "key_sha256", key_sha
    for n, r in enumerate(rows, 1):
        ln.cell(row=1 + n, column=1, value=n)
        ln.cell(row=1 + n, column=2, value=r["where"])
        ln.cell(row=1 + n, column=3, value=r["add"])
    ln.sheet_state = "hidden"
    wb.save(path)


def read_review(path):
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True)
    ws, ln = wb["Review"], wb["_link"]
    links = {ln.cell(row=r, column=1).value: (ln.cell(row=r, column=2).value, ln.cell(row=r, column=3).value) for r in range(2, ln.max_row + 1)}
    rows = []
    for r in range(5, ws.max_row + 1):
        n = ws.cell(row=r, column=1).value
        if n is None:
            continue
        rows.append({"n": n, "item": ws.cell(row=r, column=3).value, "add": ws.cell(row=r, column=4).value, "suggested": ws.cell(row=r, column=5).value,
                     "action": (str(ws.cell(row=r, column=7).value or "").strip().capitalize() or None), "correction": ws.cell(row=r, column=8).value,
                     "comment": ws.cell(row=r, column=9).value, "where": links.get(n, (None, None))[0]})
    meta = {"reviewed_by": ws["B2"].value, "date": ws["D2"].value, "key_sha256": ln["B1"].value}
    if isinstance(meta["date"], (datetime.date, datetime.datetime)):
        meta["date"] = meta["date"].isoformat()[:10]
    return rows, meta


def locate(gold, where):
    m = re.fullmatch(r"(known_rivals|material_discrepancies|human_judgments)\[(\d+)\]", where or "")
    if m:
        xs = gold.get(m.group(1)) or []
        return xs[int(m.group(2))] if int(m.group(2)) < len(xs) else None
    m = re.fullmatch(r"answers\.(\w+)\.supporting_anchors\[(\d+)\]", where or "")
    if m:
        xs = ((gold.get("answers") or {}).get(m.group(1)) or {}).get("supporting_anchors") or []
        return xs[int(m.group(2))] if int(m.group(2)) < len(xs) else None
    return None


def apply_review(gold_path, review_path, out_path, workbooks=None):
    if os.path.exists(out_path) or os.path.abspath(out_path) == os.path.abspath(gold_path):
        print(f"REFUSED: {out_path} already exists (or is the key itself); --apply always writes a NEW key file")
        return 2
    gold = GV.read_json(gold_path)
    rows, meta = read_review(review_path)
    if meta["key_sha256"] != sha_file(gold_path):
        print("REFUSED: this review sheet was made for another version of the key (fingerprint differs); run gold_suggest.py again")
        return 2
    new = json.loads(json.dumps(gold))
    applied, skipped, problems = [], [], []
    for r in rows:
        if r["action"] not in ACTIONS:
            skipped.append(f"#{r['n']} {r['add']}: not decided")
            continue
        if r["action"] == "Reject":
            skipped.append(f"#{r['n']} {r['add']}: rejected")
            continue
        value = r["suggested"] if r["action"] == "Approve" else r["correction"]
        if value in (None, ""):
            problems.append(f"#{r['n']} {r['add']}: {'Correct needs a value in Your correction' if r['action'] == 'Correct' else 'nothing was suggested; use Correct'}")
            continue
        target = locate(new, r["where"])
        if target is None:
            problems.append(f"#{r['n']}: the item it refers to is not in this key")
            continue
        value = str(value).strip()
        if r["add"] == "id":
            if iid(target):
                problems.append(f"#{r['n']} id: the item already has id {iid(target)!r}; left unchanged")
                continue
            target["id"] = value
        elif r["add"] == "cells":
            refs = [x.strip() for x in value.split(";") if x.strip()]
            bad = [x for x in refs if not parse_ref(x)]
            if bad:
                problems.append(f"#{r['n']} cells: not W<n>:'Sheet'!Cell: {bad}")
                continue
            target["cells"] = refs
        elif r["add"] == "keywords":
            target["keywords"] = [x.strip() for x in value.split(";") if x.strip()]
        elif r["add"] == "support":
            m = re.fullmatch(r"component\s*\((cash|debt)\)|(component|context)", value.lower())
            if not m:
                problems.append(f"#{r['n']} support: write component (cash), component (debt), component or context")
                continue
            target["support"] = "component" if (m.group(1) or m.group(2) == "component") else "context"
            if m.group(1):
                target["component"] = m.group(1)
        else:
            problems.append(f"#{r['n']}: unknown kind {r['add']!r}")
            continue
        applied.append({"row": r["n"], "where": r["where"], "add": r["add"], "value": value, "action": r["action"].upper(),
                        **({"comment": r["comment"]} if r["comment"] else {})})
    new["metadata_review"] = {"from_key_sha256": meta["key_sha256"], "review_file": os.path.basename(review_path),
                              "reviewed_by": meta["reviewed_by"] or "not stated", "date": meta["date"] or "not stated", "applied": applied,
                              "note": "matching metadata for the test bench only; never company memory"}
    json.dump(new, open(out_path, "w"), indent=1)
    v = GV.validate(new, workbooks)
    print(f"APPLIED: {len(applied)} approved or corrected | {len(skipped)} rejected or not decided | {len(problems)} problems | new key {os.path.basename(out_path)}"
          f" | the original key is unchanged")
    for x in problems:
        print(f"- PROBLEM: {x}")
    for x in skipped:
        print(f"- SKIPPED: {x}")
    print(f"NEW KEY: {'VALID' if not v['errors'] else 'INVALID'} ({len(v['errors'])} errors, {len(v['warnings'])} warnings)")
    for e in v["errors"]:
        print(f"- ERROR: {e}")
    return 0 if not v["errors"] and not problems else 1


def main(argv=None):
    raw = list(sys.argv[1:] if argv is None else argv)
    if any(x in ("--extraction", "--verification", "--review-output") for x in raw):
        print("REFUSED: gold_suggest proposes metadata from the Gold key and the frozen workbooks only; it never reads extraction or run output")
        return 2
    ap = argparse.ArgumentParser(description="propose the matching metadata a Gold key needs; apply an approved review")
    ap.add_argument("--gold", required=True)
    ap.add_argument("--workbooks", nargs="*")
    ap.add_argument("--out")
    ap.add_argument("--review", help="write the Approve / Correct / Reject review sheet (.xlsx)")
    ap.add_argument("--apply", help="a filled-in review sheet; writes the approved metadata into the NEW key named by --out")
    a = ap.parse_args(raw)
    for pth in [a.gold] + list(a.workbooks or []):
        if refuse_run_output(pth):
            print(f"REFUSED: {os.path.basename(pth)} looks like extraction or run output; Gold metadata is never derived from it")
            return 2
    if a.apply:
        if not a.out:
            print("REFUSED: --apply needs --out NEW_KEY.json (the original key is never overwritten)")
            return 2
        return apply_review(a.gold, a.apply, a.out, a.workbooks)
    gold = GV.read_json(a.gold)
    if not isinstance(gold, dict) or gold.get("schema") != GV.SCHEMA:
        print(f"REFUSED: {os.path.basename(a.gold)} is not a {GV.SCHEMA} key")
        return 2
    books = {}
    if a.workbooks:
        books, _, _ = GV.load_workbooks(a.workbooks, GV.source_files(gold), tempfile.mkdtemp(prefix="gold_sg_"))
    rows = proposals(gold, books)
    need = sorted({r["where"] for r in rows if r["add"] != "support"})
    if not rows:
        print("MATCHING METADATA NEEDED: none (every rival, discrepancy and unresolved decision has an id, cells and keywords)")
    else:
        print(f"MATCHING METADATA NEEDED: {len(need)} item(s), {len(rows)} proposal(s). Nothing is changed; approve them in the review sheet "
              f"(matching order: id, cells, keywords; items with none of them score UNSCORED).")
        labels = {k: lab for k, lab, *_ in SECTIONS}
        for where in need:
            k, i = re.fullmatch(r"(\w+)\[(\d+)\]", where).groups()
            mine = {r["add"]: r for r in rows if r["where"] == where}
            first = next(iter(mine.values()))
            print(f"- {labels[k]} #{int(i) + 1} (missing: {', '.join(x for x in ('id', 'cells', 'keywords') if x in mine)}): {first['item'][:140]}")
            if "id" in mine:
                print(f"    id: \"{mine['id']['suggested']}\"")
            if "cells" in mine:
                c = mine["cells"]
                print(f"    cells found [{c['confidence']}]: " + (f"{c['suggested']} ({c['why']})" if c["suggested"] else c["why"]))
            if "keywords" in mine:
                kwr = mine["keywords"]
                print("    keywords: your decision (a fallback only) - " + (f"candidates from its own text: {kwr['suggested']}" if kwr["suggested"] else kwr["why"]))
        for r in rows:
            if r["add"] == "support":
                print(f"- answer anchor {r['item']}: support {r['suggested']} ({r['why']})")
    anchors_on_file = [(k, (c.get("primary_anchor") or {}).get("ref"), (c.get("primary_anchor") or {}).get("shows"))
                       for k, c in (gold.get("answers") or {}).items() if isinstance(c, dict) and (c.get("primary_anchor") or {}).get("ref")]
    print("ANCHORS ALREADY IN THIS KEY (candidates to reuse in `cells`; listed as written, not matched to any item):")
    for k, ref, shows in anchors_on_file:
        print(f"    {k}: {ref}" + (f"  - {shows}" if shows else ""))
    if a.review:
        write_review(a.review, gold, rows, sha_file(a.gold))
        print(f"REVIEW SHEET: {os.path.basename(a.review)} ({len(rows)} rows: Approve / Correct / Reject; then run --apply)")
    if a.out:
        json.dump(rows, open(a.out, "w"), indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
