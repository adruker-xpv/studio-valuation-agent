---
name: xpv-onboarding-testbench
description: Test bench for XPV onboarding (build 13.2.2) - runs the onboarding test suite, scores an extraction or a blind review against a synthetic trial key or an analyst's blind answers, validates and scores against a gold-mvp/3 Gold key (Gold mode), holds the synthetic trial workbooks (including the five-workbook set T1) and regenerates them. Use for "run the onboarding tests", "score ...", "validate the Gold key", "Gold-score ...", "list the trial workbooks", "rebuild trial set T1". For a separate test agent only - never attach it to the extractor or reviewer agents, because it contains answer keys and reference answers.
---

# Onboarding test bench (build 13.2.2)

## Legend
Trial workbook = a made-up company and fund workbook in `trial/workbook-NN`; trial set T1 = five made-up workbooks in `trial/set-T1`
(management accounts with an inflated used range, a TTM pro forma, an XPV monthly summary, a company valuation that links to an
unsupplied "v3" file, and a fund summary that reports a different value); key = its answer key in `trial/keys/`; reference = a
hand-checked answer in `trial/reference/` used only by the tests; analyst answers = `templates/analyst_answers_template.xlsx`, filled in
by an analyst from a real workbook before seeing any agent output; TTM = trailing twelve months; unresolved decision = a question the workbooks cannot settle (the key's `human_judgments` list);
review sheet = the Excel file where a person approves, corrects or rejects proposed key metadata; checking code = scripts that re-open the
workbooks and confirm a claim.

## What the user says, and what you run
| The user says | Run |
|---|---|
| "Run the onboarding tests" | `python scripts/test_onboarding.py` - expected last line `TESTS: PASS (N/N)` (353/353 in this build) |
| "List the trial workbooks" | list `trial/workbook-*` and `trial/set-T1` with the company named in each; never open `trial/keys/` or `trial/reference/` |
| "Score <file> for trial workbook NN" (an extraction.json or reviewer_blind.json the user uploads) | `python scripts/score.py --key trial/keys/key-NN.json --extraction "<file>"` (add `--verification "<verification.json>"` if given) |
| "Score <file> for trial set T1" | `python scripts/score.py --key trial/keys/key-T1.json --extraction "<file>"` |
| "Score <file> against the analyst's answers <answers.xlsx>" | `python scripts/score.py --key "<answers.xlsx>" --extraction "<file>"` |
| "Rebuild trial set T1" | `python scripts/make_fixture_set.py --out trial/set-T1` (byte-for-byte identical; the tests depend on it) |
| "Give me the analyst answer form" | offer `templates/analyst_answers_template.xlsx` |
| "Validate the Gold key <gold.json>" (add "with the workbooks" when the frozen .xlsx files are attached) | `python scripts/gold_validate.py --gold "<gold.json>" [--workbooks <the .xlsx files>]` |
| "Gold-score <extraction.json> against <gold.json>" (add the workbooks if attached; add `--verification "<verification.json>"` if given) | `python scripts/gold_validate.py ...` first, then `python scripts/gold_score.py [--sources source_manifest.json] [--allow-different-binary] --gold "<gold.json>" --extraction "<file>" [--workbooks <the .xlsx files>] [--verification "<verification.json>"] --out gold_report.json`; post both outputs |
| "Run the Gold gates" / "Run the real Gold benchmark" | `python scripts/gold_run.py --gold "<gold.json>" --workbooks <the .xlsx files> --extraction "<extraction.json>" [--verification "<verification.json>"] [--require-metadata] --fixture-tests [--out gold_report.json]`; it ends with a SUMMARY of four separate results (fixture tests, Gold-key readiness, verified anchor coverage, extraction score): post it unchanged and never merge them: gate 1 gold_suggest, gate 2 enrichment (human), gates 3-4 gold_sources, gate 5 gold_validate, gates 6-7 gold_score; stops at the first failed gate and scores only a valid key |
| "Freeze the benchmark's source identities" / "Do the extraction's hashes match these workbooks?" | `python scripts/gold_sources.py --gold "<gold.json>" --workbooks <the .xlsx files> [--extraction "<extraction.json>"] [--out source_manifest.json]` (fingerprints come only from the supplied files) |
| "What matching metadata does the Gold key need?" / "Make the key review sheet" | `python scripts/gold_suggest.py --gold "<gold.json>" --workbooks <the .xlsx files> --review key_review.xlsx` (read-only; offer the sheet). Never pass an extraction or any run output: the script refuses it |
| "Apply the key review <review.xlsx>" (the person has filled in Action) | `python scripts/gold_suggest.py --gold "<gold.json>" --apply "<review.xlsx>" --out "<new key name>.json" [--workbooks <the .xlsx files>]`; offer the new key. Never fill in or change the Action column yourself |
| "Run Gold mode on the synthetic case G2" | `python scripts/gold_score.py --gold trial/keys/gold-G2.json --extraction trial/reference/G2/extraction.json --workbooks trial/set-G2/*.xlsx` (expect `Core semantic answers: 10/10`, `Period proven by checking code on another range: 1`, `Found by the extraction, not in the key: 1 confirmed by checking code / 1 not verified`) |
| "Run Gold mode on the synthetic case G1" | `python scripts/gold_score.py --gold trial/keys/gold-G1.json --extraction trial/reference/G1/extraction-flawed.json --workbooks trial/set-G1/*.xlsx` (expect `Core semantic answers: 9/10`, `False material claims: 1`, `Material Gold items omitted: 1`) |
| "Show the key-review suggestions for the synthetic case G3" | `python scripts/gold_suggest.py --gold trial/keys/gold-G3.json --workbooks trial/set-G3/*.xlsx` (a free-text key that reproduces the real-key suggestion failures) |
| "Rebuild the Gold fixtures G1 to G4" | `python scripts/make_gold_fixture.py --out trial` (byte-for-byte identical; the tests depend on it) |
| "Give me the Gold key form" | offer `templates/gold-mvp-3.template.json` (refused by the validator until every placeholder is replaced and certification is YES) |

Post the printed lines unchanged. Never show a key's, a Gold key's or a reference's contents (the printed score lines are not the key). Trial workbooks 52 and 94 and trial set T1 are the ones
for agent trials; the others have references used by the tests.

## Gold mode (gold-mvp/3)
**What it measures.** GOLD ACCURACY: did the extraction discover and interpret the material truth an analyst wrote down? It is separate from
WORKBOOK VERIFICATION (are its checkable claims supported by the workbooks?). Both are printed; they are never merged, and the verifier's status
changes no Gold count. The legacy `score.py` (nine fixed items) is untouched.

**Rules.** Native (the key is never translated to the older key format). Deterministic: no LLM judge, no free-text similarity. A Gold key that
fails `gold_validate.py` (schema, certification YES, no FILL_IN or `<...>` placeholders, source ids and references well formed, fields typed, with the workbooks: source
identity, anchor cells, numbers) is never scored.

**Legend.** Concept = one entry under `answers`. Anchor = the workbook location that represents a concept: `primary_anchor` (best), `supporting_anchors`
(Gold-authorized equivalent representations; not extra answers). Whole-sheet anchor = `W1:'Cap Table'` with no cell. Pure copy = a formula that only
copies one cell: `=A1`, `=A1*0.001`, `=A1/1000`, `=-A1`, `=ROUND(A1,0)`; never a sum, product of two cells or any other function.

| Section | Statuses |
|---|---|
| Core concepts | CORRECT, WRONG, OMITTED (the schema could say it, the extraction did not), NOT_EXPRESSIBLE_IN_SCHEMA (the schema has no slot: reported so the schema can change; never counted as an omission), NEEDS_ANALYST (cannot be decided deterministically) |
| Anchor of a concept | EXACT_ANCHOR (Gold's primary), GOLD_EQUIVALENT_ANCHOR (Gold lists it as supporting), VERIFIED_LINKED_EQUIVALENT (a chain of pure copies from a Gold cell anchor, found in the supplied workbooks), WRONG_ANCHOR, MISSING; UNVERIFIED when a link check was needed and no workbooks were supplied (the concept is then NEEDS_ANALYST, never wrong); N/A when the extraction has no anchor for the concept (method, relationship) |
| Known rivals | CORRECTLY_REJECTED, SELECTED_RIVAL (used as an answer), NOT_ADDRESSED (neither used nor rejected: did not distinguish it), NEEDS_ANALYST, UNSCORED |
| Material discrepancies | FOUND, MISINTERPRETED (Gold REAL but treated as nil/immaterial; Gold UNRESOLVED but called explained), OMITTED, NEEDS_ANALYST, UNSCORED |
| Human judgments (UNRESOLVED) | PRESERVED_UNRESOLVED (raised as an open question), UNSUPPORTED_CONCLUSION (closed as an "explained" discrepancy), OMITTED, NEEDS_ANALYST, UNSCORED |

**How a cell concept is decided.** By the extraction's anchor, never by a number: a typed copy with the same value as a Gold anchor is WRONG_ANCHOR
(numeric equality is not a link). Labels and months are compared as values: the method is normalised ("EV/EBITDA" = "EV/EBITDA multiple" = "EV to
EBITDA" = "EBITDA multiple"; different methods are WRONG; ones that cannot be normalised are NEEDS_ANALYST); the TTM window as months (its anchor is
reported beside it); the waterfall by the sheet Gold names; the company-to-fund relationship from the extraction's discrepancies (DIFFERENT) and
checkable edges (MATCH). Build 13.1: when Gold's relationship is MATCH with `relationship_basis` ROUNDING (below), a checkable edge between the
company and fund values (e.g. `rounded_match`) is CORRECT, a difference the extraction calls `explained` is NEEDS_ANALYST (it may be that rounding), and an
unresolved difference is still WRONG. If a role is missing from the chain but its cell appears in an edge, or its keywords in the narrative, it is NEEDS_ANALYST,
not omitted. With workbooks, a Gold-equivalent cell whose saved value disagrees with Gold's number is flagged `VALUE DISAGREES` and the bridge cells are checked against Gold's cash and debt.

**How rivals, discrepancies and judgments are matched** (this order only): 1. explicit id: an extraction item's own `gold_id` (an ordinary
`E1`/`D1` id never counts, because it could collide); 2. the cells they reference: Gold's `cells` against the item's cells (a discrepancy's a, b and
driver cells; a rejection's cell; cell references written in a question's text, e.g. `Valuation Summary!F26`) - rivals need an exact cell, the others
accept Gold-listed or verified-linked equivalents; 3. normalised keywords (every keyword must be present as whole words; `a|b` accepts either) - a
fallback only, so rewording an extraction cannot flip a score that its cells decide; 4. otherwise NEEDS_ANALYST (seen elsewhere) or OMITTED (not
anywhere). An item whose Gold entry has no id, cells or keywords is UNSCORED, not wrong.

**Worksheet names.** A Gold reference such as `W2:'Valuation Summary'!H10` is resolved against the workbook's ACTUAL OOXML worksheet names: 1. EXACT raw
match; 2. NORMALIZED_WHITESPACE only if exact fails (reader escaping such as `&amp;` undone, non-breaking spaces read as spaces, leading/trailing whitespace trimmed,
runs of internal whitespace collapsed, case ignored as Excel does; every other character is kept, so `Valuation Summary-Prior Period` is a different sheet) and only
when exactly one worksheet matches. Several matches are an ambiguous sheet (BENCHMARK_INTEGRITY). The validator prints, per sheet, what Gold wrote, the workbook's
raw name and the method; Gold is never rewritten, and the same normalisation is applied to the extraction's references so a reader's stray space cannot split a match.

**Anchor numbers (primary strict, supporting corroborating).** A PRIMARY anchor must reproduce Gold's numeric answer (floating-point tolerance) or declare an
explicit scaling (`"support": "scaled"`, optional `factor`); implicit scaling is not accepted for a primary. A SUPPORTING anchor must exist and is compared only as
its stated support class says: `support` (optional key on the anchor: `exact`, `rounded` with optional `decimals`, `scaled` with optional `factor`, `context`), else read
from `shows` ("rounded", "2 decimals" -> rounded; "$000s", "thousands", "scaled" -> scaled); a declared or stated class that does not fit is an error; with neither, a rounded or
scaled display is recognised and an unrelated number only warns. So a full-precision 10.1394 with a supporting 10.14x is valid. Whole-sheet anchors (`W1:'Cap Table'`) only need the sheet
to exist: they are contextual support, never compared to a number, never substituted by a value found on the sheet, never exact provenance. Range cells need at least one value in them.

**Source identity (runtime renaming must not invalidate a benchmark).** Gold W1..Wn are tied to the supplied workbooks by SHA-256 when Gold (or a
`--sources` manifest) gives one; otherwise by the normalised file name, which ignores folder, extension, case, spaces vs underscores, punctuation, a browser
`(1)` and a runtime hash suffix (`Company_Valuation-1a2b3c4d.xlsx` = `Company Valuation.xlsx`), and only when exactly ONE supplied file matches: two
matches are ambiguous and fail, and a file neither identifies fails with BENCHMARK_INTEGRITY. Build 13.1: when that finds no file, a second try removes an
all-digit upload number joined by a hyphen from the SUPPLIED name only (`Book_V2-11963866.xlsx` = `Book V2.xlsx`), again only when exactly one file matches;
it is printed as `file name (normalised, upload number removed)`. A date ending such as `Valuation-20260630` is never stripped by the first try. The output says how every match was made. A SHA-256 identifies
the exact binary, so `gold_sources.py` computes the frozen fingerprints from the files actually supplied for the benchmark and never from an extraction;
retain its manifest (or write the SHA-256s into Gold) once a case is frozen.

**Source integrity against a historical extraction** (printed by `gold_score.py`, also by `gold_sources.py --extraction`): per workbook, SAME_BINARY (the
extraction recorded the frozen SHA-256), DIFFERENT_BINARY (same name, another SHA-256: a re-saved or re-downloaded copy, even if it looks equivalent),
NOT_COMPARABLE (a SHA-256 is unknown, tied by name only), MISSING. Overall `SOURCE INTEGRITY: SAME_BINARY (n/n)` or `MISMATCH`. A mismatch is
BENCHMARK_INTEGRITY, never EXTRACTION_WRONG: that workbook's concepts are not scored (NEEDS_ANALYST). Scoring against a semantically equivalent
saved copy is a separate explicit mode (`--allow-different-binary`), stated in the report; it is never the default.

**Owners.** Every failure carries its owner: GOLD_METADATA (the key is wrong or unfinished), TESTBENCH_VALIDATION (the key could not be read),
BENCHMARK_INTEGRITY (the files are not the frozen binaries), EXTRACTION_REASONING (wrong answer, selected rival, misread discrepancy, unsupported conclusion),
EXTRACTION_COVERAGE (omitted), EXTRACTION_SCHEMA (the schema has no slot), DETERMINISTIC_VERIFIER (the verifier's status is not VERIFIED),
UNSCORED_MATCHING_METADATA (a rival, discrepancy or judgment that could not be matched deterministically). Build 13.2: ANALYST_DECISION (the extraction's checked explanation disagrees with a Gold that says unresolved; a person decides).

**Three separate dimensions, never collapsed:** 1. Gold validity (`GOLD VALIDATION: PASS|FAIL`); 2. Gold accuracy and coverage (the score and BREAKDOWN);
3. extraction evidence verification (the verifier's status, labelled "as recorded in extraction.json" unless a fresh `--verification` file is given).

**Certification.** `material_truth_complete: YES` means the key captures all the material truth the analyst expects the extraction to discover from
this evidence package. It does not mean every approval is known or every ambiguity resolved: UNRESOLVED is a legitimate Gold answer and a key containing
UNRESOLVED judgments can still be certified.

**Gates for a real run, in order:** 1. `gold_suggest`; 2. the analyst enriches the key; 3. `gold_sources` (freeze SHA-256s from the supplied binaries; Gold needs no hand-written
SHA-256 when the manifest provides them: Gold's semantic source identity and the manifest's binary identity stay separate); 4. compare them with the extraction's hashes; 5. `gold_validate`;
6. only if valid, `gold_score`; 7. the extraction's verification shown separately. `gold_run.py` performs them. The extraction is never modified, rerun or repaired from reviewer output, and no
Gold answer is derived from it.

**Counts.** `false_material_claims` = wrong core answers + rivals selected + unsupported conclusions + misinterpreted discrepancies.
`material_gold_items_missed` = omitted concepts + rivals not addressed + omitted discrepancies + omitted judgments. They are kept separate. Ratios count decided items only
(NEEDS_ANALYST, UNSCORED and NOT_EXPRESSIBLE are reported beside them). There is no overall weighted score.

**Optional additions to the key** (all additive; see `templates/gold-mvp-3.template.json`): `id` or `gold_id`, `cells`, `keywords` on rivals, discrepancies and
judgments (`gold_suggest.py` lists what each item needs); `sha256` per source file; `keywords` on any concept; build 13.1: `relationship_basis` on `company_to_fund_relationship`,
`{"type": "ROUNDING", "decimals": N}` (0 to 6), which makes MATCH valid when one value rounded to N decimals equals the other (e.g. 24,723,978.88 shown as
24,723,979 with N = 0). Without it, MATCH still needs equal values; there is no other tolerance. `valuation_metric.answer` is required; `valuation_metric.value`
is optional (validated against the workbook when present, never substituted from another concept). Real Gold keys are supplied at scoring time with the
frozen workbooks and the existing `extraction.json`; the extractor is not rerun.


## Build 13.2 additions (all optional and additive; a 13.1 key validates and scores exactly as before)
Proven by `trial/reference/G1/score-13.1-*.json`: the G1 extractions score exactly as build 13.1 scored them.

| Topic | Rule |
|---|---|
| Period evidence | `metric_period` may give `header_anchor` (12 month headers) and `value_anchor` (12 monthly values). The validator checks the headers read first_month..last_month, the two line up (same sheet) and the values sum to `valuation_metric.value` when given. An old single `primary_anchor` is read as the header evidence. The scorer grades the answer, the header evidence (EXACT, VERIFIED_SAME_PERIOD, DIFFERENT_PERIOD, NOT_PROVEN, NOT_CHECKED) and the value evidence (EXACT, SUMS_TO_METRIC, DOES_NOT_SUM, NOT_CHECKED) separately. Another range than Gold's gets anchor VERIFIED_SAME_PERIOD only when checking code reads Gold's 12 months over it AND its values sum to the metric. Matching numbers alone never prove a period |
| Component anchors | `"support": "component"` (optional `"component": "cash"` or `"debt"`) on a supporting anchor: it must hold a number (Gold's cash or debt when named). A component is never an equivalent of the answer, so picking the cash cell as the equity value is WRONG_ANCHOR. The report lists each component as IN_BRIDGE or NOT_IN_BRIDGE |
| Rounding | A ROUNDING discrepancy may declare `basis` `{"type": "ROUNDING", "decimals": 0-6}` (else the relationship's basis is used). Recorded only as a checkable edge (e.g. `rounded_match`), it is FOUND only when checking code confirms the rule on the workbook values; without workbooks it is NEEDS_ANALYST |
| Immateriality | Only Gold sets it: `immaterial_below` (a dollar amount) on a discrepancy, or `materiality: {"immaterial_below": N}` for the key. Absent = none. Applied only to a difference checking code reproduces; percentages are refused; a threshold written by the extraction is ignored |
| Gold says unresolved, the extraction explains it | NEEDS_ANALYST, owner ANALYST_DECISION, when checking code reproduces the difference and the extraction cites driver cells beyond the two compared. Otherwise MISINTERPRETED / UNSUPPORTED_CONCLUSION as in 13.1. The extraction never overrules Gold: a person confirms the explanation and updates the key |
| Found, not in the key | Extraction discrepancies no Gold item or concept accounts for: FOUND_NOT_IN_GOLD when checking code (or a fresh `--verification` file, never the copy inside the extraction) reproduces them, else EXTRA_NOT_VERIFIED. No credit, no penalty, never added to Gold automatically |
| Report | Score lines, breakdown, then one section per topic: needs attention, core answers, evidence, known rivals, discrepancies, unresolved decisions, found not in key, integrity, checking-code verification. "Unresolved decisions" is the display name; the JSON keeps `human_judgments` and `judgments` |
| Key review | `gold_suggest.py --review` writes an Excel sheet (Review, Legend, a hidden link sheet) with one row per proposal: id, cells (each with its own reason), keywords, support type. Proposals come only from the key and the frozen workbooks; a rival is never offered the answer's own cell. `--apply` writes only Approve and Correct rows into a NEW key, refuses a sheet made for another version of the key, never overwrites a file, and records the reviewer in `metadata_review`. This metadata is test-bench only and never enters company memory |


## Build 13.2.1: key-review suggestions (gold_suggest.py and gold_run.py only; scoring is unchanged)
Every proposed cell is reopened in its workbook and written with the workbook's EXACT sheet name (a trailing space included). Each row has a
Confidence: **verified exact cell** (written in the item's text, the key's own anchor, or a key anchor's row under the one header reading the
period the item names), **candidate - review** (found by value or row label, or by an ambiguous rule), **one side only** (a comparison missing
its second cell), **no reliable candidate**. Rules:
- A key anchor written as a range is narrowed to the one cell holding the key's number (the metric's number comes from EV / multiple when the key gives none). Ranges are never proposed for an item.
- Blank cells and cells holding text are never proposed; the reason says why.
- A discrepancy, or an unresolved decision that compares two values, gets one cell per side. The second side is searched on the sheets or workbooks the text names: a value differing by the difference the text states, else a close value. A value EQUAL to side one is never the other side. If none is found: "other side missing".
- Rivals: a period the text names ("prior period", "prior year", "as of Jun 30 2026") gives the key's anchor rows under that header; otherwise the row label sharing the most words with the item, read in the TTM/LTM/total column or at a number near the related answer. A rival is never offered the answer's own cell and is never treated as a comparison.
- A number several cells hold is a candidate only, with the count shown. Keywords are offered only when no verified cell exists.
- gold_run's readiness counts items with no metadata, items with an id only (an extraction cannot match them), and discrepancies citing one side. Coverage reopens the key's own item cells. Neither says anything about the extraction, and the extraction score says nothing about the key.

## Build 13.2.2: four more suggestion fixes from the real review (gold_suggest.py only; scoring and Gold answers unchanged; fixture G4)
- An EBITDA-type item is never offered a multiple: labels naming a multiple (multiple, EV /, x) are skipped unless the item is about the multiple, and a value off the related answer's scale is skipped. An item about UNadjusted figures skips labels that say adjusted.
- When several headers read the same date (cost, valuation and gain "as of Jun 30, 2026"), only the one worded like the key anchor's own header ("Valuation as of Mar 31, 2026") is kept, and then it is verified.
- Two-letter words such as "PF" count in label matching; ties between look-alike rows go to the value closest to the related answer.
- The second side of a comparison must be on side one's scale (never the stated difference itself), is never a formula copy of another candidate, and is ranked: differs by the stated difference, then shares the most words with its row label, then closest. Only a unique best is proposed.
