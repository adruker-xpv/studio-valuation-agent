# review_xlsx.py (build 13.2.2) - the Excel review round trip. Plain code, no judgment.
#   build  --run-dir R [--out Review.xlsx]
#          writes the review workbook from proposed_changes.json: Start here | Unresolved decisions | Proposed changes |
#          Memory candidates | Legend. A person picks Approve / Correct / Reject in the Decision column, types a correction where
#          they pick Correct, and their name on Start here. Nothing else is editable (sheets are protected without a password;
#          every row also carries a hash of what it showed, so an edited row is refused on read).
#   read   --run-dir R --review FILLED.xlsx [--out review_decisions.json]
#          checks the filled workbook and writes review_decisions.json (every decision, as typed corrections) and
#          approved_changes.json (the proposals a person approved or corrected, in proposal order - the input 13.3 will use).
#          Refused, with every problem listed and NOTHING written, when: the review was built from other proposals (stale), a
#          row was edited, an id is unknown, no reviewer name, Correct without a valid correction, Approve on a contradicted
#          proposal, Approve/Correct on a proposal blocked by an unresolved decision nobody answered, or Approve on a decision
#          with no suggested answer. A blank Decision is "not decided" - never an approval.
# "Unresolved decisions" is the display name of the human_judgments list (the JSON field keeps its name).
# 13.2.1: numbers are compared the way Excel stores them (15 significant digits), so a value Excel re-saved is not an "edit" -
# this is storage only, never a tolerance on business values. Every row has "Rule or note for memory": a person's own rule (e.g.
# which file wins) kept as a confirmed assumption; it needs a Decision on that row. A decision with no suggested answer offers only
# Correct (type the answer) or Reject. A decision left blank stays pending in company memory and blocks what it touches.
import argparse, datetime, hashlib, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import guard as G  # noqa: E402
from onboarding_schema import SCHEMA_VERSION, REF_RE  # noqa: E402

DECISIONS = ["Approve", "Correct", "Reject"]
SHEETS = {"judgment": "Unresolved decisions", "proposal": "Proposed changes", "memory": "Memory candidates"}
KIND_TEXT = {"advance_period_label": "Move the period header", "roll_window": "Roll the 12-month window", "update_from_source": "Update from source",
             "carry_forward": "Carry forward (confirm)", "analyst_input": "Analyst gives the value", "keep_formula": "Keep the live formula",
             "record_revision": "Past value revised"}


def item_hash(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()[:16]


def load_pc(run_dir):
    p = os.path.join(run_dir, "proposed_changes.json")
    if not os.path.exists(p):
        raise SystemExit("REVIEW: no proposed_changes.json - save stage 7 first")
    return G.check_json_file(p, "proposed_changes.json")


def ref_txt(r):
    if not isinstance(r, dict):
        return ""
    return f"{r.get('source', '')}:{r.get('cell', '')}"


def rule_txt(it):
    r = it.get("rule") or {}
    k = it["kind"]
    if k == "advance_period_label":
        return f"header {r.get('from_period')} -> {r.get('to_period')}"
    if k == "roll_window":
        f = ", ".join(f"{ref_txt(x['from'])} ({x['edge']}, {x.get('class')})" for x in r.get("fill_from") or []) or "no source edge"
        return f"window {r['months_now'][0]}..{r['months_now'][1]} -> {r['months_next'][0]}..{r['months_next'][1]}; new months from {f}"
    if k == "update_from_source":
        rel = r.get("relation") or {}
        return f"from {ref_txt(r.get('from'))} ({r.get('edge')}, {r.get('class')}{', ' + rel.get('op') if rel else ''}), next period's column"
    if k == "carry_forward":
        return "keep the typed value"
    if k == "analyst_input":
        return "analyst types next quarter's value"
    if k == "keep_formula":
        return "keep the formula: " + str((it.get("current") or {}).get("formula") or "")[:60]
    if k == "record_revision":
        a, b = r.get("as_reported_at_period") or {}, r.get("later_known_value") or {}
        return f"{r.get('period')}: as reported {a.get('value')} ({a.get('file')} {a.get('cell')}) -> later known {b.get('value')} ({b.get('cell')})"
    return json.dumps(r)[:120]


def mem_txt(m):
    if not m:
        return ""
    return f"{m.get('value')} for {m.get('period')} (confirmed by {m.get('confirmed_by')})" + ("" if m.get("matches_current") else " - differs from now")


def rows_for(pc):
    """(sheet, header, [(item_type, item_id, hash, cells...)]) - what the person sees; the hash covers exactly what is shown."""
    out = {}
    jrows = []
    blocks = {}
    for it in pc["proposed_changes"]:
        for j in it.get("blocked_by") or []:
            blocks[j] = blocks.get(j, 0) + 1
    for i, j in enumerate(pc["human_judgments"], 1):
        sug = (j.get("suggested") or "") + (" (last confirmed answer, from company memory)" if j.get("suggested_from") == "company memory" else "")
        shown = [i, j["question"], ", ".join(ref_txt(c) for c in j.get("cells_affected") or []), sug,
                 " / ".join(j.get("options") or []), blocks.get(j["id"], 0), j.get("origin")]
        jrows.append(("judgment", j["id"], item_hash([j["id"], shown]), shown))
    out["judgment"] = (["#", "Question", "Cells it affects", "Suggested answer", "Options", "Changes it blocks", "Raised by"], jrows,
                       [5, 70, 30, 30, 24, 10, 20])
    prows = []
    for i, it in enumerate(pc["proposed_changes"], 1):
        cur = it.get("current") or {}
        shown = [i, KIND_TEXT.get(it["kind"], it["kind"]), it.get("what") or "", ref_txt(it.get("target") or (it.get("rule") or {}).get("window")),
                 it.get("row_label") or "", cur.get("formula") and f"={cur['formula']}" or cur.get("value"), rule_txt(it),
                 it["verify"]["status"] + ": " + it["verify"]["note"], "YES" if it.get("always_confirm") else "",
                 ", ".join(it.get("blocked_by") or []), mem_txt(it.get("in_memory"))]
        prows.append(("proposal", it["id"], item_hash([it["id"], shown]), shown))
    out["proposal"] = (["#", "Change", "What", "Cell", "Row label", "Now", "Rule (next quarter)", "Checking code", "Always confirm",
                        "Blocked by", "Company memory says"], prows, [5, 22, 26, 22, 20, 16, 60, 50, 9, 18, 30])
    mrows = []
    for i, c in enumerate(pc["memory_candidates"], 1):
        ev = "; ".join(f"{e.get('role')} {e.get('sheet')}!{e.get('cell')}" for e in c.get("evidence") or [])
        me = c.get("memory_entry") or {}
        status = {"new": "new", "differs": "CONTRADICTS company memory"}.get(c.get("memory_status"), "")
        shown = [i, c.get("type"), c["kind"], c["subject"], c["statement"], c.get("period"), ev, status,
                 (f"{me.get('statement')} ({me.get('type')}, {me.get('period')}, confirmed by {me.get('confirmed_by')})" if me else ""), c.get("origin")]
        mrows.append(("memory", c["id"], item_hash([c["id"], shown]), shown))
    out["memory"] = (["#", "Type", "Kind", "Subject", "What memory would say", "Period", "Evidence", "Compared with memory",
                      "Company memory says now", "Raised by"], mrows, [5, 11, 18, 30, 70, 9, 36, 18, 50, 12])
    return out


def build(run_dir, out_path):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill, Protection
    from openpyxl.worksheet.datavalidation import DataValidation
    pc = load_pc(run_dir)
    R = rows_for(pc)
    wb = Workbook()
    base, bold = Font(name="Arial", size=10), Font(name="Arial", size=10, bold=True)
    head, inp = PatternFill("solid", fgColor="DDEBF7"), PatternFill("solid", fgColor="FFF2CC")
    s = wb.active
    s.title = "Start here"
    c = pc["counts"]
    lines = [("Onboarding review - proposed changes for next quarter", None),
             ("Company", pc.get("company")), ("Quarter end", pc.get("quarter_end")), ("Next quarter end", pc.get("next_quarter_end")),
             ("Valuation workbook", pc["valuation_workbook"]["file"]),
             ("Reviewer name (required)", ""),
             ("", None),
             ("How to review", "On each of the next three sheets pick a Decision for every row: Approve (as shown), Correct (type your "
                               "correction in the yellow column) or Reject. Leave it blank if you have not decided - blank is never an approval."),
             ("Unresolved decisions", f"{c['human_judgments']} questions the workbooks cannot settle. Answer them first: a change they block "
                                      "cannot be approved until its decision is answered (Approve the suggested answer, or Correct with yours) "
                                      "or rejected as not needed."),
             ("Proposed changes", f"{c['proposed_changes']} changes ({c['confirmed']} confirmed by checking code, {c['not_checkable']} "
                                  f"judgment, {c['contradicted']} contradicted). 'Always confirm' rows (the multiple) need your decision every quarter."),
             ("Memory candidates", f"{c['memory_candidates']} things company memory could keep - facts (the workbooks show it) and "
                                   "assumptions (a person's call). Only rows you Approve or Correct are added; memory is never edited or "
                                   "deleted, a newer confirmed item wins and keeps what it replaced."
                                   + (f" {c.get('memory_unchanged', 0)} items already in company memory matched and are not shown; "
                                      f"{c.get('memory_differs', 0)} contradict it." if pc.get("memory_attached") else "")),
             ("Also kept in memory", "Your answers to unresolved decisions, and the 'Always confirm' values you approve or correct, are "
                                     "kept in company memory as assumptions for this period."),
             ("Corrections", "Number: 8.75 | Cell: 'Sheet name'!D9 (or W2:'Sheet name'!D9) | Text: one plain sentence. The Cell, Number or Text "
                             "allowed is listed in each row's 'Correction may be' column."),
             ("Rule or note for memory", "Any row: write a rule the company should keep (e.g. 'cash: use the balance sheet; the XPV summary only "
                                         "if the balance sheet is late'). It is saved as your confirmed assumption. Pick a Decision on that row too."),
             ("Left blank", "An unresolved decision you leave blank stays open in company memory, comes back next quarter, and blocks "
                            "the changes it touches until it is answered or rejected."),
             ("Example row", "Decision: Correct | Your correction: 8.75 | Comment: comps moved down this quarter"),
             ("Do not", "edit any other cell, add or delete rows, or rename sheets - the file is checked when it is read back.")]
    for i, (k, v) in enumerate(lines, 1):
        s.cell(i, 1, k).font = bold
        if v is not None:
            s.cell(i, 2, v).font = base
            s.cell(i, 2).alignment = Alignment(wrap_text=True, vertical="top")
    s["A1"].font = Font(name="Arial", size=14, bold=True)
    s["B6"].fill, s["B6"].protection = inp, Protection(locked=False)
    s.column_dimensions["A"].width, s.column_dimensions["B"].width = 28, 120
    s.protection.sheet = True
    for t in ("judgment", "proposal", "memory"):
        hdr, rows, widths = R[t]
        ws = wb.create_sheet(SHEETS[t])
        full = hdr + ["Decision", "Your correction", "Correction may be", "Comment", "Rule or note for memory", "_id", "_hash"]
        ws.append(full)
        for cc in ws[1]:
            cc.font, cc.fill = bold, head
            cc.alignment = Alignment(wrap_text=True, vertical="top")
        dv = DataValidation(type="list", formula1='"' + ",".join(DECISIONS) + '"', allow_blank=True)
        dv2 = DataValidation(type="list", formula1='"Correct,Reject"', allow_blank=True,
                             promptTitle="No suggested answer", prompt="Pick Correct and type your answer, or Reject if it is not needed.",
                             showInputMessage=True)
        ws.add_data_validation(dv)
        ws.add_data_validation(dv2)
        items = {x["id"]: x for x in pc["proposed_changes"] + pc["human_judgments"] + pc["memory_candidates"]}
        for r, (_, iid, hh, shown) in enumerate(rows, 2):
            ct = ", ".join(items[iid].get("correction_types") or [])
            no_sug = t == "judgment" and not items[iid].get("suggested")
            if no_sug:
                ct = "REQUIRED with Correct: your answer (" + ct + ")"
            for j, v in enumerate(shown + ["", "", ct, "", "", iid, hh], 1):
                cell = ws.cell(r, j)
                cell.value = v
                if isinstance(v, str) and v.startswith("="):
                    cell.data_type = "s"          # show a formula as text, never as a live formula
                cell.font = base
                cell.alignment = Alignment(wrap_text=True, vertical="top")
            n = len(hdr)
            for j in (n + 1, n + 2, n + 4, n + 5):
                ws.cell(r, j).fill, ws.cell(r, j).protection = inp, Protection(locked=False)
            (dv2 if no_sug else dv).add(ws.cell(r, n + 1))
        for i, w in enumerate(widths + [12, 26, 16, 30, 36, 4, 4], 1):
            ws.column_dimensions[ws.cell(1, i).column_letter].width = w
        for i in (len(full) - 1, len(full)):
            ws.column_dimensions[ws.cell(1, i).column_letter].hidden = True
        ws.freeze_panes = "B2"
        ws.protection.sheet = True
        ws.protection.formatColumns = False
    lg = wb.create_sheet("Legend")
    lg.append(["Term", "Meaning"])
    for cc in lg[1]:
        cc.font, cc.fill = bold, head
    for k, v in [("Unresolved decision", "a question the workbooks cannot settle; the JSON field is human_judgments"),
                 ("Proposed change", "one cell next quarter's workbook touches, with the rule the quarterly builder will follow"),
                 ("Memory candidate", "something company memory could keep once a person confirms it"),
                 ("Approve", "accept the row as shown"), ("Correct", "accept with your correction (typed in the yellow column)"),
                 ("Reject", "do not use this row"), ("blank", "not decided yet: never treated as an approval"),
                 ("confirmed", "checking code reproduced it from the workbooks"),
                 ("judgment / not_checkable", "an assumption or a call only a person can make - nothing proves it"),
                 ("contradicted", "checking code found it does not hold: it cannot be approved, only corrected or rejected"),
                 ("Always confirm", "decided by the analyst every quarter (the applied multiple, ownership)"),
                 ("fact", "a memory item the workbooks show (where something lives, a restated past value)"),
                 ("assumption", "a memory item that is a person's call (which file wins, a rule, the multiple, an answered decision)"),
                 ("CONTRADICTS company memory", "this run reads something different from what a person confirmed earlier; it is also an unresolved decision"),
                 ("TTM", "trailing twelve months"), ("EV", "enterprise value")] + \
                [(KIND_TEXT[k], k) for k in KIND_TEXT]:
        lg.append([k, v])
    for row in lg.iter_rows(min_row=2):
        for cc in row:
            cc.font = base
    lg.column_dimensions["A"].width, lg.column_dimensions["B"].width = 26, 100
    m = wb.create_sheet("_meta")
    for k, v in (("schema", "xpv-review/1"), ("inputs_sha256", pc["inputs_sha256"]), ("company", pc.get("company")),
                 ("quarter_end", pc.get("quarter_end")), ("made_by", f"review_xlsx {SCHEMA_VERSION}")):
        m.append([k, v])
    m.sheet_state = "hidden"
    m.protection.sheet = True
    wb.save(out_path)
    return {t: len(R[t][1]) for t in R}


def norm(v):
    """what a shown cell must still say. Numbers: Excel keeps 15 significant digits, so compare at that precision (a re-saved
    3803200.0000000005 is still 3803200) - representation only, never a tolerance on values."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, (int, float)):
        return format(float(f"{float(v):.15g}"), ".15g")
    t = str(v).strip()
    if re.fullmatch(r"[-+]?\d+(\.\d+)?([eE][-+]?\d+)?", t):
        return format(float(f"{float(t):.15g}"), ".15g")
    return t


def parse_correction(raw, types, sheets_by_source):
    """typed correction -> ({"type", "value"}, None) or (None, problem). Cells are checked against the run's workbooks."""
    if raw is None or str(raw).strip() == "":
        return None, "Correct needs a correction in 'Your correction'"
    t = str(raw).strip()
    if "cell" in types:
        m = re.fullmatch(r"(?:(W\d+|X\d+):)?(.+)", t)
        sid, ref = m.group(1), m.group(2)
        if REF_RE.match(ref):
            sh = ref.rsplit("!", 1)[0]
            sh = sh[1:-1].replace("''", "'") if sh.startswith("'") else sh
            cands = [sid] if sid else list(sheets_by_source)
            ok = [s for s in cands if sh.lower() in {x.lower() for x in sheets_by_source.get(s, [])}]
            if not ok:
                return None, f"{t}: no supplied workbook{(' ' + sid) if sid else ''} has a sheet {sh!r}"
            if len(ok) > 1 and not sid:
                return None, f"{t}: sheet {sh!r} is in {', '.join(ok)} - write it as {ok[0]}:{ref}"
            return {"type": "cell", "value": {"source": ok[0], "cell": ref}}, None
    if "number" in types:
        try:
            v = float(t.replace(",", "").replace("$", "").rstrip("xX").strip()) if not isinstance(raw, (int, float)) else float(raw)
            return {"type": "number", "value": v}, None
        except ValueError:
            pass
    if "text" in types:
        return {"type": "text", "value": t}, None
    return None, f"{t!r} is not a {' or '.join(types)}"


def read(run_dir, review_path):
    from openpyxl import load_workbook
    pc = load_pc(run_dir)
    G.check_file_name(review_path)
    P = []
    wb = load_workbook(review_path, data_only=True)
    need = ["Start here", "_meta"] + list(SHEETS.values())
    miss = [n for n in need if n not in wb.sheetnames]
    if miss:
        raise ValueError([f"sheet(s) missing: {', '.join(miss)} - is this the review workbook built for this run?"])
    meta = {r[0]: r[1] for r in wb["_meta"].iter_rows(values_only=True) if r and r[0]}
    # 13.2.2: a review stays valid while it shows exactly what this run proposes - checked row by row below (ids, hashes, every
    # shown cell). A different code build or a re-saved workbook alone does not make it stale.
    stale = meta.get("inputs_sha256") != pc["inputs_sha256"]
    reviewer = str(wb["Start here"]["B6"].value or "").strip()
    src1 = os.path.join(run_dir, "checkpoints", "01_sources.json")
    sheets_by = {s["id"]: [x["name"] for x in s.get("sheets", [])] for s in json.load(open(src1))["sources"]} if os.path.exists(src1) else {}
    R = rows_for(pc)
    items = {x["id"]: x for x in pc["proposed_changes"] + pc["human_judgments"] + pc["memory_candidates"]}
    dec = {}
    for t, sname in SHEETS.items():
        hdr, rows, _ = R[t]
        expect = {iid: hh for (_, iid, hh, _) in rows}
        ws = wb[sname]
        head = [c.value for c in ws[1]]
        try:
            ci = {k: head.index(k) for k in ("Decision", "Your correction", "Comment", "_id", "_hash")}
        except ValueError:
            P.append(f"{sname}: the header row was changed")
            continue
        ci["Rule or note for memory"] = head.index("Rule or note for memory") if "Rule or note for memory" in head else None  # older workbooks
        seen = set()
        for r in ws.iter_rows(min_row=2, values_only=True):
            if not any(v not in (None, "") for v in r):
                continue
            iid, hh = r[ci["_id"]], r[ci["_hash"]]
            if iid not in expect:
                P.append(f"{sname}: a row with an unknown id ({iid}) - rows cannot be added or copied")
                continue
            if iid in seen:
                P.append(f"{sname} {iid}: the row appears twice - rows cannot be added or copied")
                continue
            seen.add(iid)
            shown = next(x[3] for x in rows if x[1] == iid)
            if hh != expect[iid] or [norm(v) for v in r[:len(hdr)]] != [norm(v) for v in shown]:
                P.append(f"{sname} {iid}: the row was edited after it was built - only Decision, Your correction and Comment may change")
                continue
            d = str(r[ci["Decision"]] or "").strip().capitalize()
            if d and d not in DECISIONS:
                P.append(f"{sname} {iid}: Decision {d!r} is not Approve, Correct or Reject")
                continue
            corr = None
            if d == "Correct":
                corr, why = parse_correction(r[ci["Your correction"]], items[iid].get("correction_types") or ["text"], sheets_by)
                if why:
                    P.append(f"{sname} {iid}: {why}")
                    continue
            ni = ci["Rule or note for memory"]
            note = str(r[ni]).strip() if ni is not None and r[ni] not in (None, "") else None
            if note and not d:
                P.append(f"{sname} {iid}: a rule or note for memory needs a Decision on the same row (a blank row is not decided)")
                continue
            dec[iid] = {"item_type": t, "item_id": iid, "item_hash": hh, "decision": d or None, "correction": corr,
                        "comment": (str(r[ci["Comment"]]).strip() if r[ci["Comment"]] not in (None, "") else None), "memory_note": note}
        for iid in expect:
            if iid not in seen:
                P.append(f"{sname}: row {iid} is missing - rows cannot be deleted")
    # cross-item rules
    for j in pc["human_judgments"]:
        d = dec.get(j["id"]) or {}
        if d.get("decision") == "Approve" and not j.get("suggested"):
            P.append(f"Unresolved decisions {j['id']}: Approve means 'the suggested answer', and there is none - Correct with your answer")
    answered = {j["id"] for j in pc["human_judgments"] if (dec.get(j["id"]) or {}).get("decision") in DECISIONS}
    for it in pc["proposed_changes"]:
        d = (dec.get(it["id"]) or {}).get("decision")
        if d == "Approve" and it["verify"]["status"] == "contradicted":
            P.append(f"Proposed changes {it['id']}: checking code contradicts it - it can be corrected or rejected, not approved")
        if d in ("Approve", "Correct") and any(b not in answered for b in it.get("blocked_by") or []):
            P.append(f"Proposed changes {it['id']}: blocked by unresolved decision {', '.join(b for b in it['blocked_by'] if b not in answered)} - "
                     "answer it (or reject it as not needed) first")
    if any(d.get("decision") for d in dec.values()) and not reviewer:
        P.append("Start here: the reviewer's name (B6) is required")
    if P and stale:
        raise ValueError(["this review was built from other proposals and its rows no longer match what this run proposes: "
                          "build a fresh review workbook"] + P)
    if P:
        raise ValueError(P)
    review_sha = hashlib.sha256(open(review_path, "rb").read()).hexdigest()
    order = [x["id"] for x in pc["human_judgments"]] + [x["id"] for x in pc["proposed_changes"]] + [x["id"] for x in pc["memory_candidates"]]
    D = [dec[i] for i in order if i in dec]
    counts = {t: {k: sum(1 for d in D if d["item_type"] == t and d["decision"] == k) for k in DECISIONS + [None]} for t in SHEETS}
    for t in counts:
        counts[t]["undecided"] = counts[t].pop(None)
    out = {"schema": "xpv-review-decisions/1", "made_by": f"review_xlsx {SCHEMA_VERSION}", "company": pc.get("company"),
           "quarter_end": pc.get("quarter_end"), "inputs_sha256": pc["inputs_sha256"], "review_file": os.path.basename(review_path),
           "review_sha256": review_sha, "reviewer": reviewer or None,
           "read_at": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"), "decisions": D, "counts": counts}
    approved = []
    for it in pc["proposed_changes"]:
        d = dec.get(it["id"]) or {}
        if d.get("decision") in ("Approve", "Correct"):
            approved.append(dict(it, decision=d["decision"], correction=d.get("correction"), reviewer_comment=d.get("comment")))
    answers = []
    for j in pc["human_judgments"]:
        d = dec.get(j["id"]) or {}
        if d.get("decision"):
            answers.append({"id": j["id"], "question": j["question"], "decision": d["decision"],
                            "answer": (d.get("correction") or {}).get("value") if d["decision"] == "Correct" else
                            j.get("suggested") if d["decision"] == "Approve" else None})
    ac = {"schema": "xpv-approved-changes/1", "company": pc.get("company"), "quarter_end": pc.get("quarter_end"),
          "next_quarter_end": pc.get("next_quarter_end"), "valuation_workbook": pc["valuation_workbook"], "inputs_sha256": pc["inputs_sha256"],
          "review_sha256": review_sha, "reviewer": reviewer or None, "approved_changes": approved, "decisions_answered": answers,
          "not_approved": [it["id"] for it in pc["proposed_changes"] if it["id"] not in {a["id"] for a in approved}]}
    G.check_doc(out, "review_decisions")
    return out, ac


def main(argv=None):
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build")
    b.add_argument("--run-dir", default=".")
    b.add_argument("--out")
    r = sub.add_parser("read")
    r.add_argument("--run-dir", default=".")
    r.add_argument("--review", required=True)
    r.add_argument("--out")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "build":
            out = a.out or os.path.join(a.run_dir, "Review.xlsx")
            n = build(a.run_dir, out)
            print(f"REVIEW: built {os.path.basename(out)} | {n['judgment']} unresolved decisions, {n['proposal']} proposed changes, "
                  f"{n['memory']} memory candidates | UPLOAD: {os.path.basename(out)}")
            return 0
        dec, ac = read(a.run_dir, a.review)
    except G.Refused as x:
        print(f"REVIEW: refused | {x}")
        return 2
    except ValueError as x:
        P = x.args[0] if x.args and isinstance(x.args[0], list) else [str(x)]
        print(f"REVIEW: refused | {len(P)} problem(s); nothing was written. Fix the review workbook and read it again:")
        for m in P[:30]:
            print(f"  - {m}")
        return 1
    outp = a.out or os.path.join(a.run_dir, "review_decisions.json")
    json.dump(dec, open(outp, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    with open(os.path.join(os.path.dirname(outp) or ".", "approved_changes.json"), "w", encoding="utf-8") as fh:
        fh.write(json.dumps(ac, sort_keys=True, indent=1, ensure_ascii=False, default=str) + "\n")
    c = dec["counts"]
    print("REVIEW: read | " + " | ".join(f"{SHEETS[t]}: {v['Approve']} approved, {v['Correct']} corrected, {v['Reject']} rejected, "
                                         f"{v['undecided']} undecided" for t, v in c.items())
          + f" | reviewer {dec['reviewer'] or '-'} | UPLOAD: {os.path.basename(outp)}, approved_changes.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
