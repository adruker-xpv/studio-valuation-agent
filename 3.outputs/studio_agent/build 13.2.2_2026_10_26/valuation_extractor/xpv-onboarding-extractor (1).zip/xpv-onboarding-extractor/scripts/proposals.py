# proposals.py (build 13.2) - turns a saved extraction into STRUCTURED, DETERMINISTIC proposed changes for next quarter, so the
# quarterly builder (13.3) can write and check the workbook with no new interpretation. The AI proposes (stage 7); this code
# decides the final form, reads every value from the workbooks, checks each item, and sorts the result. Same stage files +
# same workbooks -> byte-identical proposed_changes.json. It never writes a workbook.
#
# What it makes
#   proposed_changes   one item per cell next quarter touches, in the company valuation workbook (and the 12-month window
#                      wherever it is). Code derives the core set from the chain; the agent's stage 7 may change an item's kind
#                      (same target) or add items for other material inputs.
#                        advance_period_label  roll_window  update_from_source  carry_forward  analyst_input  keep_formula
#                        record_revision (code only: both values read from cells whose headers read the past period)
#   human_judgments    the "Unresolved decisions": the agent's stage 7 questions, stage 6 open questions and every unresolved
#                      discrepancy. A proposal whose cells a decision affects is blocked_by it.
#   memory_candidates  what could go into company memory once a person confirms it: where each chain item lives (mapping),
#                      where each updated input comes from, every evidenced revision, plus the agent's rules / precedence notes.
#                      Portable form: workbook ROLE + sheet + cell (+ row label), never run ids. Nothing here is memory yet.
# Item verify status: confirmed (checking code reproduced it) | not_checkable (a judgment or an assumption the analyst
# confirms) | contradicted. Nothing is ever "confirmed" without checking code; a carried-forward multiple is not_checkable.
# Usage: python proposals.py build --run-dir R        (normally run for you by checkpoint.py save --stage 7)
#        python proposals.py show  --run-dir R
import argparse, calendar, datetime, hashlib, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from xlsx_evidence import SourceSet, split_ref, parse_range, parse_cell, addr, num, quote_sheet  # noqa: E402
from onboarding_schema import SCHEMA_VERSION, PROPOSAL_KINDS, CODE_ONLY_KINDS, MEMORY_KINDS  # noqa: E402
import guard as G  # noqa: E402

SCHEMA = "xpv-proposed-changes/1"
KIND_ORDER = ["advance_period_label", "roll_window", "update_from_source", "carry_forward", "analyst_input", "keep_formula",
              "record_revision"]
CORRECTION_TYPES = {"advance_period_label": ["text"], "roll_window": ["cell", "text"], "update_from_source": ["cell", "number"],
                    "carry_forward": ["number"], "analyst_input": ["number"], "keep_formula": ["text"], "record_revision": ["text"]}
MEMORY_CORRECTION = {"mapping": ["cell"], "source_precedence": ["text"], "adjustment_rule": ["text"], "method_note": ["text"],
                     "revision": ["text"]}
JUDGMENT_CORRECTION = ["text", "number", "cell"]
# every memory item is a FACT (read from the workbooks: where something lives, a restatement) or an ASSUMPTION / JUDGMENT (a
# person's call: which file wins, an add-back rule, the multiple, an answered decision). Both enter memory only when a person confirms.
TYPE_BY_KIND = {"mapping": "fact", "revision": "fact", "source_precedence": "assumption", "adjustment_rule": "assumption",
                "method_note": "assumption", "assumption_value": "assumption", "judgment": "assumption", "analyst_rule": "assumption"}
MEMORY_IN_FILE = "company_memory.in.json"     # the company memory attached to this run (memory.py attach); read-only here
ROLE_LABEL = {"valuation_metric": "Valuation metric (TTM)", "selected_multiple": "Applied multiple", "enterprise_value": "Enterprise value",
              "equity_value": "Equity value", "value_to_xpv": "Value to XPV", "metric_window": "12-month window", "fund_cell": "Fund-reported value"}


class BuildError(Exception):
    def __init__(self, problems):
        super().__init__("; ".join(problems))
        self.problems = list(problems)


def h(obj, n=12):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()[:n]


def add_months(ym_, k):
    y, m = int(ym_[:4]), int(ym_[5:7])
    t = y * 12 + (m - 1) + k
    return f"{t // 12:04d}-{t % 12 + 1:02d}"


def quarter_after(qe):
    y, m = int(qe[:4]), int(qe[5:7]) + 3
    y, m = y + (m - 1) // 12, (m - 1) % 12 + 1
    return f"{y:04d}-{m:02d}-{calendar.monthrange(y, m)[1]:02d}"


class Ctx:
    """everything a check needs: the workbooks, the extraction, the edge statuses."""

    def __init__(self, W, X):
        import verify as V
        self.V, self.W, self.X = V, W, X
        self.want = (X.get("quarter_end") or "")[:7]
        self.ch = X.get("chain") or {}
        self.cs = self.ch.get("source")
        self.roles = {s.get("id"): s.get("role") for s in (X.get("sources") or []) + (X.get("external") or []) if isinstance(s, dict)}
        self.files = {s.get("id"): s.get("file") for s in (X.get("sources") or []) + (X.get("external") or []) if isinstance(s, dict)}
        self.edges = {e["id"]: e for sec in ("provenance", "downstream") for e in X.get(sec) or [] if isinstance(e, dict) and e.get("id")}
        self._est, self._win = {}, None

    def edge_status(self, eid):
        if eid not in self._est:
            e = self.edges.get(eid)
            self._est[eid] = self.V.check_edge(self.W, e) if e else ("contradicted", f"no edge {eid} in the extraction")
        return self._est[eid]

    def key(self, ref):
        ks = self.W.expand(ref)
        if len(ks) != 1:
            raise ValueError(f"{ref.get('cell')} is {len(ks)} cells; a target is one cell")
        return ks[0]

    def ref(self, k):
        return {"source": k[0], "cell": f"{quote_sheet(k[1])}!{k[2]}"}

    def keys(self, ref):
        try:
            return set(self.W.expand(ref))
        except (ValueError, KeyError, TypeError):
            return set()

    def role_key(self, role):
        c = (self.ch.get(role) or {}).get("cell")
        if not c or not self.cs:
            return None
        try:
            return self.key({"source": self.cs, "cell": c})
        except ValueError:
            return None

    def current(self, k):
        c = self.W.cell(*k)
        v = c[0] if c else None
        if isinstance(v, (datetime.date, datetime.datetime)):
            v = v.isoformat()
        return {"value": v, "formula": (c[1] if c else None)}

    def row_label(self, k):
        b = self.W.book(k[0])
        if not b:
            return None
        rc = parse_cell(k[2])
        cells = b.cells(k[1])
        for c in range(rc[1] - 1, 0, -1):
            v = cells.get((rc[0], c), (None,))[0]
            if isinstance(v, str) and v.strip():
                return v.strip()[:80]
        return None

    def portable(self, ref_or_key):
        k = ref_or_key if isinstance(ref_or_key, tuple) else None
        if k is None:
            sh, rng = split_ref(ref_or_key.get("cell", ""))
            sid = ref_or_key.get("source")
            return {"role": self.roles.get(sid), "file": self.files.get(sid), "sheet": self.W.sheet(sid, sh), "cell": rng.replace("$", "")}
        return {"role": self.roles.get(k[0]), "file": self.files.get(k[0]), "sheet": k[1], "cell": k[2], "row_label": self.row_label(k)}

    def window(self):
        if self._win is None:
            mw = self.ch.get("metric_window") or {}
            mk = self.role_key("valuation_metric")
            if not mw.get("cells") or not mk:
                self._win = ("not checked", {"problem": "no 12-month window or metric"})
            else:
                self._win = self.V.window_check(self.W, mw, mk, self.want)
        return self._win


def edges_into(cx, keyset):
    """provenance/downstream edges whose target overlaps keyset, sorted by id -> [edge]."""
    out = []
    for eid in sorted(cx.edges):
        e = cx.edges[eid]
        if isinstance(e.get("to"), dict) and cx.keys(e["to"]) & keyset:
            out.append(e)
    return out


def periods_of(cx, ref):
    """period headers over the first and last cell of a source ref -> [first, last] (None where checking code finds no header)."""
    try:
        ks = cx.W.expand(ref if isinstance(ref, dict) else ref[0])
    except (ValueError, KeyError, TypeError, IndexError):
        return [None, None]
    return [cx.V.column_period(cx.W, *ks[0])[0], cx.V.column_period(cx.W, *ks[-1])[0]] if ks else [None, None]


def src_rule(cx, e):
    p = periods_of(cx, e["from"])
    return {"from": e["from"], "edge": e["id"], "class": e.get("class"), "relation": e.get("relation"), "match_by": "period_header",
            "from_period": p[-1]}


def check_item(cx, it):
    """-> (status, note) for one proposed change, re-read from the workbooks. Used by build and by verify."""
    W, kind = cx.W, it["kind"]
    tk = None
    if it.get("target"):
        try:
            tk = cx.key(it["target"])
        except (ValueError, KeyError) as x:
            return "contradicted", f"target cannot be read: {x}"
        now = cx.current(tk)
        was = it.get("current") or {}
        if (now["formula"] or None) != (was.get("formula") or None) or not same_value(now["value"], was.get("value")):
            return "contradicted", "the workbook no longer holds what this proposal was built from (value or formula changed)"
    if kind == "keep_formula":
        if not now["formula"]:
            return "contradicted", "no formula in the target: it is a typed value"
        role = (it.get("basis") or {}).get("chain_role")
        v = {r: num(W.value(*k)) for r in ("valuation_metric", "selected_multiple", "enterprise_value", "equity_value")
             if (k := cx.role_key(r))}
        if role == "enterprise_value" and not cx.ch.get("components"):
            if None in (v.get("valuation_metric"), v.get("selected_multiple"), v.get("enterprise_value")) or not cx.V.close(
                    v["valuation_metric"] * v["selected_multiple"], v["enterprise_value"], rel=1e-6):
                return "contradicted", "EV does not recompute as metric x multiple"
            return "confirmed", "live formula; EV recomputes as metric x multiple"
        if role == "equity_value":
            try:
                calc = v["enterprise_value"] + sum(int(i.get("sign", 1)) * (num(W.value(*cx.key({"source": cx.cs, "cell": i["cell"]}))) or 0)
                                                   for i in cx.ch.get("bridge") or [])
            except (KeyError, TypeError, ValueError):
                calc = None
            if calc is None or not cx.V.close(calc, v.get("equity_value"), rel=1e-6):
                return "contradicted", "equity does not recompute as EV + the signed bridge items"
            return "confirmed", "live formula; equity recomputes as EV + the signed bridge items"
        if num(now["value"]) is None and now["value"] is None:
            return "contradicted", "the formula has no saved value"
        return "confirmed", "live formula with a saved value; keep it"
    if kind == "carry_forward":
        if now["formula"]:
            return "contradicted", "the target is a formula, not a typed value to carry forward"
        if num(now["value"]) is None:
            return "contradicted", "no number to carry forward"
        return "not_checkable", "an assumption: the analyst confirms it for next quarter"
    if kind == "analyst_input":
        return "not_checkable", "no source in the supplied files: the analyst gives next quarter's value"
    if kind == "advance_period_label":
        p = cx.V.period_at(W, *tk)
        r = it.get("rule") or {}
        if p != r.get("from_period"):
            return "contradicted", f"the header reads {p}, not {r.get('from_period')}"
        if now["formula"]:
            return "contradicted", "the header is a formula: keep_formula, not a label to retype"
        return "confirmed", f"the header reads {p}; next quarter it reads {r.get('to_period')}"
    if kind == "update_from_source":
        eid = (it.get("basis") or {}).get("edge")
        st, note = cx.edge_status(eid)
        return st, f"edge {eid}: {note}"
    if kind == "roll_window":
        st, wd = cx.window()
        if st == "fail":
            return "contradicted", f"the window check fails: {wd.get('problem') or 'see verify'}"
        if st != "pass":
            return "not_checkable", "the window's period could not be proven by checking code"
        fills = (it.get("rule") or {}).get("fill_from") or []
        if not fills:
            return "not_checkable", "window proven, but no edge says where the months come from"
        sts = [cx.edge_status(f["edge"]) for f in fills]
        if any(s == "contradicted" for s, _ in sts):
            return "contradicted", "an edge filling the window is contradicted"
        if all(s == "confirmed" for s, _ in sts):
            return "confirmed", f"window proven ({wd.get('header_from')} reads the 12 months; the values sum to the metric); source edges confirmed"
        return "not_checkable", "window proven; its source is judgment (an edge is not checkable)"
    if kind == "record_revision":
        r = it.get("rule") or {}
        try:
            ka, kb = cx.key(r["as_reported_at_period"]), cx.key(r["later_known_value"])
        except (ValueError, KeyError, TypeError) as x:
            return "contradicted", f"cannot read a revision cell: {x}"
        va, vb = num(W.value(*ka)), num(W.value(*kb))
        if va is None or vb is None or not same_value(va, r["as_reported_at_period"].get("value")) or not same_value(vb, r["later_known_value"].get("value")):
            return "contradicted", "a revision value changed or is not a number"
        pa, pb = cx.V.column_period(W, *ka)[0], cx.V.column_period(W, *kb)[0]
        if pa != r.get("period") or pb != r.get("period"):
            return "contradicted", f"headers read {pa} / {pb}, not {r.get('period')}"
        return "confirmed", "both values read from cells whose headers read the period; which one is right is the analyst's call"
    return "contradicted", f"unknown kind {kind}"


def _loc(v):
    v = v or {}
    return (v.get("role"), str(v.get("sheet") or "").lower(), str(v.get("cell") or "").replace("$", "").upper())


def same_memory(c, e):
    """does this run's reading say what the memory entry in force says? (cells of a source move with the period, so a source
    mapping compares workbook role, sheet and ROW; a chain mapping compares role, sheet and cell)."""
    a, b = c.get("value"), e.get("value")
    if c["kind"] == "mapping" and c["subject"].startswith("source."):
        fa, fb = (a or {}).get("from") or {}, (b or {}).get("from") or b or {}
        ra, rb = parse_cell(str(fa.get("cell", "")).split(":")[0]), parse_cell(str(fb.get("cell", "")).split(":")[0])
        return _loc(fa)[:2] == _loc(fb)[:2] and bool(ra) and bool(rb) and ra[0] == rb[0]
    if c["kind"] == "mapping":
        return _loc(a) == _loc(b)
    if c["kind"] == "revision":
        return (same_value((a or {}).get("as_reported_at_period", {}).get("value"), (b or {}).get("as_reported_at_period", {}).get("value"))
                and same_value((a or {}).get("later_known_value", {}).get("value"), (b or {}).get("later_known_value", {}).get("value")))
    norm = lambda t: re.sub(r"\s+", " ", str(t or "").strip().lower())
    return norm(c.get("statement")) == norm(e.get("statement"))


def mapping_refs(cx, c):
    """this run's cells for a mapping candidate (the cells a contradiction with memory affects)."""
    v = c.get("value") or {}
    v = v.get("target") or v
    sid = next((k for k, f in sorted(cx.files.items()) if f == v.get("file")), None)
    return [{"source": sid, "cell": f"{quote_sheet(v['sheet'])}!{v['cell']}"}] if sid and v.get("sheet") and v.get("cell") else []


def decision_key(cx, q, cells):
    """the same question about the same place in the workbooks has the same key every quarter (run ids and file names change)."""
    loc = sorted(json.dumps([v.get("role"), str(v.get("sheet") or "").lower(), str(v.get("cell") or "").upper()])
                 for v in (cx.portable(c) for c in cells))
    return "DK-" + h([re.sub(r"\s+", " ", q.strip().lower()), loc])


def locate(cx, v):
    """a portable cell (role, sheet, cell) -> this run's ref, only if exactly one supplied workbook has that role and sheet."""
    sids = [sid for sid, r in sorted(cx.roles.items()) if r == v.get("role") and cx.W.book(sid)
            and v.get("sheet") and str(v["sheet"]).lower() in {x["name"].lower() for x in cx.W.book(sid).sheets}]
    if len(sids) != 1 or not v.get("cell"):
        return None
    return {"source": sids[0], "cell": f"{quote_sheet(cx.W.sheet(sids[0], v['sheet']))}!{v['cell']}"}


def assumption_subject(cx, it):
    tv = cx.portable(cx.key(it["target"]))
    return f"assumption_value:value.{tv['sheet'].lower()}!{tv['cell'].lower()}"


def same_value(a, b):
    na, nb = num(a), num(b)
    if na is not None or nb is not None:
        return na is not None and nb is not None and abs(na - nb) <= 1e-9 * max(1.0, abs(na), abs(nb))
    return (a if a != "" else None) == (b if b != "" else None)


def build(run_dir, override=None):
    import checkpoint as CK
    X = CK.collect(run_dir, "extraction", override, rebuild=False)
    if not X or not X.get("chain"):
        raise BuildError(["stage 3 (the chain) is needed before proposals"])
    s7 = (override or {}).get(CK.PROPOSALS) or CK.latest(run_dir, "extraction", CK.PROPOSALS)[1] or {}
    for doc, where in ((s7, "stage 7"), (X, "extraction")):
        P = G.scan({k: v for k, v in doc.items() if k not in ("evidence",)}, where)
        if P:
            raise BuildError(P)
    srcs = SourceSet(run_dir)
    srcs.ensure_all()
    if not srcs.external and X.get("external"):
        srcs.external = X["external"]
    import verify as V
    W = V.World(srcs)
    cx = Ctx(W, X)
    MEMORY_IN, MEMORY_SHA, MEMORY_PENDING = None, None, []
    mp = os.path.join(run_dir, MEMORY_IN_FILE)
    if os.path.exists(mp):
        import memory as MEM
        try:
            mem = MEM.load(mp)
        except (G.Refused, ValueError) as x:
            raise BuildError([f"the attached company memory cannot be used: {x}"])
        bad = MEM.check_chain(mem)
        if bad:
            raise BuildError(["the attached company memory is not intact: " + bad[0]])
        if mem.get("company") and X.get("company") and mem["company"] != X["company"]:
            raise BuildError([f"the attached company memory is {mem['company']!r}'s; this run is {X['company']!r}"])
        MEMORY_IN = MEM.current(mem)
        MEMORY_PENDING = MEM.pending(mem)
        MEMORY_SHA = hashlib.sha256(open(mp, "rb").read()).hexdigest()
    if cx.cs not in srcs.books:
        raise BuildError([f"the valuation workbook {cx.cs} is not available in this run (run the inventory first)"])
    problems, items = [], {}

    def put(kind, k, rule, check, basis, what, origin, always_confirm=False, extra=None):
        it = {"kind": kind, "target": cx.ref(k) if k else None, "what": what, "origin": origin, "current": cx.current(k) if k else None,
              "rule": rule, "check": check, "basis": basis, "always_confirm": always_confirm,
              "row_label": cx.row_label(k) if k else None, "correction_types": CORRECTION_TYPES[kind]}
        it.update(extra or {})
        items[("window",) if kind == "roll_window" else ("revision", k) if kind == "record_revision" else k] = it

    # --- the core set, derived from the chain -------------------------------------------------------------------------------
    ch = cx.ch
    for role in ("valuation_metric", "selected_multiple", "enterprise_value", "equity_value", "value_to_xpv"):
        k = cx.role_key(role)
        if not k:
            continue
        f = (W.cell(*k) or (None, None))[1]
        ins = edges_into(cx, {k})
        if f:
            put("keep_formula", k, {"keep": "formula"}, {"op": "chain", "role": role}, {"chain_role": role}, ROLE_LABEL[role], "code",
                always_confirm=role == "selected_multiple")
        elif ins and role != "selected_multiple":
            e = ins[0]
            put("update_from_source", k, src_rule(cx, e),
                {"op": "edge", "edge": e["id"]}, {"edge": e["id"]}, ROLE_LABEL[role], "code")
        elif role == "selected_multiple":
            put("carry_forward", k, {"keep": "value"}, {"op": "equal_current"}, {"chain_role": role}, ROLE_LABEL[role], "code",
                always_confirm=True)
        else:
            put("analyst_input", k, {"value_from": "analyst"}, {"op": "none"}, {"chain_role": role}, ROLE_LABEL[role], "code")
    for grp, lst in (("bridge", ch.get("bridge") or []), ("waterfall", ch.get("waterfall") or [])):
        for x in lst:
            try:
                k = cx.key({"source": cx.cs, "cell": x.get("cell")})
            except (ValueError, KeyError):
                continue
            if k in items or (grp == "waterfall" and x.get("kind") in ("equity_input", "xpv_value")):
                continue
            f = (W.cell(*k) or (None, None))[1]
            ins = edges_into(cx, {k})
            what = f"{grp}: {x.get('what') or ''}".strip()
            if ins:
                e = ins[0]
                put("update_from_source", k, src_rule(cx, e), {"op": "edge", "edge": e["id"]}, {"edge": e["id"]}, what, "code")
            elif f:
                put("keep_formula", k, {"keep": "formula"}, {"op": "formula_value"}, {"chain_role": grp}, what, "code")
            elif grp == "waterfall":
                put("carry_forward", k, {"keep": "value"}, {"op": "equal_current"}, {"chain_role": grp}, what, "code", always_confirm=True)
            else:
                put("analyst_input", k, {"value_from": "analyst"}, {"op": "none"}, {"chain_role": grp}, what, "code")
    mw = ch.get("metric_window") or {}
    if mw.get("cells"):
        wset = cx.keys({"source": mw.get("source"), "cell": mw["cells"]})
        fills = [{"edge": e["id"], "from": e["from"], "class": e.get("class"), "relation": e.get("relation"), "from_months": periods_of(cx, e["from"])}
                 for e in edges_into(cx, wset)]
        if mw.get("first") and mw.get("last"):
            put("roll_window", None, {"window": {"source": mw.get("source"), "cell": mw["cells"]}, "months_now": [mw["first"], mw["last"]],
                                      "months_next": [add_months(mw["first"], 3), add_months(mw["last"], 3)], "shift_months": 3,
                                      "drop_first": 3, "append": 3, "fill_from": fills, "match_by": "period_header"},
                {"op": "window_sums_to", "chain_role": "valuation_metric"}, {"chain_role": "metric_window"}, ROLE_LABEL["metric_window"], "code")
    evk = cx.role_key("enterprise_value")
    if evk:
        p, where = V.column_period(W, *evk)
        if p and where:
            hk = (evk[0], evk[1], where)
            if not (W.cell(*hk) or (None, None))[1]:
                put("advance_period_label", hk, {"from_period": p, "to_period": add_months(p, 3),
                                                 "year_from_above": V.parse_period(W.value(*hk)) is None},
                    {"op": "header_reads", "period": add_months(p, 3)},
                    {"chain_role": "enterprise_value"}, "Period header over the valuation column", "code")
    for x in X.get("inputs") or []:
        try:
            k = cx.key(x)
        except (ValueError, KeyError):
            continue
        if k in items or k[0] != cx.cs:
            continue
        f = (W.cell(*k) or (None, None))[1]
        ins = edges_into(cx, {k})
        what = f"input: {x.get('what') or ''}".strip()
        if ins:
            e = ins[0]
            put("update_from_source", k, src_rule(cx, e), {"op": "edge", "edge": e["id"]}, {"edge": e["id"]}, what, "code")
        elif not f:
            put("analyst_input", k, {"value_from": "analyst"}, {"op": "none"}, {"input": x.get("kind")}, what, "code")

    # --- the agent's stage 7: change a kind (same target) or add an item -------------------------------------------------------
    for i, p_ in enumerate(s7.get("proposals") or []):
        w = f"proposals[{i}]"
        kind = p_.get("kind")
        try:
            k = cx.key(p_["target"]) if p_.get("target") else None
        except (ValueError, KeyError) as x:
            problems.append(f"{w}: {x}")
            continue
        if kind == "roll_window":
            if ("window",) not in items:
                problems.append(f"{w}: roll_window needs the chain's 12-month window (first, last, cells)")
                continue
            it = items[("window",)]
            if (p_.get("basis") or {}).get("edge"):
                e = cx.edges.get(p_["basis"]["edge"])
                if not e:
                    problems.append(f"{w}: no edge {p_['basis']['edge']}")
                    continue
                fl = {"edge": e["id"], "from": e["from"], "class": e.get("class"), "relation": e.get("relation"), "from_months": periods_of(cx, e["from"])}
                if fl not in it["rule"]["fill_from"]:
                    it["rule"]["fill_from"] = sorted(it["rule"]["fill_from"] + [fl], key=lambda z: z["edge"])
            it.update(what=p_.get("what") or it["what"], origin="agent")
            continue
        if not k:
            problems.append(f"{w}: a target cell is required")
            continue
        f = (W.cell(*k) or (None, None))[1]
        basis = p_.get("basis") or {}
        if kind == "update_from_source":
            e = cx.edges.get(basis.get("edge"))
            if not e:
                problems.append(f"{w}: no edge {basis.get('edge')!r} in the extraction")
                continue
            if k not in cx.keys(e.get("to") or {}):
                problems.append(f"{w}: edge {e['id']} does not end at {p_['target'].get('cell')}")
                continue
            put(kind, k, src_rule(cx, e),
                {"op": "edge", "edge": e["id"]}, {"edge": e["id"]}, p_["what"], "agent")
        elif kind == "keep_formula":
            if not f:
                problems.append(f"{w}: {p_['target'].get('cell')} holds a typed value, not a formula")
                continue
            role = basis.get("chain_role")
            put(kind, k, {"keep": "formula"}, {"op": "chain", "role": role} if role else {"op": "formula_value"}, basis or {"chain_role": None},
                p_["what"], "agent")
        elif kind in ("carry_forward", "analyst_input"):
            if f:
                problems.append(f"{w}: {p_['target'].get('cell')} is a formula ({f[:40]}); use keep_formula")
                continue
            prev = items.get(k) or {}
            put(kind, k, {"keep": "value"} if kind == "carry_forward" else {"value_from": "analyst"},
                {"op": "equal_current"} if kind == "carry_forward" else {"op": "none"}, basis or prev.get("basis") or {}, p_["what"], "agent",
                always_confirm=kind == "carry_forward" or bool(prev.get("always_confirm")))
        elif kind == "advance_period_label":
            per = V.period_at(W, *k)
            if not per or f:
                problems.append(f"{w}: {p_['target'].get('cell')} is not a typed period header")
                continue
            put(kind, k, {"from_period": per, "to_period": add_months(per, 3), "year_from_above": V.parse_period(W.value(*k)) is None},
                {"op": "header_reads", "period": add_months(per, 3)}, basis,
                p_["what"], "agent")

    # --- revisions: only where BOTH values are directly evidenced ---------------------------------------------------------------
    revs = []
    for i, r in enumerate(s7.get("revisions") or []):
        w = f"revisions[{i}]"
        try:
            ka, kb = cx.key(r["as_reported_at_period"]), cx.key(r["later_known_value"])
        except (ValueError, KeyError, TypeError) as x:
            problems.append(f"{w}: {x}")
            continue
        if ka == kb:
            problems.append(f"{w}: the as-reported and later-known cells are the same cell")
            continue
        va, vb = num(W.value(*ka)), num(W.value(*kb))
        if va is None or vb is None:
            problems.append(f"{w}: {'the as-reported' if va is None else 'the later-known'} cell holds no number - a revision is "
                            "emitted only when both values are in the supplied workbooks (never inferred)")
            continue
        if V.close(va, vb, rel=1e-9, ab=0.005):
            problems.append(f"{w}: both cells hold {va}: no revision")
            continue
        pa, pb = V.column_period(W, *ka)[0], V.column_period(W, *kb)[0]
        if pa != r["period"] or pb != r["period"]:
            problems.append(f"{w}: the headers over the two cells read {pa or 'no period'} / {pb or 'no period'}, not {r['period']}: the period "
                            "is not directly evidenced, so no revision is emitted (name cells whose column headers read the period)")
            continue
        rule = {"period": r["period"], "as_reported_at_period": dict(cx.ref(ka), value=va, file=cx.files.get(ka[0]), role=cx.roles.get(ka[0])),
                "later_known_value": dict(cx.ref(kb), value=vb, file=cx.files.get(kb[0]), role=cx.roles.get(kb[0])), "difference": vb - va}
        put("record_revision", kb, rule, {"op": "values_differ"}, {"revision": r["period"]}, r.get("what"), "agent")
        revs.append((kb, rule, r.get("what")))
    if problems:
        raise BuildError(problems)

    # --- finish proposals: ids, checks ------------------------------------------------------------------------------------------
    def sk(it):
        t = it.get("target") or (it.get("rule") or {}).get("window") or {}
        sh, a = split_ref(t.get("cell", "!A1")) if t.get("cell") else ("", "A1")
        rc = parse_cell(a.split(":")[0]) or (0, 0)
        return (KIND_ORDER.index(it["kind"]), t.get("source") or "", sh.lower(), rc[0], rc[1])
    pcs = sorted(items.values(), key=sk)
    for it in pcs:
        it["id"] = "PC-" + h([it["kind"], it.get("target"), it["rule"]])
        st, note = check_item(cx, it)
        it["verify"] = {"status": st, "note": note}
        it["evidence_class"] = (cx.edges.get((it.get("basis") or {}).get("edge")) or {}).get("class")

    # --- unresolved decisions ---------------------------------------------------------------------------------------------------
    hjs = {}

    def judgment(q, cells, origin, suggested=None, options=None, extra=None):
        cells = [c for c in (cells or []) if isinstance(c, dict)]
        jid = "HJ-" + h([re.sub(r"\s+", " ", q.strip().lower()), cells])
        hjs[jid] = {"id": jid, "decision_key": decision_key(cx, q, cells), "question": q.strip(), "cells_affected": cells,
                    "suggested": suggested, "options": options or [], "origin": origin, "correction_types": JUDGMENT_CORRECTION,
                    "cells_portable": [cx.portable(c) for c in cells]}
        hjs[jid].update(extra or {})
    for j in s7.get("human_judgments") or []:
        cells = j.get("cells_affected")
        judgment(j["question"], cells if isinstance(cells, list) else [cells] if cells else [], "agent", j.get("suggested"), j.get("options"))
    for q in X.get("open_questions") or []:
        if isinstance(q, str) and q.strip():
            judgment(q, [], "stage 6 open question")
    for d in X.get("discrepancies") or []:
        if isinstance(d, dict) and d.get("status") == "unresolved":
            judgment(f"{d.get('id')}: {d.get('what')} - which value is the approved one?", [d.get("a"), d.get("b")], "unresolved discrepancy")
    # --- company-memory candidates (nothing is memory until a person confirms it) -------------------------------------------------
    mcs = {}

    def cand(kind, subject, statement, value=None, evidence=None, origin="code", typ=None, period=None):
        c = {"kind": kind, "type": typ or TYPE_BY_KIND[kind], "subject": subject, "subject_key": f"{kind}:{subject}", "statement": statement,
             "value": value, "period": period or (X.get("quarter_end") or "")[:7] or None, "evidence": evidence or [], "origin": origin,
             "correction_types": MEMORY_CORRECTION[kind]}
        c["id"] = "MC-" + h([c["subject_key"], c["statement"], c["value"]])
        mcs[c["id"]] = c
    for role in ("valuation_metric", "selected_multiple", "enterprise_value", "equity_value", "value_to_xpv"):
        k = cx.role_key(role)
        if k:
            v = cx.portable(k)
            cand("mapping", f"chain.{role}", f"{ROLE_LABEL[role]}: {v['role']} workbook, {quote_sheet(v['sheet'])}!{v['cell']}"
                 + (f" (row '{v['row_label']}')" if v.get("row_label") else ""), v, [v])
    if mw.get("cells"):
        v = cx.portable({"source": mw.get("source"), "cell": mw["cells"]})
        v.update(months=[mw.get("first"), mw.get("last")])
        cand("mapping", "chain.metric_window", f"12-month window: {v['role']} workbook, {quote_sheet(v['sheet'])}!{v['cell']}", v, [v])
    if ch.get("fund_cell"):
        try:
            k = cx.key(ch["fund_cell"])
            v = cx.portable(k)
            cand("mapping", "chain.fund_cell", f"Fund-reported value: {v['role']} workbook, {quote_sheet(v['sheet'])}!{v['cell']}"
                 + (f" (row '{v['row_label']}')" if v.get("row_label") else ""), v, [v])
        except ValueError:
            pass
    for it in pcs:
        if it["kind"] == "update_from_source" and it["verify"]["status"] != "contradicted":
            fr = it["rule"]["from"]
            fv = cx.portable(fr if isinstance(fr, dict) else fr[0])
            tv = cx.portable(cx.key(it["target"]))
            cand("mapping", f"source.{tv['sheet'].lower()}!{tv['cell'].lower()}",
                 f"{it['what']}: next quarter's value comes from the {fv['role']} workbook, {quote_sheet(fv['sheet'])}!{fv['cell']} "
                 f"({(it['rule'].get('class') or '').replace('_', ' ')})", {"target": tv, "from": fv, "relation": it["rule"].get("relation")}, [fv, tv])
    for kb, rule, what in revs:
        tv = cx.portable(kb)
        cand("revision", f"revision.{rule['period']}.{tv['sheet'].lower()}!{tv['cell'].lower()}",
             f"{what or 'Restated value'} for {rule['period']}: as reported {rule['as_reported_at_period']['value']}, later known "
             f"{rule['later_known_value']['value']}", {"period": rule["period"], "as_reported_at_period": rule["as_reported_at_period"],
                                                        "later_known_value": rule["later_known_value"]},
             [cx.portable(cx.key(rule["as_reported_at_period"])), tv], "agent", period=rule["period"])
    for m in s7.get("memory_candidates") or []:
        ev = m.get("evidence")
        ev = ev if isinstance(ev, list) else [ev] if ev else []
        cand(m["kind"], m["subject"], m["statement"].strip(), None, [cx.portable(e) for e in ev if isinstance(e, dict)], "agent", m.get("type"))
    # --- what company memory already says (attached with memory.py attach): matches are not proposed again, a contradiction is
    #     shown beside the new reading and becomes an unresolved decision; memory is never overridden by the run ---------------
    unchanged = []
    if MEMORY_IN is not None:
        cur = MEMORY_IN
        for cid, c in sorted(mcs.items()):
            e = cur.get(c["subject_key"])
            if not e:
                c["memory_status"] = "new"
                continue
            snap = {"entry_id": e["entry_id"], "type": e.get("type"), "statement": e.get("statement"), "value": e.get("value"),
                    "period": e.get("period") or (e.get("run") or {}).get("quarter_end"), "confirmed_by": e.get("confirmed_by")}
            if same_memory(c, e):
                unchanged.append({"subject_key": c["subject_key"], "entry_id": e["entry_id"]})
                del mcs[cid]
                continue
            c["memory_status"] = "differs"
            c["memory_entry"] = snap
            if c["kind"] == "mapping":
                cells = mapping_refs(cx, c)
                judgment(f"Company memory says '{e.get('statement')}' (confirmed by {e.get('confirmed_by')}); this run reads "
                         f"'{c['statement']}'. Which is right this quarter?", cells, "company memory contradiction")
        for it in pcs:                                   # a reviewer's own rule for this cell, shown beside it
            if it.get("target"):
                r_ = cur.get(f"analyst_rule:rule.{assumption_subject(cx, it).split(':', 1)[1]}")
                if r_:
                    it["memory_rule"] = {"entry_id": r_["entry_id"], "rule": r_.get("statement"), "period": r_.get("period"), "confirmed_by": r_.get("confirmed_by")}
        for c in mcs.values():
            r_ = cur.get(f"analyst_rule:rule.{c['subject']}")
            if r_:
                c["memory_rule"] = {"entry_id": r_["entry_id"], "rule": r_.get("statement"), "period": r_.get("period"), "confirmed_by": r_.get("confirmed_by")}
        for it in pcs:                                   # assumptions a person confirmed earlier, shown beside this quarter's value
            if it.get("always_confirm") and it.get("target"):
                sk = assumption_subject(cx, it)
                e = cur.get(sk)
                if e:
                    it["in_memory"] = {"entry_id": e["entry_id"], "value": e.get("value"), "period": e.get("period"),
                                       "confirmed_by": e.get("confirmed_by"),
                                       "matches_current": same_value(e.get("value"), (it.get("current") or {}).get("value"))}
        for jid, j in list(hjs.items()):
            e = cur.get(f"judgment:{j['decision_key']}")
            if e:
                j["in_memory"] = {"entry_id": e["entry_id"], "answer": e.get("value"), "period": e.get("period"), "confirmed_by": e.get("confirmed_by")}
                if not j.get("suggested") and e.get("value") is not None:
                    j["suggested"] = str(e.get("value"))
                    j["suggested_from"] = "company memory"
    # --- pending decisions: questions a person left unanswered in an earlier review. They come back every run, unanswered (never
    #     guessed from history), and block every change they touch; if their cells cannot be found in this run, they block all.
    by_key = {j["decision_key"]: j for j in hjs.values()}
    for pdg in MEMORY_PENDING:
        j = by_key.get(pdg["decision_key"])
        if j:
            j["pending_since"] = pdg.get("first_seen")
            if j.get("suggested_from") == "company memory":
                j["suggested"], j["suggested_from"] = None, None
            continue
        cells, lost = [], False
        for pc_ in pdg.get("cells") or []:
            r = locate(cx, pc_)
            if r:
                cells.append(r)
            else:
                lost = True
        judgment(pdg["question"], cells, f"pending since {pdg.get('first_seen')}",
                 extra={"decision_key": pdg["decision_key"], "pending_since": pdg.get("first_seen"), "blocks_all": lost,
                        "cells_not_found": lost})
    mc_list = sorted(mcs.values(), key=lambda c: (c["kind"], c["subject"], c["id"]))
    hj_list = sorted(hjs.values(), key=lambda j: j["id"])
    for it in pcs:
        touched = set()
        for ref in [it.get("target"), (it.get("rule") or {}).get("window"), (it.get("rule") or {}).get("from")] + \
                   [f.get("from") for f in (it.get("rule") or {}).get("fill_from") or []]:
            for r in (ref if isinstance(ref, list) else [ref]):
                if isinstance(r, dict):
                    touched |= cx.keys(r)
        it["blocked_by"] = sorted(j["id"] for j in hj_list if j.get("blocks_all") or any(cx.keys(c) & touched for c in j["cells_affected"]))


    vb = srcs.books[cx.cs]
    doc = {"schema": SCHEMA, "made_by": f"proposals {SCHEMA_VERSION}", "company": X.get("company"), "quarter_end": X.get("quarter_end"),
           "next_quarter_end": quarter_after(X["quarter_end"]) if X.get("quarter_end") else None,
           "valuation_workbook": {"id": cx.cs, "file": vb.file, "sha256": vb.sha256},
           "proposed_changes": pcs, "human_judgments": hj_list, "memory_candidates": mc_list, "memory_unchanged": unchanged,
           "memory_attached": MEMORY_SHA,
           "counts": {"proposed_changes": len(pcs), "human_judgments": len(hj_list), "memory_candidates": len(mc_list),
                      "by_kind": {k: sum(1 for it in pcs if it["kind"] == k) for k in KIND_ORDER if any(it["kind"] == k for it in pcs)},
                      "confirmed": sum(it["verify"]["status"] == "confirmed" for it in pcs),
                      "not_checkable": sum(it["verify"]["status"] == "not_checkable" for it in pcs),
                      "contradicted": sum(it["verify"]["status"] == "contradicted" for it in pcs),
                      "blocked": sum(1 for it in pcs if it["blocked_by"]), "revisions": len(revs),
                      "memory_unchanged": len(unchanged), "pending_from_memory": len(MEMORY_PENDING), "memory_differs": sum(1 for c in mc_list if c.get("memory_status") == "differs")}}
    G.check_doc({k: v for k, v in doc.items()}, "proposed_changes")
    return doc


def canonical(doc):
    return json.dumps(doc, sort_keys=True, indent=1, ensure_ascii=False, default=str) + "\n"


def write(run_dir, doc, inputs_sha):
    d = dict(doc, inputs_sha256=inputs_sha)
    with open(os.path.join(run_dir, "proposed_changes.json"), "w", encoding="utf-8") as fh:
        fh.write(canonical(d))
    return d


def main(argv=None):
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    for c in ("build", "show"):
        p = sub.add_parser(c)
        p.add_argument("--run-dir", default=".")
    a = ap.parse_args(argv)
    import checkpoint as CK
    if a.cmd == "build":
        try:
            d = build(a.run_dir)
        except BuildError as x:
            print(f"PROPOSALS: refused | {len(x.problems)} problem(s); nothing was written:")
            for m in x.problems[:25]:
                print(f"  - {m}")
            return 1
        write(a.run_dir, d, CK.proposals_inputs_sha(a.run_dir))
        CK.assemble(a.run_dir, "extraction")
    p = os.path.join(a.run_dir, "proposed_changes.json")
    if not os.path.exists(p):
        print("PROPOSALS: none yet - save stage 7 first")
        return 1
    d = json.load(open(p))
    c = d["counts"]
    print(f"PROPOSALS: {c['proposed_changes']} changes ({', '.join(f'{k} {v}' for k, v in c['by_kind'].items())}) | verify: {c['confirmed']} "
          f"confirmed, {c['not_checkable']} judgment, {c['contradicted']} contradicted | {c['blocked']} blocked by "
          f"{c['human_judgments']} unresolved decisions | {c['memory_candidates']} memory candidates | revisions {c['revisions']}")
    for it in d["proposed_changes"]:
        t = it.get("target") or (it.get("rule") or {}).get("window") or {}
        print(f"  {it['id']} {it['kind']:<21} {t.get('source', '')}:{t.get('cell', '')} | {it['verify']['status']}"
              + (f" | blocked by {', '.join(it['blocked_by'])}" if it["blocked_by"] else "") + f" | {it.get('what') or ''}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
