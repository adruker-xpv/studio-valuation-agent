# test_13_2_3.py - build 13.2.3 tests: the contradiction gate, the source-fingerprint lock, generated-artifact naming and identity,
# and backward compatibility. Synthetic only: the made-up five-workbook set T1 from the test bench (path given by --trial or the
# XPV_TRIAL environment variable). No real company, cell or value is used, and nothing here names a source workbook the code
# expects: source files are renamed freely, extra files are added, and the code must not care.
# Usage: python tests/test_13_2_3.py --trial <path to xpv-onboarding-testbench/trial>   (last line: TESTS: PASS (n/n))
import argparse, glob, json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.join(os.path.dirname(HERE), "scripts")
sys.path.insert(0, S)
ap = argparse.ArgumentParser()
ap.add_argument("--trial", default=os.environ.get("XPV_TRIAL", os.path.join(HERE, "..", "..", "xpv-onboarding-testbench", "trial")))
A = ap.parse_args()
TR = os.path.abspath(A.trial)
T1 = os.path.join(TR, "set-T1")
REF = os.path.join(TR, "reference", "T1")
TMP = tempfile.mkdtemp(prefix="t1323-")
RESULTS = []


def run(script, *args):
    r = subprocess.run([sys.executable, os.path.join(S, script), *args], capture_output=True, text=True, timeout=600)
    return r.stdout + r.stderr


def test(name, ok, got=""):
    RESULTS.append(bool(ok))
    print(f"- {'PASS' if ok else 'FAIL'}: {name}" + ("" if ok else f" -> {str(got)[:600]}"))


def workbooks(names=None, extra=None, edit=None):
    """a copy of T1 under new file names (kept in the same sort order so stage ids stay W1..W5), plus optional extras."""
    d = tempfile.mkdtemp(dir=TMP, prefix="wb-")
    src = sorted(glob.glob(os.path.join(T1, "*.xlsx")))
    out = []
    for i, p in enumerate(src):
        nm = (names[i] if names else os.path.basename(p))
        q = os.path.join(d, nm)
        shutil.copyfile(p, q)
        out.append(q)
    if edit is not None:
        from openpyxl import load_workbook
        i, sheet, cell, val = edit
        wb = load_workbook(out[i])
        wb[sheet][cell] = val
        wb.save(out[i])
    for e in extra or []:
        q = os.path.join(d, os.path.basename(e))
        shutil.copyfile(e, q)
        out.append(q)
    return out


def full_run(name, wbs, company="Tidewater", period="2026 Q2", n=1, s7=None, memory=None, init=True):
    rd = os.path.join(TMP, name)
    shutil.rmtree(rd, ignore_errors=True)
    os.makedirs(rd)
    o = run("xlsx_evidence.py", "inventory", "--run-dir", rd, "--workbooks", *wbs)
    if init:
        o += run("run_manifest.py", "init", "--run-dir", rd, "--company", company, "--period", period, "--run-number", str(n))
    for k in range(2, 7):
        o += run("checkpoint.py", "save", "--run-dir", rd, "--stage", str(k), "--file", glob.glob(os.path.join(REF, f"0{k}_*.json"))[0])
    if memory:
        o += run("memory.py", "attach", "--run-dir", rd, "--memory", memory)
    p = os.path.join(rd, "s7.json")
    json.dump(s7 or {}, open(p, "w"))
    o += run("checkpoint.py", "save", "--run-dir", rd, "--stage", "7", "--file", p)
    o += run("verify.py", "--run-dir", rd, "--final")
    return rd, o


def pc(rd):
    return json.load(open(os.path.join(rd, "proposed_changes.json")))


def fill(rd, decisions, out_name="Review.completed.xlsx", reviewer="Test Reviewer", notes=None):
    """decisions: {item_id: (Decision, correction or None)}; anything else stays blank."""
    from openpyxl import load_workbook
    run("review_xlsx.py", "build", "--run-dir", rd)
    wb = load_workbook(os.path.join(rd, "Review.xlsx"))
    wb["Start here"]["B6"] = reviewer
    for sn in ("Unresolved decisions", "Proposed changes", "Memory candidates"):
        ws = wb[sn]
        head = [c.value for c in ws[1]]
        di, ci, ii = head.index("Decision") + 1, head.index("Your correction") + 1, head.index("_id") + 1
        ni = head.index("Rule or note for memory") + 1
        for r in range(2, ws.max_row + 1):
            iid = ws.cell(r, ii).value
            if iid in decisions:
                d, c = decisions[iid]
                ws.cell(r, di).value = d
                if c is not None:
                    ws.cell(r, ci).value = c
            if notes and iid in notes:
                ws.cell(r, ni).value = notes[iid]
    p = os.path.join(rd, out_name)
    wb.save(p)
    return p


def ids(P, kind=None, subject=None, target=None):
    out = []
    for c in P["memory_candidates"]:
        if (kind is None or c["kind"] == kind) and (subject is None or c["subject"] == subject):
            out.append(c["id"])
    for it in P["proposed_changes"]:
        if target and (it.get("target") or {}).get("cell") == target and (kind is None or it["kind"] == kind):
            out.append(it["id"])
    return out


def clean_decisions(P):
    """approve everything that can be approved; leave decisions with no suggested answer and blocked changes blank."""
    D = {}
    for c in P["memory_candidates"]:
        D[c["id"]] = ("Approve", None)
    for it in P["proposed_changes"]:
        if not it.get("blocked_by") and it["verify"]["status"] != "contradicted":
            D[it["id"]] = ("Approve", None)
    return D


import concepts as CG  # noqa: E402
import memory as MEM  # noqa: E402
import run_manifest as RM  # noqa: E402

# ------------------------------------------------------------------------------------------------------------------------------
# N: names and identity of generated artifacts (sources stay discovery-driven)
o = run("run_manifest.py", "plan", "--company", "Tidewater", "--period", "2026 Q2")
test("N plan lists the run folders to try, Qn first then Qn_r2 ...", "2.extractor-outputs/Tidewater/2026/Q2 |" in o and "Q2_r2 |" in o, o)
for bad, why in (("tidewater co", "space"), ("Tide_water", "underscore"), ("2Tide", "digit first")):
    o = run("run_manifest.py", "plan", "--company", bad, "--period", "2026 Q2")
    test(f"N a company key with a {why} fails clearly", "RUN: refused" in o and "company key" in o, o)
for bad in ("2026 q2", "2026-Q2", "Q2 2026", "2026 Q5"):
    o = run("run_manifest.py", "plan", "--company", "Tidewater", "--period", bad)
    test(f"N period {bad!r} fails clearly", "RUN: refused" in o and "YYYY Qn" in o, o)
o = run("run_manifest.py", "open", "--run-folder", "/Shared Documents/Valuations/2.extractor-outputs/Tidewater/2026/q2")
test("N a run folder with a lower-case q fails clearly", "RUN: refused" in o and "capital Q" in o, o)
o = run("run_manifest.py", "open", "--run-folder", "/Shared Documents/Valuations/2.extractor-outputs/Tidewater/2026/Q2_r2", "--company", "tidewater")
test("N the company in the message must match the folder's exactly (case matters)", "RUN: refused" in o and "case matters" in o, o)
o = run("run_manifest.py", "open", "--run-folder", "/Shared Documents/Valuations/2.extractor-outputs/Tidewater/2026/Q2_r2", "--company", "Tidewater",
        "--period", "2026 Q2")
test("N open names the exact files to fetch and the older plain names", "Tidewater_2026_Q2_r2_extraction.json" in o and "older run uses the plain names" in o, o)

# arbitrary source file names (no workbook name, count or layout is expected by code)
# (a file another workbook links to keeps its name: an Excel link names its file - that is workbook evidence, not a code rule)
odd = ["a 01 - whatever v7 FINAL (2).xlsx", "b-Fund pack.xlsx", "Tidewater - June 2026 Management Accounts.xlsx", "Tidewater - x proforma copy.xlsx",
       "zz summary (2).xlsx"]
rdA, o = full_run("A", workbooks(odd), n=2)
M = RM.load(rdA)
test("B arbitrary source file names: the run completes VERIFIED", "VERIFY: status | VERIFIED" in o, o[-800:])
test("B the manifest records every source by its ORIGINAL file name, fingerprints and the role the AI discovered",
     sorted(f["original_file"] for f in M["sources"]["files"]) == sorted(odd)
     and all(f["sha256"] and f["content_sha256"] and f["discovered_role"] not in (None, "not yet assigned") for f in M["sources"]["files"]), M["sources"])
test("N generated artifacts follow <Company>_<YYYY>_<Qn>[_rN]_<artifact>; checkpoints keep plain names",
     os.path.exists(os.path.join(rdA, "upload", "Tidewater_2026_Q2_r2_extraction.json"))
     and os.path.exists(os.path.join(rdA, "upload", "Tidewater_2026_Q2_r2_proposed_changes.json"))
     and os.path.exists(os.path.join(rdA, "upload", "Tidewater_2026_Q2_r2_run_manifest.json"))
     and os.path.exists(os.path.join(rdA, "upload", "checkpoints", "03_chain.json"))
     and not any(os.path.basename(p).startswith("Tidewater") for p in glob.glob(os.path.join(rdA, "upload", "checkpoints", "*"))), os.listdir(os.path.join(rdA, "upload")))
test("N inside the run dir the plain names are kept (scripts and the frozen bench read them as before)",
     os.path.exists(os.path.join(rdA, "extraction.json")) and os.path.exists(os.path.join(rdA, "proposed_changes.json")))
test("N the manifest records each generated artifact's SHA-256", all(v.get("sha256") for v in M["artifacts"].values()) and "extraction.json" in M["artifacts"], M["artifacts"])
rdB, oB = full_run("A-default-names", workbooks(), n=1)
test("B the same evidence under the original names gives the same proposals (names do not drive interpretation)",
     [x["id"] for x in pc(rdA)["proposed_changes"]] == [x["id"] for x in pc(rdB)["proposed_changes"]]
     and [(x["subject_key"], CG.loc(x.get("value") if not (x.get("value") or {}).get("from") else x["value"]["from"])) for x in pc(rdA)["memory_candidates"]]
     == [(x["subject_key"], CG.loc(x.get("value") if not (x.get("value") or {}).get("from") else x["value"]["from"])) for x in pc(rdB)["memory_candidates"]])

# stage-in: fetched files back into a fresh run dir
rdS = os.path.join(TMP, "stage")
os.makedirs(rdS)
up = os.path.join(rdA, "upload")
o = run("run_manifest.py", "stage-in", "--run-dir", rdS, "--files", *glob.glob(os.path.join(up, "*.json")), *glob.glob(os.path.join(up, "checkpoints", "*.json")))
test("N stage-in maps contract names back to plain names", "STAGED:" in o and os.path.exists(os.path.join(rdS, "extraction.json"))
     and os.path.exists(os.path.join(rdS, "checkpoints", "03_chain.json")), o)
other = os.path.join(TMP, "Tidewater_2026_Q2_r3_extraction.json")
shutil.copyfile(os.path.join(up, "Tidewater_2026_Q2_r2_extraction.json"), other)
o = run("run_manifest.py", "stage-in", "--run-dir", rdS, "--files", os.path.join(up, "Tidewater_2026_Q2_r2_run_manifest.json"), other)
test("N stage-in refuses a file named for another run", "RUN: refused" in o and "belongs to run Tidewater_2026_Q2_r3" in o, o)
ed = os.path.join(TMP, "edit", "Tidewater_2026_Q2_r2_extraction.json")
os.makedirs(os.path.dirname(ed))
X = json.load(open(os.path.join(up, "Tidewater_2026_Q2_r2_extraction.json")))
X["how_it_works"] = "edited by hand"
json.dump(X, open(ed, "w"))
o = run("run_manifest.py", "stage-in", "--run-dir", rdS, "--files", os.path.join(up, "Tidewater_2026_Q2_r2_run_manifest.json"), ed)
test("N stage-in refuses an artifact whose contents are not the ones the run saved", "RUN: refused" in o and "not the ones this run saved" in o, o)
leg = os.path.join(TMP, "legacy")
os.makedirs(leg)
shutil.copyfile(os.path.join(rdB, "extraction.json"), os.path.join(leg, "extraction.json"))
rdL = os.path.join(TMP, "stage-legacy")
o = run("run_manifest.py", "stage-in", "--run-dir", rdL, "--files", os.path.join(leg, "extraction.json"))
test("C an older run's plain names are still accepted", "STAGED: 1" in o and os.path.exists(os.path.join(rdL, "extraction.json")), o)

# ------------------------------------------------------------------------------------------------------------------------------
# F: fingerprints - replaced contents, extra workbook, and the lock
rdF, o = full_run("F", workbooks(), n=1)
from openpyxl import load_workbook  # noqa: E402
src = sorted(glob.glob(os.path.join(T1, "*.xlsx")))
first_sheet = load_workbook(src[4], read_only=True).sheetnames[0]
rep = workbooks(edit=(4, first_sheet, "Z99", 12345))
o = run("xlsx_evidence.py", "inventory", "--run-dir", rdF, "--workbooks", *rep)
test("A same company and quarter, one workbook's contents replaced: the run is STOPPED and locked", "STOPPED: the source set changed" in o
     and os.path.exists(os.path.join(rdF, RM.LOCK)), o[-500:])
for script, args in (("checkpoint.py", ["status", "--run-dir", rdF]), ("checkpoint.py", ["save", "--run-dir", rdF, "--stage", "7", "--file", os.path.join(rdF, "s7.json")]),
                     ("review_xlsx.py", ["build", "--run-dir", rdF]), ("run_manifest.py", ["init", "--run-dir", rdF, "--company", "Tidewater", "--period", "2026 Q2", "--run-number", "1"])):
    o = run(script, *args)
    test(f"A while locked, {script} {args[0]} refuses and asks for a fresh onboarding", "source set changed" in o and "fresh onboarding" in o, o[-300:])
o = run("xlsx_evidence.py", "inventory", "--run-dir", rdF, "--workbooks", *sorted(glob.glob(os.path.join(T1, "*.xlsx"))))
test("A giving the original workbooks again unlocks the run (it is the same source set)", not os.path.exists(os.path.join(rdF, RM.LOCK))
     and "kept unchanged" in o and "NEXT" in run("checkpoint.py", "status", "--run-dir", rdF), o[-300:])
extra = os.path.join(TR, "workbook-11", "XPV Fund Q2 2026.xlsx")
o = run("xlsx_evidence.py", "inventory", "--run-dir", rdF, "--workbooks", *sorted(glob.glob(os.path.join(T1, "*.xlsx"))), extra)
test("C an extra source workbook in an existing run is a different source set: STOPPED, locked", "STOPPED: the source set changed" in o
     and "not in the set this run started with" in o, o[-400:])
run("xlsx_evidence.py", "inventory", "--run-dir", rdF, "--workbooks", *sorted(glob.glob(os.path.join(T1, "*.xlsx"))))
o = run("xlsx_evidence.py", "inventory", "--run-dir", rdF, "--workbooks", *sorted(glob.glob(os.path.join(T1, "*.xlsx")))[:4])
test("H a missing workbook is also a different source set (recorded, the run stops rather than guessing)",
     "STOPPED" in o and "missing or changed" in o, o[-400:])
run("xlsx_evidence.py", "inventory", "--run-dir", rdF, "--workbooks", *sorted(glob.glob(os.path.join(T1, "*.xlsx"))))
rdX, o = full_run("X-extra", workbooks(extra=[extra]), n=3, s7=None)
MX = RM.load(rdX)
test("C a NEW run with an extra workbook is inventoried by fingerprint (6 sources); code expects no fixed count",
     MX["sources"]["count"] == 6 and any(f["original_file"] == "XPV Fund Q2 2026.xlsx" for f in MX["sources"]["files"]), MX["sources"]["count"])

# ------------------------------------------------------------------------------------------------------------------------------
# G: the contradiction gate
mem = os.path.join(TMP, "mem", "Tidewater.memory.json")
os.makedirs(os.path.dirname(mem))
rdG, o = full_run("G-clean", workbooks(), n=1)
P = pc(rdG)
D = clean_decisions(P)
rv = fill(rdG, D, "Tidewater_2026_Q2_Review.completed.xlsx")
o = run("review_xlsx.py", "read", "--run-dir", rdG, "--review", rv)
test("F clean review: read with no STOPPED line", "REVIEW: accepted" in o and "STOPPED" not in o, o)
o = run("memory.py", "apply", "--run-dir", rdG, "--decisions", os.path.join(rdG, "review_decisions.json"), "--memory", mem)
m1 = MEM.load(mem)
test("F clean review: memory is created (not appended), coherent, nothing stopped", "created a new memory file" in o and "STOPPED" not in o
     and not CG.coherence(m1) and len(MEM.current(m1)) > 0, o)
test("F every entry records the run's source-set fingerprint", all((e.get("run") or {}).get("source_set_sha256") for e in m1["entries"]))
o = run("memory.py", "apply", "--run-dir", rdG, "--decisions", os.path.join(rdG, "review_decisions.json"), "--memory", mem)
test("F applying the same review again adds nothing and raises nothing", "0 entries added" in o and "STOPPED" not in o and "memory file unchanged" in o, o)
o = run("memory.py", "check", "--memory", mem)
test("F memory check reports coherence OK", "coherence OK" in o and "check OK" in o, o)
n_pending_blank = len(MEM.pending(m1))
test("F blank decisions stay pending (not memory)", n_pending_blank == sum(1 for j in P["human_judgments"]), n_pending_blank)

# F2: a later run of the same period from the same workbooks reuses memory: matches are not proposed again
rdG2, o = full_run("G-r2", workbooks(), n=2, memory=mem)
P2 = pc(rdG2)
test("F reuse: same period, same workbooks: confirmed matches are not proposed again", P2["counts"]["memory_unchanged"] > 0
     and P2["counts"]["memory_candidates"] < P["counts"]["memory_candidates"] and not P2["memory_not_used_sources_replaced"], P2["counts"])
test("F reuse: pending decisions are surfaced at the start", "PENDING:" in o and f"{n_pending_blank} decision(s) still open" in o, o[-600:])
D2 = clean_decisions(P2)
rv2 = fill(rdG2, D2, "Tidewater_2026_Q2_r2_Review.completed.xlsx")
o = run("review_xlsx.py", "read", "--run-dir", rdG2, "--review", rv2)
o += run("memory.py", "apply", "--run-dir", rdG2, "--decisions", os.path.join(rdG2, "review_decisions.json"), "--memory", mem)
test("F reuse: re-confirming the same values is not a contradiction", "STOPPED" not in o and "appended" in o or "unchanged" in o, o)

# A2: replaced sources, same period, fresh run: memory confirmed from the old set is not reused
rdR, o = full_run("R-replaced", rep, n=3, memory=mem)
PR = pc(rdR)
test("A memory confirmed for this period from replaced workbooks is not used (comes back for confirmation), and says so",
     "sources were replaced" in o and PR["memory_not_used_sources_replaced"] and PR["counts"]["memory_unchanged"] == 0, (o[-500:], PR["counts"]))

# D: same concept, conflicting values (code mapping corrected to another cell, the change at the old cell approved)
mem2 = os.path.join(TMP, "mem2", "Tidewater.memory.json")
os.makedirs(os.path.dirname(mem2))
rdD, o = full_run("D-conflict", workbooks(), n=1)
P = pc(rdD)
D = clean_decisions(P)
ev = ids(P, "mapping", "chain.enterprise_value")[0]
pc_ev = ids(P, "keep_formula", target="Valuation!D8")[0]
D[ev] = ("Correct", "W1:Valuation!D11")
rv = fill(rdD, D)
o = run("review_xlsx.py", "read", "--run-dir", rdD, "--review", rv)
ac = json.load(open(os.path.join(rdD, "approved_changes.json")))
test("D one concept confirmed with two values in one review: STOPPED at read", "STOPPED: 1 concept" in o and "conflict" in o, o)
test("D the conflicting approved change is not handed on in approved_changes.json", pc_ev not in [x["id"] for x in ac["approved_changes"]]
     and pc_ev in ac["stopped"], ac.get("stopped"))
o = run("memory.py", "apply", "--run-dir", rdD, "--decisions", os.path.join(rdD, "review_decisions.json"), "--memory", mem2)
m2 = MEM.load(mem2)
test("D neither competing value is written; the rest of the review is", "mapping:chain.enterprise_value" not in MEM.current(m2)
     and "mapping:chain.equity_value" in MEM.current(m2), sorted(MEM.current(m2)))
pd2 = MEM.pending(m2)
cg = [x for x in pd2 if x["decision_key"].startswith("CG-")]
test("D the concept returns to the analyst as a pending decision showing both values", len(cg) == 1 and "Contradiction" in cg[0]["question"]
     and "valuation!d8" in cg[0]["question"].lower() and "valuation!d11" in cg[0]["question"].lower(), [x["question"] for x in cg])
test("D final memory holds one coherent confirmed state per concept", not CG.coherence(m2), CG.coherence(m2))
rdD2, o = full_run("D-next", workbooks(), n=2, memory=mem2)
P = pc(rdD2)
hj = [j for j in P["human_judgments"] if (j.get("decision_key") or "").startswith("CG-")]
test("D next run: the stopped concept comes back as an unresolved decision, and blocks the changes on its cells",
     len(hj) == 1 and any(hj[0]["id"] in (it.get("blocked_by") or []) for it in P["proposed_changes"]), [j["question"] for j in hj])

# D2: two agent rules on the same subject with different wording, both approved
s7 = {"memory_candidates": [{"kind": "source_precedence", "subject": "precedence.cash", "statement": "Cash comes from the company balance sheet.",
                             "evidence": [{"source": "W3", "cell": "'Balance Sheet'!T8"}]},
                            {"kind": "source_precedence", "subject": "precedence.cash", "statement": "Cash comes from the XPV monthly summary.",
                             "evidence": [{"source": "W5", "cell": "Summary!B5"}]}]}
rdD3, o = full_run("D-rules", workbooks(), n=1, s7=s7)
P = pc(rdD3)
test("D2 setup: both rules are proposed", len(ids(P, "source_precedence")) == 2, (o[-600:], [c["subject"] for c in P["memory_candidates"]]))
D = clean_decisions(P)
rv = fill(rdD3, D)
o = run("review_xlsx.py", "read", "--run-dir", rdD3, "--review", rv)
mem3 = os.path.join(TMP, "mem3", "Tidewater.memory.json")
os.makedirs(os.path.dirname(mem3))
o += run("memory.py", "apply", "--run-dir", rdD3, "--decisions", os.path.join(rdD3, "review_decisions.json"), "--memory", mem3)
m3 = MEM.load(mem3)
test("D2 two different approved rules for one subject: neither is written, the concept is pending", "STOPPED" in o
     and "source_precedence:precedence.cash" not in MEM.current(m3) and any(x["decision_key"].startswith("CG-") for x in MEM.pending(m3)), o)

# D3: against memory in force for the same period, a person's own rule that says something else (not shown side by side)
rdN, _ = full_run("N1", workbooks(), n=1)
PN = pc(rdN)
mem4 = os.path.join(TMP, "mem4", "Tidewater.memory.json")
os.makedirs(os.path.dirname(mem4))
mult = ids(PN, "carry_forward", target="Valuation!D7")[0]
kf = ids(PN, "keep_formula", target="Valuation!D8")[0]
rv = fill(rdN, {mult: ("Approve", None), kf: ("Approve", None)}, notes={kf: "Keep the multiple unless the comps move by more than a turn."})
run("review_xlsx.py", "read", "--run-dir", rdN, "--review", rv)
o = run("memory.py", "apply", "--run-dir", rdN, "--decisions", os.path.join(rdN, "review_decisions.json"), "--memory", mem4)
test("D3 setup: the person's rule is written", "STOPPED" not in o and any(k.startswith("analyst_rule:") for k in MEM.current(MEM.load(mem4))), o)
rdN2, _ = full_run("N2", workbooks(), n=2, memory=mem4)
PN2 = pc(rdN2)
kf2 = ids(PN2, "keep_formula", target="Valuation!D8")[0]
rv = fill(rdN2, {kf2: ("Approve", None)}, notes={kf2: "Reset the multiple to the comps median every quarter."})
o = run("review_xlsx.py", "read", "--run-dir", rdN2, "--review", rv)
o += run("memory.py", "apply", "--run-dir", rdN2, "--decisions", os.path.join(rdN2, "review_decisions.json"), "--memory", mem4)
m4 = MEM.load(mem4)
rule = [e for k, e in MEM.current(m4).items() if k.startswith("analyst_rule:")]
test("D3 a rule that contradicts memory in force for the same period stops; memory keeps the earlier one, both shown as pending",
     "STOPPED" in o and len(rule) == 1 and "Keep the multiple" in rule[0]["statement"]
     and any("reset the multiple" in x["question"].lower() for x in MEM.pending(m4)), o)
test("D3 the multiple confirmed earlier for this period stays in memory (13.2.5: reused, not asked again)", any(k.startswith("assumption_value:") for k in MEM.current(m4)))

# E: identity uncertain stays pending, never merged
s7 = {"memory_candidates": [{"kind": "adjustment_rule", "subject": "addback.integration", "statement": "Integration costs are added back every month.",
                             "evidence": [{"source": "W1", "cell": "Valuation!D6"}]},
                            {"kind": "method_note", "subject": "addback.integration", "statement": "Integration costs are added back only in Q2.",
                             "evidence": [{"source": "W1", "cell": "Valuation!D6"}]},
                            {"kind": "mapping", "subject": "headline.ev", "statement": "The headline EV lives on the Valuation sheet.",
                             "evidence": [{"source": "W1", "cell": "Valuation!D8"}]}]}
rdE, o = full_run("E-uncertain", workbooks(), n=1, s7=s7)
P = pc(rdE)
D = clean_decisions(P)
rv = fill(rdE, D)
o = run("review_xlsx.py", "read", "--run-dir", rdE, "--review", rv)
mem5 = os.path.join(TMP, "mem5", "Tidewater.memory.json")
os.makedirs(os.path.dirname(mem5))
o += run("memory.py", "apply", "--run-dir", rdE, "--decisions", os.path.join(rdE, "review_decisions.json"), "--memory", mem5)
m5 = MEM.load(mem5)
cur5 = MEM.current(m5)
test("E the same subject under two kinds of rule with different wording: not merged, neither written, asked as same-or-different",
     "adjustment_rule:addback.integration" not in cur5 and "method_note:addback.integration" not in cur5
     and any("Same item or different" in x["question"] for x in MEM.pending(m5)), (o, sorted(cur5)))
test("E two different chain items placed on one cell: not merged, neither written, asked",
     "mapping:headline.ev" not in cur5 and "mapping:chain.enterprise_value" not in cur5, sorted(cur5))
test("E items with no identity question still go ahead", "mapping:chain.equity_value" in cur5, sorted(cur5))
test("E memory stays coherent", not CG.coherence(m5), CG.coherence(m5))

# G: distinct periods / distinct concepts are never a question (unit level, no company material)
L = lambda sh, c: {"role": "company_valuation", "sheet": sh, "cell": c}
cl = [
    {"item": "a", "item_type": "memory", "kind": "mapping", "concept": "mapping:chain.equity_value", "subject": "chain.equity_value",
     "value": CG.loc(L("Valuation", "D11")), "cells": [L("Valuation", "D11")], "period": "2026-06", "source": "review"},
    {"item": "b", "item_type": "memory", "kind": "mapping", "concept": "mapping:prior.equity_value", "subject": "prior.equity_value",
     "value": CG.loc(L("Valuation - Prior Period", "D11")), "cells": [], "period": "2026-06", "source": "review"},
    {"item": "c", "item_type": "memory", "kind": "mapping", "concept": "mapping:fund.cap_table", "subject": "fund.cap_table",
     "value": ("loc", "fund_valuation", "cap table", "C9"), "cells": [], "period": "2026-06", "source": "review"}]
g = CG.gate(cl)
test("G a current valuation, a complete-looking prior-period valuation and an embedded earlier cap table are three concepts: no question",
     not g["groups"], g)
memf = {"value:value.valuation!d7": {"entry_id": "ME-1", "kind": "assumption_value", "subject_key": "assumption_value:value.valuation!d7",
                                      "value": 9.0, "period": "2026-03", "evidence": [L("Valuation", "D7")]}}
cl2 = [{"item": "m", "item_type": "proposal", "kind": "assumption_value", "concept": "value:value.valuation!d7", "subject": "value.valuation!d7",
        "value": ("num", 9.5), "cells": [L("Valuation", "D7")], "period": "2026-06", "source": "review"}]
test("G a different value confirmed for a later period supersedes; it is not a contradiction", not CG.gate(cl2, memf)["groups"])
memf["value:value.valuation!d7"]["period"] = "2026-06"
test("G the same period with a different value, not shown side by side, is a contradiction", CG.gate(cl2, memf)["counts"]["conflict"] == 1)
cl2[0]["memory_status"] = "differs"
test("G ... unless the person was shown memory beside it and chose", not CG.gate(cl2, memf)["groups"])
test("G numbers compare as Excel stores them (15 significant digits), never with a business tolerance",
     CG.num15(0.1 + 0.2) == CG.num15(0.3) and CG.num15(11.071081) != CG.num15(11.07108))

# I: incoherent memory from before the gate (one review wrote two values for one subject) is refused, never patched
bad = json.loads(json.dumps(m1))
e0 = next(e for e in bad["entries"] if e["kind"] == "mapping")
dup = dict(e0, value=dict(e0["value"], cell="Z1"), seq=len(bad["entries"]) + 1, prev_hash=bad["entries"][-1]["entry_hash"])
dup.pop("entry_hash")
dup["entry_hash"] = MEM.entry_hash(dup)
bad["entries"].append(dup)
badp = os.path.join(TMP, "bad", "Tidewater.memory.json")
os.makedirs(os.path.dirname(badp))
json.dump(bad, open(badp, "w"))
o = run("memory.py", "check", "--memory", badp)
test("I memory check finds competing values written by one review (the pre-13.2.3 failure)", "coherence FAILED" in o and "one review" in o, o)
o = run("memory.py", "apply", "--run-dir", rdG, "--decisions", os.path.join(rdG, "review_decisions.json"), "--memory", badp)
test("I a review cannot add to an incoherent memory file; it says to move it aside and rebuild", "competing confirmed values" in o
     and "Move it aside" in o and json.load(open(badp)) == bad, o)
o = run("memory.py", "attach", "--run-dir", rdG2, "--memory", badp)
test("I attaching an incoherent memory warns", "WARNING" in o and "competing confirmed values" in o, o)

# W: review identity
o = run("review_xlsx.py", "read", "--run-dir", rdG, "--review", rv2)
test("W a review named for another run is refused", "REVIEW: refused" in o and "named for run Tidewater_2026_Q2_r2" in o, o)
plain = os.path.join(TMP, "Review.completed.xlsx")
shutil.copyfile(rv2, plain)
o = run("review_xlsx.py", "read", "--run-dir", rdG, "--review", plain)
test("W a review built for another run is refused even under a plain name", "REVIEW: refused" in o and ("built for run" in o or "snapshot missing" in o), o)

# C: backward compatibility - a run with no manifest behaves as before
rdO, o = full_run("O-old", workbooks(), init=False)
test("C a run with no manifest keeps the plain UPLOAD names of 13.2.2", "UPLOAD: checkpoints/07_proposals.json, extraction.json, proposed_changes.json" in o, o[-700:])
old = json.loads(json.dumps(m1))
for e in old["entries"]:
    e["run"].pop("source_set_sha256", None)
    e.pop("entry_hash")
prev = "0" * 64
for e in old["entries"]:
    e["prev_hash"] = prev
    e["entry_hash"] = MEM.entry_hash(e)
    prev = e["entry_hash"]
oldp = os.path.join(TMP, "old", "Tidewater.memory.json")
os.makedirs(os.path.dirname(oldp))
json.dump(old, open(oldp, "w"))
o = run("memory.py", "attach", "--run-dir", rdG2, "--memory", oldp)
test("C older memory entries with no source fingerprint are used and flagged", "no source fingerprint: used, and flagged" in o, o)

n = len(RESULTS)
print(f"TESTS: {'PASS' if all(RESULTS) else 'FAIL'} ({sum(RESULTS)}/{n})")
shutil.rmtree(TMP, ignore_errors=True)
sys.exit(0 if all(RESULTS) else 1)
