# test_13_2_5.py - build 13.2.5 P0 regression suite (synthetic T1 only; helpers as in test_13_2_3.py)
# test_13_2_3.py - build 13.2.3 tests: the contradiction gate, the source-fingerprint lock, generated-artifact naming and identity,
# and backward compatibility. Synthetic only: the made-up five-workbook set T1 from the test bench (path given by --trial or the
# XPV_TRIAL environment variable). No real company, cell or value is used, and nothing here names a source workbook the code
# expects: source files are renamed freely, extra files are added, and the code must not care.
# Usage: python tests/test_13_2_3.py --trial <path to xpv-onboarding-testbench/trial>   (last line: TESTS: PASS (n/n))
import argparse, glob, json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.join(os.path.dirname(HERE), "scripts")
sys.path.insert(0, S)
ap = argparse.ArgumentParser()
ap.add_argument("--trial", default=os.environ.get("XPV_TRIAL", os.path.join(HERE, "..", "..", "xpv-onboarding-testbench", "trial")))
A = ap.parse_args()
TR = os.path.abspath(A.trial)
T1 = os.path.join(TR, "set-T1")
REF = os.path.join(TR, "reference", "T1")
TMP = tempfile.mkdtemp(prefix="t1325-")
RESULTS = []


def run(script, *args):
    r = subprocess.run([sys.executable, os.path.join(S, script), *args], capture_output=True, text=True, timeout=600)
    return r.stdout + r.stderr


def test(name, ok, got=""):
    RESULTS.append(bool(ok))
    print(f"- {'PASS' if ok else 'FAIL'}: {name}" + ("" if ok else f" -> {str(got)[:600]}"))


def workbooks(names=None, extra=None, edit=None):
    """a copy of T1 under new file names (kept in the same sort order so stage ids stay W1..W5), plus optional extras."""
    d = tempfile.mkdtemp(dir=TMP, prefix="wb-")
    src = sorted(glob.glob(os.path.join(T1, "*.xlsx")))
    out = []
    for i, p in enumerate(src):
        nm = (names[i] if names else os.path.basename(p))
        q = os.path.join(d, nm)
        shutil.copyfile(p, q)
        out.append(q)
    if edit is not None:
        from openpyxl import load_workbook
        i, sheet, cell, val = edit
        wb = load_workbook(out[i])
        wb[sheet][cell] = val
        wb.save(out[i])
    for e in extra or []:
        q = os.path.join(d, os.path.basename(e))
        shutil.copyfile(e, q)
        out.append(q)
    return out


def full_run(name, wbs, company="Tidewater", period="2026 Q2", n=1, s7=None, memory=None, init=True):
    rd = os.path.join(TMP, name)
    shutil.rmtree(rd, ignore_errors=True)
    os.makedirs(rd)
    o = run("xlsx_evidence.py", "inventory", "--run-dir", rd, "--workbooks", *wbs)
    if init:
        o += run("run_manifest.py", "init", "--run-dir", rd, "--company", company, "--period", period, "--run-number", str(n))
    for k in range(2, 7):
        o += run("checkpoint.py", "save", "--run-dir", rd, "--stage", str(k), "--file", glob.glob(os.path.join(REF, f"0{k}_*.json"))[0])
    if memory:
        o += run("memory.py", "attach", "--run-dir", rd, "--memory", memory)
    p = os.path.join(rd, "s7.json")
    json.dump(s7 or {}, open(p, "w"))
    o += run("checkpoint.py", "save", "--run-dir", rd, "--stage", "7", "--file", p)
    o += run("verify.py", "--run-dir", rd, "--final")
    return rd, o


def pc(rd):
    return json.load(open(os.path.join(rd, "proposed_changes.json")))


def fill(rd, decisions, out_name="Review.completed.xlsx", reviewer="Test Reviewer", notes=None):
    """decisions: {item_id: (Decision, correction or None)}; anything else stays blank."""
    from openpyxl import load_workbook
    run("review_xlsx.py", "build", "--run-dir", rd)
    wb = load_workbook(os.path.join(rd, "Review.xlsx"))
    wb["Start here"]["B6"] = reviewer
    for sn in ("Unresolved decisions", "Proposed changes", "Memory candidates"):
        ws = wb[sn]
        head = [c.value for c in ws[1]]
        di, ci, ii = head.index("Decision") + 1, head.index("Your correction") + 1, head.index("_id") + 1
        ni = head.index("Rule or note for memory") + 1
        for r in range(2, ws.max_row + 1):
            iid = ws.cell(r, ii).value
            if iid in decisions:
                d, c = decisions[iid]
                ws.cell(r, di).value = d
                if c is not None:
                    ws.cell(r, ci).value = c
            if notes and iid in notes:
                ws.cell(r, ni).value = notes[iid]
    p = os.path.join(rd, out_name)
    wb.save(p)
    return p


def ids(P, kind=None, subject=None, target=None):
    out = []
    for c in P["memory_candidates"]:
        if (kind is None or c["kind"] == kind) and (subject is None or c["subject"] == subject):
            out.append(c["id"])
    for it in P["proposed_changes"]:
        if target and (it.get("target") or {}).get("cell") == target and (kind is None or it["kind"] == kind):
            out.append(it["id"])
    return out


def clean_decisions(P):
    """approve everything that can be approved; leave decisions with no suggested answer and blocked changes blank."""
    D = {}
    for c in P["memory_candidates"]:
        D[c["id"]] = ("Approve", None)
    for it in P["proposed_changes"]:
        if not it.get("blocked_by") and it["verify"]["status"] != "contradicted":
            D[it["id"]] = ("Approve", None)
    return D



import memory as MEM  # noqa: E402
import run_manifest as RM  # noqa: E402
import concepts as CG  # noqa: E402
WB = sorted(glob.glob(os.path.join(T1, "*.xlsx")))
S7G = {"question_groups": [{"primary": "D1", "members": ["Q2"], "why": "the fund/company gap and the LP-report question are one decision"}],
       "human_judgments": [{"question": "Which multiple did the fund approve for its own calculation?", "cells_affected": [{"source": "W2", "cell": "'Fund Calc'!D5"}]}]}


def review_cycle(rd, mem, decide=None, blank=()):
    P = pc(rd)
    D = clean_decisions(P)
    for j in P["human_judgments"]:
        if j["id"] not in blank:
            D[j["id"]] = ("Correct", "the company workbook value") if not j.get("suggested") else ("Approve", None)
    D.update(decide or {})
    for b in blank:
        D.pop(b, None)
    rv = fill(rd, D, f"{RM.load(rd)['run_id']}_Review.completed.xlsx")
    o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", rv)
    o += run("memory.py", "apply", "--run-dir", rd, "--decisions", os.path.join(rd, "review_decisions.json"), "--memory", mem)
    return o, P


# 8 / 13 run allocation from a listing, names only
listing = {"value": [{"Name": "Q2", "IsFolder": True}, {"{Name}": "Q2_r2", "{IsFolder}": True}, {"Name": "Q1"}, {"Name": "Q2_r3_notes.txt"}]}
n, taken, f = RM.allocate("Tidewater", "2026 Q2", listing)
test("8 allocate picks the next run number from the listing's folder names", n == 3 and taken == [1, 2] and f["run"].endswith("/Tidewater/2026/Q2_r3"), (n, taken))
test("8 an empty / missing year folder gives run 1", RM.allocate("Tidewater", "2026 Q2", None)[0] == 1 and RM.allocate("Tidewater", "2026 Q2", [])[0] == 1)
try:
    RM.allocate("Tidewater", "2026 Q2", ["q2_r2"])
    ok = False
except RM.ManifestError as x:
    ok = "wrong case" in str(x)
test("8 a folder in the wrong case is refused, not silently skipped", ok)
o = run("run_manifest.py", "allocate", "--company", "Tidewater", "--period", "2026 Q2")
test("8 allocate refuses to run without a listing (no guessed-path probing)", "RUN: refused" in o and "Never probe guessed paths" in o, o)
lp = os.path.join(TMP, "listing.json")
json.dump([{"Name": "Q2", "Path": "/Shared Documents/Valuations/2.extractor-outputs/Tidewater/2026/Q2/Tidewater_2026_Q2_run_manifest.json"}], open(lp, "w"))
o = run("run_manifest.py", "allocate", "--company", "Tidewater", "--period", "2026 Q2", "--listing", lp)
test("13 allocation reads names only: a listing that points at an earlier run's manifest opens nothing (the path does not exist here)",
     "RUN ALLOCATED: run number 2" in o, o)

# 1 / 2 active-run context and attachment reuse
rdA, o = full_run("A", workbooks(), n=1)
o = run("run_manifest.py", "context", "--run-dir", rdA, "--search")
test("1 same conversation: the active run and all its workbooks are found unchanged; nothing to ask", "ACTIVE RUN: Tidewater_2026_Q2" in o
     and "sources 5/5 still here" in o and "WORKBOOKS:" in o and "NEED ONLY" not in o, o)
paths = json.load(open(os.path.join(rdA, ".paths.json")))
gone = sorted(paths.items())[2]
moved = os.path.join(TMP, "moved")
os.makedirs(moved)
shutil.move(gone[1], os.path.join(moved, "renamed copy.xlsx"))
o = run("run_manifest.py", "context", "--run-dir", rdA, "--search", moved)
test("1 a workbook moved or renamed in this conversation is still found by its fingerprint", "sources 5/5" in o and "renamed copy.xlsx" in o, o)
os.remove(os.path.join(moved, "renamed copy.xlsx"))
o = run("run_manifest.py", "context", "--run-dir", rdA, "--search")
orig = json.load(open(os.path.join(rdA, "checkpoints", "01_sources.json")))["sources"]
gname = next(s_["file"] for s_ in orig if s_["id"] == gone[0])
test("2 a missing workbook: only that one is asked for", "sources 4/5" in o and f"NEED ONLY: {gname}" in o and o.count(".xlsx") == 1, o)
o = run("run_manifest.py", "context", "--run-dir", os.path.join(TMP, "nothing-here"))
test("1 no active run: the message must give Company and Period", "ACTIVE RUN: none" in o, o)
rep = workbooks(edit=(4, __import__("openpyxl").load_workbook(WB[4], read_only=True).sheetnames[0], "Z99", 7))
rdL, _ = full_run("L", workbooks(), n=1)
o = run("xlsx_evidence.py", "inventory", "--run-dir", rdL, "--workbooks", *rep)
test("3 source replacement still locks the run", "STOPPED: the source set changed" in o)

# 6 / 7 materiality
o = run("checkpoint.py", "sufficiency", "--run-dir", rdA)
test("6 once the material chain is established and verified: SUFFICIENT, stop tracing, defer the rest", "MATERIAL CHAIN: SUFFICIENT" in o
     and "deferred" in o, o)
test("7 an open material difference is named as worth tracing (or asking)", "OPEN MATERIAL: D1" in o, o)
rdP = os.path.join(TMP, "partial")
os.makedirs(rdP)
run("xlsx_evidence.py", "inventory", "--run-dir", rdP, "--workbooks", *workbooks())
for k in (2, 3):
    run("checkpoint.py", "save", "--run-dir", rdP, "--stage", str(k), "--file", glob.glob(os.path.join(REF, f"0{k}_*.json"))[0])
o = run("checkpoint.py", "sufficiency", "--run-dir", rdP)
test("7 before upstream sources and checks: NOT YET, and says what to trace toward", "MATERIAL CHAIN: NOT YET" in o and "stage 4" in o, o)

# 4 / 5 semantic question deduplication
rdG, o = full_run("G", workbooks(), n=1, s7=S7G)
P = pc(rdG)
qs = [j["question"] for j in P["human_judgments"]]
prim = next(j for j in P["human_judgments"] if j["question"].startswith("D1:"))
test("4 one driver difference: the duplicate question is merged into one decision, which lists what it also settles",
     len(P["human_judgments"]) == 4 and len(P["consolidated_judgments"]) == 1 and prim.get("also_resolves")
     and "28,731" in prim["also_resolves"][0]["question"] and not any("28,731" in q for q in qs), (qs, P["question_groups"]))
test("4 the merged question's keys stay traceable on the primary", P["consolidated_judgments"][0]["decision_key"] in prim["also_keys"])
test("5 a similar but distinct question (different cells) stays separate", any(q.startswith("Which multiple did the fund approve") for q in qs))
rdG5, o = full_run("G5", workbooks(), n=1, s7={"question_groups": [{"primary": "D1", "members": ["J1"], "why": "looks related"}],
                                             "human_judgments": S7G["human_judgments"]})
P5 = pc(rdG5)
test("5 a group whose member shares no cell with the primary is refused and both stay separate", len(P5["consolidated_judgments"]) == 0
     and any(k["reason"].startswith("no cell in common") for g in P5["question_groups"] for k in g["kept_separate"]), P5["question_groups"])
rdS, o = full_run("Sbad", workbooks(), n=1, s7={"question_groups": [{"primary": "D1"}]})
test("4 a malformed question group is refused at save", "question_groups[0]" in o, o[-400:])

# 12 memory reuse: reviewed run -> identical fresh run
mem = os.path.join(TMP, "mem", "Tidewater.memory.json")
os.makedirs(os.path.dirname(mem))
blank = next(j["id"] for j in P["human_judgments"] if j["origin"] == "stage 6 open question" and "v3" in j["question"])
o, P1 = review_cycle(rdG, mem, blank=[blank])
test("12 setup: first review accepted, memory created, one deliberate blank", "REVIEW: accepted" in o and "created a new memory file" in o, o)
m1 = MEM.load(mem)
test("12 the merged answer is recorded for the question it settles too", all(f"judgment:{k}" in MEM.current(m1) for k in prim["also_keys"]))
rdR, o = full_run("R", workbooks(), n=2, s7=S7G, memory=mem)
P2 = pc(rdR)
rs = P2["review_summary"]
n1 = len(P1["human_judgments"]) + len(P1["memory_candidates"]) + len([x for x in P1["proposed_changes"] if not x.get("reused_from_memory")])
n2 = len(P2["human_judgments"]) + len(P2["memory_candidates"]) + len([x for x in P2["proposed_changes"] if not x.get("reused_from_memory")])
test("12 confirmed decisions answered for this period are reused, not asked again", rs["reused_detail"]["answered_decisions"] >= 2
     and not any(j["question"].startswith("D1:") for j in P2["human_judgments"]), (rs, [j["question"][:40] for j in P2["human_judgments"]]))
test("12 the confirmed multiple for this period is reused, not asked again", rs["reused_detail"]["confirmed_values"] >= 1, rs)
test("12 the deliberate blank stays pending and is the only decision left", rs["pending_carried_forward"] == 1
     and len(P2["human_judgments"]) == 1 and "v3" in P2["human_judgments"][0]["question"], [j["question"][:50] for j in P2["human_judgments"]])
test("12 materially fewer items to review on the identical rerun", n2 <= n1 // 2, (n1, n2))
test("12 the summary separates reused / pending / reopened / new", rs["reopened_by_changed_evidence"] == 0 and rs["new_decisions"] == 0, rs)
o = run("review_xlsx.py", "build", "--run-dir", rdR)
from openpyxl import load_workbook  # noqa: E402
wbR = load_workbook(os.path.join(rdR, "Review.xlsx"))
test("12 reused items are listed read-only, with no decision asked", "Reused from memory" in wbR.sheetnames
     and wbR["Reused from memory"].max_row >= 3 + rs["reused_detail"]["answered_decisions"], wbR.sheetnames)
o, _ = review_cycle(rdR, mem, blank=[P2["human_judgments"][0]["id"]])
ac = json.load(open(os.path.join(rdR, "approved_changes.json")))
test("12 reused items flow into approved changes as reused (not lost)", any(a.get("reused_from_memory") for a in ac["approved_changes"])
     and any(a["decision"] == "Reused" for a in ac["decisions_answered"]), [a["decision"] for a in ac["decisions_answered"]])
test("12 the blank is still pending after the second review", any("v3" in x["question"] for x in MEM.pending(MEM.load(mem))))
s7c = dict(S7G, human_judgments=S7G["human_judgments"] + [{"question": "Is the bridge cash the audited figure?", "cells_affected": [{"source": "W1", "cell": "Valuation!D9"}]}])
rdC, o = full_run("C", workbooks(), n=3, s7=s7c, memory=mem)
PC = pc(rdC)
test("12 confirmed memory never suppresses a new question", any(j["question"].startswith("Is the bridge cash") for j in PC["human_judgments"])
     and PC["review_summary"]["new_decisions"] >= 1, [j["question"][:40] for j in PC["human_judgments"]])
s7m = {"memory_candidates": [{"kind": "mapping", "subject": "chain.enterprise_value", "statement": "EV lives elsewhere now.",
                              "evidence": [{"source": "W1", "cell": "Valuation!D11"}]}]}
mm = MEM.load(mem)
test("12 setup: memory has the EV location", "mapping:chain.enterprise_value" in MEM.current(mm))

# precedence consistency
s7p = {"memory_candidates": [{"kind": "source_precedence", "subject": "precedence.cash", "statement": "Cash: the balance sheet wins.",
                              "evidence": [{"source": "W3", "cell": "'Balance Sheet'!T8"}]},
                             {"kind": "source_precedence", "subject": "precedence.cash", "statement": "Cash: the monthly summary wins.",
                              "evidence": [{"source": "W5", "cell": "Summary!B5"}]}]}
rdQ, o = full_run("Q", workbooks(), n=1, s7=s7p)
PQ = pc(rdQ)
test("P two different source-precedence rules for one subject become one decision before review", any(j["origin"] == "conflicting rules in this run" for j in PQ["human_judgments"])
     and all(c.get("conflicts_with") for c in PQ["memory_candidates"] if c["kind"] == "source_precedence"), [j["origin"] for j in PQ["human_judgments"]])
memq = os.path.join(TMP, "memq", "Tidewater.memory.json")
os.makedirs(os.path.dirname(memq))
rdQ1, _ = full_run("Q1", workbooks(), n=1, s7={"memory_candidates": s7p["memory_candidates"][:1]})
review_cycle(rdQ1, memq)
rdQ2, o = full_run("Q2", workbooks(), n=2, s7={"memory_candidates": s7p["memory_candidates"][1:]}, memory=memq)
PQ2 = pc(rdQ2)
test("P a precedence rule that differs from confirmed memory reopens as a decision (memory shown beside it)",
     any(j["origin"] == "company memory contradiction" and "balance sheet wins" in j["question"] for j in PQ2["human_judgments"])
     and PQ2["review_summary"]["reopened_by_changed_evidence"] >= 1, [j["question"][:60] for j in PQ2["human_judgments"]])
eid = next(e["entry_id"] for e in MEM.current(MEM.load(memq)).values() if e["kind"] == "source_precedence")
rdQ3, o = full_run("Q3", workbooks(), n=3, memory=memq, s7={"memory_candidates": [dict(s7p["memory_candidates"][0], statement="Cash comes from the balance sheet first.", same_as_memory=eid)]})
PQ3 = pc(rdQ3)
test("P a reworded restatement of a confirmed rule on the same evidence is reused, not re-asked", not any(c["kind"] == "source_precedence" for c in PQ3["memory_candidates"])
     and any(u.get("restated_by_agent") for u in PQ3["memory_unchanged"]), PQ3["memory_candidates"])
rdQ4, o = full_run("Q4", workbooks(), n=4, memory=memq, s7={"memory_candidates": [dict(s7p["memory_candidates"][0], statement="Cash comes from the summary.",
                                                                                         evidence=[{"source": "W5", "cell": "Summary!B5"}], same_as_memory=eid)]})
PQ4 = pc(rdQ4)
test("P same_as_memory with different evidence is NOT reused: it reopens", any(c["kind"] == "source_precedence" and c.get("memory_status") == "differs" for c in PQ4["memory_candidates"]))

# 9 artifact UX and review package
o = run("run_manifest.py", "resources", "--run-dir", rdR)
test("9 resources lists only durable locations: run folder, review package, memory", "RESOURCE: run folder | /Shared Documents/Valuations/2.extractor-outputs/Tidewater/2026/Q2_r2" in o
     and "RESOURCE: review package | /Shared Documents/Valuations/4.human_review/Tidewater/2026/Q2_r2" in o and "upload" not in o and "checkpoint" not in o, o)
up = os.listdir(os.path.join(rdR, "upload", "review_package"))
test("11 the review package is saved together under contract names in the human-review folder",
     sorted(up) == sorted(["Tidewater_2026_Q2_r2_Review.xlsx", "Tidewater_2026_Q2_r2_Review.completed.xlsx", "Tidewater_2026_Q2_r2_review_decisions.json",
                           "Tidewater_2026_Q2_r2_approved_changes.json", "Tidewater_2026_Q2_r2_review_package.json"]), up)
M = RM.load(rdR)
test("11 the manifest records the review package: names, hashes, snapshot, reviewer, attachment name kept as a note only",
     M["review_package"]["completed_review"] == "Tidewater_2026_Q2_r2_Review.completed.xlsx" and M["review_package"]["snapshot_sha256"]
     and M["review_package"]["reviewer"] == "Test Reviewer", M.get("review_package"))
o = run("review_xlsx.py", "read", "--run-dir", rdR, "--review", os.path.join(rdA, "Review.xlsx") if os.path.exists(os.path.join(rdA, "Review.xlsx")) else WB[0])
test("14 every review read says exactly which file it read (name, SHA-256, made by, snapshot, run)", o.startswith("REVIEW INPUT:") and "sha256" in o and "snapshot" in o, o[:300])

# generation handoff
o = run("handoff.py", "build", "--run-dir", rdR, "--memory", mem)
if not os.path.exists(os.path.join(rdR, "generation_handoff.json")):
    print(o[-1500:])
H = json.load(open(os.path.join(rdR, "generation_handoff.json")))
test("H the handoff is built and saved under its contract name in the handoff folder", "HANDOFF: ready_with_unresolved" in o
     and "Tidewater_2026_Q2_r2_generation_handoff.json -> /Shared Documents/Valuations/6.generation_handoff/Tidewater/2026/Q2_r2" in o, o)
test("H it carries identity, approved workbook, fingerprints, confirmed memory, mappings, updateable inputs and protected formulas",
     H["identity"]["run_id"] == "Tidewater_2026_Q2_r2" and H["approved_workbook"]["sha256"] and H["fingerprints"]["source_set_sha256"]
     and H["confirmed_memory"]["entries"] and H["semantic_mappings"] and H["updateable_inputs"] and H["protected_formulas"]
     and all(k in H for k in ("source_precedence", "approved_relationships", "valuation_chain", "rules_for_generation")), list(H))
test("H pending decisions stay explicitly unresolved", any("v3" in p_["question"] for p_ in H["unresolved"]["pending_decisions"])
     and not any("v3" in str(e["statement"]) for e in H["confirmed_memory"]["entries"]))
test("10 mappings carry the last confirmed location, and generation is told a location match alone never allows an overwrite",
     all(mp["last_confirmed_location"] for mp in H["semantic_mappings"]) and any("location match alone never" in r for r in H["rules_for_generation"]))
rdN, _ = full_run("N", workbooks(), n=5)
o = run("handoff.py", "build", "--run-dir", rdN, "--memory", mem)
test("H no accepted review: refused, nothing written", "HANDOFF: refused" in o and not os.path.exists(os.path.join(rdN, "generation_handoff.json")), o)
o = run("handoff.py", "build", "--run-dir", rdR, "--memory", os.path.join(TMP, "none.memory.json"))
test("H no memory file: refused", "HANDOFF: refused" in o, o)

# 11 backward compatibility: a 13.2.3-style manifest without the handoff folder still uploads
Mx = RM.load(rdA)
Mx["folders"].pop("handoff", None)
json.dump(Mx, open(os.path.join(rdA, "run_manifest.json"), "w"))
o = RM.upload_text(rdA, ["extraction.json"])
test("11 an older manifest still uploads (new folders filled in)", "Tidewater_2026_Q2_extraction.json" in o)

n = len(RESULTS)
print(f"TESTS: {'PASS' if all(RESULTS) else 'FAIL'} ({sum(RESULTS)}/{n})")
shutil.rmtree(TMP, ignore_errors=True)
sys.exit(0 if all(RESULTS) else 1)
