# test_13_2_6.py - build 13.2.6: the review bundle round trip (synthetic T1 only; helpers as in test_13_2_3.py)
# test_13_2_3.py - build 13.2.3 tests: the contradiction gate, the source-fingerprint lock, generated-artifact naming and identity,
# and backward compatibility. Synthetic only: the made-up five-workbook set T1 from the test bench (path given by --trial or the
# XPV_TRIAL environment variable). No real company, cell or value is used, and nothing here names a source workbook the code
# expects: source files are renamed freely, extra files are added, and the code must not care.
# Usage: python tests/test_13_2_3.py --trial <path to xpv-onboarding-testbench/trial>   (last line: TESTS: PASS (n/n))
import argparse, glob, json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.join(os.path.dirname(HERE), "scripts")
sys.path.insert(0, S)
ap = argparse.ArgumentParser()
ap.add_argument("--trial", default=os.environ.get("XPV_TRIAL", os.path.join(HERE, "..", "..", "xpv-onboarding-testbench", "trial")))
A = ap.parse_args()
TR = os.path.abspath(A.trial)
T1 = os.path.join(TR, "set-T1")
REF = os.path.join(TR, "reference", "T1")
TMP = tempfile.mkdtemp(prefix="t1326-")
RESULTS = []


def run(script, *args):
    r = subprocess.run([sys.executable, os.path.join(S, script), *args], capture_output=True, text=True, timeout=600)
    return r.stdout + r.stderr


def test(name, ok, got=""):
    RESULTS.append(bool(ok))
    print(f"- {'PASS' if ok else 'FAIL'}: {name}" + ("" if ok else f" -> {str(got)[:600]}"))


def workbooks(names=None, extra=None, edit=None):
    """a copy of T1 under new file names (kept in the same sort order so stage ids stay W1..W5), plus optional extras."""
    d = tempfile.mkdtemp(dir=TMP, prefix="wb-")
    src = sorted(glob.glob(os.path.join(T1, "*.xlsx")))
    out = []
    for i, p in enumerate(src):
        nm = (names[i] if names else os.path.basename(p))
        q = os.path.join(d, nm)
        shutil.copyfile(p, q)
        out.append(q)
    if edit is not None:
        from openpyxl import load_workbook
        i, sheet, cell, val = edit
        wb = load_workbook(out[i])
        wb[sheet][cell] = val
        wb.save(out[i])
    for e in extra or []:
        q = os.path.join(d, os.path.basename(e))
        shutil.copyfile(e, q)
        out.append(q)
    return out


def full_run(name, wbs, company="Tidewater", period="2026 Q2", n=1, s7=None, memory=None, init=True):
    rd = os.path.join(TMP, name)
    shutil.rmtree(rd, ignore_errors=True)
    os.makedirs(rd)
    o = run("xlsx_evidence.py", "inventory", "--run-dir", rd, "--workbooks", *wbs)
    if init:
        o += run("run_manifest.py", "init", "--run-dir", rd, "--company", company, "--period", period, "--run-number", str(n))
    for k in range(2, 7):
        o += run("checkpoint.py", "save", "--run-dir", rd, "--stage", str(k), "--file", glob.glob(os.path.join(REF, f"0{k}_*.json"))[0])
    if memory:
        o += run("memory.py", "attach", "--run-dir", rd, "--memory", memory)
    p = os.path.join(rd, "s7.json")
    json.dump(s7 or {}, open(p, "w"))
    o += run("checkpoint.py", "save", "--run-dir", rd, "--stage", "7", "--file", p)
    o += run("verify.py", "--run-dir", rd, "--final")
    return rd, o


def pc(rd):
    return json.load(open(os.path.join(rd, "proposed_changes.json")))


def fill(rd, decisions, out_name="Review.completed.xlsx", reviewer="Test Reviewer", notes=None):
    """decisions: {item_id: (Decision, correction or None)}; anything else stays blank."""
    from openpyxl import load_workbook
    run("review_xlsx.py", "build", "--run-dir", rd)
    wb = load_workbook(os.path.join(rd, "Review.xlsx"))
    wb["Start here"]["B6"] = reviewer
    for sn in ("Unresolved decisions", "Proposed changes", "Memory candidates"):
        ws = wb[sn]
        head = [c.value for c in ws[1]]
        di, ci, ii = head.index("Decision") + 1, head.index("Your correction") + 1, head.index("_id") + 1
        ni = head.index("Rule or note for memory") + 1
        for r in range(2, ws.max_row + 1):
            iid = ws.cell(r, ii).value
            if iid in decisions:
                d, c = decisions[iid]
                ws.cell(r, di).value = d
                if c is not None:
                    ws.cell(r, ci).value = c
            if notes and iid in notes:
                ws.cell(r, ni).value = notes[iid]
    p = os.path.join(rd, out_name)
    wb.save(p)
    return p


def ids(P, kind=None, subject=None, target=None):
    out = []
    for c in P["memory_candidates"]:
        if (kind is None or c["kind"] == kind) and (subject is None or c["subject"] == subject):
            out.append(c["id"])
    for it in P["proposed_changes"]:
        if target and (it.get("target") or {}).get("cell") == target and (kind is None or it["kind"] == kind):
            out.append(it["id"])
    return out


def clean_decisions(P):
    """approve everything that can be approved; leave decisions with no suggested answer and blocked changes blank."""
    D = {}
    for c in P["memory_candidates"]:
        D[c["id"]] = ("Approve", None)
    for it in P["proposed_changes"]:
        if not it.get("blocked_by") and it["verify"]["status"] != "contradicted":
            D[it["id"]] = ("Approve", None)
    return D



import base64, hashlib  # noqa: E402
import memory as MEM  # noqa: E402
import run_manifest as RM  # noqa: E402
import bundle as BU  # noqa: E402
from openpyxl import load_workbook  # noqa: E402
S7G = {"question_groups": [{"primary": "D1", "members": ["Q2"], "why": "one decision"}]}


def tamper(src, name, fn):
    wb = load_workbook(src)
    fn(wb)
    p = os.path.join(TMP, name)
    wb.save(p)
    return p


def fresh(name):
    d = os.path.join(TMP, name)
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    return d


def read(rd, rv):
    return run("review_xlsx.py", "read", "--run-dir", rd, "--review", rv)


# conversation A: extraction, fresh review, the person fills it in (one deliberate blank)
rdA, o = full_run("A", workbooks(), n=5, s7=S7G)
o = run("review_xlsx.py", "build", "--run-dir", rdA)
test("B building a review embeds the bundle and lists the review + snapshot for upload", "REVIEW: built" in o, o)
wbA = load_workbook(os.path.join(rdA, "Review.xlsx"))
meta = {r[0].value: r[1].value for r in wbA["_meta"].iter_rows() if r[0].value}
test("B the bundle sheet is very hidden and its fingerprint is in _meta", BU.SHEET in wbA.sheetnames and wbA[BU.SHEET].sheet_state == "veryHidden"
     and len(meta.get("bundle_sha256") or "") == 64, meta)
comps, bsha = BU.read_sheet(wbA, meta)
src = json.loads(comps["sources"])
test("B the bundle holds identities, fingerprints, roles and sheet names only - no workbook contents",
     all(set(x) <= {"id", "original_file", "file", "sha256", "content_sha256", "role", "role_period", "sheets"} for x in src)
     and all(set(sh) <= {"name", "state"} for x in src for sh in x["sheets"]), src[0])
test("B the bundle carries the exact proposals snapshot", comps["proposals_snapshot"].encode() == open(os.path.join(rdA, "proposed_changes.json"), "rb").read())
P = pc(rdA)
blank = next(j["id"] for j in P["human_judgments"] if "v3" in j["question"])
D = clean_decisions(P)
for j in P["human_judgments"]:
    if j["id"] != blank:
        D[j["id"]] = ("Correct", "the company workbook value")
rv = fill(rdA, D, "Tidewater_2026_Q2_r5_Review.completed.xlsx")
# the original conversation is closed: conversation B has only the completed review and the memory path
rdB = fresh("B")
mem = os.path.join(TMP, "mem", "Tidewater.memory.json")
os.makedirs(os.path.dirname(mem))
o = read(rdB, rv)
test("R new conversation, only the completed review attached: the bundle restores and the review is accepted", "REVIEW: accepted" in o
     and "bundle " + bsha[:12] in o, o)
test("R nothing in checkpoints/ is written or reconstructed; no extraction or manifest is recreated",
     not os.path.exists(os.path.join(rdB, "checkpoints")) and not os.path.exists(os.path.join(rdB, "extraction.json"))
     and not os.path.exists(os.path.join(rdB, "run_manifest.json")), os.listdir(rdB))
snapB = glob.glob(os.path.join(rdB, "review", "proposals_*.json"))
test("R the restored snapshot is byte-identical to the one built in conversation A", len(snapB) == 1
     and open(snapB[0], "rb").read() == open(glob.glob(os.path.join(rdA, "review", "proposals_*.json"))[0], "rb").read())
o = run("memory.py", "apply", "--run-dir", rdB, "--decisions", os.path.join(rdB, "review_decisions.json"), "--memory", mem)
m1 = MEM.load(mem)
test("R memory is created and coherence-checked from the bundle alone", "created a new memory file" in o and "coherence OK" in o
     and not MEM.check_chain(m1), o)
test("R the deliberate blank becomes pending", any("v3" in x["question"] for x in MEM.pending(m1)))
test("R memory evidence keeps roles and file names (from the bundle, not retyped)", all(
    (ev.get("role") and ev.get("file")) for e in m1["entries"] for ev in e.get("evidence") or [] if ev.get("cell")), m1["entries"][0].get("evidence"))
o = run("handoff.py", "build", "--run-dir", rdB, "--memory", mem)
H = json.load(open(os.path.join(rdB, "generation_handoff.json"))) if os.path.exists(os.path.join(rdB, "generation_handoff.json")) else {}
test("R the generation handoff builds from the bundle, pending kept unresolved", "HANDOFF: ready_with_unresolved" in o
     and H["fingerprints"]["review_bundle_sha256"] == bsha and any("v3" in p_["question"] for p_ in H["unresolved"]["pending_decisions"])
     and H["approved_relationships"] and H["valuation_chain"], o)
up = sorted(os.path.relpath(p_, os.path.join(rdB, "upload")) for p_ in glob.glob(os.path.join(rdB, "upload", "**", "*"), recursive=True) if os.path.isfile(p_))
test("R a restored run uploads only the review package and the handoff - never a manifest or checkpoint",
     up and all(p_.startswith(("review_package/", "handoff/")) for p_ in up), up)
# then a fresh extraction with that memory
rdC, o = full_run("C", workbooks(), n=6, s7=S7G, memory=mem)
PC = pc(rdC)
rs = PC["review_summary"]
test("R next run: approved concepts reused, the pending item still pending and the only decision", rs["reused_detail"]["answered_decisions"] >= 2
     and rs["pending_carried_forward"] == 1 and len(PC["human_judgments"]) == 1 and "v3" in PC["human_judgments"][0]["question"], rs)

# tampering with the bundle: always refused, nothing left behind
def no_sheet(wb):
    del wb[BU.SHEET]
def flip(wb):
    ws = wb[BU.SHEET]
    v = ws.cell(2, 2).value
    ws.cell(2, 2).value = v[:100] + ("A" if v[100] != "A" else "B") + v[101:]
def dup(wb):
    ws = wb[BU.SHEET]
    ws.append([ws.cell(2, 1).value, ws.cell(2, 2).value])
def drop(wb):
    ws = wb[BU.SHEET]
    ws.cell(1, 2).value = int(ws.cell(1, 2).value) + 1
def head_sha(wb):
    wb[BU.SHEET].cell(1, 3).value = "0" * 64
def meta_sha(wb):
    for r in wb["_meta"].iter_rows():
        if r[0].value == "bundle_sha256":
            r[1].value = "0" * 64
def resign(wb, mutate):
    ws = wb[BU.SHEET]
    n = int(ws.cell(1, 2).value)
    body = base64.b64decode("".join(ws.cell(i + 2, 2).value for i in range(n)))
    newbody = mutate(body)
    new = hashlib.sha256(newbody).hexdigest()
    enc = base64.b64encode(newbody).decode()
    parts = [enc[i:i + BU.CHUNK] for i in range(0, len(enc), BU.CHUNK)]
    ws.delete_rows(1, ws.max_row)
    ws.append([BU.SCHEMA, len(parts), new])
    for i, p_ in enumerate(parts, 1):
        ws.append([i, p_])
    for r in wb["_meta"].iter_rows():
        if r[0].value == "bundle_sha256":
            r[1].value = new
def comp_edit(b):
    d = json.loads(b)
    d["components"]["sources"] = d["components"]["sources"].replace('"role":"', '"role":"x', 1)
    return BU.canon(d).encode()
def extra_comp(b):
    d = json.loads(b)
    d["components"]["extra"] = "x"
    d["component_sha256"]["extra"] = BU.sha("x")
    return BU.canon(d).encode()
def dupkey(b):
    return b.replace(b'{"component_sha256":', b'{"schema":"xpv-review-bundle/1","component_sha256":', 1)
def noncanon(b):
    return json.dumps(json.loads(b), indent=2, sort_keys=True, ensure_ascii=False).encode()
cases = [("the bundle sheet removed", no_sheet, "required review bundle missing"), ("one character of a chunk changed", flip, ""),
         ("a chunk repeated", dup, "repeats chunk"), ("a chunk missing", drop, "should have chunks"),
         ("the header fingerprint changed", head_sha, "altered"), ("the _meta fingerprint changed", meta_sha, "not the one this review was built with"),
         ("a component edited and the bundle re-signed", lambda wb: resign(wb, comp_edit), "sources was altered"),
         ("an extra component added", lambda wb: resign(wb, extra_comp), "exactly"),
         ("a duplicated key", lambda wb: resign(wb, dupkey), "repeats the key"),
         ("the bundle re-serialised (not byte-for-byte canonical)", lambda wb: resign(wb, noncanon), "canonical")]
for nm, fn, why in cases:
    d = fresh("T-" + nm.replace(" ", "_")[:20])
    o = read(d, tamper(rv, f"t{len(nm)}{nm[:6].replace(' ', '')}.xlsx", fn))
    test(f"T {nm} -> REVIEW: refused, nothing restored or written", "REVIEW: refused" in o and why in o
         and not os.path.exists(os.path.join(d, "review_decisions.json")) and not glob.glob(os.path.join(d, "review", "*.json"))
         and not glob.glob(os.path.join(d, "restored", "*.json")), o[-400:])
d = fresh("T-rows")
def edit_row(wb):
    wb["Proposed changes"].cell(2, 3).value = "changed"
o = read(d, tamper(rv, "t-row.xlsx", edit_row))
test("T a valid bundle but an edited review row -> refused, and the restored files are removed again", "REVIEW: refused" in o
     and not glob.glob(os.path.join(d, "review", "*.json")) and not glob.glob(os.path.join(d, "restored", "*.json")), (o[-300:], os.listdir(d)))

# a review cannot be built from staged (fetched) copies or from a restored bundle
rdS = fresh("S")
up = os.path.join(rdA, "upload")
run("run_manifest.py", "stage-in", "--run-dir", rdS, "--files", *glob.glob(os.path.join(up, "*.json")), *glob.glob(os.path.join(up, "checkpoints", "*.json")))
run("xlsx_evidence.py", "inventory", "--run-dir", rdS, "--workbooks", *workbooks())
o = run("review_xlsx.py", "build", "--run-dir", rdS)
test("S a review is never built from copies fetched from SharePoint", "REVIEW: refused" in o and "only in the conversation where the run was extracted" in o, o)
o = run("review_xlsx.py", "build", "--run-dir", rdB)
test("S nor from a run restored from a review bundle", "REVIEW: refused" in o, o)
cp = glob.glob(os.path.join(up, "checkpoints", "03_chain*.json"))[0]
bad = os.path.join(TMP, "03_chain.json")
X = json.load(open(cp))
X["how_it_works"] = "retyped"
json.dump(X, open(bad, "w"))
o = run("run_manifest.py", "stage-in", "--run-dir", fresh("S2"), "--files", glob.glob(os.path.join(up, "*_run_manifest.json"))[0], bad)
test("S a checkpoint that is not byte-identical to the one the run saved is refused at stage-in", "RUN: refused" in o and "never retype" in o, o)

# same conversation still works
o = read(rdA, rv)
test("R reading the review in the conversation that built it also goes through the bundle", "REVIEW: accepted" in o, o)

n = len(RESULTS)
print(f"TESTS: {'PASS' if all(RESULTS) else 'FAIL'} ({sum(RESULTS)}/{n})")
shutil.rmtree(TMP, ignore_errors=True)
sys.exit(0 if all(RESULTS) else 1)
