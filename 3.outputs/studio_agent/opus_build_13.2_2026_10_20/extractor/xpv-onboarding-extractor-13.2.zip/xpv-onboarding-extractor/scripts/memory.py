# memory.py (build 13.2) - company memory: one dedicated, persistent file per company, written only by this code, APPEND-ONLY,
# holding only what a person confirmed in the review workbook. Plain code, no judgment.
# Every entry says what KIND of thing it is:
#   type fact        the workbooks show it: where a concept lives (mapping), a restatement of a past period (revision)
#   type assumption  a person's call: which file wins (source_precedence), an adjustment rule, a method note, an answered
#                    unresolved decision (judgment), a value confirmed every quarter such as the applied multiple (assumption_value)
# ...and its provenance: period, source (workbook role, file, sheet, cell), decision (approve | correct), who confirmed it and
# when, the review file it came from, and what it replaced (supersedes + a copy of the replaced entry's statement and value).
# Nothing the AI proposes - fact or assumption - is ever written until a person approves or corrects it.
#   attach  --run-dir R --memory PATH     copy the company's memory into the run (company_memory.in.json, read-only) so this
#                                          quarter's proposals are compared with it: matches are not proposed again, contradictions
#                                          are shown beside the new reading and become unresolved decisions. Memory is never
#                                          overridden by a run, and history is never reconstructed from the workbooks.
#   apply   --run-dir R --decisions review_decisions.json --memory PATH
#           adds: memory candidates Approved or Corrected; unresolved decisions answered (Approve = the suggested answer,
#           Correct = the person's answer) as assumptions; "always confirm" values (the multiple) Approved or Corrected as
#           assumptions. Rejected and undecided items are never added. Re-applying the same review adds nothing.
#   current --memory PATH [--json]        the memory in force: for each subject, the LATEST confirmed entry wins
#   check   --memory PATH [--since OLD]   the hash chain is intact (nothing edited, reordered or deleted); with --since, OLD is
#                                          an exact prefix of PATH (append-only across versions)
#   view    --memory PATH --out X.xlsx    a readable Excel view (In force | History | Legend); the JSON file stays the record
# Location: there is NO built-in location. PATH is given every time (the run message names it), so where memory lives - and
# who may edit it - can be decided later without changing code. Nothing here reads or writes any other path.
# Never stored: answer-key / Gold / test-bench matching metadata (refused by guard.py). Ordinary workbook evidence is stored.
import argparse, datetime, hashlib, json, os, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import guard as G  # noqa: E402
from onboarding_schema import SCHEMA_VERSION  # noqa: E402

SCHEMA = "xpv-company-memory/2"
READABLE = ("xpv-company-memory/1", SCHEMA)
TYPE_BY_KIND = {"mapping": "fact", "revision": "fact", "source_precedence": "assumption", "adjustment_rule": "assumption",
                "method_note": "assumption", "assumption_value": "assumption", "judgment": "assumption"}
GENESIS = "0" * 64


def entry_hash(e):
    body = {k: v for k, v in e.items() if k != "entry_hash"}
    return hashlib.sha256(json.dumps(body, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()


def load(path, company=None):
    if not os.path.exists(path):
        return {"schema": SCHEMA, "company": company, "made_by": f"memory {SCHEMA_VERSION}", "entries": []}
    m = G.check_json_file(path, "company memory")
    if m.get("schema") not in READABLE:
        raise ValueError(f"{path} is not a company memory file ({m.get('schema')})")
    return m


def check_chain(m):
    """-> list of problems (empty = intact)."""
    P, prev = [], GENESIS
    for i, e in enumerate(m.get("entries") or []):
        if e.get("seq") != i + 1:
            P.append(f"entry {i + 1}: sequence {e.get('seq')} (entries were removed or reordered)")
        if e.get("prev_hash") != prev:
            P.append(f"entry {i + 1}: does not follow the entry before it (an entry was edited, removed or inserted)")
        if entry_hash(e) != e.get("entry_hash"):
            P.append(f"entry {i + 1}: its content changed after it was written")
        prev = e.get("entry_hash")
    return P


def current(m):
    """subject_key -> the latest confirmed entry (later entries supersede earlier ones for the same subject)."""
    out = {}
    for e in m.get("entries") or []:
        out[e["subject_key"]] = e
    return dict(sorted(out.items()))


def _sources(run_dir):
    p = os.path.join(run_dir, "extraction.json")
    return {s.get("id"): s for s in (json.load(open(p)).get("sources") or [])} if os.path.exists(p) else {}


def role_of(run_dir, sid):
    return (_sources(run_dir).get(sid) or {}).get("role")


def portable_ref(run_dir, ref):
    s_ = _sources(run_dir).get((ref or {}).get("source")) or {}
    sh, _, cell = str((ref or {}).get("cell", "")).rpartition("!")
    return {"role": s_.get("role"), "file": s_.get("file"), "sheet": sh.strip("'").replace("''", "'"), "cell": cell.replace("$", "")}


def attach(run_dir, memory_path):
    m = load(memory_path)
    P = check_chain(m)
    if P:
        raise ValueError(["the memory file is not intact - not attached:"] + P)
    x = os.path.join(run_dir, "extraction.json")
    co = json.load(open(x)).get("company") if os.path.exists(x) else None
    if co and m.get("company") and co != m["company"]:
        raise ValueError(f"the memory file is {m['company']!r}'s; this run is {co!r}")
    write_atomic(os.path.join(run_dir, "company_memory.in.json"), m)
    return m


def write_atomic(path, m):
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(m, indent=1, ensure_ascii=False, default=str) + "\n")
    os.replace(tmp, path)


def apply(run_dir, decisions_path, memory_path):
    D = G.check_json_file(decisions_path, "review decisions")
    pcp = os.path.join(run_dir, "proposed_changes.json")
    pc = G.check_json_file(pcp, "proposed_changes.json")
    if D.get("schema") != "xpv-review-decisions/1":
        raise ValueError("not a review_decisions.json made by review_xlsx.py read")
    if D.get("inputs_sha256") != pc.get("inputs_sha256"):
        raise ValueError("these decisions were made on other proposals than this run's proposed_changes.json")
    m = load(memory_path, pc.get("company"))
    P = check_chain(m)
    if P:
        raise ValueError(["the memory file is not intact - nothing was added:"] + P)
    if m.get("company") and pc.get("company") and m["company"] != pc["company"]:
        raise ValueError(f"the memory file is {m['company']!r}'s; this run is {pc['company']!r}")
    cands = {c["id"]: c for c in pc.get("memory_candidates") or []}
    hjs = {j["id"]: j for j in pc.get("human_judgments") or []}
    pcs = {x["id"]: x for x in pc.get("proposed_changes") or []}
    done = {(e.get("candidate_id"), e.get("review_sha256")) for e in m["entries"]}
    cur = current(m)
    qe = (pc.get("quarter_end") or "")[:7] or None
    items = []
    for d in D.get("decisions") or []:
        if d.get("decision") not in ("Approve", "Correct"):
            continue
        corr, t = d.get("correction"), d.get("item_type")
        if d["decision"] == "Correct" and corr is None:
            raise ValueError(f"{d['item_id']}: Correct without a correction")
        if t == "memory":
            c = cands.get(d["item_id"])
            if not c:
                raise ValueError(f"decision for {d['item_id']}, which is not a memory candidate of this run")
            value, statement = c.get("value"), c["statement"]
            if d["decision"] == "Correct":
                if corr["type"] == "cell":
                    ref = corr["value"]
                    sh, _, cell = ref["cell"].rpartition("!")
                    value = {"role": role_of(run_dir, ref["source"]), "sheet": sh.strip("'").replace("''", "'"), "cell": cell.replace("$", ""),
                             "corrected": True}
                    statement = f"{statement} - corrected by {D.get('reviewer')}: {ref['cell']}"
                    c = dict(c, evidence=[portable_ref(run_dir, ref)])        # the source is the person's cell, not the run's
                elif corr["type"] == "text":
                    statement = str(corr["value"])
                else:
                    value = corr["value"]
            items.append(dict(cid=c["id"], kind=c["kind"], subject=c["subject"], subject_key=c["subject_key"], statement=statement,
                              value=value, evidence=c.get("evidence") or [], type=c.get("type") or TYPE_BY_KIND[c["kind"]],
                              period=c.get("period") or qe, origin=c.get("origin"), d=d))
        elif t == "judgment":
            j = hjs.get(d["item_id"])
            if not j:
                raise ValueError(f"decision for {d['item_id']}, which is not an unresolved decision of this run")
            if d["decision"] == "Approve" and not j.get("suggested"):
                raise ValueError(f"{j['id']}: approved, but there is no suggested answer")
            ans = (corr or {}).get("value") if d["decision"] == "Correct" else j.get("suggested")
            items.append(dict(cid=j["id"], kind="judgment", subject=j["id"], subject_key=f"judgment:{j['id']}",
                              statement=f"{j['question']} -> {ans}", value=ans, evidence=[portable_ref(run_dir, c) for c in j.get("cells_affected") or []],
                              type="assumption", period=qe, origin=j.get("origin"), d=d))
        elif t == "proposal":
            it = pcs.get(d["item_id"])
            if not it or not it.get("always_confirm") or not it.get("target"):
                continue                                   # other approved changes are for the quarterly builder, not memory
            ev = portable_ref(run_dir, it["target"])
            val = (corr or {}).get("value") if d["decision"] == "Correct" and (corr or {}).get("type") == "number" else (it.get("current") or {}).get("value")
            items.append(dict(cid=it["id"], kind="assumption_value", subject=f"value.{ev['sheet'].lower()}!{ev['cell'].lower()}",
                              subject_key=f"assumption_value:value.{ev['sheet'].lower()}!{ev['cell'].lower()}",
                              statement=f"{it.get('what')}: {val} for {qe}" + (f" (corrected from {(it.get('current') or {}).get('value')})"
                                                                             if d["decision"] == "Correct" else ""),
                              value=val, evidence=[ev], type="assumption", period=qe, origin=it.get("origin"), d=d))
    added, skipped = [], 0
    for x in items:
        d = x["d"]
        if (x["cid"], D["review_sha256"]) in done:
            skipped += 1
            continue
        old = cur.get(x["subject_key"])
        prev = m["entries"][-1]["entry_hash"] if m["entries"] else GENESIS
        e = {"seq": len(m["entries"]) + 1, "subject_key": x["subject_key"], "kind": x["kind"], "type": x["type"], "subject": x["subject"],
             "statement": x["statement"], "value": x["value"], "period": x["period"], "source": x["evidence"], "evidence": x["evidence"],
             "decision": d["decision"].lower(), "correction": d.get("correction"), "comment": d.get("comment"), "candidate_id": x["cid"],
             "candidate_origin": x["origin"], "proposed_by": "agent or code (unconfirmed until this entry)",
             "confirmed_by": D.get("reviewer"), "confirmed_at": D.get("read_at"), "review_sha256": D["review_sha256"],
             "run": {"quarter_end": pc.get("quarter_end"), "valuation_workbook_sha256": pc["valuation_workbook"]["sha256"],
                     "valuation_workbook_file": pc["valuation_workbook"]["file"]},
             "supersedes": (old or {}).get("entry_id"),
             "replaces": ({"entry_id": old["entry_id"], "type": old.get("type"), "statement": old.get("statement"), "value": old.get("value"),
                           "period": old.get("period") or (old.get("run") or {}).get("quarter_end"), "confirmed_by": old.get("confirmed_by")}
                          if old else None),
             "prev_hash": prev}
        e["entry_id"] = "ME-" + hashlib.sha256(f"{x['cid']}|{D['review_sha256']}".encode()).hexdigest()[:12]
        G.check_doc(e, f"memory entry {x['cid']}")
        e["entry_hash"] = entry_hash(e)
        m["entries"].append(e)
        cur[x["subject_key"]] = e
        added.append(e)
    m["schema"] = SCHEMA
    if not m.get("company"):
        m["company"] = pc.get("company")
    if added:
        write_atomic(memory_path, m)
    return added, skipped, m


def view(m, out):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    wb = Workbook()
    base, bold, head = Font(name="Arial", size=10), Font(name="Arial", size=10, bold=True), PatternFill("solid", fgColor="DDEBF7")

    def sheet(ws, hdr, rows, widths):
        ws.append(hdr)
        for c in ws[1]:
            c.font, c.fill = bold, head
        for r in rows:
            ws.append([json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v for v in r])
        for row in ws.iter_rows(min_row=2):
            for c in row:
                c.font, c.alignment = base, Alignment(wrap_text=True, vertical="top")
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[ws.cell(1, i).column_letter].width = w
        ws.freeze_panes = "A2"
    ws = wb.active
    ws.title = "In force"
    sheet(ws, ["Subject", "Type", "Kind", "What memory says", "Period", "Where (role, sheet, cell)", "Confirmed by", "Confirmed at",
               "Replaced", "Entry"],
          [[e["subject"], e.get("type") or TYPE_BY_KIND.get(e["kind"]), e["kind"], e["statement"], e.get("period") or (e.get("run") or {}).get("quarter_end"),
            ", ".join(f"{v.get('role')} {v.get('sheet')}!{v.get('cell')}" for v in e.get("evidence") or []),
            e.get("confirmed_by"), e.get("confirmed_at"), ((e.get("replaces") or {}).get("statement") or ""), e["entry_id"]] for e in current(m).values()],
          [32, 11, 16, 70, 10, 36, 18, 22, 40, 18])
    sheet(wb.create_sheet("History"), ["#", "Subject", "Decision", "What memory says", "Supersedes", "Confirmed by", "Confirmed at", "Entry"],
          [[e["seq"], e["subject"], e["decision"], e["statement"], e.get("supersedes"), e.get("confirmed_by"), e.get("confirmed_at"), e["entry_id"]]
           for e in m.get("entries") or []], [5, 32, 10, 80, 18, 18, 22, 18])
    sheet(wb.create_sheet("Legend"), ["Term", "Meaning"],
          [["In force", "for each subject, the latest entry a person confirmed"],
           ["fact", "the workbooks show it (where something lives, a restated past value)"],
           ["assumption", "a person's call (which file wins, a rule, the multiple, an answered decision)"],
           ["Replaced", "what the earlier entry for the same subject said; it stays in History"], ["History", "every entry ever added, oldest first; nothing is edited or deleted"],
           ["Supersedes", "the earlier entry for the same subject that this one replaced"],
           ["approve / correct", "the reviewer accepted the candidate as shown / with their correction"],
           ["Record", "the JSON memory file is the record; this workbook is a view of it"]], [20, 90])
    wb.save(out)


def main(argv=None):
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("apply")
    p.add_argument("--run-dir", default=".")
    p.add_argument("--decisions", required=True)
    p.add_argument("--memory", required=True)
    p = sub.add_parser("attach")
    p.add_argument("--run-dir", default=".")
    p.add_argument("--memory", required=True)
    p = sub.add_parser("current")
    p.add_argument("--memory", required=True)
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("check")
    p.add_argument("--memory", required=True)
    p.add_argument("--since")
    p = sub.add_parser("view")
    p.add_argument("--memory", required=True)
    p.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    try:
        if a.cmd == "apply":
            added, skipped, m = apply(a.run_dir, a.decisions, a.memory)
            print(f"MEMORY: {len(added)} entr{'y' if len(added) == 1 else 'ies'} added ({sum(1 for e in added if e['supersedes'])} replace an earlier "
                  f"entry for the same subject), {skipped} already there | {len(m['entries'])} entries, {len(current(m))} subjects in force"
                  + (f" | UPLOAD: {os.path.basename(a.memory)}" if added else ""))
            return 0
        if a.cmd == "attach":
            if not os.path.exists(a.memory):
                print("MEMORY: none yet for this company - nothing attached (the first review will create it)")
                return 0
            m = attach(a.run_dir, a.memory)
            cur = current(m)
            print(f"MEMORY: attached {os.path.basename(a.memory)} | {len(m['entries'])} entries, {len(cur)} in force "
                  f"({sum(1 for e in cur.values() if e.get('type', TYPE_BY_KIND.get(e.get('kind'))) == 'fact')} facts, "
                  f"{sum(1 for e in cur.values() if e.get('type', TYPE_BY_KIND.get(e.get('kind'))) == 'assumption')} assumptions) | "
                  "proposals will be compared with it (save stage 7 again if it is already saved)")
            return 0
        m = load(a.memory)
        if a.cmd == "check":
            P = check_chain(m)
            if a.since:
                old = load(a.since)
                n = len(old.get("entries") or [])
                if (m.get("entries") or [])[:n] != old.get("entries"):
                    P.append(f"{os.path.basename(a.since)} is not an exact prefix of {os.path.basename(a.memory)}: earlier entries were changed or removed")
            print(f"MEMORY: check {'FAILED' if P else 'OK'} | {len(m.get('entries') or [])} entries")
            for x in P[:20]:
                print(f"  - {x}")
            return 1 if P else 0
        if a.cmd == "current":
            cur = current(m)
            if a.json:
                print(json.dumps(cur, indent=1, ensure_ascii=False, default=str))
            else:
                for k, e in cur.items():
                    print(f"{k} | {e['statement']} | {e.get('confirmed_by')} {e.get('confirmed_at')}")
            return 0
        if a.cmd == "view":
            view(m, a.out)
            print(f"MEMORY: view written {os.path.basename(a.out)} | {len(current(m))} subjects in force")
            return 0
    except G.Refused as x:
        print(f"MEMORY: refused | {x}")
        return 2
    except ValueError as x:
        P = x.args[0] if x.args and isinstance(x.args[0], list) else [str(x)]
        print("MEMORY: refused | " + P[0])
        for m_ in P[1:20]:
            print(f"  - {m_}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
