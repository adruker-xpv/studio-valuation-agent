# guard.py (build 13.2) - keeps benchmark material out of production. The test bench and its answer keys only MEASURE the
# extractor; nothing from them may feed a production run, a proposal, a review decision or company memory.
#   refused as whole artifacts  Gold keys (gold-mvp/*), trial keys, score / Gold reports, reference answers, the analyst
#                               answer form, the key-review sheet, anything named like an answer key
#   refused inside any document benchmark-only matching metadata: an item's gold_id, Gold anchors (primary / supporting /
#                               header / value), keywords, known rivals, certification, Gold thresholds ... and text that
#                               cites an answer key or Gold key
#   allowed                     ordinary workbook evidence: {"source", "cell"}, sheet names, cell references, labels.
#                               Company memory needs them.
# Used by: xlsx_evidence inventory (workbooks), checkpoint save (stage files), verify (the extraction it is given),
# review_xlsx read (decisions), memory apply (entries). A refusal is final: remove the material and run again.
import json, os, re

# keys that exist only in Gold keys, trial keys and benchmark scoring. Production schemas never use them.
FORBIDDEN_KEYS = {
    "gold_id", "gold_ids", "gold", "gold_key", "gold_ref", "answer_key", "answer_keys", "keywords", "match_keywords",
    "matching", "match_metadata", "primary_anchor", "supporting_anchors", "header_anchor", "value_anchor",
    "known_rivals", "material_discrepancies", "certification", "immaterial_below", "looks_like", "why_not_the_answer",
    "case_id", "gold_validation", "concepts", "link_check", "seed", "variant", "val_header_style", "report_header_style",
}
TEXT_PATTERNS = [re.compile(p, re.I) for p in (
    r"gold[-_ ]?mvp", r"\bgold[-_ ](key|answer|anchor|item|mode)s?\b", r"\banswer[-_ ]?keys?\b", r"\btrial/keys\b",
    r"\bkey[-_]review\b", r"\bgold_score\b", r"\bgold_suggest\b", r"\banalyst[-_ ]answers?[-_ ](form|template|sheet|file)\b")]
FILE_PATTERNS = [re.compile(p, re.I) for p in (
    r"gold[-_ ]?(mvp|key)", r"(^|[^a-z])gold[-_]g?\d", r"answer[-_ ]?key", r"analyst[-_ ]?answers", r"key[-_ ]?review",
    r"(^|[/\\])key-[a-z0-9]+\.json$", r"score[-_].*\.json$", r"gold_report", r"(^|[/\\])trial[/\\](keys|reference)[/\\]")]


class Refused(Exception):
    pass


def artifact_kind(doc):
    """a whole JSON document that is benchmark material -> a short name of what it is, else None."""
    if not isinstance(doc, dict):
        return None
    k = set(doc)
    sch = str(doc.get("schema", "")).lower()
    if sch.startswith("gold-mvp") or "gold" in sch:
        return "a Gold key"
    if {"answers", "certification"} <= k or {"answers", "known_rivals"} <= k:
        return "a Gold key"
    if {"gold_validation", "concepts"} & k or {"concepts", "judgments", "summary"} <= k:
        return "a Gold score report"
    if "seed" in k and ("metric_window" in k or "variant" in k) and "chain" not in k:
        return "a trial answer key"
    return None


def scan(obj, where="document", out=None):
    """benchmark matching metadata anywhere inside obj -> list of 'where: problem' strings."""
    out = [] if out is None else out
    if isinstance(obj, dict):
        for kk, v in obj.items():
            if str(kk).lower() in FORBIDDEN_KEYS:
                out.append(f"{where}.{kk}: '{kk}' is benchmark matching metadata (answer key / Gold only), never a production field")
            scan(v, f"{where}.{kk}", out)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            scan(v, f"{where}[{i}]", out)
    elif isinstance(obj, str):
        for p in TEXT_PATTERNS:
            if p.search(obj):
                out.append(f"{where}: cites benchmark material ({p.search(obj).group(0)!r}); production never uses answer keys")
                break
    return out


def check_doc(doc, where="document"):
    """raise Refused if doc is a benchmark artifact or carries benchmark metadata."""
    kind = artifact_kind(doc)
    if kind:
        raise Refused(f"{where} is {kind}: answer keys and test-bench files are never production inputs")
    P = scan(doc, where)
    if P:
        raise Refused("; ".join(P[:8]) + (f" (+{len(P) - 8} more)" if len(P) > 8 else ""))


def check_file_name(path):
    n = str(path).replace("\\", "/")
    for p in FILE_PATTERNS:
        if p.search(n):
            raise Refused(f"{os.path.basename(n)}: the name says it is benchmark material ({p.pattern}); never a production input")


def check_json_file(path, where=None):
    check_file_name(path)
    with open(path, encoding="utf-8") as fh:
        doc = json.load(fh)
    check_doc(doc, where or os.path.basename(path))
    return doc


def check_workbook(book):
    """book: xlsx_evidence.Book. Refuses the analyst answer form and the key-review sheet (by structure, not only name)."""
    check_file_name(book.path)
    names = [s["name"] for s in book.sheets]
    low = {n.lower() for n in names}
    if {"answers", "start here"} <= low:
        raise Refused(f"{book.file}: an analyst answer form (sheets 'Start here' + 'Answers') - benchmark only")
    if {"review", "_link"} <= low:
        try:
            sh = book.resolve_sheet("Review")
            head = [str(c[0]).strip().lower() for (r, c_), c in book.cells(sh).items() if r == 1 and c[0] is not None]
        except Exception:      # noqa: BLE001 - an unreadable header still counts as the review sheet's structure
            head = []
        if not head or {"action", "suggested"} & set(head):
            raise Refused(f"{book.file}: a Gold key-review sheet - benchmark only")
