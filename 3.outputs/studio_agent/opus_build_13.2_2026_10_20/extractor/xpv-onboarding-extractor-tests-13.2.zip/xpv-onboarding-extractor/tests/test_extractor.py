# test_extractor.py (build 13.2) - synthetic regression tests for the production extractor. Synthetic workbooks only (fixtures.py);
# no answer keys, no Gold files, no real company data. Run: python tests/test_extractor.py   -> last line "TESTS: PASS (n/n)"
#   F  flow: stages 1-7, verify --final (stage 8), extraction final; the 13.0 checks unchanged on the same extraction
#   P  proposals: deterministic, structured, checked; the multiple never "confirmed"; contradictions and tampering caught
#   R  revisions: emitted only when both values are directly evidenced (cells whose headers read the period); never inferred
#   W  window period: header evidence and value evidence graded separately (ported from test bench 13.2.2)
#   X  Excel review round trip: Approve / Correct / Reject, blocked changes, edits and stale reviews refused
#   M  company memory: append-only, only confirmed items, latest confirmed wins, tamper-evident, location given each time
#   Q  the next quarter: memory is attached and compared - matches not proposed again, contradictions become decisions
#   G  guard: answer keys, Gold files and benchmark matching metadata refused; ordinary cell evidence allowed
#   L  legacy: a build 13.0 seven-stage run still assembles and resumes
import copy, glob, json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SC = os.path.join(ROOT, "scripts")
sys.path.insert(0, HERE)
sys.path.insert(0, SC)
import fixtures as FX  # noqa: E402
import stages_s1 as S  # noqa: E402

TMP = tempfile.mkdtemp(prefix="xpv132_")
RESULTS = []


def test(name, ok, detail=""):
    RESULTS.append((name, bool(ok)))
    print(f"- {'PASS' if ok else 'FAIL'}: {name}" + ("" if ok else f"\n      {str(detail)[:900]}"))


def run(script, *args):
    r = subprocess.run([sys.executable, os.path.join(SC, script), *map(str, args)], capture_output=True, text=True, timeout=300)
    return r.returncode, r.stdout + r.stderr


def workbooks(name, **kw):
    d = os.path.join(TMP, name, "wb")
    FX.build(d, **kw)
    return d


def new_run(name, st=None, upto=7, final=True, wb=None, memory=None, **kw):
    wbd = wb or workbooks(name, **kw)
    rd = os.path.join(TMP, name, "run")
    shutil.rmtree(rd, ignore_errors=True)
    rc, o = run("xlsx_evidence.py", "inventory", "--run-dir", rd, "--workbooks", *sorted(glob.glob(os.path.join(wbd, "*.xlsx"))))
    assert rc == 0, o
    st = st or S.stages()
    outs = []
    for n in range(2, upto + 1):
        if n == 7 and memory:
            outs.append(run("memory.py", "attach", "--run-dir", rd, "--memory", memory))
        p = os.path.join(TMP, name, f"st{n}.json")
        json.dump(st[n], open(p, "w"))
        outs.append(run("checkpoint.py", "save", "--run-dir", rd, "--stage", n, "--file", p))
    if final and upto >= 7:
        outs.append(run("verify.py", "--run-dir", rd, "--final"))
    return rd, outs


def J(rd, f):
    return json.load(open(os.path.join(rd, f)))


def pc_of(rd):
    return J(rd, "proposed_changes.json")


def by_kind(pc, kind):
    return [x for x in pc["proposed_changes"] if x["kind"] == kind]


def item_at(pc, cell):
    return next((x for x in pc["proposed_changes"] if (x.get("target") or {}).get("cell") == cell), None)


# ---------------------------------------------------------------- F: flow
rd, outs = new_run("base")
X = J(rd, "extraction.json")
V = J(rd, "verification.json")
test("F stages 1-7 save; stage 7 builds proposed_changes.json and lists it to upload",
     all(o[0] == 0 for o in outs[:-1]) and "proposed_changes.json" in outs[5][1], outs[5][1])
test("F verify --final: VERIFIED, recorded as stage 8, extraction final", "status | VERIFIED" in outs[-1][1] and "recorded as stage 8" in outs[-1][1]
     and X["status"] == "final" and os.path.exists(os.path.join(rd, "checkpoints", "08_validation.json")), outs[-1][1])
test("F extraction.json carries proposed_changes, human_judgments, memory_candidates (schema /4)",
     X["schema"].endswith("/4") and X["proposed_changes"] and X["human_judgments"] and X["memory_candidates"])
test("F stage 8 is written by verify, never saved by the agent",
     run("checkpoint.py", "save", "--run-dir", rd, "--stage", 8, "--file", os.path.join(TMP, "base", "st7.json"))[0] == 1)
rc, o = run("checkpoint.py", "status", "--run-dir", rd)
test("F status shows stage 7 proposals and stage 8 validation done", "STAGE 7 proposals" in o and "STAGE 8 validation  | done" in o, o)

rr = os.path.join(TMP, "resume")
shutil.copytree(os.path.join(rd, "checkpoints"), os.path.join(rr, "checkpoints"))
run("xlsx_evidence.py", "inventory", "--run-dir", rr, "--workbooks", *sorted(glob.glob(os.path.join(TMP, "base", "wb", "*.xlsx"))))
run("checkpoint.py", "assemble", "--run-dir", rr)
strip = lambda d: {k: v for k, v in d.items() if k != "assembled_at"}
test("F resume: a fresh agent with only the checkpoints rebuilds the same extraction, proposals included, final",
     strip(J(rr, "extraction.json")) == strip(X) and open(os.path.join(rr, "proposed_changes.json"), "rb").read() ==
     open(os.path.join(rd, "proposed_changes.json"), "rb").read() and J(rr, "extraction.json")["status"] == "final")

# the 13.0 checks on the same extraction are unchanged: compare with the build 13.0 verify (kept in tests/legacy_13_0 when present)
LEG = os.path.join(HERE, "legacy_13_0")
if os.path.isdir(LEG):
    x13 = {k: v for k, v in X.items() if k not in ("proposed_changes", "human_judgments", "memory_candidates", "proposals", "next_quarter_end")}
    x13["schema"] = "xpv-onboarding-extraction/3"
    x13["stages_done"] = [1, 2, 3, 4, 5, 6]
    p = os.path.join(TMP, "base", "x13.json")
    json.dump(x13, open(p, "w"))
    r_old = subprocess.run([sys.executable, os.path.join(LEG, "verify.py"), "--run-dir", rd, "--file", p, "--out", os.path.join(TMP, "base", "v_old.json")],
                           capture_output=True, text=True)
    rc, o = run("verify.py", "--run-dir", rd, "--file", p, "--out", os.path.join(TMP, "base", "v_new.json"))
    vo, vn = J(os.path.join(TMP, "base"), "v_old.json"), J(os.path.join(TMP, "base"), "v_new.json")
    same = all(vo["checks"].get(k) == vn["checks"].get(k) for k in ("integrity", "roles", "chain", "window", "edges", "discrepancies", "fund"))
    test("F regression: on the same extraction the 13.0 and 13.2 verify agree on every 13.0 check and on the status",
         same and vo["status"] == vn["status"] == "VERIFIED", (vo["checks"], vn["checks"], vo["status"], vn["status"], r_old.stdout[-300:]))
    test("F regression: the 13.0 edge results are identical", [(e["id"], e["status"]) for e in vo["edges"]] == [(e["id"], e["status"]) for e in vn["edges"]])

# ---------------------------------------------------------------- P: proposals
pc = pc_of(rd)
kinds = {x["kind"] for x in pc["proposed_changes"]}
test("P the core set is derived from the chain: header, window roll, cash/debt from source, multiple and ownership carried, live formulas kept, revision",
     kinds == {"advance_period_label", "roll_window", "update_from_source", "carry_forward", "keep_formula", "record_revision"}, kinds)
mult = item_at(pc, "Valuation!D7")
test("P the applied multiple: carry_forward, always_confirm, NOT confirmed (an assumption, never a verified suggestion)",
     mult["kind"] == "carry_forward" and mult["always_confirm"] and mult["verify"]["status"] == "not_checkable", mult)
test("P no proposal is 'confirmed' without a check: carry_forward / analyst_input are never confirmed",
     all(x["verify"]["status"] != "confirmed" for x in pc["proposed_changes"] if x["kind"] in ("carry_forward", "analyst_input")))
cash = item_at(pc, "Valuation!D9")
test("P cash: update_from_source, rule names the source cell, its edge, class and period; confirmed via the edge",
     cash["kind"] == "update_from_source" and cash["rule"]["from"] == {"source": "W2", "cell": "BS!S5"} and cash["rule"]["edge"] == "E2"
     and cash["rule"]["from_period"] == "2026-06" and cash["verify"]["status"] == "confirmed", cash)
win = by_kind(pc, "roll_window")[0]
test("P window roll: months now / next, shift 3, filled from E1 with its source months",
     win["rule"]["months_now"] == ["2025-07", "2026-06"] and win["rule"]["months_next"] == ["2025-10", "2026-09"]
     and win["rule"]["fill_from"][0]["edge"] == "E1" and win["rule"]["fill_from"][0]["from_months"] == ["2025-07", "2026-06"], win)
hdr = by_kind(pc, "advance_period_label")[0]
test("P period header: Valuation!D3, 2026-06 -> 2026-09", hdr["target"]["cell"] == "Valuation!D3"
     and hdr["rule"] == {"from_period": "2026-06", "to_period": "2026-09", "year_from_above": False}, hdr)
rdH, outsH = new_run("split_hdr", split_header=True)
hH = by_kind(pc_of(rdH), "advance_period_label")[0]
test("P a header 'Jun 30' with its year in the cell above: confirmed, year_from_above recorded for the builder, run VERIFIED",
     hH["verify"]["status"] == "confirmed" and hH["rule"]["year_from_above"] and "status | VERIFIED" in outsH[-1][1], (hH, outsH[-1][1]))
test("P every item: id, kind, structured rule and check, current value/formula, verify status, correction types",
     all(set(("id", "kind", "rule", "check", "verify", "correction_types", "blocked_by")) <= set(x) and x["id"].startswith("PC-") for x in pc["proposed_changes"]))
own = item_at(pc, "Valuation!D13")
test("P the ownership carry-forward is blocked_by the unresolved decision that names its cell",
     own["blocked_by"] and own["blocked_by"][0] in {j["id"] for j in pc["human_judgments"]}, own)
test("P unresolved decisions include the stage 6 open question and the agent's stage 7 question",
     {j["origin"] for j in pc["human_judgments"]} == {"agent", "stage 6 open question"}, pc["human_judgments"])
test("P next quarter end is 2026-09-30", pc["next_quarter_end"] == "2026-09-30")
b1 = open(os.path.join(rd, "proposed_changes.json"), "rb").read()
run("proposals.py", "build", "--run-dir", rd)
b2 = open(os.path.join(rd, "proposed_changes.json"), "rb").read()
test("P deterministic: rebuilding gives byte-identical proposed_changes.json", b1 == b2)
rd2, _ = new_run("base2", final=False)
test("P deterministic: a fresh run from the same workbooks and stage files gives the same proposed_changes.json (save times ignored)",
     open(os.path.join(rd2, "proposed_changes.json"), "rb").read() == b1)
test("P no timestamps inside proposed_changes.json", "saved_at" not in b1.decode() and "made_at" not in b1.decode())

st = S.mutate(S.stages(), 7, lambda d: d["proposals"].append({"kind": "carry_forward", "target": {"source": "W4", "cell": "Valuation!D7"}, "what": "x", "value": 9}))
_, outs = new_run("typed", st, final=False)
test("P a proposal carrying a typed number is refused at save (code reads values)", outs[5][0] == 1 and "never carry typed numbers" in outs[5][1], outs[5][1])
st = S.mutate(S.stages(), 7, lambda d: d["proposals"].append({"kind": "carry_forward", "target": {"source": "W4", "cell": "Valuation!D8"}, "what": "EV"}))
_, outs = new_run("cf_formula", st, final=False)
test("P carry_forward on a formula cell is refused (use keep_formula)", outs[5][0] == 1 and "use keep_formula" in outs[5][1], outs[5][1])
st = S.mutate(S.stages(), 7, lambda d: d["proposals"].append({"kind": "update_from_source", "target": {"source": "W4", "cell": "Valuation!D9"},
                                                               "basis": {"edge": "E3"}, "what": "cash"}))
_, outs = new_run("wrong_edge", st, final=False)
test("P update_from_source whose edge ends elsewhere is refused", outs[5][0] == 1 and "does not end at" in outs[5][1], outs[5][1])
st = S.mutate(S.stages(), 7, lambda d: d["proposals"].append({"kind": "analyst_input", "target": {"source": "W4", "cell": "Valuation!D13"},
                                                               "what": "ownership: cap table"}))
rdA, outs = new_run("agent_kind", st, final=False)
o13 = item_at(pc_of(rdA), "Valuation!D13")
test("P the agent may change an item's kind on the same target (ownership -> analyst_input, origin agent, still always_confirm)",
     o13["kind"] == "analyst_input" and o13["origin"] == "agent" and o13["always_confirm"], o13)

st = S.mutate(S.stages(), 4, lambda d: d["provenance"][1].update(**{"from": {"source": "W2", "cell": "BS!R5"}}))
rdC, outs = new_run("contra", st)
pcC = pc_of(rdC)
cC = item_at(pcC, "Valuation!D9")
test("P a proposal whose source edge is contradicted is contradicted, and verify fails (REVIEW)",
     cC["verify"]["status"] == "contradicted" and "status | REVIEW" in outs[-1][1] and "proposals | fail" in outs[-1][1], (cC, outs[-1][1]))

X2 = J(rd, "extraction.json")
X2["proposed_changes"][0]["verify"]["status"] = "confirmed"
X2["proposed_changes"][[x["kind"] for x in X2["proposed_changes"]].index("carry_forward")]["verify"]["status"] = "confirmed"
p = os.path.join(TMP, "base", "tampered.json")
json.dump(X2, open(p, "w"))
rc, o = run("verify.py", "--run-dir", rd, "--file", p, "--out", os.path.join(TMP, "base", "vt.json"))
test("P verify catches a status edited to 'confirmed' (a false verified suggestion)", "proposals | fail" in o and "checking code says not_checkable" in o, o)
X3 = J(rd, "extraction.json")
X3["proposed_changes"][2]["current"]["value"] = 1
json.dump(X3, open(p, "w"))
rc, o = run("verify.py", "--run-dir", rd, "--file", p, "--out", os.path.join(TMP, "base", "vt2.json"))
test("P verify catches a proposal built from other workbook contents", "no longer holds what this proposal was built from" in o, o)

rdS, _ = new_run("stale", final=True)
st = S.stages()
st[6]["open_questions"].append("Does the fund apply a discount this quarter?")
p6 = os.path.join(TMP, "stale", "st6b.json")
json.dump(st[6], open(p6, "w"))
rc, o = run("checkpoint.py", "save", "--run-dir", rdS, "--stage", 6, "--file", p6)
pcS = pc_of(rdS)
test("P saving an earlier stage after stage 7 rebuilds the proposals (the new open question appears) and the extraction is provisional again",
     any("discount" in j["question"] for j in pcS["human_judgments"]) and J(rdS, "extraction.json")["status"] == "provisional", o)

# ---------------------------------------------------------------- R: revisions
rev = by_kind(pc, "record_revision")[0]
test("R the restated Q1 metric: both values kept (as reported 1,100,000 in W3, later known 1,150,000 in W4), difference 50,000",
     rev["rule"]["as_reported_at_period"]["value"] == 1_100_000 and rev["rule"]["later_known_value"]["value"] == 1_150_000
     and rev["rule"]["difference"] == 50_000 and rev["rule"]["period"] == "2026-03", rev)


def rev_case(name, fn):
    st = S.mutate(S.stages(), 7, lambda d: fn(d["revisions"][0]))
    _, outs = new_run(name, st, final=False)
    return outs[5]


o = rev_case("rev_hdr", lambda r: r.update(period="2025-12"))
test("R refused when the headers over the cells do not read the period (never assumed)", o[0] == 1 and "not directly evidenced" in o[1], o[1])
o = rev_case("rev_cur", lambda r: r.update(later_known_value={"source": "W4", "cell": "Valuation!D6"}))
test("R refused when one cell is in the current quarter's column (its header reads 2026-06)", o[0] == 1 and "not directly evidenced" in o[1], o[1])
o = rev_case("rev_empty", lambda r: r.update(as_reported_at_period={"source": "W4", "cell": "Valuation!C8"}))
test("R refused when the as-reported cell holds no number (no historical value is inferred)", o[0] == 1 and "never inferred" in o[1], o[1])
o = rev_case("rev_val", lambda r: r.update(as_reported_value=1_100_000))
test("R refused when the agent types a value instead of naming a cell", o[0] == 1 and "a value is never typed or inferred" in o[1], o[1])
o = rev_case("rev_same", lambda r: r.update(as_reported_at_period={"source": "W4", "cell": "Valuation!C6"}))
test("R refused when both cells are the same cell", o[0] == 1 and "same cell" in o[1], o[1])
_, outs = new_run("rev_equal", final=False, restated=1_100_000)
test("R refused when the two values are equal (no revision)", outs[5][0] == 1 and "no revision" in outs[5][1], outs[5][1])
st = S.mutate(S.stages(), 7, lambda d: d.update(revisions=[]))
rdN, outs = new_run("rev_none", st)
test("R no revision is emitted unless the agent names two evidenced cells", not by_kind(pc_of(rdN), "record_revision") and "VERIFIED" in outs[-1][1])

# ---------------------------------------------------------------- W: window period (header + value)
import verify as VF  # noqa: E402
from xlsx_evidence import SourceSet  # noqa: E402


def window(rd_, mw, metric="Valuation!D6"):
    srcs = SourceSet(rd_)
    srcs.ensure_all()
    W = VF.World(srcs)
    return VF.window_check(W, mw, W.key("W4", "Valuation", metric.split("!")[1]), "2026-06")


base_mw = {"source": "W4", "cells": "TTM!C6:N6", "first": "2025-07", "last": "2026-06", "link": "pasted_exact_match"}
st_, wd = window(rd, base_mw)
test("W correct window: pass, header VERIFIED_PERIOD, value SUMS_TO_METRIC", st_ == "pass" and wd["header"] == "VERIFIED_PERIOD" and wd["value"] == "SUMS_TO_METRIC", wd)
st_, wd = window(rd, dict(base_mw, first="2025-06", last="2026-05"))
test("W the same numbers claimed a month earlier: fail, DIFFERENT_PERIOD (numbers never prove a period)",
     st_ == "fail" and wd["header"] == "DIFFERENT_PERIOD" and wd["value"] == "SUMS_TO_METRIC" and "period" in wd.get("problem", ""), wd)
st_, wd = window(rd, dict(base_mw, cells="'P&L'!H9:S9", source="W2"))
test("W the source row in the monthly file (headers read Jul-25..Jun-26, values sum): pass", st_ == "pass" and wd["header"] == "VERIFIED_PERIOD", wd)
st_, wd = window(rd, dict(base_mw, cells="'P&L'!G9:R9", source="W2", first="2025-06", last="2026-05"))
test("W a row a month off: DOES_NOT_SUM and fails", st_ == "fail" and wd["value"] == "DOES_NOT_SUM", wd)
st_, wd = window(rd, dict(base_mw, header_cells="TTM!C4:N4"))
test("W header_cells named explicitly are read exactly", st_ == "pass" and wd["header_from"] == "W4:TTM!C4:N4", wd)
st_, wd = window(rd, dict(base_mw, header_cells="'P&L'!B3:M3", header_source="W2"))
test("W header_cells that read other months: fail DIFFERENT_PERIOD", st_ == "fail" and wd["header"] == "DIFFERENT_PERIOD", wd)

# column window with month labels to the LEFT (found only by the header-line search, not the header above)
col_dir = os.path.join(TMP, "colwin", "wb")
os.makedirs(col_dir, exist_ok=True)
b = FX.Book()
sh = b.sheet("Valuation")
FX.Book.put(sh, "D3", "Jun 30, 2026")
for i, mname in enumerate(FX.months(2025, 7, 12)):
    FX.Book.put(sh, f"B{10 + i}", mname)
    FX.Book.put(sh, f"C{10 + i}", 100 + i)
FX.Book.put(sh, "D6", sum(100 + i for i in range(12)), "SUM(C10:C21)")
b.save(os.path.join(col_dir, "Synthetic Co Column Window.xlsx"))
rdW = os.path.join(TMP, "colwin", "run")
run("xlsx_evidence.py", "inventory", "--run-dir", rdW, "--workbooks", os.path.join(col_dir, "Synthetic Co Column Window.xlsx"))
srcs = SourceSet(rdW)
srcs.ensure_all()
Wc = VF.World(srcs)
st_, wd = VF.window_check(Wc, {"source": "W1", "cells": "Valuation!C10:C21", "first": "2025-07", "last": "2026-06", "link": "direct_formula_link"},
                          Wc.key("W1", "Valuation", "D6"), "2026-06")
test("W a column window labelled by months on its left: header found by the header-line search, pass", st_ == "pass" and wd["header_from"] == "W1:Valuation!B10:B21", wd)

# ---------------------------------------------------------------- X: Excel review round trip
from openpyxl import load_workbook  # noqa: E402

rc, o = run("review_xlsx.py", "build", "--run-dir", rd)
rv = os.path.join(rd, "Review.xlsx")
wb = load_workbook(rv)
test("X review workbook: Start here, Unresolved decisions, Proposed changes, Memory candidates, Legend (+ hidden _meta)",
     rc == 0 and wb.sheetnames == ["Start here", "Unresolved decisions", "Proposed changes", "Memory candidates", "Legend", "_meta"], (o, wb.sheetnames))
dvs = wb["Proposed changes"].data_validations.dataValidation
test("X Decision column offers exactly Approve, Correct, Reject", dvs and dvs[0].formula1 == '"Approve,Correct,Reject"', dvs)
test("X sheets are protected; only Decision / correction / comment (and the reviewer name) are unlocked",
     wb["Proposed changes"].protection.sheet and wb["Proposed changes"]["C2"].protection.locked
     and not wb["Proposed changes"].cell(2, [c.value for c in wb["Proposed changes"][1]].index("Decision") + 1).protection.locked
     and not wb["Start here"]["B6"].protection.locked)
rc, o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", rv)
D0 = J(rd, "review_decisions.json")
test("X an untouched review reads back as all undecided: blank is never an approval",
     rc == 0 and D0["counts"]["proposal"]["undecided"] == len(pc["proposed_changes"]) and not J(rd, "approved_changes.json")["approved_changes"], o)


def fill(src, dst, rows, reviewer="A. Analyst", edit=None):
    wb = load_workbook(src)
    if reviewer is not None:
        wb["Start here"]["B6"] = reviewer
    for sheet, iid, dec, corr in rows:
        ws = wb[sheet]
        head = [c.value for c in ws[1]]
        ci = {k: head.index(k) + 1 for k in ("Decision", "Your correction", "_id")}
        for r in range(2, ws.max_row + 1):
            if ws.cell(r, ci["_id"]).value == iid:
                ws.cell(r, ci["Decision"], dec)
                if corr is not None:
                    ws.cell(r, ci["Your correction"], corr)
    if edit:
        edit(wb)
    wb.save(dst)
    return dst


PC, HJ, MC = "Proposed changes", "Unresolved decisions", "Memory candidates"
hj_own = own["blocked_by"][0]
mc = {c["subject"]: c["id"] for c in pc["memory_candidates"]}
f1 = fill(rv, os.path.join(TMP, "r1.xlsx"), [(PC, own["id"], "Approve", None)])
rc, o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", f1)
test("X approving a change blocked by an unanswered decision is refused (nothing written)", rc == 1 and "blocked by unresolved decision" in o, o)
f2 = fill(rv, os.path.join(TMP, "r2.xlsx"), [(HJ, hj_own, "Approve", None)])
rc, o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", f2)
test("X approving a decision that has no suggested answer is refused (Correct with your answer)", rc == 1 and "there is none" in o, o)
f3 = fill(rv, os.path.join(TMP, "r3.xlsx"), [(PC, mult["id"], "Correct", None)])
rc, o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", f3)
test("X Correct without a correction is refused", rc == 1 and "Correct needs a correction" in o, o)
f4 = fill(rv, os.path.join(TMP, "r4.xlsx"), [(PC, mult["id"], "Correct", "eight point seven")])
rc, o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", f4)
test("X a correction of the wrong type is refused (the multiple takes a number)", rc == 1 and "is not a number" in o, o)
f5 = fill(rv, os.path.join(TMP, "r5.xlsx"), [(MC, mc["chain.enterprise_value"], "Correct", "'No Such Sheet'!D8")])
rc, o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", f5)
test("X a cell correction naming a sheet no workbook has is refused", rc == 1 and "has a sheet" in o, o)
f5b = fill(rv, os.path.join(TMP, "r5b.xlsx"), [(MC, mc["chain.enterprise_value"], "Correct", "Valuation!E8")])
rc, o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", f5b)
test("X a cell correction whose sheet is in two workbooks must name the workbook (W4:...)", rc == 1 and "write it as" in o, o)
f6 = fill(rv, os.path.join(TMP, "r6.xlsx"), [(PC, mult["id"], "Approve", None)], reviewer="")
rc, o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", f6)
test("X a reviewer name is required once anything is decided", rc == 1 and "reviewer's name" in o, o)
f7 = fill(rv, os.path.join(TMP, "r7.xlsx"), [], edit=lambda w: w[PC].cell(3, 3, "edited what"))
rc, o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", f7)
test("X an edited row (any shown cell) is refused", rc == 1 and "edited after it was built" in o, o)


f8a = fill(rv, os.path.join(TMP, "r8a.xlsx"), [], edit=lambda w: w[PC].append([c.value for c in w[PC][2]]))
rc, o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", f8a)
test("X a copied (added) row is refused", rc == 1 and "appears twice" in o, o)
f8 = fill(rv, os.path.join(TMP, "r8.xlsx"), [], edit=lambda w: (w[PC].delete_rows(3)))
rc, o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", f8)
test("X a deleted row is refused", rc == 1 and "is missing" in o, o)
contra_rv = os.path.join(rdC, "Review.xlsx")
run("review_xlsx.py", "build", "--run-dir", rdC)
f9 = fill(contra_rv, os.path.join(TMP, "r9.xlsx"), [(PC, cC["id"], "Approve", None)])
rc, o = run("review_xlsx.py", "read", "--run-dir", rdC, "--review", f9)
test("X a contradicted proposal cannot be approved (only corrected or rejected)", rc == 1 and "not approved" in o, o)
rc, o = run("review_xlsx.py", "read", "--run-dir", rdS, "--review", rv)
test("X a review built from other proposals is refused as stale", rc == 1 and "other proposals" in o, o)

good = fill(rv, os.path.join(TMP, "good.xlsx"), [
    (HJ, hj_own, "Correct", "Yes - still 40% (cap table checked)"),
    (PC, own["id"], "Approve", None), (PC, mult["id"], "Correct", "8.75x"), (PC, cash["id"], "Approve", None),
    (PC, rev["id"], "Approve", None), (PC, win["id"], "Reject", None),
    (MC, mc["chain.enterprise_value"], "Approve", None), (MC, mc["chain.selected_multiple"], "Approve", None),
    (MC, mc["precedence.cash"], "Correct", "Cash comes from the balance sheet; use the XPV summary only if the BS is late."),
    (MC, mc["chain.equity_value"], "Reject", None)])
rc, o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", good)
D1 = J(rd, "review_decisions.json")
A1 = J(rd, "approved_changes.json")
test("X a valid review reads back: counts per sheet, reviewer recorded", rc == 0 and D1["reviewer"] == "A. Analyst"
     and D1["counts"]["proposal"]["Approve"] == 3 and D1["counts"]["proposal"]["Correct"] == 1 and D1["counts"]["proposal"]["Reject"] == 1, o)
test("X a blocked change can be approved once its decision is answered", own["id"] in [x["id"] for x in A1["approved_changes"]])
m_ = next(x for x in A1["approved_changes"] if x["id"] == mult["id"])
test("X approved_changes.json: only approved/corrected proposals, in proposal order, with the typed correction (8.75)",
     [x["id"] for x in A1["approved_changes"]] == [x["id"] for x in pc["proposed_changes"] if x["id"] in {own["id"], mult["id"], cash["id"], rev["id"]}]
     and m_["correction"] == {"type": "number", "value": 8.75} and win["id"] in A1["not_approved"], A1["approved_changes"])
test("X the answered decision is carried with the person's answer", A1["decisions_answered"][0]["answer"].startswith("Yes - still 40%"))

# ---------------------------------------------------------------- M: company memory
MEM = os.path.join(TMP, "memory", "synthetic-co.memory.json")
rc, o = run("memory.py", "apply", "--run-dir", rd, "--decisions", os.path.join(rd, "review_decisions.json"), "--memory", MEM)
M1 = json.load(open(MEM))
subj = [e["subject"] for e in M1["entries"]]
test("M only what a person approved or corrected is added: 3 memory candidates, 1 answered decision, 2 always-confirm values; "
     "rejected and undecided never are", rc == 0 and sorted(subj) == sorted(["chain.enterprise_value", "chain.selected_multiple", "precedence.cash",
                                                                           hj_own, "value.valuation!d7", "value.valuation!d13"]), (o, subj))
ty = {e["subject"]: e["type"] for e in M1["entries"]}
test("M every entry is typed: mappings are facts; source precedence, the answered decision and confirmed values are assumptions",
     ty["chain.enterprise_value"] == "fact" and ty["precedence.cash"] == ty[hj_own] == ty["value.valuation!d7"] == "assumption", ty)
mv = next(e for e in M1["entries"] if e["subject"] == "value.valuation!d7")
test("M the corrected multiple is kept as the person's assumption for the period (8.75 for 2026-06, corrected from 8.5)",
     mv["value"] == 8.75 and mv["period"] == "2026-06" and "corrected from 8.5" in mv["statement"] and mv["decision"] == "correct", mv)
ja = next(e for e in M1["entries"] if e["subject"] == hj_own)
test("M the answered decision keeps the question, the person's answer and the cells it concerns",
     ja["value"].startswith("Yes - still 40%") and ja["source"][0]["cell"] == "D13" and ja["confirmed_by"] == "A. Analyst", ja)
test("M every entry has provenance: period, source, decision, who and when, review file, what it replaced",
     all(set(("period", "source", "decision", "confirmed_by", "confirmed_at", "review_sha256", "replaces", "supersedes")) <= set(e) for e in M1["entries"]))
pe = next(e for e in M1["entries"] if e["subject"] == "precedence.cash")
test("M a correction is stored as the person's (decision correct, their wording, who and when)",
     pe["decision"] == "correct" and pe["statement"].startswith("Cash comes from the balance sheet; use") and pe["confirmed_by"] == "A. Analyst" and pe["confirmed_at"])
ee = next(e for e in M1["entries"] if e["subject"] == "chain.enterprise_value")
test("M memory keeps ordinary portable cell evidence (role, sheet, cell, row label) - no run ids needed",
     ee["value"]["role"] == "company_valuation" and ee["value"]["sheet"] == "Valuation" and ee["value"]["cell"] == "D8" and ee["value"]["row_label"] == "Enterprise value", ee)
rc, o = run("memory.py", "apply", "--run-dir", rd, "--decisions", os.path.join(rd, "review_decisions.json"), "--memory", MEM)
test("M applying the same review again adds nothing", "0 entries added" in o and len(json.load(open(MEM))["entries"]) == 6, o)
old_copy = os.path.join(TMP, "memory", "v1.json")
shutil.copy(MEM, old_copy)
# a later review corrects where the EV lives: the latest confirmed entry wins, the old one stays in history
g2 = fill(os.path.join(rd, "Review.xlsx"), os.path.join(TMP, "good2.xlsx"), [(MC, mc["chain.enterprise_value"], "Correct", "W4:Valuation!E8")], reviewer="B. Second")
rc, o = run("review_xlsx.py", "read", "--run-dir", rd, "--review", g2, "--out", os.path.join(TMP, "d2.json"))
rc, o = run("memory.py", "apply", "--run-dir", rd, "--decisions", os.path.join(TMP, "d2.json"), "--memory", MEM)
M2 = json.load(open(MEM))
rc2, cur = run("memory.py", "current", "--memory", MEM, "--json")
cur = json.loads(cur)
ne = cur["mapping:chain.enterprise_value"]
test("M latest confirmed wins: the corrected EV mapping is in force, supersedes the first and keeps a copy of what it replaced; history kept",
     len(M2["entries"]) == 7 and ne["value"]["cell"] == "E8" and ne["source"][0]["cell"] == "E8" and ne["supersedes"] == ee["entry_id"]
     and ne["replaces"]["value"]["cell"] == "D8" and ne["replaces"]["statement"] == ee["statement"] and M2["entries"][:6] == M1["entries"], (o, ne))
rc, o = run("memory.py", "check", "--memory", MEM, "--since", old_copy)
test("M check: hash chain intact and the earlier file is an exact prefix (append-only)", rc == 0 and "check OK" in o, o)
bad = copy.deepcopy(M2)
bad["entries"][0]["statement"] = "edited"
badp = os.path.join(TMP, "memory", "edited.json")
json.dump(bad, open(badp, "w"))
rc, o = run("memory.py", "check", "--memory", badp)
test("M an edited entry is detected", rc == 1 and "content changed" in o, o)
bad = copy.deepcopy(M2)
del bad["entries"][1]
json.dump(bad, open(badp, "w"))
rc, o = run("memory.py", "check", "--memory", badp)
test("M a deleted entry is detected", rc == 1 and ("removed" in o), o)
rc, o = run("memory.py", "apply", "--run-dir", rd, "--decisions", os.path.join(rd, "review_decisions.json"), "--memory", badp)
test("M nothing is appended to a memory file that is not intact", rc == 1 and "not intact" in o, o)
op_ = os.path.join(TMP, "memory", "other.json")
json.dump({"schema": "xpv-company-memory/1", "company": "Another Co", "entries": []}, open(op_, "w"))
rc, o = run("memory.py", "apply", "--run-dir", rd, "--decisions", os.path.join(rd, "review_decisions.json"), "--memory", op_)
test("M another company's memory file is refused", rc == 1 and "Another Co" in o, o)
rc, o = run("memory.py", "apply", "--run-dir", rd, "--decisions", os.path.join(rd, "review_decisions.json"))
test("M there is no default memory location: --memory is required every time", rc != 0)
rc, o = run("memory.py", "view", "--memory", MEM, "--out", os.path.join(TMP, "memory", "view.xlsx"))
vw = load_workbook(os.path.join(TMP, "memory", "view.xlsx"))
test("M readable Excel view: In force (one row per subject), History, Legend", rc == 0 and vw.sheetnames == ["In force", "History", "Legend"]
     and vw["In force"].max_row == 7 and vw["History"].max_row == 8 and vw["In force"]["B1"].value == "Type")
txt = open(MEM).read()
test("M no benchmark matching metadata in the memory file", not any(k in txt for k in ('"gold_id"', '"keywords"', "gold-mvp", "answer key")))

# ---------------------------------------------------------------- Q: the next quarter reads memory, proposes updates
st = S.mutate(S.stages(), 7, lambda d: d["memory_candidates"].append({"kind": "adjustment_rule", "subject": "addback.owner_salary",
                                                                       "statement": "Owner salary above market is added back.", "type": "assumption"}))
rdQ, outsQ = new_run("q_next", st, memory=old_copy)
pcQ = pc_of(rdQ)
subjQ = {c["subject"]: c for c in pcQ["memory_candidates"]}
test("Q memory is attached to the run (read-only copy) and the run is still VERIFIED",
     "attached" in outsQ[5][1] and os.path.exists(os.path.join(rdQ, "company_memory.in.json")) and "status | VERIFIED" in outsQ[-1][1], outsQ[5][1])
test("Q what memory already says, and this run reads the same, is not proposed again",
     "chain.enterprise_value" not in subjQ and "chain.selected_multiple" not in subjQ and pcQ["counts"]["memory_unchanged"] >= 2, sorted(subjQ))
test("Q a new reading is marked new; the agent's assumption candidate is typed 'assumption'",
     subjQ["chain.equity_value"]["memory_status"] == "new" and subjQ["addback.owner_salary"]["type"] == "assumption", subjQ.get("addback.owner_salary"))
test("Q a rule whose wording differs from memory is shown beside what memory says (precedence.cash), not silently replaced",
     subjQ["precedence.cash"]["memory_status"] == "differs" and subjQ["precedence.cash"]["memory_entry"]["statement"].startswith("Cash comes from the balance sheet; use"))
mQ = item_at(pcQ, "Valuation!D7")
test("Q the multiple carries what a person confirmed last time (8.75) beside this quarter's value (8.5), flagged as different",
     mQ["in_memory"]["value"] == 8.75 and mQ["in_memory"]["matches_current"] is False and mQ["verify"]["status"] == "not_checkable", mQ.get("in_memory"))
jQ = next(j for j in pcQ["human_judgments"] if j["id"] == hj_own)
test("Q a decision asked again is pre-filled with the last confirmed answer, marked as coming from memory - still the person's to approve",
     jQ["suggested"].startswith("Yes - still 40%") and jQ["suggested_from"] == "company memory", jQ)
run("review_xlsx.py", "build", "--run-dir", rdQ)
rc, o = run("review_xlsx.py", "read", "--run-dir", rdQ, "--review", os.path.join(rdQ, "Review.xlsx"), "--out", os.path.join(rdQ, "dq.json"))
before = len(json.load(open(MEM))["entries"])
mq = os.path.join(TMP, "memory", "q.json")
shutil.copy(MEM, mq)
rc, o = run("memory.py", "apply", "--run-dir", rdQ, "--decisions", os.path.join(rdQ, "dq.json"), "--memory", mq)
test("Q an AI-proposed assumption (and everything else) left undecided never enters memory", "0 entries added" in o and len(json.load(open(mq))["entries"]) == before, o)

rdQ2, outsQ2 = new_run("q_contra", memory=MEM)
pcQ2 = pc_of(rdQ2)
evc = next(c for c in pcQ2["memory_candidates"] if c["subject"] == "chain.enterprise_value")
jc = [j for j in pcQ2["human_judgments"] if j["origin"] == "company memory contradiction"]
evp = item_at(pcQ2, "Valuation!D8")
test("Q memory says the EV is at E8, this run reads D8: shown as a contradiction with what memory says, never overwritten",
     evc["memory_status"] == "differs" and evc["memory_entry"]["value"]["cell"] == "E8" and len(json.load(open(MEM))["entries"]) == 7, evc)
test("Q the contradiction becomes an unresolved decision that blocks the EV change until a person answers",
     len(jc) == 1 and jc[0]["id"] in evp["blocked_by"], (jc, evp.get("blocked_by")))
run("review_xlsx.py", "build", "--run-dir", rdQ2)
fq = fill(os.path.join(rdQ2, "Review.xlsx"), os.path.join(TMP, "rq.xlsx"), [(PC, evp["id"], "Approve", None)])
rc, o = run("review_xlsx.py", "read", "--run-dir", rdQ2, "--review", fq)
test("Q approving the EV change before the memory contradiction is answered is refused", rc == 1 and jc[0]["id"] in o, o)
rdQ3, _ = new_run("q_late", final=False)
before_sha = pc_of(rdQ3)["inputs_sha256"]
run("memory.py", "attach", "--run-dir", rdQ3, "--memory", MEM)
rc, o = run("checkpoint.py", "status", "--run-dir", rdQ3)
test("Q attaching memory after stage 7 makes the proposals rebuild against it (memory is an input)",
     pc_of(rdQ3)["inputs_sha256"] != before_sha and pc_of(rdQ3)["memory_attached"], o)
rc, o = run("memory.py", "attach", "--run-dir", rdQ3, "--memory", badp)
test("Q a memory file that is not intact is never attached", rc == 1 and "not intact" in o, o)
rc, o = run("memory.py", "attach", "--run-dir", rdQ3, "--memory", os.path.join(TMP, "memory", "none-yet.json"))
test("Q no memory yet for the company: nothing attached, the run carries on", rc == 0 and "none yet" in o, o)

# ---------------------------------------------------------------- G: guard
import guard as GD  # noqa: E402

st = S.mutate(S.stages(), 5, lambda d: d.update(discrepancies=[{"id": "D9", "gold_id": "HJ1", "a": {"source": "W4", "cell": "Valuation!D14"},
                                                                 "b": {"source": "W1", "cell": "Portfolio!D6"}, "status": "unresolved", "what": "x"}]))
_, outs = new_run("g_meta", st, upto=5, final=False)
test("G a stage file carrying gold_id is refused at save", outs[3][0] == 1 and "benchmark matching metadata" in outs[3][1], outs[3][1])
st = S.mutate(S.stages(), 7, lambda d: d["memory_candidates"].append({"kind": "method_note", "subject": "method.x", "statement": "Per the Gold key, use D8.",
                                                                       "keywords": ["ev"]}))
_, outs = new_run("g_mem", st, final=False)
test("G a memory candidate with keywords / citing the Gold key is refused", outs[5][0] == 1 and "benchmark" in outs[5][1], outs[5][1])
gk = os.path.join(TMP, "gold-G9.json")
json.dump({"schema": "gold-mvp/3", "answers": {}, "certification": "YES"}, open(gk, "w"))
rc, o = run("verify.py", "--run-dir", rd, "--file", gk)
test("G verify refuses a Gold key as its input", rc == 2 and "refused" in o, o)
tk = os.path.join(TMP, "x.json")
json.dump({"seed": 3, "metric_window": "x", "variant": 1}, open(tk, "w"))
rc, o = run("verify.py", "--run-dir", rd, "--file", tk)
test("G verify refuses a trial answer key (by content, whatever its name)", rc == 2, o)
ka = os.path.join(TMP, "gform", "wb")
os.makedirs(ka, exist_ok=True)
b = FX.Book()
FX.Book.put(b.sheet("Start here"), "A1", "Blind answers")
FX.Book.put(b.sheet("Answers"), "A1", "Enterprise value")
b.save(os.path.join(ka, "Company Q2 answers.xlsx"))
rc, o = run("xlsx_evidence.py", "inventory", "--run-dir", os.path.join(TMP, "gform", "run"), "--workbooks", os.path.join(ka, "Company Q2 answers.xlsx"))
test("G inventory refuses an analyst answer form (by structure) and records nothing",
     rc == 1 and "answer form" in o and not os.path.exists(os.path.join(TMP, "gform", "run", "checkpoints", "01_sources.json")), o)
shutil.copy(os.path.join(rd, "review_decisions.json"), os.path.join(TMP, "key_review.json"))
rc, o = run("memory.py", "apply", "--run-dir", rd, "--decisions", os.path.join(TMP, "key_review.json"), "--memory", MEM)
test("G a file named like benchmark material is refused", rc == 2 and "benchmark" in o, o)
test("G ordinary production cell evidence passes the guard", GD.scan({"evidence": [{"source": "W4", "cell": "Valuation!D8"}],
                                                                       "statement": "EV lives in Valuation D8", "cells_affected": []}) == [])
d_bad = J(rd, "review_decisions.json")
d_bad["decisions"][0]["keywords"] = ["x"]
dp = os.path.join(TMP, "decisions_x.json")
json.dump(d_bad, open(dp, "w"))
rc, o = run("memory.py", "apply", "--run-dir", rd, "--decisions", dp, "--memory", MEM)
test("G review decisions carrying matching metadata are refused before memory is touched", rc == 2 and len(json.load(open(MEM))["entries"]) == 7, o)

# ---------------------------------------------------------------- L: legacy 13.0 runs
rdL, _ = new_run("legacy", upto=6, final=False)
legacy_hashes = {}
import checkpoint as CKP  # noqa: E402
for n in (2, 3, 4, 5, 6):
    legacy_hashes[str(n)] = CKP.sha_file(CKP.latest(rdL, "extraction", n)[0])
json.dump({"stage": 7, "name": "validation", "made_at": "2026-10-01T00:00:00+00:00", "status": "VERIFIED", "verify_version": "13.0.0",
           "counts": {}, "stage_hashes": legacy_hashes}, open(os.path.join(rdL, "checkpoints", "07_validation.json"), "w"))
rc, o = run("checkpoint.py", "status", "--run-dir", rdL)
XL = J(rdL, "extraction.json")
test("L a build 13.0 seven-stage run (07_validation.json) still assembles final, flagged legacy_13_0", XL["status"] == "final" and XL.get("legacy_13_0"), o)
test("L its status offers stage 7 proposals next (resumable)", "NEXT: stage 7 proposals" in o and "LEGACY 13.0" in o, o)
p7 = os.path.join(TMP, "legacy", "st7.json")
json.dump(S.stages()[7], open(p7, "w"))
rc, o = run("checkpoint.py", "save", "--run-dir", rdL, "--stage", 7, "--file", p7)
rc2, o2 = run("verify.py", "--run-dir", rdL, "--final")
test("L resuming it with stage 7 then verify --final gives a 13.2 final extraction (stage 8)",
     rc == 0 and "recorded as stage 8" in o2 and J(rdL, "extraction.json")["status"] == "final" and not J(rdL, "extraction.json").get("legacy_13_0"), o + o2)

n_ok = sum(1 for _, ok in RESULTS if ok)
print(f"TESTS: {'PASS' if n_ok == len(RESULTS) else 'FAIL'} ({n_ok}/{len(RESULTS)})")
shutil.rmtree(TMP, ignore_errors=True)
sys.exit(0 if n_ok == len(RESULTS) else 1)
