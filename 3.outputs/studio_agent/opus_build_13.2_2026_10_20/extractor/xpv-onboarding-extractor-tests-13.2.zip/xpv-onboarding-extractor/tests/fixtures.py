# fixtures.py (build 13.2, extractor tests) - writes SYNTHETIC workbooks only (a made-up "Synthetic Co"), as raw Office Open XML
# with Excel-style saved values, so formulas AND values are present exactly as in a workbook Excel saved. Deterministic: fixed
# zip timestamps, so SHA-256s are stable. No real company data, no answer keys.
#   set S1  W1 fund summary ($000s) | W2 monthly financials (P&L + balance sheet, Jan-25..Jun-26) | W3 last quarter's valuation as
#           reported (Q1 2026) | W4 this quarter's valuation (Q2 2026): TTM pasted from W2, EV = metric x multiple, equity bridge,
#           ownership waterfall, and a Q1 column whose metric was later restated (1,150,000 vs 1,100,000 as reported)
# Usage: python fixtures.py --out DIR
import argparse, os, zipfile
from xml.sax.saxutils import escape

MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG = "http://schemas.openxmlformats.org/package/2006/relationships"
MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def col(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def cn(s):
    n = 0
    for ch in s:
        n = n * 26 + ord(ch) - 64
    return n


def split(a):
    i = next(i for i, ch in enumerate(a) if ch.isdigit())
    return int(a[i:]), cn(a[:i])


class Book:
    def __init__(self):
        self.sheets, self.sst, self.sidx = [], [], {}

    def sheet(self, name):
        sh = {"name": name, "cells": {}}
        self.sheets.append(sh)
        return sh

    @staticmethod
    def put(sh, a, v=None, f=None):
        sh["cells"][split(a)] = (v, f)

    def s(self, t):
        if t not in self.sidx:
            self.sidx[t] = len(self.sst)
            self.sst.append(t)
        return self.sidx[t]

    def cell(self, a, v, f):
        fx = f"<f>{escape(f)}</f>" if f else ""
        if isinstance(v, str):
            return f'<c r="{a}" t="str">{fx}<v>{escape(v)}</v></c>' if f else f'<c r="{a}" t="s"><v>{self.s(v)}</v></c>'
        if v is None:
            return f'<c r="{a}">{fx}</c>'
        return f"<c r=\"{a}\">{fx}<v>{repr(float(v)) if isinstance(v, float) and not float(v).is_integer() else int(v)}</v></c>"

    def save(self, path):
        parts = {}
        ct = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
              '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
              '<Default Extension="xml" ContentType="application/xml"/>',
              '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
              '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>']
        wrels = [f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="{PKG}">']
        sx = []
        for i, sh in enumerate(self.sheets, 1):
            rows = {}
            for (r, c), (v, f) in sh["cells"].items():
                rows.setdefault(r, []).append((c, v, f))
            rmax = max(rows) if rows else 1
            cmax = max((c for rr in rows.values() for c, _, _ in rr), default=1)
            body = "".join(f'<row r="{r}">' + "".join(self.cell(f"{col(c)}{r}", v, f) for c, v, f in sorted(rows[r], key=lambda x: x[0])) + "</row>"
                           for r in sorted(rows))
            parts[f"xl/worksheets/sheet{i}.xml"] = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="{MAIN}" '
                                                    f'xmlns:r="{REL}"><dimension ref="A1:{col(cmax)}{rmax}"/><sheetData>{body}</sheetData></worksheet>')
            ct.append(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>')
            wrels.append(f'<Relationship Id="rId{i}" Type="{REL}/worksheet" Target="worksheets/sheet{i}.xml"/>')
            sx.append(f'<sheet name="{escape(sh["name"])}" sheetId="{i}" r:id="rId{i}"/>')
        n = len(self.sheets)
        wrels.append(f'<Relationship Id="rId{n + 1}" Type="{REL}/sharedStrings" Target="sharedStrings.xml"/></Relationships>')
        parts["xl/workbook.xml"] = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook xmlns="{MAIN}" xmlns:r="{REL}"><workbookPr/>'
                                    f'<sheets>{"".join(sx)}</sheets><calcPr calcId="191029"/></workbook>')
        parts["xl/_rels/workbook.xml.rels"] = "".join(wrels)
        parts["xl/sharedStrings.xml"] = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<sst xmlns="{MAIN}" count="{len(self.sst)}" '
                                         f'uniqueCount="{len(self.sst)}">' + "".join(f'<si><t xml:space="preserve">{escape(t)}</t></si>' for t in self.sst) + "</sst>")
        ct.append("</Types>")
        parts["[Content_Types].xml"] = "".join(ct)
        parts["_rels/.rels"] = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="{PKG}"><Relationship Id="rId1" '
                                f'Type="{REL}/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        order = ["[Content_Types].xml", "_rels/.rels", "xl/workbook.xml", "xl/_rels/workbook.xml.rels", "xl/sharedStrings.xml"]
        order += sorted(k for k in parts if k not in order)
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            for k in order:
                zi = zipfile.ZipInfo(k, date_time=(2026, 7, 15, 9, 0, 0))
                zi.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(zi, parts[k].encode("utf-8"))


def months(y, m, n):
    out = []
    for _ in range(n):
        out.append(f"{MON[m - 1]}-{y % 100:02d}")
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


FILES = {"W1": "Fund - Q2 2026 Valuation Summary.xlsx", "W2": "Synthetic Co - Monthly Financials 2026.xlsx",
         "W3": "Synthetic Co Q1 2026 Valuation.xlsx", "W4": "Synthetic Co Q2 2026 Valuation.xlsx"}


def build(out, multiple=8.5, restated=1_150_000, as_reported=1_100_000, split_header=False):
    os.makedirs(out, exist_ok=True)
    hdr = months(2025, 1, 18)                                   # Jan-25 .. Jun-26 in B..S
    ebitda = [90_000 + 1_000 * i for i in range(18)]
    cash = [400_000 + 5_000 * i for i in range(18)]
    debt = [1_500_000 - 10_000 * i for i in range(18)]
    m = Book()
    pl, bs = m.sheet("P&L"), m.sheet("BS")
    for sh, rows in ((pl, {9: ("Adjusted EBITDA", ebitda)}), (bs, {5: ("Cash", cash), 8: ("Debt", debt)})):
        Book.put(sh, "A3", "Line")
        for i, hname in enumerate(hdr):
            Book.put(sh, f"{col(2 + i)}3", hname)
        for r, (lab, vals) in rows.items():
            Book.put(sh, f"A{r}", lab)
            for i, v in enumerate(vals):
                Book.put(sh, f"{col(2 + i)}{r}", v)
    m.save(os.path.join(out, FILES["W2"]))

    ttm = ebitda[6:18]                                          # Jul-25 .. Jun-26 (P&L H..S)
    metric = sum(ttm)
    ev = metric * multiple
    c_, d_ = cash[17], debt[17]
    eq = ev + c_ - d_
    own = 0.4
    xpv = eq * own
    v = Book()
    t, val = v.sheet("TTM"), v.sheet("Valuation")
    Book.put(t, "A4", "Month")
    for i, hname in enumerate(hdr[6:18]):
        Book.put(t, f"{col(3 + i)}4", hname)
    Book.put(t, "A6", "Adjusted EBITDA")
    for i, x in enumerate(ttm):
        Book.put(t, f"{col(3 + i)}6", x)
    Book.put(t, "O4", "TTM")
    Book.put(t, "O6", metric, "SUM(C6:N6)")
    Book.put(val, "A1", "Synthetic Co - valuation")
    if split_header:                                            # 'Jun 30' with the year in the cell above, as some workbooks do
        Book.put(val, "C2", "2026")
        Book.put(val, "D2", "2026")
        Book.put(val, "C3", "Mar 31")
        Book.put(val, "D3", "Jun 30")
    else:
        Book.put(val, "C3", "Mar 31, 2026")
        Book.put(val, "D3", "Jun 30, 2026")
    for r, lab in ((6, "TTM adjusted EBITDA"), (7, "Applied multiple"), (8, "Enterprise value"), (9, "Cash"), (10, "Debt"),
                   (11, "Equity value"), (13, "XPV ownership"), (14, "Value to XPV")):
        Book.put(val, f"A{r}", lab)
    Book.put(val, "C6", restated)
    Book.put(val, "C7", multiple)
    Book.put(val, "D6", metric, "TTM!O6")
    Book.put(val, "D7", multiple)
    Book.put(val, "D8", ev, "D6*D7")
    Book.put(val, "D9", c_)
    Book.put(val, "D10", d_)
    Book.put(val, "D11", eq, "D8+D9-D10")
    Book.put(val, "D13", own)
    Book.put(val, "D14", xpv, "D11*D13")
    v.save(os.path.join(out, FILES["W4"]))

    p = Book()
    pv = p.sheet("Valuation")
    Book.put(pv, "D3", "Mar 31, 2026")
    Book.put(pv, "A6", "TTM adjusted EBITDA")
    Book.put(pv, "D6", as_reported)
    Book.put(pv, "A7", "Applied multiple")
    Book.put(pv, "D7", multiple)
    p.save(os.path.join(out, FILES["W3"]))

    f = Book()
    pf = f.sheet("Portfolio")
    Book.put(pf, "A4", "Company")
    Book.put(pf, "D4", "Jun 30, 2026")
    Book.put(pf, "A6", "Synthetic Co")
    Book.put(pf, "D6", round(xpv / 1000))
    f.save(os.path.join(out, FILES["W1"]))
    return {"metric": metric, "ev": ev, "xpv": xpv, "fund": round(xpv / 1000), "files": FILES}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    print(build(ap.parse_args().out))
