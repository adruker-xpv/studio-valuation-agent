# stages_s1.py (build 13.2, extractor tests) - a hand-written, correct extraction of the synthetic set S1 (fixtures.py), one dict
# per stage, as an agent would save them. Synthetic only.
import copy

W_FUND, W_MONTHLY, W_PRIOR, W_VAL = "W1", "W2", "W3", "W4"


def stages():
    s2 = {"produced_by": "XPV Onboarding Extractor | model test | run s1", "company": "Synthetic Co", "quarter_end": "2026-06-30",
          "sources": [{"id": "W1", "role": "fund_valuation", "period": "30 Jun 2026", "contributes": "the value reported to the fund", "reason": "title"},
                      {"id": "W2", "role": "monthly_financials", "period": "Jan-25 to Jun-26", "contributes": "EBITDA, cash and debt", "reason": "P&L and BS"},
                      {"id": "W3", "role": "other_supporting", "period": "Q1 2026", "contributes": "last quarter's valuation as reported", "reason": "title"},
                      {"id": "W4", "role": "company_valuation", "period": "Q2 2026; Q1 beside it", "contributes": "the chain", "reason": "title"}],
          "valuation_workbook": "W4", "fund_workbook": "W1"}
    s3 = {"chain": {"source": "W4", "method": "EV/EBITDA multiple",
                    "valuation_metric": {"cell": "Valuation!D6", "what": "TTM adjusted EBITDA", "units": "$", "currency": "CAD"},
                    "selected_multiple": {"cell": "Valuation!D7", "what": "applied multiple", "units": "x"},
                    "enterprise_value": {"cell": "Valuation!D8", "what": "metric x multiple", "units": "$", "currency": "CAD"},
                    "bridge": [{"cell": "Valuation!D9", "sign": 1, "what": "cash"}, {"cell": "Valuation!D10", "sign": -1, "what": "debt"}],
                    "equity_value": {"cell": "Valuation!D11", "what": "EV + cash - debt", "units": "$", "currency": "CAD"},
                    "waterfall": [{"cell": "Valuation!D13", "what": "XPV ownership", "kind": "ownership"},
                                  {"cell": "Valuation!D14", "what": "value to XPV", "kind": "xpv_value"}],
                    "value_to_xpv": {"cell": "Valuation!D14", "what": "equity x ownership", "units": "$", "currency": "CAD"},
                    "metric_window": {"source": "W4", "cells": "TTM!C6:N6", "first": "2025-07", "last": "2026-06", "link": "direct_formula_link"},
                    "fund_cell": {"source": "W1", "cell": "Portfolio!D6", "units": "$000s", "currency": "CAD"}},
          "path": [{"source": "W1", "cell": "Portfolio!D6", "step": "fund value"}, {"source": "W4", "cell": "Valuation!D14", "step": "value to XPV"},
                   {"source": "W4", "cell": "Valuation!D6", "step": "metric"}],
          "direction": "top_down",
          "downstream": [{"id": "E20", "from": {"source": "W4", "cell": "Valuation!D14"}, "to": {"source": "W1", "cell": "Portfolio!D6"},
                          "class": "rounded_match", "relation": {"op": "round", "factor": 0.001, "decimals": 0}, "what": "typed into the fund summary in $000s"}],
          "discrepancies": [], "how_it_works": "Draft."}
    s4 = {"provenance": [
        {"id": "E1", "from": {"source": "W2", "cell": "'P&L'!H9:S9"}, "to": {"source": "W4", "cell": "TTM!C6:N6"}, "class": "pasted_exact_match",
         "what": "adjusted EBITDA, 12 months, pasted"},
        {"id": "E2", "from": {"source": "W2", "cell": "BS!S5"}, "to": {"source": "W4", "cell": "Valuation!D9"}, "class": "pasted_exact_match", "what": "cash"},
        {"id": "E3", "from": {"source": "W2", "cell": "BS!S8"}, "to": {"source": "W4", "cell": "Valuation!D10"}, "class": "pasted_exact_match", "what": "debt"}],
          "rejected": [], "deferred": []}
    s5 = {"downstream": [], "discrepancies": []}
    s6 = {"open_questions": ["Is the 8.5x multiple still the right one for next quarter?"],
          "inputs": [{"source": "W4", "cell": "Valuation!D7", "what": "applied multiple", "kind": "valuation_assumption", "changes": "analyst decision",
                      "next_value_from": "comparables review"}],
          "how_it_works": "The fund reports the value to XPV in $000s. The value to XPV is equity times the 40% ownership. Equity is EV plus cash "
                          "less debt. EV is the TTM adjusted EBITDA times the applied multiple. The TTM is pasted from the monthly P&L."}
    s7 = {"proposals": [],
          "revisions": [{"period": "2026-03", "as_reported_at_period": {"source": "W3", "cell": "Valuation!D6"},
                         "later_known_value": {"source": "W4", "cell": "Valuation!C6"}, "what": "Q1 2026 TTM adjusted EBITDA restated"}],
          "human_judgments": [{"question": "Is the 40% ownership still current after the Q2 option exercise?",
                               "cells_affected": [{"source": "W4", "cell": "Valuation!D13"}]}],
          "memory_candidates": [{"kind": "source_precedence", "subject": "precedence.cash",
                                 "statement": "Cash comes from the company balance sheet, not the XPV monthly summary.",
                                 "evidence": [{"source": "W2", "cell": "BS!S5"}]}]}
    return {2: s2, 3: s3, 4: s4, 5: s5, 6: s6, 7: s7}


def mutate(st, n, fn):
    st = copy.deepcopy(st)
    fn(st[n])
    return st
