# memory.py (build 13.2.5: one answer to a merged question is recorded for every question it settles; a pending decision keeps
# the keys of the questions merged into it, so they are recognised next run)
# memory.py (build 13.2.4: decisions are applied against the review's own snapshot - review/proposals_<sha>.json - never against
# a proposed_changes.json rebuilt later; no snapshot -> "required review snapshot missing")
# memory.py (build 13.2.3) - 13.2.3 adds: the contradiction gate (concepts.py) before anything is written; a coherence check
# after (one confirmed state per concept, or nothing is written); the run's source-set fingerprint on every entry, so a fact
# confirmed from one set of workbooks is not reused for the same period when the workbooks are replaced; the source lock.
# (13.2.1 text follows)
# memory.py (build 13.2.1) - company memory: one dedicated, persistent file per company, written only by this code, APPEND-ONLY,
# holding only what a person confirmed in the review workbook. Plain code, no judgment.
# Every entry says what KIND of thing it is:
#   type fact        the workbooks show it: where a concept lives (mapping), a restatement of a past period (revision)
#   type assumption  a person's call: which file wins (source_precedence), an adjustment rule, a method note, an answered
#                    unresolved decision (judgment), a value confirmed every quarter such as the applied multiple (assumption_value)
# ...and its provenance: period, source (workbook role, file, sheet, cell), decision (approve | correct), who confirmed it and
# when, the review file it came from, and what it replaced (supersedes + a copy of the replaced entry's statement and value).
# Nothing the AI proposes - fact or assumption - is ever written until a person approves or corrects it.
# PENDING DECISIONS (13.2.1) are kept apart from the confirmed entries, in their own append-only list of events (opened, resolved,
# rejected): an unresolved decision a person left blank in a review is never memory. It is shown again at the start of every
# later run (attach, `pending`), comes back as an unresolved decision that blocks every change it touches, and closes only when a
# person answers it (resolved -> the answer becomes a confirmed assumption) or rejects it as not needed. Nothing infers an answer
# from earlier quarters. A person's "Rule or note for memory" on any review row is kept as a confirmed assumption (analyst_rule).
#   attach  --run-dir R --memory PATH     copy the company's memory into the run (company_memory.in.json, read-only) so this
#                                          quarter's proposals are compared with it: matches are not proposed again, contradictions
#                                          are shown beside the new reading and become unresolved decisions. Memory is never
#                                          overridden by a run, and history is never reconstructed from the workbooks.
#   apply   --run-dir R --decisions review_decisions.json --memory PATH
#           adds: memory candidates Approved or Corrected; unresolved decisions answered (Approve = the suggested answer,
#           Correct = the person's answer) as assumptions; "always confirm" values (the multiple) Approved or Corrected as
#           assumptions. Rejected and undecided items are never added. Re-applying the same review adds nothing.
#   current --memory PATH [--json]        the memory in force: for each subject, the LATEST confirmed entry wins
#   check   --memory PATH [--since OLD]   the hash chain is intact (nothing edited, reordered or deleted); with --since, OLD is
#                                          an exact prefix of PATH (append-only across versions)
#   view    --memory PATH --out X.xlsx    a readable Excel view (In force | History | Legend); the JSON file stays the record
# Location: there is NO built-in location. PATH is given every time (the run message names it), so where memory lives - and
# who may edit it - can be decided later without changing code. Nothing here reads or writes any other path.
# Never stored: answer-key / Gold / test-bench matching metadata (refused by guard.py). Ordinary workbook evidence is stored.
import argparse, datetime, hashlib, json, os, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import guard as G  # noqa: E402
import concepts as CG  # noqa: E402
import run_manifest as RM  # noqa: E402
from onboarding_schema import SCHEMA_VERSION  # noqa: E402

SCHEMA = "xpv-company-memory/3"
READABLE = ("xpv-company-memory/1", "xpv-company-memory/2", SCHEMA)
TYPE_BY_KIND = {"mapping": "fact", "revision": "fact", "source_precedence": "assumption", "adjustment_rule": "assumption",
                "method_note": "assumption", "assumption_value": "assumption", "judgment": "assumption", "analyst_rule": "assumption"}
GENESIS = "0" * 64


def entry_hash(e):
    body = {k: v for k, v in e.items() if k != "entry_hash"}
    return hashlib.sha256(json.dumps(body, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()


def load(path, company=None):
    if not os.path.exists(path):
        return {"schema": SCHEMA, "company": company, "made_by": f"memory {SCHEMA_VERSION}", "entries": []}
    m = G.check_json_file(path, "company memory")
    if m.get("schema") not in READABLE:
        raise ValueError(f"{path} is not a company memory file ({m.get('schema')})")
    return m


def check_chain(m):
    """-> list of problems (empty = intact)."""
    P, prev = [], GENESIS
    for i, e in enumerate(m.get("entries") or []):
        if e.get("seq") != i + 1:
            P.append(f"entry {i + 1}: sequence {e.get('seq')} (entries were removed or reordered)")
        if e.get("prev_hash") != prev:
            P.append(f"entry {i + 1}: does not follow the entry before it (an entry was edited, removed or inserted)")
        if entry_hash(e) != e.get("entry_hash"):
            P.append(f"entry {i + 1}: its content changed after it was written")
        prev = e.get("entry_hash")
    prev = GENESIS
    for i, e in enumerate(m.get("pending_decisions") or []):
        if e.get("seq") != i + 1 or e.get("prev_hash") != prev or entry_hash(e) != e.get("entry_hash"):
            P.append(f"pending decision event {i + 1}: edited, removed, reordered or inserted")
        prev = e.get("entry_hash")
    return P


def pending(m):
    """the decisions still open (last event opened) -> list, oldest first. Never part of current()."""
    st = {}
    for e in m.get("pending_decisions") or []:
        k = e["decision_key"]
        if e["event"] == "opened":
            st.setdefault(k, dict(e, first_seen=e.get("period")))
            st[k]["open"] = True
        elif k in st:
            st[k]["open"] = False
    return [v for v in st.values() if v.get("open")]


def add_event(m, ev):
    lst = m.setdefault("pending_decisions", [])
    ev = dict(ev, seq=len(lst) + 1, prev_hash=lst[-1]["entry_hash"] if lst else GENESIS)
    G.check_doc(ev, "pending decision")
    ev["entry_hash"] = entry_hash(ev)
    lst.append(ev)
    return ev


def current(m):
    """subject_key -> the latest confirmed entry (later entries supersede earlier ones for the same subject)."""
    out = {}
    for e in m.get("entries") or []:
        out[e["subject_key"]] = e
    return dict(sorted(out.items()))


def run_period(run_dir):
    x = os.path.join(run_dir, "extraction.json")
    return ((json.load(open(x)).get("quarter_end") or "")[:7] or None) if os.path.exists(x) else None


def current_for_run(m, run_dir):
    """memory in force that this run may use -> (current, replaced, unknown). An entry confirmed for THIS run's period from a
    different source set (the workbooks were replaced) is not used until a person confirms it again; an older entry with no
    source fingerprint is used but listed."""
    cur = current(m)
    ss = RM.source_set(run_dir) or {}
    per = run_period(run_dir)
    out, replaced, unknown = {}, [], []
    for k, e in cur.items():
        fp = (e.get("run") or {}).get("source_set_sha256")
        same_period = per and (e.get("period") or "")[:7] == per
        if same_period and fp and ss.get("content_sha256") and fp != ss["content_sha256"]:
            replaced.append(e)
            continue
        if not fp:
            unknown.append(e)
        out[k] = e
    return out, replaced, unknown


def _sources(run_dir):
    p = os.path.join(run_dir, "extraction.json")
    return {s.get("id"): s for s in (json.load(open(p)).get("sources") or [])} if os.path.exists(p) else {}


def role_of(run_dir, sid):
    return (_sources(run_dir).get(sid) or {}).get("role")


def portable_ref(run_dir, ref):
    s_ = _sources(run_dir).get((ref or {}).get("source")) or {}
    sh, _, cell = str((ref or {}).get("cell", "")).rpartition("!")
    return {"role": s_.get("role"), "file": s_.get("file"), "sheet": sh.strip("'").replace("''", "'"), "cell": cell.replace("$", "")}


def attach(run_dir, memory_path):
    m = load(memory_path)
    P = check_chain(m)
    if P:
        raise ValueError(["the memory file is not intact - not attached:"] + P)
    x = os.path.join(run_dir, "extraction.json")
    co = json.load(open(x)).get("company") if os.path.exists(x) else None
    if co and m.get("company") and co != m["company"]:
        raise ValueError(f"the memory file is {m['company']!r}'s; this run is {co!r}")
    write_atomic(os.path.join(run_dir, "company_memory.in.json"), m)
    return m


def write_atomic(path, m):
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(m, indent=1, ensure_ascii=False, default=str) + "\n")
    os.replace(tmp, path)


def apply(run_dir, decisions_path, memory_path):
    D = G.check_json_file(decisions_path, "review decisions")
    if D.get("schema") != "xpv-review-decisions/1":
        raise ValueError("not a review_decisions.json made by review_xlsx.py read")
    RM.require_same_sources(run_dir)
    import review_xlsx as RX                  # 13.2.4: the exact snapshot the review was built from, never a rebuilt proposal set
    pc, _snap = RX.load_snapshot(run_dir, D.get("snapshot_sha256"))
    RX.check_snapshot_sources(run_dir, pc)
    if D.get("inputs_sha256") != pc.get("inputs_sha256"):
        raise ValueError("these decisions do not belong to the review snapshot they name")
    m = load(memory_path, pc.get("company"))
    P = check_chain(m)
    if P:
        raise ValueError(["the memory file is not intact - nothing was added:"] + P)
    P0 = CG.coherence(m)
    if P0:
        raise ValueError(["this memory file already holds competing confirmed values - nothing was added. Move it aside (do not edit "
                          "it) and rebuild memory from a fresh review:"] + P0)
    man = RM.load(run_dir)
    if man:
        stem = os.path.basename(memory_path)
        if stem != f"{man['company_key']}.memory.json":
            raise ValueError(f"the memory file for {man['company_key']} is {man['company_key']}.memory.json, not {stem}")
        if m.get("company_key") and m["company_key"] != man["company_key"]:
            raise ValueError(f"the memory file is {m['company_key']!r}'s; this run is {man['company_key']!r}")
    if m.get("company") and pc.get("company") and m["company"] != pc["company"]:
        raise ValueError(f"the memory file is {m['company']!r}'s; this run is {pc['company']!r}")
    cands = {c["id"]: c for c in pc.get("memory_candidates") or []}
    hjs = {j["id"]: j for j in pc.get("human_judgments") or []}
    pcs = {x["id"]: x for x in pc.get("proposed_changes") or []}
    # 13.2.3 contradiction gate: one concept confirmed two ways (in this review, or against memory in force for the same period)
    # or an identity code cannot settle -> that concept stops, nothing of it is written, it returns as a pending decision
    gate = CG.gate(CG.review_claims(pc, D, run_dir, portable_ref), current(m))
    stopped = set(gate["stopped_items"])
    fp = (pc.get("source_set") or {}).get("content_sha256") or (RM.source_set(run_dir) or {}).get("content_sha256")
    done = {(e.get("candidate_id"), e.get("review_sha256")) for e in m["entries"]}
    cur = current(m)
    qe = (pc.get("quarter_end") or "")[:7] or None
    items = []
    for d in D.get("decisions") or []:
        if d.get("decision") not in ("Approve", "Correct"):
            continue
        corr, t = d.get("correction"), d.get("item_type")
        if d["decision"] == "Correct" and corr is None:
            raise ValueError(f"{d['item_id']}: Correct without a correction")
        if t == "memory":
            c = cands.get(d["item_id"])
            if not c:
                raise ValueError(f"decision for {d['item_id']}, which is not a memory candidate of this run")
            value, statement = c.get("value"), c["statement"]
            if d["decision"] == "Correct":
                if corr["type"] == "cell":
                    ref = corr["value"]
                    sh, _, cell = ref["cell"].rpartition("!")
                    value = {"role": role_of(run_dir, ref["source"]), "sheet": sh.strip("'").replace("''", "'"), "cell": cell.replace("$", ""),
                             "corrected": True}
                    statement = f"{statement} - corrected by {D.get('reviewer')}: {ref['cell']}"
                    c = dict(c, evidence=[portable_ref(run_dir, ref)])        # the source is the person's cell, not the run's
                elif corr["type"] == "text":
                    statement = str(corr["value"])
                else:
                    value = corr["value"]
            items.append(dict(cid=c["id"], kind=c["kind"], subject=c["subject"], subject_key=c["subject_key"], statement=statement,
                              value=value, evidence=c.get("evidence") or [], type=c.get("type") or TYPE_BY_KIND[c["kind"]],
                              period=c.get("period") or qe, origin=c.get("origin"), d=d))
        elif t == "judgment":
            j = hjs.get(d["item_id"])
            if not j:
                raise ValueError(f"decision for {d['item_id']}, which is not an unresolved decision of this run")
            if d["decision"] == "Approve" and not j.get("suggested"):
                raise ValueError(f"{j['id']}: approved, but there is no suggested answer")
            ans = (corr or {}).get("value") if d["decision"] == "Correct" else j.get("suggested")
            dk = j.get("decision_key") or j["id"]
            items.append(dict(cid=j["id"], kind="judgment", subject=dk, subject_key=f"judgment:{dk}",
                              statement=f"{j['question']} -> {ans}", value=ans, evidence=[portable_ref(run_dir, c) for c in j.get("cells_affected") or []],
                              type="assumption", period=qe, origin=j.get("origin"), d=d))
            for k in sorted(set(j.get("also_keys") or []) - {dk}):     # the questions this answer settles, recognised next run
                items.append(dict(cid=f"{j['id']}:{k}", kind="judgment", subject=k, subject_key=f"judgment:{k}",
                                  statement=f"(settled together with: {j['question']}) -> {ans}", value=ans,
                                  evidence=[portable_ref(run_dir, c) for c in j.get("cells_affected") or []],
                                  type="assumption", period=qe, origin=j.get("origin"), d=d))
        elif t == "proposal":
            it = pcs.get(d["item_id"])
            if not it or not it.get("always_confirm") or not it.get("target"):
                continue                                   # other approved changes are for the quarterly builder, not memory
            ev = portable_ref(run_dir, it["target"])
            val = (corr or {}).get("value") if d["decision"] == "Correct" and (corr or {}).get("type") == "number" else (it.get("current") or {}).get("value")
            items.append(dict(cid=it["id"], kind="assumption_value", subject=f"value.{ev['sheet'].lower()}!{ev['cell'].lower()}",
                              subject_key=f"assumption_value:value.{ev['sheet'].lower()}!{ev['cell'].lower()}",
                              statement=f"{it.get('what')}: {val} for {qe}" + (f" (corrected from {(it.get('current') or {}).get('value')})"
                                                                             if d["decision"] == "Correct" else ""),
                              value=val, evidence=[ev], type="assumption", period=qe, origin=it.get("origin"), d=d))
    for d in D.get("decisions") or []:                    # a person's own rule or note on any row: a confirmed assumption
        note = (d.get("memory_note") or "").strip()
        if not note:
            continue
        t, iid = d.get("item_type"), d.get("item_id")
        if t == "memory" and iid in cands:
            base, ev = cands[iid]["subject"], cands[iid].get("evidence") or []
        elif t == "proposal" and iid in pcs and pcs[iid].get("target"):
            ev = [portable_ref(run_dir, pcs[iid]["target"])]
            base = f"value.{ev[0]['sheet'].lower()}!{ev[0]['cell'].lower()}"
        elif t == "judgment" and iid in hjs:
            base, ev = hjs[iid].get("decision_key") or iid, [portable_ref(run_dir, c) for c in hjs[iid].get("cells_affected") or []]
        else:
            raise ValueError(f"a note for {iid}, which is not an item of this run")
        items.append(dict(cid=f"{iid}:note", kind="analyst_rule", subject=f"rule.{base}", subject_key=f"analyst_rule:rule.{base}",
                          statement=note, value=None, evidence=ev, type="assumption", period=qe, origin="reviewer", d=dict(d, decision="Approve")))
    added, skipped = [], 0
    for x in items:
        d = x["d"]
        if x["cid"] in stopped or x["cid"].split(":")[0] in stopped and x["kind"] == "judgment":
            continue
        if (x["cid"], D["review_sha256"]) in done:
            skipped += 1
            continue
        old = cur.get(x["subject_key"])
        prev = m["entries"][-1]["entry_hash"] if m["entries"] else GENESIS
        e = {"seq": len(m["entries"]) + 1, "subject_key": x["subject_key"], "kind": x["kind"], "type": x["type"], "subject": x["subject"],
             "statement": x["statement"], "value": x["value"], "period": x["period"], "source": x["evidence"], "evidence": x["evidence"],
             "decision": d["decision"].lower(), "correction": d.get("correction"), "comment": d.get("comment"), "candidate_id": x["cid"],
             "candidate_origin": x["origin"], "proposed_by": "agent or code (unconfirmed until this entry)",
             "confirmed_by": D.get("reviewer"), "confirmed_at": D.get("read_at"), "review_sha256": D["review_sha256"],
             "run": {"quarter_end": pc.get("quarter_end"), "valuation_workbook_sha256": pc["valuation_workbook"]["sha256"],
                     "valuation_workbook_file": pc["valuation_workbook"]["file"], "source_set_sha256": fp},
             "supersedes": (old or {}).get("entry_id"),
             "replaces": ({"entry_id": old["entry_id"], "type": old.get("type"), "statement": old.get("statement"), "value": old.get("value"),
                           "period": old.get("period") or (old.get("run") or {}).get("quarter_end"), "confirmed_by": old.get("confirmed_by")}
                          if old else None),
             "prev_hash": prev}
        e["entry_id"] = "ME-" + hashlib.sha256(f"{x['cid']}|{D['review_sha256']}".encode()).hexdigest()[:12]
        G.check_doc(e, f"memory entry {x['cid']}")
        e["entry_hash"] = entry_hash(e)
        m["entries"].append(e)
        cur[x["subject_key"]] = e
        added.append(e)
    # pending decisions: open what a person left blank, close what they answered or rejected
    events = []
    dec = {d["item_id"]: d for d in D.get("decisions") or []}
    seen = {(e["decision_key"], e.get("review_sha256")) for e in m.get("pending_decisions") or []}
    opened = {p_["decision_key"] for p_ in pending(m)}
    jentry = {e["candidate_id"]: e["entry_id"] for e in m["entries"] if e.get("kind") == "judgment"}
    for j in sorted(hjs.values(), key=lambda x: x["id"]):
        dk = j.get("decision_key") or j["id"]
        if (dk, D["review_sha256"]) in seen or j["id"] in stopped:
            continue
        d = (dec.get(j["id"]) or {}).get("decision")
        base = {"decision_key": dk, "question": j["question"], "cells": j.get("cells_portable") or [portable_ref(run_dir, c) for c in j.get("cells_affected") or []],
                "period": qe, "review_sha256": D["review_sha256"], "at": D.get("read_at"), "by": D.get("reviewer")}
        also = sorted(set(j.get("also_keys") or []) - {dk})
        if also:
            base["also_keys"] = also
        if d in ("Approve", "Correct"):
            for k in [dk] + also:                              # closes the decision and any merged question still open
                if k in opened:
                    events.append(add_event(m, dict(base, decision_key=k, event="resolved", answer_entry=jentry.get(j["id"]))))
        elif d == "Reject":
            for k in [dk] + also:
                if k in opened:
                    events.append(add_event(m, dict(base, decision_key=k, event="rejected")))
        elif not d and dk not in opened:
            events.append(add_event(m, dict(base, event="opened")))
            for k in also:                                     # a merged question that was open separately is now part of this one
                if k in opened:
                    events.append(add_event(m, dict(base, decision_key=k, event="merged", merged_into=dk)))
    for g in gate["groups"]:                               # each stopped concept returns to the analyst, both values shown
        if g["group_id"] in opened or (g["group_id"], D["review_sha256"]) in seen:
            continue
        events.append(add_event(m, {"decision_key": g["group_id"], "question": CG.question(g), "cells": g["cells"], "period": qe,
                                    "review_sha256": D["review_sha256"], "at": D.get("read_at"), "by": D.get("reviewer"),
                                    "event": "opened", "reason": g["status"], "concept_keys": g["concept_keys"]}))
        opened.add(g["group_id"])
    m["schema"] = SCHEMA
    if not m.get("company"):
        m["company"] = pc.get("company")
    if man and not m.get("company_key"):
        m["company_key"] = man["company_key"]
    P1 = [x for x in CG.coherence(m) if x not in P0]
    if P1:                                                 # the gate should make this impossible; if not, write nothing
        raise ValueError(["the memory would hold competing confirmed values - nothing was written:"] + P1)
    created = not os.path.exists(memory_path)
    if added or events:
        write_atomic(memory_path, m)
    if gate["stopped_items"]:                              # nothing stopped is handed on to the quarterly builder either
        acp = os.path.join(run_dir, "approved_changes.json")
        if os.path.exists(acp):
            ac = json.load(open(acp))
            keep = [x for x in ac.get("approved_changes") or [] if x.get("id") not in stopped]
            if len(keep) != len(ac.get("approved_changes") or []) or any(a.get("id") in stopped for a in ac.get("decisions_answered") or []):
                ac["stopped"] = sorted(set(ac.get("stopped") or []) | {x["id"] for x in ac["approved_changes"] if x.get("id") in stopped}
                                       | {a["id"] for a in ac.get("decisions_answered") or [] if a.get("id") in stopped})
                ac["approved_changes"] = keep
                ac["decisions_answered"] = [a for a in ac.get("decisions_answered") or [] if a.get("id") not in stopped]
                with open(acp, "w", encoding="utf-8") as fh:
                    fh.write(json.dumps(ac, sort_keys=True, indent=1, ensure_ascii=False, default=str) + "\n")
    apply.events, apply.gate, apply.created = events, gate, created
    if man:                                                # 13.2.5: the review package records that memory was written from it
        mm = RM.load(run_dir)
        rp = mm.setdefault("review_package", {})
        rp["memory_applied"] = {"review_sha256": D["review_sha256"], "memory_file": os.path.basename(memory_path),
                                "result": "created" if created and (added or events) else "appended" if (added or events) else "unchanged",
                                "entries_added": len(added), "pending_events": len(events)}
        RM.write(run_dir, mm)
    return added, skipped, m


def view(m, out):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    wb = Workbook()
    base, bold, head = Font(name="Arial", size=10), Font(name="Arial", size=10, bold=True), PatternFill("solid", fgColor="DDEBF7")

    def sheet(ws, hdr, rows, widths):
        ws.append(hdr)
        for c in ws[1]:
            c.font, c.fill = bold, head
        for r in rows:
            ws.append([json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v for v in r])
        for row in ws.iter_rows(min_row=2):
            for c in row:
                c.font, c.alignment = base, Alignment(wrap_text=True, vertical="top")
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[ws.cell(1, i).column_letter].width = w
        ws.freeze_panes = "A2"
    ws = wb.active
    ws.title = "In force"
    sheet(ws, ["Subject", "Type", "Kind", "What memory says", "Period", "Where (role, sheet, cell)", "Confirmed by", "Confirmed at",
               "Replaced", "Entry"],
          [[e["subject"], e.get("type") or TYPE_BY_KIND.get(e["kind"]), e["kind"], e["statement"], e.get("period") or (e.get("run") or {}).get("quarter_end"),
            ", ".join(f"{v.get('role')} {v.get('sheet')}!{v.get('cell')}" for v in e.get("evidence") or []),
            e.get("confirmed_by"), e.get("confirmed_at"), ((e.get("replaces") or {}).get("statement") or ""), e["entry_id"]] for e in current(m).values()],
          [32, 11, 16, 70, 10, 36, 18, 22, 40, 18])
    sheet(wb.create_sheet("History"), ["#", "Subject", "Decision", "What memory says", "Supersedes", "Confirmed by", "Confirmed at", "Entry"],
          [[e["seq"], e["subject"], e["decision"], e["statement"], e.get("supersedes"), e.get("confirmed_by"), e.get("confirmed_at"), e["entry_id"]]
           for e in m.get("entries") or []], [5, 32, 10, 80, 18, 18, 22, 18])
    sheet(wb.create_sheet("Pending decisions"), ["Since", "Question", "Cells (role, sheet, cell)", "Key"],
          [[x.get("first_seen"), x["question"], ", ".join(f"{c.get('role')} {c.get('sheet')}!{c.get('cell')}" for c in x.get("cells") or []),
            x["decision_key"]] for x in pending(m)], [10, 90, 40, 18])
    sheet(wb.create_sheet("Legend"), ["Term", "Meaning"],
          [["In force", "for each subject, the latest entry a person confirmed"],
           ["fact", "the workbooks show it (where something lives, a restated past value)"],
           ["assumption", "a person's call (which file wins, a rule, the multiple, an answered decision)"],
           ["Replaced", "what the earlier entry for the same subject said; it stays in History"],
           ["Pending decisions", "questions a person has not answered yet; not memory; they block what they touch until answered or rejected"], ["History", "every entry ever added, oldest first; nothing is edited or deleted"],
           ["Supersedes", "the earlier entry for the same subject that this one replaced"],
           ["approve / correct", "the reviewer accepted the candidate as shown / with their correction"],
           ["Record", "the JSON memory file is the record; this workbook is a view of it"]], [20, 90])
    wb.save(out)


def main(argv=None):
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("apply")
    p.add_argument("--run-dir", default=".")
    p.add_argument("--decisions", required=True)
    p.add_argument("--memory", required=True)
    p = sub.add_parser("attach")
    p.add_argument("--run-dir", default=".")
    p.add_argument("--memory", required=True)
    p = sub.add_parser("pending")
    p.add_argument("--memory", required=True)
    p = sub.add_parser("current")
    p.add_argument("--memory", required=True)
    p.add_argument("--json", action="store_true")
    p = sub.add_parser("check")
    p.add_argument("--memory", required=True)
    p.add_argument("--since")
    p = sub.add_parser("view")
    p.add_argument("--memory", required=True)
    p.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    try:
        if a.cmd == "apply":
            added, skipped, m = apply(a.run_dir, a.decisions, a.memory)
            ev = getattr(apply, "events", [])
            gt = getattr(apply, "gate", {"groups": []})
            print(f"MEMORY: {len(added)} entr{'y' if len(added) == 1 else 'ies'} added ({sum(1 for e in added if e['supersedes'])} replace an earlier "
                  f"entry for the same subject), {skipped} already there | {len(m['entries'])} entries, {len(current(m))} subjects in force"
                  f" | pending decisions: {sum(e['event'] == 'opened' for e in ev)} opened, {sum(e['event'] == 'resolved' for e in ev)} resolved, "
                  f"{sum(e['event'] == 'rejected' for e in ev)} rejected, {len(pending(m))} still open"
                  + f" | {'created a new memory file' if getattr(apply, 'created', False) and (added or ev) else 'appended to the existing memory file' if added or ev else 'memory file unchanged'}"
                  + f" | coherence OK" + (f" | UPLOAD: {os.path.basename(a.memory)}" if added or ev else ""))
            if gt["groups"]:
                print(f"STOPPED: {len(gt['groups'])} concept(s) returned to the analyst as pending decisions; none of their items was written "
                      f"or handed on ({sum(g['status'] == 'conflict' for g in gt['groups'])} contradictions, "
                      f"{sum(g['status'] == 'identity_uncertain' for g in gt['groups'])} same-or-different questions):")
                for g in gt["groups"]:
                    print(f"  - {g['status']}: {g['reason']}")
                acp = os.path.join(a.run_dir, "approved_changes.json")
                if os.path.exists(acp):
                    print(f"UPLOAD: {RM.upload_text(a.run_dir, ['approved_changes.json'])}")
            return 0
        if a.cmd == "attach":
            if not os.path.exists(a.memory):
                print("MEMORY: none yet for this company - nothing attached (the first review will create it)")
                return 0
            m = attach(a.run_dir, a.memory)
            cur, repl, unk = current_for_run(m, a.run_dir)
            coh = CG.coherence(m)
            if coh:
                print("MEMORY: WARNING - this memory file holds competing confirmed values; a review cannot add to it until it is moved "
                      "aside and rebuilt from a fresh review:")
                for x in coh[:10]:
                    print(f"  - {x}")
            if repl:
                print(f"MEMORY: {len(repl)} entr{'y was' if len(repl) == 1 else 'ies were'} confirmed for this period from a different set of "
                      "workbooks (the sources were replaced): not used; they come back as candidates for a person to confirm again")
            if unk:
                print(f"MEMORY: {len(unk)} older entr{'y has' if len(unk) == 1 else 'ies have'} no source fingerprint: used, and flagged here")
            print(f"MEMORY: attached {os.path.basename(a.memory)} | {len(m['entries'])} entries, {len(cur)} in force "
                  f"({sum(1 for e in cur.values() if e.get('type', TYPE_BY_KIND.get(e.get('kind'))) == 'fact')} facts, "
                  f"{sum(1 for e in cur.values() if e.get('type', TYPE_BY_KIND.get(e.get('kind'))) == 'assumption')} assumptions) | "
                  "proposals will be compared with it (save stage 7 again if it is already saved)")
            pd_ = pending(m)
            print(f"PENDING: {len(pd_)} decision(s) still open from earlier reviews - each comes back unanswered and blocks what it touches")
            for x in pd_:
                print(f"  - {x['decision_key']} since {x.get('first_seen')}: {x['question']}")
            ans = [e for e in cur.values() if e.get("kind") == "judgment"]
            rules = [e for e in cur.values() if e.get("kind") in ("source_precedence", "adjustment_rule", "method_note")]
            if ans or rules:
                print("CONFIRMED (for question_groups and same_as_memory at stage 7 - name these, never retype them):")
                for e in ans[:40]:
                    print(f"  - decision {e['subject']} ({e.get('period')}): {str(e.get('statement'))[:160]}")
                for e in rules[:40]:
                    print(f"  - rule {e['entry_id']} {e['kind']}:{e['subject']}: {str(e.get('statement'))[:160]}")
            return 0
        m = load(a.memory)
        if a.cmd == "pending":
            pd_ = pending(m)
            print(f"PENDING: {len(pd_)} decision(s) still open")
            for x in pd_:
                print(f"  - since {x.get('first_seen')}: {x['question']}")
            return 0
        if a.cmd == "check":
            P = check_chain(m)
            coh = CG.coherence(m)
            print(f"MEMORY: coherence {'FAILED' if coh else 'OK'} | {len(current(m))} subjects in force, pending decisions open: {len(pending(m))}")
            P += coh
            if a.since:
                old = load(a.since)
                n = len(old.get("entries") or [])
                if (m.get("entries") or [])[:n] != old.get("entries"):
                    P.append(f"{os.path.basename(a.since)} is not an exact prefix of {os.path.basename(a.memory)}: earlier entries were changed or removed")
            print(f"MEMORY: check {'FAILED' if P else 'OK'} | {len(m.get('entries') or [])} entries")
            for x in P[:20]:
                print(f"  - {x}")
            return 1 if P else 0
        if a.cmd == "current":
            cur = current(m)
            if a.json:
                print(json.dumps(cur, indent=1, ensure_ascii=False, default=str))
            else:
                for k, e in cur.items():
                    print(f"{k} | {e['statement']} | {e.get('confirmed_by')} {e.get('confirmed_at')}")
            return 0
        if a.cmd == "view":
            view(m, a.out)
            print(f"MEMORY: view written {os.path.basename(a.out)} | {len(current(m))} subjects in force")
            return 0
    except G.Refused as x:
        print(f"MEMORY: refused | {x}")
        return 2
    except RM.ManifestError as x:
        print(f"MEMORY: refused | {x}")
        return 1
    except FileNotFoundError as x:
        print(f"MEMORY: refused | {os.path.basename(str(x.filename))} not found in the run; nothing was written")
        return 1
    except ValueError as x:
        P = x.args[0] if x.args and isinstance(x.args[0], list) else [str(x)]
        print("MEMORY: refused | " + P[0])
        for m_ in P[1:20]:
            print(f"  - {m_}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
