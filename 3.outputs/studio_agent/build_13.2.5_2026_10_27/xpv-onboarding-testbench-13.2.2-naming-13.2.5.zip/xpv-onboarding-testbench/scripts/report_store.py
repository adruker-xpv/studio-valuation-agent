# report_store.py (test bench 13.2.2 + naming wrapper 13.2.5) - turns a grading report into a durable, self-describing file.
# It never scores, re-scores or changes the report: the report is copied byte-for-byte inside a wrapper with identity metadata.
# Nothing from the Gold key is copied - only its case id, schema and SHA-256 - and no workbook content.
#   python scripts/report_store.py --report gold_report.json --manifest <run id>_run_manifest.json --gold <gold.json>
#        --extraction <the extraction file scored> (--listing <listing of the grading folder> | --no-folder)
# -> <Company>_<YYYY>_<Qn>[_rN]_grading_report_vN.json in the current folder; save it to
#    /Shared Documents/Valuations/3.test_bench_outputs/<Company>/<YYYY>/<Qn>[_rN]/  (vN = next free number; never overwrites)
import argparse, datetime, hashlib, json, os, re, sys

WRAPPER = "13.2.5"
BENCH_BUILD = "13.2.2"
ROOT = "/Shared Documents/Valuations"


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def names_in(listing):
    out = []

    def walk(x):
        if isinstance(x, dict):
            for k in ("Name", "{Name}", "DisplayName", "name", "FileLeafRef"):
                if isinstance(x.get(k), str):
                    out.append(x[k].strip("/").split("/")[-1])
                    break
            for v in x.values():
                if isinstance(v, (list, dict)):
                    walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
        elif isinstance(x, str):
            out.extend(n.strip().split("/")[-1] for n in x.splitlines() if n.strip())
    walk(listing)
    return out


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--manifest", required=True, help="the run manifest of the extraction that was scored")
    ap.add_argument("--gold", required=True)
    ap.add_argument("--extraction", required=True)
    ap.add_argument("--listing")
    ap.add_argument("--no-folder", action="store_true")
    ap.add_argument("--out-dir", default=".")
    a = ap.parse_args(argv)
    if not a.listing and not a.no_folder:
        print("REPORT: refused | give the listing of the grading folder (--listing) or --no-folder; never guess which versions exist")
        return 1
    M = json.load(open(a.manifest))
    rid = M.get("run_id")
    if not rid or not re.fullmatch(r"[A-Za-z][A-Za-z0-9-]*_\d{4}_Q[1-4](_r\d+)?", rid):
        print("REPORT: refused | the manifest has no valid run id")
        return 1
    X = json.load(open(a.extraction))
    if M.get("quarter_end") and X.get("quarter_end") and X["quarter_end"][:10] != M["quarter_end"]:
        print("REPORT: refused | the extraction scored is not this run's (quarter end differs)")
        return 1
    art = (M.get("artifacts") or {}).get("extraction.json") or {}
    if art.get("sha256") and art["sha256"] != sha(a.extraction):
        print("REPORT: refused | the extraction scored is not the one this run saved (SHA-256 differs)")
        return 1
    Gk = json.load(open(a.gold))
    listing = None
    if a.listing:
        raw = open(a.listing, encoding="utf-8").read()
        try:
            listing = json.loads(raw)
        except ValueError:
            listing = raw
    taken = {int(m.group(1)) for n in names_in(listing) for m in [re.fullmatch(rf"{re.escape(rid)}_grading_report_v(\d+)\.json", n)] if m}
    v = 1
    while v in taken:
        v += 1
    raw = open(a.report, "rb").read()
    report = json.loads(raw)
    leaf = f"{M['company_key']}/{M['year']}/{rid.split('_', 2)[2]}"
    doc = {"metadata": {"schema": "xpv-grading-report/1", "company": M.get("company_key"), "period": M.get("period"),
                        "extraction_run_id": rid, "extractor_build": M.get("build"), "test_bench_build": BENCH_BUILD,
                        "wrapper": WRAPPER, "gold_case_id": Gk.get("case_id"), "gold_schema": Gk.get("schema"),
                        "gold_sha256": sha(a.gold), "scored_extraction": {"file": os.path.basename(a.extraction), "sha256": sha(a.extraction),
                                                                          "run_folder": (M.get("folders") or {}).get("run")},
                        "source_fingerprints": [{"original_file": f.get("original_file"), "sha256": f.get("sha256"),
                                                 "content_sha256": f.get("content_sha256")} for f in (M.get("sources") or {}).get("files") or []],
                        "report_sha256": hashlib.sha256(raw).hexdigest(), "version": v,
                        "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")},
           "report": report}
    name = f"{rid}_grading_report_v{v}.json"
    with open(os.path.join(a.out_dir, name), "w", encoding="utf-8") as fh:
        fh.write(json.dumps(doc, indent=1, ensure_ascii=False) + "\n")
    print(f"REPORT: saved {name} | UPLOAD: {name} -> {ROOT}/3.test_bench_outputs/{leaf}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
