# test_report_store.py - the 13.2.5 naming wrapper: durable names, versions, no Gold content, report byte-identical inside.
import json, os, subprocess, sys, tempfile, hashlib
H = os.path.dirname(os.path.abspath(__file__))
T = tempfile.mkdtemp()
R = []
def t(n, ok, got=""):
    R.append(bool(ok)); print(f"- {'PASS' if ok else 'FAIL'}: {n}" + ("" if ok else f" -> {got}"))
def run(*a):
    r = subprocess.run([sys.executable, os.path.join(H, "report_store.py"), *a], capture_output=True, text=True, cwd=T); return r.stdout + r.stderr
X = {"quarter_end": "2026-06-30", "chain": {}}
xp = os.path.join(T, "ex.json"); json.dump(X, open(xp, "w"))
M = {"run_id": "Tidewater_2026_Q2_r3", "company_key": "Tidewater", "year": 2026, "period": "2026 Q2", "quarter_end": "2026-06-30", "build": "13.2.5",
     "folders": {"run": "/x"}, "artifacts": {"extraction.json": {"sha256": hashlib.sha256(open(xp, "rb").read()).hexdigest()}},
     "sources": {"files": [{"original_file": "a.xlsx", "sha256": "1" * 64, "content_sha256": "2" * 64}]}}
mp = os.path.join(T, "m.json"); json.dump(M, open(mp, "w"))
gp = os.path.join(T, "g.json"); json.dump({"schema": "gold-mvp/3", "case_id": "G9", "answers": {"secret": 123}}, open(gp, "w"))
rp = os.path.join(T, "gold_report.json"); open(rp, "w").write('{"score": {"core": "10/10"}}')
o = run("--report", rp, "--manifest", mp, "--gold", gp, "--extraction", xp)
t("no listing: refused", "REPORT: refused" in o, o)
o = run("--report", rp, "--manifest", mp, "--gold", gp, "--extraction", xp, "--no-folder")
f1 = os.path.join(T, "Tidewater_2026_Q2_r3_grading_report_v1.json")
t("first report is v1 with the durable name and folder", os.path.exists(f1) and "3.test_bench_outputs/Tidewater/2026/Q2_r3" in o, o)
D = json.load(open(f1))
t("the report is carried unchanged", D["report"] == json.load(open(rp)) and D["metadata"]["report_sha256"] == hashlib.sha256(open(rp, "rb").read()).hexdigest())
t("metadata: company, period, run, builds, Gold case and schema, fingerprints", D["metadata"]["extraction_run_id"] == "Tidewater_2026_Q2_r3"
  and D["metadata"]["gold_case_id"] == "G9" and D["metadata"]["source_fingerprints"] and D["metadata"]["test_bench_build"] == "13.2.2")
t("no Gold content copied", "secret" not in open(f1).read() and "answers" not in open(f1).read())
lp = os.path.join(T, "l.json"); json.dump({"value": [{"Name": "Tidewater_2026_Q2_r3_grading_report_v1.json"}]}, open(lp, "w"))
o = run("--report", rp, "--manifest", mp, "--gold", gp, "--extraction", xp, "--listing", lp)
t("a rerun becomes v2; v1 is never overwritten", os.path.exists(os.path.join(T, "Tidewater_2026_Q2_r3_grading_report_v2.json")), o)
open(xp, "w").write('{"quarter_end": "2026-06-30", "changed": 1}')
o = run("--report", rp, "--manifest", mp, "--gold", gp, "--extraction", xp, "--no-folder")
t("an extraction that is not the run's saved one is refused", "REPORT: refused" in o and "SHA-256" in o, o)
print(f"TESTS: {'PASS' if all(R) else 'FAIL'} ({sum(R)}/{len(R)})")
