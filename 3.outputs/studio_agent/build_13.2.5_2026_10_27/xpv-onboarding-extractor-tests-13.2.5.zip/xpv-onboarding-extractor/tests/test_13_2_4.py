# test_13_2_4.py - build 13.2.4 tests: the review round trip is checked against the exact proposals snapshot the review was
# built from. (helpers as in test_13_2_3.py)
# test_13_2_3.py - build 13.2.3 tests: the contradiction gate, the source-fingerprint lock, generated-artifact naming and identity,
# and backward compatibility. Synthetic only: the made-up five-workbook set T1 from the test bench (path given by --trial or the
# XPV_TRIAL environment variable). No real company, cell or value is used, and nothing here names a source workbook the code
# expects: source files are renamed freely, extra files are added, and the code must not care.
# Usage: python tests/test_13_2_3.py --trial <path to xpv-onboarding-testbench/trial>   (last line: TESTS: PASS (n/n))
import argparse, glob, json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.join(os.path.dirname(HERE), "scripts")
sys.path.insert(0, S)
ap = argparse.ArgumentParser()
ap.add_argument("--trial", default=os.environ.get("XPV_TRIAL", os.path.join(HERE, "..", "..", "xpv-onboarding-testbench", "trial")))
A = ap.parse_args()
TR = os.path.abspath(A.trial)
T1 = os.path.join(TR, "set-T1")
REF = os.path.join(TR, "reference", "T1")
TMP = tempfile.mkdtemp(prefix="t1324-")
RESULTS = []


def run(script, *args):
    r = subprocess.run([sys.executable, os.path.join(S, script), *args], capture_output=True, text=True, timeout=600)
    return r.stdout + r.stderr


def test(name, ok, got=""):
    RESULTS.append(bool(ok))
    print(f"- {'PASS' if ok else 'FAIL'}: {name}" + ("" if ok else f" -> {str(got)[:600]}"))


def workbooks(names=None, extra=None, edit=None):
    """a copy of T1 under new file names (kept in the same sort order so stage ids stay W1..W5), plus optional extras."""
    d = tempfile.mkdtemp(dir=TMP, prefix="wb-")
    src = sorted(glob.glob(os.path.join(T1, "*.xlsx")))
    out = []
    for i, p in enumerate(src):
        nm = (names[i] if names else os.path.basename(p))
        q = os.path.join(d, nm)
        shutil.copyfile(p, q)
        out.append(q)
    if edit is not None:
        from openpyxl import load_workbook
        i, sheet, cell, val = edit
        wb = load_workbook(out[i])
        wb[sheet][cell] = val
        wb.save(out[i])
    for e in extra or []:
        q = os.path.join(d, os.path.basename(e))
        shutil.copyfile(e, q)
        out.append(q)
    return out


def full_run(name, wbs, company="Tidewater", period="2026 Q2", n=1, s7=None, memory=None, init=True):
    rd = os.path.join(TMP, name)
    shutil.rmtree(rd, ignore_errors=True)
    os.makedirs(rd)
    o = run("xlsx_evidence.py", "inventory", "--run-dir", rd, "--workbooks", *wbs)
    if init:
        o += run("run_manifest.py", "init", "--run-dir", rd, "--company", company, "--period", period, "--run-number", str(n))
    for k in range(2, 7):
        o += run("checkpoint.py", "save", "--run-dir", rd, "--stage", str(k), "--file", glob.glob(os.path.join(REF, f"0{k}_*.json"))[0])
    if memory:
        o += run("memory.py", "attach", "--run-dir", rd, "--memory", memory)
    p = os.path.join(rd, "s7.json")
    json.dump(s7 or {}, open(p, "w"))
    o += run("checkpoint.py", "save", "--run-dir", rd, "--stage", "7", "--file", p)
    o += run("verify.py", "--run-dir", rd, "--final")
    return rd, o


def pc(rd):
    return json.load(open(os.path.join(rd, "proposed_changes.json")))


def fill(rd, decisions, out_name="Review.completed.xlsx", reviewer="Test Reviewer", notes=None):
    """decisions: {item_id: (Decision, correction or None)}; anything else stays blank."""
    from openpyxl import load_workbook
    run("review_xlsx.py", "build", "--run-dir", rd)
    wb = load_workbook(os.path.join(rd, "Review.xlsx"))
    wb["Start here"]["B6"] = reviewer
    for sn in ("Unresolved decisions", "Proposed changes", "Memory candidates"):
        ws = wb[sn]
        head = [c.value for c in ws[1]]
        di, ci, ii = head.index("Decision") + 1, head.index("Your correction") + 1, head.index("_id") + 1
        ni = head.index("Rule or note for memory") + 1
        for r in range(2, ws.max_row + 1):
            iid = ws.cell(r, ii).value
            if iid in decisions:
                d, c = decisions[iid]
                ws.cell(r, di).value = d
                if c is not None:
                    ws.cell(r, ci).value = c
            if notes and iid in notes:
                ws.cell(r, ni).value = notes[iid]
    p = os.path.join(rd, out_name)
    wb.save(p)
    return p


def ids(P, kind=None, subject=None, target=None):
    out = []
    for c in P["memory_candidates"]:
        if (kind is None or c["kind"] == kind) and (subject is None or c["subject"] == subject):
            out.append(c["id"])
    for it in P["proposed_changes"]:
        if target and (it.get("target") or {}).get("cell") == target and (kind is None or it["kind"] == kind):
            out.append(it["id"])
    return out


def clean_decisions(P):
    """approve everything that can be approved; leave decisions with no suggested answer and blocked changes blank."""
    D = {}
    for c in P["memory_candidates"]:
        D[c["id"]] = ("Approve", None)
    for it in P["proposed_changes"]:
        if not it.get("blocked_by") and it["verify"]["status"] != "contradicted":
            D[it["id"]] = ("Approve", None)
    return D



import hashlib  # noqa: E402
import memory as MEM  # noqa: E402
import review_xlsx as RX  # noqa: E402
from openpyxl import load_workbook  # noqa: E402

WB = sorted(glob.glob(os.path.join(T1, "*.xlsx")))


def meta(path):
    wb = load_workbook(path)
    return {r[0].value: r[1].value for r in wb["_meta"].iter_rows() if r[0].value}


def rows(path):
    wb = load_workbook(path)
    out = {}
    for sn in ("Unresolved decisions", "Proposed changes", "Memory candidates"):
        ws = wb[sn]
        head = [c.value for c in ws[1]]
        for r in ws.iter_rows(min_row=2, values_only=True):
            if r[head.index("_id")]:
                out[r[head.index("_id")]] = r[head.index("_hash")]
    return out


def tamper(src, name, fn):
    wb = load_workbook(src)
    fn(wb)
    p = os.path.join(os.path.dirname(src), name)
    wb.save(p)
    return p


def read(rd, rv):
    for f in ("review_decisions.json", "approved_changes.json"):
        if os.path.exists(os.path.join(rd, f)):
            os.remove(os.path.join(rd, f))
    return run("review_xlsx.py", "read", "--run-dir", rd, "--review", rv)


# 1. snapshot -> review -> analyst edits allowed fields -> completed review -> read back, every _id/_hash unchanged
rd, o = full_run("one", workbooks(), n=1)
o = run("review_xlsx.py", "build", "--run-dir", rd)
M = meta(os.path.join(rd, "Review.xlsx"))
sha = hashlib.sha256(open(os.path.join(rd, "proposed_changes.json"), "rb").read()).hexdigest()
snap = os.path.join(rd, "review", f"proposals_{sha[:16]}.json")
test("1 building a review saves the exact proposals as an immutable snapshot and puts its fingerprint in the review",
     M.get("snapshot_sha256") == sha and os.path.exists(snap) and open(snap, "rb").read() == open(os.path.join(rd, "proposed_changes.json"), "rb").read(), (M, o))
test("1 the snapshot is listed for upload with the review", f"review/proposals_{sha[:16]}.json" in o and "Review.xlsx" in o, o)
P = pc(rd)
D = clean_decisions(P)
built = rows(os.path.join(rd, "Review.xlsx"))
mc = P["memory_candidates"][0]["id"]
rv = fill(rd, D, "Tidewater_2026_Q2_Review.completed.xlsx", notes={mc: "Keep this one."})
wbx = load_workbook(rv)
ws = wbx["Proposed changes"]
head = [c.value for c in ws[1]]
ws.cell(2, head.index("Comment") + 1).value = "checked against the board pack"
wbx.save(rv)
o = read(rd, rv)
dec = json.load(open(os.path.join(rd, "review_decisions.json")))
test("1 the completed review is accepted", ("REVIEW: accepted" in o), o)
test("1 every _id/_hash read back equals the workbook as built and the snapshot", rows(rv) == built
     and {d["item_id"]: d["item_hash"] for d in dec["decisions"]} == {k: v for k, v in built.items() if k in {d["item_id"] for d in dec["decisions"]}}
     and dec["snapshot_sha256"] == sha, dec.get("snapshot_sha256"))

# the original failure: proposals rebuilt after the review was built (here: with memory attached, so ids change)
mem = os.path.join(TMP, "m0", "Tidewater.memory.json")
os.makedirs(os.path.dirname(mem))
o = run("memory.py", "apply", "--run-dir", rd, "--decisions", os.path.join(rd, "review_decisions.json"), "--memory", mem)
test("5 unchanged sources and unchanged snapshot: the memory write is allowed", "created a new memory file" in o and "coherence OK" in o, o)
rd2, _ = full_run("rebuilt", workbooks(), n=2)
run("review_xlsx.py", "build", "--run-dir", rd2)
P2 = pc(rd2)
rv2 = fill(rd2, clean_decisions(P2), "Tidewater_2026_Q2_r2_Review.completed.xlsx")
run("memory.py", "attach", "--run-dir", rd2, "--memory", mem)
run("checkpoint.py", "save", "--run-dir", rd2, "--stage", "7", "--file", os.path.join(rd2, "s7.json"))
P2b = pc(rd2)
changed = [x["id"] for x in P2["memory_candidates"]] != [x["id"] for x in P2b["memory_candidates"]]
o = read(rd2, rv2)
test("R proposals rebuilt after the review was built (memory candidate ids changed): the review is still read against its snapshot",
     changed and ("REVIEW: accepted" in o), (changed, o))
mem2 = os.path.join(TMP, "m2", "Tidewater.memory.json")
os.makedirs(os.path.dirname(mem2))
o = run("memory.py", "apply", "--run-dir", rd2, "--decisions", os.path.join(rd2, "review_decisions.json"), "--memory", mem2)
test("R ... and memory is written from the snapshot, not from the rebuilt proposals", "created a new memory file" in o, o)

# a new session: only what was uploaded comes back
rdS = os.path.join(TMP, "session2")
up = os.path.join(rd, "upload")
run("xlsx_evidence.py", "inventory", "--run-dir", rdS, "--workbooks", *workbooks())
files = glob.glob(os.path.join(up, "*.json")) + glob.glob(os.path.join(up, "checkpoints", "*.json")) + glob.glob(os.path.join(up, "review", "*.json"))
o = run("run_manifest.py", "stage-in", "--run-dir", rdS, "--files", *files)
o2 = run("xlsx_evidence.py", "inventory", "--run-dir", rdS, "--workbooks", *workbooks())
o3 = read(rdS, rv)
test("R a new session that stages the uploaded run folder reads the same review", "STAGED" in o and ("REVIEW: accepted" in o3), (o, o3))

# 2. modify / add / delete a proposal row -> refused
def edit_cell(wb):
    ws = wb["Proposed changes"]
    ws.cell(2, 2).value = "something else"
def add_row(wb):
    ws = wb["Proposed changes"]
    vals = [c.value for c in ws[2]]
    head = [c.value for c in ws[1]]
    vals[head.index("_id")] = "PC-000000000000"
    ws.append(vals)
def del_row(wb):
    wb["Proposed changes"].delete_rows(2)
def edit_hash(wb):
    ws = wb["Proposed changes"]
    head = [c.value for c in ws[1]]
    ws.cell(2, head.index("_hash") + 1).value = "0" * 16
for nm, fn, why in (("modify", edit_cell, "changed"), ("add", add_row, "not"), ("delete", del_row, "missing"), ("hash", edit_hash, "")):
    o = read(rd, tamper(rv, f"t-{nm}.xlsx", fn))
    test(f"2 a proposal row {nm}{'ed' if nm != 'hash' else ' changed'} -> refused, nothing written", ("REVIEW: refused" in o)
         and not os.path.exists(os.path.join(rd, "review_decisions.json")), o)

# 3. swap the proposal snapshot -> refused
bak = open(snap, "rb").read()
other = json.loads(bak)
other["proposed_changes"] = other["proposed_changes"][1:]
open(snap, "w").write(json.dumps(other))
o = read(rd, rv)
test("3 the snapshot file swapped for other proposals -> refused", ("REVIEW: refused" in o) and "not the snapshot this review was built from" in o, o)
open(snap, "wb").write(bak)
def other_sha(wb):
    for r in wb["_meta"].iter_rows():
        if r[0].value == "snapshot_sha256":
            r[1].value = hashlib.sha256(b"another").hexdigest()
o = read(rd, tamper(rv, "t-meta.xlsx", other_sha))
test("3 a review pointing at another snapshot -> refused", ("REVIEW: refused" in o) and "snapshot missing" in o, o)
rdO, _ = full_run("other-run", workbooks(), n=3)
run("review_xlsx.py", "build", "--run-dir", rdO)
rvO = fill(rdO, clean_decisions(pc(rdO)), "Tidewater_2026_Q2_r3_Review.completed.xlsx")
o = read(rd, rvO)
test("3 a review that belongs to another run is still refused", ("REVIEW: refused" in o) and "Tidewater_2026_Q2_r3" in o, o)

# 4. missing canonical snapshot -> refused, never reconstructed
os.remove(snap)
o = read(rd, rv)
test("4 snapshot missing -> 'required review snapshot missing', nothing written, even though proposed_changes.json is present",
     ("REVIEW: refused" in o) and "required review snapshot missing" in o and os.path.exists(os.path.join(rd, "proposed_changes.json"))
     and not os.path.exists(os.path.join(rd, "review_decisions.json")) and not os.path.exists(snap), o)
json.dump(dec, open(os.path.join(rd, "review_decisions.json"), "w"))
mem3 = os.path.join(TMP, "m3", "Tidewater.memory.json")
os.makedirs(os.path.dirname(mem3))
o = run("memory.py", "apply", "--run-dir", rd, "--decisions", os.path.join(rd, "review_decisions.json"), "--memory", mem3)
test("4 memory write with the snapshot missing -> refused, no memory file created", "required review snapshot missing" in o and not os.path.exists(mem3), o)
def no_sha(wb):
    for r in wb["_meta"].iter_rows():
        if r[0].value == "snapshot_sha256":
            r[1].value = None
o = read(rd, tamper(rv, "t-old.xlsx", no_sha))
test("4 a review with no snapshot fingerprint (built before 13.2.4) -> refused, asks for a fresh review", "required review snapshot missing" in o
     and "fresh review" in o, o)
open(snap, "wb").write(bak)

# 5b. changed sources -> refused
json.dump(dec, open(os.path.join(rd, "review_decisions.json"), "w"))
rep = workbooks(edit=(4, load_workbook(WB[4], read_only=True).sheetnames[0], "Z99", 1))
run("xlsx_evidence.py", "inventory", "--run-dir", rd, "--workbooks", *rep)
o = run("memory.py", "apply", "--run-dir", rd, "--decisions", os.path.join(rd, "review_decisions.json"), "--memory", mem3)
test("5 changed source fingerprints -> the memory write is refused", "source set changed" in o and not os.path.exists(mem3), o)

n = len(RESULTS)
print(f"TESTS: {'PASS' if all(RESULTS) else 'FAIL'} ({sum(RESULTS)}/{n})")
shutil.rmtree(TMP, ignore_errors=True)
sys.exit(0 if all(RESULTS) else 1)
