---
name: xpv-valuation-playbook
description: How XPV's portfolio-company valuations work across the workbooks that make them - company monthly financials, XPV monthly summaries, TTM or pro forma files, the company valuation workbook and the fund valuation workbook - and how to read them like an experienced valuation analyst - the valuation chain, provenance between files, evidence classes, traps careless readers fall into, periods, units, currencies, waterfalls, discrepancies, and what an analyst must confirm. Read it before onboarding, extracting from, or reviewing any company or fund valuation workbook.
---

# XPV valuation playbook (build 13.0)

This is your briefing as if you were a sharp new analyst joining XPV's valuation team. It explains *why* things matter so you can
judge situations it does not list. Section 11 is XPV's own house rules; where it conflicts with anything else here, section 11 wins.
This playbook is general guidance informed by the International Private Equity and Venture Capital Valuation Guidelines (IPEV); it
is not XPV's valuation policy.

## Glossary
| Term | Meaning |
|---|---|
| Fair value | The price a market participant would pay for the holding at the measurement date (here: the quarter end) |
| EV | Enterprise value: value of the operating business, before debt and cash |
| TTM / LTM | Trailing / last twelve months: the 12 months ending at the quarter end |
| EBITDA | Earnings before interest, tax, depreciation and amortisation |
| Add-back | An adjustment to reported EBITDA for items not expected to recur (one-off legal fees, owner compensation above market) |
| Pro forma | Figures restated as if an acquisition (or disposal) had happened before the start of the window |
| Equity bridge | EV + cash - debt - other claims ranking ahead of equity = total equity value |
| Waterfall | How total equity is shared among holders: ownership shares, options, a management incentive pool (MIP), preferred shares |
| XPV's value | XPV's share after the waterfall: the number the fund valuation workbook reports for the company |
| Fund workbook | The fund valuation workbook or summary: every company's reported value; it feeds the LP report |
| LP report | The report to the fund's investors (limited partners): the end product everything must trace to |
| MOIC | Multiple on invested capital: XPV's value / invested capital |
| FX | Foreign exchange (a currency conversion) |
| Provenance | Where a number came from, and how strongly the files prove it |

## 1. What matters most
The LP report is the end product. Every number in it must trace back to the company's own figures. When you read the workbooks you
are reconstructing that trace: **monthly figures -> TTM earnings -> applied multiple -> EV -> equity bridge -> waterfall -> XPV's value
-> fund workbook**. Anything that feeds that chain matters; anything that does not is context.

## 2. Two ways in - both valid, and the two agents use different ones on purpose
**Top-down (the extractor):** start from the value the fund reports, find it in the company workbook (it may be in $, $000s or $m, and
in another currency) and follow the formulas back. A chain that reaches the reported value is strong evidence; then read forward to
make sure the story holds. **Bottom-up (the blind reviewer):** start from the source financials, build the 12 months of earnings, find
where that figure lands and follow it forward to the fund. Bottom-up catches what top-down can miss: a valuation built on a stale or
different version of the source figures, or a reported value that reconciles only because of an offsetting error.

## 3. Several workbooks: what each usually contributes
- **Company monthly financials / management accounts:** reported revenue and EBITDA by month, add-back schedules, the balance sheet.
  Often large and messy: inflated used ranges, hidden rows, old drafts.
- **TTM / pro forma file:** the 12-month window, add-backs and pre-acquisition months for an acquired business. Pro forma rows may cover
  only part of the window; say which months, and where their figures came from.
- **XPV monthly summary:** XPV's own record of the monthly figures, usually typed and rounded to $000s. It may corroborate without
  feeding anything; a workbook that contributes nothing is a correct finding (`not_used`).
- **Company valuation workbook:** the chain itself, often with the prior quarter beside it, sensitivities and comparables.
- **Fund valuation workbook:** the reported value, sometimes after a fund-level adjustment (another multiple, a discount, a hold at cost).
Files link to each other by file name. A link to a name that was not supplied (a "v3", a draft, a local copy) shows only the cached
values; whether the supplied file is that version is a question, not a fact.

## 4. Evidence classes - how strongly a relationship is proven
Every claimed relationship carries one: **direct formula link** (the formula refers to the source), **pasted or typed exact match**
(identical, no formula), **rounded match** (equal after stated rounding), **arithmetic transformation** (reproducible by a stated
operation), **contextual support** (labels or notes only), **inferred candidate** (best reading), **unresolved**. Equal numbers are a
match, never a link: two cells can agree by coincidence, by a paste from another version, or by an offsetting change. Say what the
evidence shows, no more.

## 5. Traps careless readers fall into
- **Sensitivity tables.** Rows of EV at several multiples, often an Excel data table (`=TABLE(...)`); one row equals the real EV. The real
  EV is the one the equity bridge and the waterfall use.
- **Comparables "implied EV".** Peer median x the company's EBITDA: a cross-check, not the valuation, unless the workbook applies it.
- **The previous quarter.** Often a full, live chain beside the current one. Check the column header and the 12 months.
- **Copies.** Report rows and cap-table inputs that only repeat a chain cell (`=Sheet!B16`, `=ROUND(B16/1000,0)`). The answer is the
  calculation, not the copy; copies that feed the LP report must be known, because they must stay linked when the workbook rolls forward.
- **Look-alike arithmetic.** Options x exercise price, units x price per unit, peer EV / EBITDA: products that look like
  "metric x multiple" and are not.
- **A TTM that is not the metric.** A rolling TTM in the management accounts can exclude the pro forma months the valuation includes.
- **Stale and hidden areas.** Old sheets, `#REF!` errors, pasted history, very hidden tabs. Note them; do not build on them.
- **Typed history.** Prior quarters typed into a report may be in another currency or unit than the live quarter.

## 6. Periods
- "Jun 30" or "Dec 31" under a year row means 30 June / 31 December of that year, never the year 2030 or 2031.
- A TTM is exactly 12 consecutive months ending at the quarter end. Check the header of every month in the window.
- Fiscal years can differ from calendar years; pro forma rows can cover only part of the window. Say so.

## 7. Units and currency
State the unit ($, $000s, $m) and currency of every number you name. When the fund workbook reports in another currency, the
conversion cell and its rate are part of the chain, and the rate's source and date are an analyst question.

## 8. Waterfalls - read every step
Common shapes: a simple ownership share; options treated as exercised (exercise proceeds added to equity, divided over fully diluted
units); a management incentive pool above a hurdle; preferred shares taking the greater of a liquidation preference and their
as-converted share. Name each step, its inputs, and whether a preference or hurdle is binding this quarter.

## 9. Discrepancies are results, not failures
When the company value and the fund-reported value differ, or two versions of a source disagree, record the difference, the cells,
and the driver if the evidence shows one (another multiple, a fund adjustment, a different version). Leave it unresolved unless the
workbooks resolve it. A run that concludes "the supplied evidence does not establish which version was approved" has done its job;
a run that forces the numbers to agree has not.

## 10. What is material, and when you are done
Material: anything that changes the metric, the multiple, a bridge item, a waterfall step, XPV's value or the reported value; the link
from the company value to the fund value; a rival a careful reader could mistake for the answer; copies that feed the LP report.
Not material: stale tabs and unused alternatives that feed nothing, history columns, formulas downstream of the chain that never
reach the report. Inventory those once and move on; look at an unusual sheet long enough to know whether it matters. You are done when
the chain is mapped, the material relationships upstream and downstream are classified, every material difference is recorded, and
the checks have run. Keep a running `notes.md` (one line per finding, with its cells); it survives a long session and is part of the
audit trail.

## 11. XPV house rules (to be completed by XPV)
- Valuation policy and methods used, and when each applies:
- Comparable-set and multiple selection: who decides, how it is documented:
- Add-back and pro forma policy (what qualifies, who approves):
- Currency and FX rate policy (source, date convention):
- Reporting units and rounding for the fund workbook and LP report:
- Fund-level adjustments to company values (who decides, how recorded):
- Named reviewers and approval roles:
