# gold_suggest.py (build 13.0, test bench) - lists the matching metadata a Gold key still needs, so an analyst can upgrade a free-text key
# without rebuilding it. Read-only: it never changes the key, never writes semantic answers, never guesses a match.
# Suggestions are mechanical: (1) a numbered id (R1, MD1, HJ1) for an item with none; (2) cell references ALREADY WRITTEN in the item's own
# text ('Valuation Summary!H11', "W1:'Valuation Summary'!H11") resolved against the sheets Gold's anchors name (and the workbooks, if given);
# (3) the item's own wording, offered so the analyst can pick keywords - keywords are the analyst's decision.
# Usage: python gold_suggest.py --gold KEY.json [--workbooks A.xlsx ...] [--out suggestions.json]
import argparse, json, os, re, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gold_validate as GV  # noqa: E402
from gold_validate import iid, refs_in_text, anchors_of, parse_ref, skey  # noqa: E402
from xlsx_evidence import Book as XBook  # noqa: E402

SECTIONS = [("known_rivals", "rival", "R", ("candidate", "looks_like", "why_not_the_answer")),
            ("material_discrepancies", "discrepancy", "MD", ("item", "explanation")),
            ("human_judgments", "judgment", "HJ", ("question",))]


def main(argv=None):
    ap = argparse.ArgumentParser(description="list the matching metadata a Gold key needs")
    ap.add_argument("--gold", required=True)
    ap.add_argument("--workbooks", nargs="*")
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    gold = GV.read_json(a.gold)
    sheets = {}                                                  # sheet lower -> {(wid, real name)}
    refs = [r for c in (gold.get("answers") or {}).values() if isinstance(c, dict) for _, r in anchors_of(c)]
    refs += [r for k, *_ in SECTIONS for it in gold.get(k) or [] if isinstance(it, dict) for r in it.get("cells") or []]
    for r in refs:
        p = parse_ref(r)
        if p:
            sheets.setdefault(skey(p[1]), set()).add((p[0], p[1]))
    if a.workbooks:
        books, _, _ = GV.load_workbooks(a.workbooks, GV.source_files(gold), tempfile.mkdtemp(prefix="gold_sg_"))
        for wid, b in books.items():
            for sh in b.sheet_names():
                sheets.setdefault(skey(sh), set()).add((wid, sh))
    need, out = [], {}
    for key, label, pre, fields in SECTIONS:
        for i, it in enumerate(gold.get(key) or []):
            if not isinstance(it, dict):
                continue
            miss = [m for m, have in (("id", iid(it)), ("cells", it.get("cells")), ("keywords", it.get("keywords"))) if not have]
            if not miss:
                continue
            text = " ".join(str(it.get(f)) for f in fields if it.get(f))
            found = []
            for m in re.finditer(r"(W\d+):('[^']+'|[^!\s]+)!\$?([A-Za-z]{1,3})\$?(\d+)", text):
                found.append(f"{m.group(1)}:{m.group(2) if m.group(2).startswith(chr(39)) else chr(39) + m.group(2) + chr(39)}!{(m.group(3) + m.group(4)).upper()}")
            for sh, cell in sorted(refs_in_text(text, set(sheets))):
                for wid, real in sorted(sheets[sh]):
                    ref = f"{wid}:'{real}'!{cell}"
                    if not any(f.lower() == ref.lower() for f in found):
                        found.append(ref + ("" if len(sheets[sh]) == 1 else "  (this sheet name exists in more than one workbook: confirm which)"))
            sug = {"index": i, "missing": miss, "text": text}
            if "id" in miss:
                sug["suggested_id"] = f"{pre}{i + 1}"
            sug["cells_found_in_text"] = found
            need.append((label, sug))
            out.setdefault(key, []).append(sug)
    anchors_on_file = [(k, (c.get("primary_anchor") or {}).get("ref"), (c.get("primary_anchor") or {}).get("shows"))
                       for k, c in (gold.get("answers") or {}).items() if isinstance(c, dict) and (c.get("primary_anchor") or {}).get("ref")]
    if not need:
        print("MATCHING METADATA NEEDED: none (every rival, discrepancy and judgment has an id, cells or keywords)")
        return 0
    print(f"MATCHING METADATA NEEDED: {len(need)} item(s). Nothing is changed; add what you approve to the key "
          f"(matching order: id, cells, keywords; items with none of them score UNSCORED).")
    for label, s in need:
        print(f"- {label} #{s['index'] + 1} (missing: {', '.join(s['missing'])}): {s['text'][:140]}")
        if "suggested_id" in s:
            print(f"    id: \"{s['suggested_id']}\"")
        print("    cells found in its own text: " + ("; ".join(s["cells_found_in_text"]) if s["cells_found_in_text"]
                                                    else "none - add the cells an extraction would reference (e.g. the rival's cell, or both values being compared)"))
        if "keywords" in s["missing"]:
            print("    keywords: your decision (a fallback only); pick whole words from the text above")
    print("ANCHORS ALREADY IN THIS KEY (candidates to reuse in `cells`; listed as written, not matched to any item):")
    for k, ref, shows in anchors_on_file:
        print(f"    {k}: {ref}" + (f"  - {shows}" if shows else ""))
    if a.out:
        json.dump(out, open(a.out, "w"), indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
