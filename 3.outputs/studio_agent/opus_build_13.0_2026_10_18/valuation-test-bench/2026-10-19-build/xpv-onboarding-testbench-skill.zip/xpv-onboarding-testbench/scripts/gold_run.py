# gold_run.py (build 13.0, test bench) - the real-run gates in order, stopping at the first one that fails. It adds no logic of its own: each gate is
# the script of that name, and the three dimensions (Gold validity, Gold accuracy, extraction verification) stay separate in the output.
#   GATE 1  gold_suggest   the matching metadata the key still needs (information; items without any score UNSCORED)
#   GATE 2  (the analyst enriches the key - a human step; --require-metadata stops here when anything is still missing)
#   GATE 3  gold_sources   freeze the SHA-256 of the supplied binaries; GATE 4 compare them with the historical extraction's hashes
#   GATE 5  gold_validate  only a valid key goes on
#   GATE 6  gold_score     Gold accuracy, with the verifier's status shown separately (GATE 7)
# Nothing here changes the extraction, the key or the workbooks. Usage:
#   python gold_run.py --gold KEY.json --workbooks A.xlsx ... --extraction extraction.json [--verification V.json] [--manifest-out M.json]
#                      [--require-metadata] [--allow-different-binary] [--out report.json]
import argparse, os, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gold_validate as GV, gold_suggest, gold_sources, gold_score  # noqa: E402


def lacking(gold):
    return sum(1 for k in ("known_rivals", "material_discrepancies", "human_judgments") for it in gold.get(k) or []
               if isinstance(it, dict) and not (GV.iid(it) or it.get("cells") or it.get("keywords")))


def main(argv=None):
    ap = argparse.ArgumentParser(description="run the Gold gates in order")
    ap.add_argument("--gold", required=True)
    ap.add_argument("--workbooks", nargs="+", required=True)
    ap.add_argument("--extraction", required=True)
    ap.add_argument("--verification")
    ap.add_argument("--manifest-out")
    ap.add_argument("--require-metadata", action="store_true")
    ap.add_argument("--allow-different-binary", action="store_true")
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    gold = GV.read_json(a.gold)
    man = a.manifest_out or os.path.join(tempfile.mkdtemp(prefix="gold_run_"), "source_manifest.json")
    print("== GATE 1: matching metadata (gold_suggest)")
    gold_suggest.main(["--gold", a.gold, "--workbooks", *a.workbooks])
    n = lacking(gold) if isinstance(gold, dict) else 0
    print(f"== GATE 2: enrichment - {n} item(s) still lack id, cells and keywords" + (" (they will score UNSCORED)" if n else ""))
    if n and a.require_metadata:
        print("STOPPED at gate 2: --require-metadata is set; enrich the key and run again")
        return 3
    print("== GATE 3 and 4: source fingerprints and the historical extraction's hashes (gold_sources)")
    rc = gold_sources.main(["--gold", a.gold, "--workbooks", *a.workbooks, "--extraction", a.extraction, "--out", man])
    if rc:
        print("STOPPED at gate 3: the benchmark workbooks are not identified; nothing was validated or scored")
        return 1
    print("== GATE 5: Gold validation (gold_validate)")
    rc = GV.main(["--gold", a.gold, "--workbooks", *a.workbooks, "--sources", man])
    if rc:
        print("STOPPED at gate 5: the Gold key is not valid; nothing was scored")
        return 2
    print("== GATE 6 and 7: Gold score, with the extraction's verification shown separately (gold_score)")
    args = ["--gold", a.gold, "--extraction", a.extraction, "--workbooks", *a.workbooks, "--sources", man]
    args += (["--verification", a.verification] if a.verification else []) + (["--allow-different-binary"] if a.allow_different_binary else []) + (["--out", a.out] if a.out else [])
    return gold_score.main(args)


if __name__ == "__main__":
    sys.exit(main())
