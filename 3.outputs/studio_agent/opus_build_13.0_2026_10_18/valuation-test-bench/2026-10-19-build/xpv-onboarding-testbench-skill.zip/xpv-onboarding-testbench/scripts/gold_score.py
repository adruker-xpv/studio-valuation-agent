# gold_score.py (build 13.1, test bench) - GOLD ACCURACY: did the extraction discover and interpret the material truth an analyst wrote
# down in a gold-mvp/3 key? Native (the key is never translated into the older trial-key format), deterministic (no LLM judge, no
# free-text similarity), and SEPARATE from workbook verification: verify.py answers "are its checkable claims supported by the
# workbooks?"; this answers "did it find what matters?". The two are printed side by side and never merged.
#
# What is scored, per Gold section
#   answers (core concepts)   CORRECT | WRONG | OMITTED | NOT_EXPRESSIBLE_IN_SCHEMA (| NEEDS_ANALYST when it cannot be decided)
#       cell concepts are decided by the extraction's anchor: EXACT_ANCHOR (Gold's primary), GOLD_EQUIVALENT_ANCHOR (Gold lists it as a
#       supporting anchor), VERIFIED_LINKED_EQUIVALENT (a chain of pure copies - =A1, =A1/1000, =ROUND(A1,0) - from a Gold anchor, found
#       in the supplied workbooks), WRONG_ANCHOR, MISSING; UNVERIFIED when a link check was needed but no workbooks were supplied.
#       Numeric equality is never a link. Labels (method) are normalised ("EV/EBITDA" = "EV/EBITDA multiple"); the period is compared
#       as months; the waterfall by the sheet Gold names; the company-to-fund relationship from the extraction's discrepancies and edges.
#   known_rivals              CORRECTLY_REJECTED | SELECTED_RIVAL | NOT_ADDRESSED (neither used nor rejected: did not distinguish)
#   material_discrepancies    FOUND | MISINTERPRETED | OMITTED
#   human_judgments (UNRESOLVED)  PRESERVED_UNRESOLVED | UNSUPPORTED_CONCLUSION | OMITTED
#   Matching of rivals / discrepancies / judgments to extraction items, in this order only: explicit id (the extraction item's own
#   "gold_id"), the cells they reference (Gold's cells vs the item's cells, or cell references written in its text), normalised
#   keywords, otherwise NEEDS_ANALYST (referenced somewhere but not where expected) or UNSCORED (Gold gave no matching metadata).
# Source identity: Gold W1..Wn are tied to extraction source ids by SHA-256 when Gold gives one, else by file name; with workbooks the
# supplied files' SHA-256 is recomputed. A failure is an INTEGRITY error, never a valuation-answer error (affected items become
# NEEDS_ANALYST).
# Usage: python gold_score.py --gold KEY.json --extraction extraction.json [--workbooks A.xlsx ...] [--verification verification.json] [--out report.json]
import argparse, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gold_validate as GV  # noqa: E402
from gold_validate import (gnode, anchors_of, node_match, kw_match, refs_in_text, val_match, show_node, parse_ref, Graph, canon_name, iid, skey, name_tier, name_candidates, rounding_basis)  # noqa: E402
from xlsx_evidence import split_ref, parse_range  # noqa: E402
from onboarding_schema import CHECKABLE  # noqa: E402

CORE_ROLES = {"valuation_metric": "valuation_metric", "applied_multiple": "selected_multiple", "enterprise_value": "enterprise_value",
              "equity_bridge": "equity_value", "company_value": "value_to_xpv", "fund_reported_value": "fund_cell"}
OK_ANCHOR = {"EXACT_ANCHOR", "GOLD_EQUIVALENT_ANCHOR", "VERIFIED_LINKED_EQUIVALENT"}
METHODS = {"ev ebitda", "ev revenue", "blend of", "held at cost", "other"}
METHOD_ALIAS = {"ebitda": "ev ebitda", "enterprise value ebitda": "ev ebitda", "revenue": "ev revenue", "ev sales": "ev revenue",
                "ev revenue": "ev revenue", "sales": "ev revenue"}


def canon_method(s):
    t = re.sub(r"[^a-z0-9/ ]", " ", str(s).lower())
    t = re.sub(r"\b(multiples?|method|valuation|approach|based|the|a)\b", " ", t)
    t = re.sub(r"\benterprise value\b", "ev", t)
    t = re.sub(r"\bto\b|/", " ", t)
    t = " ".join(t.split())
    return METHOD_ALIAS.get(t, t)


def month(s):
    m = re.match(r"^\s*(\d{4})-(\d{2})", str(s or ""))
    return f"{m.group(1)}-{m.group(2)}" if m else None


def gids(item):
    g = item.get("gold_id") if isinstance(item, dict) else None
    return set(g) if isinstance(g, list) else ({g} if g else set())


def item_text(d):
    return " - ".join(str(d.get(k)) for k in ("what", "why", "driver", "question", "text") if d.get(k))


def source_integrity(gsrc, ex_sources, books, allow=False):
    """compare, per Gold workbook, the FROZEN binary (the supplied workbook's SHA-256; else the SHA-256 Gold or its manifest carries) with the
    SHA-256 the historical extraction recorded for the file it read.
      SAME_BINARY       the extraction read exactly this binary
      DIFFERENT_BINARY  it read a file with the same (normalised) name but another SHA-256: a re-saved or re-downloaded copy
      NOT_COMPARABLE    the frozen binary or the extraction's SHA-256 is not known, so only the name ties them
      MISSING           no extraction source matches (or the name is ambiguous)
    A different binary is a BENCHMARK_INTEGRITY problem, never a wrong answer: its concepts are not scored (NEEDS_ANALYST) unless the run is
    explicitly told to score a different saved copy (allow=True), which is then stated in the report.
    Returns (gmap ext id -> Gold id, g2e, rows, blocking problems)."""
    gmap, g2e, rows, bad = {}, {}, [], []
    for wid, s in sorted(gsrc.items()):
        frozen = books[wid].sha256 if wid in books else s["sha256"]
        sup = books[wid].file if wid in books else None
        row = {"wid": wid, "file": s["file"], "filename_match": None if not sup else "EXACT" if sup == s["file"] else "NORMALIZED" if name_tier(sup, s["file"]) else "DIFFERENT (tied by SHA-256)", "frozen_sha256": frozen, "frozen_from": "supplied workbook" if wid in books else ("Gold/manifest sha256" if frozen else None),
               "extraction_id": None, "extraction_sha256": None, "matched_by": None}
        cand = next((x for x in ex_sources if frozen and (x.get("sha256") or "").lower() == frozen), None)
        by = "sha256"
        if not cand:
            same, how = name_candidates(ex_sources, s["file"], lambda x: x.get("file"))
            if len(same) > 1:
                row["status"] = "MISSING"
                row["note"] = f"ambiguous: {len(same)} extraction sources share this normalised name"
            elif same:
                cand, by = same[0], how
        if cand:
            xs = (cand.get("sha256") or "").lower() or None
            row.update(extraction_id=cand["id"], extraction_sha256=xs, matched_by=by)
            row["status"] = "SAME_BINARY" if by == "sha256" else "NOT_COMPARABLE" if not (xs and frozen) else "SAME_BINARY" if xs == frozen else "DIFFERENT_BINARY"
        elif "status" not in row:
            row["status"] = "MISSING"
            row["note"] = "not among the extraction's sources"
        ok = row["status"] in ("SAME_BINARY", "NOT_COMPARABLE") or (row["status"] == "DIFFERENT_BINARY" and allow)
        if ok and cand["id"] in gmap:
            bad.append(f"{wid} and {gmap[cand['id']]} both map to extraction source {cand['id']}")
            row["status"], ok = "MISSING", False
        if ok:
            gmap[cand["id"]], g2e[wid] = wid, cand["id"]
        elif row["status"] == "DIFFERENT_BINARY":
            bad.append(f"{wid} '{s['file']}': the extraction recorded SHA-256 {row['extraction_sha256'][:12]}... but the benchmark binary is {frozen[:12]}... (a different saved copy)")
        elif row["status"] == "MISSING":
            bad.append(f"{wid} '{s['file']}': {row.get('note', 'not among the extraction sources')}")
        rows.append(row)
    return gmap, g2e, rows, bad


def integrity_summary(rows, allow):
    n = len(rows)
    same = sum(1 for r in rows if r["status"] == "SAME_BINARY")
    diff = sum(1 for r in rows if r["status"] == "DIFFERENT_BINARY")
    miss = sum(1 for r in rows if r["status"] == "MISSING")
    if diff or miss:
        t = f"MISMATCH ({diff} different binary, {miss} missing)"
        return t + (" - scoring a different saved copy was explicitly allowed" if allow and not miss else "")
    return f"SAME_BINARY ({same}/{n})" if same == n else f"NOT COMPARABLE ({n - same} of {n} can be tied to the extraction by name only)"


class Scorer:
    def __init__(self, gold, doc, books=None, allow_different=False):
        self.gold, self.doc, self.books = gold, doc, books or {}
        self.ans = gold.get("answers") or {}
        self.ch = doc.get("chain") or {}
        self.gmap, self.g2e, self.rows, self.integrity = source_integrity(GV.source_files(gold), doc.get("sources") or [], self.books, allow_different)
        self.allow_different = allow_different
        self.graph = Graph(self.books) if self.books else None
        self.sets = {k: [n for n in (gnode(r) for _, r in anchors_of(c)) if n and n[2]] for k, c in self.ans.items() if isinstance(c, dict)}
        self.sheets = {}                                        # sheet lower -> {wid} (from every Gold reference and every loaded book)
        for it in [c for c in self.ans.values() if isinstance(c, dict)] + [i for k in ("known_rivals", "material_discrepancies", "human_judgments")
                                                                         for i in gold.get(k) or []]:
            refs = [r for _, r in anchors_of(it)] + list(it.get("cells") or [])
            for r in refs:
                n = gnode(r)
                if n:
                    self.sheets.setdefault(n[1], set()).add(n[0])
        for wid, b in self.books.items():
            for sh in b.sheet_names():
                self.sheets.setdefault(skey(sh), set()).add(wid)
        self.disc = [d for d in doc.get("discrepancies") or [] if isinstance(d, dict)]
        self.rej = [d for d in doc.get("rejected") or [] if isinstance(d, dict)]
        self.edges = [e for k in ("provenance", "downstream") for e in doc.get(k) or [] if isinstance(e, dict)]
        self.qs = [q if isinstance(q, dict) else {"question": str(q)} for q in doc.get("open_questions") or []]

    # ---- extraction side ----
    def node(self, ref, default=None):
        if not isinstance(ref, dict):
            return None
        s, cell = ref.get("source") or default, ref.get("cell") or ref.get("cells")
        if not s or not isinstance(cell, str):
            return None
        sheet, a = split_ref(cell)
        if not sheet or not a:
            return None
        return (self.gmap.get(s), skey(sheet), a.upper(), f"{s}:{cell}")

    def role_node(self, role):
        d = self.ch.get(role)
        return self.node(d, None if role == "fund_cell" else self.ch.get("source"))

    def all_refs(self):
        out = []
        dflt = self.ch.get("source")
        for k, v in self.ch.items():
            if isinstance(v, dict) and (v.get("cell") or v.get("cells")):
                out.append((self.node(v, dflt), f"chain.{k}"))
            elif isinstance(v, list):
                out += [(self.node(x, dflt), f"chain.{k}") for x in v if isinstance(x, dict)]
        out += [(self.node(x), "path") for x in self.doc.get("path") or [] if isinstance(x, dict)]
        for e in self.edges:
            out += [(self.node(e.get("from")), f"edge {e.get('id', '')}"), (self.node(e.get("to")), f"edge {e.get('id', '')}")]
        for d in self.disc:
            out += [(self.node(d.get("a")), f"discrepancy {d.get('id', '')}"), (self.node(d.get("b")), f"discrepancy {d.get('id', '')}")]
            out += [(self.node(x), f"discrepancy {d.get('id', '')}") for x in d.get("driver_cells") or []]
        out += [(self.node(r), "rejected") for r in self.rej]
        out += [(self.node(x), "inputs") for x in self.doc.get("inputs") or [] if isinstance(x, dict)]
        return [(n, w) for n, w in out if n]

    def texts(self):
        out = [("how_it_works", self.doc.get("how_it_works") or "")]
        out += [("open_questions", item_text(q)) for q in self.qs]
        out += [("deferred", str(x)) for x in self.doc.get("deferred") or []]
        out += [(f"discrepancy {d.get('id', '')}", item_text(d)) for d in self.disc]
        out += [("rejected", item_text(r)) for r in self.rej]
        out += [(f"edge {e.get('id', '')}", item_text(e)) for e in self.edges]
        return [(w, t) for w, t in out if t]

    def text_nodes(self, text):
        out = []
        for sh, cell in refs_in_text(text, set(self.sheets)):
            out += [(w, sh, cell, "text") for w in self.sheets.get(sh, ())]
        return out

    # ---- equivalence and anchors ----
    def equiv(self, g, e):
        """is extraction node e the same economic cell as Gold node g? exact | gold_equivalent (both in one concept's cell-level anchors)
        | verified_link (chain of pure copies in the supplied workbooks) | None."""
        if not g or not e or e[0] is None or g[2] is None:
            return None
        if node_match(g, e):
            return "exact"
        for nodes in self.sets.values():
            if any(node_match(n, g) for n in nodes) and any(node_match(n, e) for n in nodes):
                return "gold_equivalent"
        if self.graph and self.graph.linked(e, g):
            return "verified_link"
        return None

    def classify(self, concept, e):
        anchors = [(k, gnode(r), r) for k, r in anchors_of(concept)]
        anchors = [(k, g, r) for k, g, r in anchors if g]
        if e is None:
            return "MISSING", ""
        miss = sorted({g[0] for _, g, _ in anchors if g[0] not in self.g2e})
        if e[0] is None or miss:
            return "UNVERIFIED", "integrity: " + (f"Gold source {', '.join(miss)} not identified in the extraction" if miss else "extraction source not identified")
        for k, g, r in anchors:
            if k == "primary" and node_match(g, e):
                return "EXACT_ANCHOR", ""
        for k, g, r in anchors:
            if k == "supporting" and node_match(g, e):
                return "GOLD_EQUIVALENT_ANCHOR", f"Gold lists {r} as a supporting anchor"
        if self.graph:
            for k, g, r in anchors:
                path = self.graph.linked(e, g) if g[2] else None          # a whole-sheet anchor is matched by sheet only, never by a copy
                if path:
                    return "VERIFIED_LINKED_EQUIVALENT", "pure-copy link: " + " <- ".join(show_node(n) for n in path)
            return "WRONG_ANCHOR", ""
        return "UNVERIFIED", "not one of Gold's anchors; the link check needs the workbooks"

    def value_at(self, e):
        b = self.books.get(e[0]) if e and e[0] else None
        if not b:
            return None
        sh = next((x for x in b.sheet_names() if skey(x) == e[1]), None)
        rg = parse_range(e[2])
        if not sh or not rg or None in rg or (rg[0], rg[1]) != (rg[2], rg[3]):
            return None
        return b.value(sh, e[2])

    def elsewhere(self, c, anchors=True):
        why = []
        if anchors:
            gs = [g for g in (gnode(r) for _, r in anchors_of(c)) if g]
            for n, where in self.all_refs():
                if any(node_match(g, n) for g in gs):
                    why.append(f"{n[3]} appears in {where}")
                    break
        if c.get("keywords"):
            for where, t in self.texts():
                if kw_match(c["keywords"], t):
                    why.append(f"its keywords appear in {where}")
                    break
        return why

    # ---- core concepts ----
    def res(self, key, c, status, anchor="N/A", ext=None, detail="", **kw):
        p = (c.get("primary_anchor") or {}).get("ref") if isinstance(c, dict) else None
        return {"concept": key, "status": status, "anchor": anchor, "extraction": ext, "gold": p, "detail": detail, **kw}

    def score_concept(self, key, c):
        if key not in GV.KNOWN or not isinstance(c, dict):
            return self.res(key, c, "NOT_EXPRESSIBLE_IN_SCHEMA", detail="the extraction schema has no slot for this concept; consider extending the schema")
        if key == "valuation_method":
            return self.c_method(key, c)
        if key == "metric_period":
            return self.c_period(key, c)
        if key == "ownership_or_waterfall":
            return self.c_waterfall(key, c)
        if key == "company_to_fund_relationship":
            return self.c_relationship(key, c)
        return self.c_cell(key, c)

    def omitted_or_elsewhere(self, key, c, anchor, detail, anchors=True):
        w = self.elsewhere(c, anchors)
        if w:
            return self.res(key, c, "NEEDS_ANALYST", anchor, None, f"{detail}; but {'; '.join(w)}")
        return self.res(key, c, "OMITTED", anchor, None, detail)

    def c_method(self, key, c):
        ext = self.ch.get("method")
        if not ext:
            return self.omitted_or_elsewhere(key, c, "N/A", "the extraction states no valuation method", anchors=False)
        g, e = canon_method(c.get("answer")), canon_method(ext)
        if g == e:
            return self.res(key, c, "CORRECT", ext=ext, detail=f"'{ext}' is the same method as Gold's '{c.get('answer')}'")
        if g in METHODS and e in METHODS:
            return self.res(key, c, "WRONG", ext=ext, detail=f"extraction says '{ext}'; Gold says '{c.get('answer')}'")
        return self.res(key, c, "NEEDS_ANALYST", ext=ext, detail=f"cannot normalise '{ext}' against '{c.get('answer')}' deterministically")

    def window_node(self):
        mw = self.ch.get("metric_window") or {}
        return self.node({"source": mw.get("source"), "cell": mw.get("cells")}) if mw.get("cells") else None

    def c_period(self, key, c):
        mw = self.ch.get("metric_window") or {}
        f, l = month(mw.get("first")), month(mw.get("last"))
        e = self.window_node()
        cls, why = self.classify(c, e)
        if not (f or l):
            return self.omitted_or_elsewhere(key, c, cls, "the extraction states no TTM window", anchors=False)
        ok = f == c.get("first_month") and l == c.get("last_month")
        d = f"extraction {f}..{l}; Gold {c.get('first_month')}..{c.get('last_month')}" + (f" | window anchor {cls}" + (f" ({why})" if why else "") if cls != "EXACT_ANCHOR" else "")
        return self.res(key, c, "CORRECT" if ok else "WRONG", cls, e[3] if e else None, d)

    def c_cell(self, key, c):
        role = CORE_ROLES[key]
        e = self.role_node(role)
        cls, why = self.classify(c, e)
        if cls == "MISSING":
            return self.omitted_or_elsewhere(key, c, cls, f"the extraction's chain has no {role}")
        status = "CORRECT" if cls in OK_ANCHOR else "WRONG" if cls == "WRONG_ANCHOR" else "NEEDS_ANALYST"
        r = self.res(key, c, status, cls, e[3], why)
        field = GV.NUMERIC.get(key)
        v = self.value_at(e) if field else None
        if v is not None and c.get(field) is not None:
            vc = val_match(v, c[field])
            r["value_check"] = vc
            if cls == "WRONG_ANCHOR" and vc != "mismatch":
                r["detail"] = "the cell's value equals Gold's answer but it is not linked to a Gold anchor (numeric equality is not a link)"
            if cls in OK_ANCHOR and vc == "mismatch":
                r["detail"] = (r["detail"] + "; " if r["detail"] else "") + f"VALUE DISAGREES: the cell holds {v}, Gold says {c[field]}"
        if key == "equity_bridge" and status == "CORRECT" and self.books and c.get("cash") is not None and c.get("debt") is not None:
            sums = {1: 0.0, -1: 0.0}
            n_found = 0
            for x in self.ch.get("bridge") or []:
                nb = self.node(x, self.ch.get("source"))
                val = self.value_at(nb) if nb else None
                if isinstance(val, (int, float)) and x.get("sign") in (1, -1):
                    sums[x["sign"]] += abs(val)
                    n_found += 1
            if n_found:
                bad = [n for n, tot, want in (("cash", sums[1], c["cash"]), ("debt", sums[-1], c["debt"])) if val_match(tot, want) == "mismatch"]
                if bad:
                    r["status"], r["detail"] = "WRONG", f"the bridge cells do not match Gold's {' and '.join(bad)}"
        return r

    def c_waterfall(self, key, c):
        wf = [self.node(x, self.ch.get("source")) for x in self.ch.get("waterfall") or [] if isinstance(x, dict)]
        wf = [n for n in wf if n]
        if not wf:
            return self.omitted_or_elsewhere(key, c, "MISSING", "the extraction's chain reports no waterfall")
        got = [(self.classify(c, n), n) for n in wf]
        rank = ["EXACT_ANCHOR", "GOLD_EQUIVALENT_ANCHOR", "VERIFIED_LINKED_EQUIVALENT", "UNVERIFIED", "WRONG_ANCHOR"]
        (cls, why), n = sorted(got, key=lambda x: rank.index(x[0][0]))[0]
        status = "CORRECT" if cls in OK_ANCHOR else "WRONG" if cls == "WRONG_ANCHOR" else "NEEDS_ANALYST"
        return self.res(key, c, status, cls, n[3], why or f"{len(wf)} waterfall cells reported")

    def derive_relationship(self):
        ok = lambda k, n: n is not None and self.classify(self.ans.get(k) or {}, n)[0] in OK_ANCHOR
        company = lambda n: ok("company_value", n)
        fund = lambda n: ok("fund_reported_value", n)
        for d in self.disc:
            a, b = self.node(d.get("a")), self.node(d.get("b"))
            if (company(a) and fund(b)) or (company(b) and fund(a)):
                return "DIFFERENT", d.get("status"), f"discrepancy {d.get('id', '')} ({d.get('status')})"
        for e in self.edges:
            a, b = self.node(e.get("from")), self.node(e.get("to"))
            if e.get("class") in CHECKABLE and ((company(a) and fund(b)) or (company(b) and fund(a))):
                return "MATCH", None, f"edge {e.get('id', '')} ({e.get('class')})"
        return None, None, None

    def match_edge(self):
        """a checkable edge between the company value and the fund value (build 13.1 helper)."""
        ok = lambda k, n: n is not None and self.classify(self.ans.get(k) or {}, n)[0] in OK_ANCHOR
        for e in self.edges:
            a, b = self.node(e.get("from")), self.node(e.get("to"))
            if e.get("class") in CHECKABLE and ((ok("company_value", a) and ok("fund_reported_value", b)) or (ok("company_value", b) and ok("fund_reported_value", a))):
                return e
        return None

    def c_relationship(self, key, c):
        dec = rounding_basis(c)
        if dec is not None and c.get("answer") == "MATCH":
            # build 13.1: Gold declares MATCH after rounding. A checkable edge (e.g. rounded_match) is decisive; a discrepancy the extraction
            # calls "explained" may be that same rounding and cannot be told apart deterministically, so it is NEEDS_ANALYST, not WRONG.
            e = self.match_edge()
            if e is not None:
                return self.res(key, c, "CORRECT", ext="MATCH", detail=f"extraction: MATCH via edge {e.get('id', '')} ({e.get('class')}); Gold: MATCH after rounding to {dec} decimal(s)")
            kind, status, via = self.derive_relationship()
            if kind == "DIFFERENT" and status == "explained":
                return self.res(key, c, "NEEDS_ANALYST", ext="DIFFERENT (explained)", detail=f"extraction: an explained difference via {via}; Gold: MATCH after rounding to {dec} decimal(s) - check whether its explanation is that rounding")
        kind, status, via = self.derive_relationship()
        if not kind:
            return self.omitted_or_elsewhere(key, c, "N/A", "the extraction states no relationship between the company value and the fund value", anchors=False)
        want = c.get("answer")
        if want == "UNRESOLVED":
            good = kind == "DIFFERENT" and status == "unresolved"
        else:
            good = kind == want
        return self.res(key, c, "CORRECT" if good else "WRONG", ext=kind, detail=f"extraction: {kind} via {via}; Gold: {want}")

    # ---- matching items ----
    def find(self, item, pool, mode="all"):
        """(object, via) by id, then cells, then keywords; pool = [(object, nodes, text)]."""
        gid = iid(item)
        if gid:
            for o, _, _ in pool:
                if gid in gids(o):
                    return o, "id"
        gs = [g for g in (gnode(r) for r in item.get("cells") or []) if g]
        if gs:
            for o, nodes, _ in pool:
                nodes = [n for n in nodes if n]
                if mode == "rival":
                    hit = any(node_match(g, n) and g[2] for g in gs for n in nodes if n[0] is not None)
                else:
                    hit = bool(nodes) and all(any(self.equiv(g, n) for n in nodes) for g in gs)
                if hit:
                    return o, "cells"
        if item.get("keywords"):
            for o, _, t in pool:
                if kw_match(item["keywords"], t):
                    return o, "keywords"
        return None, None

    def disc_pool(self):
        return [(d, [self.node(d.get("a")), self.node(d.get("b"))] + [self.node(x) for x in d.get("driver_cells") or []], item_text(d)) for d in self.disc]

    def q_pool(self):
        return [(q, self.text_nodes(item_text(q)) + [self.node(x) for x in q.get("cells") or [] if isinstance(x, dict)], item_text(q)) for q in self.qs]

    def narrative_hit(self, item):
        """is the item mentioned outside its own typed list? (how_it_works / deferred): by cells written in the text, or keywords"""
        gs = [g for g in (gnode(r) for r in item.get("cells") or []) if g]
        for where, t in [("how_it_works", self.doc.get("how_it_works") or "")] + [("deferred", str(x)) for x in self.doc.get("deferred") or []]:
            nodes = self.text_nodes(t)
            if gs and nodes and all(any(self.equiv(g, n) for n in nodes) for g in gs):
                return where
            if item.get("keywords") and kw_match(item["keywords"], t):
                return where
        return None

    # ---- known rivals ----
    def score_rival(self, r):
        base = {"id": iid(r), "candidate": r.get("candidate")}
        cells = [g for g in (gnode(x) for x in r.get("cells") or []) if g]
        if not (iid(r) or cells or r.get("keywords")):
            return {**base, "status": "UNSCORED", "detail": "Gold gave no id, cells or keywords for this rival"}
        for key, role in CORE_ROLES.items():
            n = self.role_node(role)
            if n and n[0] is not None and any(g[2] and node_match(g, n) for g in cells):
                return {**base, "status": "SELECTED_RIVAL", "detail": f"{n[3]} is the extraction's {role}"}
        pool = [(x, [self.node(x)], item_text(x)) for x in self.rej]
        o, via = self.find(r, pool, mode="rival")
        if o:
            return {**base, "status": "CORRECTLY_REJECTED", "detail": f"rejected ({via}): {item_text(o)[:90]}"}
        for n, where in self.all_refs():
            if n[0] is not None and any(g[2] and node_match(g, n) for g in cells):
                return {**base, "status": "NEEDS_ANALYST", "detail": f"{n[3]} appears in {where} but is neither rejected nor chosen"}
        for where, t in self.texts():
            if r.get("keywords") and kw_match(r["keywords"], t):
                return {**base, "status": "NEEDS_ANALYST", "detail": f"its keywords appear in {where} but it is not rejected"}
        return {**base, "status": "NOT_ADDRESSED", "detail": "the extraction neither used nor rejected it (it did not distinguish the rival)"}

    # ---- material discrepancies ----
    def score_discrepancy(self, m):
        base = {"id": iid(m), "item": m.get("item"), "gold_status": m.get("status")}
        if not (iid(m) or m.get("cells") or m.get("keywords")):
            return {**base, "status": "UNSCORED", "detail": "Gold gave no id, cells or keywords for this discrepancy"}
        d, via = self.find(m, self.disc_pool())
        if not d:
            w = self.narrative_hit(m)
            o, _ = self.find(m, self.q_pool())
            if o or w:
                return {**base, "status": "NEEDS_ANALYST", "detail": f"mentioned in {'open_questions' if o else w} but not recorded as a discrepancy"}
            return {**base, "status": "OMITTED", "detail": "the extraction records no such discrepancy"}
        diff, material, st = d.get("difference"), d.get("material"), d.get("status")
        gold = m.get("status")
        d_txt = f"discrepancy {d.get('id', '')} ({via}); status {st}"
        if gold == "REAL":
            if (isinstance(diff, (int, float)) and diff == 0) or material is False:
                return {**base, "status": "MISINTERPRETED", "detail": f"{d_txt}: Gold says the difference is real; the extraction treats it as nil or immaterial"}
        elif gold == "UNRESOLVED":
            if st == "explained":
                return {**base, "status": "MISINTERPRETED", "detail": f"{d_txt}: Gold says it is unresolved; the extraction calls it explained"}
        elif gold == "ROUNDING":
            if not ((isinstance(diff, (int, float)) and diff == 0) or material is False):
                return {**base, "status": "NEEDS_ANALYST", "detail": f"{d_txt}: cannot tell deterministically whether the extraction treats it as rounding"}
        return {**base, "status": "FOUND", "detail": d_txt}

    # ---- human judgments ----
    def score_judgment(self, h):
        base = {"id": iid(h), "question": h.get("question")}
        if not (iid(h) or h.get("cells") or h.get("keywords")):
            return {**base, "status": "UNSCORED", "detail": "Gold gave no id, cells or keywords for this judgment"}
        q, via = self.find(h, self.q_pool())
        if q:
            return {**base, "status": "PRESERVED_UNRESOLVED", "detail": f"raised as an open question ({via})"}
        d, via = self.find(h, self.disc_pool())
        if d and d.get("status") == "explained":
            return {**base, "status": "UNSUPPORTED_CONCLUSION",
                    "detail": f"discrepancy {d.get('id', '')} ({via}) is closed as 'explained': {item_text(d)[:90]}; Gold says the workbooks cannot settle this"}
        w = self.narrative_hit(h) or ("discrepancy list" if d else None)
        if w:
            return {**base, "status": "NEEDS_ANALYST", "detail": f"mentioned in {w} but not raised as an open question"}
        return {**base, "status": "OMITTED", "detail": "the extraction never raises this question"}

    def score_all(self):
        core = [self.score_concept(k, c) for k, c in self.ans.items()]
        R = {"concepts": core, "rivals": [self.score_rival(r) for r in self.gold.get("known_rivals") or []],
             "discrepancies": [self.score_discrepancy(m) for m in self.gold.get("material_discrepancies") or []],
             "judgments": [self.score_judgment(h) for h in self.gold.get("human_judgments") or []]}
        for xs in R.values():
            for x in xs:
                x["class"] = owner(x)
        return R


OWNER = {"WRONG": "EXTRACTION_REASONING", "SELECTED_RIVAL": "EXTRACTION_REASONING", "MISINTERPRETED": "EXTRACTION_REASONING",
         "UNSUPPORTED_CONCLUSION": "EXTRACTION_REASONING", "OMITTED": "EXTRACTION_COVERAGE", "NOT_ADDRESSED": "EXTRACTION_COVERAGE",
         "NOT_EXPRESSIBLE_IN_SCHEMA": "EXTRACTION_SCHEMA", "UNSCORED": "UNSCORED_MATCHING_METADATA"}


def owner(x):
    """who owns a result that is not a clean success: the extraction's reasoning, its coverage, its schema, the Gold's matching metadata, or the benchmark's files"""
    st = x["status"]
    if st == "NEEDS_ANALYST":
        return "BENCHMARK_INTEGRITY" if "integrity" in x.get("detail", "").lower() else "UNSCORED_MATCHING_METADATA"
    return OWNER.get(st)


def summarise(R):
    C, V, D, H = R["concepts"], R["rivals"], R["discrepancies"], R["judgments"]
    n = lambda xs, st: sum(1 for x in xs if x["status"] == st)
    decided = [x for x in C if x["status"] in ("CORRECT", "WRONG", "OMITTED")]
    anch = [x for x in C if x["anchor"] not in ("N/A",) and x["status"] != "NOT_EXPRESSIBLE_IN_SCHEMA"]
    s = {
        "core_correct": n(C, "CORRECT"), "core_total": len(decided), "core_wrong": n(C, "WRONG"), "core_omitted": n(C, "OMITTED"),
        "not_expressible": n(C, "NOT_EXPRESSIBLE_IN_SCHEMA"),
        "anchors_exact": sum(1 for x in anch if x["anchor"] == "EXACT_ANCHOR"), "anchors_total": len(anch),
        "anchors_gold_equivalent": sum(1 for x in anch if x["anchor"] == "GOLD_EQUIVALENT_ANCHOR"),
        "anchors_verified_linked": sum(1 for x in anch if x["anchor"] == "VERIFIED_LINKED_EQUIVALENT"),
        "rivals_handled": n(V, "CORRECTLY_REJECTED"), "rivals_total": sum(1 for x in V if x["status"] in ("CORRECTLY_REJECTED", "SELECTED_RIVAL", "NOT_ADDRESSED")),
        "discrepancies_found": n(D, "FOUND"), "discrepancies_total": sum(1 for x in D if x["status"] in ("FOUND", "MISINTERPRETED", "OMITTED")),
        "judgments_preserved": n(H, "PRESERVED_UNRESOLVED"), "judgments_total": sum(1 for x in H if x["status"] in ("PRESERVED_UNRESOLVED", "UNSUPPORTED_CONCLUSION", "OMITTED")),
    }
    s["wrong_material_answers"] = n(C, "WRONG")
    s["false_material_claims"] = n(C, "WRONG") + n(V, "SELECTED_RIVAL") + n(H, "UNSUPPORTED_CONCLUSION") + n(D, "MISINTERPRETED")
    s["material_gold_items_missed"] = n(C, "OMITTED") + n(V, "NOT_ADDRESSED") + n(D, "OMITTED") + n(H, "OMITTED")
    s["needs_analyst"] = sum(n(xs, "NEEDS_ANALYST") for xs in (C, V, D, H))
    s["unscored"] = sum(n(xs, "UNSCORED") for xs in (C, V, D, H))
    return s


def render(case, R, S, integrity, verification, rows=(), integ="", warnings=(), recorded=False):
    C, V, D, H = R["concepts"], R["rivals"], R["discrepancies"], R["judgments"]
    cnt = lambda xs, st: sum(1 for x in xs if x["status"] == st)
    ac = lambda c: sum(1 for x in C if x["anchor"] == c)
    L = [f"GOLD SCORE: {case}", "", f"GOLD VALIDATION: PASS ({len(warnings)} warnings)"] + [f"- WARN: {w}" for w in warnings]
    L += [f"SOURCE INTEGRITY: {integ}", "SOURCE IDENTITY (Gold file | filename match to the supplied workbook | binary vs the extraction):"]
    for r in rows:
        L.append(f"- {r['wid']} filename {r['filename_match'] or 'not checked (no workbooks)'} + {r['status']} | {r['file']} | extraction source {r['extraction_id'] or '-'}"
                 + (f" | matched by {r['matched_by']}" if r["matched_by"] else "") + (f" | {r['note']}" if r.get("note") else "")
                 + (f" | frozen sha256 {r['frozen_sha256'][:12]}... ({r['frozen_from']})" if r["frozen_sha256"] else " | frozen sha256 unknown"))
    L += ["",
          f"Core semantic answers: {S['core_correct']}/{S['core_total']}", f"Exact primary anchors: {S['anchors_exact']}/{S['anchors_total']}",
          f"Equivalent linked anchors: {S['anchors_gold_equivalent'] + S['anchors_verified_linked']} "
          f"(Gold-listed {S['anchors_gold_equivalent']}, verified by workbook link {S['anchors_verified_linked']})",
          f"Wrong material answers: {S['wrong_material_answers']}", f"Material Gold items omitted: {S['material_gold_items_missed']}",
          f"Known rivals: {S['rivals_handled']}/{S['rivals_total']}", f"Material discrepancies: {S['discrepancies_found']}/{S['discrepancies_total']}",
          f"Unresolved judgments: {S['judgments_preserved']}/{S['judgments_total']}", f"False material claims: {S['false_material_claims']}",
          f"Not expressible in schema: {S['not_expressible']}", f"Needs analyst / unscored: {S['needs_analyst']} / {S['unscored']}",
          f"Integrity: {'OK' if not integrity else 'FAILED (' + str(len(integrity)) + ')'}",
          f"Workbook verification (separate, not part of the Gold score): {verification}"
          + (" (as recorded in extraction.json; run verify.py for a fresh check)" if recorded else "")
          + (" [DETERMINISTIC_VERIFIER]" if verification not in ("VERIFIED", "not verified") else ""), "",
          "BREAKDOWN",
          f"Core semantic answers: correct {cnt(C, 'CORRECT')} / wrong {cnt(C, 'WRONG')} / omitted {cnt(C, 'OMITTED')} / needs analyst {cnt(C, 'NEEDS_ANALYST')} / not expressible {cnt(C, 'NOT_EXPRESSIBLE_IN_SCHEMA')}",
          f"Anchors: exact {ac('EXACT_ANCHOR')} / Gold-equivalent {ac('GOLD_EQUIVALENT_ANCHOR')} / verified-linked-equivalent {ac('VERIFIED_LINKED_EQUIVALENT')} / "
          f"wrong {ac('WRONG_ANCHOR')} / missing {ac('MISSING')} / unverified {ac('UNVERIFIED')}",
          f"Known rivals: correctly rejected {cnt(V, 'CORRECTLY_REJECTED')} / selected incorrectly {cnt(V, 'SELECTED_RIVAL')} / omitted {cnt(V, 'NOT_ADDRESSED')} / "
          f"unscored {cnt(V, 'UNSCORED')} / needs analyst {cnt(V, 'NEEDS_ANALYST')}",
          f"Material discrepancies: found {cnt(D, 'FOUND')} / materially misinterpreted {cnt(D, 'MISINTERPRETED')} / omitted {cnt(D, 'OMITTED')} / "
          f"unscored {cnt(D, 'UNSCORED')} / needs analyst {cnt(D, 'NEEDS_ANALYST')}",
          f"Unresolved judgments: preserved unresolved {cnt(H, 'PRESERVED_UNRESOLVED')} / unsupported conclusion {cnt(H, 'UNSUPPORTED_CONCLUSION')} / omitted {cnt(H, 'OMITTED')} / "
          f"unscored {cnt(H, 'UNSCORED')} / needs analyst {cnt(H, 'NEEDS_ANALYST')}", ""]
    tag = lambda x: f" [{x['class']}]" if x.get("class") else ""

    def sec(title, rows_):
        L.append(title)
        L.extend(rows_ or ["- none"])
        L.append("")
    sec("WRONG ITEMS", [f"- {x['concept']}: extraction {x['extraction']} | {x['detail']}{tag(x)}" for x in C if x["status"] == "WRONG"]
        + [f"- discrepancy {x['id'] or x['item']}: {x['detail']}{tag(x)}" for x in D if x["status"] == "MISINTERPRETED"])
    sec("OMITTED ITEMS", [f"- {x['concept']}: {x['detail']}{tag(x)}" for x in C if x["status"] == "OMITTED"]
        + [f"- rival {x['id'] or x['candidate']}: {x['detail']}{tag(x)}" for x in V if x["status"] == "NOT_ADDRESSED"]
        + [f"- discrepancy {x['id'] or x['item']}: {x['detail']}{tag(x)}" for x in D if x["status"] == "OMITTED"]
        + [f"- judgment {x['id'] or x['question']}: {x['detail']}{tag(x)}" for x in H if x["status"] == "OMITTED"])
    sec("RIVAL FAILURES", [f"- {x['id'] or x['candidate']}: {x['status']} | {x['detail']}{tag(x)}" for x in V if x["status"] in ("SELECTED_RIVAL", "NOT_ADDRESSED")])
    sec("UNSUPPORTED CONCLUSIONS", [f"- {x['id'] or x['question']}: {x['detail']}{tag(x)}" for x in H if x["status"] == "UNSUPPORTED_CONCLUSION"])
    sec("EQUIVALENT-ANCHOR DIFFERENCES", [f"- {x['concept']}: {x['anchor']} {x['extraction']} (Gold primary {x['gold']})" + (f" | {x['detail']}" if x["detail"] else "")
                                           for x in C if x["anchor"] in ("GOLD_EQUIVALENT_ANCHOR", "VERIFIED_LINKED_EQUIVALENT")])
    sec("NEEDS ANALYST / UNSCORED", [f"- {x['concept']}: {x['detail']}{tag(x)}" for x in C if x["status"] == "NEEDS_ANALYST"]
        + [f"- {k} {x.get('id') or x.get('candidate') or x.get('item') or x.get('question')}: {x['status']} | {x['detail']}{tag(x)}"
           for k, xs in (("rival", V), ("discrepancy", D), ("judgment", H)) for x in xs if x["status"] in ("NEEDS_ANALYST", "UNSCORED")])
    sec("NOT EXPRESSIBLE IN SCHEMA", [f"- {x['concept']}: {x['detail']}{tag(x)}" for x in C if x["status"] == "NOT_EXPRESSIBLE_IN_SCHEMA"])
    sec("INTEGRITY", [f"- {x} [BENCHMARK_INTEGRITY]" for x in integrity])
    sec("CORE ANSWERS (all)", [f"- {x['concept']}: {x['status']} | anchor {x['anchor']}" + (f" | {x['detail']}" if x["detail"] else "") for x in C])
    return "\n".join(L).rstrip()


def main(argv=None):
    ap = argparse.ArgumentParser(description="score an extraction against a gold-mvp/3 key")
    ap.add_argument("--gold", required=True)
    ap.add_argument("--extraction", required=True)
    ap.add_argument("--workbooks", nargs="*")
    ap.add_argument("--sources", help="frozen source manifest (from gold_sources.py) supplying SHA-256s Gold does not carry")
    ap.add_argument("--allow-different-binary", action="store_true",
                    help="score against a re-saved copy of the workbooks (an explicit, separate mode; the default historical benchmark requires the same binaries)")
    ap.add_argument("--verification")
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    gold = GV.read_json(a.gold)
    v = GV.validate(gold, a.workbooks, manifest=GV.read_json(a.sources) if a.sources else None)
    cid = gold.get("case_id") if isinstance(gold, dict) else "?"
    if v["errors"]:
        print(f"GOLD VALIDATION: FAIL | {cid} | {len(v['errors'])} errors | nothing was scored")
        print(f"GOLD INVALID: {cid} | {len(v['errors'])} errors | nothing was scored")
        for e in v["errors"]:
            print(f"- ERROR: {e}")
        return 2
    gold = v["gold"]
    doc = GV.read_json(a.extraction)
    sc = Scorer(gold, doc, v["books"], a.allow_different_binary)
    R = sc.score_all()
    S = summarise(R)
    recorded = False
    if a.verification:
        ver = GV.read_json(a.verification).get("status") or "not verified"
    else:
        ver = (doc.get("verification") or {}).get("status")
        recorded = bool(ver)
        ver = ver or "not verified"
    integ = integrity_summary(sc.rows, a.allow_different_binary)
    print(render(cid, R, S, sc.integrity, ver, sc.rows, integ, v["warnings"], recorded))
    if a.out:
        json.dump({"case_id": cid, "gold_validation": "PASS", "validation_warnings": v["warnings"], "source_integrity": {"summary": integ, "rows": sc.rows},
                   "summary": S, "integrity": sc.integrity, "workbook_verification": ver, **R,
                   "link_check": "workbooks" if v["books"] else "not run"}, open(a.out, "w"), indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
