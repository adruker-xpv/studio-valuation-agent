# test_onboarding.py (build 13.1, test bench) - checks the deterministic parts of onboarding on synthetic workbooks only:
#   R  the evidence reader: inflated used ranges, hidden/very-hidden sheets, shared/array/data-table formulas, links to other files
#      (supplied and not supplied), dates, targeted reads, numeric search that never claims a link, time budget, stable source ids
#   K  checkpoints: a provisional extraction exists from stage 3; stage files are validated, append-only and resumable
#   V  verify: correct extractions VERIFIED (a preserved discrepancy included); every evidence class is tested as claimed;
#      numeric equality is never promoted to a link; decoys (sensitivity table, prior quarter, copies, another row) never VERIFIED
#   X  reconcile: comparison by fingerprint, reviewer-value measures, statuses, analyst files
#   S  scoring against keys
#   G  Gold mode: gold-mvp/3 validation, scoring (core answers, anchors, rivals, discrepancies, human judgments), source identity, on the
#      synthetic fixture G1 (trial/set-G1, trial/keys/gold-G1.json, trial/reference/G1)
# Prints one line per test and: TESTS: PASS (n/n)
import copy, glob, json, os, shutil, subprocess, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
TB = os.path.dirname(HERE)
TR = os.path.join(TB, "trial")
T1 = os.path.join(TR, "set-T1")
REF = os.path.join(TR, "reference")
TMP = tempfile.mkdtemp()
PY = sys.executable
results = []


def run(script, *args):
    return subprocess.run([PY, os.path.join(HERE, script), *map(str, args)], capture_output=True, text=True).stdout


def test(name, ok, got=""):
    results.append(bool(ok))
    print(f"- {'PASS' if ok else 'FAIL'}: {name}" + (f" -> {got}" if got and not ok else ""))


def new_run(name, workbooks=None):
    rd = os.path.join(TMP, name)
    shutil.rmtree(rd, ignore_errors=True)
    os.makedirs(rd)
    out = run("xlsx_evidence.py", "inventory", "--run-dir", rd, "--workbooks", *(workbooks or sorted(glob.glob(os.path.join(T1, "*.xlsx")))))
    return rd, out


def save(rd, stage, doc, kind="extraction"):
    p = os.path.join(rd, f"draft-{kind}-{stage}.json")
    json.dump(doc, open(p, "w"))
    return run("checkpoint.py", "save", "--run-dir", rd, "--kind", kind, "--stage", stage, "--file", p)


def ref_stage(n):
    return json.load(open(glob.glob(os.path.join(REF, "T1", f"0{n}_*.json"))[0]))


def t1_run(name, upto=6, final=True):
    rd, _ = new_run(name)
    for n in range(2, upto + 1):
        save(rd, n, ref_stage(n))
    if final and upto == 6:
        run("verify.py", "--run-dir", rd, "--final")
    return rd


def verify_doc(rd, X, *extra):
    p = os.path.join(rd, "x.json")
    json.dump(X, open(p, "w"))
    run("verify.py", "--run-dir", rd, "--file", p, "--out", os.path.join(rd, "vx.json"), *extra)
    return json.load(open(os.path.join(rd, "vx.json")))


def edge(V, eid):
    return next(e for e in V["edges"] if e["id"] == eid)


# ---------------- R: reader ----------------
t = time.time()
rd, out = new_run("r")
el = time.time() - t
test("R the five workbooks and the linked file that was not supplied are all fingerprinted",
     out.count("READ: W") == 5 and "X1 | Tidewater - June 2026 TTM Pro Forma v3.xlsx | NOT SUPPLIED" in out and out.count("sha256 ") == 5, out[-300:])
test(f"R an inflated used range (A1:XFD1048576, ~270,000 formatted empty cells) is read in seconds ({el:.1f}s)", el < 20, f"{el:.1f}s")
inv = {os.path.basename(p)[:-4]: open(p).read() for p in glob.glob(os.path.join(rd, "evidence", "inventory", "*.txt"))}
ma = next(k for k, v in inv.items() if "Management Accounts" in v.splitlines()[0])
test("R the inflated sheet is flagged, its real populated area found, empty formatted cells not counted as cells",
     "A1:XFD1048576 -> A1:T102 | 142 cells" in inv[ma] and "INFLATED" in inv[ma], inv[ma][:400])
test("R very-hidden and hidden sheets are exposed", "Old Draft | veryHidden" in inv[ma] and "Q1 Val (old) | hidden" in inv["W1"])
o = run("xlsx_evidence.py", "cells", "--run-dir", rd, "--workbook", ma, "--ref", "'P&L'!K9", "--ref", "'P&L'!C4")
test("R a shared formula is shown as the formula of each cell, with Excel's saved value beside it", "K9 =K7-K8 -> 618,000" in o, o)
test("R a date-formatted serial is shown as a date", "C4 date 2025-01-31" in o, o)
pf = next(k for k, v in inv.items() if "TTM Pro Forma.xlsx" in v.splitlines()[0])
o = run("xlsx_evidence.py", "cells", "--run-dir", rd, "--workbook", pf, "--ref", "TTM!O10") + \
    run("xlsx_evidence.py", "cells", "--run-dir", rd, "--workbook", "W1", "--ref", "Valuation!C15:C17")
test("R array and data-table formulas are shown, and data-table cells are marked as what-if values",
     "{array formula over O10}" in o and "=TABLE(,D7)" in o and "C17 82,607,250 [#,##0] {inside dataTable anchored at C15}" in o, o)
test("R links to other files are resolved: a supplied file to its id, an unsupplied version to an X id",
     f"Tidewater - June 2026 Management Accounts.xlsx -> {ma}" in inv["W1"] and "TTM Pro Forma v3.xlsx -> X1 (NOT SUPPLIED" in inv["W1"], inv["W1"])
o = run("xlsx_evidence.py", "cells", "--run-dir", rd, "--workbook", ma, "--ref", "'EBITDA Adjustments'!B102:T102", "--headers", "3", "--labels", "B:B")
test("R a targeted row read shows each column's header (the 'row 102 vs the TTM window' question in one call)",
     "T=date 2026-06-30" in o and "T102 =SUM(I11:T11) -> 8,455,500" in o, o)
o = run("xlsx_evidence.py", "find", "--run-dir", rd, "--value", "30698613.35")
test("R find reports exact and $000s-rounded matches and says a match is not a link",
     "Waterfall!B10 exact" in o and "rounded at x1000" in o and "NOT evidence of a link" in o, o)
o = run("xlsx_evidence.py", "find", "--run-dir", rd, "--value", "8695500")
test("R find does not report small numbers (multiples) as rounded millions", "x1e+06" not in o and "2 matching cells" in o, o)
o = run("xlsx_evidence.py", "refs", "--run-dir", rd, "--to", f"{ma}:'P&L'!K9")
test("R refs finds formulas in other workbooks that link to a cell", f"{pf}:TTM!E6 ='[1]P&L'!K9" in o, o)
o = run("xlsx_evidence.py", "refs", "--run-dir", rd, "--from", "W1:Valuation!D9") + run("xlsx_evidence.py", "refs", "--run-dir", rd, "--from", "W1:Valuation!D6")
test("R refs from a linked cell compares the cached value with the supplied file, or says the file was not supplied",
     "(same)" in o and "that file was not supplied" in o, o)
o = run("xlsx_evidence.py", "sheet", "--run-dir", rd, "--workbook", ma, "--sheet", "EBITDA Adjustments", "--max-cells", "20")
test("R a sheet read past its cap says so and how to continue (never a silent truncation)", "TRUNCATED: 20 cells shown" in o and "--rows" in o, o[-200:])
rd2 = os.path.join(TMP, "r-budget")
os.makedirs(rd2)
o = run("xlsx_evidence.py", "inventory", "--run-dir", rd2, "--max-seconds", "0", "--workbooks", *sorted(glob.glob(os.path.join(T1, "*.xlsx"))))
c1 = json.load(open(os.path.join(rd2, "checkpoints", "01_sources.json")))
marked = any("NOT READ" in open(p).read() for p in glob.glob(os.path.join(rd2, "evidence", "inventory", "*.txt")))
o2 = run("xlsx_evidence.py", "inventory", "--run-dir", rd2, "--workbooks", *sorted(glob.glob(os.path.join(T1, "*.xlsx"))))
c2 = json.load(open(os.path.join(rd2, "checkpoints", "01_sources.json")))
test("R a call that runs out of time says STOPPED, marks what it did not read, and a rerun completes the same checkpoint",
     "STOPPED" in o and marked and c1["complete"] is False and c2["complete"] is True and c1["made_at"] == c2["made_at"], o[-300:])
o = run("xlsx_evidence.py", "inventory", "--run-dir", rd, "--workbooks", *reversed(sorted(glob.glob(os.path.join(T1, "*.xlsx")))))
test("R source ids are stable: rerunning inventory (files in another order) keeps checkpoint 1 unchanged", "kept unchanged (resuming)" in o, o)
from openpyxl import load_workbook
vo = os.path.join(TMP, "values only.xlsx")
load_workbook(os.path.join(T1, "2026 Q2 - Tidewater Valuation (30 June 2026).xlsx"), data_only=True).save(vo)
rd3, o = new_run("r-values", [vo])
test("R a workbook that arrived without its formulas is flagged", "READ WARNING" in o and "no formulas" in o, o)
o = run("xlsx_evidence.py", "inventory", "--run-dir", rd, "--workbooks", vo)
test("R a different set of files in the same run folder is refused, not merged", "differ from the ones this run started with" in o, o)

# ---------------- K: checkpoints ----------------
rd = t1_run("k", upto=3)
X = json.load(open(os.path.join(rd, "extraction.json")))
test("K after stage 3 a usable extraction exists: PROVISIONAL, with the chain, and stages 4-7 pending",
     X["status"] == "provisional" and X["chain"]["enterprise_value"]["cell"] == "Valuation!D8" and X["stages_pending"] == [4, 5, 6, 7], X["stages_pending"])
o = run("checkpoint.py", "status", "--run-dir", rd)
test("K status names the next stage with its goal and budget", "NEXT: stage 4 upstream" in o and "budget about 25" in o, o[-300:])
bad = ref_stage(4)
bad["provenance"][0]["class"] = "linked"
o = save(rd, 4, bad)
test("K a stage with an unknown evidence class is rejected and nothing is saved",
     "rejected" in o and "class 'linked'" in o and not glob.glob(os.path.join(rd, "checkpoints", "04_*")), o)
bad = ref_stage(4)
bad["provenance"][0]["to"]["source"] = "W9"
o = save(rd, 4, bad)
test("K an unknown source id is rejected", "unknown source 'W9'" in o, o)
bad = ref_stage(4)
bad["provenance"][0]["to"]["cell"] = "Valuation D6"
o = save(rd, 4, bad)
test("K a malformed cell reference is rejected", "is not 'Sheet'!A1" in o, o)
bad = ref_stage(4)
bad["provenance"][0]["to"]["cell"] = "Valuations!D6"
o = save(rd, 4, bad)
test("K a sheet that does not exist is rejected", "has no sheet 'Valuations'" in o, o)
big = ref_stage(4)
big["deferred"] = ["x" * 400] * 19 + ["y" * 60000]
o = save(rd, 4, big)
test("K an oversized stage is rejected with the instruction to move detail to evidence", "cap 60,000" in o and "evidence/" in o, o[:300])
bad = ref_stage(4)
bad["provenance"] = [dict(bad["provenance"][3], id=f"E{100 + i}") for i in range(61)]
o = save(rd, 4, bad)
test("K too many items in a section are rejected (keep material ones)", "keep at most 60" in o and "duplicate id" not in o, o[:300])
rdo, _ = new_run("k-order")
save(rdo, 2, ref_stage(2))
o = save(rdo, 4, ref_stage(4))
test("K a stage saved before its prerequisites is rejected", "needs stage(s) 3 first" in o, o)
r2 = ref_stage(2)
r2["sources"] = r2["sources"][:4]
o = save(rdo, 2, r2)
test("K every supplied workbook must get a role ('not_used' is a role)", "every supplied workbook needs a role" in o, o)
save(rd, 4, ref_stage(4))
s4 = ref_stage(4)
s4["provenance"][0]["what"] = "revised wording"
o = save(rd, 4, s4)
test("K a re-saved stage is stored as a revision; the original is kept and the revision wins",
     os.path.exists(os.path.join(rd, "checkpoints", "04_upstream.json")) and os.path.exists(os.path.join(rd, "checkpoints", "04_upstream.r2.json"))
     and json.load(open(os.path.join(rd, "extraction.json")))["provenance"][0]["what"] == "revised wording", o)
rd = t1_run("k-full")
x1 = json.load(open(os.path.join(rd, "extraction.json")))
rr = os.path.join(TMP, "k-resume")
shutil.rmtree(rr, ignore_errors=True)
shutil.copytree(os.path.join(rd, "checkpoints"), os.path.join(rr, "checkpoints"))
o = run("xlsx_evidence.py", "inventory", "--run-dir", rr, "--workbooks", *sorted(glob.glob(os.path.join(T1, "*.xlsx"))))
run("checkpoint.py", "assemble", "--run-dir", rr)
x2 = json.load(open(os.path.join(rr, "extraction.json")))
strip = lambda d: {k: v for k, v in d.items() if k != "assembled_at"}
test("K a fresh agent with only the checkpoints rebuilds exactly the same extraction (resume)", strip(x1) == strip(x2) and x2["status"] == "final")
save(rd, 6, dict(ref_stage(6), open_questions=ref_stage(6)["open_questions"][:1]))
x3 = json.load(open(os.path.join(rd, "extraction.json")))
o = run("checkpoint.py", "status", "--run-dir", rd)
test("K saving a stage after validation makes the extraction provisional again until verify --final reruns",
     x3["status"] == "provisional" and "out of date" in o, o[-400:])
rb, _ = new_run("k-blind")
core = json.load(open(os.path.join(REF, "T1-blind", "02_core.json")))
core["provenance"] = [dict(core["provenance"][0], id=f"B{i}") for i in range(21)]
o = save(rb, 2, core, "blind")
test("K the blind review is capped at 20 key edges", "keep at most 20" in o, o[:300])

# ---------------- V: verify ----------------
rd = t1_run("v")
V = json.load(open(os.path.join(rd, "verification.json")))
test("V the five-workbook reference is VERIFIED, and the fund discrepancy is confirmed and preserved (a pass, not a failure)",
     V["status"] == "VERIFIED" and V["detail"]["fund"].get("discrepancy") == "D1" and V["discrepancies"][0]["status"] == "confirmed", V["status"])
test("V judgment edges are never 'confirmed': contextual support stays not checkable", edge(V, "E6")["status"] == "not_checkable")
rp = t1_run("v-prov", upto=3)
o = run("verify.py", "--run-dir", rp)
test("V a provisional extraction (stages 1-3) is PROVISIONAL with the core checks passing",
     "status | PROVISIONAL" in o and "chain | pass" in o and "window | pass" in o and "fund | pass" in o, o)
X = json.load(open(os.path.join(rd, "extraction.json")))


def mutate(f):
    Y = copy.deepcopy(X)
    f(Y)
    return verify_doc(rd, Y)


def set_edge(Y, eid, **kw):
    for sec in ("provenance", "downstream"):
        for e in Y[sec]:
            if e["id"] == eid:
                e.update(kw)


R_ = mutate(lambda Y: set_edge(Y, "E5", **{"class": "direct_formula_link"}))
test("V numeric equality is never promoted to a link: a pasted match claimed as a formula link is CONTRADICTED",
     R_["status"] == "REVIEW" and edge(R_, "E5")["status"] == "contradicted" and "match, not a link" in edge(R_, "E5")["note"], edge(R_, "E5")["note"])
R_ = mutate(lambda Y: set_edge(Y, "E4", **{"class": "pasted_exact_match"}))
test("V a real formula link claimed as a pasted match is contradicted (understated evidence is still wrong)",
     "classify direct_formula_link" in edge(R_, "E4")["note"], edge(R_, "E4")["note"])
R_ = mutate(lambda Y: set_edge(Y, "E1", **{"from": {"source": "W4", "cell": "TTM!O10"}}))
test("V a link claimed to the supplied file when the formula points at another version (v3) is contradicted",
     edge(R_, "E1")["status"] == "contradicted" and "does not refer to" in edge(R_, "E1")["note"], edge(R_, "E1")["note"])
R_ = mutate(lambda Y: set_edge(Y, "E20", relation={"op": "round", "factor": 0.01, "decimals": 0}))
test("V a rounded match with the wrong scale is contradicted", edge(R_, "E20")["status"] == "contradicted", edge(R_, "E20")["note"])
R_ = mutate(lambda Y: set_edge(Y, "E20", **{"class": "pasted_exact_match", "relation": None}))
test("V a rounded figure claimed as an exact match is contradicted", edge(R_, "E20")["status"] == "contradicted", edge(R_, "E20")["note"])
R_ = mutate(lambda Y: set_edge(Y, "E3", **{"from": {"source": "W4", "cell": "TTM!C10:M10"}}))
test("V a sum over the wrong months does not recompute", edge(R_, "E3")["status"] == "contradicted", edge(R_, "E3")["note"])
R_ = mutate(lambda Y: set_edge(Y, "E3", **{"class": "arithmetic_transformation"}))
test("V an arithmetic transformation (sum) that recomputes is confirmed", edge(R_, "E3")["status"] == "confirmed" and R_["status"] == "VERIFIED", R_["status"])
R_ = mutate(lambda Y: Y["discrepancies"][0].update(b={"source": "W2", "cell": "'Fund Calc'!C5"}, difference=None))
test("V a 'discrepancy' between two values that agree is contradicted", R_["discrepancies"][0]["status"] == "contradicted", R_["discrepancies"][0]["note"])
R_ = mutate(lambda Y: Y["discrepancies"][0].update(difference=-500))
test("V a discrepancy with the wrong stated difference is contradicted", R_["discrepancies"][0]["status"] == "contradicted", R_["discrepancies"][0]["note"])


def hide_disc(Y):
    Y["discrepancies"] = []
    Y["downstream"].append({"id": "E99", "from": {"source": "W1", "cell": "Waterfall!B10"}, "to": {"source": "W2", "cell": "Portfolio!D5"},
                            "class": "rounded_match", "relation": {"op": "round", "factor": 0.001, "decimals": 0}, "what": "forced"})
R_ = mutate(hide_disc)
test("V forcing the company value to reconcile with the fund value is caught", R_["status"] == "REVIEW" and edge(R_, "E99")["status"] == "contradicted", R_["status"])
R_ = mutate(lambda Y: Y.update(discrepancies=[], downstream=[]))
test("V a company value never connected to the fund cell (no edge, no discrepancy) fails", R_["checks"]["fund"] == "fail", R_["checks"]["fund"])
R_ = mutate(lambda Y: Y["sources"][0].update(sha256="0" * 64))
test("V an extraction made from a different file fails integrity", R_["checks"]["integrity"] == "fail" and R_["status"] == "REVIEW")
R_ = mutate(lambda Y: Y["chain"]["enterprise_value"].update(cell="Valuation!C17"))
test("V decoy: EV = the sensitivity data-table row with the same value is not VERIFIED", R_["status"] != "VERIFIED" and R_["checks"]["chain"] == "fail")


def prior(Y):
    c = Y["chain"]
    for r, a in (("valuation_metric", "C6"), ("selected_multiple", "C7"), ("enterprise_value", "C8"), ("equity_value", "C11")):
        c[r]["cell"] = f"Valuation!{a}"
    c["bridge"] = [{"cell": "Valuation!C9", "sign": 1}, {"cell": "Valuation!C10", "sign": -1}]
R_ = mutate(prior)
test("V decoy: the live previous-quarter chain is not VERIFIED", R_["status"] != "VERIFIED", R_["status"])
R_ = mutate(lambda Y: Y["chain"]["value_to_xpv"].update(cell="Report!D6"))
test("V decoy: the report's rounded copy as XPV's value is not VERIFIED", R_["status"] != "VERIFIED", R_["status"])
R_ = mutate(lambda Y: Y["chain"]["fund_cell"].update(cell="Portfolio!D4"))
test("V decoy: another company's fund row is not VERIFIED", R_["status"] != "VERIFIED" and R_["checks"]["fund"] == "fail", R_["checks"]["fund"])
R_ = mutate(lambda Y: Y["chain"]["metric_window"].update(cells="TTM!C10:M10"))
test("V a window of 11 months fails", R_["checks"]["window"] == "fail")
R_ = mutate(lambda Y: Y["chain"]["metric_window"].update(source="W3", cells="'EBITDA Adjustments'!I11:T11"))
test("V a window that does not sum to the metric (the excl.-pro-forma rival) fails", R_["checks"]["window"] == "fail")
R_ = mutate(lambda Y: Y["chain"]["metric_window"].update(link="direct_formula_link"))
test("V a window claimed as a formula link when the path runs through an unsupplied file fails",
     R_["checks"]["window"] == "fail" and "no formula path" in R_["detail"]["window"].get("problem", ""), R_["detail"]["window"])
R_ = mutate(lambda Y: Y["chain"].update(metric_window={"link": "unresolved"}))
test("V an honestly unresolved window gives SUPPORTED, never VERIFIED and never a failure", R_["status"] == "SUPPORTED", R_["status"])
CO = {11: "Granite Basin Services", 23: "Northline Utilities", 37: "Blue Heron Water", 68: "Granite Basin Services"}
trial = {}
for seed in (11, 23, 37, 68):
    d = os.path.join(TR, f"workbook-{seed}")
    r_, _ = new_run(f"v{seed}", [os.path.join(d, f) for f in sorted(os.listdir(d))])
    for n, doc in enumerate(json.load(open(os.path.join(REF, f"stages-{seed}.json"))), 2):
        save(r_, n, doc)
    o = run("verify.py", "--run-dir", r_, "--final", "--company", CO[seed])
    trial[seed] = r_
    test(f"V two-workbook trial {seed}: the migrated reference is VERIFIED", "status | VERIFIED" in o, o.splitlines()[-1] if o else "")
VS, EA = "'Valuation Summary'", "'Equity Allocation'"
cases = [
    ("EV = the sensitivity row with the same value", 23, {"enterprise_value": f"{VS}!D18"}),
    ("EV and equity = sensitivity rows", 23, {"enterprise_value": f"{VS}!D18", "equity_value": f"{VS}!D19"}),
    ("the live previous-quarter chain", 37, {"enterprise_value": f"{VS}!C8", "equity_value": f"{VS}!C11", "valuation_metric": f"{VS}!C6",
                                             "selected_multiple": f"{VS}!C7", "bridge": [{"cell": f"{VS}!C9", "sign": 1}, {"cell": f"{VS}!C10", "sign": 1}],
                                             "window": {"source": "W1", "first": "2025-04", "last": "2026-03", "cells": "'Monthly P&L'!E12:P12", "link": "direct_formula_link"}}),
    ("XPV's value = the report's copy", 23, {"value_to_xpv": "'Investor Report'!E6"}),
    ("XPV's value in local currency (the fund reports USD)", 11, {"value_to_xpv": f"{EA}!B16"}),
    ("multiple = the comparables median", 23, {"selected_multiple": "'Trading Comps'!D11"}),
    ("another company's fund row", 11, {"fund": "Portfolio!D5"}),
    ("equity = the waterfall's copy of equity", 23, {"equity_value": "Waterfall!B3"}),
    ("option decoy", 11, {"enterprise_value": f"{EA}!D6", "valuation_metric": f"{EA}!B6", "selected_multiple": f"{EA}!C6", "equity_value": f"{EA}!B10",
                          "bridge": [{"cell": f"{EA}!D7", "sign": 1}, {"cell": f"{EA}!B3", "sign": 1}]}),
    ("option decoy with no window", 11, {"enterprise_value": f"{EA}!D6", "valuation_metric": f"{EA}!B6", "selected_multiple": f"{EA}!C6",
                                         "equity_value": f"{EA}!B10", "window": {"link": "unresolved"}}),
]
for name, seed, ch in cases:
    Y = json.load(open(os.path.join(trial[seed], "extraction.json")))
    for k, v in ch.items():
        if k == "bridge":
            Y["chain"]["bridge"] = v
        elif k == "window":
            Y["chain"]["metric_window"] = v
        elif k == "fund":
            Y["chain"]["fund_cell"]["cell"] = v
        else:
            Y["chain"][k]["cell"] = v
    R_ = verify_doc(trial[seed], Y, "--company", CO[seed])
    test(f"V decoy on trial {seed}: {name} is not VERIFIED", R_["status"] != "VERIFIED", R_["status"])

# ---------------- X: reconcile ----------------
rd = t1_run("x")
rb = os.path.join(rd, "reviewer")
os.makedirs(rb)
run("xlsx_evidence.py", "inventory", "--run-dir", rb, "--workbooks", *sorted(glob.glob(os.path.join(T1, "*.xlsx"))))
save(rb, 2, json.load(open(os.path.join(REF, "T1-blind", "02_core.json"))), "blind")
save(rb, 3, json.load(open(os.path.join(REF, "T1-blind", "03_challenges.json"))), "blind")
o = run("reconcile.py", "--run-dir", rd, "--compare-only")
C = json.load(open(os.path.join(rd, "out", "compare.json")))
test("X compare-only lists the contested items for phase 2 (every blind challenge included) and gives no status",
     "COMPARE: core agreed 9/9" in o and sum(c["kind"] == "blind challenge" for c in C["contested"]) == 4 and "ONBOARDING" not in o, o)
save(rb, 1, json.load(open(os.path.join(REF, "T1-blind", "review_findings.json"))), "review")
o = run("reconcile.py", "--run-dir", rd, "--review", os.path.join(rb, "review.json"))
RC = json.load(open(os.path.join(rd, "out", "reconcile.json")))
test("X a faithfully preserved discrepancy makes the run NEEDS ANALYST (a decision), never CHECKS FAILED",
     RC["status"] == "NEEDS ANALYST" and any(q["from"] == "discrepancy" for q in RC["questions"]), RC["status"])
test("X the reviewer's different path is measured (top-down from the fund vs bottom-up from the monthly financials)",
     RC["reviewer_value"]["different_path"] is True and "bottom_up from monthly_financials" in RC["reviewer_value"]["reviewer_path"], RC["reviewer_value"])
test("X an unsupported assumption counts as judgment-only added value", RC["reviewer_value"]["value"].startswith("ADDED VALUE (judgment only"), RC["reviewer_value"]["value"])


def recon(rv=None, blind=None, xdoc=None):
    rdd = os.path.join(TMP, "xr")
    shutil.rmtree(rdd, ignore_errors=True)
    shutil.copytree(rd, rdd)
    if xdoc is not None:
        json.dump(xdoc, open(os.path.join(rdd, "extraction.json"), "w"))
    if blind is not None:
        json.dump(blind, open(os.path.join(rdd, "reviewer", "reviewer_blind.json"), "w"))
    rv = rv if rv is not None else json.load(open(os.path.join(rb, "review.json")))
    json.dump(rv, open(os.path.join(rdd, "rv.json"), "w"))
    run("reconcile.py", "--run-dir", rdd, "--review", os.path.join(rdd, "rv.json"))
    return json.load(open(os.path.join(rdd, "out", "reconcile.json")))


RV0 = json.load(open(os.path.join(rb, "review.json")))
rv = copy.deepcopy(RV0)
rv["findings"].append({"id": "F9", "type": "missed_rival", "target": "new", "evidence": [{"source": "W1", "cell": "Comps!D10"}], "note": "comps median", "material": True})
rv["findings"].append({"id": "F10", "type": "missed_rival", "target": "new", "evidence": [{"source": "W1", "cell": "Valuation!C17"}], "note": "sensitivity", "material": True})
r_ = recon(rv)
test("X a missed rival counts only if the extraction neither used nor rejected it",
     r_["reviewer_value"]["missed_material_rivals"] == 1 and next(f for f in r_["findings"] if f["id"] == "F10")["novel"] is False, r_["reviewer_value"])
Xb = json.load(open(os.path.join(rd, "extraction.json")))
for e in Xb["provenance"]:
    if e["id"] == "E5":
        e["class"] = "direct_formula_link"
rv = copy.deepcopy(RV0)
rv["findings"].append({"id": "F11", "type": "contradiction", "target": "E5", "evidence": [{"source": "W4", "cell": "TTM!C7:N7"}], "material": True,
                       "note": "the add-backs are typed, not linked", "claim": {"from": {"source": ma, "cell": "'EBITDA Adjustments'!I9:T9"},
                       "to": {"source": "W4", "cell": "TTM!C7:N7"}, "class": "pasted_exact_match", "what": "add-backs"}})
rv["findings"].append({"id": "F12", "type": "contradiction", "target": "E4", "evidence": [{"source": "W4", "cell": "TTM!C6:N6"}], "material": True,
                       "note": "wrong claim", "claim": {"from": {"source": ma, "cell": "'P&L'!I9:T9"}, "to": {"source": "W4", "cell": "TTM!C6:N6"},
                       "class": "pasted_exact_match", "what": "reported EBITDA"}})
r_ = recon(rv, xdoc=Xb)
test("X a contradiction whose claim verify confirms is counted as evidence-backed; one that fails verify is a reviewer error",
     r_["reviewer_value"]["evidence_backed_contradictions"] == 1 and r_["reviewer_value"]["reviewer_claims_contradicted"] >= 1, r_["reviewer_value"])
test("X an extraction verify contradicts is CHECKS FAILED, whatever the agents agree on", r_["status"] == "CHECKS FAILED", r_["status"])
bl = json.load(open(os.path.join(rb, "reviewer_blind.json")))
bl2 = copy.deepcopy(bl)
bl2["direction"] = "top_down"
bl2["path"] = [{"source": "W2", "cell": "Portfolio!D5", "step": "fund"}]
r_ = recon({"produced_by": "t", "findings": [], "overall": "ok"}, blind=bl2)
test("X same path, full agreement and no findings: 'no independent value shown' (agreement is not proof)",
     r_["reviewer_value"]["value"] == "NO INDEPENDENT VALUE SHOWN", r_["reviewer_value"]["value"])
bl3 = copy.deepcopy(bl)
bl3["sources"][0]["sha256"] = "1" * 64
r_ = recon(blind=bl3)
test("X the reviewer read different files: CHECKS FAILED, integrity first", r_["status"] == "CHECKS FAILED" and r_["questions"][0]["from"] == "integrity", r_["status"])
bl4 = copy.deepcopy(bl)
bl4["chain"]["value_to_xpv"]["cell"] = "Waterfall!B7"
r_ = recon(blind=bl4)
test("X the blind reviewer picks another cell: NEEDS ANALYST with the question", r_["status"] == "NEEDS ANALYST" and
     any("Waterfall!B7" in q["question"] and "Waterfall!B10" in q["question"] for q in r_["questions"]), r_["status"])
# trial 11: agreement by a different path, nothing open -> READY FOR APPROVAL
r11 = trial[11]
X11 = json.load(open(os.path.join(r11, "extraction.json")))
bl11 = {k: X11[k] for k in ("schema", "sources", "external", "company", "quarter_end", "valuation_workbook", "fund_workbook", "chain", "provenance", "downstream", "discrepancies")}
bl11.update(produced_by="blind (test)", direction="bottom_up", path=[{"source": "W1", "cell": X11["chain"]["metric_window"]["cells"], "step": "monthly"}],
            challenges=[], status="final")
json.dump(bl11, open(os.path.join(r11, "reviewer_blind.json"), "w"))
json.dump({"produced_by": "t", "findings": [{"id": "F1", "type": "confirmed", "target": "chain.value_to_xpv", "evidence": [], "note": "checked"}],
           "overall": "complete", "questions": []}, open(os.path.join(r11, "review.json"), "w"))
run("reconcile.py", "--run-dir", r11, "--company", CO[11])
r_ = json.load(open(os.path.join(r11, "out", "reconcile.json")))
test("X verified, agreed by a different path, nothing to decide: READY FOR APPROVAL (value: corroboration)",
     r_["status"] == "READY FOR APPROVAL" and r_["reviewer_value"]["value"] == "CORROBORATION (different path)", (r_["status"], r_["reviewer_value"]["value"]))
Xq = copy.deepcopy(X11)
Xq["how_it_works"] = "=SUM(A1) is how a careless reader would see it"
json.dump(Xq, open(os.path.join(r11, "extraction.json"), "w"))
json.dump({"responses": [{"item": "F1", "position": "contest", "evidence": "B22 is typed, see the cell"}]}, open(os.path.join(r11, "resp.json"), "w"))
run("reconcile.py", "--run-dir", r11, "--company", CO[11], "--response", os.path.join(r11, "resp.json"))
r_ = json.load(open(os.path.join(r11, "out", "reconcile.json")))
c = load_workbook(os.path.join(r11, "out", "onboarding_review.xlsx"))["Summary"]["B12"]
test("X text beginning with '=' is stored as text in the analyst workbook, never as a formula", c.data_type == "s" and str(c.value).startswith("="), c.data_type)
test("X the extractor's response round appears beside the dispute", any("stands by its reading" in q["question"] for q in r_["questions"]))

# ---------------- S: scoring ----------------
o = run("score.py", "--key", os.path.join(TR, "keys", "key-T1.json"), "--extraction", os.path.join(rd, "extraction.json"))
test("S the five-workbook reference scores 9/9, confidently wrong 0", "9/9 correct | verify VERIFIED | confidently wrong 0" in o, o)
Y = json.load(open(os.path.join(rd, "extraction.json")))
Y["chain"]["enterprise_value"]["cell"] = "Valuation!C17"
json.dump(Y, open(os.path.join(TMP, "wrong.json"), "w"))
o = run("score.py", "--key", os.path.join(TR, "keys", "key-T1.json"), "--extraction", os.path.join(TMP, "wrong.json"))
test("S a wrong answer under a VERIFIED stamp is reported as confidently wrong", "confidently wrong 1" in o, o)


# ---------------- G: Gold mode (gold-mvp/3, synthetic fixture G1) ----------------
import hashlib
G1 = os.path.join(TR, "set-G1")
GOLDKEY = os.path.join(TR, "keys", "gold-G1.json")
GWB = sorted(glob.glob(os.path.join(G1, "*.xlsx")))
GFLAW = json.load(open(os.path.join(REF, "G1", "extraction-flawed.json")))
GCLEAN = json.load(open(os.path.join(REF, "G1", "extraction-clean.json")))
GOLD0 = json.load(open(GOLDKEY))
CO, FU = "W5", "W1"          # the evidence reader's ids for the company and fund workbooks (NOT Gold's W1 and W2): source mapping is part of every test
_gn = [0]


def grun(script, args):
    r = subprocess.run([PY, os.path.join(HERE, script), *map(str, args)], capture_output=True, text=True)
    return r.returncode, r.stdout


def gscore(X, gold=None, wb=True, extra=()):
    """score extraction X (dict) against gold (dict, default the G1 key); -> (stdout, report dict or None, returncode)"""
    _gn[0] += 1
    gp, xp, op = (os.path.join(TMP, f"g{_gn[0]}{n}.json") for n in ("k", "x", "o"))
    json.dump(gold or GOLD0, open(gp, "w"))
    json.dump(X, open(xp, "w"))
    rc, out = grun("gold_score.py", ["--gold", gp, "--extraction", xp, "--out", op, *extra] + (["--workbooks", *GWB] if wb else []))
    return out, (json.load(open(op)) if os.path.exists(op) else None), rc


def gvalid(gold, wb=True):
    gp = os.path.join(TMP, f"gv{_gn[0] + 1}.json")
    _gn[0] += 1
    json.dump(gold, open(gp, "w"))
    return grun("gold_validate.py", ["--gold", gp] + (["--workbooks", *GWB] if wb else []))


def mut(base, fn):
    d = copy.deepcopy(base)
    fn(d)
    return d


def line(out, label):
    return next((l for l in out.splitlines() if l.startswith(label)), "")


def st(R, kind, key, field="concept"):
    return next((x["status"] for x in R[kind] if x.get(field) == key), None)


def anc(R, key):
    return next(x["anchor"] for x in R["concepts"] if x["concept"] == key)


# --- the fixture and the validator
d1 = os.path.join(TMP, "g1regen")
subprocess.run([PY, os.path.join(HERE, "make_gold_fixture.py"), "--out", d1], capture_output=True)
same = all(hashlib.sha256(open(os.path.join(d1, "set-G1", os.path.basename(f)), "rb").read()).hexdigest() == hashlib.sha256(open(f, "rb").read()).hexdigest() for f in GWB) \
    and all(open(os.path.join(d1, a), "rb").read() == open(os.path.join(TR, a), "rb").read()
            for a in ("keys/gold-G1.json", "reference/G1/extraction-flawed.json", "reference/G1/extraction-clean.json"))
test("G the synthetic G1 fixture (five workbooks, key, two extractions) regenerates byte-for-byte", same)
rc, o = gvalid(GOLD0)
test("G a complete gold-mvp/3 key validates with the frozen workbooks (files, SHA-256, anchor cells, numbers incl. a $000s copy)", rc == 0 and "GOLD VALID: G1" in o and "WARN" not in o, o)
rc, o = gvalid(GOLD0, wb=False)
test("G without workbooks it still validates but says the file and cell checks were skipped", rc == 0 and "workbooks not supplied" in o, o)
for name, fn, needle in [
    ("a different schema", lambda g: g.update(schema="gold-mvp/2"), "gold-mvp/3"),
    ("certification not YES", lambda g: g["certification"].update(material_truth_complete="NO"), "not YES"),
    ("certification listing missing items", lambda g: g["certification"].update(missing=["cap table"]), "does not yet capture"),
    ("FILL_IN text", lambda g: g["answers"]["applied_multiple"].update(answer="FILL_IN"), "placeholder"),
    ("a <number> template placeholder", lambda g: g["answers"]["enterprise_value"].update(calculation="<number>"), "placeholder"),
    ("an anchor on a source that does not exist", lambda g: g["answers"]["enterprise_value"]["primary_anchor"].update(ref="W9:'Valuation Summary'!F11"), "W9"),
    ("a malformed reference", lambda g: g["answers"]["enterprise_value"]["primary_anchor"].update(ref="Valuation Summary F11"), "not W<n>"),
    ("a non-numeric numeric answer", lambda g: g["answers"]["enterprise_value"].update(answer="twenty million"), "must be a number"),
    ("Gold that contradicts itself (EV + cash - debt != equity)", lambda g: g["answers"]["equity_bridge"].update(equity_value=22_000_000), "disagrees with itself"),
    ("a human judgment answered definitively", lambda g: g["human_judgments"][0].update(answer="Company value"), "must be UNRESOLVED"),
    ("a bad discrepancy status", lambda g: g["material_discrepancies"][0].update(status="BIG"), "status must be"),
    ("a duplicate id", lambda g: g["known_rivals"][0].update(id="HJ1"), "duplicate id"),
]:
    rc, o = gvalid(mut(GOLD0, fn))
    test(f"G invalid Gold is refused: {name}", rc == 1 and "GOLD INVALID" in o and needle in o, o)
rc, o = grun("gold_validate.py", ["--gold", os.path.join(TB, "templates", "gold-mvp-3.template.json")])
test("G the blank Gold template cannot be scored until an analyst fills it in (placeholders and certification refuse it)", rc == 1 and "placeholder text" in o and "not YES" in o)
rc, o = grun("gold_validate.py", ["--gold", os.path.join(TR, "keys", "key-T1.json")])
test("G a legacy trial key is not a Gold key", rc == 1 and "GOLD INVALID" in o)
rc, o = grun("gold_validate.py", ["--gold", GOLDKEY, "--workbooks", *GWB[:4]])
test("G a missing frozen workbook is an error", rc == 1 and "not among the supplied workbooks" in o, o)
rc, o = gvalid(mut(GOLD0, lambda g: g["source_files"]["W2"].update(sha256="0" * 64)))
test("G a file with the right name but another SHA-256 is an error (not the frozen file)", rc == 1 and "differs" in o, o)
rc, o = gvalid(mut(GOLD0, lambda g: g["answers"]["enterprise_value"].update(answer=19_000_000)))
test("G Gold's number must equal the anchor's saved value", rc == 1 and "holds 20000000" in o, o)
rc, o = gvalid(mut(GOLD0, lambda g: [g["known_rivals"][0].pop(k) for k in ("id", "cells", "keywords")]))
test("G an item with no matching metadata stays valid, with a warning", rc == 0 and "cannot be matched deterministically" in o, o)
rc, o = gvalid(mut(GOLD0, lambda g: g["source_files"].update({k: v["file"] for k, v in g["source_files"].items()})), wb=True)
test("G source_files may be plain file names (no SHA-256): matched by name, with a note", rc == 0 and "matched" in o and "by file name" in o, o)

# --- the two baseline scores
out, R, rc = gscore(GFLAW)
want = ["Core semantic answers: 9/10", "Exact primary anchors: 6/8", "Equivalent linked anchors: 1 (Gold-listed 1, verified by workbook link 0)", "Wrong material answers: 0",
        "Material Gold items omitted: 1", "Known rivals: 1/1", "Material discrepancies: 1/1", "Unresolved judgments: 0/1", "False material claims: 1", "Integrity: OK"]
test("G the flawed fixture scores as designed: 9/10 core, 1 equivalent anchor, rival 1/1, discrepancy 1/1, judgment 0/1, 1 false claim, 1 omitted",
     rc == 0 and all(w in out.splitlines() for w in want), [w for w in want if w not in out.splitlines()])
test("G the omission (waterfall) and the false claim (an approval the workbooks cannot support) are listed, as different things",
     st(R, "concepts", "ownership_or_waterfall") == "OMITTED" and st(R, "judgments", "HJ1", "id") == "UNSUPPORTED_CONCLUSION" and R["summary"]["wrong_material_answers"] == 0)
out2, R2, _ = gscore(GCLEAN)
test("G the clean fixture scores 10/10 core, 1/1 rival, 1/1 discrepancy, 1/1 judgment, no false claims, nothing omitted",
     all(w in out2.splitlines() for w in ["Core semantic answers: 10/10", "Known rivals: 1/1", "Material discrepancies: 1/1", "Unresolved judgments: 1/1",
                                          "False material claims: 0", "Material Gold items omitted: 0"]), out2[:400])
test("G Gold's W1 is found under another id in the extraction (the reader numbers files by name): the company workbook is W5 there",
     next(x["extraction"] for x in R["concepts"] if x["concept"] == "enterprise_value").startswith("W5:"))
out3, R3, _ = gscore(GFLAW, wb=False)
test("G the same extraction scores the same without the workbooks (no link check was needed)", R3["summary"] == R["summary"] and R3["link_check"] == "not run" and R["link_check"] == "workbooks")
o4, _, _ = gscore(GFLAW)
test("G scoring is reproducible: the same inputs print the same lines", o4 == out)

# --- semantic normalisation
for v in ("EV/EBITDA", "EV / EBITDA", "EV to EBITDA", "EBITDA multiple", "Enterprise value / EBITDA multiple", "ev/ebitda Multiple"):
    _, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"].update(method=v)))
    test(f"G wording is not a failure: method '{v}' = Gold's 'EV/EBITDA'", st(Rv, "concepts", "valuation_method") == "CORRECT", st(Rv, "concepts", "valuation_method"))
ov, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"].update(method="EV/Revenue multiple")))
test("G a different method is WRONG and counts as a false material claim", st(Rv, "concepts", "valuation_method") == "WRONG" and Rv["summary"]["false_material_claims"] == 1)
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"].update(method="Hybrid approach")))
test("G a method that cannot be normalised is NEEDS_ANALYST, not wrong", st(Rv, "concepts", "valuation_method") == "NEEDS_ANALYST")

# --- anchors
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"].__setitem__("value_to_xpv", {"source": CO, "cell": "'Cap Table'!M38"})))
test("G the exact primary anchor (Cap Table!M38) is EXACT_ANCHOR", anc(Rv, "company_value") == "EXACT_ANCHOR" and Rv["summary"]["anchors_exact"] == 8)
test("G the formula-linked Valuation Summary!F26 is a Gold-listed equivalent, not a semantic failure", anc(R, "company_value") == "GOLD_EQUIVALENT_ANCHOR" and st(R, "concepts", "company_value") == "CORRECT")
G_NOSUP = mut(GOLD0, lambda g: g["answers"]["company_value"].pop("supporting_anchors"))
for cell, hops in (("'Valuation Summary'!F26", 1), ("'LP Report'!I13", 2)):
    X = mut(GCLEAN, lambda d: d["chain"].__setitem__("value_to_xpv", {"source": CO, "cell": cell}))
    _, Rv, _ = gscore(X, G_NOSUP)
    test(f"G {cell} is not in Gold's list but is a verified chain of {hops} formula cop{'y' if hops == 1 else 'ies'} of M38 (the scaled LP copy included): VERIFIED_LINKED_EQUIVALENT",
         anc(Rv, "company_value") == "VERIFIED_LINKED_EQUIVALENT" and st(Rv, "concepts", "company_value") == "CORRECT", (anc(Rv, "company_value"), st(Rv, "concepts", "company_value")))
    _, Rn, _ = gscore(X, G_NOSUP, wb=False)
    test(f"G the same choice without workbooks is UNVERIFIED and NEEDS_ANALYST, never wrong", anc(Rn, "company_value") == "UNVERIFIED" and st(Rn, "concepts", "company_value") == "NEEDS_ANALYST" and Rn["summary"]["wrong_material_answers"] == 0)
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"].__setitem__("value_to_xpv", {"source": CO, "cell": "'LP Report'!I20"})), G_NOSUP)
test("G a typed copy with the same number as M38 (LP Report!I20) is WRONG_ANCHOR: numeric equality is not a link",
     anc(Rv, "company_value") == "WRONG_ANCHOR" and st(Rv, "concepts", "company_value") == "WRONG" and "numeric equality is not a link" in next(x["detail"] for x in Rv["concepts"] if x["concept"] == "company_value"))
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"].__setitem__("value_to_xpv", {"source": CO, "cell": "'Valuation Summary'!F14"})), G_NOSUP)
test("G a copy-chain never leaks through arithmetic: equity (F14, copied into the cap table) is not equivalent to the waterfall result", anc(Rv, "company_value") == "WRONG_ANCHOR")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"].__setitem__("valuation_metric", {"source": CO, "cell": "'Valuation Summary'!F11"})))
test("G a cell computed from the metric (EV = metric x multiple) is not the metric", anc(Rv, "valuation_metric") == "WRONG_ANCHOR" and st(Rv, "concepts", "valuation_metric") == "WRONG")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"].__setitem__("valuation_metric", {"source": CO, "cell": "'Financial Summary'!O6"})))
test("G a sheet-level supporting anchor (Financial Summary) accepts the TTM total cell", anc(Rv, "valuation_metric") == "GOLD_EQUIVALENT_ANCHOR" and st(Rv, "concepts", "valuation_metric") == "CORRECT")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"].pop("enterprise_value")))
test("G a role the chain does not state is OMITTED (and counts as missed, not wrong)", st(Rv, "concepts", "enterprise_value") == "OMITTED" and Rv["summary"]["material_gold_items_missed"] == 1)
_, Rv, _ = gscore(mut(GCLEAN, lambda d: (d["chain"].pop("enterprise_value"), d["provenance"].append({"id": "E9", "from": {"source": CO, "cell": "'Valuation Summary'!F11"},
                                                                                                  "to": {"source": CO, "cell": "'Valuation Summary'!F14"}, "class": "direct_formula_link", "what": "x"}))))
test("G a role missing from the chain but present in an edge is NEEDS_ANALYST, not omitted", st(Rv, "concepts", "enterprise_value") == "NEEDS_ANALYST")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"]["metric_window"].update(first="2025-08")))
test("G a wrong TTM month is WRONG", st(Rv, "concepts", "metric_period") == "WRONG")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"]["bridge"][0].update(cell="'Valuation Summary'!F13")))
test("G bridge cells that do not match Gold's cash and debt make the bridge WRONG (checked in the workbooks)", st(Rv, "concepts", "equity_bridge") == "WRONG")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"].__setitem__("waterfall", [{"cell": "'LP Report'!I13", "what": "x"}])))
test("G a waterfall reported on the wrong sheet is WRONG", st(Rv, "concepts", "ownership_or_waterfall") == "WRONG")
GX = mut(GOLD0, lambda g: g["answers"].__setitem__("reporting_currency", {"answer": "USD", "primary_anchor": {"ref": "W1:'Valuation Summary'!F8", "shows": "x"}}))
_, Rv, _ = gscore(GCLEAN, GX)
test("G a Gold concept the extraction schema has no slot for is NOT_EXPRESSIBLE_IN_SCHEMA: reported, not an omission, not a false claim",
     st(Rv, "concepts", "reporting_currency") == "NOT_EXPRESSIBLE_IN_SCHEMA" and Rv["summary"]["not_expressible"] == 1 and Rv["summary"]["material_gold_items_missed"] == 0
     and Rv["summary"]["core_total"] == 10)

# --- relationship
_, Rv, _ = gscore(mut(GCLEAN, lambda d: (d["discrepancies"].clear(), d["downstream"].append({"id": "E11", "from": {"source": CO, "cell": "'Valuation Summary'!F26"},
                                                                                              "to": {"source": FU, "cell": "'Fund Summary'!H10"}, "class": "pasted_exact_match", "what": "x"}))))
test("G claiming the company and fund values MATCH when Gold says DIFFERENT is WRONG (a false claim)", st(Rv, "concepts", "company_to_fund_relationship") == "WRONG" and Rv["summary"]["false_material_claims"] >= 1)
_, Rv, _ = gscore(mut(GCLEAN, lambda d: (d["discrepancies"].clear(), d.update(open_questions=[]))))
test("G silence about the relationship is OMITTED, and the discrepancy is OMITTED too", st(Rv, "concepts", "company_to_fund_relationship") == "OMITTED" and st(Rv, "discrepancies", "MD1", "id") == "OMITTED")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["discrepancies"].clear()))
test("G a difference mentioned only in an open question (not recorded as a discrepancy) is NEEDS_ANALYST, not falsely omitted", st(Rv, "discrepancies", "MD1", "id") == "NEEDS_ANALYST")

# --- known rivals
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"].__setitem__("enterprise_value", {"source": CO, "cell": "'Valuation Summary'!H11"})))
test("G choosing the rival (prior-period EV, H11) as the enterprise value: WRONG answer and SELECTED_RIVAL, both counted as false claims",
     st(Rv, "concepts", "enterprise_value") == "WRONG" and st(Rv, "rivals", "R1", "id") == "SELECTED_RIVAL" and Rv["summary"]["false_material_claims"] == 2 and Rv["summary"]["rivals_handled"] == 0)
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["rejected"].clear()))
test("G a rival the extraction neither uses nor rejects is NOT_ADDRESSED (an omission, not an error)", st(Rv, "rivals", "R1", "id") == "NOT_ADDRESSED" and Rv["summary"]["material_gold_items_missed"] == 1 and Rv["summary"]["false_material_claims"] == 0)
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["rejected"][0].update(what="a different wording entirely", why="no keywords from Gold appear here")))
test("G rewording the rejection does not break the match: the cell decides (keywords are only a fallback)", st(Rv, "rivals", "R1", "id") == "CORRECTLY_REJECTED")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["rejected"][0].update(cell="'Valuation Summary'!H12")))
test("G a rejection that names another cell is not matched by wording alone unless the keywords are all there", st(Rv, "rivals", "R1", "id") == "CORRECTLY_REJECTED")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["rejected"][0].update(cell="'Valuation Summary'!H12", what="some other cell", why="no")))
test("G ...and with neither the cell nor the keywords it is not matched", st(Rv, "rivals", "R1", "id") == "NOT_ADDRESSED")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: (d["rejected"].clear(), d["provenance"].append({"id": "E8", "from": {"source": CO, "cell": "'Valuation Summary'!H8"}, "to": {"source": CO, "cell": "'Valuation Summary'!H11"},
                                                                                       "class": "direct_formula_link", "what": "x"}))))
test("G a rival that appears only as an edge endpoint is NEEDS_ANALYST: seen, but not rejected", st(Rv, "rivals", "R1", "id") == "NEEDS_ANALYST")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["rejected"][0].update(cell="'Valuation Summary'!H12", what="x", why="y", gold_id="R1")))
test("G an explicit gold_id on an extraction item wins over cells and keywords", st(Rv, "rivals", "R1", "id") == "CORRECTLY_REJECTED")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["rejected"][0].update(id="R1", cell="'Valuation Summary'!H12", what="x", why="y")))
test("G an extraction item's ordinary id is NOT a Gold id (E1/D1 would collide)", st(Rv, "rivals", "R1", "id") == "NOT_ADDRESSED")
_, Rv, _ = gscore(GCLEAN, mut(GOLD0, lambda g: [g["known_rivals"][0].pop(k) for k in ("id", "cells", "keywords")]))
test("G a rival with no matching metadata is UNSCORED: not right, not wrong", Rv["rivals"][0]["status"] == "UNSCORED" and Rv["summary"]["unscored"] == 1 and Rv["summary"]["rivals_total"] == 0)

# --- material discrepancies
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["discrepancies"][0].update(difference=0)))
test("G Gold says the difference is REAL and the extraction treats it as nil: MISINTERPRETED (a false claim)", st(Rv, "discrepancies", "MD1", "id") == "MISINTERPRETED" and Rv["summary"]["false_material_claims"] == 1)
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["discrepancies"][0].update(a={"source": CO, "cell": "'LP Report'!I13"})))
test("G the discrepancy is still FOUND when the extraction compares an equivalent copy of the company value (LP Report!I13)", st(Rv, "discrepancies", "MD1", "id") == "FOUND")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["discrepancies"][0].update(a={"source": CO, "cell": "'Valuation Summary'!F8"}, what="x", driver="y")))
test("G a discrepancy about other cells is not matched", st(Rv, "discrepancies", "MD1", "id") in ("OMITTED", "NEEDS_ANALYST"))
GR = mut(GOLD0, lambda g: g["material_discrepancies"][0].update(status="ROUNDING"))
_, Rv, _ = gscore(GCLEAN, GR)
test("G Gold says ROUNDING but the extraction shows a real 1,000,000: NEEDS_ANALYST (cannot be decided deterministically), not wrong", st(Rv, "discrepancies", "MD1", "id") == "NEEDS_ANALYST")
GU = mut(GOLD0, lambda g: g["material_discrepancies"][0].update(status="UNRESOLVED"))
_, Rv, _ = gscore(GFLAW, GU)
test("G Gold says the cause is UNRESOLVED and the extraction calls it explained: MISINTERPRETED", st(Rv, "discrepancies", "MD1", "id") == "MISINTERPRETED")
_, Rv, _ = gscore(GCLEAN, mut(GOLD0, lambda g: [g["material_discrepancies"][0].pop(k) for k in ("id", "cells", "keywords")]))
test("G a discrepancy with no matching metadata is UNSCORED", Rv["discrepancies"][0]["status"] == "UNSCORED")

# --- human judgments
_, Rv, _ = gscore(GCLEAN)
test("G a judgment raised as an open question (matched by the cells written in its text) is PRESERVED_UNRESOLVED", st(Rv, "judgments", "HJ1", "id") == "PRESERVED_UNRESOLVED")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d.update(open_questions=["Is the 19.5m or the 20.5m the number the board signed off?"])), mut(GOLD0, lambda g: g["human_judgments"][0].update(keywords=["signed off"])))
test("G ...or by keywords when no cell is written (the fallback)", st(Rv, "judgments", "HJ1", "id") == "PRESERVED_UNRESOLVED")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d.update(open_questions=["Please confirm what the board signed off."])))
test("G a question with neither the cells nor the keywords is not matched, and the issue counts as omitted", st(Rv, "judgments", "HJ1", "id") in ("OMITTED", "UNSUPPORTED_CONCLUSION") or st(Rv, "judgments", "HJ1", "id") == "NEEDS_ANALYST")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: (d.update(open_questions=[]), d["discrepancies"].clear())))
test("G an issue the extraction never raises is OMITTED (reported separately from the false claim)", st(Rv, "judgments", "HJ1", "id") == "OMITTED" and Rv["summary"]["false_material_claims"] == 0)
_, Rv, _ = gscore(mut(GFLAW, lambda d: d.update(open_questions=["Which carrying value was formally approved: Valuation Summary!F26 or Fund Summary!H10?"])))
test("G an open question beside an 'explained' discrepancy: preserved wins (no false accusation)", st(Rv, "judgments", "HJ1", "id") == "PRESERVED_UNRESOLVED")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d.update(how_it_works=d["how_it_works"] + " Which carrying value was formally approved is unclear.", open_questions=[])))
test("G a mention in the narrative only is NEEDS_ANALYST", st(Rv, "judgments", "HJ1", "id") == "NEEDS_ANALYST")
_, Rv, _ = gscore(GCLEAN, mut(GOLD0, lambda g: [g["human_judgments"][0].pop(k) for k in ("id", "cells", "keywords")]))
test("G a judgment with no matching metadata is UNSCORED", Rv["judgments"][0]["status"] == "UNSCORED")

# --- source identity: an integrity error, never a valuation error
Xs = mut(GCLEAN, lambda d: next(s for s in d["sources"] if s["id"] == FU).update(sha256="f" * 64))
out5, Rv, _ = gscore(Xs, wb=False)
test("G an extraction that recorded another SHA-256 for the fund workbook is an INTEGRITY failure, not a wrong answer",
     "Integrity: FAILED (1)" in out5 and Rv["summary"]["wrong_material_answers"] == 0 and st(Rv, "concepts", "fund_reported_value") == "NEEDS_ANALYST")
Xm = mut(GCLEAN, lambda d: d.update(sources=[s for s in d["sources"] if s["id"] != FU]))
out6, Rv, _ = gscore(Xm, wb=False)
test("G a Gold file missing from the extraction's sources is an INTEGRITY failure", "Integrity: FAILED" in out6 and st(Rv, "concepts", "fund_reported_value") == "NEEDS_ANALYST" and Rv["summary"]["wrong_material_answers"] == 0)
Xn = mut(GCLEAN, lambda d: [s.pop("sha256") for s in d["sources"]])
_, Rv, _ = gscore(Xn)
test("G an extraction without SHA-256s is mapped by file name, and the supplied files' SHA-256 is still checked", Rv["integrity"] == [] and Rv["summary"]["core_correct"] == 10)

# --- gold accuracy and workbook verification stay separate
vp = os.path.join(TMP, "verif.json")
json.dump({"status": "CONTRADICTED"}, open(vp, "w"))
out7, Rv, _ = gscore(GFLAW, extra=["--verification", vp])
test("G the verifier's status is shown beside the Gold score, never merged into it: CONTRADICTED changes no Gold count",
     "Workbook verification (separate, not part of the Gold score): CONTRADICTED" in out7 and Rv["summary"] == R["summary"])
Xw = mut(GCLEAN, lambda d: d["chain"].__setitem__("enterprise_value", {"source": CO, "cell": "'Valuation Summary'!H11"}))
out8, Rv, _ = gscore(Xw)
test("G a wrong answer under a VERIFIED stamp is still scored wrong (the two questions are independent)", "Workbook verification (separate, not part of the Gold score): VERIFIED" in out8 and Rv["summary"]["wrong_material_answers"] == 1)
o, _, rc = gscore(GCLEAN, mut(GOLD0, lambda g: g["certification"].update(material_truth_complete="NO")))
test("G an invalid key scores nothing (exit 2)", rc == 2 and "nothing was scored" in o and "GOLD SCORE" not in o, o)
test("G the report file carries the summary the printed lines come from",
     all(k in R["summary"] for k in ("core_correct", "core_total", "false_material_claims", "material_gold_items_missed", "needs_analyst", "unscored", "not_expressible")))



# ---------------- G2: the first real Gold run's failures (metric value, bad reference, runtime file names, binary identity, owners) ----------------
import zipfile, importlib
sys.path.insert(0, HERE)
GVm = importlib.import_module("gold_validate")
RTDIR = os.path.join(TMP, "runtime")
os.makedirs(RTDIR, exist_ok=True)
RT = []
for i, f in enumerate(GWB):                                              # what a chat attachment looks like: underscores and a hash suffix
    base = os.path.basename(f)[:-5].replace(" ", "_")
    dst = os.path.join(RTDIR, f"{base}-{'1a2b3c4d5e'[:8 - (i % 2)]}.xlsx")
    shutil.copy(f, dst)
    RT.append(dst)


def vrun(gold, wb, extra=()):
    gp = os.path.join(TMP, f"v{len(os.listdir(TMP))}.json")
    json.dump(gold, open(gp, "w"))
    return grun("gold_validate.py", ["--gold", gp, *extra] + (["--workbooks", *wb] if wb else []))


def srun(gold, wb, X=GCLEAN, extra=()):
    gp, xp, op = (os.path.join(TMP, f"s{len(os.listdir(TMP))}{n}.json") for n in ("k", "x", "o"))
    json.dump(gold, open(gp, "w"))
    json.dump(X, open(xp, "w"))
    rc, out = grun("gold_score.py", ["--gold", gp, "--extraction", xp, "--out", op, "--workbooks", *wb, *extra])
    return out, (json.load(open(op)) if os.path.exists(op) else None), rc


G_NAMES = mut(GOLD0, lambda g: g["source_files"].update({k: v["file"] for k, v in g["source_files"].items()}))     # no sha256 anywhere

# 1. valuation_metric.value is optional
G_NOVAL = mut(GOLD0, lambda g: g["answers"]["valuation_metric"].pop("value"))
rc, o = gvalid(G_NOVAL)
test("G2 valuation_metric.answer is required but .value is optional: a key without it is valid", rc == 0 and "GOLD VALID" in o, o)
_, Rv, _ = gscore(GCLEAN, G_NOVAL)
test("G2 ...and scores exactly as before (the applied multiple is never borrowed as the metric's value)", Rv["summary"] == R2["summary"])
rc, o = gvalid(mut(GOLD0, lambda g: g["answers"]["valuation_metric"].update(value="lots")))
test("G2 a metric value that is present must still be numeric", rc == 1 and "valuation_metric.value must be a number when given" in o, o)
rc, o = gvalid(mut(GOLD0, lambda g: g["answers"]["valuation_metric"].update(value=8.0)))
test("G2 a metric value that disagrees with its anchor is caught against the workbook", rc == 1 and "holds 2500000" in o, o)
rc, o = gvalid(mut(GOLD0, lambda g: g["answers"]["valuation_metric"].pop("answer")))
test("G2 the metric's semantic answer is required", rc == 1 and "valuation_metric.answer is missing" in o, o)

# 2. the malformed reference
bad = mut(GOLD0, lambda g: g["answers"]["company_value"]["supporting_anchors"][1].update(ref="W1:'LP Report!'I13"))
rc, o = gvalid(bad)
test("G2 W1:'LP Report!'I13 is refused as a Gold-authoring error, with a hint where the ! belongs", rc == 1 and "[GOLD_METADATA]" in o and "after the closing quote" in o, o)
rc, o = gvalid(mut(bad, lambda g: g["answers"]["company_value"]["supporting_anchors"][1].update(ref="W1:'LP Report'!I13")))
test("G2 the corrected reference W1:'LP Report'!I13 validates", rc == 0, o)

# 3. runtime-renamed files
test("G2 name normalisation: spaces/underscores, punctuation, case, extension and a runtime hash suffix do not matter",
     GVm.canon_name("Company Valuation.xlsx") == GVm.canon_name("Company_Valuation-1a2b3c4d.xlsx") == GVm.canon_name("company_valuation-1A2B3C4D (1).xlsx") == "company valuation"
     and GVm.canon_name("Fund Q - Valuation Summary_Jun 30, 2026.xlsx") == GVm.canon_name("Fund_Q_-_Valuation_Summary_Jun_30__2026-ab12cd34.xlsx"))
test("G2 ...but a date at the end of a name is not mistaken for a hash suffix", GVm.canon_name("Valuation-20260630.xlsx") == "valuation 20260630" and GVm.canon_name("Valuation 2026.xlsx") == "valuation 2026")
rc, o = vrun(GOLD0, RT)
test("G2 Gold WITH SHA-256: runtime-renamed attachments are matched by SHA-256 (the canonical name is only a description)", rc == 0 and o.count("matched by sha256") == 5, o)
rc, o = vrun(G_NAMES, RT)
test("G2 Gold WITHOUT SHA-256: the normalised name matches, and the output says how the match was made", rc == 0 and o.count("matched by file name (normalised)") >= 5 and "WARN" in o, o)
rc, o = vrun(G_NAMES, RT[:4])
test("G2 a workbook neither SHA-256 nor name identifies fails source integrity (BENCHMARK_INTEGRITY), never a guess", rc == 1 and "[BENCHMARK_INTEGRITY]" in o and "not among the supplied workbooks" in o, o)
dup = os.path.join(RTDIR, "Meridian_-_Q2_2026_Company_Valuation-ffffffff.xlsx")
shutil.copy(GWB[0], dup)
rc, o = vrun(G_NAMES, RT + [dup])
test("G2 two supplied files with the same normalised name are ambiguous: fail, do not pick one", rc == 1 and "ambiguous" in o, o)
rc, o = vrun(GOLD0, RT + [dup])
test("G2 ...unless Gold carries a SHA-256, which settles it", rc == 0, o)
os.remove(dup)

# 4. binary identity: the frozen binaries come from the supplied files, never from the extraction
def resave(path, dst):
    """the same workbook content saved again: identical parts, other zip timestamps -> another SHA-256 (what a re-download does)"""
    with zipfile.ZipFile(path) as zi, zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zo:
        for n in zi.namelist():
            zinfo = zipfile.ZipInfo(n, date_time=(2026, 10, 1, 8, 30, 0))
            zinfo.compress_type = zipfile.ZIP_DEFLATED
            zo.writestr(zinfo, zi.read(n))


RS = os.path.join(TMP, "resaved")
os.makedirs(RS, exist_ok=True)
RSF = []
for f in GWB:
    d = os.path.join(RS, os.path.basename(f))
    resave(f, d)
    RSF.append(d)
test("G2 a re-saved workbook really is another binary with the same content", all(hashlib.sha256(open(a, "rb").read()).hexdigest() != hashlib.sha256(open(b, "rb").read()).hexdigest() for a, b in zip(GWB, RSF)))
man = os.path.join(TMP, "man.json")
json.dump(G_NAMES, open(os.path.join(TMP, "gnames.json"), "w"))
rc, o = grun("gold_sources.py", ["--gold", os.path.join(TMP, "gnames.json"), "--workbooks", *RSF, "--extraction", os.path.join(REF, "G1", "extraction-clean.json"), "--out", man])
M = json.load(open(man))["source_files"]
test("G2 gold_sources freezes the SHA-256 of the SUPPLIED binaries (not the extraction's), and reports each against the historical extraction as DIFFERENT_BINARY",
     rc == 0 and M["W1"]["sha256"] == hashlib.sha256(open(next(f for f in RSF if "Company Valuation" in f), "rb").read()).hexdigest()
     and "SOURCE INTEGRITY (historical extraction vs these binaries): MISMATCH" in o and o.count("DIFFERENT_BINARY") >= 5, o[-700:])
rc, o = grun("gold_sources.py", ["--gold", GOLDKEY, "--workbooks", *GWB, "--extraction", os.path.join(REF, "G1", "extraction-clean.json")])
test("G2 the same binaries as the historical extraction: SAME_BINARY for all five", rc == 0 and "SOURCE INTEGRITY (historical extraction vs these binaries): SAME_BINARY (5/5)" in o and o.count("SAME_BINARY |") == 5, o[-500:])
out, Rv, rc = srun(G_NAMES, RSF)
test("G2 scoring a historical extraction against re-saved binaries reports SOURCE INTEGRITY: MISMATCH, classes it BENCHMARK_INTEGRITY, and marks no answer wrong",
     "SOURCE INTEGRITY: MISMATCH" in out and Rv["summary"]["wrong_material_answers"] == 0 and Rv["summary"]["core_correct"] < 10 and "BENCHMARK_INTEGRITY" in out
     and any(x["class"] == "BENCHMARK_INTEGRITY" for x in Rv["concepts"]), out[:900])
out, Rv, rc = srun(G_NAMES, RSF, extra=["--allow-different-binary"])
test("G2 a different saved copy is scored only in the explicit mode, and the report says so", "explicitly allowed" in out and Rv["summary"]["core_correct"] == 10 and "DIFFERENT_BINARY" in out, out[:700])
rc, o = vrun(GOLD0, RSF)
test("G2 Gold that carries a SHA-256 refuses a re-saved binary (BENCHMARK_INTEGRITY), however equal it looks", rc == 1 and "not the frozen binary" in o and "[BENCHMARK_INTEGRITY]" in o, o)
rc, o = vrun(G_NAMES, RSF, ["--sources", man])
test("G2 a frozen manifest supplies the SHA-256s Gold lacks: the re-saved set validates against its own frozen fingerprints", rc == 0 and "matched by sha256" in o, o)
bm = os.path.join(TMP, "badman.json")
json.dump({"source_files": {"W1": {"file": "x", "sha256": "0" * 64}}}, open(bm, "w"))
rc, o = vrun(GOLD0, GWB, ["--sources", bm])
test("G2 a manifest that contradicts Gold's own SHA-256 is an integrity error", rc == 1 and "[BENCHMARK_INTEGRITY]" in o and "differs from Gold" in o, o)
mo = os.path.join(TMP, "scoreman.json")
rc, o = grun("gold_sources.py", ["--gold", os.path.join(TMP, "gnames.json"), "--workbooks", *GWB, "--out", mo])
out, Rv, rc = srun(G_NAMES, GWB, extra=["--sources", mo])
test("G2 gold_score takes the manifest too: the original binaries score SAME_BINARY against the historical extraction", "SOURCE INTEGRITY: SAME_BINARY (5/5)" in out and Rv["summary"]["core_correct"] == 10, out[:300])
out, Rv, rc = srun(G_NAMES, RT)
test("G2 runtime-renamed attachments of the original binaries still score SAME_BINARY (a hash difference, not a name difference, is what matters)",
     "SOURCE INTEGRITY: SAME_BINARY (5/5)" in out and Rv["summary"]["core_correct"] == 10, out[:400])
Xnosha = mut(GCLEAN, lambda d: [x.pop("sha256") for x in d["sources"]])
out, Rv, rc = srun(GOLD0, GWB, Xnosha)
test("G2 an extraction that recorded no SHA-256s is NOT_COMPARABLE (tied by name only), stated rather than assumed identical", "SOURCE INTEGRITY: NOT COMPARABLE" in out and Rv["integrity"] == [], out[:300])
Xrt = mut(GCLEAN, lambda d: [x.update(file=os.path.basename(RT[i])) for i, x in enumerate(sorted(d["sources"], key=lambda z: z["file"]))])
out, Rv, rc = srun(G_NAMES, GWB, Xrt)
test("G2 an extraction that recorded runtime-renamed file names still maps to Gold's canonical names", Rv["summary"]["core_correct"] == 10 and Rv["integrity"] == [], out[:300])

# 5. matching metadata: gold_id alias, helper
G_GID = mut(GOLD0, lambda g: [it.update(gold_id=it.pop("id")) for k in ("known_rivals", "material_discrepancies", "human_judgments") for it in g[k]])
_, Rv, _ = gscore(GCLEAN, G_GID)
test("G2 Gold items may carry gold_id instead of id (same scoring)", Rv["summary"] == R2["summary"])
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["rejected"][0].update(cell="'Valuation Summary'!H12", what="x", why="y", gold_id="R1")), G_GID)
test("G2 an extraction item's gold_id matches a Gold item's gold_id first", st(Rv, "rivals", "R1", "id") == "CORRECTLY_REJECTED")
gfree = os.path.join(TMP, "gfree.json")
G_FREE = mut(GOLD0, lambda g: ([[it.pop(f, None) for f in ("id", "cells", "keywords")] for k in ("known_rivals", "material_discrepancies", "human_judgments") for it in g[k]],
                               g["known_rivals"][0].update(candidate="Valuation Summary!H11 (prior-period enterprise value)"),
                               g["material_discrepancies"][0].update(item="W1:'Valuation Summary'!F26 vs W2:'Fund Summary'!H10 differ")))
json.dump(G_FREE, open(gfree, "w"))
before = hashlib.sha256(open(gfree, "rb").read()).hexdigest()
rc, o = grun("gold_suggest.py", ["--gold", gfree, "--workbooks", *GWB])
test("G2 gold_suggest lists what each rival, discrepancy and judgment needs, using only cells already written in the key's own text",
     rc == 0 and "MATCHING METADATA NEEDED: 3 item(s)" in o and "W1:'Valuation Summary'!H11" in o and "W1:'Valuation Summary'!F26; W2:'Fund Summary'!H10" in o
     and 'id: "R1"' in o and 'id: "HJ1"' in o, o)
test("G2 ...invents no keywords, no answers, and never changes the key", "keywords: your decision" in o and hashlib.sha256(open(gfree, "rb").read()).hexdigest() == before)
rc, o = grun("gold_suggest.py", ["--gold", GOLDKEY])
test("G2 a key whose items all carry matching metadata needs nothing", rc == 0 and "MATCHING METADATA NEEDED: none" in o, o)
_, Rv, _ = gscore(GCLEAN, G_FREE)
test("G2 an un-upgraded free-text key scores its rivals, discrepancies and judgments UNSCORED (never guessed), class UNSCORED_MATCHING_METADATA, and never counts them wrong",
     Rv["summary"]["unscored"] == 3 and all(x["class"] == "UNSCORED_MATCHING_METADATA" for k in ("rivals", "discrepancies", "judgments") for x in Rv[k])
     and Rv["summary"]["false_material_claims"] == 0 and Rv["summary"]["core_correct"] == 10)

# 6. owner classes and the three separate dimensions
test("G2 every non-success carries its owner: omission -> EXTRACTION_COVERAGE, false claim -> EXTRACTION_REASONING",
     next(x["class"] for x in R["concepts"] if x["concept"] == "ownership_or_waterfall") == "EXTRACTION_COVERAGE" and R["judgments"][0]["class"] == "EXTRACTION_REASONING")
_, Rv, _ = gscore(GCLEAN, GX)
test("G2 ...a concept the schema cannot hold -> EXTRACTION_SCHEMA", next(x["class"] for x in Rv["concepts"] if x["concept"] == "reporting_currency") == "EXTRACTION_SCHEMA")
test("G2 invalid-Gold and integrity errors name their owner ([GOLD_METADATA], [BENCHMARK_INTEGRITY])",
     "[GOLD_METADATA]" in gvalid(mut(GOLD0, lambda g: g.update(schema="x")))[1] and "[BENCHMARK_INTEGRITY]" in vrun(G_NAMES, RT[:4])[1])
vp2 = os.path.join(TMP, "verif2.json")
json.dump({"status": "CONTRADICTED"}, open(vp2, "w"))
out, Rv, _ = gscore(GCLEAN, extra=["--verification", vp2])
test("G2 the three dimensions stay separate in one report: Gold validation PASS, Gold accuracy, and a CONTRADICTED verifier tagged DETERMINISTIC_VERIFIER",
     "GOLD VALIDATION: PASS" in out and "Core semantic answers: 10/10" in out and "CONTRADICTED [DETERMINISTIC_VERIFIER]" in out and Rv["summary"] == R2["summary"])
out, _, _ = gscore(GCLEAN)
test("G2 a status recorded inside extraction.json is labelled as recorded, not as a fresh verification", "as recorded in extraction.json" in out)
o, _, rc = gscore(GCLEAN, mut(GOLD0, lambda g: g.update(schema="x")))
test("G2 an invalid key prints GOLD VALIDATION: FAIL and scores nothing", rc == 2 and "GOLD VALIDATION: FAIL" in o and "Core semantic answers" not in o)
test("G2 UNRESOLVED is a legitimate certified answer: the G1 key has an UNRESOLVED judgment and certification YES and validates", gvalid(GOLD0)[0] == 0)


# ---------------- G3: real Excel (sheet names with stray whitespace, rounded presentation cells, ranges, whole sheets) and the run gates ----------------
import re as _re


def edit_workbook(src, dst, rename=None, cells=None):
    """rewrite a workbook's OOXML: rename={old: new} worksheet names; cells={(sheet, 'F9'): value} saved values (formulas kept)."""
    with zipfile.ZipFile(src) as zi:
        parts = {n: zi.read(n) for n in zi.namelist()}
    wbx = parts["xl/workbook.xml"].decode("utf-8")
    order = _re.findall(r'<sheet name="([^"]*)"', wbx)
    for (sheet, cell), val in (cells or {}).items():
        part = f"xl/worksheets/sheet{order.index(sheet) + 1}.xml"
        x = parts[part].decode("utf-8")
        pat = _re.compile(r'(<c r="' + cell + r'"[^>]*>(?:<f[^>]*>[^<]*</f>)?<v>)[^<]*(</v>)')
        assert pat.search(x), (sheet, cell)
        parts[part] = pat.sub(lambda m: m.group(1) + str(val) + m.group(2), x, count=1).encode("utf-8")
    for old, new in (rename or {}).items():
        assert f'name="{old}"' in wbx
        wbx = wbx.replace(f'name="{old}"', f'name="{new}"')
    parts["xl/workbook.xml"] = wbx.encode("utf-8")
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zo:
        for n, b in parts.items():
            zi_ = zipfile.ZipInfo(n, date_time=(2026, 7, 15, 9, 0, 0))
            zi_.compress_type = zipfile.ZIP_DEFLATED
            zo.writestr(zi_, b)


def variant(name, **kw):
    d = os.path.join(TMP, "var-" + name)
    os.makedirs(d, exist_ok=True)
    out = []
    for f in GWB:
        dst = os.path.join(d, os.path.basename(f))
        if "Company Valuation" in f:
            edit_workbook(f, dst, **kw)
        else:
            shutil.copy(f, dst)
        out.append(dst)
    return out


# 1. sheet names: the workbook's ACTUAL OOXML names decide
WS = variant("trail", rename={"Valuation Summary": "Valuation Summary "})
rc, o = vrun(G_NAMES, WS)
test("G3 Gold writes 'Valuation Summary'; the workbook's raw sheet is 'Valuation Summary ' (trailing space): it validates, and the report shows both and the method",
     rc == 0 and "Gold wrote 'Valuation Summary' | workbook raw sheet 'Valuation Summary ' | NORMALIZED_WHITESPACE" in o, o)
rc, o = vrun(G_NAMES, GWB)
test("G3 a sheet that matches exactly is reported EXACT", rc == 0 and "| EXACT" in o and "NORMALIZED" not in o, o)
rc, o = vrun(mut(G_NAMES, lambda g: g["answers"]["enterprise_value"]["primary_anchor"].update(ref="W1:'Valuation Summary '!F11")), GWB)
test("G3 ...and Gold is never asked to encode an invisible space: a Gold sheet name with a space the workbook lacks still resolves (by normalisation, uniquely)", rc == 0, o)
WA = variant("ambig", rename={"Valuation Summary": "Valuation  Summary", "Cap Table": "Valuation Summary "})
rc, o = vrun(G_NAMES, WA)
test("G3 two worksheets that normalise to the same name, neither exact, are ambiguous: BENCHMARK_INTEGRITY, never a guess", rc == 1 and "ambiguous sheet" in o and "[BENCHMARK_INTEGRITY]" in o, o)
WE = variant("exact", rename={"Cap Table": "Valuation Summary "})
rc, o = vrun(G_NAMES, WE)
test("G3 an exact raw match wins even when another sheet would also normalise to it", "ambiguous sheet" not in o.split("Valuation Summary")[0] and "Valuation Summary' | EXACT" in o, o)
rc, o = vrun(mut(G_NAMES, lambda g: g["answers"]["enterprise_value"]["primary_anchor"].update(ref="W1:'Valuation Summary Prior'!F11")), GWB)
test("G3 a sheet that does not exist is a Gold error", rc == 1 and "has no sheet" in o and "[GOLD_METADATA]" in o, o)
test("G3 sheet normalisation is conservative: it keeps meaningful internal characters ('Valuation Summary-Prior Period' is not 'Valuation Summary')",
     GVm.skey(" Valuation\u00a0 Summary ") == "valuation summary" and GVm.skey("Valuation Summary-Prior Period") != GVm.skey("Valuation Summary") and GVm.skey("R&amp;D") == "r&d")
Xsp = mut(GCLEAN, lambda d: [d["chain"][k].update(cell=d["chain"][k]["cell"].replace("'Valuation Summary'", "'Valuation Summary '")) for k in ("valuation_metric", "selected_multiple", "enterprise_value", "equity_value", "value_to_xpv")])
_, Rv, _ = gscore(Xsp)
test("G3 an extraction that wrote 'Valuation Summary ' (its reader's trailing space) still matches Gold's 'Valuation Summary': the score is unchanged", Rv["summary"] == R2["summary"] and anc(Rv, "enterprise_value") == "EXACT_ANCHOR")
_, Rv, _ = gscore(GCLEAN, mut(GOLD0, lambda g: g["answers"]["enterprise_value"]["primary_anchor"].update(ref="W1:'Valuation Summary '!F11")))
test("G3 ...and the other way round (Gold carries the space, the extraction does not)", anc(Rv, "enterprise_value") == "EXACT_ANCHOR")

# 2. supporting anchors: corroboration, not numeric identity; primary stays strict
WR = variant("round", cells={("Valuation Summary", "F9"): "8.1394", ("Comparables", "C11"): "8.14"})
GM = mut(G_NAMES, lambda g: g["answers"]["applied_multiple"].update(answer=8.1394))
rc, o = vrun(GM, WR)
test("G3 a full-precision multiple (primary 8.1394) with a supporting cell showing 8.14 validates: a rounded display is not a Gold contradiction", rc == 0 and "ERROR" not in o, o)
GM2 = mut(GM, lambda g: g["answers"]["applied_multiple"]["supporting_anchors"][0].update(shows="Presentation cell, rounded to two decimals"))
rc, o = vrun(GM2, WR)
test("G3 ...also when `shows` says it is rounded", rc == 0 and "WARN: answers.applied_multiple" not in o, o)
rc, o = vrun(mut(GM, lambda g: g["answers"]["applied_multiple"].update(answer=8.14)), WR)
test("G3 the PRIMARY anchor stays strict: Gold's rounded 8.14 against a primary holding 8.1394 is refused", rc == 1 and "a primary anchor must reproduce Gold's answer" in o, o)
rc, o = vrun(mut(GM, lambda g: g["answers"]["applied_multiple"]["supporting_anchors"][0].update(support="exact")), WR)
test("G3 a supporting anchor DECLARED exact that is only a rounding is refused (the analyst's own claim)", rc == 1 and "stated as exact via support" in o, o)
rc, o = vrun(mut(GM, lambda g: g["answers"]["applied_multiple"]["supporting_anchors"][0].update(support="rounded", decimals=2)), WR)
test("G3 declared rounded to 2 decimals validates", rc == 0, o)
rc, o = vrun(mut(GM, lambda g: g["answers"]["applied_multiple"]["supporting_anchors"][0].update(support="rounded", decimals=3)), WR)
test("G3 declared rounded to 3 decimals does not fit 8.14", rc == 1 and "does not fit" in o, o)
WU = variant("unrel", cells={("Comparables", "C11"): "9.99"})
rc, o = vrun(G_NAMES, WU)
test("G3 an unrelated number on a supporting anchor only warns (it must exist; it does not invalidate Gold)", rc == 0 and "WARN: answers.applied_multiple: supporting anchor" in o, o)
rc, o = vrun(mut(G_NAMES, lambda g: g["answers"]["applied_multiple"]["supporting_anchors"][0].update(support="context")), WU)
test("G3 a supporting anchor declared `context` is never compared to a number", rc == 0 and "WARN: answers.applied_multiple" not in o, o)
rc, o = vrun(mut(G_NAMES, lambda g: g["answers"]["company_value"]["primary_anchor"].update(ref="W1:'LP Report'!I13")), GWB)
test("G3 a primary anchor that is a scaled copy must say so: implicit scaling is no longer accepted for a primary", rc == 1 and "declare" in o, o)
rc, o = vrun(mut(G_NAMES, lambda g: g["answers"]["company_value"]["primary_anchor"].update(ref="W1:'LP Report'!I13", support="scaled", factor=0.001)), GWB)
test("G3 ...with an explicit scaling it validates", rc == 0, o)
rc, o = vrun(mut(G_NAMES, lambda g: g["answers"]["company_value"]["primary_anchor"].update(support="rounded")), GWB)
test("G3 a primary anchor cannot be 'rounded' or 'context'", rc == 1 and "exact or explicitly scaled" in o, o)

# 3. whole-sheet anchors
rc, o = vrun(mut(G_NAMES, lambda g: g["answers"]["valuation_metric"]["supporting_anchors"][0].update(ref="W1:'LP Report'")), GWB)
test("G3 a whole-sheet anchor only has to exist: 'LP Report' corroborates the metric though no value there equals it", rc == 0 and "ERROR" not in o, o)
rc, o = vrun(mut(G_NAMES, lambda g: g["answers"]["valuation_metric"]["supporting_anchors"][0].update(ref="W1:'No Such Sheet'")), GWB)
test("G3 ...and a whole-sheet anchor on a missing sheet is refused", rc == 1 and "has no sheet" in o, o)
out, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"].__setitem__("valuation_metric", {"source": CO, "cell": "'LP Report'!I13"})), mut(G_NAMES, lambda g: g["answers"]["valuation_metric"]["supporting_anchors"][0].update(ref="W1:'LP Report'")))
test("G3 a whole-sheet supporting anchor accepts a cell on that sheet only as contextual support: never exact provenance (exact anchors drop from 7 to 6), and a value that is not the metric is flagged",
     anc(Rv, "valuation_metric") == "GOLD_EQUIVALENT_ANCHOR" and Rv["summary"]["anchors_exact"] == 6 and "VALUE DISAGREES" in out, out[:400])

# 4. rivals given as ranges (a prior-period block)
GRG = mut(GOLD0, lambda g: g["known_rivals"][0].update(cells=["W1:'Valuation Summary'!H8:H11"]))
_, Rv, _ = gscore(GCLEAN, GRG)
test("G3 a rival written as a range matches a rejection of any cell inside it", st(Rv, "rivals", "R1", "id") == "CORRECTLY_REJECTED")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["chain"].__setitem__("selected_multiple", {"source": CO, "cell": "'Valuation Summary'!H9"})), GRG)
test("G3 ...and choosing any cell inside the rival's range as an answer is SELECTED_RIVAL", st(Rv, "rivals", "R1", "id") == "SELECTED_RIVAL")
rc, o = vrun(mut(GOLD0, lambda g: g["known_rivals"][0].update(cells=["W1:'Valuation Summary'!K40:K45"])), GWB)
test("G3 a range with nothing in it is a Gold error", rc == 1 and "holds no values" in o, o)

# 5. scoring with rounded presentation cells: not flagged as a value disagreement
Xr = mut(GCLEAN, lambda d: ([x.pop("sha256") for x in d["sources"]], d["chain"].__setitem__("selected_multiple", {"source": CO, "cell": "'Comparables'!C11"})))
out, Rv, rc = srun(GM, WR, Xr)
test("G3 an extraction that picked the supporting cell showing 8.14 for a full-precision 8.1394 is Gold-equivalent and not flagged VALUE DISAGREES",
     anc(Rv, "applied_multiple") == "GOLD_EQUIVALENT_ANCHOR" and "VALUE DISAGREES" not in out and st(Rv, "concepts", "applied_multiple") == "CORRECT", out[-900:])

# 6. source identity rows, the gates, the helper
out, Rv, _ = srun(G_NAMES, RT)
test("G3 SOURCE IDENTITY shows, per workbook, the filename match (EXACT / NORMALIZED) and the binary status", "SOURCE IDENTITY" in out and out.count("filename NORMALIZED + SAME_BINARY") == 5, out[:900])
out, Rv, _ = srun(G_NAMES, GWB)
test("G3 ...EXACT when the supplied names are Gold's names", out.count("filename EXACT + SAME_BINARY") == 5)
rc, o = grun("gold_run.py", ["--gold", GOLDKEY, "--workbooks", *GWB, "--extraction", os.path.join(REF, "G1", "extraction-flawed.json")])
order = [o.index(f"== GATE {n}") for n in ("1:", "2:", "3 and 4:", "5:", "6 and 7:")]
test("G3 gold_run runs the gates in order (suggest, enrich, sources + compare, validate, score) and ends with a Gold score", rc == 0 and order == sorted(order) and "Core semantic answers: 9/10" in o, o[:300])
bad_run = os.path.join(TMP, "badrun.json")
json.dump(mut(GOLD0, lambda g: g["certification"].update(material_truth_complete="NO")), open(bad_run, "w"))
rc, o = grun("gold_run.py", ["--gold", bad_run, "--workbooks", *GWB, "--extraction", os.path.join(REF, "G1", "extraction-flawed.json")])
test("G3 gold_run scores only if the key is valid: otherwise it stops at gate 5 and no score is printed", rc == 2 and "STOPPED at gate 5" in o and "GOLD SCORE" not in o, o[-300:])
rc, o = grun("gold_run.py", ["--gold", GOLDKEY, "--workbooks", *GWB[:3], "--extraction", os.path.join(REF, "G1", "extraction-flawed.json")])
test("G3 gold_run stops at gate 3 when the benchmark workbooks cannot be identified", rc == 1 and "STOPPED at gate 3" in o and "GOLD SCORE" not in o, o[-300:])
rc, o = grun("gold_run.py", ["--gold", gfree, "--workbooks", *GWB, "--extraction", os.path.join(REF, "G1", "extraction-flawed.json"), "--require-metadata"])
test("G3 --require-metadata stops at gate 2 while any rival, discrepancy or judgment lacks matching metadata", rc == 3 and "STOPPED at gate 2" in o and "GOLD SCORE" not in o, o[-300:])
rc, o = grun("gold_run.py", ["--gold", gfree, "--workbooks", *GWB, "--extraction", os.path.join(REF, "G1", "extraction-flawed.json")])
test("G3 without that flag the un-enriched items are scored UNSCORED, and the run says so at gate 2", rc == 0 and "3 item(s) still lack id, cells and keywords" in o and "Needs analyst / unscored: 0 / 3" in o, o[:200])
rc, o = grun("gold_suggest.py", ["--gold", gfree, "--workbooks", *GWB])
test("G3 gold_suggest lists the anchors already in the key as candidates for `cells` (as written, matched to nothing)", "ANCHORS ALREADY IN THIS KEY" in o and "company_value: W1:'Cap Table'!M38" in o and "fund_reported_value: W2:'Fund Summary'!H10" in o, o[-500:])

# ---------------- G4 (build 13.1): upload numbers on file names; MATCH after a declared rounding ----------------
RTD = os.path.join(TMP, "runtime-digits")
os.makedirs(RTD, exist_ok=True)
RTN = []
for i, f in enumerate(GWB):                                              # a chat upload that appends an all-digit number: Book_Name-11963866.xlsx
    dst = os.path.join(RTD, os.path.basename(f)[:-5].replace(" ", "_") + f"-{11963866 + i}.xlsx")
    shutil.copy(f, dst)
    RTN.append(dst)
test("G4 an all-digit upload number is matched only as a second try, and says so",
     GVm.name_tier("2026_Consolidated_Master_File_0326_V2-11963866.xlsx", "2026 Consolidated Master File_0326 V2.xlsx") == "file name (normalised, upload number removed)"
     and GVm.name_tier("Company_Valuation-1a2b3c4d.xlsx", "Company Valuation.xlsx") == "file name (normalised)"
     and GVm.name_tier("Valuation-20260630.xlsx", "Valuation-20260630.xlsx") == "file name (normalised)"
     and GVm.name_tier("Other Book-11963866.xlsx", "Company Valuation.xlsx") is None)
rc, o = vrun(G_NAMES, RTN)
test("G4 Gold WITHOUT SHA-256 validates against attachments with all-digit upload numbers, and prints how each was matched",
     rc == 0 and o.count("upload number removed") >= 5, o[-600:])
DUP = os.path.join(RTD, "dup")
os.makedirs(DUP, exist_ok=True)
two = [shutil.copy(RTN[0], os.path.join(DUP, os.path.basename(RTN[0]).replace("-11963866", "-22222222")))]
rc, o = vrun(G_NAMES, RTN + two)
test("G4 two attachments that differ only by upload number are ambiguous and fail (never a guess)", rc == 1 and "ambiguous" in o, o[-600:])
out, Rv, rc = srun(G_NAMES, RTN)
test("G4 ...and the extraction scores exactly as with the original names", Rv is not None and Rv["summary"]["core_correct"] == 10 and Rv["integrity"] == [], out[:300])

GR = mut(GOLD0, lambda g: (g["answers"]["company_value"].update(answer=19500000.4), g["answers"]["fund_reported_value"].update(answer=19500000),
                           g["answers"].__setitem__("company_to_fund_relationship", {"answer": "MATCH", "relationship_basis": {"type": "ROUNDING", "decimals": 0},
                                                                                    "explanation": "the fund reports the company value in whole dollars"})))
rc, o = gvalid(mut(GR, lambda g: g["answers"]["company_to_fund_relationship"].pop("relationship_basis")), wb=False)
test("G4 without a declared basis, MATCH still needs equal values (build 13.0 behaviour kept)", rc == 1 and "relationship is MATCH but the company and fund values differ" in o, o[-400:])
rc, o = gvalid(GR, wb=False)
test("G4 with relationship_basis ROUNDING to 0 decimals, 19,500,000.4 vs 19,500,000 is a valid MATCH (and the output says why)", rc == 0 and "under the declared rounding to 0 decimal(s)" in o, o[-400:])
rc, o = gvalid(mut(GR, lambda g: g["answers"]["company_value"].update(answer=19500000.6)), wb=False)
test("G4 ...but a value that does not round to the fund value is still an error (no general tolerance)", rc == 1 and "does not round to the fund value" in o, o[-400:])
rc, o = gvalid(mut(GR, lambda g: g["answers"]["company_to_fund_relationship"].update(relationship_basis={"type": "NEAR", "decimals": 0})), wb=False)
test("G4 a malformed relationship_basis is refused", rc == 1 and "relationship_basis must be" in o, o[-400:])
EDGE = {"id": "E99", "from": {"source": CO, "cell": "'Valuation Summary'!F26"}, "to": {"source": FU, "cell": "'Fund Summary'!H10"},
        "class": "rounded_match", "relation": {"op": "round", "decimals": 0}, "what": "fund shows the company value in whole dollars"}
_, Rv, _ = gscore(mut(GCLEAN, lambda d: (d.__setitem__("discrepancies", []), d.setdefault("downstream", []).append(EDGE))), GR, wb=False)
test("G4 an extraction edge (rounded_match) between the company and fund values scores CORRECT against MATCH-after-rounding",
     Rv is not None and st(Rv, "concepts", "company_to_fund_relationship") == "CORRECT")
_, Rv, _ = gscore(mut(GCLEAN, lambda d: d["discrepancies"][0].update(status="explained")), GR, wb=False)
test("G4 an 'explained' difference against MATCH-after-rounding is NEEDS_ANALYST (it may be that rounding), not WRONG",
     Rv is not None and st(Rv, "concepts", "company_to_fund_relationship") == "NEEDS_ANALYST")
_, Rv, _ = gscore(GCLEAN, GR, wb=False)
test("G4 an UNRESOLVED difference against MATCH-after-rounding is still WRONG", Rv is not None and st(Rv, "concepts", "company_to_fund_relationship") == "WRONG")

shutil.rmtree(TMP, ignore_errors=True)
print(f"TESTS: {'PASS' if all(results) else 'FAIL'} ({sum(results)}/{len(results)})")
sys.exit(0 if all(results) else 1)
