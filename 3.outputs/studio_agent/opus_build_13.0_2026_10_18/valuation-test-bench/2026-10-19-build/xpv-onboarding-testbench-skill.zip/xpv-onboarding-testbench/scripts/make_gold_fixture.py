# make_gold_fixture.py (build 13.0, test bench) - writes the synthetic Gold-mode fixture "G1" (a made-up company, "Meridian Test Co"):
#   trial/set-G1/*.xlsx                      five small workbooks (raw Office Open XML with saved values, byte-for-byte deterministic)
#   trial/keys/gold-G1.json                  a gold-mvp/3 key (TEST BENCH ONLY - keys never go to the extractor or reviewer agents)
#   trial/reference/G1/extraction-flawed.json   a schema-3 extraction with two deliberate flaws (one omission, one false material claim)
#   trial/reference/G1/extraction-clean.json    the same extraction without the flaws
# Every value is invented. The workbooks carry the structure Gold mode has to understand:
#   Cap Table!M38 (investor proceeds by waterfall) -> Valuation Summary!F26 (formula link) -> LP Report!I13 (scaled copy, $000s)
#   Valuation Summary!H11 = prior-period EV (a rival for F11); Fund Summary!H10 differs from the company value (reason unresolved)
#   LP Report!I20 is a typed copy of I13 with the same number and NO formula (a decoy: numeric equality is not a link)
# Usage: python make_gold_fixture.py --out trial     (writes set-G1/, keys/gold-G1.json, reference/G1/)
import argparse, datetime, hashlib, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import make_fixture_set as MF  # noqa: E402

FILES = {"W1": "Meridian - Q2 2026 Company Valuation.xlsx", "W2": "Fund - Q2 2026 Valuation Summary.xlsx",
         "W3": "Meridian - June 2026 TTM Pro Forma.xlsx", "W4": "Meridian - Monthly Financials 2026.xlsx",
         "W5": "Meridian - Monthly Summary 2026.xlsx"}
VALUES = {"valuation_method": "EV/EBITDA", "metric": "Adjusted Pro Forma TTM EBITDA", "metric_value": 2_500_000, "multiple": 8.0,
          "enterprise_value": 20_000_000, "cash": 2_000_000, "debt": 1_000_000, "equity_value": 21_000_000,
          "investor_value": 19_500_000, "fund_reported_value": 20_500_000}
MONTHLY = [208_000] * 11 + [212_000]                                  # sums to exactly 2,500,000
assert sum(MONTHLY) == VALUES["metric_value"]


def build_workbooks(out):
    os.makedirs(out, exist_ok=True)
    months = MF.month_ends(2025, 7, 12)                              # Jul-25 .. Jun-26

    b = MF.Book()                                                      # W1 company valuation
    fs = b.sheet("Financial Summary")
    fs.put("A1", "Meridian Test Co - financial summary (TTM pro forma)"); fs.put("B4", "Month")
    for i, d in enumerate(months):
        fs.put(f"{MF.col(3 + i)}4", d, s=1)
    fs.put("O4", "TTM"); fs.put("B6", "Adjusted pro forma EBITDA"); fs.row(6, 3, MONTHLY)
    fs.put("O6", sum(MONTHLY), "SUM(C6:N6)", 2)
    cp = b.sheet("Comparables")
    cp.put("A1", "Comparable companies - EV/EBITDA"); cp.put("B4", "Peer")
    for i, (n, m) in enumerate([("Peer A", 7.0), ("Peer B", 7.5), ("Peer C", 8.0), ("Peer D", 8.5), ("Peer E", 9.0)]):
        cp.put(f"B{5 + i}", n); cp.put(f"C{5 + i}", m, s=3)
    cp.put("B11", "Median"); cp.put("C11", 8.0, "MEDIAN(C5:C9)", 3)
    vs = b.sheet("Valuation Summary")
    vs.put("A1", "Meridian Test Co - valuation summary"); vs.put("F6", "Q2 2026"); vs.put("H6", "Q1 2026 (prior period)")
    vs.put("B8", "Adjusted Pro Forma TTM EBITDA"); vs.put("F8", 2_500_000, "'Financial Summary'!O6", 2); vs.put("H8", 2_400_000, None, 2)
    vs.put("B9", "Applied EV/EBITDA multiple"); vs.put("F9", 8.0, "Comparables!C11", 3); vs.put("H9", 7.5, None, 3)
    vs.put("B11", "Enterprise value"); vs.put("F11", 20_000_000, "F8*F9", 2); vs.put("H11", 18_000_000, "H8*H9", 2)
    vs.put("B12", "Cash"); vs.put("F12", 2_000_000, None, 2)
    vs.put("B13", "Debt"); vs.put("F13", 1_000_000, None, 2)
    vs.put("B14", "Total equity value"); vs.put("F14", 21_000_000, "F11+F12-F13", 2)
    vs.put("B26", "Value to investor (carrying value)"); vs.put("F26", 19_500_000, "'Cap Table'!M38", 2)
    ct = b.sheet("Cap Table")
    ct.put("A1", "Cap table and waterfall"); ct.put("L31", "Calculation")
    ct.put("B32", "Total equity value"); ct.put("M32", 21_000_000, "'Valuation Summary'!F14", 2)
    ct.put("B33", "Investor liquidation preference"); ct.put("M33", 15_000_000, None, 2)
    ct.put("B34", "Remainder after preference"); ct.put("M34", 6_000_000, "M32-M33", 2)
    ct.put("B35", "Investor participation share"); ct.put("M35", 0.75, None, 4)
    ct.put("B36", "Participation proceeds"); ct.put("M36", 4_500_000, "M34*M35", 2)
    ct.put("B37", "Preference paid"); ct.put("M37", 15_000_000, "MIN(M33,M32)", 2)
    ct.put("B38", "Investor proceeds (waterfall)"); ct.put("M38", 19_500_000, "M37+M36", 2)
    lp = b.sheet("LP Report")
    lp.put("A1", "LP report - carrying values ($000s)"); lp.put("B13", "Meridian Test Co carrying value ($000s)")
    lp.put("I13", 19_500, "'Valuation Summary'!F26/1000", 2)
    lp.put("B20", "Draft carrying value ($000s, typed copy of I13 - no formula)"); lp.put("I20", 19_500, None, 2)     # decoy: same number, no link
    b.save(os.path.join(out, FILES["W1"]))

    b = MF.Book()                                                      # W2 fund valuation summary
    fu = b.sheet("Fund Summary")
    fu.put("A1", "Fund - valuation summary, 30 June 2026"); fu.put("H5", "Carrying value (USD)")
    fu.put("B10", "Meridian Test Co"); fu.put("H10", 20_500_000, None, 2)
    fu.put("B11", "Other holdings"); fu.put("H11", 7_000_000, None, 2)
    b.save(os.path.join(out, FILES["W2"]))

    b = MF.Book()                                                      # W3 TTM pro forma
    t = b.sheet("TTM Pro Forma")
    t.put("A1", "Meridian Test Co - TTM pro forma, June 2026"); t.put("B4", "Month")
    for i, d in enumerate(months):
        t.put(f"{MF.col(3 + i)}4", d, s=1)
    t.put("O4", "TTM"); t.put("B6", "Adjusted pro forma EBITDA"); t.row(6, 3, MONTHLY); t.put("O6", sum(MONTHLY), "SUM(C6:N6)", 2)
    b.save(os.path.join(out, FILES["W3"]))

    b = MF.Book()                                                      # W4 monthly financials
    m = b.sheet("Monthly P&L")
    m.put("A1", "Meridian Test Co - monthly financials"); m.put("B4", "Month")
    for i, d in enumerate(months):
        m.put(f"{MF.col(3 + i)}4", d, s=1)
    m.put("B6", "Reported EBITDA"); m.row(6, 3, [v - 8_000 for v in MONTHLY])
    m.put("B7", "Add-backs"); m.row(7, 3, [8_000] * 12)
    m.put("B8", "Adjusted EBITDA"); m.row(8, 3, MONTHLY, f=MF.SI(), shared="C6+C7")
    b.save(os.path.join(out, FILES["W4"]))

    b = MF.Book()                                                      # W5 monthly summary
    s = b.sheet("Summary")
    s.put("A1", "Meridian Test Co - monthly summary (prepared by the fund manager)"); s.put("B4", "TTM adjusted EBITDA"); s.put("C4", 2_500_000, None, 2)
    b.save(os.path.join(out, FILES["W5"]))


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def gold(shas):
    """the gold-mvp/3 key. source_files carries a sha256 for each file (optional in the schema)."""
    sf = {k: {"file": v, "sha256": shas[k]} for k, v in FILES.items()}
    a = lambda ref, shows: {"ref": ref, "shows": shows}
    return {
        "schema": "gold-mvp/3", "case_id": "G1", "quarter_end": "2026-06-30", "source_files": sf,
        "answers": {
            "valuation_method": {"answer": "EV/EBITDA", "implementation": "Selected EV/EBITDA multiple x Adjusted Pro Forma TTM EBITDA = Implied Enterprise Value",
                                 "primary_anchor": a("W1:'Valuation Summary'!F11", "Method actually used by valuation (EV = metric x multiple)"),
                                 "supporting_anchors": [a("W1:'Comparables'", "EV/EBITDA comparable multiples")]},
            "valuation_metric": {"answer": "Adjusted Pro Forma TTM EBITDA", "value": VALUES["metric_value"],
                                 "primary_anchor": a("W1:'Valuation Summary'!F8", "Metric actually used in valuation"),
                                 "supporting_anchors": [a("W1:'Financial Summary'", "TTM/pro forma financial presentation")]},
            "metric_period": {"answer": "TTM Jul 2025 - Jun 2026", "first_month": "2025-07", "last_month": "2026-06",
                              "primary_anchor": a("W1:'Financial Summary'", "Relevant TTM/pro forma period")},
            "applied_multiple": {"answer": VALUES["multiple"], "primary_anchor": a("W1:'Valuation Summary'!F9", "Multiple actually applied"),
                                 "supporting_anchors": [a("W1:'Comparables'!C11", "Source comparable calculation (median)")]},
            "enterprise_value": {"answer": VALUES["enterprise_value"], "calculation": "Applied multiple x valuation metric",
                                 "primary_anchor": a("W1:'Valuation Summary'!F11", "Enterprise value")},
            "equity_bridge": {"answer": "Enterprise Value + Cash - Debt = Total Equity", "cash": VALUES["cash"], "debt": VALUES["debt"],
                              "equity_value": VALUES["equity_value"],
                              "primary_anchor": a("W1:'Valuation Summary'!F14", "Equity value after bridge")},
            "ownership_or_waterfall": {"answer": "Total equity is split by a participating waterfall: the investor takes its liquidation preference first, "
                                                 "then 75% of the remainder.",
                                       "keywords": ["waterfall"],
                                       "primary_anchor": a("W1:'Cap Table'", "Ownership/waterfall calculation")},
            "company_value": {"answer": VALUES["investor_value"],
                              "primary_anchor": a("W1:'Cap Table'!M38", "Investor proceeds calculated by waterfall"),
                              "supporting_anchors": [a("W1:'Valuation Summary'!F26", "Linked investor-value summary"),
                                                     a("W1:'LP Report'!I13", "Investor-facing carrying-value copy ($000s)")]},
            "fund_reported_value": {"answer": VALUES["fund_reported_value"],
                                    "primary_anchor": a("W2:'Fund Summary'!H10", "Quarter-end carrying value reported by fund")},
            "company_to_fund_relationship": {"answer": "DIFFERENT", "company_value": VALUES["investor_value"],
                                             "fund_reported_value": VALUES["fund_reported_value"],
                                             "explanation": "The fund reports 1,000,000 more than the company waterfall; nothing supplied explains why."},
        },
        "known_rivals": [{"id": "R1", "candidate": "Valuation Summary H11 (prior-period enterprise value)", "looks_like": "current enterprise value (F11)",
                          "why_not_the_answer": "H11 sits in the Q1 2026 column; it is the prior quarter's EV.",
                          "cells": ["W1:'Valuation Summary'!H11"], "keywords": ["prior period", "enterprise value"]}],
        "material_discrepancies": [{"id": "MD1", "item": "Company investor value (19.5m) differs from the fund-reported value (20.5m)", "status": "REAL",
                                    "explanation": "Real difference of 1,000,000; the reason is unresolved from the supplied workbooks.",
                                    "cells": ["W1:'Valuation Summary'!F26", "W2:'Fund Summary'!H10"], "keywords": ["fund value", "company value"]}],
        "human_judgments": [{"id": "HJ1", "question": "Which carrying value was formally approved?", "answer": "UNRESOLVED",
                             "cells": ["W1:'Valuation Summary'!F26", "W2:'Fund Summary'!H10"], "keywords": ["approved carrying value"]}],
        "certification": {"material_truth_complete": "YES", "missing": [], "analyst_note": "synthetic test fixture - invented values"},
    }


def extraction(shas, flawed):
    src = lambda i, role, why: {"id": i, "file": FILES[i], "sha256": shas[i], "role": role, "period": "Q2 2026", "contributes": why, "reason": why}
    c = lambda s, cell, what, **k: {"source": s, "cell": cell, "what": what, **k}
    chain = {
        "source": "W1", "method": "EV/EBITDA multiple",
        "valuation_metric": c("W1", "'Valuation Summary'!F8", "TTM pro forma adjusted EBITDA", units="$"),
        "selected_multiple": c("W1", "'Valuation Summary'!F9", "applied EV/EBITDA multiple", units="x"),
        "enterprise_value": c("W1", "'Valuation Summary'!F11", "F8 x F9", units="$"),
        "bridge": [{"cell": "'Valuation Summary'!F12", "sign": 1, "what": "cash"}, {"cell": "'Valuation Summary'!F13", "sign": -1, "what": "debt"}],
        "equity_value": c("W1", "'Valuation Summary'!F14", "EV + cash - debt", units="$"),
        "value_to_xpv": c("W1", "'Valuation Summary'!F26", "investor value carried on the valuation summary", units="$"),
        "metric_window": {"source": "W1", "cells": "'Financial Summary'!C6:N6", "first": "2025-07", "last": "2026-06", "link": "arithmetic_transformation"},
        "fund_cell": {"source": "W2", "cell": "'Fund Summary'!H10", "units": "$"},
    }
    if not flawed:                                                    # the clean version also reports the waterfall
        chain["waterfall"] = [c("W1", "'Cap Table'!M32", "equity value (link)"), c("W1", "'Cap Table'!M33", "investor liquidation preference"),
                              c("W1", "'Cap Table'!M36", "participation proceeds"), c("W1", "'Cap Table'!M38", "investor proceeds")]
    doc = {
        "schema": "13.0.0", "company": "Meridian Test Co", "quarter_end": "2026-06-30", "status": "final",
        "sources": [src("W1", "company_valuation", "the valuation chain"), src("W2", "fund_valuation", "the value the fund reports"),
                    src("W3", "pro_forma", "TTM pro forma"), src("W4", "monthly_financials", "monthly figures"), src("W5", "monthly_summary", "monthly summary")],
        "external": [], "chain": chain,
        "provenance": [{"id": "E1", "from": {"source": "W3", "cell": "'TTM Pro Forma'!C6:N6"}, "to": {"source": "W1", "cell": "'Financial Summary'!C6:N6"},
                        "class": "pasted_exact_match", "what": "monthly adjusted EBITDA pasted into the financial summary"}],
        "downstream": [{"id": "E10", "from": {"source": "W1", "cell": "'Valuation Summary'!F26"}, "to": {"source": "W1", "cell": "'LP Report'!I13"},
                        "class": "direct_formula_link", "relation": {"op": "scale", "factor": 0.001}, "what": "LP report copy in $000s"}],
        "discrepancies": [{"id": "D1", "a": {"source": "W1", "cell": "'Valuation Summary'!F26"}, "b": {"source": "W2", "cell": "'Fund Summary'!H10"},
                           "difference": 1_000_000, "what": "the fund reports 1,000,000 more than the company value", "status": "unresolved", "material": True}],
        "rejected": [{"source": "W1", "cell": "'Valuation Summary'!H11", "what": "prior-period enterprise value (Q1 2026 column)",
                      "why": "it is the prior quarter's figure, not the current enterprise value"}],
        "inputs": [], "open_questions": [], "deferred": [],
        "how_it_works": "Draft: TTM pro forma adjusted EBITDA x 8.0 gives EV of 20m; plus cash, less debt gives equity of 21m; the investor's value is 19.5m. "
                        "The fund reports 20.5m.",
        "verification": {"status": "VERIFIED"},
    }
    if flawed:
        # flaw 1 (omission): no waterfall is reported anywhere (no Cap Table cell appears in the extraction)
        # flaw 2 (false material claim): the discrepancy is closed as 'explained' with an approval claim Gold says the workbooks cannot support
        doc["discrepancies"][0].update(status="explained", driver="the fund applies the approved carrying value, so the company figure is stale",
                                       driver_cells=[{"source": "W2", "cell": "'Fund Summary'!H10"}])
    else:
        doc["open_questions"] = ["Which carrying value was formally approved: the company's 19.5m (Valuation Summary!F26) or the fund's 20.5m (Fund Summary!H10)?"]
        doc["discrepancies"][0]["driver"] = "not explained by the supplied workbooks"
    return doc


def ext_ids():
    """the ids the evidence reader gives these files: W1..W5 in file-name order, NOT Gold's W1..W5 (so source mapping is really tested)."""
    order = sorted(FILES, key=lambda k: FILES[k].lower())
    return {k: f"W{i + 1}" for i, k in enumerate(order)}


def remap(x, ids):
    if isinstance(x, dict):
        return {k: (ids[v] if k in ("source", "id") and isinstance(v, str) and v in ids and (k == "source" or "file" in x) else remap(v, ids))
                for k, v in x.items()}
    if isinstance(x, list):
        return [remap(v, ids) for v in x]
    return x


def build(out):
    sd = os.path.join(out, "set-G1")
    build_workbooks(sd)
    shas = {k: sha(os.path.join(sd, v)) for k, v in FILES.items()}
    os.makedirs(os.path.join(out, "keys"), exist_ok=True)
    os.makedirs(os.path.join(out, "reference", "G1"), exist_ok=True)
    json.dump(gold(shas), open(os.path.join(out, "keys", "gold-G1.json"), "w"), indent=1)
    for name, flawed in (("extraction-flawed", True), ("extraction-clean", False)):
        json.dump(remap(extraction(shas, flawed), ext_ids()), open(os.path.join(out, "reference", "G1", name + ".json"), "w"), indent=1)
    return shas


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="trial")
    a = ap.parse_args()
    for k, v in build(a.out).items():
        print(f"{k} {FILES[k]} sha256 {v}")
