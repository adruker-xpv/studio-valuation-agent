---
name: xpv-onboarding-testbench
description: Test bench for XPV onboarding (build 13.1) - runs the onboarding test suite, scores an extraction or a blind review against a synthetic trial key or an analyst's blind answers, validates and scores against a gold-mvp/3 Gold key (Gold mode), holds the synthetic trial workbooks (including the five-workbook set T1) and regenerates them. Use for "run the onboarding tests", "score ...", "validate the Gold key", "Gold-score ...", "list the trial workbooks", "rebuild trial set T1". For a separate test agent only - never attach it to the extractor or reviewer agents, because it contains answer keys and reference answers.
---

# Onboarding test bench (build 13.1)

## Legend
Trial workbook = a made-up company and fund workbook in `trial/workbook-NN`; trial set T1 = five made-up workbooks in `trial/set-T1`
(management accounts with an inflated used range, a TTM pro forma, an XPV monthly summary, a company valuation that links to an
unsupplied "v3" file, and a fund summary that reports a different value); key = its answer key in `trial/keys/`; reference = a
hand-checked answer in `trial/reference/` used only by the tests; analyst answers = `templates/analyst_answers_template.xlsx`, filled in
by an analyst from a real workbook before seeing any agent output; TTM = trailing twelve months.

## What the user says, and what you run
| The user says | Run |
|---|---|
| "Run the onboarding tests" | `python scripts/test_onboarding.py` - expected last line `TESTS: PASS (N/N)` (253/253 in this build) |
| "List the trial workbooks" | list `trial/workbook-*` and `trial/set-T1` with the company named in each; never open `trial/keys/` or `trial/reference/` |
| "Score <file> for trial workbook NN" (an extraction.json or reviewer_blind.json the user uploads) | `python scripts/score.py --key trial/keys/key-NN.json --extraction "<file>"` (add `--verification "<verification.json>"` if given) |
| "Score <file> for trial set T1" | `python scripts/score.py --key trial/keys/key-T1.json --extraction "<file>"` |
| "Score <file> against the analyst's answers <answers.xlsx>" | `python scripts/score.py --key "<answers.xlsx>" --extraction "<file>"` |
| "Rebuild trial set T1" | `python scripts/make_fixture_set.py --out trial/set-T1` (byte-for-byte identical; the tests depend on it) |
| "Give me the analyst answer form" | offer `templates/analyst_answers_template.xlsx` |
| "Validate the Gold key <gold.json>" (add "with the workbooks" when the frozen .xlsx files are attached) | `python scripts/gold_validate.py --gold "<gold.json>" [--workbooks <the .xlsx files>]` |
| "Gold-score <extraction.json> against <gold.json>" (add the workbooks if attached; add `--verification "<verification.json>"` if given) | `python scripts/gold_validate.py ...` first, then `python scripts/gold_score.py [--sources source_manifest.json] [--allow-different-binary] --gold "<gold.json>" --extraction "<file>" [--workbooks <the .xlsx files>] [--verification "<verification.json>"] --out gold_report.json`; post both outputs |
| "Run the Gold gates" / "Run the real Gold benchmark" | `python scripts/gold_run.py --gold "<gold.json>" --workbooks <the .xlsx files> --extraction "<extraction.json>" [--verification "<verification.json>"] [--require-metadata] [--out gold_report.json]`: gate 1 gold_suggest, gate 2 enrichment (human), gates 3-4 gold_sources, gate 5 gold_validate, gates 6-7 gold_score; stops at the first failed gate and scores only a valid key |
| "Freeze the benchmark's source identities" / "Do the extraction's hashes match these workbooks?" | `python scripts/gold_sources.py --gold "<gold.json>" --workbooks <the .xlsx files> [--extraction "<extraction.json>"] [--out source_manifest.json]` (fingerprints come only from the supplied files) |
| "What matching metadata does the Gold key need?" | `python scripts/gold_suggest.py --gold "<gold.json>" [--workbooks <the .xlsx files>]` (read-only; the analyst adds what they approve) |
| "Run Gold mode on the synthetic case G1" | `python scripts/gold_score.py --gold trial/keys/gold-G1.json --extraction trial/reference/G1/extraction-flawed.json --workbooks trial/set-G1/*.xlsx` (expect `Core semantic answers: 9/10`, `False material claims: 1`, `Material Gold items omitted: 1`) |
| "Rebuild the Gold fixture G1" | `python scripts/make_gold_fixture.py --out trial` (byte-for-byte identical; the tests depend on it) |
| "Give me the Gold key form" | offer `templates/gold-mvp-3.template.json` (refused by the validator until every placeholder is replaced and certification is YES) |

Post the printed lines unchanged. Never show a key's, a Gold key's or a reference's contents (the printed score lines are not the key). Trial workbooks 52 and 94 and trial set T1 are the ones
for agent trials; the others have references used by the tests.

## Gold mode (gold-mvp/3)
**What it measures.** GOLD ACCURACY: did the extraction discover and interpret the material truth an analyst wrote down? It is separate from
WORKBOOK VERIFICATION (are its checkable claims supported by the workbooks?). Both are printed; they are never merged, and the verifier's status
changes no Gold count. The legacy `score.py` (nine fixed items) is untouched.

**Rules.** Native (the key is never translated to the older key format). Deterministic: no LLM judge, no free-text similarity. A Gold key that
fails `gold_validate.py` (schema, certification YES, no FILL_IN or `<...>` placeholders, source ids and references well formed, fields typed, with the workbooks: source
identity, anchor cells, numbers) is never scored.

**Legend.** Concept = one entry under `answers`. Anchor = the workbook location that represents a concept: `primary_anchor` (best), `supporting_anchors`
(Gold-authorized equivalent representations; not extra answers). Whole-sheet anchor = `W1:'Cap Table'` with no cell. Pure copy = a formula that only
copies one cell: `=A1`, `=A1*0.001`, `=A1/1000`, `=-A1`, `=ROUND(A1,0)`; never a sum, product of two cells or any other function.

| Section | Statuses |
|---|---|
| Core concepts | CORRECT, WRONG, OMITTED (the schema could say it, the extraction did not), NOT_EXPRESSIBLE_IN_SCHEMA (the schema has no slot: reported so the schema can change; never counted as an omission), NEEDS_ANALYST (cannot be decided deterministically) |
| Anchor of a concept | EXACT_ANCHOR (Gold's primary), GOLD_EQUIVALENT_ANCHOR (Gold lists it as supporting), VERIFIED_LINKED_EQUIVALENT (a chain of pure copies from a Gold cell anchor, found in the supplied workbooks), WRONG_ANCHOR, MISSING; UNVERIFIED when a link check was needed and no workbooks were supplied (the concept is then NEEDS_ANALYST, never wrong); N/A when the extraction has no anchor for the concept (method, relationship) |
| Known rivals | CORRECTLY_REJECTED, SELECTED_RIVAL (used as an answer), NOT_ADDRESSED (neither used nor rejected: did not distinguish it), NEEDS_ANALYST, UNSCORED |
| Material discrepancies | FOUND, MISINTERPRETED (Gold REAL but treated as nil/immaterial; Gold UNRESOLVED but called explained), OMITTED, NEEDS_ANALYST, UNSCORED |
| Human judgments (UNRESOLVED) | PRESERVED_UNRESOLVED (raised as an open question), UNSUPPORTED_CONCLUSION (closed as an "explained" discrepancy), OMITTED, NEEDS_ANALYST, UNSCORED |

**How a cell concept is decided.** By the extraction's anchor, never by a number: a typed copy with the same value as a Gold anchor is WRONG_ANCHOR
(numeric equality is not a link). Labels and months are compared as values: the method is normalised ("EV/EBITDA" = "EV/EBITDA multiple" = "EV to
EBITDA" = "EBITDA multiple"; different methods are WRONG; ones that cannot be normalised are NEEDS_ANALYST); the TTM window as months (its anchor is
reported beside it); the waterfall by the sheet Gold names; the company-to-fund relationship from the extraction's discrepancies (DIFFERENT) and
checkable edges (MATCH). Build 13.1: when Gold's relationship is MATCH with `relationship_basis` ROUNDING (below), a checkable edge between the
company and fund values (e.g. `rounded_match`) is CORRECT, a difference the extraction calls `explained` is NEEDS_ANALYST (it may be that rounding), and an
unresolved difference is still WRONG. If a role is missing from the chain but its cell appears in an edge, or its keywords in the narrative, it is NEEDS_ANALYST,
not omitted. With workbooks, a Gold-equivalent cell whose saved value disagrees with Gold's number is flagged `VALUE DISAGREES` and the bridge cells are checked against Gold's cash and debt.

**How rivals, discrepancies and judgments are matched** (this order only): 1. explicit id: an extraction item's own `gold_id` (an ordinary
`E1`/`D1` id never counts, because it could collide); 2. the cells they reference: Gold's `cells` against the item's cells (a discrepancy's a, b and
driver cells; a rejection's cell; cell references written in a question's text, e.g. `Valuation Summary!F26`) - rivals need an exact cell, the others
accept Gold-listed or verified-linked equivalents; 3. normalised keywords (every keyword must be present as whole words; `a|b` accepts either) - a
fallback only, so rewording an extraction cannot flip a score that its cells decide; 4. otherwise NEEDS_ANALYST (seen elsewhere) or OMITTED (not
anywhere). An item whose Gold entry has no id, cells or keywords is UNSCORED, not wrong.

**Worksheet names.** A Gold reference such as `W2:'Valuation Summary'!H10` is resolved against the workbook's ACTUAL OOXML worksheet names: 1. EXACT raw
match; 2. NORMALIZED_WHITESPACE only if exact fails (reader escaping such as `&amp;` undone, non-breaking spaces read as spaces, leading/trailing whitespace trimmed,
runs of internal whitespace collapsed, case ignored as Excel does; every other character is kept, so `Valuation Summary-Prior Period` is a different sheet) and only
when exactly one worksheet matches. Several matches are an ambiguous sheet (BENCHMARK_INTEGRITY). The validator prints, per sheet, what Gold wrote, the workbook's
raw name and the method; Gold is never rewritten, and the same normalisation is applied to the extraction's references so a reader's stray space cannot split a match.

**Anchor numbers (primary strict, supporting corroborating).** A PRIMARY anchor must reproduce Gold's numeric answer (floating-point tolerance) or declare an
explicit scaling (`"support": "scaled"`, optional `factor`); implicit scaling is not accepted for a primary. A SUPPORTING anchor must exist and is compared only as
its stated support class says: `support` (optional key on the anchor: `exact`, `rounded` with optional `decimals`, `scaled` with optional `factor`, `context`), else read
from `shows` ("rounded", "2 decimals" -> rounded; "$000s", "thousands", "scaled" -> scaled); a declared or stated class that does not fit is an error; with neither, a rounded or
scaled display is recognised and an unrelated number only warns. So a full-precision 10.1394 with a supporting 10.14x is valid. Whole-sheet anchors (`W1:'Cap Table'`) only need the sheet
to exist: they are contextual support, never compared to a number, never substituted by a value found on the sheet, never exact provenance. Range cells need at least one value in them.

**Source identity (runtime renaming must not invalidate a benchmark).** Gold W1..Wn are tied to the supplied workbooks by SHA-256 when Gold (or a
`--sources` manifest) gives one; otherwise by the normalised file name, which ignores folder, extension, case, spaces vs underscores, punctuation, a browser
`(1)` and a runtime hash suffix (`Company_Valuation-1a2b3c4d.xlsx` = `Company Valuation.xlsx`), and only when exactly ONE supplied file matches: two
matches are ambiguous and fail, and a file neither identifies fails with BENCHMARK_INTEGRITY. Build 13.1: when that finds no file, a second try removes an
all-digit upload number joined by a hyphen from the SUPPLIED name only (`Book_V2-11963866.xlsx` = `Book V2.xlsx`), again only when exactly one file matches;
it is printed as `file name (normalised, upload number removed)`. A date ending such as `Valuation-20260630` is never stripped by the first try. The output says how every match was made. A SHA-256 identifies
the exact binary, so `gold_sources.py` computes the frozen fingerprints from the files actually supplied for the benchmark and never from an extraction;
retain its manifest (or write the SHA-256s into Gold) once a case is frozen.

**Source integrity against a historical extraction** (printed by `gold_score.py`, also by `gold_sources.py --extraction`): per workbook, SAME_BINARY (the
extraction recorded the frozen SHA-256), DIFFERENT_BINARY (same name, another SHA-256: a re-saved or re-downloaded copy, even if it looks equivalent),
NOT_COMPARABLE (a SHA-256 is unknown, tied by name only), MISSING. Overall `SOURCE INTEGRITY: SAME_BINARY (n/n)` or `MISMATCH`. A mismatch is
BENCHMARK_INTEGRITY, never EXTRACTION_WRONG: that workbook's concepts are not scored (NEEDS_ANALYST). Scoring against a semantically equivalent
saved copy is a separate explicit mode (`--allow-different-binary`), stated in the report; it is never the default.

**Owners.** Every failure carries its owner: GOLD_METADATA (the key is wrong or unfinished), TESTBENCH_VALIDATION (the key could not be read),
BENCHMARK_INTEGRITY (the files are not the frozen binaries), EXTRACTION_REASONING (wrong answer, selected rival, misread discrepancy, unsupported conclusion),
EXTRACTION_COVERAGE (omitted), EXTRACTION_SCHEMA (the schema has no slot), DETERMINISTIC_VERIFIER (the verifier's status is not VERIFIED),
UNSCORED_MATCHING_METADATA (a rival, discrepancy or judgment that could not be matched deterministically).

**Three separate dimensions, never collapsed:** 1. Gold validity (`GOLD VALIDATION: PASS|FAIL`); 2. Gold accuracy and coverage (the score and BREAKDOWN);
3. extraction evidence verification (the verifier's status, labelled "as recorded in extraction.json" unless a fresh `--verification` file is given).

**Certification.** `material_truth_complete: YES` means the key captures all the material truth the analyst expects the extraction to discover from
this evidence package. It does not mean every approval is known or every ambiguity resolved: UNRESOLVED is a legitimate Gold answer and a key containing
UNRESOLVED judgments can still be certified.

**Gates for a real run, in order:** 1. `gold_suggest`; 2. the analyst enriches the key; 3. `gold_sources` (freeze SHA-256s from the supplied binaries; Gold needs no hand-written
SHA-256 when the manifest provides them: Gold's semantic source identity and the manifest's binary identity stay separate); 4. compare them with the extraction's hashes; 5. `gold_validate`;
6. only if valid, `gold_score`; 7. the extraction's verification shown separately. `gold_run.py` performs them. The extraction is never modified, rerun or repaired from reviewer output, and no
Gold answer is derived from it.

**Counts.** `false_material_claims` = wrong core answers + rivals selected + unsupported conclusions + misinterpreted discrepancies.
`material_gold_items_missed` = omitted concepts + rivals not addressed + omitted discrepancies + omitted judgments. They are kept separate. Ratios count decided items only
(NEEDS_ANALYST, UNSCORED and NOT_EXPRESSIBLE are reported beside them). There is no overall weighted score.

**Optional additions to the key** (all additive; see `templates/gold-mvp-3.template.json`): `id` or `gold_id`, `cells`, `keywords` on rivals, discrepancies and
judgments (`gold_suggest.py` lists what each item needs); `sha256` per source file; `keywords` on any concept; build 13.1: `relationship_basis` on `company_to_fund_relationship`,
`{"type": "ROUNDING", "decimals": N}` (0 to 6), which makes MATCH valid when one value rounded to N decimals equals the other (e.g. 24,723,978.88 shown as
24,723,979 with N = 0). Without it, MATCH still needs equal values; there is no other tolerance. `valuation_metric.answer` is required; `valuation_metric.value`
is optional (validated against the workbook when present, never substituted from another concept). Real Gold keys are supplied at scoring time with the
frozen workbooks and the existing `extraction.json`; the extractor is not rerun.
