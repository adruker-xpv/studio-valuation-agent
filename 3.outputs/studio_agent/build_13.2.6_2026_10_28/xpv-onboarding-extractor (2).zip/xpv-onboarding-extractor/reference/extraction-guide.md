# Extraction field guide (schema 4, build 13.2.1)

## Legend
| Term | Meaning |
|---|---|
| TTM | Trailing twelve months: the 12 months ending at the quarter end |
| EV | Enterprise value |
| Chain | metric -> multiple -> EV -> equity bridge -> waterfall -> value to XPV -> fund-reported value |
| Source id | `W1`, `W2`, ... = a supplied workbook (ids follow file names, so both agents get the same ones); `X1`, ... = a file a workbook links to that was **not** supplied (only its cached values are visible) |
| Reference | `{"source": "W1", "cell": "'Sheet Name'!D8"}`; a range is `'Sheet'!H9:S9`. Quote sheet names that contain spaces or symbols |
| Edge | One claimed relationship: `from` (a reference, or a list of them) -> `to` (a reference), with an evidence class |
| Evidence class | How strongly the workbooks prove an edge (table below) |
| Stage file | One small part of the work, saved with `checkpoint.py save`, stored append-only in `checkpoints/` |
| verify | `verify.py`: tests each claim against the workbooks' own formulas and saved values |
| Proposed change | One cell next quarter's workbook touches, with a structured rule the quarterly builder (13.3) follows without new interpretation |
| Unresolved decision | A question the workbooks cannot settle; JSON field `human_judgments` |
| Memory candidate | Something company memory could keep once a person approves or corrects it in the review workbook (a fact or an assumption) |
| Revision | A past period's value that changed: both the as-reported and the later-known value, each read from a cell |
| Checking code | The scripts (`verify.py`, `proposals.py`) that re-open the workbooks and confirm a claim |
| Benchmark material | Answer keys, Gold keys, score reports, the analyst answer form, test-bench files: never a production input |

## The run folder
| Path | What | Written by |
|---|---|---|
| `checkpoints/01_sources.json` | fingerprints (SHA-256) and inventory summary of every workbook | `xlsx_evidence.py inventory` |
| `checkpoints/02_roles.json` ... `06_questions.json` | the extractor's stages (a re-save becomes `.r2.json`, `.r3.json`; the latest wins) | the agent, via `checkpoint.py save` |
| `checkpoints/07_proposals.json` | the agent's stage 7: kind changes, extra proposals, revisions, questions, memory candidates | the agent, via `checkpoint.py save` |
| `proposed_changes.json` | **what next quarter needs**: proposed changes, unresolved decisions, memory candidates - built by code from stages 1-7, deterministic | `proposals.py` (run by `checkpoint.py save --stage 7`) |
| `checkpoints/08_validation.json` | the final verify result and the fingerprint of every stage file it checked (`07_validation.json` in build 13.0 runs) | `verify.py --final` |
| `Review.xlsx` -> `review_decisions.json`, `approved_changes.json` | the person's Approve / Correct / Reject decisions, and the approved changes for 13.3 | `review_xlsx.py build` / `read` |
| company memory file (path given each time) | append-only, human-confirmed memory for the company | `memory.py apply` |
| `extraction.json` | **the primary result**, rebuilt from the checkpoints after every save | `checkpoint.py` |
| `verification.json` | every check, every edge's result | `verify.py` |
| `notes.md`, `evidence/` | working notes, inventories (`evidence/inventory/W<n>.txt`), anything forensic | agent / reader |
| `reviewer/` | the reviewer's phase 1 run: its own `checkpoints/`, `reviewer_blind.json`, `notes_blind.md` | reviewer |
| `review.json`, `checkpoints_review/`, `out/` | the reviewer's phase 2 findings and reconcile's outputs for the analyst | reviewer + `reconcile.py` |

The primary result holds conclusions only: sources and roles, the chain, key edges, discrepancies, questions, the explanation.
Sheet inventories, cell dumps and reasoning belong in `notes.md` or `evidence/`. Stage files over their size cap are refused.

## Evidence classes (one per edge)
| Class | Means | verify checks | Typical use |
|---|---|---|---|
| `direct_formula_link` | the target's formula refers to the source cell (same workbook, or a link to that exact file name) | the reference is in the formula; the numbers too if a `relation` is given | `='[2]P&L'!I9`; `=SUM(C10:N10)` with relation sum |
| `pasted_exact_match` | identical numbers, but no formula connects these two cells (typed, pasted, or a formula pointing elsewhere) | equal, and the target's formula does **not** refer to the source | add-backs typed from a schedule; a linked v3 file's cached value equal to the supplied file |
| `rounded_match` | the numbers agree only after the stated rounding/scaling, no formula connects them | `relation` op round reproduces it; no formula link | the fund types the company value in $000s |
| `arithmetic_transformation` | the target equals a stated operation on source values | the operation recomputes | the 12 months sum to the metric with no formula path |
| `contextual_support` | labels, notes or structure support it; no numeric test applies | the cells exist (never "confirmed") | a note says pro forma months come from seller financials |
| `inferred_candidate` | the most plausible reading, not yet supported | the cells exist | best guess when the budget is spent |
| `unresolved` | the supplied evidence does not establish it | the cells exist | "which version was approved" |

Numeric equality is never promoted to a link: verify contradicts a `direct_formula_link` that is not in the formula, and also a
`pasted_exact_match` that is in fact a formula link (understated evidence is still a wrong claim).

## Relations (`relation` on an edge or a discrepancy)
| op | Target equals | Example |
|---|---|---|
| `equal` (default) | the source | |
| `round` | round(source x factor, decimals) | `{"op": "round", "factor": 0.001, "decimals": 0}` for $ -> $000s |
| `scale` | source x factor | `{"op": "scale", "factor": 0.73}` |
| `sum` | the sum of every source cell (`from` is a range or a list) | `{"op": "sum"}` |
| `multiply` | source x `by` (a number or a reference) | `{"op": "multiply", "by": {"source": "W1", "cell": "Waterfall!B9"}}` |
| `negate` | minus the source | |
| `subtract` | first source minus the rest (`from` is a list) | |
Optional `tolerance` (absolute) for `equal`, `scale`, `multiply`. Ranges pair cell by cell in row order, so name ranges of the same size.

## Stage files (extractor)
**02 roles** - `produced_by`, `company` (as the fund workbook names it), `quarter_end` (YYYY-MM-DD), `sources`
(`[{id, role, period, contributes, reason}]` for **every** supplied workbook; X ids optional), `valuation_workbook`, `fund_workbook` (id or null).
Roles: `company_valuation`, `fund_valuation`, `monthly_financials`, `monthly_summary`, `pro_forma`, `other_supporting`, `not_used`,
`referenced_not_supplied`. Cap 12 KB.

**03 chain** - `chain`: `source` (the valuation workbook), `method` (EV/EBITDA multiple | EV/Revenue multiple | Blend of multiples |
Held at cost | Other), `valuation_metric`, `selected_multiple`, `enterprise_value`, `equity_value`, `value_to_xpv` (each `{cell, what, units,
currency}`, cells in the valuation workbook), optional `value_to_xpv_local`, `bridge` (`[{cell, sign, what}]`, sign as the equity formula
uses it), `waterfall` (`[{cell, what, kind}]`), `components` (blends only), `metric_window` (`{source, cells, first, last, link}`: the 12
monthly cells wherever they are, and the class of the metric's relation to them; or `{"link": "unresolved"}`), `fund_cell`
(`{source, cell, units, currency}`). Also `path` (the anchors you moved through, in order, `[{source, cell, step}]`), `direction`
(`top_down` | `bottom_up` | `other`), `downstream` (at least the edge from value_to_xpv toward the fund cell), optional `discrepancies`,
a draft `how_it_works`. Cap 30 KB.

**04 upstream** - `provenance` (edges, at most 60, material ones, one per row or range), `rejected` (`[{source, cell, what, why}]`,
material rivals only, at most 20), `deferred` (one sentence each: what you saw and did not trace, and why it is not material). Cap 60 KB.

**05 downstream** - `downstream` (edges from value_to_xpv to the fund cell and to report copies), `discrepancies`, optional `rejected`,
`deferred`. Cap 30 KB.

**06 questions** - `open_questions` (one plain sentence per decision), `inputs` (`[{source, cell, what, kind, changes, next_value_from}]`,
material typed inputs only), `how_it_works` (5-15 plain sentences, required), optional `discrepancies`, `deferred`. Cap 30 KB.

**03 chain, optional (13.2)** - `metric_window.header_cells` (and `header_source` if they are in another workbook): the 12 cells holding
the month headers, when they are not directly above (or left of) the window. verify grades the window on HEADER evidence (do the
headers read the 12 months claimed: VERIFIED_PERIOD | DIFFERENT_PERIOD | NOT_PROVEN) and VALUE evidence (do the 12 values sum to the
metric: SUMS_TO_METRIC | DOES_NOT_SUM), separately. Numbers that sum never prove a period.

**07 proposals (13.2)** - all lists optional; code has already derived the core set from the chain (see below). Cap 40 KB.
- `proposals` - `[{kind, target, basis, what}]` to change the kind of a derived item (same target) or add one for another material
  input. Kinds: `advance_period_label`, `roll_window` (no target; `basis.edge` adds a source edge), `update_from_source`
  (`basis: {"edge": "E3"}`, an edge that ends at the target), `carry_forward` (typed value kept, analyst confirms), `analyst_input`
  (no source in the files), `keep_formula`. **Never a number** (`value` is refused): code reads every value.
- `revisions` - `[{period: "YYYY-MM", as_reported_at_period: ref, later_known_value: ref, what}]`. Name the two cells only. Code
  refuses the stage unless both hold numbers, they differ, and the column header over **each** cell reads `period`. If the
  as-reported value is not in a supplied workbook, there is no revision: never reconstruct it.
- `human_judgments` - `[{question, cells_affected: [refs], suggested?, options?}]`. Ids are made by code. A proposal touching an
  affected cell is blocked until a person answers.
- `memory_candidates` - `[{kind, subject, statement, evidence: [refs]}]`, kind `source_precedence` | `adjustment_rule` |
  `method_note` | `mapping`; `subject` a short lower-case key (`precedence.cash`). Code adds the chain mappings, source mappings and
  revisions itself.

## Proposed changes (`proposed_changes.json`, schema xpv-proposed-changes/1)
Code derives one item per cell next quarter touches: the period header over the valuation column; the 12-month window (roll 3
months, filled from the edges into it); each chain cell (keep a live formula; carry the multiple forward, always confirmed);
bridge and waterfall inputs (update from the edge that feeds them, keep a formula, carry forward ownership-type inputs, or ask
the analyst); stage 6 material inputs; the agent's stage 7 items; evidenced revisions. Each item:
`{id, kind, target, what, origin (code | agent), current {value, formula}, rule, check, basis, evidence_class, verify {status, note},
always_confirm, blocked_by, correction_types, row_label}`. Ids are hashes of kind + target + rule; items are sorted; there are no
timestamps, so the same stages and workbooks give a byte-identical file. `verify.status`: `confirmed` (checking code reproduced
it), `not_checkable` (an assumption or judgment - a carried-forward multiple is never confirmed), `contradicted`.

| kind | rule | check |
|---|---|---|
| `advance_period_label` | `from_period`, `to_period`, `year_from_above` (the year is in the cell above) | the header reads `to_period` |
| `roll_window` | `window`, `months_now`, `months_next`, `shift_months` 3, `drop_first` 3, `append` 3, `fill_from` [{edge, from, class, relation, from_months}], `match_by` period_header | the window sums to the metric |
| `update_from_source` | `from`, `edge`, `class`, `relation`, `from_period`, `match_by` period_header | the edge's relation holds |
| `carry_forward` | `keep: value` | equals the current value |
| `analyst_input` | `value_from: analyst` | none |
| `keep_formula` | `keep: formula` | the chain recomputes (EV, equity) or the formula keeps a value |
| `record_revision` | `period`, `as_reported_at_period` {ref, value, file, role}, `later_known_value` {...}, `difference` | both values still read |

## Review and company memory
`review_xlsx.py build` makes `Review.xlsx` (Start here, Unresolved decisions, Proposed changes, Memory candidates, Legend).
`review_xlsx.py read` refuses edited, copied, deleted or stale rows, a missing reviewer name, a Correct without a valid correction,
approving a contradicted change, and approving a change blocked by an unanswered decision. Blank = not decided, never approved.
**Company memory** (`xpv-company-memory/3`, one dedicated file per company, path given each time - no default location):
- Contents: human-confirmed **facts** (`mapping`: where a concept lives; `revision`: a restated past value, as-reported and later-known)
  and human-confirmed **assumptions / judgments** (`source_precedence`, `adjustment_rule`, `method_note`, `judgment`: an answered
  unresolved decision, `assumption_value`: an always-confirm value such as the multiple, for its period).
- Every entry: `type` (fact | assumption), `kind`, `subject`, `statement`, `value`, `period`, `source` (workbook role, file, sheet,
  cell), `decision` (approve | correct), `correction`, `confirmed_by`, `confirmed_at`, `review_sha256`, `supersedes` and `replaces`
  (a copy of the entry it replaced), and a hash chain (`prev_hash`, `entry_hash`).
- Written only by `memory.py apply`, only with what a person approved or corrected. The AI proposes; it never approves or writes.
- Append-only: nothing is edited or deleted; for each subject the latest confirmed entry is in force (`memory.py current`); history
  stays (`memory.py check --since OLD` proves an older copy is an exact prefix). Excel view: `memory.py view`.
- Next quarter: `memory.py attach` copies it into the run (`company_memory.in.json`). Proposals that match memory are not proposed
  again (`memory_unchanged`); a reading that differs is shown with what memory says (`memory_status: differs`, `memory_entry`) and a
  mapping contradiction becomes an unresolved decision that blocks the changes it touches; always-confirm values show the last
  confirmed value (`in_memory`); a decision asked again is pre-filled with its last confirmed answer, still for a person to approve.
- **Pending decisions** (`pending_decisions`, 13.2.1): an unresolved decision left blank in a review is NOT memory. It is kept in its
  own append-only, tamper-evident list of events (opened, resolved, rejected) keyed by `decision_key` (same question about the same
  place in the workbooks = same key every quarter). `memory.py attach` and `memory.py pending` list the open ones at the start of
  every run; each comes back with no answer (`pending_since`) and blocks the changes it touches - or every change, if its cells
  cannot be found (`cells_not_found`). It closes only when a person answers it (the answer becomes an assumption) or rejects it.
- **Rule or note for memory** (review column, any row): a person's own rule, kept as an `analyst_rule` assumption. Needs a Decision.
- Review rows compare numbers at Excel's own 15-digit precision, so a value Excel re-saved is not an edit (no tolerance on values).
  A decision with no suggested answer offers only Correct (type the answer) or Reject.

Edges and discrepancies need ids that are unique across all stages (`E1`.., `D1`..). A later stage may restate an item by id to replace it.

## Discrepancies
`{"id": "D1", "a": ref, "b": ref, "relation": {...how b would relate to a if they agreed}, "difference": b minus expected (optional),
"what": "...", "driver": "...", "driver_cells": [refs], "status": "unresolved" | "explained", "material": true}`.
verify confirms the two values really differ (by the stated amount, if given). A confirmed, unresolved discrepancy is a **correct
result**: it passes the fund check and becomes a decision for the analyst. Forcing values to reconcile is what fails.

## Reviewer files
**Blind stage 02 core** - everything in 02 roles and 03 chain together, with `direction: bottom_up`, at most 20 key `provenance`
edges, `downstream`, `discrepancies`. Cap 30 KB.
**Blind stage 03 challenges** - `challenges` (at most 12: `{id, kind, cells, note, material}`, kind = rival | weak_link | assumption |
period | units | version | discrepancy | other), `questions`, `notes`. Cap 15 KB.
**Review findings** - `produced_by`, `findings` (at most 20: `{id, type, target, evidence, note, claim, material}`), `questions`,
`overall`. Types: `confirmed`, `missed_rival`, `weak_provenance`, `unsupported_assumption`, `contradiction`, `unsure`. `target` is an
edge id, `chain.<role>`, a discrepancy id, `sources.<id>`, or `new`. `claim` is an edge (`{from, to, class, relation}`) or
`{chain_role, source, cell}` that reconcile tests with verify's own checks. Cap 40 KB.

## Statuses
**verify:** VERIFIED (nothing contradicted - proposals included; chain, window and fund confirmed; all stages saved) | SUPPORTED (nothing contradicted, but
something is honestly unresolved or not checkable) | PROVISIONAL (nothing contradicted so far; stages still to come) | REVIEW (a claim is
contradicted or the files are not the ones named).
**reconcile:** READY FOR APPROVAL | NEEDS ANALYST (anything to decide, including a preserved discrepancy) | CHECKS FAILED (verify
contradicted the extraction, or the agents read different files).
**Reviewer value (reconcile):** ADDED VALUE (an evidence-backed missed rival, weak edge or contradiction) | ADDED VALUE (judgment
only) | CORROBORATION (different path) | NO INDEPENDENT VALUE SHOWN.
