# run_manifest.py (build 13.2.6) - 13.2.6: a run read back from a review bundle (restored/run_identity.json) is a "restored" run:
# its manifest is never rewritten or uploaded from here; the review package record is its own file (<run id>_review_package.json
# in the human-review folder); stage-in records what it staged and checks checkpoints against the manifest's SHA-256s.
# run_manifest.py (build 13.2.5) - 13.2.5 adds: allocate (the next run number from a folder LISTING - names only, nothing in a
# previous run is opened); context (the active run in this conversation and which of its source workbooks are still here, by
# fingerprint); resources (the durable locations to show the person); the review package in the human-review folder; the
# generation handoff folder. (13.2.3 text follows)
# run_manifest.py (build 13.2.3) - the identity of one run and the names of the files the SYSTEM generates for it. Plain code.
# Source workbooks are never named, counted or laid out here: the manifest inventories whatever source set this run was given
# (original file name + byte fingerprint + contents fingerprint + the role the AI discovered at stage 2), so a new company or a
# new valuation format needs no code change. Only generated artifacts follow an exact contract:
#     <Company>_<YYYY>_<Qn>[_rN]_<artifact>        e.g. OceanSight_2026_Q2_r2_extraction.json
# Checkpoints keep their plain names inside checkpoints/ (01_sources.json ...). Inside the local run dir every file keeps its
# plain name (extraction.json, Review.xlsx ...); only the copies made for SharePoint (upload/) and the files fetched back
# (stage-in) carry the prefix, so every script, and the frozen test bench, read the same files as before.
#
#   plan     --company C --period "YYYY Qn"                     the run folders to try, in order, and the file that shows a folder
#                                                               is taken; use the first folder where neither file exists
#   init     --run-dir R --company C --period "YYYY Qn" --run-number N [--model M]
#                                                               after the inventory: writes run_manifest.json for this run
#   open     --run-folder F [--company C --period "YYYY Qn"]    for RESUME / REVIEW: checks the folder follows the contract and
#                                                               prints the exact files to fetch (and the older plain names)
#   stage-in --run-dir R --files F...                           copies fetched run files into the run dir under their plain names,
#                                                               refusing a file that belongs to another run or was changed
#   show     --run-dir R                                        the manifest, short
# Every script that prints UPLOAD: calls upload() below, which copies the generated files into upload/ with their contract
# names and records each file's SHA-256 in the manifest. A run with no manifest (older builds) keeps the plain names.
#
# Source lock: when the inventory finds that the workbooks given for a run differ from the ones it started with (contents
# changed, a file added or removed), it writes SOURCES_CHANGED.json. While that file exists no stage, proposal, review or memory
# step runs: a changed source set is a fresh onboarding in a new run folder, with a new Gold baseline for any benchmark.
import argparse, datetime, hashlib, json, os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

BUILD = "13.2.6"
SCHEMA = "xpv-run-manifest/1"
ROOT = "/Shared Documents/Valuations"
MANIFEST = "run_manifest.json"
LOCK = "SOURCES_CHANGED.json"
# generated artifacts: plain name in the run dir -> artifact part of the contract name (same text)
ARTIFACTS = ["run_manifest.json", "extraction.json", "verification.json", "proposed_changes.json", "notes.md", "Review.xlsx",
             "review_decisions.json", "approved_changes.json", "extractor_response.json", "Review.completed.xlsx",
             "generation_handoff.json", "review_package.json"]
REVIEW_PACKAGE = ("Review.xlsx", "Review.completed.xlsx", "review_decisions.json", "approved_changes.json", "review_package.json")
DEST = {**{a: "review" for a in REVIEW_PACKAGE}, "generation_handoff.json": "handoff"}   # everything else: the run folder
HUMAN_COPY = "Review.completed.xlsx"           # the person's filled copy, kept in 4.human_review/
COMPANY_RE = re.compile(r"[A-Za-z][A-Za-z0-9]*(?:-[A-Za-z0-9]+)*")
PERIOD_RE = re.compile(r"(\d{4}) Q([1-4])")
FOLDER_RE = re.compile(r"(?:.*/)?2\.extractor-outputs/([^/]+)/(\d{4})/(Q[1-4])(?:_r(\d+))?/?")


class ManifestError(Exception):
    pass


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")


def sha_file(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def check_company(c):
    c = str(c or "")
    if not COMPANY_RE.fullmatch(c):
        raise ManifestError(f"company key {c!r} is not valid: letters and digits only (a hyphen may join parts), starting with a "
                            "letter, no spaces or underscores - e.g. OceanSight")
    return c


def check_period(p):
    m = PERIOD_RE.fullmatch(str(p or "").strip())
    if not m:
        raise ManifestError(f"period {p!r} is not valid: write it as YYYY Qn with a capital Q, e.g. 2026 Q2")
    return int(m.group(1)), int(m.group(2))


def quarter_end(y, q):
    return {1: f"{y}-03-31", 2: f"{y}-06-30", 3: f"{y}-09-30", 4: f"{y}-12-31"}[q]


def run_id(company, y, q, n=1):
    if not isinstance(n, int) or n < 1:
        raise ManifestError(f"run number {n!r} is not valid: 1 for the first run of a quarter, 2 for the next ...")
    return f"{company}_{y}_Q{q}" + (f"_r{n}" if n > 1 else "")


def folders(company, y, q, n=1):
    leaf = f"{company}/{y}/Q{q}" + (f"_r{n}" if n > 1 else "")
    return {"run": f"{ROOT}/2.extractor-outputs/{leaf}", "review": f"{ROOT}/4.human_review/{leaf}",
            "grading": f"{ROOT}/3.test_bench_outputs/{leaf}", "memory": f"{ROOT}/5.company_memory/{company}.memory.json",
            "handoff": f"{ROOT}/6.generation_handoff/{leaf}",
            "inputs": f"{ROOT}/1.company_background_data/{company}/{y}/Q{q}"}


def name(rid, artifact):
    return f"{rid}_{artifact}"


def parse_folder(path):
    """a run folder -> (company, year, quarter, run number); exact case and form, or ManifestError."""
    p = str(path or "").replace("\\", "/").rstrip("/")
    m = FOLDER_RE.fullmatch(p)
    if not m:
        raise ManifestError(f"run folder {path!r} does not follow the contract .../2.extractor-outputs/<Company>/<YYYY>/<Qn>[_rN] "
                            "(capital Q, e.g. .../2.extractor-outputs/OceanSight/2026/Q2_r2)")
    c, y, q, n = m.group(1), int(m.group(2)), int(m.group(3)[1]), int(m.group(4) or 1)
    check_company(c)
    if m.group(4) is not None and n < 2:
        raise ManifestError(f"run folder {path!r}: a repeat run is _r2 or higher")
    return c, y, q, n


def source_set(run_dir):
    """the run's sources from checkpoint 1 (or, for a run read back from a review bundle, its verified sources component)
    -> fingerprint of the whole set + one line per file (no file name is required)."""
    p = os.path.join(run_dir, "checkpoints", "01_sources.json")
    if os.path.exists(p):
        S = json.load(open(p)).get("sources") or []
    else:
        rp = os.path.join(run_dir, "restored", "sources.json")
        if not os.path.exists(rp):
            return None
        S = [dict(x, file=x.get("original_file") or x.get("file")) for x in json.load(open(rp))]
    fps = sorted((s.get("content_sha256") or "bytes:" + s["sha256"]) for s in S)
    return {"content_sha256": hashlib.sha256("\n".join(fps).encode()).hexdigest(), "count": len(S),
            "basis": "contents" if all(s.get("content_sha256") for s in S) else "bytes (an older run recorded no contents fingerprint)",
            "files": [{"id": s["id"], "original_file": s["file"], "sha256": s["sha256"], "content_sha256": s.get("content_sha256")}
                      for s in S]}


def roles(run_dir):
    """the roles the AI gave each source at stage 2 (latest revision), with its one-line evidence -> {sid: {...}}."""
    import glob
    ck = os.path.join(run_dir, "checkpoints")
    files = sorted(glob.glob(os.path.join(ck, "02_roles*.json")),
                   key=lambda p: int(re.search(r"\.r(\d+)\.json$", p).group(1)) if ".r" in os.path.basename(p) else 1)
    if not files:
        return {}
    d = json.load(open(files[-1]))
    out = {}
    for s in d.get("sources") or d.get("roles") or []:
        if isinstance(s, dict) and s.get("id"):
            out[s["id"]] = {"role": s.get("role"), "period": s.get("period"),
                            "evidence": s.get("contributes") or s.get("what") or s.get("why")}
    return out


def load(run_dir):
    p = os.path.join(run_dir, MANIFEST)
    if os.path.exists(p):
        return json.load(open(p))
    rp = os.path.join(run_dir, "restored", "run_identity.json")
    if os.path.exists(rp):
        return dict(json.load(open(rp)), restored=True, artifacts={})
    return None


def write(run_dir, m):
    m = dict(m, updated_at=now())
    tmp = os.path.join(run_dir, MANIFEST + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(m, indent=1, ensure_ascii=False, sort_keys=True) + "\n")
    os.replace(tmp, os.path.join(run_dir, MANIFEST))
    return m


def refresh(run_dir, m):
    """sources, roles, stages and status as they stand now (code reads them; nothing is typed by the AI)."""
    ss = source_set(run_dir)
    if ss:
        rl = roles(run_dir)
        for f in ss["files"]:
            r = rl.get(f["id"]) or {}
            f["discovered_role"] = r.get("role") or "not yet assigned"
            f["role_period"] = r.get("period")
            f["role_evidence"] = r.get("evidence")
        m["sources"] = ss
    x = os.path.join(run_dir, "extraction.json")
    if os.path.exists(x):
        X = json.load(open(x))
        m["stages_done"] = X.get("stages_done")
        m["status"] = X.get("status")
        m["company_as_named_in_fund_workbook"] = X.get("company")
        if X.get("quarter_end") and X["quarter_end"][:10] != m["quarter_end"]:
            m.setdefault("warnings", []).append(f"the extraction's quarter end {X['quarter_end']} is not this run's {m['quarter_end']}")
    v = os.path.join(run_dir, "verification.json")
    if os.path.exists(v):
        m["verify_status"] = json.load(open(v)).get("status")
    m["source_lock"] = "LOCKED: the source set changed - fresh onboarding needed" if os.path.exists(os.path.join(run_dir, LOCK)) else "ok"
    return m


def init(run_dir, company, period, n, model=None):
    company = check_company(company)
    y, q = check_period(period)
    rid = run_id(company, y, q, int(n))
    if not os.path.exists(os.path.join(run_dir, "checkpoints", "01_sources.json")):
        raise ManifestError("run the inventory first (xlsx_evidence.py inventory) - the manifest records the sources it found")
    require_same_sources(run_dir)
    old = load(run_dir)
    if old and old.get("run_id") != rid:
        raise ManifestError(f"this run dir already belongs to run {old.get('run_id')}; it cannot become {rid}")
    m = old or {"schema": SCHEMA, "build": BUILD, "created_at": now(), "artifacts": {}}
    m.update(company_key=company, year=y, quarter=f"Q{q}", period=f"{y} Q{q}", quarter_end=quarter_end(y, q), run_number=int(n),
             run_id=rid, folders=folders(company, y, q, int(n)), model=model or m.get("model") or "not stated",
             names={a: name(rid, a) for a in ARTIFACTS} | {HUMAN_COPY: name(rid, HUMAN_COPY), "grading_report.json": name(rid, "grading_report.json")})
    return write(run_dir, refresh(run_dir, m))


def require_same_sources(run_dir):
    p = os.path.join(run_dir, LOCK)
    if os.path.exists(p):
        d = json.load(open(p))
        raise ManifestError("STOPPED - the source set changed: " + d.get("what", "the workbooks differ from the ones this run started with")
                            + ". Nothing from this run is reused. Start a fresh onboarding in a new run folder (and a new Gold baseline "
                            "for any benchmark of this company and period).")


def lock(run_dir, what, detail):
    json.dump({"what": what, "detail": detail, "at": now()}, open(os.path.join(run_dir, LOCK), "w"), indent=1)


def unlock(run_dir):
    p = os.path.join(run_dir, LOCK)
    if os.path.exists(p):
        os.remove(p)


def upload(run_dir, plain):
    """copy generated files into upload/ under their contract names (if this run has a manifest) -> list of paths to upload.
    plain: names relative to the run dir (checkpoints/... keep their names). Without a manifest: the plain names (older runs)."""
    m = load(run_dir)
    if not m:
        return list(plain)
    if m.get("restored"):
        return _upload_restored(run_dir, m, plain)
    m = refresh(run_dir, m)
    m["folders"] = folders(m["company_key"], m["year"], int(m["quarter"][1]), m["run_number"])   # older manifests gain new folders
    up = os.path.join(run_dir, "upload")
    for d_ in ("checkpoints", "review", "review_package", "handoff"):
        os.makedirs(os.path.join(up, d_), exist_ok=True)
    out = []
    for rel in list(plain) + [MANIFEST]:
        if rel == MANIFEST:
            write(run_dir, m)
        src = os.path.join(run_dir, rel)
        if not os.path.exists(src):
            continue
        base = os.path.basename(rel)
        if rel.startswith("checkpoints/") or rel.startswith("checkpoints" + os.sep):
            dst_rel = os.path.join("checkpoints", base)
        elif rel.startswith("review/") and re.fullmatch(r"proposals_[0-9a-f]{16}\.json", base):
            dst_rel = os.path.join("review", base)              # review snapshots keep their content-derived names
        elif base in ARTIFACTS and DEST.get(base) == "review":
            dst_rel = os.path.join("review_package", name(m["run_id"], base))
        elif base in ARTIFACTS and DEST.get(base) == "handoff":
            dst_rel = os.path.join("handoff", name(m["run_id"], base))
        elif base in ARTIFACTS:
            dst_rel = name(m["run_id"], base)
        else:
            continue
        if rel != MANIFEST:
            m["artifacts"][base if base in ARTIFACTS else rel] = {"file": dst_rel, "sha256": sha_file(src), "at": now()}
        shutil.copyfile(src, os.path.join(up, dst_rel))
        if f"upload/{dst_rel}" not in out:
            out.append(f"upload/{dst_rel}")
    write(run_dir, m)
    shutil.copyfile(os.path.join(run_dir, MANIFEST), os.path.join(up, name(m["run_id"], MANIFEST)))
    out = [o for o in out if not o.endswith(MANIFEST)] + [f"upload/{name(m['run_id'], MANIFEST)}"]
    return out


def _upload_restored(run_dir, m, plain):
    """a run read back from a review bundle: only the review package, the handoff and new snapshots are saved; the run's manifest
    and checkpoints are never rewritten from here."""
    up = os.path.join(run_dir, "upload")
    out = []
    for rel in plain:
        src = os.path.join(run_dir, rel)
        base = os.path.basename(rel)
        if not os.path.exists(src) or DEST.get(base) not in ("review", "handoff"):
            continue
        d_ = "review_package" if DEST[base] == "review" else "handoff"
        os.makedirs(os.path.join(up, d_), exist_ok=True)
        dst_rel = os.path.join(d_, name(m["run_id"], base))
        shutil.copyfile(src, os.path.join(up, dst_rel))
        out.append(f"upload/{dst_rel}")
    return out


def upload_text(run_dir, plain):
    """'files -> folder' per destination: run folder, review folder (review package), handoff folder."""
    m = load(run_dir)
    files = upload(run_dir, plain)
    if not m:
        return ", ".join(files)
    m = load(run_dir)
    grp = {}
    for f in files:
        d_ = "review" if "/review_package/" in f else "handoff" if "/handoff/" in f else "run"
        grp.setdefault(d_, []).append(f)
    return " ; ".join(f"{', '.join(v)} -> {m['folders'][k]}" for k, v in grp.items())


def review_package(run_dir):
    p = os.path.join(run_dir, "review_package.json")
    return json.load(open(p)) if os.path.exists(p) else None


def write_review_package(run_dir, rp):
    with open(os.path.join(run_dir, "review_package.json"), "w", encoding="utf-8") as fh:
        fh.write(json.dumps(rp, indent=1, sort_keys=True, ensure_ascii=False) + "\n")
    m = load(run_dir)
    if m and not m.get("restored"):
        m["review_package"] = rp
        write(run_dir, m)


def record_review(run_dir, attachment_name, dec):
    """the review package record: canonical names, hashes, snapshot, bundle, reviewer, location (the attachment's own name is kept
    only as a note - the durable copy always has the contract name)."""
    m = load(run_dir)
    if not m:
        return
    rp = {"folder": m["folders"]["review"], "snapshot_sha256": dec.get("snapshot_sha256"),
                           "snapshot_file": dec.get("snapshot_file"), "reviewer": dec.get("reviewer"), "read_at": dec.get("read_at"),
                           "completed_review": name(m["run_id"], HUMAN_COPY), "completed_review_sha256": dec.get("review_sha256"),
                           "attached_as": attachment_name, "decisions": name(m["run_id"], "review_decisions.json"),
                           "approved_changes": name(m["run_id"], "approved_changes.json"), "bundle_sha256": dec.get("bundle_sha256"),
                           "read_from": "review bundle" if m.get("restored") else "this conversation's run files"}
    write_review_package(run_dir, rp)


def allocate(company, period, listing):
    """next run number for company + period from a folder listing of .../2.extractor-outputs/<Company>/<YYYY>/ (names only).
    listing: parsed JSON from the SharePoint listing tool (any of its shapes), a list of names, or None/[] when the folder does not
    exist yet. Nothing inside an earlier run is opened."""
    c = check_company(company)
    y, q = check_period(period)
    names = []

    def walk(x):
        if isinstance(x, dict):
            for k in ("Name", "{Name}", "DisplayName", "name", "FileLeafRef"):
                if isinstance(x.get(k), str):
                    names.append(x[k].strip("/").split("/")[-1])
                    break
            for v in x.values():
                if isinstance(v, (list, dict)):
                    walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
        elif isinstance(x, str):
            names.extend(n.strip().strip("/").split("/")[-1] for n in x.splitlines() if n.strip())
    walk(listing)
    taken = set()
    for n in names:
        mm = re.fullmatch(rf"Q{q}(?:_r(\d+))?", n)
        if mm:
            taken.add(int(mm.group(1) or 1))
        elif re.fullmatch(rf"q{q}(?:_r\d+)?", n, flags=re.I):
            raise ManifestError(f"the listing has a folder {n!r} in the wrong case; fix it in SharePoint before allocating a run")
    n = 1
    while n in taken:
        n += 1
    return n, sorted(taken), folders(c, y, q, n)


def find_sources(run_dir, search=()):
    """the active run's sources -> [(sid, original file, path or None)]: a path is given only when a file there has the same SHA-256
    as when the run started (the path the inventory used, else any file under the search folders)."""
    p = os.path.join(run_dir, "checkpoints", "01_sources.json")
    S = json.load(open(p)).get("sources") or [] if os.path.exists(p) else []
    paths = json.load(open(os.path.join(run_dir, ".paths.json"))) if os.path.exists(os.path.join(run_dir, ".paths.json")) else {}
    pool = {}
    for d_ in search:
        for root, _, fs in os.walk(d_):
            for f in fs:
                if f.lower().endswith((".xlsx", ".xlsm")):
                    fp = os.path.join(root, f)
                    try:
                        pool.setdefault(sha_file(fp), fp)
                    except OSError:
                        pass
    out = []
    for s_ in S:
        hit = None
        cand = paths.get(s_["id"])
        if cand and os.path.exists(cand) and sha_file(cand) == s_["sha256"]:
            hit = cand
        hit = hit or pool.get(s_["sha256"])
        out.append((s_["id"], s_["file"], hit))
    return out


DEFAULT_SEARCH = ("/app/uploads", "/mnt/data", "/mnt/user-data/uploads", "uploads")


def resources(run_dir):
    m = load(run_dir)
    if not m:
        return []
    R = [("run folder", m["folders"]["run"])]
    if m.get("review_package") or review_package(run_dir):
        R.append(("review package", m["folders"]["review"]))
    if os.path.exists(os.path.join(run_dir, "generation_handoff.json")):
        R.append(("generation handoff", f"{m['folders']['handoff']}/{name(m['run_id'], 'generation_handoff.json')}"))
    R.append(("company memory", m["folders"]["memory"]))
    return R


def open_folder(folder, company=None, period=None):
    c, y, q, n = parse_folder(folder)
    if company is not None and check_company(company) != c:
        raise ManifestError(f"the message says company {company!r} but the run folder is {c!r} (case matters)")
    if period is not None and check_period(period) != (y, q):
        raise ManifestError(f"the message says period {period!r} but the run folder is {y} Q{q}")
    rid = run_id(c, y, q, n)
    return {"run_id": rid, "company_key": c, "period": f"{y} Q{q}", "run_number": n, "folders": folders(c, y, q, n),
            "fetch": [name(rid, a) for a in ARTIFACTS if a not in REVIEW_PACKAGE] + ["checkpoints/*.json", "review/proposals_*.json"],
            "fetch_review_folder": [name(rid, a) for a in REVIEW_PACKAGE],
            "older_plain_names": list(ARTIFACTS)}


def stage_in(run_dir, files):
    """fetched run files -> the run dir under plain names. A file prefixed for another run is refused; a manifest that records a
    different SHA-256 for an artifact is refused (it was changed or belongs elsewhere). Older plain names are accepted."""
    os.makedirs(os.path.join(run_dir, "checkpoints"), exist_ok=True)
    os.makedirs(os.path.join(run_dir, "review"), exist_ok=True)
    man = next((f for f in files if os.path.basename(f) == MANIFEST or os.path.basename(f).endswith("_" + MANIFEST)), None)
    m = json.load(open(man)) if man else load(run_dir)
    rid = (m or {}).get("run_id")
    P, done = [], []
    for f in files:
        b = os.path.basename(f)
        is_ck = re.fullmatch(r"\d{2}_[a-z_]+(\.r\d+)?(\.[A-Z]+)?\.json", b) is not None
        if re.fullmatch(r"proposals_[0-9a-f]{16}\.json", b):     # a review snapshot: its name is its fingerprint, checked on read
            done.append((f, os.path.join(run_dir, "review", b), False))
            continue
        plain = b
        if not is_ck:
            hit = next((a for a in ARTIFACTS if b == a or b.endswith("_" + a)), None)
            if not hit:
                P.append(f"{b}: not a run file this system generates (source workbooks are attachments, never staged here)")
                continue
            pre = b[: -len(hit)].rstrip("_") if b != hit else None
            if pre and rid and pre != rid:
                P.append(f"{b}: belongs to run {pre}, not to this run {rid}")
                continue
            if pre and not rid:
                P.append(f"{b}: a contract-named file but no run manifest was fetched with it - fetch {pre}_{MANIFEST} too")
                continue
            plain = hit
            rec = ((m or {}).get("artifacts") or {}).get(hit)
            if rec and hit != MANIFEST and rec.get("sha256") != sha_file(f):
                P.append(f"{b}: its contents are not the ones this run saved ({rec['sha256'][:12]}...) - fetch it again; never use an edited copy")
                continue
        done.append((f, os.path.join(run_dir, "checkpoints", plain) if is_ck else os.path.join(run_dir, plain), b != plain))
    for src, dst, renamed in done:                       # 13.2.6: a checkpoint must be the one the run saved, byte for byte
        if "/checkpoints/" in dst.replace(os.sep, "/"):
            rec = ((m or {}).get("artifacts") or {}).get("checkpoints/" + os.path.basename(dst))
            if rec and rec.get("sha256") != sha_file(src):
                P.append(f"{os.path.basename(src)}: not the checkpoint this run saved - never retype or edit a checkpoint; attach the file")
    if P:
        raise ManifestError(P)
    for src, dst, renamed in done:
        if os.path.abspath(src) != os.path.abspath(dst):
            shutil.copyfile(src, dst)
    sp = os.path.join(run_dir, ".staged.json")
    st = json.load(open(sp)) if os.path.exists(sp) else []
    st = sorted(set(st) | {os.path.relpath(d, run_dir).replace(os.sep, "/") for _, d, _ in done})
    json.dump(st, open(sp, "w"))
    return [(os.path.basename(s), os.path.relpath(d, run_dir), r) for s, d, r in done], rid


def main(argv=None):
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("plan")
    p.add_argument("--company", required=True)
    p.add_argument("--period", required=True)
    p = sub.add_parser("init")
    p.add_argument("--run-dir", default="run")
    p.add_argument("--company", required=True)
    p.add_argument("--period", required=True)
    p.add_argument("--run-number", type=int, required=True)
    p.add_argument("--model")
    p = sub.add_parser("open")
    p.add_argument("--run-folder", required=True)
    p.add_argument("--company")
    p.add_argument("--period")
    p = sub.add_parser("stage-in")
    p.add_argument("--run-dir", default="run")
    p.add_argument("--files", nargs="+", required=True)
    p = sub.add_parser("show")
    p.add_argument("--run-dir", default="run")
    p = sub.add_parser("allocate")
    p.add_argument("--company", required=True)
    p.add_argument("--period", required=True)
    p.add_argument("--listing", help="file with the listing tool's output (JSON or one name per line)")
    p.add_argument("--no-folder", action="store_true", help="the listing tool said the year folder does not exist yet")
    p = sub.add_parser("context")
    p.add_argument("--run-dir", default="run")
    p.add_argument("--search", nargs="*", default=list(DEFAULT_SEARCH))
    p = sub.add_parser("resources")
    p.add_argument("--run-dir", default="run")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "plan":
            c = check_company(a.company)
            y, q = check_period(a.period)
            print(f"RUN PLAN: {c} {y} Q{q} | try these run folders in order; a folder is taken if either file exists in it. Use the first "
                  "free one and pass its number to init:")
            for n in range(1, 10):
                f = folders(c, y, q, n)["run"]
                print(f"  {n}: {f} | taken if {f}/{name(run_id(c, y, q, n), MANIFEST)} or {f}/checkpoints/01_sources.json exists")
            return 0
        if a.cmd == "init":
            m = init(a.run_dir, a.company, a.period, a.run_number, a.model)
            print(f"RUN: {m['run_id']} | folder {m['folders']['run']} | quarter end {m['quarter_end']} | {m['sources']['count']} source "
                  f"workbook(s) inventoried by fingerprint | UPLOAD: {upload_text(a.run_dir, [])}")
            return 0
        if a.cmd == "open":
            o = open_folder(a.run_folder, a.company, a.period)
            print(f"RUN: {o['run_id']} | {o['company_key']} {o['period']} | FETCH (those that exist, from {o['folders']['run']}): "
                  f"{', '.join(o['fetch'])} | and from {o['folders']['review']}: {', '.join(o['fetch_review_folder'])} | "
                  f"an older run uses the plain names: {', '.join(o['older_plain_names'])}")
            return 0
        if a.cmd == "stage-in":
            done, rid = stage_in(a.run_dir, a.files)
            print(f"STAGED: {len(done)} file(s) into the run dir for {rid or 'an older run (no manifest)'}"
                  + "".join(f"\n  - {s} -> {d}{' (contract name)' if r else ''}" for s, d, r in done))
            return 0
        if a.cmd == "allocate":
            if not a.listing and not a.no_folder:
                raise ManifestError("give the listing of .../2.extractor-outputs/<Company>/<YYYY>/ (--listing FILE), or --no-folder if "
                                    "the listing tool says that folder does not exist yet. Never probe guessed paths.")
            lst = None
            if a.listing:
                raw = open(a.listing, encoding="utf-8").read()
                try:
                    lst = json.loads(raw)
                except ValueError:
                    lst = raw
            n, taken, f = allocate(a.company, a.period, lst)
            print(f"RUN ALLOCATED: run number {n} | {f['run']} | existing runs for this quarter: {taken or 'none'} | pass "
                  f"--run-number {n} to init")
            return 0
        if a.cmd == "context":
            m = load(a.run_dir)
            if not m:
                print("ACTIVE RUN: none in this conversation - the message must give Company and Period (new run) or Company, Period "
                      "and Run folder (existing run)")
                return 1
            src = find_sources(a.run_dir, a.search)
            have = [x for x in src if x[2]]
            miss = [x for x in src if not x[2]]
            lock = os.path.exists(os.path.join(a.run_dir, LOCK))
            print(f"ACTIVE RUN: {m['run_id']} | {m['folders']['run']} | stages done {m.get('stages_done')} | memory {m['folders']['memory']}"
                  f" | sources {len(have)}/{len(src)} still here, unchanged" + (" | LOCKED (source set changed)" if lock else ""))
            if miss:
                print("NEED ONLY: " + "; ".join(f"{x[1]}" for x in miss) + " (ask the person to attach just these)")
            else:
                print("WORKBOOKS: " + " ".join(json.dumps(x[2]) for x in have))
            return 0
        if a.cmd == "resources":
            for k, v in resources(a.run_dir):
                print(f"RESOURCE: {k} | {v}")
            return 0
        if a.cmd == "show":
            m = load(a.run_dir)
            if not m:
                print("RUN: no manifest (an older run, or init has not run)")
                return 1
            m = refresh(a.run_dir, m)
            print(f"RUN: {m['run_id']} | {m['quarter_end']} | sources {m['sources']['count']} ({m['sources']['basis']}) | "
                  f"lock {m['source_lock']} | stages {m.get('stages_done')} | status {m.get('status')}")
            for f in m["sources"]["files"]:
                print(f"  - {f['id']} {f['original_file']} | role {f['discovered_role']} | contents {str(f.get('content_sha256'))[:12]}")
            return 0
    except ManifestError as x:
        P = x.args[0] if x.args and isinstance(x.args[0], list) else [str(x)]
        print("RUN: refused | " + P[0])
        for y_ in P[1:20]:
            print(f"  - {y_}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
