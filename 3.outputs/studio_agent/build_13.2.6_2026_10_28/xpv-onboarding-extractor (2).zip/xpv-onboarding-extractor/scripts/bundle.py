# bundle.py (build 13.2.6) - the review bundle: everything the review read, the memory write and the generation handoff need,
# carried INSIDE the review workbook (hidden sheet _bundle), so a completed review is self-sufficient and no run file is ever
# fetched as text, retyped, reformatted, trimmed or regenerated. Plain code.
#
# Components (each a canonical UTF-8 text, each with its own SHA-256; the whole bundle has one SHA-256 written into _meta):
#   proposals_snapshot   the exact bytes of the proposals the review shows (same SHA-256 as review/proposals_<sha>.json)
#   run_identity         run id, company key, period, quarter end, run number, folders, build, model
#   sources              per source workbook: id, original file name, SHA-256, contents SHA-256, discovered role, sheet names and
#                        states. NO workbook contents.
#   verified_context     the extraction's chain, path, links (provenance, downstream), discrepancies, stages and status, and the
#                        verification status of each link - what the handoff needs
# Restore checks, in order, and refuses on the first failure (nothing is written): the _bundle sheet exists; its header names this
# schema; every chunk 1..n is present exactly once; the bundle decodes; its SHA-256 equals the header's and _meta's; no duplicate
# keys; exactly the four components; each component's SHA-256 matches; the snapshot's SHA-256 equals _meta's snapshot fingerprint;
# the components agree with each other (company, quarter end, run). There is no fallback of any kind.
import base64, hashlib, json, os

SCHEMA = "xpv-review-bundle/1"
SHEET = "_bundle"
REQUIRED = ("proposals_snapshot", "run_identity", "sources", "verified_context")
CHUNK = 30000                                          # Excel holds 32,767 characters per cell
RESTORED = "restored"


class BundleError(ValueError):
    pass


def sha(b):
    return hashlib.sha256(b if isinstance(b, bytes) else b.encode("utf-8")).hexdigest()


def canon(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def _no_dupes(pairs):
    d = {}
    for k, v in pairs:
        if k in d:
            raise BundleError(f"the review bundle repeats the key {k!r}")
        d[k] = v
    return d


def components(run_dir, snapshot_bytes):
    """-> {name: canonical text}. Reads only code-made files of THIS run (checkpoint 1, extraction, verification, manifest)."""
    import run_manifest as RM
    need = {"checkpoints/01_sources.json": os.path.join(run_dir, "checkpoints", "01_sources.json"),
            "extraction.json": os.path.join(run_dir, "extraction.json"), "verification.json": os.path.join(run_dir, "verification.json"),
            "run_manifest.json": os.path.join(run_dir, "run_manifest.json")}
    miss = [k for k, p in need.items() if not os.path.exists(p)]
    if miss:
        raise BundleError("a review can only be built where the run was extracted (missing here: " + ", ".join(miss) + ")")
    S = json.load(open(need["checkpoints/01_sources.json"]))
    X = json.load(open(need["extraction.json"]))
    V = json.load(open(need["verification.json"]))
    M = RM.load(run_dir)
    roles = {s.get("id"): s for s in X.get("sources") or []}
    src = [{"id": s["id"], "original_file": s["file"], "sha256": s["sha256"], "content_sha256": s.get("content_sha256"),
            "role": (roles.get(s["id"]) or {}).get("role"), "role_period": (roles.get(s["id"]) or {}).get("period"),
            "file": s["file"], "sheets": [{"name": x.get("name"), "state": x.get("state")} for x in s.get("sheets") or []]}
           for s in S.get("sources") or []]
    ident = {k: M.get(k) for k in ("run_id", "company_key", "year", "quarter", "period", "quarter_end", "run_number", "folders", "build", "model",
                                    "created_at", "schema")}
    edges = V.get("edges")
    if isinstance(edges, dict):
        estat = {k: (v or {}).get("status") for k, v in edges.items()}
    else:
        estat = {e.get("id"): e.get("status") for e in edges or [] if isinstance(e, dict)}
    ctx = {"company": X.get("company"), "quarter_end": X.get("quarter_end"), "stages_done": X.get("stages_done"), "status": X.get("status"),
           "valuation_workbook": X.get("valuation_workbook"), "fund_workbook": X.get("fund_workbook"), "chain": X.get("chain"),
           "path": X.get("path"), "direction": X.get("direction"), "provenance": X.get("provenance"), "downstream": X.get("downstream"),
           "discrepancies": X.get("discrepancies"), "sources": [{"id": s.get("id"), "role": s.get("role"), "file": s.get("file")} for s in X.get("sources") or []],
           "verification": {"status": V.get("status"), "edges": estat}}
    return {"proposals_snapshot": snapshot_bytes.decode("utf-8"), "run_identity": canon(ident), "sources": canon(src),
            "verified_context": canon(ctx)}


def pack(comps):
    """-> (bundle bytes, bundle sha). The bundle is canonical: same components, same bytes."""
    if sorted(comps) != sorted(REQUIRED):
        raise BundleError("a bundle has exactly the components " + ", ".join(REQUIRED))
    body = canon({"schema": SCHEMA, "components": comps, "component_sha256": {k: sha(v) for k, v in comps.items()}}).encode("utf-8")
    return body, sha(body)


def write_sheet(wb, body, bsha):
    ws = wb.create_sheet(SHEET)
    enc = base64.b64encode(body).decode("ascii")
    parts = [enc[i:i + CHUNK] for i in range(0, len(enc), CHUNK)] or [""]
    ws.append([SCHEMA, len(parts), bsha])
    for i, p in enumerate(parts, 1):
        ws.append([i, p])
    ws.sheet_state = "veryHidden"
    ws.protection.sheet = True


def read_sheet(wb, meta):
    """-> (components, bundle sha). Every check in the header comment; BundleError on any failure."""
    if SHEET not in wb.sheetnames:
        raise BundleError("required review bundle missing: this review workbook carries no bundle (built before 13.2.6, or the hidden "
                          "sheet was removed). Build a fresh review where the run was extracted.")
    ws = wb[SHEET]
    rows = [r for r in ws.iter_rows(values_only=True) if r and any(v not in (None, "") for v in r)]
    if not rows or rows[0][0] != SCHEMA:
        raise BundleError("the review bundle's header is missing or not " + SCHEMA)
    try:
        n, hsha = int(rows[0][1]), str(rows[0][2])
    except (TypeError, ValueError, IndexError):
        raise BundleError("the review bundle's header is damaged")
    got = {}
    for r in rows[1:]:
        try:
            i = int(r[0])
        except (TypeError, ValueError):
            raise BundleError("the review bundle has a damaged chunk row")
        if i in got:
            raise BundleError(f"the review bundle repeats chunk {i}")
        got[i] = r[1] if isinstance(r[1], str) else ""
    if sorted(got) != list(range(1, n + 1)):
        raise BundleError(f"the review bundle should have chunks 1..{n}; it has {sorted(got)[:5]}{'...' if len(got) > 5 else ''}")
    try:
        body = base64.b64decode("".join(got[i] for i in range(1, n + 1)), validate=True)
    except ValueError:
        raise BundleError("the review bundle does not decode")
    bsha = sha(body)
    if bsha != hsha:
        raise BundleError("the review bundle was altered (its fingerprint does not match its header)")
    if meta.get("bundle_sha256") != bsha:
        raise BundleError("the review bundle is not the one this review was built with (its fingerprint does not match _meta)")
    try:
        doc = json.loads(body.decode("utf-8"), object_pairs_hook=_no_dupes)
    except BundleError:
        raise
    except ValueError:
        raise BundleError("the review bundle is not valid")
    if doc.get("schema") != SCHEMA or not isinstance(doc.get("components"), dict) or not isinstance(doc.get("component_sha256"), dict):
        raise BundleError("the review bundle's layout is not " + SCHEMA)
    comps, csha = doc["components"], doc["component_sha256"]
    if sorted(comps) != sorted(REQUIRED) or sorted(csha) != sorted(REQUIRED):
        raise BundleError("the review bundle must hold exactly: " + ", ".join(REQUIRED))
    for k in REQUIRED:
        if not isinstance(comps[k], str) or sha(comps[k]) != csha[k]:
            raise BundleError(f"the review bundle's {k} was altered (its fingerprint does not match)")
    if canon(doc).encode("utf-8") != body:
        raise BundleError("the review bundle is not in canonical form (it cannot be reproduced byte for byte)")
    if sha(comps["proposals_snapshot"].encode("utf-8")) != meta.get("snapshot_sha256"):
        raise BundleError("the review bundle's proposals are not the snapshot this review shows")
    pc = json.loads(comps["proposals_snapshot"])
    ident = json.loads(comps["run_identity"])
    ctx = json.loads(comps["verified_context"])
    if (pc.get("quarter_end") or "")[:10] != (ctx.get("quarter_end") or "")[:10] or ident.get("quarter_end") != (ctx.get("quarter_end") or "")[:10]:
        raise BundleError("the review bundle's parts disagree on the quarter end")
    if meta.get("run_id") and ident.get("run_id") != meta["run_id"]:
        raise BundleError("the review bundle belongs to another run")
    return comps, bsha


def restore(run_dir, comps, bsha):
    """write the verified components into the run dir: the snapshot under its own name (byte for byte) and the rest under restored/.
    Nothing in checkpoints/ is written. A file already here must be identical, or nothing is written."""
    snap = comps["proposals_snapshot"].encode("utf-8")
    ssha = sha(snap)
    ident = json.loads(comps["run_identity"])
    plan = {os.path.join("review", f"proposals_{ssha[:16]}.json"): snap}
    for k in ("run_identity", "sources", "verified_context"):
        plan[os.path.join(RESTORED, f"{k}.json")] = comps[k].encode("utf-8")
    plan[os.path.join(RESTORED, "bundle_sha256.txt")] = bsha.encode("ascii")
    mp = os.path.join(run_dir, "run_manifest.json")
    if os.path.exists(mp) and json.load(open(mp)).get("run_id") != ident.get("run_id"):
        raise BundleError("this conversation holds another run; read the review in a new conversation")
    for rel, b in plan.items():
        p = os.path.join(run_dir, rel)
        if os.path.exists(p) and open(p, "rb").read() != b and not rel.startswith(RESTORED):
            raise BundleError(f"{rel} here differs from the review bundle; nothing was restored")
    created = []
    for rel, b in plan.items():
        p = os.path.join(run_dir, rel)
        if not os.path.exists(p):
            created.append(p)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p + ".tmp", "wb") as fh:
            fh.write(b)
        os.replace(p + ".tmp", p)
    restore.created = created
    return ident


def undo(run_dir):
    """remove what the last restore created (a refused read leaves nothing behind)."""
    for p in getattr(restore, "created", []):
        if os.path.exists(p):
            os.remove(p)
    restore.created = []


def restored(run_dir, name):
    p = os.path.join(run_dir, RESTORED, f"{name}.json")
    return json.load(open(p)) if os.path.exists(p) else None
