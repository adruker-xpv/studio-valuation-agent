# concepts.py (build 13.2.3) - the contradiction gate that runs before anything a person confirmed is written to company memory
# (and before approved changes are handed on). Plain code: no company, cell, sheet, value or tolerance is written here.
#
# Every confirmed item in a review (a memory candidate Approved or Corrected, an unresolved decision answered, an always-confirm
# value such as the multiple, an approved change that names where a value lives, a person's own rule) is turned into a CLAIM:
#   concept   which valuation item it is about - built from the same identity code already gives the item (kind + subject,
#             a decision's key, the target cell of a value), normalised for case, spaces, underscores and hyphens
#   value     what it says about it, in a form that can be compared exactly: a location (workbook role, sheet, cell), a number
#             (compared as Excel stores it, 15 significant digits - storage, never a business tolerance), a pair (a revision's
#             as-reported and later-known values) or a normalised text. None when it cannot be compared.
# Then, per concept:
#   CONFLICT            the same concept, two confirmed values that differ (in this review, or against memory in force for the
#                       same period that the person was not shown side by side). The concept STOPS: none of its items is
#                       written or handed on; it returns to the analyst as a pending decision showing both values.
#   IDENTITY UNCERTAIN  code cannot tell whether two items are one concept or two: the same concept where one value cannot be
#                       compared; two different chain items placed on the same cell; a numeric answer about the cell an
#                       always-confirm value sits on, with a different number; the same subject under two kinds of rule.
#                       Nothing is merged. Both stop and return to the analyst ("same or different?") as a pending decision.
# Items whose dates differ (a different period) are a later confirmation that supersedes, not a contradiction. Equal values are
# never a question. Everything not in a stopped group goes ahead as before.
#   coherence(memory) -> problems: in force, at most one confirmed value per concept; and no single review wrote two different
#                        values for one subject (how competing facts got in before this gate existed).
import hashlib, json, re

NOTE_FAMILY = "rule"
TEXT_KINDS = ("source_precedence", "adjustment_rule", "method_note")


def norm_subject(s):
    return re.sub(r"[\s_\-]+", "_", str(s or "").strip().lower())


def norm_text(t):
    return re.sub(r"\s+", " ", str(t or "").strip().lower())


def num15(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(f"{float(v):.15g}")
    if isinstance(v, str):
        t = v.strip().replace(",", "")
        if re.fullmatch(r"[-+]?\d+(\.\d+)?([eE][-+]?\d+)?", t):
            return float(f"{float(t):.15g}")
    return None


def loc(v):
    """a portable cell {role, sheet, cell} -> a comparable tuple, or None."""
    if not isinstance(v, dict) or not v.get("sheet") or not v.get("cell"):
        return None
    return ("loc", str(v.get("role") or ""), str(v["sheet"]).strip().lower(), str(v["cell"]).replace("$", "").upper())


def show(v):
    if v is None:
        return "(cannot be compared)"
    if v[0] == "loc":
        return f"{v[1]} workbook, {v[2]}!{v[3]}"
    if v[0] == "num":
        return f"{v[1]:g}"
    if v[0] == "pair":
        return f"as reported {v[1]}, later known {v[2]}"
    return f"'{v[1]}'"


def value_of_answer(a):
    if isinstance(a, dict):
        return loc(a) or ("text", norm_text(json.dumps(a, sort_keys=True)))
    n = num15(a)
    if n is not None:
        return ("num", n)
    return ("text", norm_text(a)) if a not in (None, "") else None


def family(kind):
    return {"mapping": "mapping", "revision": "revision", "assumption_value": "value", "judgment": "judgment",
            "analyst_rule": NOTE_FAMILY}.get(kind, kind)


def concept_key(kind, subject):
    return f"{family(kind)}:{norm_subject(subject)}"


def _portable(run_dir, ref, portable_ref):
    return portable_ref(run_dir, ref) if isinstance(ref, dict) and "source" in ref else ref


def review_claims(pc, D, run_dir, portable_ref):
    """the confirmed items of one review -> claims. Rejected and blank items say nothing and make no claim."""
    period = (pc.get("quarter_end") or "")[:7] or None
    cands = {c["id"]: c for c in pc.get("memory_candidates") or []}
    hjs = {j["id"]: j for j in pc.get("human_judgments") or []}
    pcs = {x["id"]: x for x in pc.get("proposed_changes") or []}
    chain_at = {}                                    # where code placed each chain item (as proposed, before any correction)
    for c in cands.values():
        if c["kind"] == "mapping" and str(c["subject"]).startswith("chain.") and loc(c.get("value")):
            chain_at[loc(c["value"])] = c["subject"]
    C = []

    def add(item, item_type, kind, subject, value, cells, extra=None):
        C.append(dict({"item": item, "item_type": item_type, "kind": kind, "concept": concept_key(kind, subject),
                       "subject": subject, "value": value, "cells": [x for x in cells if loc(x)], "period": period,
                       "source": "review"}, **(extra or {})))
    for d in D.get("decisions") or []:
        dec, corr, iid, t = d.get("decision"), d.get("correction") or {}, d.get("item_id"), d.get("item_type")
        if dec in ("Approve", "Correct"):
            if t == "memory" and iid in cands:
                c = cands[iid]
                k, sub = c["kind"], c["subject"]
                ev = [_portable(run_dir, e, portable_ref) for e in c.get("evidence") or []]
                if k == "mapping":
                    v = c.get("value") or {}
                    val = loc(v.get("from") if str(sub).startswith("source.") and isinstance(v, dict) and "from" in v else v)
                    if val is None and not c.get("value") and len(ev) == 1:
                        val = loc(ev[0])             # an agent's mapping: the one cell it cites is what it asserts
                    if dec == "Correct" and corr.get("type") == "cell":
                        pr = portable_ref(run_dir, corr["value"])
                        val, ev = loc(pr), [pr]
                    elif dec == "Correct":
                        val = None
                elif k == "revision":
                    v = c.get("value") or {}
                    val = ("pair", num15((v.get("as_reported_at_period") or {}).get("value")),
                           num15((v.get("later_known_value") or {}).get("value"))) if dec == "Approve" else value_of_answer(corr.get("value"))
                else:
                    val = ("text", norm_text(corr.get("value") if dec == "Correct" else c.get("statement")))
                add(iid, "memory", k, sub, val, ev, {"memory_status": c.get("memory_status")})
            elif t == "judgment" and iid in hjs:
                j = hjs[iid]
                ans = corr.get("value") if dec == "Correct" else j.get("suggested")
                add(iid, "judgment", "judgment", j.get("decision_key") or iid, value_of_answer(ans),
                    j.get("cells_portable") or [_portable(run_dir, x, portable_ref) for x in j.get("cells_affected") or []],
                    {"memory_status": "differs" if j.get("in_memory") else None})
            elif t == "proposal" and iid in pcs:
                it = pcs[iid]
                tgt = _portable(run_dir, it.get("target"), portable_ref) if it.get("target") else None
                if it.get("always_confirm") and tgt:
                    v = corr.get("value") if dec == "Correct" and corr.get("type") == "number" else (it.get("current") or {}).get("value")
                    n = num15(v)
                    add(iid, "proposal", "assumption_value", f"value.{tgt['sheet'].lower()}!{tgt['cell'].lower()}",
                        ("num", n) if n is not None else None, [tgt], {"memory_status": "differs" if it.get("in_memory") else None})
                elif it.get("kind") == "update_from_source" and tgt:
                    fr = (it.get("rule") or {}).get("from")
                    fr = fr[0] if isinstance(fr, list) and fr else fr
                    if dec == "Correct" and corr.get("type") == "cell":
                        fr = corr["value"]
                    elif dec == "Correct":
                        fr = None                     # a typed number for this quarter says nothing about where it lives
                    if fr is not None:
                        pf = _portable(run_dir, fr, portable_ref)
                        add(iid, "proposal", "mapping", f"source.{tgt['sheet'].lower()}!{tgt['cell'].lower()}", loc(pf), [pf, tgt])
                elif tgt and dec == "Approve" and loc(tgt) in chain_at:
                    add(iid, "proposal", "mapping", chain_at[loc(tgt)], loc(tgt), [tgt])
        note = (d.get("memory_note") or "").strip()
        if note and dec:
            if t == "memory" and iid in cands:
                base = cands[iid]["subject"]
            elif t == "judgment" and iid in hjs:
                base = hjs[iid].get("decision_key") or iid
            elif t == "proposal" and iid in pcs and pcs[iid].get("target"):
                tg = portable_ref(run_dir, pcs[iid]["target"])
                base = f"value.{tg['sheet'].lower()}!{tg['cell'].lower()}"
            else:
                continue
            add(f"{iid}:note", "note", "analyst_rule", f"rule.{base}", ("text", norm_text(note)), [])
    return C


def entry_claim(e):
    """a memory entry in force -> a claim (source: memory)."""
    k, v = e.get("kind"), e.get("value")
    if k == "mapping":
        val = loc(v.get("from") if isinstance(v, dict) and "from" in v and not v.get("corrected") else v)
    elif k == "revision":
        val = ("pair", num15((v or {}).get("as_reported_at_period", {}).get("value")), num15((v or {}).get("later_known_value", {}).get("value"))) \
            if isinstance(v, dict) and "as_reported_at_period" in v else value_of_answer(v if v is not None else e.get("statement"))
    elif k == "assumption_value":
        n = num15(v)
        val = ("num", n) if n is not None else None
    elif k == "judgment":
        val = value_of_answer(v)
    else:
        val = ("text", norm_text(e.get("statement")))
    sub = str(e.get("subject_key", "")).split(":", 1)[1] if ":" in str(e.get("subject_key", "")) else e.get("subject")
    return {"item": e.get("entry_id"), "item_type": "memory entry", "kind": k, "concept": concept_key(k, sub), "subject": sub,
            "value": val, "cells": [x for x in e.get("evidence") or [] if loc(x)], "period": e.get("period") or ((e.get("run") or {}).get("quarter_end") or "")[:7] or None,
            "source": "memory", "confirmed_by": e.get("confirmed_by")}


def _gid(keys):
    return "CG-" + hashlib.sha256(json.dumps(sorted(set(keys))).encode()).hexdigest()[:12]


def gate(claims, memory_in_force=None):
    """-> {"groups": [...], "stopped_items": [...]} . memory_in_force: {subject_key: entry} or None."""
    mem = [entry_claim(e) for e in (memory_in_force or {}).values()]
    by = {}
    for c in claims:
        by.setdefault(c["concept"], []).append(c)
    groups, stopped = [], set()

    def stop(status, keys, items, reason):
        ids_ = {x["item"] for x in items}             # a stopped concept stops whole: every confirmation of it in this review
        items = list(items) + [x for k_ in keys for x in by.get(k_, []) if x["item"] not in ids_ and not ids_.add(x["item"])]
        g = {"group_id": _gid(keys), "status": status, "concept_keys": sorted(set(keys)), "reason": reason,
             "items": [{"item": x["item"], "item_type": x["item_type"], "source": x["source"], "says": show(x["value"]),
                        "period": x.get("period"), "confirmed_by": x.get("confirmed_by")} for x in items],
             "cells": [c_ for x in items for c_ in x.get("cells") or []]}
        seen = set()
        g["cells"] = [c_ for c_ in g["cells"] if not (loc(c_) in seen or seen.add(loc(c_)))]
        if g["group_id"] not in {x["group_id"] for x in groups}:
            groups.append(g)
        stopped.update(x["item"] for x in items if x["source"] == "review")
    # 1. one concept, two confirmed values in this review
    for k, cl in sorted(by.items()):
        vals = {x["value"] for x in cl}
        if len(cl) < 2 or len(vals) == 1:
            continue
        if None in vals:
            stop("identity_uncertain", [k], cl, f"{k}: confirmed more than once and one confirmation cannot be compared with the other")
        else:
            stop("conflict", [k], cl, f"{k}: confirmed with {len(vals)} different values in this review")
    # 2. against memory in force (same period, not shown side by side)
    for m in mem:
        for x in by.get(m["concept"], []):
            if x["item"] in stopped or x["value"] is None or m["value"] is None or x["value"] == m["value"]:
                continue
            if x.get("period") and m.get("period") and x["period"] != m["period"]:
                continue                                  # a later quarter's confirmation supersedes; not a contradiction
            if x.get("memory_status") == "differs":
                continue                                  # the person saw memory beside this reading and chose
            stop("conflict", [m["concept"]], [x, m], f"{m['concept']}: memory in force for {m.get('period')} says {show(m['value'])}; "
                 f"this review confirms {show(x['value'])}")
    # 3. identity uncertain across concepts (nothing is merged)
    live = [x for x in claims if x["item"] not in stopped]
    pool = live + mem
    for i, a in enumerate(pool):
        for b in pool[i + 1:]:
            if a["source"] == "memory" and b["source"] == "memory":
                continue
            if a["concept"] == b["concept"] or a["item"] in stopped or b["item"] in stopped:
                continue
            why = None
            if (a["kind"] == b["kind"] == "mapping" and not a["subject"].startswith("source.") and not b["subject"].startswith("source.")
                    and a["value"] and a["value"] == b["value"] and a["value"][0] == "loc"):
                why = f"{a['concept']} and {b['concept']} are both placed on {show(a['value'])}"
            elif {a["kind"], b["kind"]} == {"judgment", "assumption_value"}:
                j, v = (a, b) if a["kind"] == "judgment" else (b, a)
                jl = [loc(c_) for c_ in j.get("cells") or []]
                if (len(jl) == 1 and v.get("cells") and jl[0] == loc(v["cells"][0]) and j["value"] and j["value"][0] == "num"
                        and v["value"] and j["value"] != v["value"] and (j.get("period") == v.get("period"))):
                    why = f"an answered decision gives {show(j['value'])} for the cell where {v['concept']} is {show(v['value'])}"
            elif (a["kind"] in TEXT_KINDS + ("analyst_rule",) and b["kind"] in TEXT_KINDS + ("analyst_rule",) and a["kind"] != b["kind"]
                  and norm_subject(a["subject"]).split(".")[-1] == norm_subject(b["subject"]).split(".")[-1]
                  and a["value"] != b["value"] and a.get("period") == b.get("period")):
                why = f"the same subject is a {a['kind']} and a {b['kind']} with different wording"
            if why:
                stop("identity_uncertain", [a["concept"], b["concept"]], [a, b], why)
    return {"groups": groups, "stopped_items": sorted(stopped),
            "counts": {"conflict": sum(g["status"] == "conflict" for g in groups),
                       "identity_uncertain": sum(g["status"] == "identity_uncertain" for g in groups)}}


def question(g):
    says = "; ".join(f"{x['says']} ({x['source']}{', ' + x['period'] if x.get('period') else ''})" for x in g["items"])
    if g["status"] == "conflict":
        return f"Contradiction - {', '.join(g['concept_keys'])} was confirmed with different values: {says}. Which one is right?"
    return (f"Same item or different? Code cannot tell whether these are one valuation item or two: {says} ({g['reason']}). "
            "Say which, and which value holds.")


def coherence(m):
    """company memory -> problems (empty = one coherent confirmed state per concept)."""
    import memory as MEM
    P = []
    cur = MEM.current(m)
    by = {}
    for e in cur.values():
        c = entry_claim(e)
        by.setdefault(c["concept"], []).append(c)
    for k, cl in sorted(by.items()):
        vals = {x["value"] for x in cl if x["value"] is not None}
        if len(vals) > 1:
            P.append(f"{k}: {len(vals)} different confirmed values are in force ({'; '.join(show(v) for v in vals)})")
    seen = {}
    for e in m.get("entries") or []:
        key = (e.get("subject_key"), e.get("review_sha256"))
        c = entry_claim(e)
        if key in seen and seen[key] != c["value"] and c["value"] is not None and seen[key] is not None:
            P.append(f"{e.get('subject_key')}: one review (…{str(e.get('review_sha256'))[-8:]}) wrote two different values: "
                     f"{show(seen[key])} and {show(c['value'])}")
        seen.setdefault(key, c["value"])
    return P
