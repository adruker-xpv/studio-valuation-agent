# handoff.py (build 13.2.6: also builds from a run read back from its review bundle - restored/, never from fetched copies)
# handoff.py (build 13.2.5) - the generation handoff: one machine-readable file the quarterly workbook generator starts from.
# Plain code: it only collects what onboarding already established and a person confirmed; it adds no interpretation, and
# nothing pending, stopped or not approved is presented as settled.
#   python scripts/handoff.py build --run-dir run --memory <Company>.memory.json
# -> run/generation_handoff.json, uploaded as <run id>_generation_handoff.json to
#    /Shared Documents/Valuations/6.generation_handoff/<Company>/<YYYY>/<Qn>[_rN]/
# Refuses (writes nothing) unless: the source set is unlocked, the review was accepted against its snapshot, the memory file is
# intact and coherent, and the memory holds this run's confirmations.
import argparse, datetime, hashlib, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import concepts as CG  # noqa: E402
import guard as G  # noqa: E402
import memory as MEM  # noqa: E402
import run_manifest as RM  # noqa: E402

SCHEMA = "xpv-generation-handoff/1"
BUILD = "13.2.6"
UPDATE_KINDS = ("advance_period_label", "roll_window", "update_from_source", "carry_forward", "analyst_input", "record_revision")
RULES = [
    "Only items in confirmed_memory, approved_changes and approved_relationships are settled. Everything in unresolved stays "
    "unresolved: do not apply it, do not guess it; ask the analyst.",
    "A stored location is a lead, not permission: before writing a cell, check its workbook role, sheet, row/column labels, period "
    "and formula context match the concept. If they do not, find the concept again by meaning; a location match alone never "
    "allows an overwrite.",
    "protected_formulas stay live formulas: never replace them with typed values.",
    "A source workbook whose contents fingerprint differs from sources[] for the same period is a different source set: stop.",
    "AI never types into a workbook; code writes, a person approves, and the multiple is always confirmed.",
]


class HandoffError(Exception):
    pass


def sha_file(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def _load(run_dir, name):
    p = os.path.join(run_dir, name)
    if not os.path.exists(p):
        raise HandoffError(f"{name} is missing - the review must be read (review accepted) before a handoff")
    return G.check_json_file(p, name)


def build(run_dir, memory_path):
    try:
        RM.require_same_sources(run_dir)
    except RM.ManifestError as x:
        raise HandoffError(str(x))
    man = RM.load(run_dir)
    if not man:
        raise HandoffError("this run has no run manifest (built before 13.2.3) - run a 13.2.5 onboarding for a handoff")
    D = _load(run_dir, "review_decisions.json")
    ac = _load(run_dir, "approved_changes.json")
    import review_xlsx as RX
    try:
        pc, snap_rel = RX.load_snapshot(run_dir, D.get("snapshot_sha256"))
        RX.check_snapshot_sources(run_dir, pc)
    except ValueError as x:
        raise HandoffError(str(x.args[0][0] if x.args and isinstance(x.args[0], list) else x))
    if not os.path.exists(memory_path):
        raise HandoffError(f"the company memory file {os.path.basename(memory_path)} is not here - fetch it first")
    m = MEM.load(memory_path)
    P = MEM.check_chain(m) + CG.coherence(m)
    if P:
        raise HandoffError("company memory is not intact or not coherent: " + "; ".join(P[:5]))
    if (((RM.review_package(run_dir) or man.get("review_package") or {}).get("memory_applied")) or {}).get("review_sha256") != D.get("review_sha256"):
        raise HandoffError("memory has not been written from this review yet - write memory first, then build the handoff")
    import bundle as BU
    ctx = BU.restored(run_dir, "verified_context")
    if os.path.exists(os.path.join(run_dir, "extraction.json")):
        X = json.load(open(os.path.join(run_dir, "extraction.json")))
        V = json.load(open(os.path.join(run_dir, "verification.json"))) if os.path.exists(os.path.join(run_dir, "verification.json")) else {}
    elif ctx:
        X, V = ctx, {"status": (ctx.get("verification") or {}).get("status"), "edges": (ctx.get("verification") or {}).get("edges") or {}}
    else:
        raise HandoffError("the run's verified context is not here - read the completed review first")
    port = lambda r: MEM.portable_ref(run_dir, r) if isinstance(r, dict) and "source" in r else r
    if man.get("restored"):
        rs = BU.restored(run_dir, "sources") or []
        ss = RM.source_set(run_dir) or {}
        srcs = {"content_sha256": ss.get("content_sha256"), "files": [{"id": x["id"], "original_file": x["original_file"], "sha256": x["sha256"],
                                                                      "content_sha256": x.get("content_sha256"), "discovered_role": x.get("role"),
                                                                      "role_period": x.get("role_period")} for x in rs]}
    else:
        srcs = (RM.refresh(run_dir, dict(man)).get("sources") or {})
    vb = pc["valuation_workbook"]
    vrow = next((f for f in srcs.get("files") or [] if f["id"] == vb["id"]), {})
    cur = MEM.current(m)
    pend = MEM.pending(m)

    def entry(e):
        return {k: e.get(k) for k in ("entry_id", "kind", "type", "subject_key", "statement", "value", "period", "evidence",
                                       "confirmed_by", "confirmed_at", "supersedes")}
    confirmed = [entry(e) for _, e in sorted(cur.items())]
    mappings = []
    for e in confirmed:
        if e["kind"] == "mapping":
            v = e.get("value") or {}
            mappings.append({"concept": e["subject_key"].split(":", 1)[1], "last_confirmed_location": v.get("from") if "from" in v else v,
                             "target": v.get("target"), "relation": v.get("relation"), "statement": e["statement"],
                             "period": e["period"], "entry_id": e["entry_id"], "confirmed_by": e["confirmed_by"]})
    precedence = [e for e in confirmed if e["kind"] == "source_precedence"] + \
                 [e for e in confirmed if e["kind"] == "mapping" and str(e["subject_key"]).startswith("mapping:source.")]
    approved = ac.get("approved_changes") or []
    stopped = set(ac.get("stopped") or []) | set(((D.get("concept_gate") or {}).get("stopped_items")) or [])

    def change(it):
        return {"id": it["id"], "kind": it["kind"], "what": it.get("what"), "target": port(it.get("target")),
                "rule": json.loads(json.dumps(it.get("rule") or {}, default=str), object_hook=lambda d: port(d) if "source" in d and "cell" in d else d),
                "current_formula": (it.get("current") or {}).get("formula"), "always_confirm": bool(it.get("always_confirm")),
                "decision": it.get("decision"), "correction": it.get("correction"), "reused_from_memory": it.get("reused_from_memory")}
    updateable = [change(it) for it in approved if it["kind"] in UPDATE_KINDS and it["id"] not in stopped]
    protected = [change(it) for it in approved if it["kind"] == "keep_formula" and it["id"] not in stopped]
    rel = []
    for e in (X.get("provenance") or []) + (X.get("downstream") or []):
        if not isinstance(e, dict):
            continue
        ev_ = (V.get("edges") or {}).get(e.get("id")) if isinstance(V.get("edges"), dict) else None
        st = ev_.get("status") if isinstance(ev_, dict) else ev_
        if st is None and isinstance(V.get("edges"), list):
            st = next((x.get("status") for x in V["edges"] if isinstance(x, dict) and x.get("id") == e.get("id")), None)
        rel.append({"id": e.get("id"), "from": port(e.get("from")), "to": port(e.get("to")), "class": e.get("class"),
                    "relation": e.get("relation"), "what": e.get("what"), "verified": st})
    chain = {k: (port(dict(v, source=v.get("source") or (X.get("chain") or {}).get("source"))) if isinstance(v, dict) and v.get("cell") else v)
             for k, v in (X.get("chain") or {}).items() if k not in ("bridge", "waterfall")}
    not_approved = [x for x in ac.get("not_approved") or []]
    unresolved = {"pending_decisions": [{"decision_key": p_["decision_key"], "question": p_["question"], "cells": p_.get("cells"),
                                         "first_seen": p_.get("first_seen"), "also_keys": p_.get("also_keys") or [],
                                         "reason": p_.get("reason") or "left blank by the analyst"} for p_ in pend],
                  "stopped_concepts": (D.get("concept_gate") or {}).get("groups") or [],
                  "changes_not_approved": not_approved,
                  "verification_status": V.get("status")}
    blockers = []
    if V.get("status") != "VERIFIED":
        blockers.append(f"verification is {V.get('status')}, not VERIFIED")
    status = "blocked" if blockers else ("ready_with_unresolved" if unresolved["pending_decisions"] or unresolved["stopped_concepts"]
                                         or not_approved else "ready")
    doc = {"schema": SCHEMA, "made_by": f"handoff {BUILD}", "made_at": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
           "status": status, "blockers": blockers,
           "identity": {"run_id": man["run_id"], "company_key": man["company_key"], "company_as_named": X.get("company"),
                        "period": man["period"], "quarter_end": man["quarter_end"], "next_quarter_end": pc.get("next_quarter_end"),
                        "run_folder": man["folders"]["run"], "extractor_build": man.get("build"), "proposals_made_by": pc.get("made_by")},
           "approved_workbook": {"source_id": vb["id"], "original_file": vrow.get("original_file") or vb.get("file"), "sha256": vb["sha256"],
                                 "content_sha256": vrow.get("content_sha256"), "role": vrow.get("discovered_role"),
                                 "approved_by": D.get("reviewer"), "approved_at": D.get("read_at"), "review_sha256": D.get("review_sha256")},
           "sources": srcs.get("files") or [], "fingerprints": {"source_set_sha256": srcs.get("content_sha256"),
                                                               "proposals_snapshot_sha256": D.get("snapshot_sha256"),
                                                               "review_sha256": D.get("review_sha256"),
                                                               "review_bundle_sha256": D.get("bundle_sha256"),
                                                               "memory_file_sha256": sha_file(memory_path)},
           "confirmed_memory": {"file": man["folders"]["memory"], "entries": confirmed},
           "semantic_mappings": mappings, "source_precedence": precedence, "valuation_chain": chain,
           "approved_relationships": rel, "approved_changes": updateable + protected, "updateable_inputs": updateable,
           "protected_formulas": protected, "unresolved": unresolved, "rules_for_generation": RULES}
    G.check_doc(doc, "generation_handoff")
    with open(os.path.join(run_dir, "generation_handoff.json"), "w", encoding="utf-8") as fh:
        fh.write(json.dumps(doc, indent=1, sort_keys=True, ensure_ascii=False, default=str) + "\n")
    return doc


def main(argv=None):
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("build")
    p.add_argument("--run-dir", default="run")
    p.add_argument("--memory", required=True)
    a = ap.parse_args(argv)
    try:
        d = build(a.run_dir, a.memory)
    except HandoffError as x:
        print(f"HANDOFF: refused | {x} | nothing was written")
        return 1
    u = d["unresolved"]
    print(f"HANDOFF: {d['status']} | {len(d['confirmed_memory']['entries'])} confirmed memory items, {len(d['updateable_inputs'])} updateable "
          f"inputs, {len(d['protected_formulas'])} protected formulas | unresolved: {len(u['pending_decisions'])} pending, "
          f"{len(u['stopped_concepts'])} stopped, {len(u['changes_not_approved'])} changes not approved"
          + (f" | blockers: {'; '.join(d['blockers'])}" if d["blockers"] else "")
          + f" | UPLOAD: {RM.upload_text(a.run_dir, ['generation_handoff.json'])}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
