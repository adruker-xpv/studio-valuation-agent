# checkpoint.py (build 13.2.5: `sufficiency` says whether the material valuation chain is established, so tracing stops there
# unless one of the listed reasons applies; no workbook size, sheet count or row count is used)
# checkpoint.py (build 13.2.3: refuses to save or continue while the source set is locked; UPLOAD lists contract names)
# checkpoint.py (build 13.2) - durable progress for long AI-led investigations. The agent writes one small stage file at a time;
# this script checks it, stores it append-only under checkpoints/, and immediately rebuilds the primary result from all the
# stages saved so far - so a usable (provisional) extraction exists from stage 3 on, and a run that dies keeps everything it saved.
#   status   --run-dir R [--kind extraction|blind|review]          what is saved, what is next, the next stage's goal and budget
#   save     --run-dir R --stage N --file draft.json [--kind ...]  validate + store stage N (a re-save is stored as a revision)
#   assemble --run-dir R [--kind ...]                              rebuild extraction.json / reviewer_blind.json / review.json
# Stage files are never overwritten: checkpoints/03_chain.json, then 03_chain.r2.json, ... The latest revision of each stage wins.
# The primary result is derived from the checkpoints, so a resumed run (or anyone auditing it) can rebuild it exactly.
# Build 13.2: stage 7 is "proposals" (saving it makes code build proposed_changes.json) and validation moved to stage 8.
# A 13.0 run (seven stages, validation saved as 07_validation.json) still assembles: if that validation is current for
# stages 2-6 the extraction stays final (legacy_13_0) and status offers stage 7 to add proposals.
import argparse, datetime, glob, hashlib, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from onboarding_schema import STAGES, SCHEMA_VERSION, stage_info, stage_by_name, validate_stage  # noqa: E402

OUTPUT = {"extraction": "extraction.json", "blind": "reviewer_blind.json", "review": "review.json"}
SCHEMA = {"extraction": "xpv-onboarding-extraction/4", "blind": "xpv-onboarding-blind/2", "review": "xpv-onboarding-review/2"}
CK_DIR = {"extraction": "checkpoints", "blind": "checkpoints", "review": "checkpoints_review"}
VALIDATION = 8                     # extraction stage written by verify.py --final (stage 7 in build 13.0)
PROPOSALS = 7
EXTRACTION_CORE = [2, 3, 4, 5, 6]  # the stages a 13.0 extraction had


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")


def ck_dir(run_dir, kind):
    return os.path.join(run_dir, CK_DIR[kind])


def latest(run_dir, kind, n):
    """the newest revision of stage n -> (path, doc) or (None, None)."""
    st = stage_info(kind, n)
    base = os.path.join(ck_dir(run_dir, kind), f"{n:02d}_{st[1]}")
    files = [p for p in glob.glob(base + "*.json") if re.fullmatch(re.escape(base) + r"(\.r\d+)?\.json", p)]
    if not files:
        return None, None
    rev = lambda p: int(re.search(r"\.r(\d+)\.json$", p).group(1)) if ".r" in os.path.basename(p) else 1
    p = max(files, key=rev)
    return p, json.load(open(p))


def latest_named(run_dir, kind, n, name):
    base = os.path.join(ck_dir(run_dir, kind), f"{n:02d}_{name}")
    files = [p for p in glob.glob(base + "*.json") if re.fullmatch(re.escape(base) + r"(\.r\d+)?\.json", p)]
    if not files:
        return None, None
    rev = lambda p: int(re.search(r"\.r(\d+)\.json$", p).group(1)) if ".r" in os.path.basename(p) else 1
    p = max(files, key=rev)
    return p, json.load(open(p))


def sha_file(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def context(run_dir, kind, exclude=None):
    """ids/sheets from stage 1 (sources), plus ids already used by other saved stages."""
    p = os.path.join(run_dir, "checkpoints", "01_sources.json")
    if not os.path.exists(p):
        return None
    d = json.load(open(p))
    w = {s["id"]: [x["name"] for x in s.get("sheets", [])] for s in d["sources"]}
    x = {e["id"]: [] for e in d.get("external", [])}
    ctx = {"ids": set(w) | set(x), "sheets": w, "w_ids": set(w), "edge_ids": set(), "sources_doc": d}
    if kind != "review":
        for st in STAGES[kind]:
            if st[2] != "agent" or st[0] == exclude:
                continue
            _, doc = latest(run_dir, kind, st[0])
            for key in ("provenance", "downstream", "discrepancies"):
                for e in (doc or {}).get(key) or []:
                    if isinstance(e, dict) and e.get("id"):
                        ctx["edge_ids"].add(e["id"])
    return ctx


def merge_by_id(*lists, key=lambda x: x.get("id")):
    out, pos = [], {}
    for lst in lists:
        for x in lst or []:
            k = key(x) if isinstance(x, dict) else json.dumps(x, sort_keys=True)
            if k is not None and k in pos:
                out[pos[k]] = x
            else:
                if k is not None:
                    pos[k] = len(out)
                out.append(x)
    return out


def assemble(run_dir, kind, quiet=False, override=None):
    out = collect(run_dir, kind, override)
    if out is not None:
        json.dump(out, open(os.path.join(run_dir, OUTPUT[kind]), "w"), indent=1, ensure_ascii=False)
    return out


def collect(run_dir, kind, override=None, rebuild=True):
    """the primary result from the saved stages (override = {n: doc} to include a stage not yet saved). Writes nothing."""
    stages = {st[0]: latest(run_dir, kind, st[0]) for st in STAGES[kind]}
    for n, d in (override or {}).items():
        stages[n] = ("(pending)", d)
    done = [n for n, (p, _) in stages.items() if p]
    D = {n: d for n, (p, d) in stages.items() if p}
    if kind == "review":
        d = D.get(1)
        if not d:
            return None
        out = dict(d, schema=SCHEMA[kind], made_by=f"checkpoint {SCHEMA_VERSION}", status="final")
        p1 = os.path.join(run_dir, "checkpoints", "01_sources.json")
        if os.path.exists(p1):
            out["workbook_sha256s"] = sorted(s["sha256"] for s in json.load(open(p1))["sources"])
        return out
    src = D.get(1) or {}
    roles = D.get(2) or {}
    core = D.get(3 if kind == "extraction" else 2) or {}
    if kind == "blind":
        roles = D.get(2) or {}
    rmap = {s["id"]: s for s in roles.get("sources") or [] if isinstance(s, dict)}
    sources = [{"id": s["id"], "file": s["file"], "sha256": s["sha256"], **{k: v for k, v in rmap.get(s["id"], {}).items() if k != "id"}}
               for s in src.get("sources", [])]
    external = [{**x, **{k: v for k, v in rmap.get(x["id"], {}).items() if k != "id"}} for x in src.get("external", [])]
    agent_stages = [st[0] for st in STAGES[kind] if st[2] == "agent"]
    all_agent = [D.get(n) or {} for n in agent_stages]
    out = {"schema": SCHEMA[kind], "made_by": f"checkpoint {SCHEMA_VERSION} (assembled from {CK_DIR[kind]}/)",
           "assembled_at": now(), "status": "provisional",
           "stages_done": done, "stages_pending": [st[0] for st in STAGES[kind] if st[0] not in done],
           "produced_by": roles.get("produced_by"), "company": roles.get("company"), "quarter_end": roles.get("quarter_end"),
           "sources": sources, "external": external,
           "valuation_workbook": roles.get("valuation_workbook"), "fund_workbook": roles.get("fund_workbook"),
           "chain": core.get("chain"), "path": core.get("path"), "direction": core.get("direction"),
           "provenance": merge_by_id(*[d.get("provenance") for d in all_agent]),
           "downstream": merge_by_id(*[d.get("downstream") for d in all_agent]),
           "discrepancies": merge_by_id(*[d.get("discrepancies") for d in all_agent]),
           "rejected": merge_by_id(*[d.get("rejected") for d in all_agent], key=lambda x: f"{x.get('source')}|{x.get('cell')}"),
           "inputs": merge_by_id(*[d.get("inputs") for d in all_agent], key=lambda x: f"{x.get('source')}|{x.get('cell')}"),
           "open_questions": merge_by_id(*[d.get("open_questions") for d in all_agent], key=lambda x: x),
           "deferred": merge_by_id(*[d.get("deferred") for d in all_agent], key=lambda x: x),
           "how_it_works": next((d.get("how_it_works") for d in reversed(all_agent) if d.get("how_it_works")), None),
           "evidence": {"notes": "notes.md" if kind == "extraction" else "notes_blind.md", "inventory": "evidence/inventory/",
                        "checkpoints": CK_DIR[kind] + "/"}}
    if kind == "blind":
        ch = D.get(3) or {}
        out.update(challenges=ch.get("challenges") or [], questions=ch.get("questions") or [], notes=ch.get("notes"))
        out.pop("inputs", None)
        out.pop("deferred", None)
        if 2 in done and 3 in done:
            out["status"] = "final"
    if kind == "extraction":
        st7 = D.get(PROPOSALS)
        pc_path = os.path.join(run_dir, "proposed_changes.json")
        if st7 is not None:
            pc = json.load(open(pc_path)) if os.path.exists(pc_path) else None
            fresh_pc = bool(pc) and pc.get("inputs_sha256") == proposals_inputs_sha(run_dir, stages)
            if not fresh_pc and rebuild and not override:      # a resumed run (checkpoints only): proposals are derived - rebuild them
                try:
                    import proposals as PR
                    pc = PR.write(run_dir, PR.build(run_dir), proposals_inputs_sha(run_dir))
                    fresh_pc = True
                except Exception:  # noqa: BLE001 - workbooks not inventoried yet etc.: report stale below, never crash
                    pass
            if pc:
                out["proposed_changes"] = pc.get("proposed_changes") or []
                out["human_judgments"] = pc.get("human_judgments") or []
                out["memory_candidates"] = pc.get("memory_candidates") or []
                out["next_quarter_end"] = pc.get("next_quarter_end")
                out["proposals"] = {"file": "proposed_changes.json", "inputs_sha256": pc.get("inputs_sha256"), "current": fresh_pc,
                                    "counts": pc.get("counts")}
            if not fresh_pc:
                out["proposals"] = dict(out.get("proposals") or {}, current=False,
                                        note="a stage or workbook changed after the proposals were built: save stage 7 again")
        vp, vd = latest(run_dir, kind, VALIDATION)
        if vd:
            current = {str(n): sha_file(stages[n][0]) for n in agent_stages if stages[n][0] and stages[n][0] != "(pending)"}
            fresh = vd.get("stage_hashes") == current
            out["verification"] = {"status": vd.get("status"), "verify_version": vd.get("verify_version"), "at": vd.get("made_at"),
                                   "counts": vd.get("counts"), "current": fresh}
            if fresh and all(n in done for n in agent_stages) and (out.get("proposals") or {}).get("current"):
                out["status"] = "final"
            elif not fresh:
                out["verification"]["note"] = "a stage was saved after validation: run verify.py --final again"
        elif PROPOSALS not in done:
            lp, ld = latest_named(run_dir, kind, 7, "validation")          # a build 13.0 run: validation was stage 7
            if ld:
                current = {str(n): sha_file(stages[n][0]) for n in EXTRACTION_CORE if stages[n][0]}
                fresh = ld.get("stage_hashes") == current
                out["verification"] = {"status": ld.get("status"), "verify_version": ld.get("verify_version"), "at": ld.get("made_at"),
                                       "counts": ld.get("counts"), "current": fresh, "legacy_13_0": True}
                if fresh and all(n in done for n in EXTRACTION_CORE):
                    out["status"] = "final"
                    out["legacy_13_0"] = ("a build 13.0 seven-stage run, validated before proposals existed: final as an extraction; "
                                          "save stage 7 (proposals) and run verify.py --final to add proposed changes")
    if kind == "extraction" and src.get("sources"):
        out["workbook_sha256"] = next((s["sha256"] for s in src["sources"] if s["id"] == out["valuation_workbook"]), None)
    return out


def proposals_inputs_sha(run_dir, stages=None):
    """what proposed_changes.json is derived from: the latest stage files 1-7 and this build of proposals.py."""
    stages = stages or {st[0]: latest(run_dir, "extraction", st[0]) for st in STAGES["extraction"]}
    h = hashlib.sha256()
    for n in range(1, PROPOSALS + 1):
        p = (stages.get(n) or (None, None))[0]
        if n == 1:
            p = os.path.join(run_dir, "checkpoints", "01_sources.json")
        if p and p != "(pending)" and os.path.exists(p):           # content only: save times do not change the proposals
            d = json.load(open(p))
            d = {k: v for k, v in d.items() if k not in ("saved_at", "made_at")}
            if n == 1:
                d = {"sources": [{k: s_.get(k) for k in ("id", "file", "sha256")} for s_ in d.get("sources", [])],
                     "external": [{k: x.get(k) for k in ("id", "file")} for x in d.get("external", [])]}
            h.update(f"{n}:".encode() + json.dumps(d, sort_keys=True, ensure_ascii=False).encode())
    mp = os.path.join(run_dir, "company_memory.in.json")        # the attached company memory is an input too
    if os.path.exists(mp):
        h.update(b"memory:" + sha_file(mp).encode())
    h.update(sha_file(os.path.join(HERE, "proposals.py")).encode())
    return h.hexdigest()


def cmd_status(a):
    if _locked(a.run_dir):
        return 1
    kind = a.kind
    d = ck_dir(a.run_dir, kind)
    p1 = os.path.join(a.run_dir, "checkpoints", "01_sources.json")
    if not os.path.exists(p1):
        print(f"RUN: no checkpoints in {d}/. If this run was started before, copy the run folder's {CK_DIR[kind]}/*.json (and "
              f"checkpoints/01_sources.json) into {d}/ first, then run status again. Otherwise start: stage 1 = "
              "python scripts/xlsx_evidence.py inventory --run-dir <run dir> --workbooks <every workbook>")
        return 0
    s1 = json.load(open(p1))
    t0 = datetime.datetime.fromisoformat(s1["made_at"])
    mins = (datetime.datetime.now(datetime.timezone.utc) - t0).total_seconds() / 60
    print(f"RUN: {a.run_dir} | {kind} | started {s1['made_at']} ({mins:.0f} min ago) | {len(s1['sources'])} workbooks, "
          f"{len(s1.get('external', []))} linked files not supplied")
    nxt = None
    for st in STAGES[kind]:
        if kind == "review" and st[0] == 1:
            pass
        p, doc = latest(a.run_dir, kind, st[0]) if not (kind != "review" and st[0] == 1) else (p1, s1)
        if p and kind == "extraction" and st[0] == VALIDATION:
            v = (assemble(a.run_dir, kind).get("verification") or {})
            if not v.get("current"):
                p = None
        if p:
            when = (doc or {}).get("saved_at") or (doc or {}).get("made_at") or ""
            print(f"STAGE {st[0]} {st[1]:<11} | done {when} | {os.path.relpath(p, a.run_dir)}")
        else:
            ready = all(latest(a.run_dir, kind, q)[0] or (q == 1 and kind != "review") for q in st[3])
            if kind == "extraction" and st[0] == VALIDATION and latest(a.run_dir, kind, VALIDATION)[0]:
                print(f"STAGE {st[0]} {st[1]:<11} | out of date (a stage was saved after the last verify --final)" if ready else
                      f"STAGE {st[0]} {st[1]:<11} | to do")
                if ready and nxt is None:
                    nxt = st
                continue
            mark = "NEXT" if nxt is None and ready else "to do"
            if mark == "NEXT":
                nxt = st
            print(f"STAGE {st[0]} {st[1]:<11} | {mark}")
    if kind != "review":
        out = assemble(a.run_dir, kind)
        v = out.get("verification") or {}
        print(f"RESULT: {OUTPUT[kind]} {out['status'].upper()} | stages done {out['stages_done']} | verify {v.get('status', 'not run')}"
              + ("" if v.get("current", True) else " (out of date)") + (" | LEGACY 13.0 run: " + out["legacy_13_0"] if out.get("legacy_13_0") else "")
              + ("" if (out.get("proposals") or {}).get("current", True) else " | PROPOSALS OUT OF DATE: save stage 7 again"))
    if nxt:
        cmd = ("python scripts/verify.py --run-dir <run dir> --final" if nxt[2] == "script" and nxt[0] == VALIDATION else
               f"python scripts/checkpoint.py save --run-dir <run dir> --kind {kind} --stage {nxt[0]} --file <your draft>.json")
        bud = f" | budget about {nxt[6]} reader calls" if nxt[6] else ""
        print(f"NEXT: stage {nxt[0]} {nxt[1]} - {nxt[5]}{bud} | then: {cmd}")
    else:
        print("NEXT: nothing - every stage is saved. Upload the files, end with your JSON line, and stop.")
    return 0


def _locked(run_dir):
    import run_manifest as RM
    try:
        RM.require_same_sources(run_dir)
    except RM.ManifestError as x:
        print(f"CHECKPOINT: {x}")
        return True
    return False


def _has_manifest(run_dir):
    return os.path.exists(os.path.join(run_dir, "run_manifest.json"))


def _up(run_dir, names):
    import run_manifest as RM
    return RM.upload_text(run_dir, names)


def cmd_save(a):
    if _locked(a.run_dir):
        return 1
    kind = a.kind
    st = stage_by_name(kind, a.stage)
    if not st:
        print(f"CHECKPOINT: rejected | no stage {a.stage!r} for {kind}: {', '.join(f'{s[0]} {s[1]}' for s in STAGES[kind])}")
        return 1
    n = st[0]
    if st[2] == "script":
        print(f"CHECKPOINT: rejected | stage {n} {st[1]} is written by a script ({st[5]})")
        return 1
    ctx = context(a.run_dir, kind, exclude=n)
    if ctx is None:
        print("CHECKPOINT: rejected | stage 1 (sources) is missing: run xlsx_evidence.py inventory first (or copy the run folder's "
              "checkpoints/ here when resuming)")
        return 1
    if kind != "review":
        missing = [q for q in st[3] if q != 1 and not latest(a.run_dir, kind, q)[0]]
        if missing:
            print(f"CHECKPOINT: rejected | stage {n} needs stage(s) {', '.join(map(str, missing))} first")
            return 1
    try:
        doc = json.load(open(a.file))
    except (OSError, ValueError) as e:
        print(f"CHECKPOINT: rejected | {a.file} is not valid JSON ({e})")
        return 1
    if not isinstance(doc, dict):
        print("CHECKPOINT: rejected | a stage file is one JSON object")
        return 1
    P = validate_stage(kind, n, doc, ctx)
    built = None
    if not P and kind == "extraction" and (n == PROPOSALS or latest(a.run_dir, kind, PROPOSALS)[0]):
        import proposals as PR                     # code, not the agent, derives the proposed changes
        override = {n: doc}
        if n != PROPOSALS:
            override[PROPOSALS] = latest(a.run_dir, kind, PROPOSALS)[1]
        try:
            built = PR.build(a.run_dir, override=override)
        except PR.BuildError as x:
            if n == PROPOSALS:
                P.extend(x.problems)
            else:
                print(f"CHECKPOINT: note | proposals could not be rebuilt after this change ({x.problems[0]}); save stage 7 again")
    if P:
        print(f"CHECKPOINT: rejected | stage {n} {st[1]} | {len(P)} problem(s); nothing was saved. Fix these and save again:")
        for x in P[:25]:
            print(f"  - {x}")
        return 1
    os.makedirs(ck_dir(a.run_dir, kind), exist_ok=True)
    base = os.path.join(ck_dir(a.run_dir, kind), f"{n:02d}_{st[1]}")
    p = base + ".json"
    r = 1
    while os.path.exists(p):
        r += 1
        p = f"{base}.r{r}.json"
    doc = dict(doc, stage=n, name=st[1], kind=kind, saved_at=now())
    json.dump(doc, open(p, "w"), indent=1, ensure_ascii=False)
    if built is not None:
        import proposals as PR
        PR.write(a.run_dir, built, proposals_inputs_sha(a.run_dir))
    out = assemble(a.run_dir, kind)
    rel = os.path.relpath(p, a.run_dir)
    if kind == "review":
        print(f"CHECKPOINT: saved {rel} | review.json written | UPLOAD: {rel}, review.json")
        return 0
    pend = out["stages_pending"]
    nxt = next((s for s in STAGES[kind] if s[0] in pend and all(q not in pend for q in s[3])), None)
    extra_up = ", proposed_changes.json" if built is not None else ""
    pcn = f" | proposals: {built['counts']['proposed_changes']} changes, {built['counts']['human_judgments']} unresolved decisions, " \
          f"{built['counts']['memory_candidates']} memory candidates" if built is not None else ""
    print(f"CHECKPOINT: saved {rel}{' (revision ' + str(r) + ')' if r > 1 else ''} | {OUTPUT[kind]} {out['status'].upper()} "
          f"(stages done {out['stages_done']}){pcn} | UPLOAD: "
          f"{_up(a.run_dir, [rel, OUTPUT[kind], 'notes.md'] + (['proposed_changes.json'] if built is not None else [])) if _has_manifest(a.run_dir) and kind == 'extraction' else str(rel) + ', ' + OUTPUT[kind] + extra_up}" +
          (f" | NEXT: stage {nxt[0]} {nxt[1]}" if nxt else " | NEXT: nothing - stop"))
    return 0


def cmd_assemble(a):
    out = assemble(a.run_dir, a.kind)
    if out is None:
        print("ASSEMBLE: nothing saved yet")
        return 1
    print(f"ASSEMBLE: {OUTPUT[a.kind]} {out.get('status', '').upper()} | stages done {out.get('stages_done')}")
    return 0


MATERIAL = (("method", "valuation method"), ("valuation_metric", "metric"), ("metric_window", "metric period window"),
            ("selected_multiple", "selected assumption"), ("enterprise_value", "enterprise / asset value"),
            ("equity_value", "equity value after bridge items"), ("value_to_xpv", "ownership / waterfall to XPV's value"))


def sufficiency(run_dir):
    """the material chain's coverage from the saved extraction and its verification -> (sufficient, have, missing, open_material)."""
    xp = os.path.join(run_dir, "extraction.json")
    if not os.path.exists(xp):
        return False, [], ["no extraction saved yet"], []
    X = json.load(open(xp))
    ch = X.get("chain") or {}
    have, miss = [], []
    for k, label in MATERIAL:
        (have if ch.get(k) else miss).append(label)
    if X.get("fund_workbook") or any((s.get("role") or "").startswith("fund") for s in X.get("sources") or []):
        (have if ch.get("fund_cell") and X.get("downstream") else miss).append("downstream reported value and its link")
    if 4 in (X.get("stages_done") or []):
        (have if X.get("provenance") else miss).append("where next quarter's material inputs come from")
    else:
        miss.append("where next quarter's material inputs come from (stage 4)")
    vp = os.path.join(run_dir, "verification.json")
    V = json.load(open(vp)) if os.path.exists(vp) else {}
    contra = [c for c in (V.get("edges") or []) if isinstance(c, dict) and c.get("status") == "CONTRADICTED"]
    if not V:
        miss.append("deterministic checks (run verify.py)")
    elif V.get("status") == "CONTRADICTED" or contra:
        miss.append("deterministic checks pass (something is CONTRADICTED)")
    open_m = [f"{d.get('id')}: {d.get('what')}" for d in X.get("discrepancies") or [] if isinstance(d, dict) and d.get("status") == "unresolved"]
    return not miss, have, miss, open_m


def cmd_sufficiency(a):
    ok, have, miss, open_m = sufficiency(a.run_dir)
    if ok:
        print("MATERIAL CHAIN: SUFFICIENT | " + ", ".join(have) + " | Stop tracing here. Trace further ONLY to: resolve an open material "
              "contradiction, find where a material next-quarter input comes from, explain a material value that is still "
              "unexplained, establish which source wins, or settle something a decision or memory candidate depends on. "
              "Everything else goes in `deferred` (one line each: what you saw, why it is not material).")
    else:
        print("MATERIAL CHAIN: NOT YET | still needed: " + "; ".join(miss) + " | trace only toward these")
    if open_m:
        print("OPEN MATERIAL: " + " | ".join(open_m[:15]) + " - tracing that resolves one of these is worth doing; otherwise ask the analyst")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("sufficiency")
    p.add_argument("--run-dir", default=".")
    for c in ("status", "save", "assemble"):
        p = sub.add_parser(c)
        p.add_argument("--run-dir", default=".")
        p.add_argument("--kind", default="extraction", choices=list(STAGES))
        if c == "save":
            p.add_argument("--stage", required=True)
            p.add_argument("--file", required=True)
    a = ap.parse_args(argv)
    return {"status": cmd_status, "save": cmd_save, "assemble": cmd_assemble, "sufficiency": cmd_sufficiency}[a.cmd](a)


if __name__ == "__main__":
    sys.exit(main())
