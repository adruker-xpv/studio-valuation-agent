# xlsx_evidence.py (build 13.0) - READ-ONLY evidence access to Excel workbooks. It shows what is in a file; it never
# decides what anything means (which sheet matters, which period is current, which cell is canonical: that is the model's job).
#
# Why it exists: the 12.0 reader walked every cell of a sheet's "used range". A sheet whose used range is inflated (formatting
# applied out to row 1,048,576 or column XFD) made it walk billions of empty cells and never return. This reader streams each
# sheet's XML and keeps only cells that hold a value or a formula, so inflated ranges and formatted-but-empty cells cost almost
# nothing. Formula text and Excel's saved value are kept together; shared, array and data-table formulas are shown; hidden and
# very-hidden sheets, hidden rows/columns, merged ranges, comments, defined names and links to other files are exposed.
#
# Commands (every one is read-only, prints compact text, and stops at --max-seconds with an explicit STOPPED line - never a
# silent truncation):
#   inventory --workbooks A.xlsx B.xlsx ... --run-dir R   fingerprints + inventory of every workbook; writes
#                                                          R/checkpoints/01_sources.json and R/evidence/inventory/W<n>.txt
#   sheet  --workbook W1 --sheet "P&L" [--rows 1:80] [--cols A:Z] [--max-cells 2500]   populated cells of one area
#   cells  --workbook W1 --ref "'P&L'!A1:D20" [--ref ...] [--headers 5] [--labels A:B]  named cells, with column headers / row labels
#   find   --value 1234567 [--scales 1,1000,1000000] [--tolerance 0.5]  |  --text "adjust"   numbers or text across all sources
#   refs   --to "W4:'Val'!D8"     formulas (in any source) that refer to a cell, including links from other workbooks
#   refs   --from "W4:'Val'!D8" [--depth 2]   what a cell's formula refers to, with saved values (external links resolved)
# --workbook / --to / --from accept a source id (W1..) once inventory has run in --run-dir, or a file path.
import argparse, datetime, hashlib, json, os, pickle, posixpath, re, sys, time, zipfile
import urllib.parse
import xml.etree.ElementTree as ET

VERSION = "13.0.0"
NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
CELL_RE = re.compile(r"^\$?([A-Za-z]{1,3})\$?(\d+)$")
REF_STRICT = re.compile(r"^\$?[A-Za-z]{1,3}\$?\d+(:\$?[A-Za-z]{1,3}\$?\d+)?$|^\$?[A-Za-z]{1,3}:\$?[A-Za-z]{1,3}$|^\$?\d+:\$?\d+$")
RANGE_RE = re.compile(r"^\$?([A-Za-z]{1,3})?\$?(\d+)?(?::\$?([A-Za-z]{1,3})?\$?(\d+)?)?$")
BUILTIN_FMT = {0: "General", 1: "0", 2: "0.00", 3: "#,##0", 4: "#,##0.00", 9: "0%", 10: "0.00%", 11: "0.00E+00", 14: "m/d/yyyy",
               15: "d-mmm-yy", 16: "d-mmm", 17: "mmm-yy", 18: "h:mm AM/PM", 19: "h:mm:ss AM/PM", 20: "h:mm", 21: "h:mm:ss",
               22: "m/d/yyyy h:mm", 37: "#,##0 ;(#,##0)", 38: "#,##0 ;[Red](#,##0)", 39: "#,##0.00;(#,##0.00)", 40: "#,##0.00;[Red](#,##0.00)",
               45: "mm:ss", 46: "[h]:mm:ss", 47: "mmss.0", 49: "@"}
DATE_IDS = set(range(14, 23)) | set(range(27, 37)) | {45, 46, 47} | set(range(50, 59))
DYNAMIC = re.compile(r"\b(INDIRECT|OFFSET)\s*\(", re.I)


def tag(e):
    return e.tag.rsplit("}", 1)[-1]


def col2n(s):
    n = 0
    for ch in s.upper():
        n = n * 26 + ord(ch) - 64
    return n


def n2col(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def addr(row, col):
    return f"{n2col(col)}{row}"


def parse_cell(a):
    m = CELL_RE.match(a.strip())
    return (int(m.group(2)), col2n(m.group(1))) if m else None


def parse_range(rng):
    """'A1', 'A1:B9', 'A:C', '5:9' -> (r1, c1, r2, c2) with None for open sides; anything else -> None."""
    if not REF_STRICT.match(rng.strip()):
        return None
    m = RANGE_RE.match(rng.replace("$", "").strip())
    if not m or not any(m.groups()):
        return None
    c1, r1, c2, r2 = m.groups()
    if ":" not in rng:
        c2, r2 = c1, r1
    return (int(r1) if r1 else None, col2n(c1) if c1 else None, int(r2) if r2 else None, col2n(c2) if c2 else None)


def quote_sheet(name):
    return name if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.]*", name) else "'" + name.replace("'", "''") + "'"


def split_ref(ref, here=None):
    """"'Q2 Val'!D8" -> ('Q2 Val', 'D8'); "D8" -> (here, 'D8'). External prefixes are kept in the sheet part."""
    ref = ref.strip()
    if "!" in ref:
        sh, a = ref.rsplit("!", 1)
        sh = sh.strip()
        if sh.startswith("'") and sh.endswith("'"):
            sh = sh[1:-1].replace("''", "'")
        return sh, a.replace("$", "")
    return here, ref.replace("$", "")


def norm_file(name):
    return re.sub(r"\s+", " ", os.path.basename(str(name)).strip().lower())


def is_date_format(code):
    """a custom number format that displays a date or time (quoted text, escapes, colours and locales removed first)."""
    if not code:
        return False
    c = re.sub(r'"[^"]*"', "", code)
    c = re.sub(r"\\.", "", c)
    c = re.sub(r"\[(?!h+\]|m+\]|s+\])[^\]]*\]", "", c, flags=re.I)
    c = c.split(";")[0].lower()
    if re.search(r"[dy]", c) or re.search(r"[hs]", c):
        return True
    return "m" in c and not re.search(r"[0#?]", c)


def serial_to_date(v, date1904):
    try:
        if date1904:
            d = datetime.datetime(1904, 1, 1) + datetime.timedelta(days=float(v))
        else:
            v = float(v)
            d = datetime.datetime(1899, 12, 30) + datetime.timedelta(days=v if v >= 61 else v + 1)
        return d.date() if d.hour == 0 and d.minute == 0 and d.second == 0 else d
    except (OverflowError, ValueError):
        return None


def fmt_value(v):
    if v is None:
        return "(no saved value)"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (datetime.datetime, datetime.date)):
        return "date " + v.isoformat()[:10]
    if isinstance(v, (int, float)):
        if float(v).is_integer() and abs(v) < 1e15:
            return f"{int(v):,}"
        return f"{v:,.6f}".rstrip("0").rstrip(".")
    s = str(v).replace("\n", " ")
    return '"' + (s[:120] + "..." if len(s) > 120 else s) + '"'


def num(v):
    return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else None


class Budget:
    def __init__(self, seconds):
        self.t0, self.seconds = time.time(), seconds

    def left(self):
        return self.seconds - (time.time() - self.t0)

    def over(self):
        return self.seconds is not None and self.left() <= 0

    def elapsed(self):
        return time.time() - self.t0


class OutOfTime(Exception):
    pass


class Book:
    """One workbook. Cells are parsed lazily per sheet and cached on disk (keyed by the file's SHA-256), so a follow-up
    question about one sheet does not re-read the others. Cell tuple: (value, formula_or_None, kind, style, info)."""

    def __init__(self, path, cache_dir=None, sid=None):
        self.path, self.sid = path, sid
        self.file = os.path.basename(path)
        with open(path, "rb") as fh:
            data = fh.read()
        self.sha256, self.bytes = hashlib.sha256(data).hexdigest(), len(data)
        self.zf = zipfile.ZipFile(path)
        self.names_in_zip = set(self.zf.namelist())
        self.cache_dir = os.path.join(cache_dir, self.sha256[:16]) if cache_dir else None
        self._cells, self._summ = {}, {}
        self._read_workbook()

    # --- package parts -------------------------------------------------------------------------------------------------
    def _xml(self, part):
        return ET.fromstring(self.zf.read(part)) if part in self.names_in_zip else None

    def _rels(self, part):
        d, b = posixpath.split(part)
        rp = posixpath.join(d, "_rels", b + ".rels")
        out = {}
        x = self._xml(rp)
        if x is None:
            return out
        for r in x:
            tgt, mode = r.get("Target", ""), r.get("TargetMode")
            if mode != "External":
                tgt = tgt.lstrip("/") if tgt.startswith("/") else posixpath.normpath(posixpath.join(d, tgt))
            out[r.get("Id")] = (r.get("Type", "").rsplit("/", 1)[-1], tgt, mode)
        return out

    def _read_workbook(self):
        wb = self._xml("xl/workbook.xml")
        rels = self._rels("xl/workbook.xml")
        self.date1904 = False
        self.sheets, self.defined, ext_ids = [], [], []
        for e in wb.iter():
            t = tag(e)
            if t == "workbookPr":
                self.date1904 = e.get("date1904") in ("1", "true")
            elif t == "sheet":
                rid = e.get(f"{{{NS_R}}}id")
                kind, tgt, _ = rels.get(rid, ("", "", None))
                self.sheets.append({"name": e.get("name"), "state": e.get("state", "visible"), "part": tgt,
                                    "type": {"worksheet": "worksheet", "chartsheet": "chart sheet", "dialogsheet": "dialog sheet"}.get(kind, kind or "?")})
            elif t == "definedName":
                self.defined.append({"name": e.get("name"), "local": e.get("localSheetId"), "hidden": e.get("hidden") in ("1", "true"),
                                     "text": (e.text or "").strip()})
            elif t == "externalReference":
                ext_ids.append(e.get(f"{{{NS_R}}}id"))
        self.sheet_index = {s["name"]: i for i, s in enumerate(self.sheets)}
        self.sheet_lower = {s["name"].lower(): s["name"] for s in self.sheets}
        # shared strings
        self.sst = []
        sp = next((t for k, t, m in rels.values() if k == "sharedStrings"), None)
        if sp and sp in self.names_in_zip:
            for ev, e in ET.iterparse(self.zf.open(sp), events=("end",)):
                if tag(e) == "si":
                    parts = []
                    for ch in e:
                        if tag(ch) == "t":
                            parts.append(ch.text or "")
                        elif tag(ch) == "r":
                            parts += [g.text or "" for g in ch if tag(g) == "t"]
                    self.sst.append("".join(parts))
                    e.clear()
        # styles: number format per style index
        self.style_fmt, self.style_date = [], []
        stp = next((t for k, t, m in rels.values() if k == "styles"), None)
        st = self._xml(stp) if stp else None
        if st is not None:
            custom = {}
            for e in st.iter():
                if tag(e) == "numFmt":
                    custom[int(e.get("numFmtId"))] = e.get("formatCode")
            xfs = next((e for e in st if tag(e) == "cellXfs"), None)
            for xf in (xfs if xfs is not None else []):
                fid = int(xf.get("numFmtId", 0))
                code = custom.get(fid, BUILTIN_FMT.get(fid, f"format {fid}"))
                self.style_fmt.append(code)
                self.style_date.append(fid in DATE_IDS or (fid in custom and is_date_format(custom[fid])))
        # external links: formula [n] = the n-th externalReference in workbook.xml
        self.ext = {}
        for n, rid in enumerate(ext_ids, 1):
            _, part, _ = rels.get(rid, ("", "", None))
            info = {"index": n, "target": None, "file": None, "sheets": [], "cache": {}}
            x = self._xml(part) if part else None
            if x is not None:
                prel = self._rels(part)
                for e in x.iter():
                    if tag(e) == "externalBook":
                        k = prel.get(e.get(f"{{{NS_R}}}id"))
                        if k:
                            info["target"] = urllib.parse.unquote(k[1])
                            info["file"] = info["target"].replace("\\", "/").rstrip("/").rsplit("/", 1)[-1]
                    elif tag(e) == "sheetName":
                        info["sheets"].append(e.get("val"))
                    elif tag(e) == "sheetData":
                        sid = int(e.get("sheetId", 0))
                        shn = info["sheets"][sid] if sid < len(info["sheets"]) else f"#{sid}"
                        for row in e:
                            for c in row:
                                v = next((g.text for g in c if tag(g) == "v"), None)
                                if v is not None:
                                    tt = c.get("t")
                                    info["cache"][(shn, c.get("r"))] = (v if tt in ("s", "str", "e", "inlineStr") else
                                                                       (v == "1") if tt == "b" else float(v))
            self.ext[n] = info

    # --- cells ---------------------------------------------------------------------------------------------------------
    def sheet_names(self):
        return [s["name"] for s in self.sheets]

    def resolve_sheet(self, name):
        if name in self.sheet_index:
            return name
        return self.sheet_lower.get(str(name).lower())

    def cells(self, sheet, budget=None):
        """{(row, col): (value, formula, kind, style, info)} for one sheet; populated cells only."""
        sheet = self.resolve_sheet(sheet)
        if sheet is None:
            raise KeyError("no such sheet")
        if sheet in self._cells:
            return self._cells[sheet]
        i = self.sheet_index[sheet]
        cp = os.path.join(self.cache_dir, f"sheet{i}.pkl") if self.cache_dir else None
        if cp and os.path.exists(cp):
            try:
                with open(cp, "rb") as fh:
                    self._cells[sheet], self._summ[sheet] = pickle.load(fh)
                return self._cells[sheet]
            except Exception:
                pass
        cells, summ = self._parse(self.sheets[i], budget)
        self._cells[sheet], self._summ[sheet] = cells, summ
        if cp:
            os.makedirs(self.cache_dir, exist_ok=True)
            with open(cp + ".tmp", "wb") as fh:
                pickle.dump((cells, summ), fh, protocol=4)
            os.replace(cp + ".tmp", cp)
        return cells

    def summary(self, sheet, budget=None):
        sheet = self.resolve_sheet(sheet)
        self.cells(sheet, budget)
        return self._summ[sheet]

    def _parse(self, sh, budget):
        cells, summ = {}, {"declared": None, "populated": None, "cells": 0, "formulas": 0, "errors": 0, "styled_empty": 0,
                           "hidden_rows": [], "hidden_cols": [], "merged": [], "data_tables": [], "arrays": [], "shared": 0,
                           "external_formulas": 0, "dynamic_formulas": 0, "comments": {}}
        if sh["type"] != "worksheet" or sh["part"] not in self.names_in_zip:
            return cells, summ
        shared, ranges = {}, []
        minr = minc = 10 ** 9
        maxr = maxc = 0
        n_el, sd = 0, None
        for ev, e in ET.iterparse(self.zf.open(sh["part"]), events=("start", "end")):
            t = tag(e)
            if ev == "start":
                if t == "sheetData":
                    sd = e
                continue
            n_el += 1
            if budget is not None and n_el % 50000 == 0 and budget.over():
                raise OutOfTime(sh["name"])
            if t == "c":
                ref = e.get("r")
                rc = parse_cell(ref) if ref else None
                f_el = v_txt = is_txt = None
                for ch in e:
                    ct = tag(ch)
                    if ct == "f":
                        f_el = ch
                    elif ct == "v":
                        v_txt = ch.text
                    elif ct == "is":
                        is_txt = "".join(g.text or "" for g in ch.iter() if tag(g) == "t")
                if rc is None:
                    e.clear()
                    continue
                if f_el is None and v_txt is None and is_txt is None:
                    summ["styled_empty"] += 1
                    e.clear()
                    continue
                s = int(e.get("s", 0))
                ty = e.get("t", "n")
                info, formula = None, None
                if f_el is not None:
                    ft = f_el.get("t", "normal")
                    txt = f_el.text
                    if ft == "shared":
                        si = f_el.get("si")
                        if txt:
                            shared[si] = (txt, ref)
                            formula = "=" + txt
                        elif si in shared:
                            try:
                                from openpyxl.formula.translate import Translator
                                formula = Translator("=" + shared[si][0], origin=shared[si][1]).translate_formula(ref)
                            except Exception:
                                formula = f"=(shared formula {si} from {shared[si][1]}, not translated)"
                        else:
                            formula = f"=(shared formula {si}, master cell not found)"
                        info = ("shared", si)
                        summ["shared"] += 1
                    elif ft == "array":
                        formula = "=" + (txt or "")
                        info = ("array", f_el.get("ref") or ref)
                        summ["arrays"].append(f"{ref} ({f_el.get('ref') or ref})")
                        ranges.append(("array", f_el.get("ref") or ref, ref))
                    elif ft == "dataTable":
                        r1, r2 = f_el.get("r1"), f_el.get("r2")
                        two = f_el.get("dt2D") in ("1", "true")
                        dtr = f_el.get("dtr") in ("1", "true")
                        args = f"{r1},{r2}" if two else (f"{r1}," if dtr else f",{r1}")
                        formula = f"=TABLE({args})"
                        info = ("dataTable", f_el.get("ref") or ref, r1, r2, two, dtr)
                        summ["data_tables"].append(f"{f_el.get('ref') or ref} (row input {r1 if (two or dtr) else '-'}, column input "
                                                   f"{(r2 if two else (r1 if not dtr else '-'))})")
                        ranges.append(("dataTable", f_el.get("ref") or ref, ref))
                    else:
                        formula = "=" + (txt or "")
                    summ["formulas"] += 1
                    if "[" in formula and re.search(r"\[\d+\]", formula):
                        summ["external_formulas"] += 1
                    if DYNAMIC.search(formula):
                        summ["dynamic_formulas"] += 1
                # value
                if ty == "s":
                    try:
                        val, kind = self.sst[int(v_txt)], "s"
                    except (ValueError, IndexError, TypeError):
                        val, kind = v_txt, "s"
                elif ty in ("str", "inlineStr"):
                    val, kind = (is_txt if ty == "inlineStr" else v_txt), "s"
                elif ty == "b":
                    val, kind = v_txt in ("1", "true"), "b"
                elif ty == "e":
                    val, kind = v_txt, "e"
                    summ["errors"] += 1
                elif ty == "d":
                    val, kind = v_txt, "d"
                else:
                    try:
                        x = float(v_txt) if v_txt is not None else None
                    except ValueError:
                        x = None
                    if x is not None and s < len(self.style_date) and self.style_date[s]:
                        val, kind = serial_to_date(x, self.date1904), "d"
                    else:
                        val = int(x) if x is not None and x.is_integer() and abs(x) < 1e15 else x
                        kind = "n"
                cells[rc] = (val, formula, kind, s, info)
                summ["cells"] += 1
                minr, minc, maxr, maxc = min(minr, rc[0]), min(minc, rc[1]), max(maxr, rc[0]), max(maxc, rc[1])
                e.clear()
            elif t == "row":
                if e.get("hidden") in ("1", "true"):
                    summ["hidden_rows"].append(int(e.get("r", 0)))
                if sd is not None:
                    try:
                        sd.remove(e)
                    except ValueError:
                        e.clear()
            elif t == "dimension":
                summ["declared"] = e.get("ref")
            elif t == "col" and e.get("hidden") in ("1", "true"):
                summ["hidden_cols"].append(f"{n2col(int(e.get('min')))}:{n2col(int(e.get('max')))}")
            elif t == "mergeCell":
                if len(summ["merged"]) < 300:
                    summ["merged"].append(e.get("ref"))
        for kind, rng, anchor in ranges:                 # tag the cells inside array / data-table ranges
            b = parse_range(rng)
            if not b or None in b:
                continue
            for k in [k for k in cells if b[0] <= k[0] <= b[2] and b[1] <= k[1] <= b[3]]:
                v = cells[k]
                if v[1] is None:
                    cells[k] = (v[0], None, v[2], v[3], (kind + "-member", anchor))
        if summ["cells"]:
            summ["populated"] = f"{addr(minr, minc)}:{addr(maxr, maxc)}"
        # comments
        for _, (k, tgt, _) in self._rels(sh["part"]).items():
            if k == "comments" and tgt in self.names_in_zip:
                x = self._xml(tgt)
                for cm in x.iter():
                    if tag(cm) == "comment":
                        summ["comments"][cm.get("ref")] = " ".join((g.text or "") for g in cm.iter() if tag(g) == "t").strip()[:200]
        return cells, summ

    def get(self, sheet, a):
        rc = parse_cell(a)
        try:
            return self.cells(sheet).get(rc) if rc else None
        except KeyError:
            return None

    def value(self, sheet, a):
        c = self.get(sheet, a)
        return c[0] if c else None

    def formula(self, sheet, a):
        c = self.get(sheet, a)
        return c[1] if c else None

    def range_keys(self, sheet, rng):
        """populated cells inside a range, in row order (open-ended ranges are clamped to the populated area)."""
        b = parse_range(rng)
        if not b:
            return []
        cs = self.cells(sheet)
        r1, c1, r2, c2 = b
        r1, c1 = r1 or 1, c1 or 1
        r2, c2 = r2 or 10 ** 7, c2 or 16384
        if (r2 - r1 + 1) * (c2 - c1 + 1) <= 200000:
            return [(r, c) for r in range(r1, r2 + 1) for c in range(c1, c2 + 1) if (r, c) in cs]
        return sorted(k for k in cs if r1 <= k[0] <= r2 and c1 <= k[1] <= c2)

    def range_shape(self, rng):
        b = parse_range(rng)
        if not b or None in b:
            return None
        return [(r, c) for r in range(b[0], b[2] + 1) for c in range(b[1], b[3] + 1)]

    def ext_file(self, n):
        x = self.ext.get(int(n))
        return x["file"] if x else None


def formula_refs(formula, here, book, _depth=0):
    """references in a formula -> [(ext_index or None, sheet, range)]; defined names resolved; dynamic refs noted."""
    out = []
    if not formula or not formula.startswith("="):
        return out
    try:
        from openpyxl.formula.tokenizer import Tokenizer
        toks = Tokenizer(formula).items
    except Exception:
        return out
    for t in toks:
        if t.type != "OPERAND" or t.subtype != "RANGE":
            continue
        v = t.value
        if "!" in v:
            sh, rng = split_ref(v, here)
            ext = None
            m = re.match(r"^\[(\d+)\](.*)$", sh)
            if m:
                ext, sh = int(m.group(1)), m.group(2)
            if ":" in sh:                       # 3-D reference Sheet1:Sheet3!A1 - kept as written
                out.append((ext, sh, rng))
                continue
            out.append((ext, sh if ext else (book.resolve_sheet(sh) or sh), rng))
        elif REF_STRICT.match(v):
            out.append((None, here, v.replace("$", "")))
        elif _depth < 3:
            dn = next((d for d in book.defined if d["name"].lower() == v.lower() and
                       (d["local"] is None or book.sheets[int(d["local"])]["name"] == here)), None) or \
                 next((d for d in book.defined if d["name"].lower() == v.lower()), None)
            if dn and dn["text"]:
                out += formula_refs("=" + dn["text"], here, book, _depth + 1)
    return out


def ref_contains(rng, a):
    b, rc = parse_range(rng), parse_cell(a)
    if not b or not rc:
        return False
    r1, c1, r2, c2 = b
    rok = (r1 is None and r2 is None) or (r1 is not None and r2 is not None and r1 <= rc[0] <= r2)
    cok = (c1 is None and c2 is None) or (c1 is not None and c2 is not None and c1 <= rc[1] <= c2)
    return rok and cok


# --- source set (the run's workbooks, with stable ids) ---------------------------------------------------------------------
class SourceSet:
    def __init__(self, run_dir=None, cache_dir=None):
        self.run_dir = run_dir
        self.cache_dir = cache_dir or (os.path.join(run_dir, ".cache") if run_dir else "/tmp/xpv_xlsx_cache")
        self.books, self.meta = {}, {}
        self.external = []
        self.paths = {}
        p = os.path.join(run_dir, "checkpoints", "01_sources.json") if run_dir else None
        if p and os.path.exists(p):
            d = json.load(open(p))
            for s in d.get("sources", []):
                self.meta[s["id"]] = s
            self.external = d.get("external", [])
        pp = os.path.join(run_dir, ".paths.json") if run_dir else None
        if pp and os.path.exists(pp):
            self.paths = json.load(open(pp))

    def save_paths(self):
        if self.run_dir:
            self.paths.update({sid: os.path.abspath(b.path) for sid, b in self.books.items() if sid.startswith("W")})
            json.dump(self.paths, open(os.path.join(self.run_dir, ".paths.json"), "w"), indent=1)

    def add(self, path, sid):
        b = Book(path, self.cache_dir, sid)
        self.books[sid] = b
        return b

    def open_paths(self, paths):
        """open workbooks; ids come from the existing 01_sources.json (matched by SHA-256), else W1..Wn by file name."""
        tmp = []
        for p in paths:
            b = Book(p, self.cache_dir)
            tmp.append(b)
        by_sha = {m["sha256"]: sid for sid, m in self.meta.items()}
        used = set(by_sha.values())
        nxt = 1 + max([int(s[1:]) for s in used if re.fullmatch(r"W\d+", s)] or [0])
        for b in sorted(tmp, key=lambda b: b.file.lower()):
            sid = by_sha.get(b.sha256)
            if not sid:
                sid = f"W{nxt}"
                nxt += 1
            b.sid = sid
            self.books[sid] = b
        return self.books

    def book(self, key):
        if key in self.books:
            return self.books[key]
        if key in self.paths and os.path.exists(self.paths[key]):
            return self.add(self.paths[key], key)
        if os.path.exists(key):
            for sid, b in self.books.items():
                if os.path.abspath(b.path) == os.path.abspath(key):
                    return b
            return self.add(key, key)
        raise KeyError(f"unknown workbook {key!r}: give a source id from inventory or a file path")

    def ensure_all(self):
        for sid, p in self.paths.items():
            if sid not in self.books and os.path.exists(p):
                self.add(p, sid)

    def by_file(self, fname):
        n = norm_file(fname or "")
        for sid, b in self.books.items():
            if norm_file(b.file) == n:
                return sid
        for x in self.external:
            if norm_file(x["file"]) == n:
                return x["id"]
        return None


def parse_src_ref(s):
    """"W4:'Val'!D8" -> ('W4', 'Val', 'D8')."""
    m = re.match(r"^([A-Za-z]+\d+):(.*)$", s.strip())
    if not m:
        raise ValueError(f"expected SOURCE:'Sheet'!A1, got {s!r}")
    sh, a = split_ref(m.group(2))
    return m.group(1), sh, a


def describe(book, sheet, rc, cell, srcs=None, show_fmt=True, summ=None):
    v, f, kind, s, info = cell
    a = addr(*rc)
    nf = ""
    if show_fmt and s < len(book.style_fmt) and book.style_fmt[s] not in ("General",):
        nf = f" [{book.style_fmt[s]}]"
    extra = ""
    if info:
        if info[0] == "array":
            extra = f" {{array formula over {info[1]}}}"
        elif info[0] == "dataTable":
            extra = f" {{DATA TABLE {info[1]}: what-if table, not a live chain}}"
        elif info[0].endswith("-member"):
            extra = f" {{inside {info[0][:-7]} anchored at {info[1]}}}"
    if f:
        ext = ""
        for n in sorted(set(int(x) for x in re.findall(r"\[(\d+)\]", f))):
            fn = book.ext_file(n)
            sid = srcs.by_file(fn) if srcs else None
            ext += f" [ext {n} = {fn or '?'} = {sid}" + ("]" if sid and sid.startswith("W") else ", not a supplied workbook]") if sid else \
                f" [ext {n} = {fn or '?'}, not a supplied workbook]"
        dyn = " {dynamic reference: INDIRECT/OFFSET}" if DYNAMIC.search(f) else ""
        txt = f"{a} {f} -> {fmt_value(v)}{nf}{extra}{ext}{dyn}"
    else:
        txt = f"{a} {fmt_value(v)}{nf}{extra}"
    if summ and a in summ.get("comments", {}):
        txt += f" {{comment: {summ['comments'][a][:120]}}}"
    return txt


# --- commands ------------------------------------------------------------------------------------------------------------
def cmd_inventory(a, budget):
    srcs = SourceSet(a.run_dir)
    books = srcs.open_paths(a.workbooks)
    inv_dir = os.path.join(a.run_dir, "evidence", "inventory")
    os.makedirs(inv_dir, exist_ok=True)
    os.makedirs(os.path.join(a.run_dir, "checkpoints"), exist_ok=True)
    sources, external, stopped = [], {}, []
    for sid in sorted(books, key=lambda s: int(s[1:]) if s[1:].isdigit() else 0):
        b = books[sid]
        lines = [f"SOURCE {sid}: {b.file}", f"SHA-256: {b.sha256}   bytes: {b.bytes:,}   date system: {'1904' if b.date1904 else '1900'}",
                 "Sheets in tab order (state | declared used range -> populated area | cells, formulas, errors | notes):"]
        tot = {"cells": 0, "formulas": 0, "errors": 0}
        sheets, inflated = [], []
        for i, sh in enumerate(b.sheets, 1):
            try:
                sm = b.summary(sh["name"], budget)
            except OutOfTime:
                stopped.append(f"{sid} sheet {sh['name']}")
                lines.append(f"  {i:02d}. {sh['name']} | {sh['state']} | NOT READ: time budget used up (rerun inventory; read sheets are cached)")
                sheets.append({"name": sh["name"], "state": sh["state"], "read": False})
                continue
            for k in tot:
                tot[k] += sm[k]
            notes = []
            dec, pop = sm["declared"], sm["populated"]
            big = False
            if dec and ":" in dec and pop:
                d, p = parse_range(dec), parse_range(pop)
                if d and p and None not in d and None not in p:
                    darea = (d[2] - d[0] + 1) * (d[3] - d[1] + 1)
                    parea = (p[2] - p[0] + 1) * (p[3] - p[1] + 1)
                    big = darea > 20 * parea and darea > 1_000_000
            if big or sm["styled_empty"] > 10 * max(1, sm["cells"]) and sm["styled_empty"] > 50000:
                notes.append(f"INFLATED used range ({sm['styled_empty']:,} formatted empty cells skipped)")
                inflated.append(sh["name"])
            if sh["type"] != "worksheet":
                notes.append(sh["type"])
            if sm["hidden_rows"]:
                notes.append(f"{len(sm['hidden_rows'])} hidden rows")
            if sm["hidden_cols"]:
                notes.append(f"hidden columns {', '.join(sm['hidden_cols'][:6])}")
            if sm["data_tables"]:
                notes.append(f"data tables: {'; '.join(sm['data_tables'][:3])}")
            if sm["arrays"]:
                notes.append(f"{len(sm['arrays'])} array formulas")
            if sm["shared"]:
                notes.append(f"{sm['shared']} cells use shared formulas")
            if sm["external_formulas"]:
                notes.append(f"{sm['external_formulas']} formulas link to other files")
            if sm["dynamic_formulas"]:
                notes.append(f"{sm['dynamic_formulas']} INDIRECT/OFFSET formulas")
            if sm["comments"]:
                notes.append(f"{len(sm['comments'])} comments")
            lines.append(f"  {i:02d}. {sh['name']} | {sh['state']} | {dec or '-'} -> {pop or 'empty'} | {sm['cells']:,} cells, "
                         f"{sm['formulas']:,} formulas, {sm['errors']} errors" + (" | " + "; ".join(notes) if notes else ""))
            sheets.append({"name": sh["name"], "state": sh["state"], "populated": pop, "cells": sm["cells"], "formulas": sm["formulas"],
                           "errors": sm["errors"], "inflated": sh["name"] in inflated})
        ext_lines, links = [], []
        for n, x in sorted(b.ext.items()):
            sup = srcs.by_file(x["file"]) if x["file"] else None
            if not sup or not sup.startswith("W"):
                key = norm_file(x["file"] or f"unknown-{sid}-{n}")
                if key not in external:
                    old_x = next((e for e in srcs.external if norm_file(e["file"] or "") == key), None)
                    external[key] = {"id": old_x["id"] if old_x else f"X{len(external) + 1}", "file": x["file"], "referenced_by": []}
                external[key]["referenced_by"].append(f"{sid} [{n}]")
                sup = external[key]["id"]
            links.append({"index": n, "file": x["file"], "source": sup})
            ext_lines.append(f"  [{n}] {x['file']} -> {sup}{'' if sup.startswith('W') else ' (NOT SUPPLIED: values are only the cached copies)'}"
                             f"   sheets: {', '.join(x['sheets'][:8])}   cached cells: {len(x['cache'])}")
        lines += ["Links to other files (formula prefix [n]):"] + (ext_lines or ["  (none)"])
        dn = [f"  {d['name']}{' (sheet ' + b.sheets[int(d['local'])]['name'] + ')' if d['local'] is not None else ''}"
              f"{' hidden' if d['hidden'] else ''} = {d['text'][:100]}" for d in b.defined]
        lines += [f"Defined names ({len(dn)}):"] + (dn[:60] or ["  (none)"]) + (["  ..."] if len(dn) > 60 else [])
        open(os.path.join(inv_dir, f"{sid}.txt"), "w", encoding="utf-8").write("\n".join(lines) + "\n")
        warn = []
        if tot["formulas"] == 0 and all(s.get("read", True) is not False for s in sheets):
            warn.append("NO FORMULAS (values-only copy?)")
        if inflated:
            warn.append(f"inflated used range on {len(inflated)} sheet(s), handled")
        sources.append({"id": sid, "file": b.file, "sha256": b.sha256, "bytes": b.bytes,
                        "sheets": sheets, "formulas": tot["formulas"], "links": links, "warnings": warn})
        print(f"READ: {sid} | {b.file} | {len(b.sheets)} sheets | {tot['cells']:,} cells | {tot['formulas']:,} formulas | "
              f"{tot['errors']} errors | links to {len(b.ext)} file(s) | sha256 {b.sha256}" + (" | " + "; ".join(warn) if warn else ""))
        if "NO FORMULAS (values-only copy?)" in warn:
            print(f"READ WARNING: {sid} has no formulas. If it is a valuation workbook it arrived as values only (e.g. converted from a "
                  "chat attachment): its links cannot be traced. Get the original .xlsx; otherwise every edge into it is at best a match.")
    for x in external.values():
        print(f"READ: {x['id']} | {x['file']} | NOT SUPPLIED | referenced by {', '.join(x['referenced_by'])}")
    out = {"schema": "xpv-onboarding-checkpoint/1", "stage": 1, "name": "sources", "made_by": f"xlsx_evidence {VERSION}",
           "made_at": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"), "sources": sources,
           "external": list(external.values()), "complete": not stopped}
    srcs.save_paths()
    p = os.path.join(a.run_dir, "checkpoints", "01_sources.json")
    old = json.load(open(p)) if os.path.exists(p) else None
    if old and {x["sha256"] for x in old["sources"]} != {x["sha256"] for x in sources}:
        print("READ WARNING: these workbooks differ from the ones this run started with (SHA-256). This is a different source set: "
              "start a new run folder rather than resuming. Nothing was overwritten (see checkpoints/01_sources.CHANGED.json).")
        json.dump(out, open(p.replace(".json", ".CHANGED.json"), "w"), indent=1)
    elif old and old.get("complete") is not False:
        print("INVENTORY: checkpoint 1 already exists for exactly these workbooks: kept unchanged (resuming).")
    else:
        if old:
            out["made_at"] = old.get("made_at", out["made_at"])
        json.dump(out, open(p, "w"), indent=1)
    if stopped:
        print(f"STOPPED: time budget ({budget.seconds:.0f}s) used up before {', '.join(stopped)}. Run the same command again: "
              "sheets already read are cached and will not be read twice.")
    print(f"INVENTORY: {len(sources)} workbooks | {len(external)} linked files not supplied | details: evidence/inventory/W<n>.txt | "
          f"checkpoint: checkpoints/01_sources.json | {budget.elapsed():.1f}s")


def _print_area(b, sheet, keys, cells, srcs, max_cells, summ):
    shown, last_row, line, n = 0, None, [], 0
    out = []
    for k in keys:
        if shown >= max_cells:
            out.append(" | ".join(line)) if line else None
            return out, k[0]
        if k[0] != last_row:
            if line:
                out.append(" | ".join(line))
            line = [f"r{k[0]}{' (hidden)' if k[0] in set(summ['hidden_rows']) else ''}"]
            last_row = k[0]
        line.append(describe(b, sheet, k, cells[k], srcs, summ=summ))
        shown += 1
    if line:
        out.append(" | ".join(line))
    return out, None


def cmd_sheet(a, budget):
    srcs = SourceSet(a.run_dir)
    b = srcs.book(a.workbook)
    sheet = b.resolve_sheet(a.sheet)
    if not sheet:
        print(f"NO SUCH SHEET: {a.sheet!r}. Sheets: {', '.join(b.sheet_names())}")
        return 1
    cells = b.cells(sheet, budget)
    sm = b.summary(sheet)
    r1, r2 = (a.rows.split(":") + [""])[:2] if a.rows else ("", "")
    c1, c2 = (a.cols.split(":") + [""])[:2] if a.cols else ("", "")
    r1, r2 = int(r1 or 1), int(r2 or 10 ** 7)
    c1, c2 = col2n(c1) if c1 else 1, col2n(c2) if c2 else 16384
    keys = sorted(k for k in cells if r1 <= k[0] <= r2 and c1 <= k[1] <= c2)
    st = b.sheets[b.sheet_index[sheet]]["state"]
    print(f"SHEET: {b.sid or b.file} '{sheet}' | {st} | declared {sm['declared']} -> populated {sm['populated']} | {sm['cells']:,} cells")
    if sm["hidden_cols"]:
        print(f"Hidden columns: {', '.join(sm['hidden_cols'])}")
    if sm["merged"]:
        print(f"Merged (value in first cell): {', '.join(sm['merged'][:40])}{' ...' if len(sm['merged']) > 40 else ''}")
    if sm["data_tables"]:
        print(f"Data tables: {'; '.join(sm['data_tables'])}")
    print("Format: row | ADDRESS value  or  ADDRESS =formula -> saved value  [number format]  {notes}")
    out, nxt = _print_area(b, sheet, keys, cells, srcs, a.max_cells, sm)
    print("\n".join(out))
    if nxt:
        print(f"TRUNCATED: {a.max_cells} cells shown of {len(keys):,} in this area. Continue with --rows {nxt}:{r2 if r2 < 10 ** 7 else ''}")
    print(f"TIME: {budget.elapsed():.1f}s")


def cmd_cells(a, budget):
    srcs = SourceSet(a.run_dir)
    b = srcs.book(a.workbook)
    for ref in a.ref:
        sh, rng = split_ref(ref)
        sheet = b.resolve_sheet(sh) if sh else None
        if not sheet:
            print(f"NO SUCH SHEET in {ref!r}. Sheets: {', '.join(b.sheet_names())}")
            continue
        cells = b.cells(sheet, budget)
        sm = b.summary(sheet)
        keys = b.range_keys(sheet, rng)
        print(f"CELLS: {b.sid or b.file} {quote_sheet(sheet)}!{rng} | {len(keys)} populated")
        hdr_rows = [int(x) for x in str(a.headers).split(",")] if a.headers else []
        lab_cols = a.labels.split(":") if a.labels else None
        if hdr_rows:
            cols = sorted({k[1] for k in keys})
            for hr in hdr_rows:
                hs = [f"{n2col(c)}={fmt_value(cells[(hr, c)][0]) if (hr, c) in cells else '-'}" for c in cols]
                print(f"  headers row {hr}: " + " | ".join(hs[:60]))
        shown = 0
        for k in keys:
            if shown >= a.max_cells:
                print(f"  TRUNCATED at {addr(*k)} ({len(keys) - shown} more); narrow the range")
                break
            lab = ""
            if lab_cols:
                lc1, lc2 = col2n(lab_cols[0]), col2n(lab_cols[-1])
                lab = " ".join(str(cells[(k[0], c)][0]) for c in range(lc1, lc2 + 1) if (k[0], c) in cells and isinstance(cells[(k[0], c)][0], str))
                lab = f"  <{lab[:60]}>" if lab else ""
            print("  " + describe(b, sheet, k, cells[k], srcs, summ=sm) + lab + (" (hidden row)" if k[0] in set(sm["hidden_rows"]) else ""))
            shown += 1
    print(f"TIME: {budget.elapsed():.1f}s")


def all_books(srcs, a):
    if getattr(a, "workbooks", None):
        srcs.open_paths(a.workbooks)
    srcs.ensure_all()
    return srcs.books


def cmd_find(a, budget):
    srcs = SourceSet(a.run_dir)
    books = all_books(srcs, a)
    hits, total = [], 0
    if a.value is not None:
        target = float(a.value)
        scales = [float(x) for x in a.scales.split(",")]
        for sid, b in books.items():
            for sh in b.sheet_names():
                try:
                    cells = b.cells(sh, budget)
                except OutOfTime:
                    print(f"STOPPED: time budget used up at {sid} '{sh}'; rerun (read sheets are cached)")
                    return
                for k, c in cells.items():
                    v = num(c[0])
                    if v is None or c[2] == "d":
                        continue
                    txt = f"{abs(v):.6f}".rstrip("0").rstrip(".")
                    decimals = len(txt.split(".")[1]) if "." in txt else 0
                    sig = len(txt.replace(".", "").lstrip("0"))
                    for sc in scales:
                        x = v * sc
                        kind = None
                        if abs(x - target) <= max(1e-9 * abs(target), 1e-6):
                            kind = "exact" + ("" if sc == 1 else f" at x{sc:g}")
                        elif sc > 1 and (sig >= 3 or (sig >= 2 and decimals >= 1)) and abs(x - target) <= 0.5 * sc * 10 ** (-decimals):
                            kind = f"rounded at x{sc:g}"
                        elif sc == 1 and abs(x - target) <= a.tolerance:
                            kind = f"within {a.tolerance:g}"
                        elif abs(x + target) <= max(1e-9 * abs(target), 1e-6):
                            kind = "opposite sign" + ("" if sc == 1 else f" at x{sc:g}")
                        if kind:
                            total += 1
                            if len(hits) < a.max_hits:
                                hits.append(f"  {sid}:{quote_sheet(sh)}!{addr(*k)} {kind} | " + describe(b, sh, k, c, srcs, show_fmt=False))
                            break
        print(f"FIND: value {fmt_value(target)} | {total} matching cells{' (first ' + str(a.max_hits) + ')' if total > len(hits) else ''} | "
              "a matching number is NOT evidence of a link: use refs to see whether a formula connects them")
    else:
        pat = a.text.lower()
        for sid, b in books.items():
            for sh in b.sheet_names():
                cells = b.cells(sh, budget)
                for k, c in cells.items():
                    if isinstance(c[0], str) and pat in c[0].lower():
                        total += 1
                        if len(hits) < a.max_hits:
                            hits.append(f"  {sid}:{quote_sheet(sh)}!{addr(*k)} {fmt_value(c[0])}")
        print(f"FIND: text {a.text!r} | {total} cells")
    print("\n".join(hits))
    print(f"TIME: {budget.elapsed():.1f}s")


def dependents(srcs, sid, sheet, a, budget):
    """formulas in any supplied workbook that refer to (sid, sheet, a)."""
    tgt = srcs.books[sid] if sid in srcs.books else None
    tfile = norm_file(tgt.file) if tgt else None
    xfile = next((norm_file(x["file"]) for x in srcs.external if x["id"] == sid), None)
    out = []
    for bid, b in srcs.books.items():
        for sh in b.sheet_names():
            cells = b.cells(sh, budget)
            for k, c in cells.items():
                f = c[1]
                if not f:
                    continue
                if bid != sid and "[" not in f:
                    continue
                for ext, rs, rng in formula_refs(f, sh, b):
                    if ext is None:
                        ok = bid == sid and rs == sheet and ref_contains(rng, a)
                    else:
                        ef = norm_file(b.ext_file(ext) or "")
                        ok = ef in (tfile, xfile) and rs.lower() == sheet.lower() and ref_contains(rng, a)
                    if ok:
                        out.append((bid, sh, k, c, b))
                        break
    return out


def cmd_refs(a, budget):
    srcs = SourceSet(a.run_dir)
    all_books(srcs, a)
    if a.to:
        sid, sh, ad = parse_src_ref(a.to)
        b = srcs.book(sid) if sid.startswith("W") else None
        sheet = (b.resolve_sheet(sh) if b else sh) or sh
        deps = dependents(srcs, sid, sheet, ad, budget)
        print(f"REFS TO {sid}:{quote_sheet(sheet)}!{ad} | {len(deps)} formulas refer to it (ranges that contain it count)")
        for bid, s2, k, c, bb in deps[:a.max_hits]:
            print(f"  {bid}:{quote_sheet(s2)}!" + describe(bb, s2, k, c, srcs, show_fmt=False))
        if len(deps) > a.max_hits:
            print(f"  ... {len(deps) - a.max_hits} more")
    else:
        sid, sh, ad = parse_src_ref(a.frm)
        b = srcs.book(sid)
        sheet = b.resolve_sheet(sh)
        seen = set()

        def walk(bk, bid, s, ad_, depth, ind):
            key = (bid, s, ad_)
            if key in seen or depth < 0:
                return
            seen.add(key)
            c = bk.get(s, ad_)
            if not c:
                print(f"{ind}{bid}:{quote_sheet(s)}!{ad_} (empty)")
                return
            print(f"{ind}{bid}:{quote_sheet(s)}!" + describe(bk, s, parse_cell(ad_), c, srcs, show_fmt=False))
            if c[4] and c[4][0] == "dataTable":
                print(f"{ind}  (data table: its values come from Excel's what-if engine over the row/column input cells "
                      f"{c[4][2]}, {c[4][3]}, not from a formula chain)")
            for ext, rs, rng in formula_refs(c[1], s, bk):
                if ext is None:
                    ks = bk.range_keys(rs, rng) if bk.resolve_sheet(rs) else []
                    if len(ks) > 12:
                        vals = [num(bk.cells(rs)[k][0]) for k in ks]
                        tot = sum(v for v in vals if v is not None)
                        print(f"{ind}  -> {bid}:{quote_sheet(rs)}!{rng}: {len(ks)} cells, numeric sum {fmt_value(tot)} (narrow with cells)")
                        continue
                    for k in ks:
                        walk(bk, bid, rs, addr(*k), depth - 1, ind + "  ")
                else:
                    fn = bk.ext_file(ext)
                    tid = srcs.by_file(fn)
                    cache = bk.ext.get(ext, {}).get("cache", {})
                    rr = parse_range(rng)
                    cs = [addr(r, c_) for r in range(rr[0], rr[2] + 1) for c_ in range(rr[1], rr[3] + 1)] if rr and None not in rr else [rng]
                    for x in cs[:24]:
                        cv = cache.get((rs, x))
                        line = f"{ind}  -> [ext {ext}] {fn}{' = ' + tid if tid else ''} {quote_sheet(rs)}!{x}: cached value in this file {fmt_value(cv)}"
                        if tid and tid in srcs.books:
                            tb = srcs.books[tid]
                            ts = tb.resolve_sheet(rs)
                            sv = tb.value(ts, x) if ts else None
                            same = num(sv) is not None and num(cv) is not None and abs(num(sv) - num(cv)) <= 1e-6 * max(1, abs(num(sv)))
                            line += f" | supplied {tid} holds {fmt_value(sv)} ({'same' if same or sv == cv else 'DIFFERENT'})"
                        elif not tid or tid.startswith("X"):
                            line += " | that file was not supplied"
                        print(line)
                        if depth - 1 >= 0 and tid in srcs.books:
                            tb = srcs.books[tid]
                            ts = tb.resolve_sheet(rs)
                            if ts:
                                walk(tb, tid, ts, x, depth - 1, ind + "    ")
        print(f"REFS FROM {sid}:{quote_sheet(sheet)}!{ad} (depth {a.depth})")
        walk(b, sid, sheet, ad, a.depth, "  ")
    print(f"TIME: {budget.elapsed():.1f}s")


def main(argv=None):
    ap = argparse.ArgumentParser(description="read-only workbook evidence")
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p):
        p.add_argument("--run-dir", default=".")
        p.add_argument("--max-seconds", type=float, default=90)
        p.add_argument("--max-hits", type=int, default=40)
    p = sub.add_parser("inventory"); common(p); p.add_argument("--workbooks", nargs="+", required=True)
    p = sub.add_parser("sheet"); common(p); p.add_argument("--workbook", required=True); p.add_argument("--sheet", required=True)
    p.add_argument("--rows"); p.add_argument("--cols"); p.add_argument("--max-cells", type=int, default=2500)
    p = sub.add_parser("cells"); common(p); p.add_argument("--workbook", required=True); p.add_argument("--ref", action="append", required=True)
    p.add_argument("--headers"); p.add_argument("--labels"); p.add_argument("--max-cells", type=int, default=400)
    p = sub.add_parser("find"); common(p); p.add_argument("--workbooks", nargs="*")
    g = p.add_mutually_exclusive_group(required=True); g.add_argument("--value", type=float); g.add_argument("--text")
    p.add_argument("--scales", default="1,1000,1000000"); p.add_argument("--tolerance", type=float, default=0.5)
    p = sub.add_parser("refs"); common(p); p.add_argument("--workbooks", nargs="*")
    g = p.add_mutually_exclusive_group(required=True); g.add_argument("--to"); g.add_argument("--from", dest="frm")
    p.add_argument("--depth", type=int, default=1)
    a = ap.parse_args(argv)
    budget = Budget(a.max_seconds)
    try:
        return {"inventory": cmd_inventory, "sheet": cmd_sheet, "cells": cmd_cells, "find": cmd_find, "refs": cmd_refs}[a.cmd](a, budget) or 0
    except OutOfTime as e:
        print(f"STOPPED: time budget ({a.max_seconds:.0f}s) used up while reading sheet {e}. Nothing was truncated silently: run the "
              "same command again (sheets already read are cached), or raise --max-seconds for this one sheet.")
        return 2
    except KeyError as e:
        print(f"ERROR: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
