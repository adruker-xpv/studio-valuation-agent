# test_onboarding.py (build 13.0, test bench) - checks the deterministic parts of onboarding on synthetic workbooks only:
#   R  the evidence reader: inflated used ranges, hidden/very-hidden sheets, shared/array/data-table formulas, links to other files
#      (supplied and not supplied), dates, targeted reads, numeric search that never claims a link, time budget, stable source ids
#   K  checkpoints: a provisional extraction exists from stage 3; stage files are validated, append-only and resumable
#   V  verify: correct extractions VERIFIED (a preserved discrepancy included); every evidence class is tested as claimed;
#      numeric equality is never promoted to a link; decoys (sensitivity table, prior quarter, copies, another row) never VERIFIED
#   X  reconcile: comparison by fingerprint, reviewer-value measures, statuses, analyst files
#   S  scoring against keys
# Prints one line per test and: TESTS: PASS (n/n)
import copy, glob, json, os, shutil, subprocess, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__))
TB = os.path.dirname(HERE)
TR = os.path.join(TB, "trial")
T1 = os.path.join(TR, "set-T1")
REF = os.path.join(TR, "reference")
TMP = tempfile.mkdtemp()
PY = sys.executable
results = []


def run(script, *args):
    return subprocess.run([PY, os.path.join(HERE, script), *map(str, args)], capture_output=True, text=True).stdout


def test(name, ok, got=""):
    results.append(bool(ok))
    print(f"- {'PASS' if ok else 'FAIL'}: {name}" + (f" -> {got}" if got and not ok else ""))


def new_run(name, workbooks=None):
    rd = os.path.join(TMP, name)
    shutil.rmtree(rd, ignore_errors=True)
    os.makedirs(rd)
    out = run("xlsx_evidence.py", "inventory", "--run-dir", rd, "--workbooks", *(workbooks or sorted(glob.glob(os.path.join(T1, "*.xlsx")))))
    return rd, out


def save(rd, stage, doc, kind="extraction"):
    p = os.path.join(rd, f"draft-{kind}-{stage}.json")
    json.dump(doc, open(p, "w"))
    return run("checkpoint.py", "save", "--run-dir", rd, "--kind", kind, "--stage", stage, "--file", p)


def ref_stage(n):
    return json.load(open(glob.glob(os.path.join(REF, "T1", f"0{n}_*.json"))[0]))


def t1_run(name, upto=6, final=True):
    rd, _ = new_run(name)
    for n in range(2, upto + 1):
        save(rd, n, ref_stage(n))
    if final and upto == 6:
        run("verify.py", "--run-dir", rd, "--final")
    return rd


def verify_doc(rd, X, *extra):
    p = os.path.join(rd, "x.json")
    json.dump(X, open(p, "w"))
    run("verify.py", "--run-dir", rd, "--file", p, "--out", os.path.join(rd, "vx.json"), *extra)
    return json.load(open(os.path.join(rd, "vx.json")))


def edge(V, eid):
    return next(e for e in V["edges"] if e["id"] == eid)


# ---------------- R: reader ----------------
t = time.time()
rd, out = new_run("r")
el = time.time() - t
test("R the five workbooks and the linked file that was not supplied are all fingerprinted",
     out.count("READ: W") == 5 and "X1 | Tidewater - June 2026 TTM Pro Forma v3.xlsx | NOT SUPPLIED" in out and out.count("sha256 ") == 5, out[-300:])
test(f"R an inflated used range (A1:XFD1048576, ~270,000 formatted empty cells) is read in seconds ({el:.1f}s)", el < 20, f"{el:.1f}s")
inv = {os.path.basename(p)[:-4]: open(p).read() for p in glob.glob(os.path.join(rd, "evidence", "inventory", "*.txt"))}
ma = next(k for k, v in inv.items() if "Management Accounts" in v.splitlines()[0])
test("R the inflated sheet is flagged, its real populated area found, empty formatted cells not counted as cells",
     "A1:XFD1048576 -> A1:T102 | 142 cells" in inv[ma] and "INFLATED" in inv[ma], inv[ma][:400])
test("R very-hidden and hidden sheets are exposed", "Old Draft | veryHidden" in inv[ma] and "Q1 Val (old) | hidden" in inv["W1"])
o = run("xlsx_evidence.py", "cells", "--run-dir", rd, "--workbook", ma, "--ref", "'P&L'!K9", "--ref", "'P&L'!C4")
test("R a shared formula is shown as the formula of each cell, with Excel's saved value beside it", "K9 =K7-K8 -> 618,000" in o, o)
test("R a date-formatted serial is shown as a date", "C4 date 2025-01-31" in o, o)
pf = next(k for k, v in inv.items() if "TTM Pro Forma.xlsx" in v.splitlines()[0])
o = run("xlsx_evidence.py", "cells", "--run-dir", rd, "--workbook", pf, "--ref", "TTM!O10") + \
    run("xlsx_evidence.py", "cells", "--run-dir", rd, "--workbook", "W1", "--ref", "Valuation!C15:C17")
test("R array and data-table formulas are shown, and data-table cells are marked as what-if values",
     "{array formula over O10}" in o and "=TABLE(,D7)" in o and "C17 82,607,250 [#,##0] {inside dataTable anchored at C15}" in o, o)
test("R links to other files are resolved: a supplied file to its id, an unsupplied version to an X id",
     f"Tidewater - June 2026 Management Accounts.xlsx -> {ma}" in inv["W1"] and "TTM Pro Forma v3.xlsx -> X1 (NOT SUPPLIED" in inv["W1"], inv["W1"])
o = run("xlsx_evidence.py", "cells", "--run-dir", rd, "--workbook", ma, "--ref", "'EBITDA Adjustments'!B102:T102", "--headers", "3", "--labels", "B:B")
test("R a targeted row read shows each column's header (the 'row 102 vs the TTM window' question in one call)",
     "T=date 2026-06-30" in o and "T102 =SUM(I11:T11) -> 8,455,500" in o, o)
o = run("xlsx_evidence.py", "find", "--run-dir", rd, "--value", "30698613.35")
test("R find reports exact and $000s-rounded matches and says a match is not a link",
     "Waterfall!B10 exact" in o and "rounded at x1000" in o and "NOT evidence of a link" in o, o)
o = run("xlsx_evidence.py", "find", "--run-dir", rd, "--value", "8695500")
test("R find does not report small numbers (multiples) as rounded millions", "x1e+06" not in o and "2 matching cells" in o, o)
o = run("xlsx_evidence.py", "refs", "--run-dir", rd, "--to", f"{ma}:'P&L'!K9")
test("R refs finds formulas in other workbooks that link to a cell", f"{pf}:TTM!E6 ='[1]P&L'!K9" in o, o)
o = run("xlsx_evidence.py", "refs", "--run-dir", rd, "--from", "W1:Valuation!D9") + run("xlsx_evidence.py", "refs", "--run-dir", rd, "--from", "W1:Valuation!D6")
test("R refs from a linked cell compares the cached value with the supplied file, or says the file was not supplied",
     "(same)" in o and "that file was not supplied" in o, o)
o = run("xlsx_evidence.py", "sheet", "--run-dir", rd, "--workbook", ma, "--sheet", "EBITDA Adjustments", "--max-cells", "20")
test("R a sheet read past its cap says so and how to continue (never a silent truncation)", "TRUNCATED: 20 cells shown" in o and "--rows" in o, o[-200:])
rd2 = os.path.join(TMP, "r-budget")
os.makedirs(rd2)
o = run("xlsx_evidence.py", "inventory", "--run-dir", rd2, "--max-seconds", "0", "--workbooks", *sorted(glob.glob(os.path.join(T1, "*.xlsx"))))
c1 = json.load(open(os.path.join(rd2, "checkpoints", "01_sources.json")))
marked = any("NOT READ" in open(p).read() for p in glob.glob(os.path.join(rd2, "evidence", "inventory", "*.txt")))
o2 = run("xlsx_evidence.py", "inventory", "--run-dir", rd2, "--workbooks", *sorted(glob.glob(os.path.join(T1, "*.xlsx"))))
c2 = json.load(open(os.path.join(rd2, "checkpoints", "01_sources.json")))
test("R a call that runs out of time says STOPPED, marks what it did not read, and a rerun completes the same checkpoint",
     "STOPPED" in o and marked and c1["complete"] is False and c2["complete"] is True and c1["made_at"] == c2["made_at"], o[-300:])
o = run("xlsx_evidence.py", "inventory", "--run-dir", rd, "--workbooks", *reversed(sorted(glob.glob(os.path.join(T1, "*.xlsx")))))
test("R source ids are stable: rerunning inventory (files in another order) keeps checkpoint 1 unchanged", "kept unchanged (resuming)" in o, o)
from openpyxl import load_workbook
vo = os.path.join(TMP, "values only.xlsx")
load_workbook(os.path.join(T1, "2026 Q2 - Tidewater Valuation (30 June 2026).xlsx"), data_only=True).save(vo)
rd3, o = new_run("r-values", [vo])
test("R a workbook that arrived without its formulas is flagged", "READ WARNING" in o and "no formulas" in o, o)
o = run("xlsx_evidence.py", "inventory", "--run-dir", rd, "--workbooks", vo)
test("R a different set of files in the same run folder is refused, not merged", "differ from the ones this run started with" in o, o)

# ---------------- K: checkpoints ----------------
rd = t1_run("k", upto=3)
X = json.load(open(os.path.join(rd, "extraction.json")))
test("K after stage 3 a usable extraction exists: PROVISIONAL, with the chain, and stages 4-7 pending",
     X["status"] == "provisional" and X["chain"]["enterprise_value"]["cell"] == "Valuation!D8" and X["stages_pending"] == [4, 5, 6, 7], X["stages_pending"])
o = run("checkpoint.py", "status", "--run-dir", rd)
test("K status names the next stage with its goal and budget", "NEXT: stage 4 upstream" in o and "budget about 25" in o, o[-300:])
bad = ref_stage(4)
bad["provenance"][0]["class"] = "linked"
o = save(rd, 4, bad)
test("K a stage with an unknown evidence class is rejected and nothing is saved",
     "rejected" in o and "class 'linked'" in o and not glob.glob(os.path.join(rd, "checkpoints", "04_*")), o)
bad = ref_stage(4)
bad["provenance"][0]["to"]["source"] = "W9"
o = save(rd, 4, bad)
test("K an unknown source id is rejected", "unknown source 'W9'" in o, o)
bad = ref_stage(4)
bad["provenance"][0]["to"]["cell"] = "Valuation D6"
o = save(rd, 4, bad)
test("K a malformed cell reference is rejected", "is not 'Sheet'!A1" in o, o)
bad = ref_stage(4)
bad["provenance"][0]["to"]["cell"] = "Valuations!D6"
o = save(rd, 4, bad)
test("K a sheet that does not exist is rejected", "has no sheet 'Valuations'" in o, o)
big = ref_stage(4)
big["deferred"] = ["x" * 400] * 19 + ["y" * 60000]
o = save(rd, 4, big)
test("K an oversized stage is rejected with the instruction to move detail to evidence", "cap 60,000" in o and "evidence/" in o, o[:300])
bad = ref_stage(4)
bad["provenance"] = [dict(bad["provenance"][3], id=f"E{100 + i}") for i in range(61)]
o = save(rd, 4, bad)
test("K too many items in a section are rejected (keep material ones)", "keep at most 60" in o and "duplicate id" not in o, o[:300])
rdo, _ = new_run("k-order")
save(rdo, 2, ref_stage(2))
o = save(rdo, 4, ref_stage(4))
test("K a stage saved before its prerequisites is rejected", "needs stage(s) 3 first" in o, o)
r2 = ref_stage(2)
r2["sources"] = r2["sources"][:4]
o = save(rdo, 2, r2)
test("K every supplied workbook must get a role ('not_used' is a role)", "every supplied workbook needs a role" in o, o)
save(rd, 4, ref_stage(4))
s4 = ref_stage(4)
s4["provenance"][0]["what"] = "revised wording"
o = save(rd, 4, s4)
test("K a re-saved stage is stored as a revision; the original is kept and the revision wins",
     os.path.exists(os.path.join(rd, "checkpoints", "04_upstream.json")) and os.path.exists(os.path.join(rd, "checkpoints", "04_upstream.r2.json"))
     and json.load(open(os.path.join(rd, "extraction.json")))["provenance"][0]["what"] == "revised wording", o)
rd = t1_run("k-full")
x1 = json.load(open(os.path.join(rd, "extraction.json")))
rr = os.path.join(TMP, "k-resume")
shutil.rmtree(rr, ignore_errors=True)
shutil.copytree(os.path.join(rd, "checkpoints"), os.path.join(rr, "checkpoints"))
o = run("xlsx_evidence.py", "inventory", "--run-dir", rr, "--workbooks", *sorted(glob.glob(os.path.join(T1, "*.xlsx"))))
run("checkpoint.py", "assemble", "--run-dir", rr)
x2 = json.load(open(os.path.join(rr, "extraction.json")))
strip = lambda d: {k: v for k, v in d.items() if k != "assembled_at"}
test("K a fresh agent with only the checkpoints rebuilds exactly the same extraction (resume)", strip(x1) == strip(x2) and x2["status"] == "final")
save(rd, 6, dict(ref_stage(6), open_questions=ref_stage(6)["open_questions"][:1]))
x3 = json.load(open(os.path.join(rd, "extraction.json")))
o = run("checkpoint.py", "status", "--run-dir", rd)
test("K saving a stage after validation makes the extraction provisional again until verify --final reruns",
     x3["status"] == "provisional" and "out of date" in o, o[-400:])
rb, _ = new_run("k-blind")
core = json.load(open(os.path.join(REF, "T1-blind", "02_core.json")))
core["provenance"] = [dict(core["provenance"][0], id=f"B{i}") for i in range(21)]
o = save(rb, 2, core, "blind")
test("K the blind review is capped at 20 key edges", "keep at most 20" in o, o[:300])

# ---------------- V: verify ----------------
rd = t1_run("v")
V = json.load(open(os.path.join(rd, "verification.json")))
test("V the five-workbook reference is VERIFIED, and the fund discrepancy is confirmed and preserved (a pass, not a failure)",
     V["status"] == "VERIFIED" and V["detail"]["fund"].get("discrepancy") == "D1" and V["discrepancies"][0]["status"] == "confirmed", V["status"])
test("V judgment edges are never 'confirmed': contextual support stays not checkable", edge(V, "E6")["status"] == "not_checkable")
rp = t1_run("v-prov", upto=3)
o = run("verify.py", "--run-dir", rp)
test("V a provisional extraction (stages 1-3) is PROVISIONAL with the core checks passing",
     "status | PROVISIONAL" in o and "chain | pass" in o and "window | pass" in o and "fund | pass" in o, o)
X = json.load(open(os.path.join(rd, "extraction.json")))


def mutate(f):
    Y = copy.deepcopy(X)
    f(Y)
    return verify_doc(rd, Y)


def set_edge(Y, eid, **kw):
    for sec in ("provenance", "downstream"):
        for e in Y[sec]:
            if e["id"] == eid:
                e.update(kw)


R_ = mutate(lambda Y: set_edge(Y, "E5", **{"class": "direct_formula_link"}))
test("V numeric equality is never promoted to a link: a pasted match claimed as a formula link is CONTRADICTED",
     R_["status"] == "REVIEW" and edge(R_, "E5")["status"] == "contradicted" and "match, not a link" in edge(R_, "E5")["note"], edge(R_, "E5")["note"])
R_ = mutate(lambda Y: set_edge(Y, "E4", **{"class": "pasted_exact_match"}))
test("V a real formula link claimed as a pasted match is contradicted (understated evidence is still wrong)",
     "classify direct_formula_link" in edge(R_, "E4")["note"], edge(R_, "E4")["note"])
R_ = mutate(lambda Y: set_edge(Y, "E1", **{"from": {"source": "W4", "cell": "TTM!O10"}}))
test("V a link claimed to the supplied file when the formula points at another version (v3) is contradicted",
     edge(R_, "E1")["status"] == "contradicted" and "does not refer to" in edge(R_, "E1")["note"], edge(R_, "E1")["note"])
R_ = mutate(lambda Y: set_edge(Y, "E20", relation={"op": "round", "factor": 0.01, "decimals": 0}))
test("V a rounded match with the wrong scale is contradicted", edge(R_, "E20")["status"] == "contradicted", edge(R_, "E20")["note"])
R_ = mutate(lambda Y: set_edge(Y, "E20", **{"class": "pasted_exact_match", "relation": None}))
test("V a rounded figure claimed as an exact match is contradicted", edge(R_, "E20")["status"] == "contradicted", edge(R_, "E20")["note"])
R_ = mutate(lambda Y: set_edge(Y, "E3", **{"from": {"source": "W4", "cell": "TTM!C10:M10"}}))
test("V a sum over the wrong months does not recompute", edge(R_, "E3")["status"] == "contradicted", edge(R_, "E3")["note"])
R_ = mutate(lambda Y: set_edge(Y, "E3", **{"class": "arithmetic_transformation"}))
test("V an arithmetic transformation (sum) that recomputes is confirmed", edge(R_, "E3")["status"] == "confirmed" and R_["status"] == "VERIFIED", R_["status"])
R_ = mutate(lambda Y: Y["discrepancies"][0].update(b={"source": "W2", "cell": "'Fund Calc'!C5"}, difference=None))
test("V a 'discrepancy' between two values that agree is contradicted", R_["discrepancies"][0]["status"] == "contradicted", R_["discrepancies"][0]["note"])
R_ = mutate(lambda Y: Y["discrepancies"][0].update(difference=-500))
test("V a discrepancy with the wrong stated difference is contradicted", R_["discrepancies"][0]["status"] == "contradicted", R_["discrepancies"][0]["note"])


def hide_disc(Y):
    Y["discrepancies"] = []
    Y["downstream"].append({"id": "E99", "from": {"source": "W1", "cell": "Waterfall!B10"}, "to": {"source": "W2", "cell": "Portfolio!D5"},
                            "class": "rounded_match", "relation": {"op": "round", "factor": 0.001, "decimals": 0}, "what": "forced"})
R_ = mutate(hide_disc)
test("V forcing the company value to reconcile with the fund value is caught", R_["status"] == "REVIEW" and edge(R_, "E99")["status"] == "contradicted", R_["status"])
R_ = mutate(lambda Y: Y.update(discrepancies=[], downstream=[]))
test("V a company value never connected to the fund cell (no edge, no discrepancy) fails", R_["checks"]["fund"] == "fail", R_["checks"]["fund"])
R_ = mutate(lambda Y: Y["sources"][0].update(sha256="0" * 64))
test("V an extraction made from a different file fails integrity", R_["checks"]["integrity"] == "fail" and R_["status"] == "REVIEW")
R_ = mutate(lambda Y: Y["chain"]["enterprise_value"].update(cell="Valuation!C17"))
test("V decoy: EV = the sensitivity data-table row with the same value is not VERIFIED", R_["status"] != "VERIFIED" and R_["checks"]["chain"] == "fail")


def prior(Y):
    c = Y["chain"]
    for r, a in (("valuation_metric", "C6"), ("selected_multiple", "C7"), ("enterprise_value", "C8"), ("equity_value", "C11")):
        c[r]["cell"] = f"Valuation!{a}"
    c["bridge"] = [{"cell": "Valuation!C9", "sign": 1}, {"cell": "Valuation!C10", "sign": -1}]
R_ = mutate(prior)
test("V decoy: the live previous-quarter chain is not VERIFIED", R_["status"] != "VERIFIED", R_["status"])
R_ = mutate(lambda Y: Y["chain"]["value_to_xpv"].update(cell="Report!D6"))
test("V decoy: the report's rounded copy as XPV's value is not VERIFIED", R_["status"] != "VERIFIED", R_["status"])
R_ = mutate(lambda Y: Y["chain"]["fund_cell"].update(cell="Portfolio!D4"))
test("V decoy: another company's fund row is not VERIFIED", R_["status"] != "VERIFIED" and R_["checks"]["fund"] == "fail", R_["checks"]["fund"])
R_ = mutate(lambda Y: Y["chain"]["metric_window"].update(cells="TTM!C10:M10"))
test("V a window of 11 months fails", R_["checks"]["window"] == "fail")
R_ = mutate(lambda Y: Y["chain"]["metric_window"].update(source="W3", cells="'EBITDA Adjustments'!I11:T11"))
test("V a window that does not sum to the metric (the excl.-pro-forma rival) fails", R_["checks"]["window"] == "fail")
R_ = mutate(lambda Y: Y["chain"]["metric_window"].update(link="direct_formula_link"))
test("V a window claimed as a formula link when the path runs through an unsupplied file fails",
     R_["checks"]["window"] == "fail" and "no formula path" in R_["detail"]["window"].get("problem", ""), R_["detail"]["window"])
R_ = mutate(lambda Y: Y["chain"].update(metric_window={"link": "unresolved"}))
test("V an honestly unresolved window gives SUPPORTED, never VERIFIED and never a failure", R_["status"] == "SUPPORTED", R_["status"])
CO = {11: "Granite Basin Services", 23: "Northline Utilities", 37: "Blue Heron Water", 68: "Granite Basin Services"}
trial = {}
for seed in (11, 23, 37, 68):
    d = os.path.join(TR, f"workbook-{seed}")
    r_, _ = new_run(f"v{seed}", [os.path.join(d, f) for f in sorted(os.listdir(d))])
    for n, doc in enumerate(json.load(open(os.path.join(REF, f"stages-{seed}.json"))), 2):
        save(r_, n, doc)
    o = run("verify.py", "--run-dir", r_, "--final", "--company", CO[seed])
    trial[seed] = r_
    test(f"V two-workbook trial {seed}: the migrated reference is VERIFIED", "status | VERIFIED" in o, o.splitlines()[-1] if o else "")
VS, EA = "'Valuation Summary'", "'Equity Allocation'"
cases = [
    ("EV = the sensitivity row with the same value", 23, {"enterprise_value": f"{VS}!D18"}),
    ("EV and equity = sensitivity rows", 23, {"enterprise_value": f"{VS}!D18", "equity_value": f"{VS}!D19"}),
    ("the live previous-quarter chain", 37, {"enterprise_value": f"{VS}!C8", "equity_value": f"{VS}!C11", "valuation_metric": f"{VS}!C6",
                                             "selected_multiple": f"{VS}!C7", "bridge": [{"cell": f"{VS}!C9", "sign": 1}, {"cell": f"{VS}!C10", "sign": 1}],
                                             "window": {"source": "W1", "first": "2025-04", "last": "2026-03", "cells": "'Monthly P&L'!E12:P12", "link": "direct_formula_link"}}),
    ("XPV's value = the report's copy", 23, {"value_to_xpv": "'Investor Report'!E6"}),
    ("XPV's value in local currency (the fund reports USD)", 11, {"value_to_xpv": f"{EA}!B16"}),
    ("multiple = the comparables median", 23, {"selected_multiple": "'Trading Comps'!D11"}),
    ("another company's fund row", 11, {"fund": "Portfolio!D5"}),
    ("equity = the waterfall's copy of equity", 23, {"equity_value": "Waterfall!B3"}),
    ("option decoy", 11, {"enterprise_value": f"{EA}!D6", "valuation_metric": f"{EA}!B6", "selected_multiple": f"{EA}!C6", "equity_value": f"{EA}!B10",
                          "bridge": [{"cell": f"{EA}!D7", "sign": 1}, {"cell": f"{EA}!B3", "sign": 1}]}),
    ("option decoy with no window", 11, {"enterprise_value": f"{EA}!D6", "valuation_metric": f"{EA}!B6", "selected_multiple": f"{EA}!C6",
                                         "equity_value": f"{EA}!B10", "window": {"link": "unresolved"}}),
]
for name, seed, ch in cases:
    Y = json.load(open(os.path.join(trial[seed], "extraction.json")))
    for k, v in ch.items():
        if k == "bridge":
            Y["chain"]["bridge"] = v
        elif k == "window":
            Y["chain"]["metric_window"] = v
        elif k == "fund":
            Y["chain"]["fund_cell"]["cell"] = v
        else:
            Y["chain"][k]["cell"] = v
    R_ = verify_doc(trial[seed], Y, "--company", CO[seed])
    test(f"V decoy on trial {seed}: {name} is not VERIFIED", R_["status"] != "VERIFIED", R_["status"])

# ---------------- X: reconcile ----------------
rd = t1_run("x")
rb = os.path.join(rd, "reviewer")
os.makedirs(rb)
run("xlsx_evidence.py", "inventory", "--run-dir", rb, "--workbooks", *sorted(glob.glob(os.path.join(T1, "*.xlsx"))))
save(rb, 2, json.load(open(os.path.join(REF, "T1-blind", "02_core.json"))), "blind")
save(rb, 3, json.load(open(os.path.join(REF, "T1-blind", "03_challenges.json"))), "blind")
o = run("reconcile.py", "--run-dir", rd, "--compare-only")
C = json.load(open(os.path.join(rd, "out", "compare.json")))
test("X compare-only lists the contested items for phase 2 (every blind challenge included) and gives no status",
     "COMPARE: core agreed 9/9" in o and sum(c["kind"] == "blind challenge" for c in C["contested"]) == 4 and "ONBOARDING" not in o, o)
save(rb, 1, json.load(open(os.path.join(REF, "T1-blind", "review_findings.json"))), "review")
o = run("reconcile.py", "--run-dir", rd, "--review", os.path.join(rb, "review.json"))
RC = json.load(open(os.path.join(rd, "out", "reconcile.json")))
test("X a faithfully preserved discrepancy makes the run NEEDS ANALYST (a decision), never CHECKS FAILED",
     RC["status"] == "NEEDS ANALYST" and any(q["from"] == "discrepancy" for q in RC["questions"]), RC["status"])
test("X the reviewer's different path is measured (top-down from the fund vs bottom-up from the monthly financials)",
     RC["reviewer_value"]["different_path"] is True and "bottom_up from monthly_financials" in RC["reviewer_value"]["reviewer_path"], RC["reviewer_value"])
test("X an unsupported assumption counts as judgment-only added value", RC["reviewer_value"]["value"].startswith("ADDED VALUE (judgment only"), RC["reviewer_value"]["value"])


def recon(rv=None, blind=None, xdoc=None):
    rdd = os.path.join(TMP, "xr")
    shutil.rmtree(rdd, ignore_errors=True)
    shutil.copytree(rd, rdd)
    if xdoc is not None:
        json.dump(xdoc, open(os.path.join(rdd, "extraction.json"), "w"))
    if blind is not None:
        json.dump(blind, open(os.path.join(rdd, "reviewer", "reviewer_blind.json"), "w"))
    rv = rv if rv is not None else json.load(open(os.path.join(rb, "review.json")))
    json.dump(rv, open(os.path.join(rdd, "rv.json"), "w"))
    run("reconcile.py", "--run-dir", rdd, "--review", os.path.join(rdd, "rv.json"))
    return json.load(open(os.path.join(rdd, "out", "reconcile.json")))


RV0 = json.load(open(os.path.join(rb, "review.json")))
rv = copy.deepcopy(RV0)
rv["findings"].append({"id": "F9", "type": "missed_rival", "target": "new", "evidence": [{"source": "W1", "cell": "Comps!D10"}], "note": "comps median", "material": True})
rv["findings"].append({"id": "F10", "type": "missed_rival", "target": "new", "evidence": [{"source": "W1", "cell": "Valuation!C17"}], "note": "sensitivity", "material": True})
r_ = recon(rv)
test("X a missed rival counts only if the extraction neither used nor rejected it",
     r_["reviewer_value"]["missed_material_rivals"] == 1 and next(f for f in r_["findings"] if f["id"] == "F10")["novel"] is False, r_["reviewer_value"])
Xb = json.load(open(os.path.join(rd, "extraction.json")))
for e in Xb["provenance"]:
    if e["id"] == "E5":
        e["class"] = "direct_formula_link"
rv = copy.deepcopy(RV0)
rv["findings"].append({"id": "F11", "type": "contradiction", "target": "E5", "evidence": [{"source": "W4", "cell": "TTM!C7:N7"}], "material": True,
                       "note": "the add-backs are typed, not linked", "claim": {"from": {"source": ma, "cell": "'EBITDA Adjustments'!I9:T9"},
                       "to": {"source": "W4", "cell": "TTM!C7:N7"}, "class": "pasted_exact_match", "what": "add-backs"}})
rv["findings"].append({"id": "F12", "type": "contradiction", "target": "E4", "evidence": [{"source": "W4", "cell": "TTM!C6:N6"}], "material": True,
                       "note": "wrong claim", "claim": {"from": {"source": ma, "cell": "'P&L'!I9:T9"}, "to": {"source": "W4", "cell": "TTM!C6:N6"},
                       "class": "pasted_exact_match", "what": "reported EBITDA"}})
r_ = recon(rv, xdoc=Xb)
test("X a contradiction whose claim verify confirms is counted as evidence-backed; one that fails verify is a reviewer error",
     r_["reviewer_value"]["evidence_backed_contradictions"] == 1 and r_["reviewer_value"]["reviewer_claims_contradicted"] >= 1, r_["reviewer_value"])
test("X an extraction verify contradicts is CHECKS FAILED, whatever the agents agree on", r_["status"] == "CHECKS FAILED", r_["status"])
bl = json.load(open(os.path.join(rb, "reviewer_blind.json")))
bl2 = copy.deepcopy(bl)
bl2["direction"] = "top_down"
bl2["path"] = [{"source": "W2", "cell": "Portfolio!D5", "step": "fund"}]
r_ = recon({"produced_by": "t", "findings": [], "overall": "ok"}, blind=bl2)
test("X same path, full agreement and no findings: 'no independent value shown' (agreement is not proof)",
     r_["reviewer_value"]["value"] == "NO INDEPENDENT VALUE SHOWN", r_["reviewer_value"]["value"])
bl3 = copy.deepcopy(bl)
bl3["sources"][0]["sha256"] = "1" * 64
r_ = recon(blind=bl3)
test("X the reviewer read different files: CHECKS FAILED, integrity first", r_["status"] == "CHECKS FAILED" and r_["questions"][0]["from"] == "integrity", r_["status"])
bl4 = copy.deepcopy(bl)
bl4["chain"]["value_to_xpv"]["cell"] = "Waterfall!B7"
r_ = recon(blind=bl4)
test("X the blind reviewer picks another cell: NEEDS ANALYST with the question", r_["status"] == "NEEDS ANALYST" and
     any("Waterfall!B7" in q["question"] and "Waterfall!B10" in q["question"] for q in r_["questions"]), r_["status"])
# trial 11: agreement by a different path, nothing open -> READY FOR APPROVAL
r11 = trial[11]
X11 = json.load(open(os.path.join(r11, "extraction.json")))
bl11 = {k: X11[k] for k in ("schema", "sources", "external", "company", "quarter_end", "valuation_workbook", "fund_workbook", "chain", "provenance", "downstream", "discrepancies")}
bl11.update(produced_by="blind (test)", direction="bottom_up", path=[{"source": "W1", "cell": X11["chain"]["metric_window"]["cells"], "step": "monthly"}],
            challenges=[], status="final")
json.dump(bl11, open(os.path.join(r11, "reviewer_blind.json"), "w"))
json.dump({"produced_by": "t", "findings": [{"id": "F1", "type": "confirmed", "target": "chain.value_to_xpv", "evidence": [], "note": "checked"}],
           "overall": "complete", "questions": []}, open(os.path.join(r11, "review.json"), "w"))
run("reconcile.py", "--run-dir", r11, "--company", CO[11])
r_ = json.load(open(os.path.join(r11, "out", "reconcile.json")))
test("X verified, agreed by a different path, nothing to decide: READY FOR APPROVAL (value: corroboration)",
     r_["status"] == "READY FOR APPROVAL" and r_["reviewer_value"]["value"] == "CORROBORATION (different path)", (r_["status"], r_["reviewer_value"]["value"]))
Xq = copy.deepcopy(X11)
Xq["how_it_works"] = "=SUM(A1) is how a careless reader would see it"
json.dump(Xq, open(os.path.join(r11, "extraction.json"), "w"))
json.dump({"responses": [{"item": "F1", "position": "contest", "evidence": "B22 is typed, see the cell"}]}, open(os.path.join(r11, "resp.json"), "w"))
run("reconcile.py", "--run-dir", r11, "--company", CO[11], "--response", os.path.join(r11, "resp.json"))
r_ = json.load(open(os.path.join(r11, "out", "reconcile.json")))
c = load_workbook(os.path.join(r11, "out", "onboarding_review.xlsx"))["Summary"]["B12"]
test("X text beginning with '=' is stored as text in the analyst workbook, never as a formula", c.data_type == "s" and str(c.value).startswith("="), c.data_type)
test("X the extractor's response round appears beside the dispute", any("stands by its reading" in q["question"] for q in r_["questions"]))

# ---------------- S: scoring ----------------
o = run("score.py", "--key", os.path.join(TR, "keys", "key-T1.json"), "--extraction", os.path.join(rd, "extraction.json"))
test("S the five-workbook reference scores 9/9, confidently wrong 0", "9/9 correct | verify VERIFIED | confidently wrong 0" in o, o)
Y = json.load(open(os.path.join(rd, "extraction.json")))
Y["chain"]["enterprise_value"]["cell"] = "Valuation!C17"
json.dump(Y, open(os.path.join(TMP, "wrong.json"), "w"))
o = run("score.py", "--key", os.path.join(TR, "keys", "key-T1.json"), "--extraction", os.path.join(TMP, "wrong.json"))
test("S a wrong answer under a VERIFIED stamp is reported as confidently wrong", "confidently wrong 1" in o, o)

shutil.rmtree(TMP, ignore_errors=True)
print(f"TESTS: {'PASS' if all(results) else 'FAIL'} ({sum(results)}/{len(results)})")
sys.exit(0 if all(results) else 1)
