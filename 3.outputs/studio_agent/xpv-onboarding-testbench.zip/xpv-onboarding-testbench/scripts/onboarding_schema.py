# onboarding_schema.py (build 13.0) - the shared vocabulary of the onboarding run: evidence classes, workbook roles, the stages
# of each agent's work, what each stage file must contain, and the size caps that keep the primary result small.
# Plain data and checks; no workbook interpretation.
import json, re

SCHEMA_VERSION = "13.0.0"

# Evidence classes, strongest first. Every claimed relationship carries exactly one.
CLASSES = {
    "direct_formula_link": "the target cell's formula refers to the source cell (same workbook, or a link to that exact file)",
    "pasted_exact_match": "the numbers are identical, but no formula connects these two cells (typed, pasted, or linked elsewhere)",
    "rounded_match": "the numbers agree only after the stated rounding/scaling (e.g. $ to $000s), and no formula connects them",
    "arithmetic_transformation": "the target equals a stated operation on the source values (sum, scale, sign, product), reproduced by code",
    "contextual_support": "labels, notes or structure support the relationship; no numeric test applies",
    "inferred_candidate": "the most plausible reading, not yet supported by a formula or a number",
    "unresolved": "the supplied evidence does not establish the relationship",
}
CHECKABLE = {"direct_formula_link", "pasted_exact_match", "rounded_match", "arithmetic_transformation"}
OPS = {"equal", "round", "scale", "sum", "multiply", "negate", "subtract"}

ROLES = {
    "company_valuation": "the company valuation workbook (metric x multiple -> EV -> equity -> waterfall -> value to XPV)",
    "fund_valuation": "the fund valuation workbook / summary that reports each company's value",
    "monthly_financials": "company-prepared monthly financial statements or management accounts",
    "monthly_summary": "XPV-prepared monthly summary of the company's figures",
    "pro_forma": "a TTM / pro forma / adjustments workbook prepared for the valuation",
    "other_supporting": "supports the valuation in another way (say how)",
    "not_used": "supplied, but contributes nothing to this valuation (say why)",
    "referenced_not_supplied": "a file another workbook links to that was not supplied (cached values only)",
}
METHODS = {"EV/EBITDA multiple", "EV/Revenue multiple", "Blend of multiples", "Held at cost", "Other"}
CHALLENGE_KINDS = {"rival", "weak_link", "assumption", "period", "units", "version", "discrepancy", "other"}
FINDING_TYPES = {
    "confirmed": "checked from the workbooks; the extractor's conclusion holds (agreement - not proof, but checked)",
    "missed_rival": "a material rival reading the extraction neither uses nor rejects",
    "weak_provenance": "an extractor edge whose evidence class is stronger than the workbook supports",
    "unsupported_assumption": "a conclusion that rests on an assumption the workbooks do not support",
    "contradiction": "the workbook shows a material extractor conclusion is wrong",
    "unsure": "could not settle it from the supplied evidence",
}

# stage plans. (number, name, made by: "script" or "agent", prerequisites, byte cap, goal, reader-call budget)
STAGES = {
    "extraction": [
        (1, "sources", "script", [], None, "fingerprint and inventory every workbook (xlsx_evidence.py inventory)", 0),
        (2, "roles", "agent", [1], 12_000, "say what each workbook is, its period and what it contributes; name the valuation and fund workbooks", 8),
        (3, "chain", "agent", [2], 30_000, "the canonical chain from the fund-reported value back to the metric and its 12-month window, and the "
                                          "link from the company value to the fund value. Save as soon as it is defensible", 20),
        (4, "upstream", "agent", [3], 60_000, "where the metric's material inputs (and bridge items) come from in the supplied workbooks, "
                                              "one classified edge per row or range; rivals rejected; what you deliberately left out", 25),
        (5, "downstream", "agent", [3], 30_000, "every hop from the company value to the fund-reported value: copies, units, currency, "
                                                "rounding; any discrepancy with its driver", 12),
        (6, "questions", "agent", [3, 4, 5], 30_000, "material discrepancies, open questions for the analyst, material typed inputs, and the "
                                                     "final plain-language explanation", 5),
        (7, "validation", "script", [6], None, "verify.py --final; fix only what it marks CONTRADICTED (at most 2 rounds); then stop", 0),
    ],
    "blind": [
        (1, "sources", "script", [], None, "fingerprint and inventory every workbook (xlsx_evidence.py inventory)", 0),
        (2, "core", "agent", [1], 30_000, "BOTTOM-UP: start from the source financials, build the TTM metric, follow it forward into the valuation "
                                          "and on to the fund value; roles, chain, window, key edges (at most 20)", 20),
        (3, "challenges", "agent", [2], 15_000, "at most 12 challenges: rivals, weak links, assumptions, period/unit/version traps a "
                                                "reader is likely to get wrong, each with cells", 10),
    ],
    "review": [
        (1, "findings", "agent", [], 40_000, "one finding per contested item, blind challenge and weak extractor edge: typed, with cells, "
                                             "and a checkable claim wherever one exists", 25),
    ],
}
ITEM_CAPS = {"provenance": 60, "downstream": 30, "rejected": 20, "open_questions": 25, "deferred": 20, "discrepancies": 15,
             "inputs": 30, "challenges": 12, "findings": 20, "path": 12}
BLIND_PROVENANCE_CAP = 20
REF_RE = re.compile(r"^(?:'(?:[^']|'')+'|[^'!:\\/?*\[\]]+)!\$?[A-Za-z]{1,3}\$?\d+(?::\$?[A-Za-z]{1,3}\$?\d+)?$")


def stage_info(kind, n):
    return next(s for s in STAGES[kind] if s[0] == n)


def stage_by_name(kind, name):
    for s in STAGES[kind]:
        if str(s[0]) == str(name) or s[1] == str(name).lower():
            return s
    return None


class Problems(list):
    def add(self, where, msg):
        self.append(f"{where}: {msg}")


def check_ref(r, where, P, ids, sheets=None, allow_list=False):
    if allow_list and isinstance(r, list):
        if not r:
            P.add(where, "empty list of cells")
        for i, x in enumerate(r):
            check_ref(x, f"{where}[{i}]", P, ids, sheets)
        return
    if not isinstance(r, dict):
        P.add(where, 'expected {"source": "W1", "cell": "\'Sheet\'!A1"}')
        return
    s, c = r.get("source"), r.get("cell")
    if s not in ids:
        P.add(where, f"unknown source {s!r} (known: {', '.join(sorted(ids))})")
    if not isinstance(c, str) or not REF_RE.match(c.strip()):
        P.add(where, f"cell {c!r} is not 'Sheet'!A1 or 'Sheet'!A1:B9 (quote sheet names with spaces)")
        return
    if sheets and s in sheets:
        sh = c.rsplit("!", 1)[0].strip()
        sh = sh[1:-1].replace("''", "'") if sh.startswith("'") else sh
        if sh.lower() not in {x.lower() for x in sheets[s]}:
            P.add(where, f"{s} has no sheet {sh!r}")


def check_edge(e, where, P, ids, sheets, seen_ids):
    if not isinstance(e, dict):
        P.add(where, "an edge is an object")
        return
    eid = e.get("id")
    if not eid or not isinstance(eid, str):
        P.add(where, "every edge needs an id (E1, E2, ...)")
    elif eid in seen_ids:
        P.add(where, f"duplicate id {eid}")
    else:
        seen_ids.add(eid)
    check_ref(e.get("from"), f"{where}.from", P, ids, sheets, allow_list=True)
    check_ref(e.get("to"), f"{where}.to", P, ids, sheets)
    cl = e.get("class")
    if cl not in CLASSES:
        P.add(where, f"class {cl!r} must be one of: {', '.join(CLASSES)}")
    rel = e.get("relation")
    if cl in ("rounded_match", "arithmetic_transformation") and not rel:
        P.add(where, f"{cl} needs a relation, e.g. {{\"op\": \"round\", \"factor\": 0.001, \"decimals\": 0}} or {{\"op\": \"sum\"}}")
    if rel is not None:
        if not isinstance(rel, dict) or rel.get("op") not in OPS:
            P.add(where, f"relation.op must be one of {', '.join(sorted(OPS))}")
        elif rel["op"] == "multiply" and "by" not in rel:
            P.add(where, "relation multiply needs 'by' (a number or a cell)")
        elif rel["op"] in ("round", "scale") and "factor" not in rel and rel["op"] == "scale":
            P.add(where, "relation scale needs 'factor'")
    if not e.get("what"):
        P.add(where, "say in a few words what the edge carries ('what')")


def check_list(doc, key, where, P, cap=None):
    v = doc.get(key)
    if v is None:
        return []
    if not isinstance(v, list):
        P.add(where, f"{key} must be a list")
        return []
    cap = cap or ITEM_CAPS.get(key)
    if cap and len(v) > cap:
        P.add(where, f"{key} has {len(v)} items; keep at most {cap} material ones and move the rest to evidence/ (notes.md)")
    return v


def validate_stage(kind, n, doc, ctx):
    """ctx: {"ids": set of source ids, "sheets": {id: [sheet names]}, "edge_ids": set already used by other stages,
    "w_ids": supplied workbook ids}. Returns Problems (empty = valid)."""
    P = Problems()
    st = stage_info(kind, n)
    if "_template" in doc:
        P.add("template", "this is still the template: replace every illustrative value with what the workbooks show, and remove '_template'")
    size = len(json.dumps(doc, ensure_ascii=False))
    if st[4] and size > st[4]:
        P.add("size", f"{size:,} bytes, cap {st[4]:,}: this is the primary result, keep it to material items and move detail "
                      "(inventories, cell dumps, reasoning) to evidence/ or notes.md")
    ids, sheets, w_ids = ctx["ids"], ctx["sheets"], ctx["w_ids"]
    seen = set(ctx.get("edge_ids", set()))
    name = st[1]
    if name == "roles" or (kind == "blind" and name == "core"):
        for k in ("company", "quarter_end", "produced_by"):
            if not doc.get(k):
                P.add(name, f"'{k}' is required")
        if doc.get("quarter_end") and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(doc["quarter_end"])):
            P.add(name, "quarter_end is YYYY-MM-DD")
        srcs = check_list(doc, "sources", name, P, cap=40)
        got = {}
        for i, s in enumerate(srcs):
            if not isinstance(s, dict) or s.get("id") not in ids:
                P.add(f"sources[{i}]", f"id must be one of {', '.join(sorted(ids))}")
                continue
            if s.get("role") not in ROLES:
                P.add(f"sources[{i}]", f"role must be one of: {', '.join(ROLES)}")
            if not s.get("contributes"):
                P.add(f"sources[{i}]", "say in one line what it contributes (or why nothing)")
            got[s["id"]] = s.get("role")
        missing = sorted(w for w in w_ids if w not in got)
        if missing:
            P.add(name, f"every supplied workbook needs a role (missing {', '.join(missing)}); 'not_used' is a valid role")
        vw = doc.get("valuation_workbook")
        if vw not in w_ids:
            P.add(name, "valuation_workbook must be a supplied workbook id")
        elif got.get(vw) != "company_valuation":
            P.add(name, f"valuation_workbook {vw} must have role company_valuation")
        fw = doc.get("fund_workbook")
        if fw is not None and (fw not in w_ids or got.get(fw) != "fund_valuation"):
            P.add(name, "fund_workbook must be a supplied workbook with role fund_valuation, or null if none was supplied")
    if name == "chain" or (kind == "blind" and name == "core"):
        ch = doc.get("chain")
        if not isinstance(ch, dict):
            P.add(name, "'chain' is required")
        else:
            if ch.get("source") not in w_ids:
                P.add("chain.source", "the company valuation workbook id")
            if ch.get("method") not in METHODS:
                P.add("chain.method", f"one of {', '.join(sorted(METHODS))}")
            for r in ("valuation_metric", "selected_multiple", "enterprise_value", "equity_value", "value_to_xpv"):
                x = ch.get(r)
                if not isinstance(x, dict) or not x.get("cell"):
                    P.add(f"chain.{r}", "required: {\"cell\": \"'Sheet'!A1\", \"what\": ..., \"units\": ..., \"currency\": ...}")
                else:
                    check_ref({"source": ch.get("source"), "cell": x["cell"]}, f"chain.{r}", P, ids, sheets)
            for i, b in enumerate(ch.get("bridge") or []):
                check_ref({"source": ch.get("source"), "cell": b.get("cell")}, f"chain.bridge[{i}]", P, ids, sheets)
                if b.get("sign") not in (1, -1):
                    P.add(f"chain.bridge[{i}]", "sign is 1 or -1, as the equity formula uses the cell")
            for i, w in enumerate(ch.get("waterfall") or []):
                check_ref({"source": ch.get("source"), "cell": w.get("cell")}, f"chain.waterfall[{i}]", P, ids, sheets)
            mw = ch.get("metric_window")
            if not isinstance(mw, dict):
                P.add("chain.metric_window", "required: {source, cells (12 monthly cells), first, last, link} - or link 'unresolved'")
            elif mw.get("link") != "unresolved" or mw.get("cells"):
                check_ref({"source": mw.get("source"), "cell": mw.get("cells")}, "chain.metric_window", P, ids, sheets)
                for k in ("first", "last"):
                    if not re.fullmatch(r"\d{4}-\d{2}", str(mw.get(k, ""))):
                        P.add(f"chain.metric_window.{k}", "YYYY-MM")
                if mw.get("link") not in CLASSES:
                    P.add("chain.metric_window.link", f"one of {', '.join(CLASSES)}")
            fc = ch.get("fund_cell")
            if fc is not None:
                check_ref(fc, "chain.fund_cell", P, ids, sheets)
        path = check_list(doc, "path", name, P)
        if not path:
            P.add(name, "'path' is required: the cells you started from and moved through, in order ([{source, cell, step}])")
        for i, p in enumerate(path):
            check_ref(p, f"path[{i}]", P, ids, sheets)
        if doc.get("direction") not in ("top_down", "bottom_up", "other"):
            P.add(name, "direction is top_down (from the reported value back), bottom_up (from source financials forward) or other")
    for key in ("provenance", "downstream"):
        cap = BLIND_PROVENANCE_CAP if kind == "blind" and key == "provenance" else None
        for i, e in enumerate(check_list(doc, key, name, P, cap)):
            check_edge(e, f"{key}[{i}]", P, ids, sheets, seen)
    for i, d in enumerate(check_list(doc, "discrepancies", name, P)):
        did = d.get("id") if isinstance(d, dict) else None
        if not did:
            P.add(f"discrepancies[{i}]", "needs an id (D1, ...)")
        elif did in seen:
            P.add(f"discrepancies[{i}]", f"duplicate id {did}")
        else:
            seen.add(did)
        if isinstance(d, dict):
            check_ref(d.get("a"), f"discrepancies[{i}].a", P, ids, sheets)
            check_ref(d.get("b"), f"discrepancies[{i}].b", P, ids, sheets)
            if d.get("status") not in ("unresolved", "explained"):
                P.add(f"discrepancies[{i}]", "status is unresolved or explained")
            if not d.get("what"):
                P.add(f"discrepancies[{i}]", "say what differs ('what')")
    for i, r in enumerate(check_list(doc, "rejected", name, P)):
        check_ref(r, f"rejected[{i}]", P, ids, sheets)
        if isinstance(r, dict) and not r.get("why"):
            P.add(f"rejected[{i}]", "say why it is not the answer")
    for key in ("open_questions", "deferred"):
        for i, q in enumerate(check_list(doc, key, name, P)):
            if not isinstance(q, str) or not q.strip():
                P.add(f"{key}[{i}]", "one plain sentence")
    for i, x in enumerate(check_list(doc, "inputs", name, P)):
        check_ref(x, f"inputs[{i}]", P, ids, sheets)
    if name in ("chain", "questions") and kind == "extraction":
        hw = doc.get("how_it_works")
        if name == "questions" and not hw:
            P.add(name, "'how_it_works' (5-15 plain sentences) is required in this stage")
        if hw and len(hw) > 3000:
            P.add("how_it_works", "keep it to 5-15 sentences (under 3,000 characters)")
    if name == "challenges":
        for i, c in enumerate(check_list(doc, "challenges", name, P)):
            if not isinstance(c, dict) or c.get("kind") not in CHALLENGE_KINDS:
                P.add(f"challenges[{i}]", f"kind must be one of {', '.join(sorted(CHALLENGE_KINDS))}")
                continue
            if not c.get("id"):
                P.add(f"challenges[{i}]", "needs an id (C1, ...)")
            check_ref(c.get("cells"), f"challenges[{i}].cells", P, ids, sheets, allow_list=True)
            if not c.get("note"):
                P.add(f"challenges[{i}]", "say what a careless reader would get wrong ('note')")
    if name == "findings":
        for i, f in enumerate(check_list(doc, "findings", name, P)):
            if not isinstance(f, dict) or f.get("type") not in FINDING_TYPES:
                P.add(f"findings[{i}]", f"type must be one of {', '.join(FINDING_TYPES)}")
                continue
            if not f.get("id"):
                P.add(f"findings[{i}]", "needs an id (F1, ...)")
            if not f.get("target"):
                P.add(f"findings[{i}]", "target: the extraction item it concerns (an edge id, chain.<role>, a discrepancy id, "
                                        "sources.<id>, or 'new' for a missed rival)")
            ev = f.get("evidence")
            if f["type"] != "unsure":
                check_ref(ev, f"findings[{i}].evidence", P, ids, sheets, allow_list=True)
            cl = f.get("claim")
            if cl is not None:
                if "class" in cl:
                    check_edge(dict(cl, id=cl.get("id") or f"{f.get('id')}-claim"), f"findings[{i}].claim", P, ids, sheets, set())
                elif "chain_role" in cl:
                    check_ref(cl.get("cell") and {"source": cl.get("source"), "cell": cl.get("cell")}, f"findings[{i}].claim", P, ids, sheets)
                else:
                    P.add(f"findings[{i}].claim", "a claim is an edge {from, to, class, relation?} or {chain_role, source, cell}")
        if not doc.get("overall"):
            P.add(name, "'overall': two or three sentences - is the extraction complete and correct enough to onboard from?")
        if not doc.get("produced_by"):
            P.add(name, "'produced_by' is required")
    return P
