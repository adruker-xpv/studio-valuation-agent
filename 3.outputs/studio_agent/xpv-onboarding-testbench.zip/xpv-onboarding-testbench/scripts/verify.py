# verify.py (build 13.0) - narrow, deterministic checks of the AI's claims. It never decides what the workbooks mean; it tests
# each specific claim the extraction makes against the workbooks' own formulas and saved values:
#   integrity     every source's SHA-256 matches a supplied file, and every supplied file is in the extraction
#   chain         the five chain cells hold numbers; EV = metric x multiple; equity = EV + the signed bridge items; the value to
#                 XPV is calculated from equity; none of them is a plain copy or a cell inside a what-if data table; the EV
#                 column's header is the valuation quarter
#   window        the 12 monthly cells named (in whichever workbook) are 12 consecutive months ending in the valuation month and
#                 sum to the metric; a window claimed as a formula link really is one
#   edges         each provenance / downstream edge holds for its evidence class: a direct_formula_link is in the formula; a
#                 pasted_exact_match is equal and NOT a formula link; a rounded_match agrees only after the stated rounding; an
#                 arithmetic_transformation recomputes. Numeric equality is never promoted to a link.
#   discrepancies each recorded discrepancy is real (the two values do differ, by the stated amount if one is stated)
#   fund          the company value reaches the fund-reported cell (company's row, quarter's column) through confirmed edges -
#                 or a confirmed discrepancy records why the reported value differs. A preserved discrepancy is a PASS.
# Status: VERIFIED (no claim contradicted; chain, window and fund all confirmed; all stages saved) | SUPPORTED (nothing
# contradicted, but something could not be checked or is honestly unresolved) | PROVISIONAL (nothing contradicted so far, stages
# still to come) | REVIEW (a claim is contradicted, or the files are not the ones the extraction names).
# Usage: python verify.py --run-dir R [--kind extraction|blind] [--file X.json] [--period-end YYYY-MM-DD] [--company "..."]
#                         [--workbooks ...] [--final] [--out verification.json]
import argparse, datetime, difflib, hashlib, json, os, re, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from xlsx_evidence import (SourceSet, formula_refs, parse_cell, parse_range, split_ref, addr, num, norm_file,  # noqa: E402
                           ref_contains, quote_sheet, fmt_value, OutOfTime)
from onboarding_schema import CLASSES, CHECKABLE, STAGES, SCHEMA_VERSION  # noqa: E402

VERSION = SCHEMA_VERSION
MONTHS = {m: i + 1 for i, m in enumerate(("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"))}
LAST = {1: (31,), 2: (28, 29), 3: (31,), 4: (30,), 5: (31,), 6: (30,), 7: (31,), 8: (31,), 9: (30,), 10: (31,), 11: (30,), 12: (31,)}
COPY_RE = re.compile(r"=\s*(ROUND\()?\s*('?[^!]+'?!)?\$?[A-Z]{1,3}\$?\d+\s*(/\s*1000(000)?)?\s*(,\s*-?\d+\s*\))?\s*", re.I)


def ym(y, m):
    return f"{y:04d}-{m:02d}"


def parse_period(v, above=()):
    """a header -> 'YYYY-MM' (period END) or None. 'Jun 30' with no year takes the year from a year header above; never 2030."""
    if isinstance(v, (datetime.datetime, datetime.date)):
        return ym(v.year, v.month)
    if not isinstance(v, str):
        return None
    t = v.strip().lower()
    m = re.search(r"\b(20\d{2})-(\d{2})(?:-\d{2})?\b", t)
    if m:
        return ym(int(m.group(1)), int(m.group(2)))
    m = re.search(r"\b(\d{1,2})/(\d{1,2})/(20\d{2})\b", t)
    if m:
        a, b, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if a > 12 >= b:
            return ym(y, b)
        if b > 12 >= a or a == b:
            return ym(y, a)
        return None
    m = re.search(r"\bq([1-4])[\s\-']*(20\d{2}|\d{2})\b", t) or re.search(r"\b(20\d{2})[\s\-]*q([1-4])\b", t)
    if m:
        g1, g2 = m.group(1), m.group(2)
        qn, y = (g1, g2) if t[m.start()] == "q" else (g2, g1)
        y = int(y) + (2000 if len(y) == 2 else 0)
        return ym(y, int(qn) * 3)
    m = re.search(r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?[\s\-']*(\d{1,2})(?:st|nd|rd|th)?,?[\s\-']*(20\d{2})\b", t)
    if m:
        return ym(int(m.group(3)), MONTHS[m.group(1)])
    m = re.search(r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?[\s\-'/]*(20\d{2}|\d{2})\b(?![\s\-'/,]*\d)", t)
    if m:
        mo, n = MONTHS[m.group(1)], m.group(2)
        if len(n) == 2 and int(n) in LAST[mo] and not re.search(r"20\d{2}", t):
            for y in above:
                if isinstance(y, (int, float)) and not isinstance(y, bool) and 1990 <= y <= 2100:
                    return ym(int(y), mo)
                if isinstance(y, str) and re.fullmatch(r"\s*(?:fy\s*)?(19|20)\d{2}\s*", y.lower()):
                    return ym(int(re.search(r"\d{4}", y).group()), mo)
            return None
        return ym(int(n) + (2000 if len(n) == 2 else 0), mo)
    return None


class World:
    """the run's workbooks, addressed as (source id, sheet, cell). X ids are linked files that were not supplied."""

    def __init__(self, srcs):
        self.srcs = srcs
        self.xfile = {x["id"]: norm_file(x["file"] or "") for x in srcs.external}
        self._up = {}

    def book(self, sid):
        return self.srcs.books.get(sid)

    def sheet(self, sid, sh):
        b = self.book(sid)
        return b.resolve_sheet(sh) if b else sh

    def key(self, sid, sh, a):
        return (sid, self.sheet(sid, sh) if sid in self.srcs.books else sh, a.replace("$", "").upper())

    def cell(self, sid, sh, a):
        b = self.book(sid)
        if not b:
            return None
        s = b.resolve_sheet(sh)
        return b.get(s, a) if s else None

    def value(self, sid, sh, a):
        if sid in self.xfile:
            for b in self.srcs.books.values():
                for x in b.ext.values():
                    if norm_file(x["file"] or "") == self.xfile[sid]:
                        for (s2, a2), v in x["cache"].items():
                            if s2.lower() == sh.lower() and a2 == a:
                                return v
            return None
        c = self.cell(sid, sh, a)
        return c[0] if c else None

    def exists(self, sid, sh):
        if sid in self.xfile:
            return True
        b = self.book(sid)
        return bool(b and b.resolve_sheet(sh))

    def expand(self, ref):
        """{"source", "cell"} -> [(sid, sheet, addr)] for every cell of the rectangle (row-major), or raise ValueError."""
        sid = ref.get("source")
        sh, rng = split_ref(ref.get("cell", ""))
        if sid not in self.srcs.books and sid not in self.xfile:
            raise ValueError(f"source {sid} was not supplied")
        if not self.exists(sid, sh):
            raise ValueError(f"{sid} has no sheet {sh!r}")
        b = parse_range(rng)
        if not b or None in b:
            raise ValueError(f"{rng!r} is not a bounded range")
        if (b[2] - b[0] + 1) * (b[3] - b[1] + 1) > 5000:
            raise ValueError(f"{rng} is too large to check (more than 5,000 cells); name the rows that matter")
        s = self.sheet(sid, sh)
        return [(sid, s, addr(r, c)) for r in range(b[0], b[2] + 1) for c in range(b[1], b[3] + 1)]

    def refs(self, sid, sh, a):
        """the formula's references, resolved: [(sid2, sheet2, range)], sid2 = W/X id or None (a file not in the run)."""
        c = self.cell(sid, sh, a)
        if not c or not c[1]:
            return []
        b = self.book(sid)
        out = []
        for ext, rs, rng in formula_refs(c[1], self.sheet(sid, sh), b):
            if ext is None:
                out.append((sid, b.resolve_sheet(rs) or rs, rng))
            else:
                out.append((self.srcs.by_file(b.ext_file(ext) or ""), rs, rng))
        return out

    def refers_to(self, sid, sh, a, tgt):
        """does the formula in (sid, sh, a) refer to cell tgt = (sid2, sh2, a2)?"""
        for s2, rs, rng in self.refs(sid, sh, a):
            if s2 == tgt[0] and str(rs).lower() == str(tgt[1]).lower() and ref_contains(rng, tgt[2]):
                return True
        return False

    def upstream(self, sid, sh, a, cross=True, limit=20000):
        """every cell the formula depends on (populated cells of the ranges it names), across supplied workbooks if cross."""
        k0 = (sid, self.sheet(sid, sh), a, cross)
        if k0 in self._up:
            return self._up[k0]
        seen, todo, ranges = set(), [(sid, self.sheet(sid, sh), a)], set()
        while todo and len(seen) < limit:
            x = todo.pop()
            for s2, rs, rng in self.refs(*x):
                if s2 is None or (s2 != x[0] and not cross):
                    continue
                ranges.add((s2, str(rs).lower(), rng))
                b = self.book(s2)
                if not b:
                    continue
                rsn = b.resolve_sheet(rs)
                if not rsn:
                    continue
                for kk in b.range_keys(rsn, rng):
                    y = (s2, rsn, addr(*kk))
                    if y not in seen:
                        seen.add(y)
                        todo.append(y)
        self._up[k0] = (seen, ranges)
        return seen, ranges


def column_period(W, sid, sh, a, max_up=40):
    b = W.book(sid)
    if not b:
        return None, None
    cells = b.cells(b.resolve_sheet(sh))
    rc = parse_cell(a)
    if not rc:
        return None, None
    r1, c1 = rc
    for r in range(r1 - 1, max(0, r1 - max_up), -1):
        v = cells.get((r, c1), (None,))[0]
        if v is None or isinstance(v, (int, float)) and not isinstance(v, bool) and not 1990 <= v <= 2100:
            continue
        above = []
        for rr in range(r - 1, max(0, r - 4), -1):
            x = cells.get((rr, c1), (None,))[0]
            if x is None:
                for cc in range(c1 - 1, max(0, c1 - 12), -1):
                    x = cells.get((rr, cc), (None,))[0]
                    if x is not None:
                        break
            above.append(x)
        p = parse_period(v, above)
        if p:
            return p, addr(r, c1)
    return None, None


def close(a, b, rel=1e-9, ab=0.01):
    return a is not None and b is not None and abs(a - b) <= max(ab, rel * max(abs(a), abs(b)))


def apply(rel, vals, W):
    """expected target value from source values under a relation."""
    op = (rel or {}).get("op", "equal")
    if op == "sum":
        return sum(vals)
    if op == "subtract":
        return vals[0] - sum(vals[1:])
    v = vals[0]
    if op == "equal":
        return v
    if op in ("scale", "round"):
        return v * float(rel.get("factor", 1))
    if op == "negate":
        return -v
    if op == "multiply":
        by = rel["by"]
        if isinstance(by, dict):
            ks = W.expand(by)
            by = num(W.value(*ks[0]))
            if by is None:
                raise ValueError("the 'by' cell holds no number")
        return v * float(by)
    raise ValueError(f"unknown op {op}")


def agrees(rel, expected, got):
    op = (rel or {}).get("op", "equal")
    if op == "round":
        d = int(rel.get("decimals", 0))
        return abs(got - expected) <= 0.5 * 10 ** (-d) + 1e-9 * max(1, abs(expected))
    tol = float((rel or {}).get("tolerance", 0.01))
    return abs(got - expected) <= max(tol, 1e-9 * max(abs(expected), abs(got)))


def fmt_ref(k):
    return f"{k[0]}:{quote_sheet(k[1])}!{k[2]}"


def check_edge(W, e):
    """-> (status, note): confirmed | contradicted | not_checkable"""
    cls, rel = e.get("class"), e.get("relation")
    froms = e["from"] if isinstance(e.get("from"), list) else [e.get("from")]
    try:
        tcells = W.expand(e["to"])
        fcells = [W.expand(f) for f in froms]
    except (ValueError, KeyError, TypeError) as x:
        return "contradicted", f"cannot read the cells named: {x}"
    for k in tcells + [k for fs in fcells for k in fs]:
        if W.value(*k) is None and not (W.cell(*k) or (None, None))[1]:
            return "contradicted", f"{fmt_ref(k)} is empty"
    if cls not in CHECKABLE:
        return "not_checkable", f"{cls.replace('_', ' ')}: judgment, no numeric test"
    op = (rel or {}).get("op", "round" if cls == "rounded_match" else "equal")
    # pair source cells with target cells
    if op in ("sum", "subtract"):
        if len(tcells) != 1:
            return "contradicted", f"'{op}' needs one target cell, got {len(tcells)}"
        flat = [k for fs in fcells for k in fs]
        pairs = [(flat if op == "sum" else [fs[0] for fs in fcells], tcells[0])]
    else:
        if len(fcells) != 1:
            return "contradicted", "a list of sources needs op 'sum' or 'subtract'"
        if len(fcells[0]) != len(tcells):
            return "contradicted", f"source has {len(fcells[0])} cells, target {len(tcells)}: name ranges of the same size"
        pairs = [([f], t) for f, t in zip(fcells[0], tcells)]
    notes = []
    for srcs, t in pairs:
        tc = W.cell(*t)
        tf = tc[1] if tc else None
        linked = [s for s in srcs if tf and W.refers_to(*t, s)]
        if cls == "direct_formula_link":
            missing = [s for s in srcs if s not in linked]
            if missing:
                vals = [num(W.value(*s)) for s in missing]
                tv = num(W.value(*t))
                same = len(missing) == 1 and close(vals[0], tv)
                where = (f"its formula is {tf}" if tf else "it is a typed number, not a formula")
                return "contradicted", (f"{fmt_ref(t)} does not refer to {fmt_ref(missing[0])}: {where}"
                                        + (". The values are equal - that is a match, not a link" if same else ""))
        elif cls in ("pasted_exact_match", "rounded_match"):
            if linked:
                return "contradicted", f"{fmt_ref(t)} is a formula that refers to {fmt_ref(linked[0])} ({tf}): classify direct_formula_link"
            if tf and len(notes) < 2:
                notes.append(f"{fmt_ref(t)} is a formula ({tf[:60]}) that does not refer to the source; values compared only")
        if cls == "direct_formula_link" and not rel:
            continue
        vals = [num(W.value(*s)) for s in srcs]
        tv = num(W.value(*t))
        if tv is None or None in vals:
            return "contradicted", f"no number in {fmt_ref(t) if tv is None else fmt_ref(srcs[vals.index(None)])}"
        try:
            exp = apply(dict(rel or {}, op=op), vals, W)
        except (ValueError, KeyError) as x:
            return "contradicted", str(x)
        if not agrees(dict(rel or {}, op=op), exp, tv):
            return "contradicted", f"{fmt_ref(t)} = {fmt_value(tv)}, but {op} of the source gives {fmt_value(exp)}"
        if cls == "rounded_match" and close(exp, tv, ab=1e-6) and "exactly equal after scaling (no rounding needed)" not in notes:
            notes.append("exactly equal after scaling (no rounding needed)")
    return "confirmed", "; ".join(notes) or ("formula link found" if cls == "direct_formula_link" else "values reproduce")


def check_discrepancy(W, d):
    try:
        ka, kb = W.expand(d["a"]), W.expand(d["b"])
    except (ValueError, KeyError, TypeError) as x:
        return "contradicted", f"cannot read the cells named: {x}", None
    if len(ka) != 1 or len(kb) != 1:
        return "contradicted", "a discrepancy compares two single cells", None
    va, vb = num(W.value(*ka[0])), num(W.value(*kb[0]))
    if va is None or vb is None:
        return "contradicted", "one of the two cells holds no number", None
    rel = d.get("relation") or {"op": "equal"}
    try:
        exp = apply(rel, [va], W)
    except (ValueError, KeyError) as x:
        return "contradicted", str(x), None
    diff = vb - exp
    if agrees(rel, exp, vb):
        return "contradicted", f"the values agree ({fmt_value(vb)} vs {fmt_value(exp)} expected): this is not a discrepancy", diff
    st = d.get("difference")
    if st is not None:
        unit = 0.5 * 10 ** (-int(rel.get("decimals", 0))) + 0.5 if rel.get("op") == "round" else max(0.5, 1e-6 * abs(diff))
        if abs(float(st) - diff) > unit:
            return "contradicted", f"stated difference {fmt_value(float(st))}, actual {fmt_value(diff)}", diff
    return "confirmed", f"b - expected = {fmt_value(diff)} (preserved for the analyst)", diff


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", default=".")
    ap.add_argument("--kind", default="extraction", choices=["extraction", "blind"])
    ap.add_argument("--file")
    ap.add_argument("--period-end")
    ap.add_argument("--company")
    ap.add_argument("--workbooks", nargs="*")
    ap.add_argument("--final", action="store_true", help="record stage 7 (validation) and mark the extraction final if it passes")
    ap.add_argument("--out")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args(argv)
    t0 = time.time()
    path = a.file or os.path.join(a.run_dir, "extraction.json" if a.kind == "extraction" else "reviewer_blind.json")
    X = json.load(open(path))
    srcs = SourceSet(a.run_dir)
    if a.workbooks:
        srcs.open_paths(a.workbooks)
    srcs.ensure_all()
    if not srcs.external and X.get("external"):
        srcs.external = X["external"]
    W = World(srcs)
    res, det = {}, {}

    def put(k, s, d):
        res[k], det[k] = s, d

    want = (a.period_end or X.get("quarter_end") or "")[:7]
    company = a.company or X.get("company")
    # integrity: ids are mapped by SHA-256, so a renamed copy of the same file still matches
    supplied = {b.sha256: sid for sid, b in srcs.books.items()}
    named = {s.get("sha256"): s.get("id") for s in X.get("sources") or []}
    remap, problems = {}, []
    for sha, sid in named.items():
        if sha not in supplied:
            problems.append(f"{sid}: no supplied file has SHA-256 {str(sha)[:12]}... (changed or different file)")
        elif supplied[sha] != sid:
            remap[sid] = supplied[sha]
    for sha, sid in supplied.items():
        if sha not in named:
            problems.append(f"supplied file {srcs.books[sid].file} ({sid}) is not in the extraction's sources")
    if remap:                                        # the extraction used other ids for the same files: translate its refs
        X = json.loads(json.dumps(X).replace("\u0000", ""))

        def tr(o):
            if isinstance(o, dict):
                return {k: (remap.get(v, v) if k in ("source", "id", "valuation_workbook", "fund_workbook") and isinstance(v, str) else tr(v)) for k, v in o.items()}
            if isinstance(o, list):
                return [tr(v) for v in o]
            return o
        X = tr(X)
    put("integrity", "fail" if problems else "pass", {"problems": problems, "id_map": remap})
    # roles
    rp = [f"{s.get('id')}: no role" for s in X.get("sources") or [] if not s.get("role")]
    vw = X.get("valuation_workbook") or (X.get("chain") or {}).get("source")
    put("roles", "fail" if rp or not vw else "pass", rp or ([] if vw else ["no valuation workbook named"]))

    ch = X.get("chain") or {}
    cs = ch.get("source")
    roles = {r: (ch.get(r) or {}).get("cell") for r in ("valuation_metric", "selected_multiple", "enterprise_value", "equity_value", "value_to_xpv")}
    bad, warn = [], []
    K = {}
    for r, c in roles.items():
        if not c or cs not in srcs.books:
            bad.append(f"{r}: missing")
            continue
        sh, ad = split_ref(c)
        if not W.exists(cs, sh):
            bad.append(f"{r}: {cs} has no sheet {sh!r}")
            continue
        k = W.key(cs, sh, ad)
        K[r] = k
        cell = W.cell(*k)
        if not cell or num(cell[0]) is None:
            bad.append(f"{r}: {fmt_ref(k)} holds no number ({fmt_value(cell[0]) if cell else 'empty'})")
            continue
        if cell[4] and cell[4][0].startswith("dataTable"):
            bad.append(f"{r}: {fmt_ref(k)} is inside a what-if data table (a sensitivity), not a live chain cell")
        b = W.book(cs)
        if b.sheets[b.sheet_index[k[1]]]["state"] != "visible":
            warn.append(f"{r}: on a {b.sheets[b.sheet_index[k[1]]]['state']} sheet")
    chain_det = {"problems": bad, "warnings": warn}
    if not bad:
        v = {r: num(W.value(*k)) for r, k in K.items()}
        comps = ch.get("components") or [{"metric": roles["valuation_metric"], "multiple": roles["selected_multiple"], "weight": None}]
        up_ev, _ = W.upstream(*K["enterprise_value"], cross=False)
        try:
            calc = 0.0
            used = True
            for c_ in comps:
                km, kx = W.key(cs, *split_ref(c_["metric"])), W.key(cs, *split_ref(c_["multiple"]))
                used &= km in up_ev and kx in up_ev
                wgt = num(W.value(*W.key(cs, *split_ref(c_["weight"])))) if c_.get("weight") else 1.0
                calc += num(W.value(*km)) * num(W.value(*kx)) * wgt
        except (TypeError, KeyError):
            calc, used = None, False
        if not used:
            bad.append("ev: the EV formula does not use the metric and the multiple named")
        if not close(calc, v["enterprise_value"], rel=1e-6):
            bad.append(f"ev: EV {fmt_value(v['enterprise_value'])} is not metric x multiple ({fmt_value(calc)})")
        up_eq, _ = W.upstream(*K["equity_value"], cross=False)
        if K["enterprise_value"] not in up_eq and K["enterprise_value"] != K["equity_value"]:
            bad.append("bridge: equity is not calculated from the EV named")
        items = ch.get("bridge") or []
        try:
            calc_eq = v["enterprise_value"] + sum(int(i.get("sign", 1)) * (num(W.value(*W.key(cs, *split_ref(i["cell"])))) or 0) for i in items)
            miss = [i["cell"] for i in items if W.key(cs, *split_ref(i["cell"])) not in up_eq]
        except (KeyError, TypeError):
            calc_eq, miss = None, ["(unreadable bridge item)"]
        if miss:
            bad.append(f"bridge: equity's formula does not use {', '.join(miss)}")
        if not close(calc_eq, v["equity_value"], rel=1e-6):
            bad.append(f"bridge: equity {fmt_value(v['equity_value'])} is not EV + the signed bridge items ({fmt_value(calc_eq)})")
        up_x, _ = W.upstream(*K["value_to_xpv"], cross=False)
        if K["equity_value"] not in up_x and K["equity_value"] != K["value_to_xpv"]:
            bad.append("xpv: the value to XPV is not calculated from the equity value named")
        for w_ in ch.get("waterfall") or []:
            try:
                kw = W.key(cs, *split_ref(w_["cell"]))
            except (KeyError, TypeError):
                continue
            if kw not in up_x and kw != K["value_to_xpv"]:
                warn.append(f"waterfall step {w_['cell']} is not upstream of the value to XPV")
        for r in ("enterprise_value", "equity_value", "value_to_xpv"):
            f = (W.cell(*K[r]) or (None, None))[1]
            if f and COPY_RE.fullmatch(f.replace("$", "")) and len(W.refs(*K[r])) == 1:
                bad.append(f"not_a_copy: {r} {fmt_ref(K[r])} only repeats another cell ({f}); name the calculation")
        p, where = column_period(W, *K["enterprise_value"])
        chain_det["period"] = {"header": where, "period": p, "wanted": want}
        if p and want and p != want:
            bad.append(f"period: the EV column's header {where} says {p}, not {want}")
        elif not p:
            warn.append("period: no period header found above the EV")
    put("chain", "fail" if bad else "pass", chain_det)

    # window
    mw = ch.get("metric_window") or {}
    if not mw or (mw.get("link") == "unresolved" and not mw.get("cells")):
        put("window", "unresolved", "the 12-month window is recorded as unresolved")
    elif "valuation_metric" not in K:
        put("window", "not checked", "chain cells failed")
    else:
        wd = {}
        try:
            ks = W.expand({"source": mw.get("source"), "cell": mw.get("cells")})
        except ValueError as x:
            ks, wd["problem"] = [], str(x)
        vals = [num(W.value(*k)) for k in ks]
        months = [column_period(W, *k)[0] for k in ks] if ks else []
        consecutive = len(months) == 12 and None not in months and all(
            (int(months[i + 1][:4]) * 12 + int(months[i + 1][5:])) - (int(months[i][:4]) * 12 + int(months[i][5:])) == 1 for i in range(11))
        metric = num(W.value(*K["valuation_metric"]))
        try:
            total = apply(mw.get("relation") or {"op": "equal"}, [sum(x for x in vals if x is not None)], W) if vals else None
        except (ValueError, KeyError):
            total = None
        sums = len(ks) == 12 and None not in vals and close(total, metric, rel=1e-6, ab=1)
        ends = bool(months) and months[-1] == want and mw.get("last") == want and mw.get("first") == months[0]
        wd.update(cells=len(ks), months=months, consecutive=consecutive, ends_in_valuation_month=ends, sum=total, metric=metric, sums_to_metric=sums)
        linked = None
        if mw.get("link") == "direct_formula_link" and ks:
            up, rngs = W.upstream(*K["valuation_metric"], cross=True)
            wset = set(ks)
            linked = bool(wset & up) or any(any(r[0] == k[0] and r[1] == k[1].lower() and ref_contains(r[2], k[2]) for k in ks) for r in rngs)
            wd["formula_path_from_metric"] = linked
        if len(ks) != 12 or not sums:
            st = "fail"
        elif None in months:
            st = "not checked"
        elif not (consecutive and ends):
            st = "fail"
        elif linked is False:
            st = "fail"
            wd["problem"] = ("the window is claimed as a formula link, but no formula path leads from the metric to these cells; "
                             "if the numbers agree, the link is an arithmetic_transformation (sum) or a match, not a link")
        else:
            st = "pass"
        put("window", st, wd)

    # edges and discrepancies
    edges = []
    for sec in ("provenance", "downstream"):
        for e in X.get(sec) or []:
            s, n = check_edge(W, e)
            edges.append({"id": e.get("id"), "section": sec, "class": e.get("class"), "status": s, "note": n, "material": e.get("material", True)})
    discs = []
    for d in X.get("discrepancies") or []:
        s, n, diff = check_discrepancy(W, d)
        discs.append({"id": d.get("id"), "status": s, "note": n, "difference": diff, "resolution": d.get("status")})
    ed = {"confirmed": sum(e["status"] == "confirmed" for e in edges), "contradicted": sum(e["status"] == "contradicted" for e in edges),
          "not_checkable": sum(e["status"] == "not_checkable" for e in edges)}
    put("edges", "fail" if ed["contradicted"] else "pass", ed)
    put("discrepancies", "fail" if any(d["status"] == "contradicted" for d in discs) else "pass",
        {"confirmed": sum(d["status"] == "confirmed" for d in discs), "contradicted": sum(d["status"] == "contradicted" for d in discs)})

    # fund: the reported value is reached by confirmed edges, or a confirmed discrepancy explains why it differs
    fc = ch.get("fund_cell")
    if not fc:
        put("fund", "not given" if not X.get("fund_workbook") else "fail", "no fund cell named" if X.get("fund_workbook") else "no fund workbook")
    elif "value_to_xpv" not in K:
        put("fund", "not checked", "chain cells failed")
    else:
        fd = {}
        try:
            fk = W.expand(fc)[0]
        except ValueError as x:
            fk, fd["problem"] = None, str(x)
        if fk:
            fv = num(W.value(*fk))
            fb = W.book(fk[0])
            row = parse_cell(fk[2])[0]
            cells = fb.cells(fk[1]) if fb else {}
            row_txt = " ".join(str(c[0]) for (r, cc), c in cells.items() if r == row and cc < parse_cell(fk[2])[1] and isinstance(c[0], str))
            nrm = lambda s: re.sub(r"\b(ltd|inc|llc|corp|co|limited|lp)\b|[^a-z0-9 ]", " ", str(s).lower()).split()
            row_ok = None if not company else (" ".join(nrm(company)) in " ".join(nrm(row_txt)) or
                                               difflib.SequenceMatcher(None, " ".join(nrm(company)), " ".join(nrm(row_txt))).ratio() >= 0.8)
            hp, hw = column_period(W, *fk)
            fd.update(reported=fv, row_label=row_txt[:80], row_matches_company=row_ok, column_period=hp, header=hw)
            graph = {}
            status_by_id = {e["id"]: e["status"] for e in edges}
            for e in X.get("downstream") or []:
                if isinstance(e.get("from"), dict) and status_by_id.get(e.get("id")) == "confirmed":
                    try:
                        f1, t1 = W.expand(e["from"]), W.expand(e["to"])
                    except ValueError:
                        continue
                    if len(f1) == 1 and len(t1) == 1:
                        graph.setdefault(f1[0], []).append((t1[0], e["id"]))
            start = K["value_to_xpv"]
            reach, todo, via = {start: []}, [start], None
            while todo:
                x = todo.pop()
                for y, eid in graph.get(x, []):
                    if y not in reach:
                        reach[y] = reach[x] + [eid]
                        todo.append(y)
            disc_ok = None
            for d, dd in zip(X.get("discrepancies") or [], discs):
                try:
                    ends_ = {W.expand(d["a"])[0], W.expand(d["b"])[0]}
                except (ValueError, KeyError):
                    continue
                if dd["status"] == "confirmed" and fk in ends_ and (ends_ - {fk}) <= set(reach):
                    disc_ok = d.get("id")
            if fk in reach:
                fd["linked_by"] = reach[fk]
                st = "pass"
            elif disc_ok:
                fd["discrepancy"] = disc_ok
                st = "pass"
            elif any(isinstance(e.get("to"), dict) and e["to"] == fc for e in X.get("downstream") or []):
                st = "unresolved"
                fd["note"] = "the hop into the fund cell is recorded but not confirmable (judgment or unresolved)"
            else:
                st = "fail"
                fd["problem"] = "no confirmed edge path from the value to XPV to the fund cell, and no confirmed discrepancy"
            if row_ok is False:
                st, fd["problem"] = "fail", f"the fund cell's row ({row_txt[:40]!r}) is not the company's"
            if want and hp and hp != want:
                st, fd["problem"] = "fail", f"the fund cell's column says {hp}, not {want}"
            put("fund", st, fd)
        else:
            put("fund", "fail", fd)

    # informational: typed numbers the value depends on (inside the valuation workbook) that the extraction never names
    info = {}
    if "value_to_xpv" in K:
        up, _ = W.upstream(*K["value_to_xpv"], cross=False)
        mentioned = set()

        def collect(o):
            if isinstance(o, dict):
                if isinstance(o.get("cell"), str) and o.get("source"):
                    try:
                        mentioned.update(W.expand({"source": o["source"], "cell": o["cell"]}))
                    except ValueError:
                        pass
                for vv in o.values():
                    collect(vv)
            elif isinstance(o, list):
                for vv in o:
                    collect(vv)
        collect({k: X.get(k) for k in ("provenance", "downstream", "rejected", "inputs", "discrepancies", "path")})
        for r_ in [ch.get(r) for r in roles] + list(ch.get("bridge") or []) + list(ch.get("waterfall") or []):
            if isinstance(r_, dict) and r_.get("cell"):
                try:
                    mentioned.update(W.expand({"source": cs, "cell": r_["cell"]}))
                except ValueError:
                    pass
        if mw.get("cells"):
            try:
                mentioned.update(W.expand({"source": mw.get("source"), "cell": mw.get("cells")}))
            except ValueError:
                pass
        typed = sorted(k for k in up if (W.cell(*k) or (None, None))[1] is None and num(W.value(*k)) is not None and k not in mentioned)
        info["typed_inputs_not_named"] = {"count": len(typed), "first": [fmt_ref(k) for k in typed[:15]],
                                          "note": "informational only: typed numbers inside the valuation workbook that the value depends on"}

    failed = [k for k, s in res.items() if s == "fail"]
    stages_ok = True
    if a.kind == "extraction":
        need = [st[0] for st in STAGES["extraction"] if st[2] == "agent"]
        stages_ok = all(n in (X.get("stages_done") or []) for n in need)
    core = [res.get(k) for k in ("integrity", "chain", "window", "fund")]
    if failed:
        status = "REVIEW"
    elif not stages_ok:
        status = "PROVISIONAL"
    elif all(s == "pass" for s in core):
        status = "VERIFIED"
    else:
        status = "SUPPORTED"
    counts = {"edges": ed, "discrepancies": det["discrepancies"], "checks_failed": failed}
    out = {"verify_version": VERSION, "status": status, "checks": res, "detail": det, "edges": edges, "discrepancies": discs, "info": info,
           "file": os.path.basename(path), "kind": a.kind, "period_end": want, "seconds": round(time.time() - t0, 2),
           "workbooks": {sid: {"file": b.file, "sha256": b.sha256} for sid, b in srcs.books.items()}}
    outp = a.out or os.path.join(a.run_dir, "verification.json" if a.kind == "extraction" else "verification_blind.json")
    json.dump(out, open(outp, "w"), indent=1, default=str)
    if a.final and a.kind == "extraction" and not stages_ok:
        print("VERIFY: --final needs stages 1-6 saved first; this was an ordinary check and stage 7 was not recorded")
    if a.final and a.kind == "extraction" and stages_ok:
        sys.path.insert(0, HERE)
        import checkpoint as ckp
        hashes = {}
        for n in [st[0] for st in STAGES["extraction"] if st[2] == "agent"]:
            p_, _ = ckp.latest(a.run_dir, "extraction", n)
            if p_:
                hashes[str(n)] = ckp.sha_file(p_)
        base = os.path.join(a.run_dir, "checkpoints", "07_validation")
        p7, r = base + ".json", 1
        while os.path.exists(p7):
            r += 1
            p7 = f"{base}.r{r}.json"
        json.dump({"stage": 7, "name": "validation", "made_at": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
                   "status": status, "verify_version": VERSION, "counts": counts, "stage_hashes": hashes}, open(p7, "w"), indent=1)
        ckp.assemble(a.run_dir, "extraction")
    if not a.quiet:
        for k in ("integrity", "roles", "chain", "window", "edges", "discrepancies", "fund"):
            extra = ""
            if k == "edges":
                extra = f" | {ed['confirmed']} confirmed, {ed['contradicted']} contradicted, {ed['not_checkable']} judgment (not checkable)"
            if k == "discrepancies" and discs:
                extra = f" | {det['discrepancies']['confirmed']} confirmed real" + (f", {det['discrepancies']['contradicted']} contradicted" if det['discrepancies']['contradicted'] else "")
            if k == "fund" and isinstance(det.get(k), dict):
                d_ = det[k]
                extra = (f" | linked by {', '.join(d_['linked_by'])}" if d_.get("linked_by") else
                         f" | reported value differs: discrepancy {d_['discrepancy']} confirmed and preserved" if d_.get("discrepancy") else "")
            print(f"VERIFY: {k} | {res.get(k)}{extra}")
        shown = 0
        for k in ("chain", "window", "fund", "integrity"):
            d_ = det.get(k)
            msgs = (d_.get("problems") if isinstance(d_, dict) and isinstance(d_.get("problems"), list) else
                    [d_.get("problem")] if isinstance(d_, dict) and d_.get("problem") else [])
            for m in msgs:
                if m and shown < 12:
                    print(f"CONTRADICTED: {k} | {m}")
                    shown += 1
        for e in edges + discs:
            if e["status"] == "contradicted" and shown < 12:
                print(f"CONTRADICTED: {e['id']} | {e['note']}")
                shown += 1
        print(f"VERIFY: status | {status}" + (f" | failed: {', '.join(failed)}" if failed else "") +
              ("" if stages_ok else " | stages still to save") + f" | {out['seconds']}s | verify {VERSION}" +
              (" | recorded as stage 7" if a.final and a.kind == "extraction" and stages_ok else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
