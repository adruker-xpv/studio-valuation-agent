# reconcile.py (build 13.0) - the last step, plain code, no judgment. It
#   1. re-runs verify on the extraction and on the reviewer's blind answer (it never trusts a status an agent reports),
#   2. compares them by file fingerprint and cell: workbook roles, the chain, the window, the fund cell, edge classes, discrepancies,
#   3. (--compare-only) writes compare.json: the contested items the reviewer must address in phase 2 - and stops there,
#   4. checks every reviewer finding's claim with verify's own tests and measures what the second pass ADDED:
#        different path        the reviewer's route through the evidence differs from the extractor's (direction and first anchor)
#        missed rivals         material rival readings the extraction neither used nor rejected
#        weak provenance       extractor edges shown (by verify) to be weaker than claimed
#        unsupported assumptions   material conclusions resting on an assumption the workbooks don't support (judgment)
#        evidence contradictions  material extractor conclusions contradicted by a claim that verify confirms
#      Agreement is reported, but agreement by itself is not proof and is never counted as added value.
#   5. writes reconcile.json, onboarding_review.xlsx and onboarding_review.md for the analyst.
# Status: READY FOR APPROVAL | NEEDS ANALYST (anything to decide - including a faithfully preserved discrepancy) | CHECKS FAILED
# Usage: python reconcile.py --run-dir R [--extraction F] [--blind F] [--review F] [--response F] [--workbooks ...]
#                            [--period-end YYYY-MM-DD] [--company "..."] [--out-dir out] [--compare-only]
import argparse, contextlib, io, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import verify as V  # noqa: E402
from xlsx_evidence import SourceSet, split_ref, quote_sheet  # noqa: E402
from onboarding_schema import SCHEMA_VERSION, CLASSES  # noqa: E402

VERSION = SCHEMA_VERSION
WEAK = {"contextual_support", "inferred_candidate", "unresolved"}
CORE = [("valuation_metric", "Earnings figure (TTM)"), ("selected_multiple", "Applied multiple"), ("enterprise_value", "Enterprise value"),
        ("equity_value", "Total equity value"), ("value_to_xpv", "XPV's value (as reported to the fund)")]


def run_verify(args):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        V.main(args)
    return buf.getvalue().strip().splitlines()


def nc(c):
    return str(c or "").replace("$", "").replace("'", "").strip().lower()


class Keys:
    """refs -> fingerprint-based keys, so two agents' ids never need to agree."""

    def __init__(self, doc):
        self.sha = {s["id"]: s.get("sha256") for s in doc.get("sources") or []}
        for x in doc.get("external") or []:
            self.sha[x["id"]] = "ext:" + str(x.get("file", "")).lower()
        self.role = {self.sha.get(s["id"]): s.get("role") for s in doc.get("sources") or []}

    def k(self, source, cell):
        return f"{str(self.sha.get(source, source))[:16]}|{nc(cell)}"

    def ref(self, r):
        if isinstance(r, list):
            return "+".join(sorted(self.ref(x) for x in r))
        return self.k((r or {}).get("source"), (r or {}).get("cell")) if isinstance(r, dict) else ""


def chain_items(doc, K):
    """{label: (comparison key, display text)}"""
    ch = doc.get("chain") or {}
    out = {}
    ref = lambda s, c: (K.k(s, c), f"{s}:{c}") if c else (None, None)
    for r, lab in CORE:
        out[lab] = ref(ch.get("source"), (ch.get(r) or {}).get("cell"))
    mw = ch.get("metric_window") or {}
    out["TTM window (cells)"] = ref(mw.get("source"), mw.get("cells")) if mw.get("cells") else (mw.get("link"), mw.get("link"))
    m = f"{mw.get('first')}..{mw.get('last')}" if mw.get("first") else None
    out["TTM window (months)"] = (m, m)
    out["Valuation method"] = (ch.get("method"), ch.get("method"))
    fc = ch.get("fund_cell") or {}
    out["Fund-reported cell"] = ref(fc.get("source"), fc.get("cell"))
    return out


def show(doc, ref_key):
    """a fingerprint key back to the document's own source id for display."""
    if not ref_key or "|" not in str(ref_key):
        return ref_key
    sha, cell = ref_key.split("|", 1)
    for s in doc.get("sources") or []:
        if str(s.get("sha256", ""))[:16] == sha:
            return f"{s['id']}:{cell}"
    return ref_key


def mentioned(doc, K):
    out = set()

    def walk(o):
        if isinstance(o, dict):
            if o.get("source") and isinstance(o.get("cell"), str):
                out.add(K.k(o["source"], o["cell"]))
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    walk({k: doc.get(k) for k in ("provenance", "downstream", "discrepancies", "rejected", "inputs", "path")})
    ch = doc.get("chain") or {}
    for r in [ch.get(x) for x, _ in CORE] + list(ch.get("bridge") or []) + list(ch.get("waterfall") or []) + [ch.get("value_to_xpv_local")]:
        if isinstance(r, dict) and r.get("cell"):
            out.add(K.k(ch.get("source"), r["cell"]))
    return out


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", default=".")
    ap.add_argument("--extraction")
    ap.add_argument("--blind")
    ap.add_argument("--review")
    ap.add_argument("--response")
    ap.add_argument("--workbooks", nargs="*")
    ap.add_argument("--period-end")
    ap.add_argument("--company")
    ap.add_argument("--out-dir", default="out")
    ap.add_argument("--compare-only", action="store_true")
    a = ap.parse_args(argv)
    rd = a.run_dir
    for k in ("extraction", "blind", "review", "response"):      # relative paths: the working folder, else the run dir
        p = getattr(a, k)
        if p and not os.path.isabs(p) and not os.path.exists(p) and os.path.exists(os.path.join(rd, p)):
            setattr(a, k, os.path.join(rd, p))
    out_dir = a.out_dir if os.path.isabs(a.out_dir) else os.path.join(rd, a.out_dir)
    os.makedirs(out_dir, exist_ok=True)
    px = a.extraction or os.path.join(rd, "extraction.json")
    pb = a.blind or next((p for p in (os.path.join(rd, "reviewer_blind.json"), os.path.join(rd, "reviewer", "reviewer_blind.json")) if os.path.exists(p)), None)
    X, B = json.load(open(px)), json.load(open(pb))
    RV = json.load(open(a.review or os.path.join(rd, "review.json"))) if not a.compare_only else {}
    RS = json.load(open(a.response)) if a.response else {}
    common = ["--run-dir", rd] + (["--workbooks", *a.workbooks] if a.workbooks else []) + \
             (["--period-end", a.period_end] if a.period_end else []) + (["--company", a.company] if a.company else [])
    vx_lines = run_verify(common + ["--file", px, "--out", os.path.join(out_dir, "verification.json"), "--kind", "extraction"])
    vb_lines = run_verify(common + ["--file", pb, "--out", os.path.join(out_dir, "verification_blind.json"), "--kind", "blind"])
    VX = json.load(open(os.path.join(out_dir, "verification.json")))
    VB = json.load(open(os.path.join(out_dir, "verification_blind.json")))
    KX, KB = Keys(X), Keys(B)

    # --- compare ---
    cx, cb = chain_items(X, KX), chain_items(B, KB)
    rows = [{"item": k, "extractor": cx[k][1], "reviewer_blind": (cb.get(k) or (None, None))[1],
             "agree": cx[k][0] is not None and str(cx[k][0]) == str((cb.get(k) or (None,))[0])} for k in cx]
    role_rows = []
    for s in X.get("sources") or []:
        rb = KB.role.get(s.get("sha256"))
        role_rows.append({"source": s["id"], "file": s.get("file"), "extractor": s.get("role"), "reviewer_blind": rb, "agree": rb == s.get("role")})
    bx = {KB.ref(e.get("to")): e for e in (B.get("provenance") or []) + (B.get("downstream") or [])}
    vst = {e["id"]: e for e in VX.get("edges") or []}
    vbs = {e["id"]: e for e in VB.get("edges") or []}
    edge_rows = []
    for e in (X.get("provenance") or []) + (X.get("downstream") or []):
        b = bx.get(KX.ref(e.get("to")))
        to = e.get("to") or {}
        edge_rows.append({"id": e.get("id"), "to": f"{to.get('source')}:{to.get('cell')}", "extractor_class": e.get("class"),
                          "verify": (vst.get(e.get("id")) or {}).get("status"), "reviewer_class": b.get("class") if b else None,
                          "reviewer_verify": (vbs.get(b.get("id")) or {}).get("status") if b else None,
                          "agree": bool(b) and b.get("class") == e.get("class"), "material": e.get("material", True), "what": e.get("what")})
    x_to = {KX.ref(e.get("to")) for e in (X.get("provenance") or []) + (X.get("downstream") or [])}
    blind_only = [e for k, e in bx.items() if k not in x_to]
    xd = {frozenset((KX.ref(d.get("a")), KX.ref(d.get("b")))): d for d in X.get("discrepancies") or []}
    bd = {frozenset((KB.ref(d.get("a")), KB.ref(d.get("b")))): d for d in B.get("discrepancies") or []}
    contested = []
    for r in rows:
        if not r["agree"]:
            contested.append({"kind": "core", "item": r["item"], "extractor": r["extractor"], "reviewer_blind": r["reviewer_blind"]})
    for r in role_rows:
        if not r["agree"]:
            contested.append({"kind": "workbook role", "item": f"sources.{r['source']}", "extractor": r["extractor"], "reviewer_blind": r["reviewer_blind"]})
    for r in edge_rows:
        if r["reviewer_class"] and not r["agree"]:
            contested.append({"kind": "edge class", "item": r["id"], "extractor": r["extractor_class"], "reviewer_blind": r["reviewer_class"]})
        if r["material"] and r["extractor_class"] in WEAK:
            contested.append({"kind": "weak edge", "item": r["id"], "extractor": r["extractor_class"], "note": r["what"]})
        if r["verify"] == "contradicted":
            contested.append({"kind": "verify contradicted", "item": r["id"], "note": vst[r["id"]]["note"]})
    for e in blind_only:
        contested.append({"kind": "edge only the reviewer found", "item": e.get("id"), "reviewer_blind": f"{e.get('class')}: {e.get('what')}"})
    for k, d in bd.items():
        if k not in xd:
            contested.append({"kind": "discrepancy only the reviewer found", "item": d.get("id"), "note": d.get("what")})
    for k, d in xd.items():
        contested.append({"kind": "extractor discrepancy" + (" (reviewer found it too)" if k in bd else ""), "item": d.get("id"), "note": d.get("what")})
    for c in B.get("challenges") or []:
        contested.append({"kind": "blind challenge", "item": c.get("id"), "note": f"{c.get('kind')}: {c.get('note')}"})
    cmp_out = {"reconcile_version": VERSION, "extraction_verify": VX["status"], "blind_verify": VB["status"], "core": rows, "roles": role_rows,
               "edges": edge_rows, "contested": contested,
               "note": "Phase 2: address every contested item with a finding (type, evidence cells, and a checkable claim where one exists)."}
    json.dump(cmp_out, open(os.path.join(out_dir, "compare.json"), "w"), indent=1, default=str)
    agreed = sum(r["agree"] for r in rows)
    if a.compare_only:
        print(f"COMPARE: core agreed {agreed}/{len(rows)} | workbook roles agreed {sum(r['agree'] for r in role_rows)}/{len(role_rows)} | "
              f"edges compared {sum(1 for r in edge_rows if r['reviewer_class'])} | contested items {len(contested)} | extraction verify "
              f"{VX['status']} | blind verify {VB['status']} | file: {os.path.relpath(os.path.join(out_dir, 'compare.json'), rd)}")
        return 0

    # --- findings: check every claim with verify's own tests ---
    srcs = SourceSet(rd)
    if a.workbooks:
        srcs.open_paths(a.workbooks)
    srcs.ensure_all()
    W = V.World(srcs)
    known = mentioned(X, KX)
    frows = []
    for f in RV.get("findings") or []:
        cl, backed, note = f.get("claim"), None, ""
        if isinstance(cl, dict) and "class" in cl:
            s, n = V.check_edge(W, cl)
            backed = {"confirmed": True, "contradicted": False}.get(s)
            note = f"claim {s}: {n}"
        elif isinstance(cl, dict) and cl.get("chain_role"):
            try:
                k = W.expand({"source": cl.get("source"), "cell": cl.get("cell")})[0]
                c = W.cell(*k)
                ok = bool(c) and V.num(c[0]) is not None and not (c[4] and str(c[4][0]).startswith("dataTable"))
                backed, note = (True if ok else False), ("claimed cell holds a live number" if ok else "claimed cell is empty, not a number, or a data-table cell")
            except ValueError as x:
                backed, note = False, str(x)
        tgt = f.get("target")
        if f.get("type") == "weak_provenance" and tgt in vst and vst[tgt]["status"] == "contradicted":
            backed, note = True, (note + "; " if note else "") + f"verify also contradicts {tgt}: {vst[tgt]['note']}"
        novel = None
        if f.get("type") == "missed_rival":
            ev = f.get("evidence") if isinstance(f.get("evidence"), list) else [f.get("evidence")]
            novel = not any(KB.ref(e) in known or KX.ref(e) in known for e in ev if isinstance(e, dict))
            if not novel:
                note = (note + "; " if note else "") + "already in the extraction (used or rejected): not a missed rival"
        frows.append({"id": f.get("id"), "type": f.get("type"), "target": tgt, "material": f.get("material", True), "note_from_reviewer": f.get("note"),
                      "evidence_backed": backed, "check": note, "novel": novel})
    mat = lambda r: r["material"] is not False
    m_rivals = [r for r in frows if r["type"] == "missed_rival" and r["novel"] and mat(r) and r["evidence_backed"] is not False]
    m_weak = [r for r in frows if r["type"] == "weak_provenance" and r["evidence_backed"] and mat(r)]
    m_assump = [r for r in frows if r["type"] == "unsupported_assumption" and mat(r)]
    m_contra = [r for r in frows if r["type"] == "contradiction" and r["evidence_backed"] and mat(r)]
    rev_errors = [r for r in frows if r["evidence_backed"] is False] + [e for e in VB.get("edges") or [] if e["status"] == "contradicted"]
    dx, db = X.get("direction"), B.get("direction")
    a0x = ((X.get("path") or [{}])[0] or {})
    a0b = ((B.get("path") or [{}])[0] or {})
    rx, rb_ = KX.role.get(KX.sha.get(a0x.get("source"))), KB.role.get(KB.sha.get(a0b.get("source")))
    path_differs = bool(dx and db and dx != db and rx != rb_)
    if m_rivals or m_weak or m_contra:
        value = "ADDED VALUE"
    elif m_assump:
        value = "ADDED VALUE (judgment only: unsupported assumptions raised, not provable by code)"
    elif path_differs:
        value = "CORROBORATION (different path)"
    else:
        value = "NO INDEPENDENT VALUE SHOWN"
    metrics = {"different_path": path_differs, "extractor_path": f"{dx} from {rx}", "reviewer_path": f"{db} from {rb_}",
               "core_agreed": f"{agreed}/{len(rows)}", "missed_material_rivals": len(m_rivals), "weak_provenance_challenged": len(m_weak),
               "unsupported_assumptions": len(m_assump), "evidence_backed_contradictions": len(m_contra),
               "reviewer_claims_contradicted": len(rev_errors), "findings": len(frows), "value": value,
               "note": "Agreement is not proof: it counts as corroboration only when the reviewer reached it by a different path."}

    # --- questions for the analyst ---
    q = []
    for r in rows:
        if not r["agree"]:
            q.append(("extractor vs reviewer", f"{r['item']}: the extractor says {r['extractor']}, the reviewer (working blind, by another path) "
                                               f"says {r['reviewer_blind']}. Which is right?"))
    for r in role_rows:
        if not r["agree"]:
            q.append(("extractor vs reviewer", f"{r['file']}: the extractor's role is {r['extractor']}, the reviewer's is {r['reviewer_blind']}."))
    for e in VX.get("edges") or []:
        if e["status"] == "contradicted":
            q.append(("verify", f"Edge {e['id']} ({e['class']}) is contradicted by the workbook: {e['note']}"))
    for k, s in VX["checks"].items():
        if s == "fail" and k not in ("edges",):
            d = VX["detail"].get(k)
            q.append(("verify", f"Check '{k}' failed: {json.dumps(d, default=str)[:300]}"))
    for d, vd in zip(X.get("discrepancies") or [], VX.get("discrepancies") or []):
        if d.get("status") == "unresolved":
            q.append(("discrepancy", f"{d.get('id')}: {d.get('what')} Driver: {d.get('driver', 'not established')}. Decide which value stands "
                                     f"(verify: {vd['status']}, {vd['note']})."))
    for r in frows:
        if r["type"] != "confirmed":
            tag = {True: "evidence confirmed by verify", False: "the reviewer's own claim did NOT verify", None: "judgment"}[r["evidence_backed"]]
            q.append(("reviewer", f"{r['id']} ({r['type'].replace('_', ' ')}, on {r['target']}; {tag}): {r['note_from_reviewer']}"))
    for src, items in (("extractor", X.get("open_questions")), ("reviewer", (B.get("questions") or []) + (RV.get("questions") or []))):
        for t in items or []:
            q.append((src, t))
    for r_ in RS.get("responses") or []:
        ck = ""
        if isinstance(r_.get("claim"), dict) and "class" in r_["claim"]:
            s_, n_ = V.check_edge(W, r_["claim"])
            ck = f" (its claim, checked by verify: {s_} - {n_})"
        q.append(("extractor's response", f"On {r_.get('item')}, the extractor {'accepts the correction' if r_.get('position') == 'concede' else 'stands by its reading'}: "
                                          f"{r_.get('evidence', '')}{ck}"))
    # integrity across agents
    shas = lambda d: {s.get("sha256") for s in d.get("sources") or []}
    mism = []
    if shas(B) != shas(X):
        mism.append("the reviewer (blind) read a different set of files from the extractor")
    if RV.get("workbook_sha256s") and set(RV["workbook_sha256s"]) != shas(X):
        mism.append("the reviewer (phase 2) read a different set of files")
    for m in mism:
        q.insert(0, ("integrity", m.capitalize() + " (SHA-256). Rerun the onboarding."))
    open_disc = [d for d in X.get("discrepancies") or [] if d.get("status") == "unresolved"]
    if VX["status"] == "REVIEW" or mism:
        status = "CHECKS FAILED"
    elif (VX["status"] == "VERIFIED" and agreed == len(rows) and all(r["agree"] for r in role_rows)
          and not [r for r in frows if r["type"] != "confirmed"] and not open_disc and not X.get("open_questions")):
        status = "READY FOR APPROVAL"
    else:
        status = "NEEDS ANALYST"
    out = {"reconcile_version": VERSION, "status": status, "extraction_verify": VX["status"], "blind_verify": VB["status"],
           "core": rows, "roles": role_rows, "edges": edge_rows, "findings": frows, "reviewer_value": metrics,
           "discrepancies": [dict(d, verify=vd) for d, vd in zip(X.get("discrepancies") or [], VX.get("discrepancies") or [])],
           "questions": [{"from": s_, "question": t} for s_, t in q], "extractor": X.get("produced_by"), "reviewer_blind": B.get("produced_by"),
           "reviewer": RV.get("produced_by"), "workbooks": VX.get("workbooks")}
    json.dump(out, open(os.path.join(out_dir, "reconcile.json"), "w"), indent=1, default=str)
    write_xlsx(out, X, RV, os.path.join(out_dir, "onboarding_review.xlsx"))
    write_md(out, X, RV, os.path.join(out_dir, "onboarding_review.md"))
    for ln in vx_lines:
        if ln.startswith("VERIFY: status"):
            print(ln.replace("VERIFY: status", "VERIFY (extraction): status"))
    print(f"REVIEWER VALUE: {value} | different path {'yes' if path_differs else 'no'} | missed rivals {len(m_rivals)} | weak provenance "
          f"{len(m_weak)} | unsupported assumptions {len(m_assump)} | evidence-backed contradictions {len(m_contra)} | reviewer claims "
          f"contradicted {len(rev_errors)}")
    print(f"ONBOARDING: {status} | key answers agreed {agreed}/{len(rows)} | extraction verify {VX['status']} | blind verify {VB['status']} | "
          f"reviewer findings {sum(1 for r in frows if r['type'] != 'confirmed')} | discrepancies {len(open_disc)} | questions {len(q)}")
    print(f"ONBOARDING: files | {os.path.relpath(out_dir, rd)}/onboarding_review.xlsx, onboarding_review.md, reconcile.json, compare.json, verification.json")
    return 0


def write_xlsx(out, X, RV, path):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    wb = Workbook()
    bold, head, base = Font(name="Arial", bold=True), PatternFill("solid", fgColor="DDEBF7"), Font(name="Arial")

    def put(c, x):
        c.value = "" if x is None else (x if isinstance(x, (int, float, str)) else json.dumps(x, default=str))
        if isinstance(c.value, str) and c.value.startswith("="):
            c.data_type = "s"
        c.font, c.alignment = base, Alignment(wrap_text=True, vertical="top")

    def sheet(title, header, data, widths):
        ws = wb.create_sheet(title)
        ws.append(header)
        for c in ws[1]:
            c.font, c.fill = bold, head
        for i, r in enumerate(data, 2):
            for j, x in enumerate(r, 1):
                put(ws.cell(i, j), x)
        for i, w in enumerate(widths):
            ws.column_dimensions[chr(65 + i)].width = w
        ws.freeze_panes = "A2"
    s = wb.active
    s.title = "Summary"
    m = out["reviewer_value"]
    rows = [("Onboarding review", ""), ("Company", X.get("company")), ("Quarter end", X.get("quarter_end")), ("Status", out["status"]),
            ("Extraction verify", out["extraction_verify"]), ("Reviewer's blind answer verify", out["blind_verify"]),
            ("Key answers agreed", m["core_agreed"]), ("What the second reader added", m["value"]),
            ("Open discrepancies (decisions, not errors)", sum(1 for d in out["discrepancies"] if d.get("status") == "unresolved")),
            ("Questions for the analyst", len(out["questions"])), ("", ""), ("How this valuation works (extractor)", X.get("how_it_works", "")),
            ("Reviewer's overall view", RV.get("overall", "")), ("", ""),
            ("Extractor", out.get("extractor")), ("Reviewer", out.get("reviewer")), ("Produced by", f"reconcile {VERSION}")]
    for i, (k, v) in enumerate(rows, 1):
        put(s.cell(i, 1), k)
        put(s.cell(i, 2), v)
        s.cell(i, 1).font = bold
    s["A1"].font = Font(name="Arial", bold=True, size=14)
    s.column_dimensions["A"].width, s.column_dimensions["B"].width = 44, 110
    sheet("Sources", ["Id", "File", "Extractor's role", "Reviewer's role", "Agree"],
          [[r["source"], r["file"], r["extractor"], r["reviewer_blind"], "yes" if r["agree"] else "NO"] for r in out["roles"]], (6, 60, 22, 22, 8))
    sheet("Valuation chain", ["Item", "Extractor", "Reviewer (blind)", "Agree"],
          [[r["item"], r["extractor"], r["reviewer_blind"], "yes" if r["agree"] else "NO"] for r in out["core"]], (30, 50, 50, 8))
    sheet("Provenance", ["Edge", "Target", "What", "Extractor's class", "Verify", "Reviewer's class", "Agree"],
          [[r["id"], r["to"], r["what"], r["extractor_class"], r["verify"], r["reviewer_class"] or "-", "yes" if r["agree"] else ("-" if not r["reviewer_class"] else "NO")]
           for r in out["edges"]], (8, 40, 50, 24, 14, 24, 8))
    sheet("Discrepancies", ["Id", "What", "Driver", "Status", "Verify"],
          [[d.get("id"), d.get("what"), d.get("driver"), d.get("status"), f"{d['verify']['status']}: {d['verify']['note']}"] for d in out["discrepancies"]],
          (6, 60, 60, 12, 50))
    sheet("Reviewer value", ["Measure", "Result"], [[k.replace("_", " "), v] for k, v in m.items()], (36, 90))
    sheet("Reviewer findings", ["Id", "Type", "Target", "Reviewer's note", "Evidence checked by verify", "Check"],
          [[r["id"], r["type"], r["target"], r["note_from_reviewer"], {True: "confirmed", False: "NOT confirmed", None: "judgment"}[r["evidence_backed"]], r["check"]]
           for r in out["findings"]], (6, 22, 16, 70, 18, 60))
    sheet("Questions", ["#", "From", "Question"], [[i + 1, x["from"], x["question"]] for i, x in enumerate(out["questions"])], (5, 22, 140))
    sheet("Legend", ["Term", "Meaning"], [[k.replace("_", " "), v] for k, v in CLASSES.items()] +
          [["TTM", "trailing twelve months"], ["EV", "enterprise value"], ["verify", "deterministic check of each claim against the workbooks' own formulas and values"],
           ["blind", "the reviewer's answer written before it saw the extraction, reached by a different path"],
           ["discrepancy", "two values that should agree but do not; preserving one faithfully is a correct result, and the analyst decides"]], (28, 110))
    wb.save(path)


def write_md(out, X, RV, path):
    m = out["reviewer_value"]
    md = [f"# Onboarding review - {X.get('company')}, quarter end {X.get('quarter_end')}", "",
          f"**Status: {out['status']}** | extraction verify {out['extraction_verify']} | key answers agreed {m['core_agreed']} | "
          f"second reader: {m['value']} | questions {len(out['questions'])}", "", "## How this valuation works", X.get("how_it_works") or "", "",
          "## Discrepancies (decisions for the analyst, not errors)"]
    md += [f"- {d.get('id')}: {d.get('what')} Driver: {d.get('driver', '-')}. Verify: {d['verify']['status']}." for d in out["discrepancies"]] or ["None."]
    md += ["", "## Key answers", "| Item | Extractor | Reviewer (blind) | Agree |", "|---|---|---|---|"]
    md += [f"| {r['item']} | {r['extractor']} | {r['reviewer_blind']} | {'yes' if r['agree'] else 'NO'} |" for r in out["core"]]
    md += ["", "## What the second reader added", f"{m['value']}. Different path: {'yes' if m['different_path'] else 'no'} "
           f"({m['extractor_path']} vs {m['reviewer_path']}); missed rivals {m['missed_material_rivals']}; weak provenance challenged "
           f"{m['weak_provenance_challenged']}; unsupported assumptions {m['unsupported_assumptions']}; evidence-backed contradictions "
           f"{m['evidence_backed_contradictions']}; reviewer claims that did not verify {m['reviewer_claims_contradicted']}. {m['note']}",
           "", "## Questions for the analyst"]
    md += [f"{i + 1}. ({x['from']}) {x['question']}" for i, x in enumerate(out["questions"])] or ["None."]
    md += ["", "Legend: " + "; ".join(f"{k.replace('_', ' ')} = {v}" for k, v in CLASSES.items()) + ". TTM = trailing twelve months; EV = enterprise value."]
    open(path, "w").write("\n".join(md) + "\n")


if __name__ == "__main__":
    sys.exit(main())
