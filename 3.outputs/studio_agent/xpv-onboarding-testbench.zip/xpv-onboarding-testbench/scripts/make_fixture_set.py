# make_fixture_set.py (build 13.0, test bench) - writes the synthetic five-workbook trial set "T1" (made-up company "Tidewater
# Analytics") that reproduces, with invented numbers, the structural features that broke or stretched the Test2 run:
#   - an INFLATED used range (formatting out to XFD1048576 and ~270,000 formatted empty cells) on the monthly add-backs sheet
#   - hidden and very-hidden sheets, hidden rows, a #REF! stale tab, current and prior quarters side by side
#   - shared formulas, an array formula and a data-table (sensitivity) formula
#   - formula links between workbooks: one to a supplied file, one to a version that was NOT supplied (a "v3" file name)
#   - pasted (typed) copies, figures rounded to $000s, a workbook that only corroborates (contributes nothing)
#   - a fund-reported value that differs from the company workbook's value because the fund applied another multiple
# The files are written as raw Office Open XML with Excel's saved values, so formulas AND values are present, exactly like a
# workbook Excel saved. Output is byte-for-byte deterministic (fixed zip timestamps), so SHA-256s are stable for the reference.
# Usage: python make_fixture_set.py --out trial/set-T1      (prints the facts the reference extraction relies on)
import argparse, datetime, json, os, zipfile
from xml.sax.saxutils import escape

MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG = "http://schemas.openxmlformats.org/package/2006/relationships"


def col(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def cn(s):
    n = 0
    for ch in s:
        n = n * 26 + ord(ch) - 64
    return n


def split(a):
    i = next(i for i, ch in enumerate(a) if ch.isdigit())
    return int(a[i:]), cn(a[:i])


def serial(d):
    return (d - datetime.date(1899, 12, 30)).days


def month_ends(y, m, n):
    out = []
    for _ in range(n):
        nxt = datetime.date(y + (m == 12), m % 12 + 1, 1)
        out.append(nxt - datetime.timedelta(days=1))
        y, m = nxt.year, nxt.month
    return out


# styles: 0 General, 1 date mmm-yy, 2 #,##0, 3 0.0x, 4 0.00%, 5 formatted-empty (fill), 6 date d-mmm-yyyy
STYLES = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="{MAIN}"><numFmts count="3"><numFmt numFmtId="164" formatCode="mmm\\-yy"/><numFmt numFmtId="165" formatCode="0.0&quot;x&quot;"/><numFmt numFmtId="166" formatCode="d\\-mmm\\-yyyy"/></numFmts>
<fonts count="1"><font><sz val="10"/><name val="Arial"/></font></fonts>
<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="7"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="10" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="0" fillId="2" borderId="0" xfId="0" applyFill="1"/>
<xf numFmtId="166" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>"""


class Sheet:
    def __init__(self, name, state="visible"):
        self.name, self.state = name, state
        self.cells = {}
        self.hidden_rows, self.hidden_cols, self.merged = set(), [], []
        self.declared = None
        self.empty_blocks = []

    def put(self, a, v=None, f=None, s=None, **fx):
        r, c = split(a)
        if s is None:
            s = 1 if isinstance(v, datetime.date) else 2 if isinstance(v, (int, float)) and not isinstance(v, bool) and abs(v) >= 1000 else 0
        self.cells[(r, c)] = {"v": v, "f": f, "s": s, **fx}

    def row(self, r, c0, vals, s=None, f=None, shared=None):
        """typed values (or shared formula values) along a row starting at column c0."""
        for i, v in enumerate(vals):
            a = f"{col(c0 + i)}{r}"
            if shared is not None:
                if i == 0:
                    self.put(a, v, shared, s, t="shared", ref=f"{a}:{col(c0 + len(vals) - 1)}{r}", si=f.si(self))
                else:
                    self.put(a, v, None, s, t="shared", si=self.cells[(r, c0)]["si"], child=True)
            else:
                self.put(a, v, None, s)


class SI:
    def __init__(self):
        self.n = {}

    def si(self, sh):
        self.n[sh.name] = self.n.get(sh.name, -1) + 1
        return str(self.n[sh.name])


class Book:
    def __init__(self):
        self.sheets, self.ext, self.names = [], [], []
        self.sst, self.sidx = [], {}

    def sheet(self, name, state="visible"):
        s = Sheet(name, state)
        self.sheets.append(s)
        return s

    def link(self, target, sheets, cache):
        """an external workbook link; returns its formula index [n]. cache: {(sheet, addr): value}"""
        self.ext.append((target, sheets, cache))
        return len(self.ext)

    def s(self, text):
        if text not in self.sidx:
            self.sidx[text] = len(self.sst)
            self.sst.append(text)
        return self.sidx[text]

    def cell_xml(self, a, d):
        attrs = f' r="{a}"' + (f' s="{d["s"]}"' if d["s"] else "")
        v, f = d["v"], d["f"]
        fx = ""
        t = d.get("t")
        if t == "shared":
            fx = f'<f t="shared" ref="{d["ref"]}" si="{d["si"]}">{escape(f)}</f>' if not d.get("child") else f'<f t="shared" si="{d["si"]}"/>'
        elif t == "array":
            fx = f'<f t="array" ref="{d["ref"]}">{escape(f)}</f>'
        elif t == "dataTable":
            fx = f'<f t="dataTable" ref="{d["ref"]}" dt2D="0" dtr="0" r1="{d["r1"]}"/>'
        elif f is not None:
            fx = f"<f>{escape(f)}</f>"
        if isinstance(v, bool):
            return f'<c{attrs} t="b">{fx}<v>{int(v)}</v></c>'
        if isinstance(v, str) and v.startswith("#") and f is not None:
            return f'<c{attrs} t="e">{fx}<v>{escape(v)}</v></c>'
        if isinstance(v, str):
            if fx:
                return f'<c{attrs} t="str">{fx}<v>{escape(v)}</v></c>'
            return f'<c{attrs} t="s"><v>{self.s(v)}</v></c>'
        if isinstance(v, datetime.date):
            return f"<c{attrs}>{fx}<v>{serial(v)}</v></c>"
        if v is None:
            return f"<c{attrs}>{fx}</c>"
        return f"<c{attrs}>{fx}<v>{repr(float(v)) if isinstance(v, float) and not float(v).is_integer() else int(v)}</v></c>"

    def sheet_xml(self, sh):
        rows = {}
        for (r, c), d in sh.cells.items():
            rows.setdefault(r, []).append((c, d))
        for (r1, c1, r2, c2) in sh.empty_blocks:
            for r in range(r1, r2 + 1):
                for c in range(c1, c2 + 1):
                    if (r, c) not in sh.cells:
                        rows.setdefault(r, []).append((c, None))
        rmax = max(rows) if rows else 1
        cmax = max((c for r in rows.values() for c, _ in r), default=1)
        dim = sh.declared or f"A1:{col(cmax)}{rmax}"
        out = [f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="{MAIN}" xmlns:r="{REL}"><dimension ref="{dim}"/>']
        if sh.hidden_cols:
            out.append("<cols>" + "".join(f'<col min="{a}" max="{b}" width="9" hidden="1" customWidth="1"/>' for a, b in sh.hidden_cols) + "</cols>")
        out.append("<sheetData>")
        for r in sorted(rows):
            out.append(f'<row r="{r}"' + (' hidden="1"' if r in sh.hidden_rows else "") + ">")
            for c, d in sorted(rows[r], key=lambda x: x[0]):
                out.append(f'<c r="{col(c)}{r}" s="5"/>' if d is None else self.cell_xml(f"{col(c)}{r}", d))
            out.append("</row>")
        out.append("</sheetData>")
        if sh.merged:
            out.append(f'<mergeCells count="{len(sh.merged)}">' + "".join(f'<mergeCell ref="{m}"/>' for m in sh.merged) + "</mergeCells>")
        out.append("</worksheet>")
        return "".join(out)

    def save(self, path):
        parts = {}
        ct = [f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
              '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
              '<Default Extension="xml" ContentType="application/xml"/>',
              '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
              '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
              '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>']
        wrels = [f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="{PKG}">']
        sheets_xml = []
        for i, sh in enumerate(self.sheets, 1):
            parts[f"xl/worksheets/sheet{i}.xml"] = self.sheet_xml(sh)
            ct.append(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>')
            wrels.append(f'<Relationship Id="rId{i}" Type="{REL}/worksheet" Target="worksheets/sheet{i}.xml"/>')
            st = f' state="{sh.state}"' if sh.state != "visible" else ""
            sheets_xml.append(f'<sheet name="{escape(sh.name, {chr(34): "&quot;"})}" sheetId="{i}"{st} r:id="rId{i}"/>')
        n = len(self.sheets)
        wrels.append(f'<Relationship Id="rId{n + 1}" Type="{REL}/styles" Target="styles.xml"/>')
        wrels.append(f'<Relationship Id="rId{n + 2}" Type="{REL}/sharedStrings" Target="sharedStrings.xml"/>')
        ext_xml = []
        for j, (target, sheets, cache) in enumerate(self.ext, 1):
            rid = f"rId{n + 2 + j}"
            wrels.append(f'<Relationship Id="{rid}" Type="{REL}/externalLink" Target="externalLinks/externalLink{j}.xml"/>')
            ct.append(f'<Override PartName="/xl/externalLinks/externalLink{j}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.externalLink+xml"/>')
            ext_xml.append(f'<externalReference r:id="{rid}"/>')
            sd = []
            for k, shn in enumerate(sheets):
                cells = sorted(((split(a), a, v) for (s_, a), v in cache.items() if s_ == shn))
                rows = {}
                for (r, c), a, v in cells:
                    rows.setdefault(r, []).append((a, v))
                sd.append(f'<sheetData sheetId="{k}">' + "".join(f'<row r="{r}">' + "".join(
                    f'<cell r="{a}"><v>{v}</v></cell>' for a, v in rows[r]) + "</row>" for r in sorted(rows)) + "</sheetData>")
            parts[f"xl/externalLinks/externalLink{j}.xml"] = (
                f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<externalLink xmlns="{MAIN}"><externalBook xmlns:r="{REL}" r:id="rId1">'
                f'<sheetNames>' + "".join(f'<sheetName val="{escape(s_)}"/>' for s_ in sheets) + f'</sheetNames><sheetDataSet>{"".join(sd)}</sheetDataSet>'
                f'</externalBook></externalLink>')
            parts[f"xl/externalLinks/_rels/externalLink{j}.xml.rels"] = (
                f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="{PKG}"><Relationship Id="rId1" '
                f'Type="{REL}/externalLinkPath" Target="{escape(target)}" TargetMode="External"/></Relationships>')
        wrels.append("</Relationships>")
        dn = ""
        if self.names:
            dn = "<definedNames>" + "".join(f'<definedName name="{nm}">{escape(tx)}</definedName>' for nm, tx in self.names) + "</definedNames>"
        parts["xl/workbook.xml"] = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook xmlns="{MAIN}" xmlns:r="{REL}">'
                                    f'<workbookPr/><bookViews><workbookView/></bookViews><sheets>{"".join(sheets_xml)}</sheets>'
                                    + (f'<externalReferences>{"".join(ext_xml)}</externalReferences>' if ext_xml else "") + dn +
                                    '<calcPr calcId="191029"/></workbook>')
        parts["xl/_rels/workbook.xml.rels"] = "".join(wrels)
        parts["xl/styles.xml"] = STYLES
        for sh in self.sheets:                      # strings are collected while sheets are written above
            pass
        parts["xl/sharedStrings.xml"] = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<sst xmlns="{MAIN}" count="{len(self.sst)}" '
                                         f'uniqueCount="{len(self.sst)}">' + "".join(f'<si><t xml:space="preserve">{escape(t)}</t></si>' for t in self.sst) + "</sst>")
        ct.append("</Types>")
        parts["[Content_Types].xml"] = "".join(ct)
        parts["_rels/.rels"] = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="{PKG}"><Relationship Id="rId1" '
                                f'Type="{REL}/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        order = ["[Content_Types].xml", "_rels/.rels", "xl/workbook.xml", "xl/_rels/workbook.xml.rels", "xl/styles.xml", "xl/sharedStrings.xml"]
        order += sorted(k for k in parts if k not in order)
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            for k in order:
                zi = zipfile.ZipInfo(k, date_time=(2026, 7, 15, 9, 0, 0))
                zi.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(zi, parts[k].encode("utf-8"))


def build(out):
    os.makedirs(out, exist_ok=True)
    F = {"W1": "Tidewater - June 2026 Management Accounts.xlsx", "W2": "Tidewater - June 2026 TTM Pro Forma.xlsx",
         "W3": "Tidewater Monthly Summary - 2026.xlsx", "W4": "2026 Q2 - Tidewater Valuation (30 June 2026).xlsx",
         "W5": "Fund Q - Valuation Summary_Jun 30, 2026.xlsx"}
    V3 = "Tidewater - June 2026 TTM Pro Forma v3.xlsx"            # the version the valuation links to: NOT supplied
    months = month_ends(2025, 1, 18)                             # Jan-25 .. Jun-26
    rev = [2_000_000 + 25_000 * i for i in range(18)]
    cogs = [round(r * 0.45) for r in rev]
    opex = [560_000 + 4_000 * i for i in range(18)]
    gp = [r - c for r, c in zip(rev, cogs)]
    ebitda = [g - o for g, o in zip(gp, opex)]
    owner = [25_000] * 18
    legal = [0] * 18; legal[2] = 80_000; legal[10] = 120_000
    acq = [0] * 18; acq[12] = 150_000; acq[13] = 60_000
    adj_tot = [a + b + c for a, b, c in zip(owner, legal, acq)]
    adj_ebitda = [e + t for e, t in zip(ebitda, adj_tot)]
    rolling = {m: sum(adj_ebitda[m - 11:m + 1]) for m in range(11, 18)}       # TTM ending Dec-25 .. Jun-26
    facts = {}
    si = SI()

    # ---- W1 management accounts (company) ----
    b = Book()
    pl = b.sheet("P&L")
    pl.put("A1", "Tidewater Analytics - management accounts"); pl.put("B4", "Line item")
    for i, d in enumerate(months):
        pl.put(f"{col(3 + i)}4", d, s=1)
    pl.put("B5", "Revenue"); pl.row(5, 3, rev)
    pl.put("B6", "Cost of sales"); pl.row(6, 3, cogs)
    pl.put("B7", "Gross profit"); pl.row(7, 3, gp, f=si, shared="C5-C6")
    pl.put("B8", "Operating expenses"); pl.row(8, 3, opex)
    pl.put("B9", "Reported EBITDA"); pl.row(9, 3, ebitda, f=si, shared="C7-C8")
    ad = b.sheet("EBITDA Adjustments")
    ad.put("A1", "EBITDA adjustments (add-backs)"); ad.put("B3", "Adjustment")
    for i in range(18):
        a = f"{col(3 + i)}3"
        if i == 0:
            ad.put(a, months[0], "'P&L'!C4", 1, t="shared", ref="C3:T3", si=si.si(ad))
        else:
            ad.put(a, months[i], None, 1, t="shared", si="0", child=True)
    ad.put("B5", "Owner compensation normalisation"); ad.row(5, 3, owner)
    ad.put("B6", "One-time legal fees"); ad.row(6, 3, legal)
    ad.put("B7", "Acquisition costs"); ad.row(7, 3, acq)
    ad.put("B9", "Total adjustments"); ad.row(9, 3, adj_tot, f=si, shared="SUM(C5:C7)")
    ad.put("B11", "Adjusted EBITDA"); ad.row(11, 3, adj_ebitda, f=si, shared="'P&L'!C9+C9")
    ad.put("B13", "Superseded add-back (removed Feb-26)"); ad.row(13, 3, [5_000] * 18); ad.hidden_rows.add(13)
    ad.put("B102", "Rolling TTM adjusted EBITDA (excl. pro forma)")
    for m in range(11, 18):
        a = f"{col(3 + m)}102"
        if m == 11:
            ad.put(a, rolling[m], "SUM(C11:N11)", 2, t="shared", ref="N102:T102", si=si.si(ad))
        else:
            ad.put(a, rolling[m], None, 2, t="shared", si=ad.cells[(102, 14)]["si"], child=True)
    ad.empty_blocks += [(14, 1, 101, 30), (103, 1, 9000, 30)]                      # ~270,000 formatted empty cells
    ad.put("XFD1048576", None, s=5)                                                # one stray formatted cell at the very end
    ad.declared = "A1:XFD1048576"
    bs = b.sheet("Balance Sheet")
    bs.put("B4", "As at"); bs.put("C4", datetime.date(2026, 3, 31), s=6); bs.put("D4", datetime.date(2026, 6, 30), s=6)
    bs.put("B5", "Cash"); bs.put("C5", 2_650_000); bs.put("D5", 3_120_000)
    bs.put("B6", "Bank debt"); bs.put("C6", 18_400_000); bs.put("D6", 17_900_000)
    od = b.sheet("Old Draft", "veryHidden")
    od.put("B2", "Draft adjustments (superseded)"); od.put("C3", "#REF!", "#REF!+C2"); od.put("C2", 999_999)
    b.save(os.path.join(out, F["W1"]))

    # ---- W2 TTM pro forma (company) ----
    win = list(range(6, 18))                                                     # Jul-25 .. Jun-26
    pf = [40_000] * 6 + [0] * 6
    pf_adj = [ebitda[m] + adj_tot[m] + p for m, p in zip(win, pf)]
    ttm = sum(pf_adj)
    b = Book()
    L1 = b.link(F["W1"], ["P&L", "EBITDA Adjustments"], {("P&L", f"{col(3 + m)}9"): ebitda[m] for m in win})
    t = b.sheet("TTM")
    t.put("A1", "Tidewater - TTM pro forma adjusted EBITDA, June 2026"); t.put("B4", "Month")
    for i, m in enumerate(win):
        t.put(f"{col(3 + i)}4", months[m], s=1)
    t.put("O4", "TTM")
    t.put("B6", "Reported EBITDA (management accounts)")
    for i, m in enumerate(win):
        a = f"{col(3 + i)}6"
        if i == 0:
            t.put(a, ebitda[m], f"'[{L1}]P&L'!I9", 2, t="shared", ref="C6:N6", si=si.si(t))
        else:
            t.put(a, ebitda[m], None, 2, t="shared", si="0", child=True)
    t.put("B7", "Add-backs (pasted from adjustments schedule)"); t.row(7, 3, [adj_tot[m] for m in win])
    t.put("B8", "Pro forma: acquired business pre-acquisition EBITDA"); t.row(8, 3, pf)
    t.put("B10", "Pro forma adjusted EBITDA"); t.row(10, 3, pf_adj, f=si, shared="C6+C7+C8")
    t.put("O10", ttm, "SUM(C10:N10)", 2, t="array", ref="O10")
    nt = b.sheet("Notes")
    nt.put("A1", "Acquisition closed 1 Jan 2026; pre-acquisition months use seller-prepared financials (unaudited).")
    b.save(os.path.join(out, F["W2"]))

    # ---- W3 XPV monthly summary (corroboration only, $000s, typed) ----
    b = Book()
    s3 = b.sheet("Summary")
    s3.put("A1", "Tidewater Analytics - XPV monthly summary (CAD 000s)"); s3.put("B3", "Month")
    h1 = list(range(12, 18))
    for i, m in enumerate(h1):
        s3.put(f"{col(3 + i)}3", months[m], s=1)
    s3.put("B4", "Revenue"); s3.row(4, 3, [round(rev[m] / 1000) for m in h1])
    s3.put("B5", "Reported EBITDA"); s3.row(5, 3, [round(ebitda[m] / 1000) for m in h1])
    s3.put("B6", "Adjusted EBITDA"); s3.row(6, 3, [round(adj_ebitda[m] / 1000) for m in h1])
    cm = b.sheet("Commentary")
    cm.put("A1", "Integration costs in Jan-Feb 2026; trading in line with budget.")
    b.save(os.path.join(out, F["W3"]))

    # ---- W4 company valuation ----
    mult, mult_prior = 9.5, 9.0
    prior_ttm = 6_905_000
    ev = ttm * mult
    cash, debt = 3_120_000, 17_900_000
    eq = ev + cash - debt
    pref, own, fx = 30_000_000, 0.62, 0.73
    asconv = eq * own
    xpv_local = max(pref, asconv)
    xpv_usd = xpv_local * fx
    b = Book()
    LV3 = b.link(V3, ["TTM"], {("TTM", "O10"): ttm})
    LW1 = b.link(F["W1"], ["P&L", "EBITDA Adjustments", "Balance Sheet"], {("Balance Sheet", "D5"): cash})
    b.names.append(("Applied_Multiple", "Valuation!$D$7"))
    v = b.sheet("Valuation")
    v.put("A1", "Tidewater Analytics - Q2 2026 valuation (CAD)")
    v.put("B3", "Valuation date"); v.put("C3", datetime.date(2026, 6, 30), s=6)
    v.put("B5", "Quarter"); v.put("C5", datetime.date(2026, 3, 31), s=6); v.put("D5", datetime.date(2026, 6, 30), s=6)
    v.put("B6", "TTM pro forma adjusted EBITDA"); v.put("C6", prior_ttm); v.put("D6", ttm, f"'[{LV3}]TTM'!O10")
    v.put("B7", "Applied EV/EBITDA multiple"); v.put("C7", mult_prior, s=3); v.put("D7", mult, s=3)
    v.put("B8", "Enterprise value"); v.put("C8", prior_ttm * mult_prior, "C6*C7"); v.put("D8", ev, "D6*Applied_Multiple")
    v.put("B9", "Cash"); v.put("C9", 2_650_000); v.put("D9", cash, f"'[{LW1}]Balance Sheet'!D5")
    v.put("B10", "Debt"); v.put("C10", 18_400_000); v.put("D10", debt)
    v.put("B11", "Equity value"); v.put("C11", prior_ttm * mult_prior + 2_650_000 - 18_400_000, "C8+C9-C10"); v.put("D11", eq, "D8+D9-D10")
    v.put("B13", "Sensitivity - EV at other multiples"); v.put("C14", ev, "D8")
    for i, m in enumerate([8.5, 9.0, 9.5, 10.0, 10.5]):
        v.put(f"B{15 + i}", m, s=3)
        d = {"t": "dataTable", "ref": "C15:C19", "r1": "D7"} if i == 0 else {}
        v.put(f"C{15 + i}", ttm * m, None, 2, **d)
    w = b.sheet("Waterfall")
    w.put("A2", "Equity allocation"); w.put("A3", "Equity value"); w.put("B3", eq, "Valuation!D11")
    w.put("A4", "Series A liquidation preference"); w.put("B4", pref)
    w.put("A5", "XPV as-converted ownership"); w.put("B5", own, s=4)
    w.put("A6", "As-converted value"); w.put("B6", asconv, "B3*B5")
    w.put("A7", "Value to XPV (CAD) - greater of preference and as-converted"); w.put("B7", xpv_local, "MAX(B4,B6)")
    w.put("A9", "CAD/USD"); w.put("B9", fx)
    w.put("A10", "Value to XPV (USD)"); w.put("B10", xpv_usd, "B7*B9")
    c = b.sheet("Comps")
    c.put("A3", "Peer"); c.put("D3", "EV/EBITDA")
    peers = [("Peer One", 8.8), ("Peer Two", 9.6), ("Peer Three", 10.1), ("Peer Four", 9.2), ("Peer Five", 11.0)]
    for i, (pn, pm) in enumerate(peers):
        c.put(f"A{4 + i}", pn); c.put(f"D{4 + i}", pm, s=3)
    med = sorted(p for _, p in peers)[2]
    c.put("A10", "Median"); c.put("D10", med, "MEDIAN(D4:D8)", 3)
    c.put("A12", "Implied EV at median (cross-check)"); c.put("D12", med * ttm, "D10*Valuation!D6")
    r = b.sheet("Report")
    r.put("B4", "Value to XPV (USD 000s)"); r.put("C5", "Mar 31"); r.put("D5", "Jun 30"); r.put("C4", 2026)
    r.put("C6", 22_480); r.put("D6", round(xpv_usd / 1000), "ROUND(Waterfall!B10/1000,0)")
    q1 = b.sheet("Q1 Val (old)", "hidden")
    q1.put("B6", "TTM adj EBITDA"); q1.put("C6", 6_700_000); q1.put("C7", 9.0); q1.put("C8", "#REF!", "#REF!*C7")
    b.save(os.path.join(out, F["W4"]))

    # ---- W5 fund valuation summary (USD 000s) ----
    ev_f = ttm * 9.0
    eq_f = ev_f + cash - debt
    fund_local = max(pref, eq_f * own)
    fund_usd_k = round(fund_local * fx / 1000)
    b = Book()
    p = b.sheet("Portfolio")
    p.put("A1", "Fund Q - valuation summary (USD 000s)")
    p.put("C2", 2026); p.put("B3", "Company"); p.put("C3", "Mar 31"); p.put("D3", "Jun 30")
    p.put("B4", "Granite Basin Services"); p.put("C4", 41_200); p.put("D4", 42_050)
    p.put("B5", "Tidewater Analytics"); p.put("C5", 22_480); p.put("D5", fund_usd_k, "'Fund Calc'!E5")
    p.put("B6", "Northline Utilities"); p.put("C6", 18_900); p.put("D6", 19_340)
    p.put("B8", "Total"); p.put("C8", 41_200 + 22_480 + 18_900, "SUM(C4:C6)"); p.put("D8", 42_050 + fund_usd_k + 19_340, "SUM(D4:D6)")
    fc = b.sheet("Fund Calc")
    fc.put("B3", "Company"); fc.put("C3", "Company-reported value (USD 000s)"); fc.put("D3", "Fund adjustment"); fc.put("E3", "Fund value (USD 000s)")
    fc.put("B5", "Tidewater Analytics"); fc.put("C5", round(xpv_usd / 1000))
    fc.put("D5", "Fund applies 9.0x (company workbook 9.5x) pending IC review"); fc.put("E5", fund_usd_k)
    b.save(os.path.join(out, F["W5"]))

    facts.update(files=F, unsupplied=V3, ttm=ttm, ev=ev, equity=eq, xpv_local=xpv_local, xpv_usd=xpv_usd,
                 xpv_usd_000=round(xpv_usd / 1000), fund_usd_000=fund_usd_k, w1_rolling_ttm_jun26=rolling[17],
                 sensitivity_at_9_5="'Valuation'!C17", window=[months[m].isoformat() for m in (6, 17)])
    return facts


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="trial/set-T1")
    a = ap.parse_args()
    print(json.dumps(build(a.out), indent=1, default=str))
