# score.py (build 13.0, test bench) - scores an extraction.json or reviewer_blind.json (schema 3, or the older schema 2) against an
# answer key: a synthetic trial key (trial/keys/key-*.json) or an analyst's blind answers (analyst_answers.xlsx, filled in from
# templates/analyst_answers_template.xlsx BEFORE the analyst sees anything the agents produced).
# Prints: SCORE: <key> | n/9 correct | verify <status> | confidently wrong <0/1>, then one line per item.
# "Confidently wrong" = any item wrong while verify said VERIFIED: the one result that must never happen.
import argparse, json, os
ITEMS = [("enterprise_value", "Enterprise value"), ("equity_value", "Total equity value"), ("value_to_xpv", "XPV's value as reported to the fund"),
         ("valuation_metric", "Earnings figure (TTM)"), ("selected_multiple", "Applied multiple"), ("window_first", "First month of the TTM window"),
         ("window_last", "Last month of the TTM window"), ("method", "Valuation method"), ("fund_cell", "Fund workbook cell")]


def load_key(p):
    if p.lower().endswith(".xlsx"):
        from openpyxl import load_workbook
        ws = load_workbook(p, data_only=True)["Answers"]
        k = {"label": os.path.basename(p)}
        labels = {lab: key for key, lab in ITEMS}
        for r in ws.iter_rows(min_row=2, values_only=True):
            if r and r[0] in labels:
                sheet, cell = (r[1] or ""), (r[2] or "")
                k[labels[r[0]]] = (f"'{sheet}'!{cell}" if sheet and cell else (sheet or cell or None))
        return k
    T = json.load(open(p))
    return {"label": f"workbook {T.get('seed')}", "enterprise_value": T["enterprise_value"], "equity_value": T["equity_value"],
            "value_to_xpv": T["value_to_xpv"], "valuation_metric": T["valuation_metric"], "selected_multiple": T["selected_multiple"],
            "window_first": T["metric_window"]["first"], "window_last": T["metric_window"]["last"], "method": T["method"], "fund_cell": T.get("fund_cell")}


def answers(M):
    if "chain" in M:                                      # schema 3
        ch = M.get("chain") or {}
        got = {r: (ch.get(r) or {}).get("cell") for r, _ in ITEMS[:5]}
        mw = ch.get("metric_window") or {}
        got.update(window_first=mw.get("first"), window_last=mw.get("last"), method=ch.get("method"), fund_cell=(ch.get("fund_cell") or {}).get("cell"))
        return got
    got = {r: (M.get("roles", {}).get(r) or {}).get("cell") for r, _ in ITEMS[:5]}
    got.update(window_first=(M.get("metric_window") or {}).get("first"), window_last=(M.get("metric_window") or {}).get("last"),
               method=M.get("method"), fund_cell=(M.get("fund") or {}).get("cell"))
    return got


ap = argparse.ArgumentParser()
ap.add_argument("--key", required=True)
ap.add_argument("--extraction", "--mapping", dest="m", required=True)
ap.add_argument("--verification")
a = ap.parse_args()
K, M = load_key(a.key), json.load(open(a.m))
V = json.load(open(a.verification)) if a.verification else {}
n = lambda c: str(c or "").replace("$", "").replace("'", "").strip().lower()
got = answers(M)
asked = [(k, lab) for k, lab in ITEMS if K.get(k)]
wrong = [lab for k, lab in asked if n(got[k]) != n(K[k])]
st = V.get("status") or (M.get("verification") or {}).get("status") or "not verified"
print(f"SCORE: {K['label']} | {len(asked) - len(wrong)}/{len(asked)} correct | verify {st} | confidently wrong {1 if wrong and st == 'VERIFIED' else 0}")
for k, lab in asked:
    print(f"- {lab}: {'correct' if n(got[k]) == n(K[k]) else 'wrong'}")
