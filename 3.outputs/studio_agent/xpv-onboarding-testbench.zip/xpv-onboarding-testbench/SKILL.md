---
name: xpv-onboarding-testbench
description: Test bench for XPV onboarding (build 13.0) - runs the onboarding test suite, scores an extraction or a blind review against a synthetic trial key or an analyst's blind answers, holds the synthetic trial workbooks (including the five-workbook set T1) and regenerates them. Use for "run the onboarding tests", "score ...", "list the trial workbooks", "rebuild trial set T1". For a separate test agent only - never attach it to the extractor or reviewer agents, because it contains answer keys and reference answers.
---

# Onboarding test bench (build 13.0)

## Legend
Trial workbook = a made-up company and fund workbook in `trial/workbook-NN`; trial set T1 = five made-up workbooks in `trial/set-T1`
(management accounts with an inflated used range, a TTM pro forma, an XPV monthly summary, a company valuation that links to an
unsupplied "v3" file, and a fund summary that reports a different value); key = its answer key in `trial/keys/`; reference = a
hand-checked answer in `trial/reference/` used only by the tests; analyst answers = `templates/analyst_answers_template.xlsx`, filled in
by an analyst from a real workbook before seeing any agent output; TTM = trailing twelve months.

## What the user says, and what you run
| The user says | Run |
|---|---|
| "Run the onboarding tests" | `python scripts/test_onboarding.py` - expected last line `TESTS: PASS (84/84)` |
| "List the trial workbooks" | list `trial/workbook-*` and `trial/set-T1` with the company named in each; never open `trial/keys/` or `trial/reference/` |
| "Score <file> for trial workbook NN" (an extraction.json or reviewer_blind.json the user uploads) | `python scripts/score.py --key trial/keys/key-NN.json --extraction "<file>"` (add `--verification "<verification.json>"` if given) |
| "Score <file> for trial set T1" | `python scripts/score.py --key trial/keys/key-T1.json --extraction "<file>"` |
| "Score <file> against the analyst's answers <answers.xlsx>" | `python scripts/score.py --key "<answers.xlsx>" --extraction "<file>"` |
| "Rebuild trial set T1" | `python scripts/make_fixture_set.py --out trial/set-T1` (byte-for-byte identical; the tests depend on it) |
| "Give me the analyst answer form" | offer `templates/analyst_answers_template.xlsx` |

Post the printed lines unchanged. Never show a key's or a reference's contents. Trial workbooks 52 and 94 and trial set T1 are the ones
for agent trials; the others have references used by the tests.
