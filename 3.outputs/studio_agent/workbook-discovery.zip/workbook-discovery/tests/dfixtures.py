# tests/dfixtures.py (build 11.5) - synthetic workbooks for the DISCOVERY failure modes (no real data). Saved values are
# injected as Excel would write them. Each fixture also returns the facts its author knows independently of discovery
# (expected precedents, periods, regions), so tests never use discovery's own conclusions as the answer.
import datetime, os, re, shutil, zipfile
import vp_fixtures as FX
from openpyxl.worksheet.formula import ArrayFormula
from openpyxl.worksheet.table import Table


def _date(y, m):
    return datetime.datetime.combine(FX.month_end(y, m), datetime.time())


def structures_workbook(path):
    """every graph-status case in one workbook: shared formulas, a dynamic-array spill, an Excel table, a defined name, a
    named constant, INDIRECT (literal and computed), INDEX, an unsupported-to-recompute function, #REF!, an external link,
    a circular pair, a hub date used by 24 formulas, a header/window conflict."""
    b = FX.Book()
    inp = b.sheet("Inputs")
    b.put(inp, "A1", "Valuation date"); b.put(inp, "B1", _date(2025, 12), fmt="yyyy-mm-dd")
    b.put(inp, "A3", "Line item")
    cols = [chr(66 + i) for i in range(12)]                       # B..M = Jan..Dec 2025
    for i, c in enumerate(cols):
        b.put(inp, f"{c}3", _date(2025, i + 1), fmt="yyyy-mm-dd")
    rev = [100_000 + 1_000 * i for i in range(12)]
    cost = [40_000 + 500 * i for i in range(12)]
    b.put(inp, "A4", "Revenue"); b.put(inp, "A5", "Costs")
    for i, c in enumerate(cols):
        b.put(inp, f"{c}4", rev[i]); b.put(inp, f"{c}5", cost[i])
    ca = b.sheet("Calc")
    b.put(ca, "B1", "Dec-25"); b.put(ca, "C1", "Dec-25")
    b.put(ca, "A2", "TTM revenue"); b.put(ca, "B2", formula="=SUM(Inputs!B4:M4)", cached=sum(rev))
    b.put(ca, "C2", formula="=SUM(Inputs!B4:L4)", cached=sum(rev[:11]))            # header Dec, window ends Nov: CONFLICTING
    b.put(ca, "A4", "Literal indirect"); b.put(ca, "B4", formula='=INDIRECT("Inputs!B4")', cached=rev[0])
    b.put(ca, "A5", "Computed indirect"); b.put(ca, "B5", formula='=INDIRECT("Inputs!B"&B10)', cached=rev[0])
    b.put(ca, "A6", "Lookup"); b.put(ca, "B6", formula="=INDEX(Inputs!B4:M4,3)", cached=rev[2])
    b.put(ca, "A7", "Volatility"); b.put(ca, "B7", formula="=STDEV(Inputs!B4:M4)", cached=3605.55)
    b.put(ca, "A8", "Broken"); b.put(ca, "B8", formula="=Inputs!#REF!*2", cached="#REF!")
    b.put(ca, "A9", "External rate"); b.put(ca, "B9", formula="=[1]Rates!B2", cached=0.0425)
    b.put(ca, "B10", 4)
    b.put(ca, "A11", "Circular A"); b.put(ca, "B11", formula="=B12+1", cached=2.0)
    b.put(ca, "A12", "Circular B"); b.put(ca, "B12", formula="=B11*0.5", cached=1.0)
    b.put(ca, "A13", "Table total"); b.put(ca, "B13", formula="=SUM(Sales[Amount])", cached=60)
    b.put(ca, "A14", "Named range"); b.put(ca, "B14", formula="=SUM(MyRange)", cached=sum(cost))
    b.put(ca, "A15", "Named constant"); b.put(ca, "B15", formula="=Growth*100", cached=5.0)
    b.put(ca, "A16", "TTM revenue dated"); b.put(ca, "B16", formula="=B2+Inputs!$B$1*0", cached=sum(rev))   # uses the hub too
    for j in range(24):                                            # 24 formulas use the valuation date: a hub
        b.put(ca, f"D{2 + j}", formula=f"=Inputs!$B$1+{j}", cached=_date(2025, 12) + datetime.timedelta(days=j))
    for j, c in enumerate(cols[:4]):                               # copied across: becomes ONE shared formula B30:E30
        b.put(ca, f"{chr(66 + j)}30", formula=f"=Inputs!{c}4*2", cached=rev[j] * 2)
    ca["G2"] = ArrayFormula("G2:G4", "=SEQUENCE(3)")
    b.put(ca, "G3", 2); b.put(ca, "G4", 3)
    b.put(ca, "H2", formula="=SUM(G2:G4)", cached=6)
    tb = b.sheet("Tbl")
    for r, (it, am) in enumerate([("Item", "Amount"), ("a", 10), ("b", 20), ("c", 30)], 1):
        b.put(tb, f"A{r}", it); b.put(tb, f"B{r}", am)
    tb.add_table(Table(displayName="Sales", ref="A1:B4"))
    no = b.sheet("Notes")
    b.put(no, "A1", "Notes only - no numbers used anywhere")
    from openpyxl.workbook.defined_name import DefinedName
    b.wb.defined_names["MyRange"] = DefinedName("MyRange", attr_text="Inputs!$B$5:$M$5")
    b.wb.defined_names["Growth"] = DefinedName("Growth", attr_text="0.05")
    b.wb.defined_names["BadName"] = DefinedName("BadName", attr_text="#REF!")       # a corrupt named range
    b.put(ca, "A17", "Uses a corrupt name"); b.put(ca, "B17", formula="=BadName*2", cached="#REF!")
    b.save(path)
    _shared_and_spill(path)
    FX.add_external_links(path, ["Rates Feed.xlsx", "Stale Old Pack.xlsx"])
    return {"rev": rev, "cost": cost}


def _shared_and_spill(path):
    """rewrite Calc!B30:E30 as ONE shared formula (as Excel stores copied formulas) and mark G2 as a dynamic array."""
    tmp = path + ".tmp"
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        names = zin.namelist()
        wbx = zin.read("xl/workbook.xml").decode()
        order = re.findall(r'<sheet [^>]*name="([^"]+)"', wbx)
        calc_part = f"xl/worksheets/sheet{order.index('Calc') + 1}.xml"
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == calc_part:
                x = data.decode()
                x = x.replace("<f>Inputs!B4*2</f>", '<f t="shared" ref="B30:E30" si="0">Inputs!B4*2</f>', 1)
                for c in "CDE":
                    x = x.replace(f"<f>Inputs!{c}4*2</f>", '<f t="shared" si="0"/>', 1)
                x = re.sub(r'<c r="G2"([^>]*)>(<f[^>]*>[^<]*</f>)(?:<v>\s*</v>|<v\s*/>)?', r'<c r="G2" cm="1"\1>\2<v>1</v>', x, count=1)
                data = x.encode()
            zout.writestr(item, data)
    shutil.move(tmp, path)


def pasted_workbook(path, stale_ev=False, balance_sheet=None):
    """a small valuation with a pasted value (Working!B5 typed into Valuation!B8), a disconnected scratch island, a
    round-number trap and an irrelevant notes sheet."""
    b = FX.Book()
    mo = b.sheet("Monthly")
    b.put(mo, "A3", "Line item")
    cols = [chr(66 + i) for i in range(12)]
    for i, c in enumerate(cols):
        b.put(mo, f"{c}3", _date(2025, i + 1), fmt="yyyy-mm-dd")
    e = [50_000 + 700 * i for i in range(12)]
    b.put(mo, "A4", "Revenue"); b.put(mo, "A5", "EBITDA")
    for i, c in enumerate(cols):
        b.put(mo, f"{c}4", 200_000 + 1_000 * i); b.put(mo, f"{c}5", e[i])
    if balance_sheet:                                   # a balance-sheet block: balanced, or off by 500 in June
        b.put(mo, "A7", "Total assets"); b.put(mo, "A8", "Total liabilities"); b.put(mo, "A9", "Total equity")
        for i, c in enumerate(cols):
            la, eq_ = 300_000 + 2_000 * i, 500_000 + 1_000 * i
            b.put(mo, f"{c}7", la + eq_ + (500 if balance_sheet == "off" and i == 5 else 0)); b.put(mo, f"{c}8", la); b.put(mo, f"{c}9", eq_)
    va = b.sheet("Valuation")
    ttm = sum(e)
    b.put(va, "A2", "Valuation date"); b.put(va, "B2", _date(2025, 12), fmt="yyyy-mm-dd")
    b.put(va, "A4", "TTM EBITDA"); b.put(va, "B4", formula="=SUM(Monthly!B5:M5)", cached=ttm)
    b.put(va, "A5", "Selected EV/EBITDA multiple"); b.put(va, "B5", 8.0)
    ev = 8.0 * ttm
    b.put(va, "A6", "Enterprise value"); b.put(va, "B6", formula="=B5*B4", cached=ev + (50_000 if stale_ev else 0))
    ev = ev + (50_000 if stale_ev else 0)
    b.put(va, "A7", "Cash"); b.put(va, "B7", 250_000)
    b.put(va, "A8", "Other debt-like items"); b.put(va, "B8", 123_457)
    eq = ev + 250_000 - 123_457
    b.put(va, "A9", "Equity value"); b.put(va, "B9", formula="=B6+B7-B8", cached=eq)
    b.put(va, "A10", "XPV fully diluted ownership"); b.put(va, "B10", 0.4)
    b.put(va, "A11", "XPV value"); b.put(va, "B11", formula="=B9*B10", cached=eq * 0.4)
    wk = b.sheet("Working")
    b.put(wk, "A1", "Debt-like items workings")
    for r, v in ((2, 100_000), (3, 20_000), (4, 3_457)):
        b.put(wk, f"B{r}", v)
    b.put(wk, "A5", "Total debt-like items"); b.put(wk, "B5", formula="=SUM(B2:B4)", cached=123_457)
    b.put(wk, "B6", formula="=B5/2", cached=61_728.5); b.put(wk, "B7", formula="=B6+B2", cached=161_728.5)
    b.put(wk, "B8", formula="=B7-B3", cached=141_728.5); b.put(wk, "B9", formula="=B8*1", cached=141_728.5)
    b.put(wk, "B10", formula="=B2*2.5", cached=250_000)            # a round number equal to cash: never a candidate
    sc = b.sheet("Scratch")
    b.put(sc, "C1", 7)
    prev = 7
    for r in range(2, 9):
        b.put(sc, f"C{r}", formula=f"=C{r - 1}+3", cached=prev + 3)
        prev += 3
    no = b.sheet("Notes")
    b.put(no, "A1", "Board notes")
    b.save(path)
    return {"ttm": ttm, "ev": ev, "equity": eq, "value": eq * 0.4}


def rename_sheet(path, old, new):
    """a sheet renamed the way Excel does it: the sheet name and every formula that names it change; values do not."""
    tmp = path + ".tmp"
    q = lambda s: f"'{s}'" if re.search(r"[^A-Za-z0-9_]", s) else s
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == "xl/workbook.xml":
                data = data.decode().replace(f'name="{old}"', f'name="{new}"').encode()
            elif item.filename.startswith("xl/worksheets/sheet"):
                data = re.sub(r"<f([^>]*)>([^<]*)</f>", lambda mm: f"<f{mm.group(1)}>{mm.group(2).replace(q(old) + '!', q(new) + '!')}</f>",
                              data.decode()).encode()
            zout.writestr(item, data)
    shutil.move(tmp, path)
