# workbook-discovery build 11.6 – maintainers' notes

## Glossary
| Term | Meaning |
|---|---|
| Discovery / benchmark | The system that maps a workbook / the system that grades a map against an independent key |
| Layer 0 / 1 / 2 | Physical facts / derived relationships / financial meaning (docs/stage0-counting-and-status-rules.md) |
| vp | The vendored build 11.3 valuation-pipeline modules, byte-identical (test V.1) |

## Design rules (do not break)
1. **Separation.** `benchmark/` imports only `common/`, the standard library and openpyxl (test B.1). Nothing in an
   answer key may come from discovery code; the key builder takes blind answers, Excel facts and the analyst's review.
2. **Read-only.** Discovery never writes to the workbook (test D.13).
3. **No silent truncation.** Every formula node carries the five flags (test D.4); an unreadable reference is a flag.
4. **The requested period is the target, never evidence** (test D.9).
5. **Deterministic.** Clock only via `VALUATION_NOW`; sorted output; gzip with a fixed timestamp (test D.12).
6. **Versioned rules.** Changing a counting / graph / period rule bumps R or P; the benchmark reports a method change.
7. **Printed lines are counts and categories only.** Names, cells and values stay in the private files. Every printed
   prefix is documented in SKILL.md (test C.1).
8. **Fail fast, fail clearly.** Unreadable files stop at pre-flight; user-actionable problems raise `common.util.Stop`
   (one `STOPPED:` line, exit 3); bugs print one `... ERROR:` line (exit 1) with the traceback in a log file (test E.1).
9. **Rules are data, validated at start-up.** Thresholds, function lists, terminal classes and invariants live in
   `discovery/references/*.json`; an unknown invariant check or a malformed rules file stops the run.
10. **Never claim absence without looking.** A check that could not read every cell says NOT_EVALUATED, never NOT_APPLICABLE.
11. **Vendored code is never edited.** `discovery/vp/` is byte-identical to build 11.3.0 (test V.1); adapt it only in
    `discovery/vp_adapter.py`.
12. **Release only via `tools/release.py`.** It refuses to build a zip unless every test passes.

## Adding things
- A new invariant: a function in `discovery/invariants.py` decorated `@check("name")`, an entry in `invariants.json`, a test
  that makes it HOLD and one that makes it VIOLATED.
- A new graph rule or threshold: change the JSON, bump its version, add a fixture and a test; the next benchmark shows
  `method changed yes`.
- A new printed prefix: SKILL.md and test C.1.
- A change to the cell export: change `common/cellfmt.py` AND `excel-export.ts` together; the demo's CSV diff must stay empty.

## Module map
| File | Role |
|---|---|
| `common/util.py` | JSON, hashing, clock, cell-reference arithmetic, exit codes, `Stop` |
| `common/files.py` | finding inputs by name (ambiguity stops), output root |
| `common/preflight.py` | can the file be read at all (before any parsing) |
| `common/schema.py` | dependency-free validation of the answer key and blind answers |
| `discovery/rules.py`, `discovery/references/` | versioned rules and the invariant registry (hashes recorded in the map) |
| `discovery/vp_adapter.py` | the one place the vendored 11.3 analysis is adapted (model reuse) |
| `discovery/invariants.py` | the invariant checks the registry selects |
| `discovery/inventory.py` | Layer 0: package facts (sheets, calc settings, names, tables, arrays / spills, shared formulas, pivots…) and counts |
| `discovery/graph.py` | Layer 1: references via openpyxl's formula tokenizer (tables, names, 3-D, spill refs, literal INDIRECT), flags, cycles (Tarjan), re-computation, closures, hubs, regions and families, sinks |
| `discovery/semantics.py` | Layer 2 proposals: junctions (via vp analyze on the same model), period evidence (P1), terminal class and source, pasted-value candidates |
| `discovery/discover.py` | the discovery command: map files, targeted second read of cells only table / name references reach |
| `benchmark/xmlcount.py` | standard-library structural tripwire and physical sampling inventory |
| `benchmark/bench.py` | fingerprint, form, check-form, save-answers, compare (cells, formula uses, key numbers, areas, since-last), physical tripwire |
| `common/forms.py` | the ONE answer-form layout, for the analyst and for the program's answers |
| `common/cellfmt.py` | how a cell is written in both cell exports (dates as Excel serials, Excel's formula text) |
| `office-scripts/excel-export.ts` | Excel's own export of every cell and of what each distinct formula uses (resumable) |
| `tools/excel_standin.py` | stand-in for the Excel export, for tests and the demo only |
| `tools/demo.py` | the whole process on a made-up workbook |
| `tests/run_tests.py`, `tests/dfixtures.py` | 39 tests: D discovery, B benchmark, M mutations, P pre-flight and files, I invariants, E errors, S schemas, R rules, C contracts and hygiene, V vendored code |
| `tools/release.py` | the release gate: tests, package check, zip, manifest |

## Tests
`python tests/run_tests.py` → `ALL TESTS: PASS (39/39)`. Release: `python tools/release.py --out <folder>`. The vendored 11.3 modules keep their 76 tests in the
valuation-pipeline package (unchanged, passing). Every test key is written from what the fixture's author knows.
