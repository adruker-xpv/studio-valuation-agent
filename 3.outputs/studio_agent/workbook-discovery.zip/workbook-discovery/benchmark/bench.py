# benchmark/bench.py (build 11.6) - the BENCHMARK SYSTEM: checks the program's reading of a workbook against two
# independent sources - Excel itself (every cell, and what formulas use) and an analyst (what the key numbers mean).
# It reads the program's OUTPUT FILES only and never imports program code (test B.1). Commands:
#   fingerprint   the workbook's digital fingerprint (SHA-256): proves later that the same, unchanged file was used
#   form          the analyst's answer form for one workbook
#   check-form    checks a filled form against the workbook and says, in plain words, what to fix
#   save-answers  checks, then saves the analyst's answers with the date and time (before the program's answers are seen)
#   compare       compares the program's output with Excel's export and / or the analyst's answers; Excel report, diffable
#                 CSV files, a result file for the next comparison, and summary lines that hold no workbook content
#   physical      internal tripwire used by the tests (standard-library counts versus the program's counts)
# Exit codes: 0 done | 1 internal error (a bug) | 2 usage | 3 STOPPED (the user must act). Files are passed by name.
import argparse, csv, datetime, difflib, json, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path[:0] = [HERE, os.path.dirname(HERE)]
from common.util import (VERSION, now, dump, load, sha256_file, sha256_text, canon, read_jsonl_gz, parse_box, box_cells, cell_key,
                         col_idx, col_let, split_addresses, split_sheet, Stop, EXIT_OK, EXIT_INTERNAL, EXIT_STOPPED)
from common.files import find_input, out_root
from common.preflight import check_workbook
from common.schema import validate, ANSWERS
from common.forms import (write_form, read_form, KEY_NUMBERS, MONTHS, METHODS, AREA_KINDS, SHOULD_BE_USED, CELL_COLUMNS)
import xmlcount as XC

ADDR = re.compile(r"^[A-Z]{1,3}[1-9]\d{0,6}$")
MONTH = re.compile(r"^(19|20)\d{2}-(0[1-9]|1[0-2])$")


# ------------------------------------------------------------------------------------------------ the form
def cmd_form(a):
    if not MONTH.match(a.quarter_end[:7]) or len(a.quarter_end) != 10:
        raise Stop(f"--quarter-end must be a date like 2026-03-31 (got '{a.quarter_end}')", "usage")
    head = {"Workbook": os.path.basename(a.workbook), "Workbook fingerprint": sha256_file(a.workbook), "Quarter end": a.quarter_end,
            "Form made on": now().date().isoformat()}
    out = os.path.join(out_root("."), a.out) if not os.path.isabs(a.out) else a.out
    write_form(out, head, title=f"Answer form - {os.path.basename(a.workbook)}")
    print(f"FORM: made {os.path.basename(out)} - give it to the analyst with the workbook. The analyst fills the yellow boxes "
          "using only the workbook, then you run check-form")
    return EXIT_OK


class Book:
    """reads single cells of the original workbook (read-only, on demand) for the form checks."""
    def __init__(self, path):
        from openpyxl import load_workbook
        self.wb = load_workbook(path, data_only=True, read_only=True)
        self.names = self.wb.sheetnames

    def sheet(self, name):
        if name is None:
            return None, None
        exact = next((s for s in self.names if s == name), None) or next((s for s in self.names if s.lower() == str(name).lower().strip()), None)
        return exact, difflib.get_close_matches(str(name), self.names, 1, 0.5)

    def value(self, sheet, addr):
        return self.wb[sheet][addr].value

    def max_col(self, sheet):
        return self.wb[sheet].max_column or 1


def is_number(v):
    return isinstance(v, (int, float, datetime.date, datetime.datetime)) and not isinstance(v, bool)


def form_problems(form, wbpath):
    """plain-language problems with a filled form, each with what to do."""
    p, bk = [], Book(wbpath)
    fp = form["header"].get("Workbook fingerprint")
    if fp and fp != sha256_file(wbpath):
        p.append("this form was made for a different version of the workbook (its fingerprint differs): make a new form, or use the original file")
    labels = {k: lab for k, lab, _ in KEY_NUMBERS}
    for key, lab, _ in KEY_NUMBERS:
        x = form["key_numbers"].get(key) or {}
        sh, cell = x.get("sheet"), x.get("cell")
        if not sh and not cell:
            p.append(f"'{lab}': empty. Give the sheet and the cell that holds the number (or write 'Not sure' in Notes)")
            continue
        real, close = bk.sheet(sh)
        if not real:
            p.append(f"'{lab}': there is no sheet called '{sh}'" + (f" - did you mean '{close[0]}'?" if close else " - copy the name from the tab"))
            continue
        if not cell or not ADDR.match(cell):
            p.append(f"'{lab}': '{cell or '(empty)'}' is not a cell. Write one cell like B4 (letters then a number)")
            continue
        v = bk.value(real, cell)
        if not is_number(v):
            hint = ""
            if isinstance(v, str) and v.strip():
                m = re.match(r"([A-Z]+)(\d+)", cell)
                for c in range(col_idx(m.group(1)) + 1, min(col_idx(m.group(1)) + 30, bk.max_col(real) + 1)):
                    if is_number(bk.value(real, f"{col_let(c)}{m.group(2)}")):
                        hint = f" The first number to its right is in {col_let(c)}{m.group(2)} - is that the one?"
                        break
                p.append(f"'{lab}': {real}!{cell} holds the text '{str(v)[:40]}', not a number. Give the cell with the NUMBER, not its name.{hint}")
            else:
                p.append(f"'{lab}': {real}!{cell} is empty or not a number. Give the cell that holds the number")
    ms = form["months"]
    for key, lab, ex in MONTHS:
        m = ms.get(key)
        if m and not MONTH.match(m):
            p.append(f"'{lab}': '{m}' is not a month written year-month ({ex})")
    if ms.get("metric_first_month") and ms.get("metric_last_month") and MONTH.match(ms["metric_first_month"]) and MONTH.match(ms["metric_last_month"]):
        y1, m1 = map(int, ms["metric_first_month"].split("-"))
        y2, m2 = map(int, ms["metric_last_month"].split("-"))
        span = (y2 * 12 + m2) - (y1 * 12 + m1) + 1
        if span < 1:
            p.append("the first month comes after the last month: swap them")
        elif span != 12:
            p.append(f"note: the earnings figure covers {span} months, not 12 - fine if that is right, otherwise check the months")
    if form["method"] and form["method"] not in METHODS:
        p.append(f"'Valuation method': '{form['method']}' is not one of the list ({', '.join(METHODS)})")
    for ar in form["areas"]:
        where = f"'2 Areas' row {ar['row']}"
        real, close = bk.sheet(ar["sheet"])
        if not real:
            p.append(f"{where}: no sheet called '{ar['sheet']}'" + (f" - did you mean '{close[0]}'?" if close else ""))
        if ar["cells"] and not parse_box(ar["cells"]):
            p.append(f"{where}: '{ar['cells']}' is not a cell range. Write it like F5:F40, or B:M, or leave it empty for the whole sheet")
        if ar["what"] not in AREA_KINDS:
            p.append(f"{where}: 'What it is' must be chosen from the list")
        if ar["month"] and not MONTH.match(ar["month"]):
            p.append(f"{where}: month '{ar['month']}' is not written year-month, e.g. 2026-03")
    return [x for x in p if not x.startswith("note:")], [x for x in p if x.startswith("note:")]


def cmd_check_form(a):
    form = read_form(a.form)
    problems, notes = form_problems(form, a.workbook)
    for n_ in notes:
        print(f"FORM: {n_}")
    if problems:
        print(f"FORM: {len(problems)} thing(s) to fix")
        for x in problems:
            print(f"- {x}")
        return EXIT_STOPPED
    print("FORM: OK - nothing to fix. Next: save-answers")
    return EXIT_OK


def cmd_save_answers(a):
    form = read_form(a.form)
    problems, notes = form_problems(form, a.workbook)
    if problems:
        print(f"FORM: {len(problems)} thing(s) to fix before the answers can be saved")
        for x in problems:
            print(f"- {x}")
        return EXIT_STOPPED
    body = {"schema": "answers/1", "workbook": os.path.basename(a.workbook), "fingerprint": sha256_file(a.workbook),
            "quarter_end": form["header"].get("Quarter end", ""), "saved_by": a.by, "saved_at": now().isoformat(),
            "answers": {"key_numbers": {k: {kk: vv for kk, vv in v.items() if kk in ("sheet", "cell")} for k, v in form["key_numbers"].items()},
                        "months": form["months"], "method": form["method"],
                        "areas": [{k: v for k, v in ar.items()} for ar in form["areas"] if ar["what"] != "Not sure"]}}
    body["sha256"] = sha256_text(canon(body))
    out = os.path.join(out_root("."), a.out) if not os.path.isabs(a.out) else a.out
    dump(body, out)
    print(f"FORM: answers saved ({os.path.basename(out)}) by {a.by} at {body['saved_at'][:16]} - keep this file; it is the analyst's answer "
          "for this workbook. Next: run the program, then compare")
    return EXIT_OK


# ------------------------------------------------------------------------------------------------ compare
def read_excel_export(path, program_sheets):
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=True)
    if "XLX Info" not in wb.sheetnames:
        raise Stop("this file has no Excel export in it: run the excel-export script on it in Excel first", "missing_file")
    info = {r[0]: r[1] for r in wb["XLX Info"].iter_rows(max_row=9, values_only=True) if r and r[0]}
    if str(info.get("Status")) != "Finished":
        raise Stop("the Excel export has not finished: open the copy in Excel, run excel-export again until it says Finished", "user_action")
    rows = list(wb["XLX Info"].iter_rows(values_only=True))
    head = next((i for i, r in enumerate(rows) if r and r[0] == "Sheet" and len(r) > 1 and r[1] == "Visibility"), None)
    if head is None:
        raise Stop("the Excel export's progress table is missing: run excel-export again on a fresh copy", "user_action")
    sheets = [r[0] for r in rows[head + 1:] if r and r[0] and r[0] not in ("Defined names", "Tables / linked workbooks")]
    if [s.lower() for s in sheets] != [s.lower() for s in program_sheets]:
        raise Stop("this Excel export is from a workbook with different sheets than the one the program read: use a copy of the same file", "user_action")
    cells = [tuple("" if x is None else str(x) for x in r[:5]) for r in wb["XLX Cells"].iter_rows(min_row=2, values_only=True) if r and r[0]]
    uses = [tuple("" if x is None else str(x) for x in r[:4]) for r in wb["XLX Uses"].iter_rows(min_row=2, values_only=True) if r and r[0]]
    return info, cells, uses


def _num(s):
    try:
        return float(s)
    except (TypeError, ValueError):
        return None


def same_value(e, p, te, tp):
    if te == "number" and tp == "number":
        x, y = _num(e), _num(p)
        return x is not None and y is not None and abs(x - y) <= max(1e-9, 1e-9 * max(abs(x), abs(y)))
    if te == "boolean" and tp == "boolean":
        return e.upper() == p.upper()
    return e == p


def compare_cells(excel_cells, prog_rows, order, kinds):
    E = {(r[0].lower(), r[1]): r for r in excel_cells}
    P = {(r[0].lower(), r[1]): r for r in prog_rows}
    diffs, counts = [], {"matched": 0, "missing in program": 0, "extra in program": 0, "formula differs": 0, "value differs": 0, "type differs": 0}
    for k in sorted(set(E) | set(P), key=lambda k: (order.get(k[0], 999), int(re.sub(r"\D", "", k[1]) or 0), col_idx(re.sub(r"\d", "", k[1])))):
        e, p = E.get(k), P.get(k)
        if e and not p:
            what = "missing in program"
        elif p and not e:
            what = "extra in program"
        elif e[2] != p[2]:
            what = "formula differs"
        elif e[4] != p[4] and not ({e[4], p[4]} <= {"empty", "text"} and not e[3] and not p[3]):
            what = "type differs"
        elif not same_value(e[3], p[3], e[4], p[4]):
            what = "value differs"
        else:
            counts["matched"] += 1
            continue
        counts[what] += 1
        why = "spilled cell (formula result)" if kinds.get(k) == "array_result" else ""
        diffs.append([(e or p)[0], k[1], what, "|".join(e[2:5]) if e else "", "|".join(p[2:5]) if p else "", why])
    return counts, diffs


def _cellset(text, default_sheet, sheets_lc):
    out = set()
    for t in split_addresses(str(text).replace(";", ",")):
        b = parse_box(t.replace("$", ""), default_sheet)
        if not b:
            continue
        sh = sheets_lc.get((b[0] or "").strip("'").lower(), b[0])
        cs = box_cells((sh,) + b[1:], 200_000)
        out |= cs or {("range", t)}
    return out


def compare_uses(excel_uses, prog_uses, sheets_lc):
    P = {(r["Sheet"].lower(), r["Cell"]): r for r in prog_uses}
    rows, counts = [], {"checked": 0, "same": 0, "missed silently": 0, "missed but flagged": 0, "extra (flagged)": 0, "extra": 0,
                        "excel could not list": 0}
    for sh, cell, uses, note in excel_uses:
        if note:
            counts["excel could not list"] += 1
            rows.append([sh, cell, "excel could not list", uses, "", note])
            continue
        counts["checked"] += 1
        p = P.get((sh.lower(), cell))
        e_set = _cellset(uses, sh, sheets_lc)
        p_set = _cellset(p["Uses"], sh, sheets_lc) if p else set()
        flagged = bool(p and any(w in p["Note"] for w in ("could not read", "deleted reference", "computed at calculation time",
                                                           "reads another workbook")))   # flags that EXPLAIN a missing reference
        if e_set == p_set:
            res = "same"
        elif e_set - p_set:
            res = "missed but flagged" if flagged else "missed silently"
        else:
            res = "extra (flagged)" if p and "over-approximated" in p["Note"] else "extra"
        counts[res] += 1
        rows.append([sh, cell, res, uses, p["Uses"] if p else "", p["Note"] if p else "program has no formula here"])
    return counts, rows


def _norm_cell(sheet, cell):
    return (str(sheet or "").strip().lower(), str(cell or "").strip().upper().replace("$", ""))


def compare_meaning(ans, prog, cells_by_sheet, order):
    kn_rows, res = [], {"key numbers asked": 0, "correct": 0, "wrong": 0, "program did not decide": 0, "confidently wrong": 0}
    for key, lab, _ in KEY_NUMBERS:
        a_ = ans["key_numbers"].get(key) or {}
        if not a_.get("cell"):
            continue
        res["key numbers asked"] += 1
        p = prog["key_numbers"].get(key) or {}
        if not p.get("cell"):
            r = "program did not decide"
        elif _norm_cell(a_.get("sheet"), a_.get("cell")) == _norm_cell(p.get("sheet"), p.get("cell")):
            r = "correct"
        else:
            r = "wrong"
            if p.get("status") == "PROVEN":
                res["confidently wrong"] += 1
        res[r] += 1
        kn_rows.append([lab, f"{a_.get('sheet')}!{a_.get('cell')}", f"{p.get('sheet')}!{p.get('cell')}" if p.get("cell") else "-", r,
                        (p.get("status") or "").lower()])
    mo = {"months asked": 0, "months correct": 0}
    for key, lab, _ in MONTHS:
        am, pm = ans["months"].get(key), prog["months"].get(key)
        if am:
            mo["months asked"] += 1
            ok = am == pm
            mo["months correct"] += ok
            if not ok and pm and prog["months"].get("status") == "PROVEN":
                res["confidently wrong"] += 1
            kn_rows.append([lab, am, pm or "-", "correct" if ok else "wrong" if pm else "program did not decide", (prog["months"].get("status") or "").lower()])
    meth = None
    if ans.get("method"):
        meth = ans["method"] == prog.get("method")
        kn_rows.append(["Valuation method", ans["method"], prog.get("method") or "-", "correct" if meth else "wrong", (prog.get("method_status") or "").lower()])
    ar_rows, ar = [], {"areas": 0, "handled correctly": 0, "handled wrongly": 0, "cells with a month": 0, "month correct": 0, "month wrong": 0,
                       "month undecided": 0}
    for x in ans["areas"]:
        if x["what"] not in SHOULD_BE_USED:
            continue
        ar["areas"] += 1
        sh = next((s for s in order if s.lower() == str(x["sheet"]).lower()), x["sheet"])
        b = parse_box(x["cells"], sh) if x.get("cells") else None
        inside = [c for c in cells_by_sheet.get(sh.lower(), []) if not b or (b[1] <= c["_r"] <= b[3] and b[2] <= c["_c"] <= b[4])]
        used = any(c["l2"]["material_by_reference"] for c in inside)
        want = SHOULD_BE_USED[x["what"]]
        ok = used == want
        ar["handled correctly" if ok else "handled wrongly"] += 1
        mc = mw = mu = 0
        if x.get("month"):
            for c in inside:
                if c["l0"]["kind"] not in ("number", "formula", "date"):
                    continue
                pe = c["l2"]["period"]
                if pe["status"] in ("PROVEN", "SUPPORTED"):
                    if pe["period"] == x["month"]:
                        mc += 1
                    else:
                        mw += 1
                        if pe["status"] == "PROVEN":
                            res["confidently wrong"] += 1
                else:
                    mu += 1
            ar["cells with a month"] += mc + mw + mu
            ar["month correct"] += mc
            ar["month wrong"] += mw
            ar["month undecided"] += mu
        ar_rows.append([f"row {x.get('row', '?')}", f"{x['sheet']}!{x.get('cells') or '(whole sheet)'}", x["what"],
                        "used by the valuation" if used else "not used by the valuation", "correct" if ok else "wrong",
                        x.get("month") or "", mc, mw, mu])
    return {"key": res, "months": mo, "method_correct": meth, "areas": ar}, kn_rows, ar_rows


def write_report(path, summary_lines, sheets):
    from openpyxl import Workbook
    from openpyxl.styles import Font
    wb = Workbook()
    s = wb.active
    s.title = "Summary"
    for ln in summary_lines:
        s.append([ln])
    s["A1"].font = Font(bold=True, size=13)
    s.column_dimensions["A"].width = 140
    for title, header, rows in sheets:
        w = wb.create_sheet(title[:31])
        w.append(header)
        for c in w[1]:
            c.font = Font(bold=True)
        for r in rows[:200_000]:
            w.append(r)
        for i in range(len(header)):
            w.column_dimensions[col_let(i + 1)].width = 28
    wb.save(path)


def cmd_compare(a):
    if not a.excel_export and not a.answers:
        raise Stop("give --excel-export (Excel's own export), --answers (the analyst's saved answers), or both", "usage")
    if not a.program and not a.workbook:
        raise Stop("give --workbook (the original workbook the program read) or --program (its results folder)", "usage")
    mapdir = a.program or "program_" + re.sub(r"[^A-Za-z0-9 ._-]", "_", os.path.splitext(os.path.basename(a.workbook))[0])[:80]
    if not os.path.isfile(os.path.join(mapdir, "workbook_map.json")):
        alt = os.path.join(out_root("."), mapdir)
        if os.path.isfile(os.path.join(alt, "workbook_map.json")):
            mapdir = alt
        else:
            raise Stop(f"no program results for this workbook in this conversation ('{os.path.basename(mapdir)}'): run the program on the "
                       "workbook first (it takes a few minutes), then compare again", "missing_file")
    M = load(os.path.join(mapdir, "workbook_map.json"))
    order_list = [s["name"] for s in sorted(({"name": k, **v} for k, v in M["layer0"]["sheets"].items()), key=lambda x: x.get("order", 999))]
    order = {s.lower(): i for i, s in enumerate(order_list)}
    sheets_lc = {s.lower(): s for s in order_list}
    a.out = a.out or "comparison_" + os.path.basename(mapdir)[len("program_"):] if not a.out else a.out
    out = os.path.join(out_root("."), a.out) if not os.path.isabs(a.out) else a.out
    os.makedirs(out, exist_ok=True)
    warnings, result = [], {"meta": {"benchmark_version": VERSION, "program_version": M["meta"]["discovery_version"],
                                     "rules_hashes": M["meta"].get("rules_hashes"), "workbook": M["meta"]["workbook"],
                                     "fingerprint": M["meta"]["workbook_sha256"], "compared_at": now().isoformat()}, "checks": {}}
    sheets_out, lines = [], [f"Comparison of the program's reading of {M['meta']['workbook']} (program build {M['meta']['discovery_version']})", ""]
    rows = list(read_jsonl_gz(os.path.join(mapdir, "cells.jsonl.gz")))
    kinds, cells_by_sheet = {}, {}
    for r in rows:
        k = cell_key(r["cell"])
        r["_r"], r["_c"] = k[1], k[2]
        kinds[(k[0].lower(), f"{col_let(k[2])}{k[1]}")] = r["l0"]["kind"]
        cells_by_sheet.setdefault(k[0].lower(), []).append(r)
    if a.excel_export:
        info, xc, xu = read_excel_export(a.excel_export, order_list)
        with open(os.path.join(mapdir, "program_cells.csv"), encoding="utf-8") as fh:
            prows = [tuple(r) for r in list(csv.reader(fh))[1:]]
        cc, diffs = compare_cells(xc, prows, order, kinds)
        key_ = lambda r: (order.get(r[0].lower(), 999), int(re.sub(r"\D", "", r[1]) or 0), col_idx(re.sub(r"\d", "", r[1])))
        for name, data in (("excel_cells.csv", xc), ("program_cells.csv", prows)):
            with open(os.path.join(out, name), "w", newline="", encoding="utf-8") as fh:
                w = csv.writer(fh, lineterminator="\n")
                w.writerow(CELL_COLUMNS)
                w.writerows(sorted(data, key=key_))
        with open(os.path.join(mapdir, "program_uses.csv"), encoding="utf-8") as fh:
            puses = list(csv.DictReader(fh))
        uc, urows = compare_uses(xu, puses, sheets_lc)
        total = cc["matched"] + sum(v for k, v in cc.items() if k not in ("matched", "extra in program"))
        result["cells"], result["uses"] = cc, uc
        result["checks"]["file contents match Excel"] = "PASS" if len(diffs) == 0 else "FAIL"
        result["checks"]["formula uses match Excel"] = "PASS" if uc["missed silently"] == 0 and uc["extra"] == 0 else "FAIL"
        lines += [f"File contents compared with Excel: {cc['matched']} of {total} cells match exactly.",
                  f"  Missing in the program: {cc['missing in program']}. Extra in the program: {cc['extra in program']}. "
                  f"Formula differs: {cc['formula differs']}. Value differs: {cc['value differs']}. Type differs: {cc['type differs']}.",
                  f"What formulas use, compared with Excel ({uc['checked']} distinct formulas checked): same {uc['same']}, "
                  f"missed silently {uc['missed silently']}, missed but flagged {uc['missed but flagged']}, extra {uc['extra']}, "
                  f"extra but flagged {uc['extra (flagged)']}, Excel could not list {uc['excel could not list']}.", ""]
        sheets_out += [("Cell differences", ["Sheet", "Cell", "What differs", "Excel (formula|value|type)", "Program (formula|value|type)", "Note"], diffs),
                       ("Formula uses", ["Sheet", "Cell", "Result", "Excel says it uses", "Program says it uses", "Program note"], urows)]
    if a.answers:
        A = validate(load(a.answers), ANSWERS, "saved answers file")
        body = {k: v for k, v in A.items() if k != "sha256"}
        if sha256_text(canon(body)) != A["sha256"]:
            raise Stop("the saved answers file was edited after it was saved: use the saved file, or save the answers again", "user_action")
        if A["fingerprint"] != M["meta"]["workbook_sha256"]:
            raise Stop("the analyst's answers are for a different version of the workbook than the one the program read (fingerprints differ)", "user_action")
        if A["saved_at"] > M["meta"]["run_at"]:
            warnings.append("the analyst's answers were saved after the program ran - make sure the analyst had not seen the program's answers")
        prog = load(os.path.join(mapdir, "program_answers.json"))
        mres, kn_rows, ar_rows = compare_meaning(A["answers"], prog, cells_by_sheet, order_list)
        result["meaning"] = mres
        k_, mo, ar = mres["key"], mres["months"], mres["areas"]
        result["checks"]["key numbers"] = "PASS" if k_["wrong"] == 0 and k_["program did not decide"] == 0 else "FAIL"
        result["checks"]["months and method"] = "PASS" if mo["months correct"] == mo["months asked"] and mres["method_correct"] in (True, None) else "FAIL"
        result["checks"]["areas"] = "PASS" if ar["handled wrongly"] == 0 and ar["month wrong"] == 0 else "FAIL"
        result["checks"]["nothing confidently wrong"] = "PASS" if k_["confidently wrong"] == 0 else "FAIL"
        lines += [f"Key numbers compared with the analyst: {k_['correct']} of {k_['key numbers asked']} correct, {k_['wrong']} wrong, "
                  f"{k_['program did not decide']} not decided by the program.",
                  f"Months: {mo['months correct']} of {mo['months asked']} correct. Method: "
                  + ("correct" if mres["method_correct"] else "wrong" if mres["method_correct"] is False else "not asked") + ".",
                  f"Areas: {ar['handled correctly']} of {ar['areas']} handled as the analyst says. Cells in labelled months: "
                  f"{ar['month correct']} correct, {ar['month wrong']} wrong, {ar['month undecided']} undecided.",
                  f"CONFIDENTLY WRONG (the program was sure and the analyst disagrees): {k_['confidently wrong']}  <- must be 0", ""]
        sheets_out += [("Key numbers", ["Item", "Analyst", "Program", "Result", "Program confidence"], kn_rows),
                       ("Areas", ["Form row", "Area", "Analyst says", "Program", "Result", "Analyst month", "Cells month correct",
                                  "Cells month wrong", "Cells month undecided"], ar_rows)]
    g = M["gates"]
    result["open"] = g
    lines += ["Things the program itself says are still open: " + ", ".join(f"{k.replace('_', ' ')} {v}" for k, v in g.items() if v) or "none", ""]
    prev = load(a.previous) if a.previous else None
    if prev:
        better = [k for k, v in result["checks"].items() if v == "PASS" and prev["checks"].get(k) == "FAIL"]
        worse = [k for k, v in result["checks"].items() if v == "FAIL" and prev["checks"].get(k) == "PASS"]
        result["since_last"] = {"better": better, "worse": worse, "rules_changed": prev["meta"].get("rules_hashes") != result["meta"]["rules_hashes"]}
        lines += [f"Since the last comparison: better {len(better)} ({', '.join(better) or '-'}), worse {len(worse)} ({', '.join(worse) or '-'})"
                  + (" - the program's rules changed" if result["since_last"]["rules_changed"] else ""), ""]
    lines += [f"Warning: {w}" for w in warnings]
    dump(result, os.path.join(out, "result.json"))
    write_report(os.path.join(out, "comparison.xlsx"), lines, sheets_out)
    for l in summary(result):
        print(l)
    print(f"NEXT: open comparison.xlsx in {os.path.basename(out)} (private: it shows cells). Send Claude only the BENCHMARK lines. "
          "Keep result.json and give it as --previous next time.")
    return EXIT_OK


def summary(r, redact=False):
    n = lambda x: "n" if redact else str(x)
    L = [f"BENCHMARK: comparison | build {r['meta']['benchmark_version']} | program build {r['meta']['program_version']}"]
    if "cells" in r:
        c, u = r["cells"], r["uses"]
        tot = c["matched"] + sum(v for k, v in c.items() if k not in ("matched", "extra in program"))
        L.append(f"BENCHMARK: file contents vs Excel | cells match {n(c['matched'])} of {n(tot)} | missing {n(c['missing in program'])} | "
                 f"extra {n(c['extra in program'])} | formula differs {n(c['formula differs'])} | value differs {n(c['value differs'])} | type differs {n(c['type differs'])}")
        L.append(f"BENCHMARK: formula uses vs Excel | checked {n(u['checked'])} | same {n(u['same'])} | missed silently {n(u['missed silently'])} | "
                 f"missed but flagged {n(u['missed but flagged'])} | extra {n(u['extra'])} | extra but flagged {n(u['extra (flagged)'])} | excel could not list {n(u['excel could not list'])}")
    if "meaning" in r:
        k, m, a = r["meaning"]["key"], r["meaning"]["months"], r["meaning"]["areas"]
        L.append(f"BENCHMARK: key numbers vs analyst | correct {n(k['correct'])} of {n(k['key numbers asked'])} | wrong {n(k['wrong'])} | "
                 f"not decided {n(k['program did not decide'])} | months correct {n(m['months correct'])} of {n(m['months asked'])} | method "
                 + ("correct" if r["meaning"]["method_correct"] else "wrong" if r["meaning"]["method_correct"] is False else "not asked"))
        L.append(f"BENCHMARK: areas vs analyst | handled correctly {n(a['handled correctly'])} of {n(a['areas'])} | cell months correct {n(a['month correct'])} | "
                 f"wrong {n(a['month wrong'])} | undecided {n(a['month undecided'])}")
        L.append(f"BENCHMARK: confidently wrong | {n(k['confidently wrong'])}")
    L.append("BENCHMARK: still open in the program | " + (" | ".join(f"{k.replace('_', ' ')} {n(v)}" for k, v in sorted(r["open"].items()) if v) or "none"))
    if "since_last" in r:
        s = r["since_last"]
        L.append(f"BENCHMARK: since last comparison | better {n(len(s['better']))} | worse {n(len(s['worse']))} | rules changed {'yes' if s['rules_changed'] else 'no'}")
    L.append("BENCHMARK: result | " + " | ".join(f"{k} {v}" for k, v in r["checks"].items()))
    return L


def cmd_physical(a):
    x = XC.scan(a.workbook)
    M = load(os.path.join(a.program, "workbook_map.json"))
    T = M["layer0"]["totals"]
    pairs = {"worksheets": (M["layer0"]["worksheets"], len(x["sheets"])), "populated_cells": (T["populated_cells"], x["totals"]["populated"]),
             "formula_cells": (T["formula_cells"], x["totals"]["formulas"]), "errors": (T["errors"], x["totals"]["errors"]),
             "array_result_cells": (T["array_result_cells"], x["totals"]["array_results"]), "tables": (M["layer0"]["tables"], x["tables"]),
             "visible_defined_names": (M["layer0"].get("visible_defined_names"), x["defined_names"])}
    print("BENCHMARK: physical tripwire | " + " | ".join(f"{k.replace('_', ' ')} {v[0]} of {v[1]} {'PASS' if v[0] == v[1] else 'FAIL'}" for k, v in pairs.items()))
    return 0 if all(v[0] == v[1] for v in pairs.values()) else 1


def main(argv=None):
    ap = argparse.ArgumentParser(prog="bench.py", description="Check the program's reading of a workbook against Excel and an analyst.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for nm in ("fingerprint", "hash"):
        h = sub.add_parser(nm); h.add_argument("--workbook", required=True)
    f = sub.add_parser("form"); f.add_argument("--workbook", required=True); f.add_argument("--quarter-end", required=True)
    f.add_argument("--out", default="answer_form.xlsx")
    c = sub.add_parser("check-form"); c.add_argument("--form", required=True); c.add_argument("--workbook", required=True)
    s = sub.add_parser("save-answers"); s.add_argument("--form", required=True); s.add_argument("--workbook", required=True)
    s.add_argument("--by", required=True); s.add_argument("--out", default="analyst_answers.json")
    cp = sub.add_parser("compare"); cp.add_argument("--workbook", default=None); cp.add_argument("--program", default=None)
    cp.add_argument("--excel-export", default=None)
    cp.add_argument("--answers", default=None); cp.add_argument("--previous", default=None); cp.add_argument("--out", default=None)
    p = sub.add_parser("physical"); p.add_argument("--workbook", required=True); p.add_argument("--program", required=True)
    a = ap.parse_args(argv)
    try:
        for attr, what in (("workbook", "workbook"), ("form", "answer form"), ("excel_export", "Excel export copy"),
                           ("answers", "saved answers file"), ("previous", "previous result file")):
            if getattr(a, attr, None):
                setattr(a, attr, find_input(getattr(a, attr), what))
        if getattr(a, "workbook", None) and a.cmd != "compare":
            check_workbook(a.workbook)
        if a.cmd in ("fingerprint", "hash"):
            print(f"BENCHMARK: workbook fingerprint {sha256_file(a.workbook)}")
            return EXIT_OK
        return {"form": cmd_form, "check-form": cmd_check_form, "save-answers": cmd_save_answers, "compare": cmd_compare,
                "physical": cmd_physical}[a.cmd](a)
    except Stop as e:
        msg = str(e)
        print(msg if msg.startswith("PREFLIGHT:") else f"STOPPED: {msg}")
        return EXIT_STOPPED
    except Exception as e:
        import traceback
        try:
            open(os.path.join(os.getcwd(), "bench_error.log"), "w").write(traceback.format_exc())
        except OSError:
            pass
        print(f"BENCHMARK ERROR: internal {type(e).__name__} - a bug, not a data problem; send this line and bench_error.log to the maintainer")
        if os.environ.get("WD_DEBUG"):
            traceback.print_exc()
        return EXIT_INTERNAL


if __name__ == "__main__":
    sys.exit(main())
