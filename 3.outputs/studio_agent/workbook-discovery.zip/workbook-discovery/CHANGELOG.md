# Changelog – workbook-discovery

## 11.6.0 – simpler, Excel-based checking
- **Excel is the answer for file contents.** New Office Script `excel-export.ts` writes, into a copy of the workbook, every
  cell (sheet, cell, formula, value, type) and what each distinct formula uses; it resumes where it stopped if it runs out of
  time ("Run again" until "Finished").
- **Same format on both sides.** The program writes `program_cells.csv` and `program_uses.csv` in Excel's layout; compare
  writes sorted `excel_cells.csv` / `program_cells.csv` that diff directly.
- **One short analyst form** (`form`): five key numbers (sheet + the cell holding the NUMBER), two months, the method, and
  labelled areas. `check-form` catches a label cell given instead of the number (and points to the number), misspelt sheets,
  badly written months; `save-answers` records them with the time. Month cells are text so Excel cannot turn them into dates.
- **The program's own answers in the same form layout** (`program_answers.xlsx` / `.json`).
- **compare** works with the Excel export, the analyst's answers, or both; plain-language Excel report; "confidently wrong"
  counted on its own; comparison with the previous result.
- **Demo** (`tools/demo.py`): the whole process on a made-up workbook in about a minute.
- Removed: the 45-cell random sample, the separate key-building step and the JSON copy-paste from the script log.
- Results folders are named after the workbook (`program_<name>`, `comparison_<name>`).
- Tests: 37 → 39 (benchmark and mutation families rewritten for the new process).


## 11.5.0 – hardening and foundations
- **Pre-flight** (`common/preflight.py`): empty, legacy `.xls`, encrypted / password-protected, `.xlsb`, damaged, non-workbook
  and oversized files are refused with one `PREFLIGHT: REFUSED` line naming the fix (exit 3), before any parsing.
- **Files by name** (`common/files.py`): inputs are found where knowledge files and uploads land; two different files with one
  name stop the run; outputs go under `/app/created`.
- **Error taxonomy**: exit 0 done | 1 internal error (one line; traceback in `run_error.log` / `bench_error.log`) | 2 usage |
  3 STOPPED (the user must act).
- **Rules as data** (`references/discovery_rules.json`, validated at start-up); the map records the rule-file hashes and the
  benchmark reports a changed hash as a method change.
- **Invariant registry** (`references/invariants.json`, `discovery/invariants.py`): eight consistency checks with per-company
  profiles; reported as "consistency, not truth" (test I.3 shows why).
- **Schemas** (`common/schema.py`) for the answer key and blind answers.
- **Vendored 11.3 code** adapted in one place (`discovery/vp_adapter.py`), still byte-identical.
- **Coverage**: small formula-free areas nothing refers to are now read completely (Layer 0 complete); a corrupt named range
  is flagged MISSING; a stale EV is caught even when the method cannot be proven.
- **Run log** (`run_log.json`): timings, peak memory, versions - outside the deterministic map.
- **Release** only through `tools/release.py` (tests, package check, zip, `RELEASE_MANIFEST.json`).
- Tests: 26 → 37 (P, I, E, S, R, C families added).

## 11.4.0 – discovery and benchmark, milestone 1
- Layer 0 / 1 / 2 discovery with graph-status flags, regions, sinks, period evidence, terminals; separate benchmark system with
  blind answer key, frozen physical sample, Excel facts script, scorer, regression and sanitised output. 26 tests.
