# common/files.py (build 11.5) - finding input files the agent passes BY NAME. Knowledge-fetched files land somewhere
# under /app, uploads under /app/uploads; tests set VALUATION_FILE_ROOTS. Same name, different content = STOPPED (never
# a silent pick); same content fetched twice = fine. Output goes to /app/created when it exists (the agent offers files
# from there), else the working folder.
import os
from common.util import Stop, sha256_file

SKIP = ("/skills", "/__pycache__", "/.git", "_tests_", "wd_tests_")


def search_roots():
    env = os.environ.get("VALUATION_FILE_ROOTS")
    if env:
        return [r for r in env.split(os.pathsep) if r]
    return [os.getcwd(), "/app/uploads", "/app"]


def find_input(name, what="file"):
    """a path or a bare file name -> absolute path. Raises Stop when missing or ambiguous."""
    if not name:
        raise Stop(f"no {what} was given")
    if os.path.isfile(name):
        return os.path.abspath(name)
    base = os.path.basename(name)
    hits = []
    for root in search_roots():
        if not os.path.isdir(root):
            continue
        for d, dirs, files in os.walk(root):
            rel = "/" + os.path.relpath(d, root).replace(os.sep, "/")       # skip rules apply BELOW the search root only
            if rel != "/." and any(s in rel for s in SKIP):
                dirs[:] = []
                continue
            if base in files:
                hits.append(os.path.join(d, base))
    hits = sorted(set(os.path.abspath(h) for h in hits))
    if not hits:
        raise Stop(f"the {what} '{base}' is not in this environment (searched {', '.join(search_roots())}): fetch it from "
                   "knowledge or ask the user to upload it", "missing_file")
    if len({sha256_file(h) for h in hits}) > 1:
        raise Stop(f"{len(hits)} different files are named '{base}': ask the user which one (or pass its full path)", "ambiguous_file")
    return hits[0]


def out_root(sub):
    base = "/app/created" if os.path.isdir("/app/created") else os.getcwd()
    p = sub if os.path.isabs(sub) else os.path.join(base, sub)
    os.makedirs(p, exist_ok=True)
    return p
