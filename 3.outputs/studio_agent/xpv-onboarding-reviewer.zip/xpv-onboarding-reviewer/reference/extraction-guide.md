# Extraction field guide (schema 3, build 13.0)

## Legend
| Term | Meaning |
|---|---|
| TTM | Trailing twelve months: the 12 months ending at the quarter end |
| EV | Enterprise value |
| Chain | metric -> multiple -> EV -> equity bridge -> waterfall -> value to XPV -> fund-reported value |
| Source id | `W1`, `W2`, ... = a supplied workbook (ids follow file names, so both agents get the same ones); `X1`, ... = a file a workbook links to that was **not** supplied (only its cached values are visible) |
| Reference | `{"source": "W1", "cell": "'Sheet Name'!D8"}`; a range is `'Sheet'!H9:S9`. Quote sheet names that contain spaces or symbols |
| Edge | One claimed relationship: `from` (a reference, or a list of them) -> `to` (a reference), with an evidence class |
| Evidence class | How strongly the workbooks prove an edge (table below) |
| Stage file | One small part of the work, saved with `checkpoint.py save`, stored append-only in `checkpoints/` |
| verify | `verify.py`: tests each claim against the workbooks' own formulas and saved values |

## The run folder
| Path | What | Written by |
|---|---|---|
| `checkpoints/01_sources.json` | fingerprints (SHA-256) and inventory summary of every workbook | `xlsx_evidence.py inventory` |
| `checkpoints/02_roles.json` ... `06_questions.json` | the extractor's stages (a re-save becomes `.r2.json`, `.r3.json`; the latest wins) | the agent, via `checkpoint.py save` |
| `checkpoints/07_validation.json` | the final verify result and the fingerprint of every stage file it checked | `verify.py --final` |
| `extraction.json` | **the primary result**, rebuilt from the checkpoints after every save | `checkpoint.py` |
| `verification.json` | every check, every edge's result | `verify.py` |
| `notes.md`, `evidence/` | working notes, inventories (`evidence/inventory/W<n>.txt`), anything forensic | agent / reader |
| `reviewer/` | the reviewer's phase 1 run: its own `checkpoints/`, `reviewer_blind.json`, `notes_blind.md` | reviewer |
| `review.json`, `checkpoints_review/`, `out/` | the reviewer's phase 2 findings and reconcile's outputs for the analyst | reviewer + `reconcile.py` |

The primary result holds conclusions only: sources and roles, the chain, key edges, discrepancies, questions, the explanation.
Sheet inventories, cell dumps and reasoning belong in `notes.md` or `evidence/`. Stage files over their size cap are refused.

## Evidence classes (one per edge)
| Class | Means | verify checks | Typical use |
|---|---|---|---|
| `direct_formula_link` | the target's formula refers to the source cell (same workbook, or a link to that exact file name) | the reference is in the formula; the numbers too if a `relation` is given | `='[2]P&L'!I9`; `=SUM(C10:N10)` with relation sum |
| `pasted_exact_match` | identical numbers, but no formula connects these two cells (typed, pasted, or a formula pointing elsewhere) | equal, and the target's formula does **not** refer to the source | add-backs typed from a schedule; a linked v3 file's cached value equal to the supplied file |
| `rounded_match` | the numbers agree only after the stated rounding/scaling, no formula connects them | `relation` op round reproduces it; no formula link | the fund types the company value in $000s |
| `arithmetic_transformation` | the target equals a stated operation on source values | the operation recomputes | the 12 months sum to the metric with no formula path |
| `contextual_support` | labels, notes or structure support it; no numeric test applies | the cells exist (never "confirmed") | a note says pro forma months come from seller financials |
| `inferred_candidate` | the most plausible reading, not yet supported | the cells exist | best guess when the budget is spent |
| `unresolved` | the supplied evidence does not establish it | the cells exist | "which version was approved" |

Numeric equality is never promoted to a link: verify contradicts a `direct_formula_link` that is not in the formula, and also a
`pasted_exact_match` that is in fact a formula link (understated evidence is still a wrong claim).

## Relations (`relation` on an edge or a discrepancy)
| op | Target equals | Example |
|---|---|---|
| `equal` (default) | the source | |
| `round` | round(source x factor, decimals) | `{"op": "round", "factor": 0.001, "decimals": 0}` for $ -> $000s |
| `scale` | source x factor | `{"op": "scale", "factor": 0.73}` |
| `sum` | the sum of every source cell (`from` is a range or a list) | `{"op": "sum"}` |
| `multiply` | source x `by` (a number or a reference) | `{"op": "multiply", "by": {"source": "W1", "cell": "Waterfall!B9"}}` |
| `negate` | minus the source | |
| `subtract` | first source minus the rest (`from` is a list) | |
Optional `tolerance` (absolute) for `equal`, `scale`, `multiply`. Ranges pair cell by cell in row order, so name ranges of the same size.

## Stage files (extractor)
**02 roles** - `produced_by`, `company` (as the fund workbook names it), `quarter_end` (YYYY-MM-DD), `sources`
(`[{id, role, period, contributes, reason}]` for **every** supplied workbook; X ids optional), `valuation_workbook`, `fund_workbook` (id or null).
Roles: `company_valuation`, `fund_valuation`, `monthly_financials`, `monthly_summary`, `pro_forma`, `other_supporting`, `not_used`,
`referenced_not_supplied`. Cap 12 KB.

**03 chain** - `chain`: `source` (the valuation workbook), `method` (EV/EBITDA multiple | EV/Revenue multiple | Blend of multiples |
Held at cost | Other), `valuation_metric`, `selected_multiple`, `enterprise_value`, `equity_value`, `value_to_xpv` (each `{cell, what, units,
currency}`, cells in the valuation workbook), optional `value_to_xpv_local`, `bridge` (`[{cell, sign, what}]`, sign as the equity formula
uses it), `waterfall` (`[{cell, what, kind}]`), `components` (blends only), `metric_window` (`{source, cells, first, last, link}`: the 12
monthly cells wherever they are, and the class of the metric's relation to them; or `{"link": "unresolved"}`), `fund_cell`
(`{source, cell, units, currency}`). Also `path` (the anchors you moved through, in order, `[{source, cell, step}]`), `direction`
(`top_down` | `bottom_up` | `other`), `downstream` (at least the edge from value_to_xpv toward the fund cell), optional `discrepancies`,
a draft `how_it_works`. Cap 30 KB.

**04 upstream** - `provenance` (edges, at most 60, material ones, one per row or range), `rejected` (`[{source, cell, what, why}]`,
material rivals only, at most 20), `deferred` (one sentence each: what you saw and did not trace, and why it is not material). Cap 60 KB.

**05 downstream** - `downstream` (edges from value_to_xpv to the fund cell and to report copies), `discrepancies`, optional `rejected`,
`deferred`. Cap 30 KB.

**06 questions** - `open_questions` (one plain sentence per decision), `inputs` (`[{source, cell, what, kind, changes, next_value_from}]`,
material typed inputs only), `how_it_works` (5-15 plain sentences, required), optional `discrepancies`, `deferred`. Cap 30 KB.

Edges and discrepancies need ids that are unique across all stages (`E1`.., `D1`..). A later stage may restate an item by id to replace it.

## Discrepancies
`{"id": "D1", "a": ref, "b": ref, "relation": {...how b would relate to a if they agreed}, "difference": b minus expected (optional),
"what": "...", "driver": "...", "driver_cells": [refs], "status": "unresolved" | "explained", "material": true}`.
verify confirms the two values really differ (by the stated amount, if given). A confirmed, unresolved discrepancy is a **correct
result**: it passes the fund check and becomes a decision for the analyst. Forcing values to reconcile is what fails.

## Reviewer files
**Blind stage 02 core** - everything in 02 roles and 03 chain together, with `direction: bottom_up`, at most 20 key `provenance`
edges, `downstream`, `discrepancies`. Cap 30 KB.
**Blind stage 03 challenges** - `challenges` (at most 12: `{id, kind, cells, note, material}`, kind = rival | weak_link | assumption |
period | units | version | discrepancy | other), `questions`, `notes`. Cap 15 KB.
**Review findings** - `produced_by`, `findings` (at most 20: `{id, type, target, evidence, note, claim, material}`), `questions`,
`overall`. Types: `confirmed`, `missed_rival`, `weak_provenance`, `unsupported_assumption`, `contradiction`, `unsure`. `target` is an
edge id, `chain.<role>`, a discrepancy id, `sources.<id>`, or `new`. `claim` is an edge (`{from, to, class, relation}`) or
`{chain_role, source, cell}` that reconcile tests with verify's own checks. Cap 40 KB.

## Statuses
**verify:** VERIFIED (nothing contradicted; chain, window and fund confirmed; all stages saved) | SUPPORTED (nothing contradicted, but
something is honestly unresolved or not checkable) | PROVISIONAL (nothing contradicted so far; stages still to come) | REVIEW (a claim is
contradicted or the files are not the ones named).
**reconcile:** READY FOR APPROVAL | NEEDS ANALYST (anything to decide, including a preserved discrepancy) | CHECKS FAILED (verify
contradicted the extraction, or the agents read different files).
**Reviewer value (reconcile):** ADDED VALUE (an evidence-backed missed rival, weak edge or contradiction) | ADDED VALUE (judgment
only) | CORROBORATION (different path) | NO INDEPENDENT VALUE SHOWN.
